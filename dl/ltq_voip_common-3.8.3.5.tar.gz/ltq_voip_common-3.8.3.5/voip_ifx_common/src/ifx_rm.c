/*****************************************************************************
**   FILE NAME        : ifx_rm.c
**   PROJECT          :
**   MODULES          : Resource Manager module
**   SRC VERSION      : V0.1
**   DATE             :
**   AUTHOR           :
**   DESCRIPTION      : This file contains all the data declarations that are
**                     used by the Resource Management Module
**   FUNCTIONS        :
**   COMPILER         : gcc
**   REFERENCE        : Coding guide lines for VSS, DIS of RM
**   COPYRIGHT        : Copyright © 2004 Infineon Technologies AG
**                     St. Martin Strasse 53; 81669 München, Germany
**                     Any use of this Software is subject to the conclusion
**                     of a respective License Agreement.Without such a
**                     License Agreement no rights to the Software are granted.
**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
*****************************************************************************/
#include "ifx_common_defs.h"
#include "ifx_os.h"
#include "ifx_debug.h"
#include "ifx_voip_defs.h"
#include "ifx_ipc.h"
#include "ifx_rm.h"

boolean  bChannelFlag=0;
boolean  bFreeChannelFlag=0;
int32 * stpiRmCoderSeg;
STATIC uint16  vstunRmAvaliableCoder=0;

/*****************************************************************************
 * *  Function Name   : IFX_RM_Init
 * *  Description     : This API is used during the start up to create the shared memory 
 * *  Input Values    : void
 * *  Output Values   : void
 * *  Return Value    : IFX_RM_SUCCESS - On Success
 * *                    IFX_RM_FAIL - On Failure
 * ****************************************************************************/
PUBLIC char8 
IFX_RM_Init(IN uint16 nGetCoder)
{  
   int32 iRmShmId;
   vstunRmAvaliableCoder=nGetCoder;
 
   if((iRmShmId =IFX_OS_ShmCreate(IFX_RM_SHARED_MEM_KEY,
                                  IFX_RM_MAXCHANNEL*vstunRmAvaliableCoder*4,
                                  IPC_CREAT|0666)) == IFX_RM_FAIL)
    {
      return IFX_RM_FAIL;
    }
   else
    { if((stpiRmCoderSeg = (int32 *)IFX_OS_ShmAttach(iRmShmId,NULL, 0))==NULL)
       {
        return IFX_RM_FAIL;
       }  
     else
      {
        memset(stpiRmCoderSeg,0,IFX_RM_MAXCHANNEL*vstunRmAvaliableCoder*4);
        return IFX_RM_SUCCESS;
      } 
    }
}

/*****************************************************************************
* *  Function Name   : IFX_RM_MgtInit
* *  Description     : This API is used by all the processes that are willing
                       to use the resource manager module.
* *  Input Values    : void
* *  Output Values   : void
* *  Return Value    : IFX_RM_SUCCESS - On Success
* *                    IFX_RM_FAIL - On Failure

* ****************************************************************************/
PUBLIC char8
IFX_RM_MgtInit()
{ int32 iRmShmId;
/* Segment probably already exists - try as a client */
if((iRmShmId = IFX_OS_ShmCreate(IFX_RM_SHARED_MEM_KEY,
                                IFX_RM_MAXCHANNEL*vstunRmAvaliableCoder*4,
                                0)) == IFX_RM_FAIL)
  {
   return  IFX_RM_FAIL;
  }
 else
  { /* Attach (map) the shared memory segment into the current process */
    if((stpiRmCoderSeg=(int32 *)IFX_OS_ShmAttach(iRmShmId,NULL,0))==NULL)
     { 
       return IFX_RM_FAIL;
     }
    else
     { 
       return IFX_RM_SUCCESS;
     }
  }
}

/*****************************************************************************
 * *  Function Name   :IFX_RM_Shut
 * *  Description     :this function to detach the shared memory..
 * *  Input Values    : void
 * *  Output Values   : void
 * *  Return Value    : IFX_RM_SUCCESS - On Success
 * *                    IFX_RM_FAIL - On Failure
 * ****************************************************************************/
PUBLIC char8 
IFX_RM_Shut(void)
{ if( IFX_OS_ShmDetach((int32 *)stpiRmCoderSeg )==IFX_RM_FAIL)
    {  
       return  IFX_RM_FAIL;
    }
  else
    {
       return IFX_RM_SUCCESS;
    }
}        

/*****************************************************************************
 * *  Function Name   :IFX_RM_MgtShut
 * *  Description     :This API is used for clearing the shared memory being
                       used by the RM module. 
 * *  Input Values    :void
 * *  Output Values   :void
 * *  Return values   :IFX_RM_SUCCESS - On Success
 * *                   IFX_RM_FAIL -  On Failure
 * ****************************************************************************/
PUBLIC char8 
IFX_RM_MgtShut(void)
{if( IFX_OS_ShmDetach((int32 *)(stpiRmCoderSeg ))==IFX_RM_FAIL)
    { 
      return  IFX_RM_FAIL;
    }
 else
    {
      return IFX_RM_SUCCESS;
    }
}

/*****************************************************************************
**  Function Name   :IFX_RM_LockCoderChannel
**  Description     :This API enables the User to get a coder channel.
**  Input Values    : connection Identifiers
**  Output Values   :void
**  Return Value    :Index of the coder channel - On Success
**                   IFX_RM_FAIL - On Failure
****************************************************************************/

PUBLIC int32
IFX_RM_LockCoderChannel(IN int32  iConnId1 ,IN int32   iConnId2)
{
  int32 iCoder;
  int32 iChannel;
 
  /*Deepak:Check if first connection id is zero*/
  if(iConnId1 == 0)
  {
	  return IFX_RM_FAIL;		 
  }
  if(iConnId2==0)
  { 
     for(iCoder=0;iCoder<vstunRmAvaliableCoder;iCoder++)
        { for(iChannel=0;iChannel<IFX_RM_MAXCHANNEL;iChannel++)
            { 
            if( *((int32 *)(stpiRmCoderSeg+iCoder*IFX_RM_MAXCHANNEL)+iChannel)==iConnId1){
            return iCoder;
				}
            }
        }

    
    for(iCoder=0;iCoder<vstunRmAvaliableCoder;iCoder++)
      {  
        bChannelFlag=1;
        for(iChannel=0;iChannel<IFX_RM_MAXCHANNEL;iChannel++)
           {           
             if( *((int32 *)(stpiRmCoderSeg+iCoder*IFX_RM_MAXCHANNEL)+iChannel)!= 0)
                { 
                 bChannelFlag=0;
                 break;
                }
           }
             if(bChannelFlag)
                {
                *((int32 *)(stpiRmCoderSeg+iCoder*IFX_RM_MAXCHANNEL)+IFX_RM_FREECHANNEL)=iConnId1;
                 return iCoder;
                }//if statement
              
      }//end of outer for loop
    return  IFX_RM_FAIL;
  }//end of iConnId2
else
 { 
   for(iCoder=0;iCoder<vstunRmAvaliableCoder;iCoder++)
      {
       for(iChannel=0;iChannel<IFX_RM_MAXCHANNEL;iChannel++)
         {
          if(*((int32 *)(stpiRmCoderSeg+iCoder*IFX_RM_MAXCHANNEL)+iChannel)==iConnId2)
           {
            return  IFX_RM_FAIL;
           }
         } 
      }
     
     
    for(iCoder=0;iCoder<vstunRmAvaliableCoder;iCoder++)
      { 
         bFreeChannelFlag=0;
             for(iChannel=0;iChannel<IFX_RM_MAXCHANNEL;iChannel++)
               {
                if(*((int32 *)(stpiRmCoderSeg+iCoder*IFX_RM_MAXCHANNEL)+iChannel)==iConnId1)
                   { 
                     bFreeChannelFlag=1;
                     break;
                    }
               }//end of inner for loop    
   
         if(bFreeChannelFlag)
              { 
            for(iChannel=0;iChannel<IFX_RM_MAXCHANNEL;iChannel++)
                {
               if(*((int32 *)(stpiRmCoderSeg+iCoder*IFX_RM_MAXCHANNEL)+iChannel) ==IFX_RM_FREECHANNEL)
                   { 
                   *((int32 *)(stpiRmCoderSeg+iCoder*IFX_RM_MAXCHANNEL)+iChannel)=iConnId2;
						 
                   return iCoder;
                   }
                }
             return  IFX_RM_FAIL;
             }//end of bFreechannelFlag Statement 
       }//end of outermost for loop
    return  IFX_RM_FAIL;
  }//end of else
}



/*****************************************************************************
**  Function Name   :IFX_RM_GetCoderChannel
**  Description     :This API is used to get the coder channel associated
                     with the given connection Identifier.
**  Input Values    :connection Identifier
**  Description     :This API enables the user to remove the association
                     between the coder channel and the connection identiffier.
**  Input Values    :connection Identifier
**  Output Values   :void
**  Return Value    :IFX_RM_SUCCESS - On Success
                     IFX_RM_FAIL - On Failure
 ****************************************************************************/

PUBLIC int32
IFX_RM_GetCoderChannel(IN int32 iConnId)
{
 int32 iCoder;
 int32 iChannel;
 for(iCoder=0;iCoder<vstunRmAvaliableCoder;iCoder++)
 {
   for(iChannel=0;iChannel<IFX_RM_MAXCHANNEL;iChannel++)
   {
     if(*((int32*)(stpiRmCoderSeg+iCoder*IFX_RM_MAXCHANNEL)+iChannel)==iConnId){
	    return iCoder;
	  }
   }
 }
 return IFX_RM_FAIL;
}

/*****************************************************************************
**  Function Name   :IFX_RM_FreeCoderChannel
**  Description     :This API is used to Free the coder channel associated
                     with the given connection Identifier.
**  Input Values    :connection Identifier
**  Description     :This API enables the user to remove the association
                     between the coder channel and the connection identiffier.
**  Input Values    :connection Identifier
**  Output Values   :void
**  Return Value    :IFX_RM_SUCCESS - On Success
                     IFX_RM_FAIL - On Failure
* ****************************************************************************/
PUBLIC int32
IFX_RM_FreeCoderChannel(IN int32 iConnId)
{
  int32 iCoder;
  int32 iChannel;
 for(iCoder=0;iCoder<vstunRmAvaliableCoder;iCoder++)
  {
   for(iChannel=0;iChannel<IFX_RM_MAXCHANNEL;iChannel++)
    {
     if(*((int32 *)(stpiRmCoderSeg+iCoder*IFX_RM_MAXCHANNEL)+iChannel)==iConnId)
       {
         *((int32 *)(stpiRmCoderSeg+iCoder*IFX_RM_MAXCHANNEL)+iChannel)=IFX_RM_FREECHANNEL;
         return IFX_RM_SUCCESS;
       }
    }
  }
  return  IFX_RM_FAIL;
}

