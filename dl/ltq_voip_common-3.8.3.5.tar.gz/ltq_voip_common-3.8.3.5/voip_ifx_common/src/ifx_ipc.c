/*****************************************************************************
 **   FILE NAME       : ifx_ipc.h
 **   PROJECT         : INCA IP and ATA
 **   MODULES         : IPC Module
 **   SRC VERSION     : V0.1
 **   DATE            : 21-03-2005
 **   AUTHOR          : Hari
 **   DESCRIPTION     : This file contains all the data declarations that are
 **                     shared across the modules
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS
 **   COPYRIGHT       : Infineon Technologies AG 2003 - 2005

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
 *****************************************************************************/

#include "ifx_common_defs.h"
#include "ifx_os.h"
#include "ifx_ipc.h"

PUBLIC char8
IFX_IPC_SendMsg(IN int32 iFd,             /* FIFO fd */
                IN uchar8 ucFrom,         /* Module Id of the addressee */
                IN uchar8 ucTo,           /* Module Id of the addressed */
                IN uint16 unMsgSize,      /* Size of message */
                IN uint32 uiReserved,
                IN char8 * pcMsg)         /* Pointer to message */
{
   x_IFX_IPC_Msg xMsg; 
   memset(&xMsg, 0, sizeof(x_IFX_IPC_Msg));

   xMsg.xHdr.ucFrom = ucFrom;
   xMsg.xHdr.ucTo = ucTo;
   xMsg.xHdr.unMsgSize = unMsgSize;
   xMsg.xHdr.uiReserved = uiReserved;

   memcpy(xMsg.acMsg, pcMsg, unMsgSize);

   if (IFX_OS_WriteFifo(iFd, (char8 *) &xMsg, 
                      unMsgSize + IFX_IPC_HDR_SIZE) < 0)
   {
      /* Error Writing Message to the FIFO */
      /* Add Debugs if required */
      return IFX_IPC_FAIL;
   }

   return IFX_IPC_SUCCESS;
}

PUBLIC char8
IFX_IPC_RecvMsg(IN int32 iFd,
                OUT uchar8 * pucFrom,
                OUT uchar8 * pucTo,
                OUT uint16 * punMsgSize,
                OUT uint32 * puiReserved,
                OUT char8 * pcMsg,
                OUT char8 * pErr)
{
   x_IFX_IPC_MsgHdr xHdr;
   int16 nBytes = 0;

   if ((nBytes = IFX_OS_ReadFifo(iFd, (char8 *) &xHdr, 
                              sizeof(x_IFX_IPC_MsgHdr))) < 0)
   {
      /* Error Reading Header */
      /* Add Debugs if required */
      *pErr = IFX_IPC_FIFO_READ_ERR;
      return IFX_IPC_FAIL;
   }
   if (nBytes != sizeof(x_IFX_IPC_MsgHdr))
   {
      return IFX_IPC_FAIL;	              
   }
   else
   {
     *pucFrom = xHdr.ucFrom;
     *pucTo = xHdr.ucTo;
     *punMsgSize = xHdr.unMsgSize;
     *puiReserved = xHdr.uiReserved;

     if((*pucFrom > IFX_IPC_APP_ID_SNMP) 
         || (*pucTo > IFX_IPC_APP_ID_SNMP)
	     	|| (*punMsgSize > IFX_IPC_MAX_MSG_SIZE))
     {
       return IFX_IPC_FAIL;
     }
     
   }
   if ((nBytes = IFX_OS_ReadFifo(iFd, pcMsg, *punMsgSize)) < 0)
   {
      /* Error Reading Header */
      /* Add Debugs if required */
      *pErr = IFX_IPC_HDR_ERR;
      return IFX_IPC_FAIL;
   }
   return IFX_IPC_SUCCESS;
}
