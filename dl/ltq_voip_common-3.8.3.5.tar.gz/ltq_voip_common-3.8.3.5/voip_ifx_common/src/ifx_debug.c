/****************************************************************************
 **   FILE NAME       : ifx_debug.c
 **   PROJECT         :  
 **   MODULES         : Debug Management module
 **   SRC VERSION     : V0.1
 **   DATE            : 01-10-2004
 **   AUTHOR          : Hari
 **   DESCRIPTION     : This file contains the code for Debug Management
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Infineon Technologies AG 2003 - 2004 

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/
#if defined(DEV_DEBUG) || defined(CUST_DEBUG)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef __LINUX__
#include <fcntl.h>
#include <unistd.h>
#endif
#include <stdarg.h>
#ifdef DBG_TIMESTAMP
#include <sys/time.h>
#endif

#include "ifx_common_defs.h"
#include "ifx_debug.h"

#define IFX_DBG_DIR "/tmp/"

#define IFX_DBG_MAX_MODULE_NAME 16
#define IFX_DBG_MAX_MODULES 32
#define IFX_DBG_MAX_LOG_FILE_NAME 64

STATIC uchar8 ucGlobalDbgLvl = 0;
#ifdef __LINUX__
char8 * vacMsgTbl[] =
{
   /* Common Errors */

   [IFX_DBG_FIFO_CREATION_ERR] = "Error Creating Fifo : %s\n",
   [IFX_DBG_FIFO_OPEN_ERR] = "Error Opening Fifo : %s\n",
   [IFX_DBG_FIFO_READ_ERR] = "Error Reading From Fifo : %d\n",
   [IFX_DBG_FIFO_WRITE_ERR] = "Error Writing To Fifo : %d\n",
   [IFX_DBG_PROCESS_CREATION_ERR] = "Process Creation Error\n",
   [IFX_DBG_GENERAL_ERR] = "Unknown Error\n",
   [IFX_DBG_INVALID_MSG_ERR] = "Invalid Message %d From %s\n",
   [IFX_DBG_MSG_PROCESS_ERR] = "Error Processing Message %d\n",
   [IFX_DBG_FUNC_ERROR] = "%s Error\n",
   [IFX_DBG_MODULE_INIT_ERR] = "%s Initialisation Failed\n",
   [IFX_DBG_CONFIG_FAILURE] = "%s Config Failure\n",
   [IFX_DBG_SOCK_CREATE_ERR] = "Error Creating Socket\n",
   [IFX_DBG_SOCK_RECV_ERR] = "Error Receiving Data from Socket : %d\n",
   [IFX_DBG_SOCK_SEND_ERR] = "Error Sending Data over Socket : %d\n",
   [IFX_DBG_READ_FAILURE] = "Read Failure\n",
   [IFX_DBG_WRITE_FAILURE] = "Write Failure\n",
   
   /* Memory Errors */

   [IFX_DBG_MEM_LIB_INIT_ERR] = "Error Initialising Memory Library\n",
   [IFX_DBG_MEM_ALLOC_ERR] = "Error Allocating Memory for %d Bytes\n",
   [IFX_DBG_MEM_FREE_ERR] = "Error Freeing Memory\n",

   /* Timer Errors */

   [IFX_DBG_TIMER_LIB_INIT] = "Error Initialising Timer Library\n",
   [IFX_DBG_TIMER_START_ERR] = "Error Starting Timer\n",
   [IFX_DBG_TIMER_STOP_ERR] = "Error Stopping Timer\n",
   [IFX_DBG_TIMER_ERR]  ="%s Failed %d\n",

   /* Common Informative Debugs */

   [IFX_DBG_STR] = "%s\n", /* Print Any String */
   [IFX_DBG_INT] = " %s :%d\n", /* Print Any integer */
   [IFX_DBG_PROCESS_STARTED] = "%s Process Started\n",
   [IFX_DBG_MODULE_INITIALIZED] = "%s Module Initialized\n", 
   [IFX_DBG_MSG_RECEIVED] = "Received Message %d From %s\n",
   [IFX_DBG_FUNC_SUCCESS] = "%s Success\n",
   [IFX_DBG_CONFIG_SUCCESS] = "%s Config Success\n",
   [IFX_DBG_SELECT_UNBLOCK] = "Select Unblocked with Value : %d\n",

   /* CM Info Type */
   [IFX_DBG_CM_REQ_TYPE] = "Req Type from CM : %d\n",
   [IFX_DBG_CM_INFO_TYPE] = "Info Type from CM : %d\n",

   /* Module Specific Errors */
   
   /* SIP */

   [IFX_DBG_SIP_CM_IF] = "CM Interface : %d %s\n",
   [IFX_DBG_SIP_RTP_IF] = "RTP Interface : %d %s\n",
   [IFX_DBG_SIP_RM_IF] = "RM Interface : %d %s\n",
   [IFX_DBG_SIP_PA_IF] = "PA Interface : %d %s\n",

   [IFX_DBG_SIP_SEND_ERR]  = 
              "Send Request Failure in Function %s : Err Code : %d\n",
   [IFX_DBG_SIP_HANDLE_RSP_ERR] =
              "Handle Response Failure in Function %s : Err Code : %d\n",
   [IFX_DBG_SIP_HANDLE_REQ_ERR] =
              "Handle Request Failure in Function %s : Err Code : %d \n",
   [IFX_DBG_SIP_CHANNEL_ID_ERR] = "Failure getting Channel\n",
   [IFX_DBG_SIP_RTP_PORT_ERR] = "Invalid RTP Port\n",
   [IFX_DBG_SIP_REPLACE_ERR] = "Replaces Present but No Dialog\n",
   [IFX_DBG_SIP_CONTACT_HDR_ERR] = "No Contact Header %s\n",
   [IFX_DBG_SIP_ENC_ERR] = "Encoder Err : %d\n",
   [IFX_DBG_SIP_DEC_ERR] = "Decode Err : %d\n",
   [IFX_DBG_SIP_ERR] = "SIP Info : %d %s\n",
   [IFX_DBG_SIP_SEND_RSP_ERR]  =
			                "Send Response Failure in Function %s : Err Code : %d\n",
	[IFX_DBG_SIP_ADDR]  = "%s Addr: %s Port: %d\n",
		
   /* PA */
	[IFX_DBG_PA_FD_OPEN_ERR] = "Error in opening %s fd\n",
	[IFX_DBG_PA_FD_CLOSE_ERR] ="Error in closeing %s fd\n",
	[IFX_DBG_PA_FILE_ERR] = "Error in file op %s\n",
	[IFX_DBG_PA_TIMEOUT] = "%s Timer Timed  Out\n", 
	[IFX_DBG_PA_ADDR_TYPE] = "Address Type:%d\n",
   [IFX_DBG_PA_ADDR_INFO] = "User=%s\nDisplay=%s\n,Ipaddr_Dom=%s\n,Port=%d\n,Protocol=%d\n", 
   [IFX_DBG_PA_TEL_ADDR_INFO] = "User=%s\nTelNo=%s\n,Protocol=%d\n", 
   [IFX_DBG_PA_IGNR_EVNT] = "Event Ignored \n", 
   [IFX_DBG_PA_FSM] = "Phone Fsm- event=%d,state=%d,flag=%x\n", 
   [IFX_DBG_PA_FCN_RET_ERR] = "%s func or ioctl ret error\n", 
   [IFX_DBG_PA_AUTH] = "Username=%s,Passwd=%s\n", 
   [IFX_DBG_PA_SET_FREE] = "Free index set is %d\n", 
   [IFX_DBG_PA_SET_USED] = "Used Index set is %d\n", 
   [IFX_DBG_PA_CONF_STATE]="Pgm State:%d,Temp Store:%s,Pgm Flg:%d Pgm Counter:%d\n",    
   [IFX_DBG_PA_FIRST_CALL_STATE]="1st Call state:%d, Conn Id:%d, Called Add:%s Call Counter:%d \n", 
   [IFX_DBG_PA_SECOND_CALL_STATE]="2nd Call state:%d, Conn Id:%d, Called Add:%s Call Counter:%d \n", 
   [IFX_DBG_PA_CALL_REGISTER]="Dial Counter:%d, Missed Counter:%d, Received Counter:%d\n", 
   [IFX_DBG_PA_DEVICE_MODE]="Device Type:%d\n", 
   [IFX_DBG_PA_CALL_PROCESSING]="Call Processing Flag:%d\n", 
   [IFX_DBG_PA_CURSOR]="Cursor Row:%d Cursor Column:%d\n",       
   [IFX_DBG_PA_CALL_CONF]="DND Mod:%d ,Extn Call Flg:%d ,Extn Call Dgt:%d,Caller id Suppn Mod:%d\n", 
   [IFX_DBG_PA_INBOX_DBG]="Msg Id:%d,Tot Msg:%d, Curr Disp Msg:%d, Curr Disp Pg:%d, Resp Choice:%d, Rd Flg:%d, Tot Pg:%d, Sender's Name:%s, Sender's No:%s, Msg:%s\n", 
	[IFX_DBG_PA_COMPOSE_DBG]=" Tot Pg:%d, Curr Ed Pg:%d, Resp Choice:%d, Cur pos:%d, Cur on:%c, Buf:%s, Time out Flg:%d, Gr Counter:%d, Caps Flg:%d\n", 
   [IFX_DBG_PA_RING_MUTE]="Ring Mute Flag:%d\n", 
   [IFX_DBG_PA_VOICE_PARAM]="Room Type:%d, Volume level:%d \n",
	[IFX_DBG_PA_VAL]="Value=%d\n",

   /* ATA */
   /* Error */
	/*********/
   [IFX_DBG_ATA_GENERAL_ERR] = "Error %s\n",/* Shweta*/
   [IFX_DBG_ATA_TONE_ERR] = "Error %s %s Tone\n",/* Shweta*/
   [IFX_DBG_ATA_SIGNAL_ERR] = "Error %s : Unknown Signal/Event from %s : %d\n",
	/**********/
   [IFX_DBG_ATA_CHANNEL_ERR] = "Error Channel %s\n",
   [IFX_DBG_ATA_INTERFACE_ERR] = "Error %s : Posting %s to %s\n",
   [IFX_DBG_ATA_DTMF_AUTH_ERR] = "Error %s : %s Authentication Info\n",
   [IFX_DBG_ATA_DTMF_FEATCODE_ERR] = "Error %s : %s Feature Code\n",
   [IFX_DBG_ATA_DTMF_FEATINFO_ERR] = "Error %s : %s Feature Info\n",
           
   /* Informative */
	/*************/
	[IFX_DBG_ATA_FUNC_ENTRY_INFO] = "Entering in Func %s in File %s\n",/*Shweta*/
	[IFX_DBG_ATA_FUNC_EXIT_INFO] = "Exiting Func %s with %s\n",/*Shweta*/
   [IFX_DBG_ATA_STRING_INFO] = "%s : %s\n",/*Shweta*/
   [IFX_DBG_ATA_INT_INFO] = "%s : %d\n",/*Shweta*/
   [IFX_DBG_ATA_SIGNAL_NUMBER] = "%s : %d\n",
	/**************/
   [IFX_DBG_ATA_SHUTDOWN] = "Shuting Down ATA Application with signal : %d\n",
   [IFX_DBG_ATA_DIALED_DIGIT] = "%s : Dialed Digit : %c\n",
   [IFX_DBG_ATA_CHANNEL_NO] = "%s : %s Channel Number : %d\n",
   [IFX_DBG_ATA_CONNECTIONID] = "%s : Connection ID : %d for Channel Id : %d\n",
   [IFX_DBG_ATA_FIFO_INFO] = "%s : %d\n",
   [IFX_DBG_ATA_TAPI_EXCEPT_BIT] = "IFX_ATA_GetEvent : Exception Bit : 0%x\n",
   [IFX_DBG_ATA_TAPI_EVENT] = "IFX_ATA_GetEvent : %s : %d\n",
   [IFX_DBG_ATA_TIMEOUT_VALUE] = "IFX_StartTimer : Timeout Value : %d \n",
   [IFX_DBG_ATA_CID_INFO] = "%s : %s Index :%d\n",
   [IFX_DBG_ATA_STATE_EVENT_INFO] =
      "%s : Extension : %d State : %d Event : %d\n",
   [IFX_DBG_ATA_DTMF_TIMER_STATUS] = "%s Timer Status : %d\n",
   [IFX_DBG_ATA_USERNAMEORPASSWD] = "%s : %s\n",
   [IFX_DBG_ATA_DTMF_EXTN_NO_INFO] = "%s :"
      "Extn No of Channel 1 and Channel 2 : %d : %d\n",
   [IFX_DBG_ATA_DTMF_PASSWD_INFO] = "%s :"
      "Password of Channel 1 and Channel 2 : %s : %s\n",
   [IFX_DBG_ATA_DTMF_FEATINFOSTR] = "%s : Feature Info :%s\n",
   [IFX_DBG_ATA_DTMF_DHCP_INFO] = "%s : DHCP Flag :%d\n",
   [IFX_DBG_ATA_DTMF_CM_EXTN_TEST] = "%s : Channel No : %d Extn No : %d\n",
   [IFX_DBG_ATA_DTMF_CM_INT_TEST] = "%s : %s :%d\n",
   [IFX_DBG_ATA_DTMF_CM_STRING_TEST] = "%s : %s :%s\n",
   [IFX_DBG_ATA_DTMF_DELIM_CNT] = "%s : Delimeter count in Feature Info : %d\n",
	 [IFX_DBG_ATA_SUCC_EXIT_INFO] = "%s Returned Success at Line: %d\n",
	 [IFX_DBG_ATA_FAIL_EXIT_INFO] = "%s Returned FAIL at Line: %d\n",

   /* RTP */
   [IFX_DBG_RTP_STR_ERR] = "Error : %s %d\n",
   [IFX_DBG_RTP_STR_PRINT] = "%s 0X%X\n",
   [IFX_DBG_RTP_IOCTL_STR_PRINT] = "Ioctl: %s 0X%X\n",
   [IFX_DBG_RTP_RTCP_STR_PRINT] = "RTCP : %s 0X%X\n",
   [IFX_DBG_RTP_SIP_IF] = "SIP Mesg - Channel : %d,  Session : %d\n",
   [IFX_DBG_RTP_RM_IF] = "RM Mesg - Channel : %d, CallId : %d\n",
   [IFX_DBG_RTP_SRTP_IF] = "SRTP IF - %s %d\n",


   /* VMAPI */

   [IFX_DBG_VMAPI_SEC_CPEID] = "Getting Object From Section: %s CpeId: %d\n",
   [IFX_DBG_VMAPI_NV_PAIRS] = "[NV-%d][%s]=[%s]\n",
   [IFX_DBG_VMAPI_NO_NV_PAIRS] = "NoOfNVPairs  %d\n",
   [IFX_DBG_VMAPI_OBJ_PREFIX] = "Prefix is %s\n",
   [IFX_DBG_VMAPI_GET_STRING] = "String from ifx_GetCfgObject %s for Object %s\n",
   [IFX_DBG_VMAPI_BUF_FROM_CFG_BUF] = "Buffer Returned = [%s]\n",
   [IFX_DBG_VMAPI_DEVICE_CONFIG] = "Info : Device configuration is not needed for %s\n",
   [IFX_DBG_VMAPI_NAME_AND_INSTANCE] = " Param Name: %s [id:%d] ** Number Of Instances : %d \n",
   [IFX_DBG_VMAPI_PARAM_PREFIX_LEN] = "Number of params=%d\nPrefix is acPrefix = %s of len = %d\n",
   [IFX_DBG_VMAPI_PARAM_PREFIX] = "Number of entries=%d\n Prefix is = %s \n",
   [IFX_DBG_VMAPI_OBJECT_TYPE_LIST] = " Parameter[%s] Is A List Of Object \n",
   [IFX_DBG_VMAPI_OBJECT_TYPE] = " Parameter[%s] Is an Object \n",
   [IFX_DBG_VMAPI_CPEID_VAL] = "CpeId is %s and val %d\n",
   [IFX_DBG_VMAPI_PCPEID_VAL] = "PCpeId is %s and val %d\n",
   [IFX_DBG_VMAPI_OBJ_FROM_NV_MISMATCH] = "*** NOT MATCHING with [%s]***\n",
   [IFX_DBG_VMAPI_GET_PARAM_TBL] = "IFX_VMAPI_GetParamTbl returns [%x : %d]\n",
   [IFX_DBG_VMAPI_GENERAL] = "%s  %s\n",
   [IFX_DBG_VMAPI_OBJ_SIZE] =  "%d %d [size of obj = %d] [num of objs = %d]\n",
   [IFX_DBG_RM_ALLOC_CODER_SUCCESS] = 
                      "Coder : %d Allocated, Session Bandwidth : %f\n",
   [IFX_DBG_RM_CODEC_BANDWIDTH] = "Codec : %hd \t Codec BW : %hf\n",
   [IFX_DBG_RM_FUNC_START] = "%s for Channel %d\n",
   [IFX_DBG_RM_LINK_BW] = "Link Bandwidth %s : %f Kbps\n",
   [IFX_DBG_RM_FRAMESIZE_CM] = "Framesize from CM %d\n",
   [IFX_DBG_RM_ERR_COUNT] = "Error Count %d\n",
   [IFX_DBG_RM_ERR_CODE] = "%d\n",
   [IFX_DBG_RM_PREF_CODEC] = "Pref Codec %s : 0x%x\n",
   [IFX_DBG_RM_ALLOC_CODER] = "AllocCoder: Channel : %d, CallId : %d\n",
   [IFX_DBG_RM_DEALLOC_CODER] = 
          "DeallocCoder: Channel : %d, CallId : %d Codec : %d, Codec : 0x%x\n",
   [IFX_DBG_RM_MODIFY_CODER] = 
          "ModifyCoder: Channel : %d, CallId : %d, Coder : %d\n",
   [IFX_DBG_RM_ALLOC_CODEC] = "AllocCoder: Codec 0x%x\n",
   [IFX_DBG_RM_SESS_BW] = "Coder Allocated %d,Session Bandwidth %f\n",
   [IFX_DBG_RM_ERR_REASON] = "%s : Reason %d\n",
   [IFX_DBG_RM_LOCK_CODEC] = "Codec 0x%x %s\n",
   [IFX_DBG_RM_CODER_MSG] = "Coder %d %s\n",
   [IFX_DBG_RM_LOCK_UNLOCK] = "Unlock Codec 0x%x, Lock Codec 0x%x\n",
   [IFX_DBG_RM_LESS_BW_ERR] = 
                 "Bandwidth %f [%f] too less to announce codec %d\n",
   [IFX_DBG_RM_LOCK_CODEC_INFO] = 
      "Lock Codec for Channel %d Call %d : Upstream BW : %f Lock Type : %d\n",
   [IFX_DBG_RM_UNLOCK_CODEC_INFO] = 
      "Unlock Codec for Channel %d Call %d : Lock Type : %d Codec %d\n",
   [IFX_DBG_RM_ALLOC_ANALOG] = 
      "AllocAnalog - Channel %d, XChannel %d, CallId %d, XCallId %d\n",
   [IFX_DBG_RM_DEALLOC_ANALOG] = "DeallocAnalog - Channel %d, CallId %d\n",
   [IFX_DBG_RM_CONV_INFO] = 
      "%s : Channel %d, CallId %d, XChannel %d, XCallId %d\n",
   [IFX_DBG_RM_FW_INFO] = 
      "Version numbers :" \
           "  nChipType         = %d\n" \
           "  nTapiVers         = %ld (%08lx)\n" \
           "  nDrvVers          = %ld (%d.%d.%d.%d)\n" \
           "  nEdspVers         = %d.%d.%d\n" \
           "  RTP/AAL2          = %x\n", 
   [IFX_DBG_RM_DEV_NAME] = "Device Name : %s\n",
   [IFX_DBG_RM_DEV_ERR] = "%s - %s %s\n",
   
   /* CM */

   [IFX_DBG_CM_REQ_TYPE_ERR] = "Error in Request Type : %d\n",
   [IFX_DBG_CM_INFO_TYPE_ERR] = "Error in Info Type : %d\n",
   [IFX_DBG_CM_CFG_FILE_ABSENT] = "Config File %s doesnt exist, Creating...\n",
   [IFX_DBG_CM_CFG_FILE_VER_ERR] = 
                         "Config File Version [%d] Mismatch, Recreating...\n",
   [IFX_DBG_CM_CFG_FILE_READ_ERR] = "Error Reading Config File\n",
   [IFX_DBG_CM_CFG_FILE_WRITE_ERR] = "Error Writing to Config File\n",
   [IFX_DBG_CM_CFG_FILE_WRITE_SIZE] = "%d Bytes written to Config file\n",
   [IFX_DBG_CM_CFG_FILE_WRITE_INFO] = 
                        "Data for Info Type [%d] written to Config file\n",


   /* SRTP */

   [IFX_DBG_SRTP_STREAM_ERR] = "Stream %d Not Available\n",
   [IFX_DBG_SRTP_PKT_ROC] = "%s - ROC Incremented : %u\n",
   [IFX_DBG_SRTP_FROM_TO_EXPIRY] = "%s <From : %llu, To : %llu> Expired\n",
   [IFX_DBG_SRTP_ENABLE_ENC_DEC_ERR] = "Enable %s Failed for %s\n",
   [IFX_DBG_SRTP_ENC_DEC_ERR] = "Error %s Packet for %s\n",
   [IFX_DBG_SRTP_SSRC] = "%s SSRC : %u\n",
   [IFX_DBG_SRTP_PKT_LEN] = "%s Packet Length for %s : %d\n",
   [IFX_DBG_SRTP_AUTH_ERR] = "Error Authenticating %s %s Packet\n",
   [IFX_DBG_SRTP_AUTH_SUCCESS] = "Successfully Authenticated %s %s Packet\n",
   [IFX_DBG_SRTP_SEQ_NUM] = "%s Sequence Number : %d\n",
   [IFX_DBG_SRTP_HIGH_SEQ_NUM] = "%s Highest Sequence Number : %d\n",
   [IFX_DBG_SRTP_REKEY] = "%s Rekey Occured for %s\n",
   [IFX_DBG_SRTP_SESS_KEY_REFRESH] = "%s Session Key Refreshed for %s\n",
   [IFX_DBG_SRTP_PKT_IDX] = "%s Packet Index : %lld\n",
   [IFX_DBG_SRTP_REPLAY_LIST_UPDATE] = "Replay List Updated\n",
   [IFX_DBG_SRTP_MKI_MISMATCH_ERR] = "%s MKI Mismatch Error for %s\n",

   /* FAX */

   [IFX_DBG_FA_SEND_PKT_TO_NET] = 
                        "Packet to Network - Channel : %d, Size : %d\n", 
   [IFX_DBG_FA_END_OF_FAX] = "End of Fax Indication for Channel : %d\n",
   [IFX_DBG_FA_GET_STATS_ERR] = 
                           "Error Getting T.38 Conn Stats for Channel : %d\n",
   [IFX_DBG_FA_SESS_START_ERR] = "Error Starting T38 Session on Channel : %d\n",
   [IFX_DBG_FA_SESS_STOP_ERR] = "Error Stopping T38 Session on Channel : %d\n",
   [IFX_DBG_FA_GENERAL_ERR] = "Error %s \n",
   [IFX_DBG_FA_SEND_DATA_TO_DP] = 
                        "Data to Datapump - Channel : %d, Size : %d\n", 
   [IFX_DBG_FA_FUNC_START] = "%s for Channel : %d\n",
   [IFX_DBG_FA_FUNC_SUCCCESS] = "%s Success for Channel : %d\n",
   [IFX_DBG_FA_FUNC_FAIL] = "%s Failure for Channel : %d\n",
   [IFX_DBG_FA_DP_ERR] = "Error from Datapump : %d\n",
   [IFX_DBG_FA_RX_MSG] = "%s Msg : %d\n",
   [IFX_DBG_FA_RX_ERR_MSG] = "Unknown Msg from %s : %d\n",
   [IFX_DBG_FA_REMOTE_ADDR] = "Remote IP %s, Port %d\n",
   [IFX_DBG_FA_INIT_PARAM] = 
     "Default Session Params \
        Options %d DBM Level %d DataWaitTime %d Recovery Pkts(High) %d \
        Recovery Pkts(Low) %d Pkts for FEC %d Gain1 %d Gain2 %d \
        DPNR %d Input Signal %d Frame Len %d MOBSM %d MOBRD %d DMBSD %d\n",
   [IFX_DBG_FA_SESS_REQ] = "%s : Channel : %d, CallId : %d\n",
   [IFX_DBG_FA_T38_PARAM] = "Rate Mgmt : %d, Err Corr : %d\n",
   [IFX_DBG_FA_ERR_REASON] = "%s for Channel : %d, Error Code : %d\n",
   [IFX_DBG_FA_DATA] = "%s : Channel %d : Bytes %d\n",
   [IFX_DBG_FA_CHANNEL] = "%s : PhoneChannel %d : Coder %d\n",
	 [IFX_DBG_FA_HEX_DISPLAY] = "%s : %x\n",
   [IFX_DBG_GENERIC]="\0", 
};
#endif
#ifdef __IMSENV__
char8 * vacMsgTbl[] =
{
   /* Common Errors */

   "Error Creating Fifo : %s\n",
   "Error Opening Fifo : %s\n",
   "Error Reading From Fifo : %d\n",
   "Error Writing To Fifo : %d\n",
   "Process Creation Error\n",
   "Unknown Error\n",
   "Invalid Message %d From %s\n",
   "Error Processing Message %d\n",
   "%s Error\n",
   "%s Initialisation Failed\n",
   "%s Config Failure\n",
   "Error Creating Socket\n",
   "Error Receiving Data from Socket : %d\n",
   "Error Sending Data over Socket : %d\n",
   "Read Failure\n",
   "Write Failure\n",
   
   /* Memory Errors */

   "Error Initialising Memory Library\n",
   "Error Allocating Memory for %d Bytes\n",
   "Error Freeing Memory\n",

   /* Timer Errors */

   "Error Initialising Timer Library\n",
   "Error Starting Timer\n",
   "Error Stopping Timer\n",
   "%s Failed %d\n",

   /* Common Informative Debugs */

   "%s\n", /* Print Any String */
   "%s Process Started\n",
   "%s Module Initialized\n", 
   "Received Message %d From %s\n",
   "%s Success\n",
   "%s Config Success\n",
   "Select Unblocked with Value : %d\n",

   /* CM Info Type */
   "Req Type from CM : %d\n",
   "Info Type from CM : %d\n",

   /* Module Specific Errors */
   
   /* SIP */

   "CM Interface : %d %s\n",
   "RTP Interface : %d %s\n",
   "RM Interface : %d %s\n",
   "PA Interface : %d %s\n",

   "Send Request Failure in Function %s : Err Code : %d\n",
   "Handle Response Failure in Function %s : Err Code : %d\n",
   "Handle Request Failure in Function %s : Err Code : %d \n",
   "Failure getting Channel\n",
   "Invalid RTP Port\n",
   "Replaces Present but No Dialog\n",
   "No Contact Header %s\n",
   "Encoder Err : %d\n",
   "Decode Err : %d\n",
   "SIP Info : %d %s\n",
   "Send Response Failure in Function %s : Err Code : %d\n",
	"%s Addr: %s Port: %d\n",
		
   /* PA */
"Error in opening %s fd\n",
"Error in closeing %s fd\n",
"Error in file op %s\n",
"%s Timer Timed  Out\n", 
"Address Type:%d\n",
 "User=%s\nDisplay=%s\n,Ipaddr_Dom=%s\n,Port=%d\n,Protocol=%d\n", 
 "User=%s\nTelNo=%s\n,Protocol=%d\n", 
"Event Ignored \n", 
 "%s func or ioctl ret error\n", 
"Username=%s,Passwd=%s\n", 
"Free index set is %d\n", 
"Used Index set is %d\n", 
"Pgm State:%d,Temp Store:%s,Pgm Flg:%d Pgm Counter:%d\n",    
"1st Call state:%d, Conn Id:%d, Called Add:%s Call Counter:%d \n", 
"2nd Call state:%d, Conn Id:%d, Called Add:%s Call Counter:%d \n", 
"Dial Counter:%d, Missed Counter:%d, Received Counter:%d\n", 
"Device Type:%d\n", 
"Call Processing Flag:%d\n", 
"Cursor Row:%d Cursor Column:%d\n",       
"DND Mod:%d ,Extn Call Flg:%d ,Extn Call Dgt:%d,Caller id Suppn Mod:%d\n", 
"Msg Id:%d,Tot Msg:%d, Curr Disp Msg:%d, Curr Disp Pg:%d, Resp Choice:%d, Rd Flg:%d, Tot Pg:%d, Sender's Name:%s, Sender's No:%s, Msg:%s\n", 
" Tot Pg:%d, Curr Ed Pg:%d, Resp Choice:%d, Cur pos:%d, Cur on:%c, Buf:%s, Time out Flg:%d, Gr Counter:%d, Caps Flg:%d\n", 
"Ring Mute Flag:%d\n", 
"Room Type:%d, Volume level:%d \n",
"Value=%d\n",

   /* ATA */
   /* Error */
	/*********/
"Error %s\n",/* Shweta*/
"Error %s %s Tone\n",/* Shweta*/
"Error %s : Unknown Signal/Event from %s : %d\n",
	/**********/
"Error Channel %s\n",
"Error %s : Posting %s to %s\n",
"Error %s : %s Authentication Info\n",
"Error %s : %s Feature Code\n",
 "Error %s : %s Feature Info\n",
           
   /* Informative */
	/*************/
"Entering in Func %s in File %s\n",/*Shweta*/
"Exiting Func %s with %s\n",/*Shweta*/
"%s : %s\n",/*Shweta*/
"%s : %d\n",/*Shweta*/
"%s : %d\n",
	/**************/
 "Shuting Down ATA Application with signal : %d\n",
 "%s : Dialed Digit : %c\n",
 "%s : %s Channel Number : %d\n",
 "%s : Connection ID : %d for Channel Id : %d\n",
"%s : %d\n",
 "IFX_ATA_GetEvent : Exception Bit : 0%x\n",
 "IFX_ATA_GetEvent : %s : %d\n",
 "IFX_StartTimer : Timeout Value : %d \n",
 "%s : %s Index :%d\n",

      "%s : Extension : %d State : %d Event : %d\n",
"%s Timer Status : %d\n",
"%s : %s\n",
 "%s :"
      "Extn No of Channel 1 and Channel 2 : %d : %d\n",
 "%s :"
      "Password of Channel 1 and Channel 2 : %s : %s\n",
 "%s : Feature Info :%s\n",
 "%s : DHCP Flag :%d\n",
"%s : Channel No : %d Extn No : %d\n",
"%s : %s :%d\n",
"%s : %s :%s\n",
 "%s : Delimeter count in Feature Info : %d\n",


   /* RTP */
 "Error : %s %d\n",
 "%s 0X%X\n",
 "Ioctl: %s 0X%X\n",
 "RTCP : %s 0X%X\n",
"SIP Mesg - Channel : %d,  Session : %d\n",
"RM Mesg - Channel : %d, CallId : %d\n",
 "SRTP IF - %s %d\n",


   /* RM */

 "Codec List Error\n",
"Codec List %s : 0x%x\n",
 "Error Filling Resource Table\n",
"Resource Table Filled Successfully\n",
 "Error Getting Bandwidth\n",
"Supported Codecs : 0x%x\n",
 "Configured Codecs %s : 0x%x\n",
"Codec : %d, Change from Phone Menu\n",
 "Error Changing Pref Codec\n",
 "Codec Change Success\n",
"Codec Change Failure\n",
 "Error Setting Link Bandwidth : %f\n",
"Configured Framesize : %d\n",
 "%s : Channel : %d, CallId : %d\n",

                      "Coder : %d Allocated, Session Bandwidth : %f\n",
 "Codec : %hd \t Codec BW : %hf\n",
 "%s for Channel %d\n",
"Link Bandwidth %s : %f Kbps\n",
 "Framesize from CM %d\n",
 "Error Count %d\n",
 "%d\n",
 "Pref Codec %s : 0x%x\n",
 "AllocCoder: Channel : %d, CallId : %d\n",

          "DeallocCoder: Channel : %d, CallId : %d Codec : %d, Codec : 0x%x\n",

          "ModifyCoder: Channel : %d, CallId : %d, Coder : %d\n",
 "AllocCoder: Codec 0x%x\n",
 "Coder Allocated %d,Session Bandwidth %f\n",
"%s : Reason %d\n",
 "Codec 0x%x %s\n",
 "Coder %d %s\n",
 "Unlock Codec 0x%x, Lock Codec 0x%x\n",

                 "Bandwidth %f [%f] too less to announce codec %d\n",

      "Lock Codec for Channel %d Call %d : Upstream BW : %f Lock Type : %d\n",

      "Unlock Codec for Channel %d Call %d : Lock Type : %d Codec %d\n",

      "AllocAnalog - Channel %d, XChannel %d, CallId %d, XCallId %d\n",
 "DeallocAnalog - Channel %d, CallId %d\n",

      "%s : Channel %d, CallId %d, XChannel %d, XCallId %d\n",
 
      "Version numbers :" \
           "  nChipType         = %d\n" \
           "  nTapiVers         = %ld (%08lx)\n" \
           "  nDrvVers          = %ld (%d.%d.%d.%d)\n" \
           "  nEdspVers         = %d.%d.%d\n" \
           "  RTP/AAL2          = %x\n", 
"Device Name : %s\n",
"%s - %s %s\n",
   
   /* CM */

"Error in Request Type : %d\n",
 "Error in Info Type : %d\n",
"Config File %s doesnt exist, Creating...\n",

                         "Config File Version [%d] Mismatch, Recreating...\n",
 "Error Reading Config File\n",
"Error Writing to Config File\n",
  "%d Bytes written to Config file\n",

                        "Data for Info Type [%d] written to Config file\n",


   /* SRTP */

 "Stream %d Not Available\n",
 "%s - ROC Incremented : %u\n",
 "%s <From : %llu, To : %llu> Expired\n",
 "Enable %s Failed for %s\n",
 "Error %s Packet for %s\n",
 "%s SSRC : %u\n",
 "%s Packet Length for %s : %d\n",
 "Error Authenticating %s %s Packet\n",
 "Successfully Authenticated %s %s Packet\n",
"%s Sequence Number : %d\n",
 "%s Highest Sequence Number : %d\n",
 "%s Rekey Occured for %s\n",
 "%s Session Key Refreshed for %s\n",
 "%s Packet Index : %lld\n",
 "Replay List Updated\n",
"%s MKI Mismatch Error for %s\n",

   /* FAX */


                        "Packet to Network - Channel : %d, Size : %d\n", 
"End of Fax Indication for Channel : %d\n",

                           "Error Getting T.38 Conn Stats for Channel : %d\n",
"Error Starting T38 Session on Channel : %d\n",
"Error Stopping T38 Session on Channel : %d\n",
"Error %s \n",

                        "Data to Datapump - Channel : %d, Size : %d\n", 
"%s for Channel : %d\n",
"%s Success for Channel : %d\n",
 "%s Failure for Channel : %d\n",
"Error from Datapump : %d\n",
"%s Msg : %d\n",
 "Unknown Msg from %s : %d\n",
"Remote IP %s, Port %d\n",
 
     "Default Session Params \
        Options %d DBM Level %d DataWaitTime %d Recovery Pkts(High) %d \
        Recovery Pkts(Low) %d Pkts for FEC %d Gain1 %d Gain2 %d \
        DPNR %d Input Signal %d Frame Len %d MOBSM %d MOBRD %d DMBSD %d\n",
 "%s : Channel : %d, CallId : %d\n",
 "Rate Mgmt : %d, Err Corr : %d\n",
 "%s for Channel : %d, Error Code : %d\n",
"%s : Channel %d : Bytes %d\n",
"%s : PhoneChannel %d : Coder %d\n",
"%s : %x\n",
 
};
#endif
typedef struct
{
   char8 cModuleName[IFX_DBG_MAX_MODULE_NAME];

   #define IFX_DBG_REGISTERED_FALSE 0
   #define IFX_DBG_REGISTERED_TRUE  1

   char8 cRegisterFlag;

   char8 ucDbgType;

   char8 ucDbgLvl;

   char8 cLogFileName[IFX_DBG_MAX_LOG_FILE_NAME];
   uint32 uiLogfileSize;

} x_IFX_DBG_RegInfo;

x_IFX_DBG_RegInfo vaxRegInfo[IFX_DBG_MAX_MODULES];

/*
 ******************************************************************************
 *  Function Name   : IFX_DBG_Init
 *  Description     : Initialises the Debug for a particular module
 *
 *  Input Values    : Module Name, Debug Type, Debug Level 
 *  Output Values   : Module Debug Id, Return value
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAILURE - On Failure
 *  Notes           :
 ******************************************************************************
*/
PUBLIC void
IFX_DBG_Init(IN char8 * pcModuleName,
             IN char8 ucDbgType,
             IN char8 ucDbgLvl,
             OUT uchar8 * pucModuleId,
             OUT char8 * pcRet)
{
   int16 nIdx = 0, nFd = 0;
   STATIC int16 nInit = 0;
   if (!nInit)
   {
      memset(vaxRegInfo, 0, sizeof(x_IFX_DBG_RegInfo) * IFX_DBG_MAX_MODULES);
      nInit = 1;
#if defined(DBG_LVL_CUSTOMER)
      ucGlobalDbgLvl = IFX_DBG_LVL_LOW;
#elif defined(DEV_DEBUG) || defined(CUST_DEBUG)
      ucGlobalDbgLvl = IFX_DBG_LVL_HIGH;
#endif

   }
   while (nIdx < IFX_DBG_MAX_MODULES)
   {
      if (!vaxRegInfo[nIdx].cRegisterFlag)
      {
         strcpy(vaxRegInfo[nIdx].cModuleName, pcModuleName);
         vaxRegInfo[nIdx].ucDbgLvl = 
           ((ucGlobalDbgLvl < ucDbgLvl) ? ucGlobalDbgLvl : ucDbgLvl);
         vaxRegInfo[nIdx].ucDbgType = ucDbgType;
#ifdef __LINUX__
         if (ucDbgType == IFX_DBG_TYPE_FILE)
         {
            sprintf(vaxRegInfo[nIdx].cLogFileName, 
               "%sifx_%s_log", IFX_DBG_DIR, pcModuleName);
            if ((nFd = open(vaxRegInfo[nIdx].cLogFileName,
                           O_WRONLY | O_CREAT | O_TRUNC, 0777)) < 0)
            {
               printf("Error Registering Module for Debug\n");
               *pcRet =  IFX_FAILURE;
               return;
            }
            close(nFd);
         }
#endif
         *pucModuleId = nIdx + 1;
         vaxRegInfo[nIdx].cRegisterFlag = IFX_DBG_REGISTERED_TRUE;
         *pcRet =  IFX_SUCCESS;
         return;
      }
      nIdx++;
   }
   if (nIdx >= IFX_DBG_MAX_MODULES)
   {
      printf("Max Modules Registered\n");
      *pcRet = IFX_FAILURE;
      return;
   }
   *pcRet =  IFX_SUCCESS;
   return;
}

/*
 ******************************************************************************
 *  Function Name   : IFX_DBG_Set
 *  Description     : Modifies the Debug settings at run-time. This API
 *                    should be called only from registered modules
 *
 *  Input Values    : Module Id, Debug Type, Debug Level 
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAILURE - On Failure
 *  Notes           :
 ******************************************************************************
*/
PUBLIC char8
IFX_DBG_Set(IN char8 * pcModuleName,
            IN uchar8 cModuleId,
            IN char8 ucDbgType,
            IN char8 ucDbgLvl)
{
   int16 nFd = 0;
	 if (cModuleId<1 || cModuleId>IFX_DBG_MAX_MODULES){
		 //printf("\nInvalid i/p params, cModuleId");
		 return IFX_FAILURE;
	 }
   if ((!(strcmp(vaxRegInfo[cModuleId-1].cModuleName, pcModuleName))) && 
       (vaxRegInfo[cModuleId-1].cRegisterFlag == IFX_DBG_REGISTERED_TRUE))
   {
      /* If Module Identification matches and the module is registered */
      vaxRegInfo[cModuleId-1].ucDbgLvl = 
           ((ucGlobalDbgLvl < ucDbgLvl) ? ucGlobalDbgLvl : ucDbgLvl);
      
      
      if (vaxRegInfo[cModuleId-1].ucDbgType != ucDbgType)
      {
#ifdef __LINUX__
         if (ucDbgType == IFX_DBG_TYPE_FILE)
         {
            sprintf(vaxRegInfo[cModuleId-1].cLogFileName, 
               "%sifx_%s_log", IFX_DBG_DIR, pcModuleName);
            if ((nFd = open(vaxRegInfo[cModuleId-1].cLogFileName,
                           O_WRONLY | O_CREAT | O_TRUNC, 0777)) < 0)
            {
               printf("Error opening Log file for Debug\n");
               return IFX_FAILURE;
            }
            close(nFd);
         }
#endif         
         vaxRegInfo[cModuleId-1].ucDbgType = ucDbgType;
      }
   }
   else
   {
 
      printf("<DBG> Fail returned %s is\n",pcModuleName);
      return IFX_FAILURE;
   }
   return IFX_SUCCESS;
}


/*
 ******************************************************************************
 *  Function Name   : IFX_DBG_Shut
 *  Description     : Cleans up the Debug Registration for a particular module
 *
 *  Input Values    : Module Debug Id 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAILURE - On Failure
 *  Notes           :
 ******************************************************************************
*/
PUBLIC void
IFX_DBG_Shut(IN uchar8  ucModuleId,
             OUT char8 * pcRet)
{
	 if (ucModuleId<1 || ucModuleId>IFX_DBG_MAX_MODULES){
		 //printf("\nInvalid i/p params, ucModuleId");
   	 *pcRet =  IFX_FAILURE;
		 return;
	 }
   memset(&vaxRegInfo[ucModuleId - 1], 0, sizeof(x_IFX_DBG_RegInfo));
   *pcRet =  IFX_SUCCESS;
   return;
}

/*
 ******************************************************************************
 *  Function Name   : IFX_DBG_Log
 *  Description     : Logs Debug messages
 *
 *  Input Values    : Module Id, Debug Level and Debug String
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAILURE - On Failure
 *  Notes           :
 ******************************************************************************
*/
PUBLIC void
IFX_DBG_Log(IN uchar8 ucModuleId,
            IN uchar8 ucDbgLvl,
			IN const char8 * pucFuncName,
            IN char8 * pucStr,
            ...)
{
   va_list ArgList;
   char8 cAppendStr[512];
   char8 cLogStr[6000];
   int16 nFd = 0;
#ifdef DBG_TIMESTAMP
   struct timeval TimeVal;
   ulong32 ulTime;
   gettimeofday(&TimeVal, NULL);
   ulTime = TimeVal.tv_sec * 1000 + TimeVal.tv_usec / 1000;
#endif
	 if (ucModuleId<1 || ucModuleId>IFX_DBG_MAX_MODULES){
		 //printf("\nInvalid i/p params, ucModuleId");
		 return;
	 }
   if (vaxRegInfo[ucModuleId - 1].ucDbgLvl >= ucDbgLvl)
   {
      va_start(ArgList, pucStr);
      /* Generic Implementation to fetch the next sting for fmt*/
      if(*pucStr == '\0'){
        pucStr = va_arg(ArgList, char *);
      }
#ifdef DBG_TIMESTAMP
        sprintf(cAppendStr, "<%lu> [%s] <%s> %s", ulTime, 
            vaxRegInfo[ucModuleId - 1].cModuleName, pucFuncName+8, pucStr);
#else
         sprintf(cAppendStr, "[%s] <%s> %s", 
             vaxRegInfo[ucModuleId - 1].cModuleName, pucFuncName+8, pucStr);
#endif
      
      if (vaxRegInfo[ucModuleId - 1].ucDbgType == IFX_DBG_TYPE_CONSOLE)
      {
         vprintf(cAppendStr, ArgList);
      }
#ifdef __LINUX__
      else if (vaxRegInfo[ucModuleId - 1].ucDbgType == IFX_DBG_TYPE_FILE)
      {
         vsprintf(cLogStr, cAppendStr, ArgList);
		 if ((strlen(cLogStr) + vaxRegInfo[ucModuleId - 1].uiLogfileSize) < (50000))  
		 {
         if ((nFd = open(vaxRegInfo[ucModuleId - 1].cLogFileName, 
                             O_WRONLY | O_APPEND, 0777)) < 0)
         	{
           	printf("Error opening log file 1\n");
           	return;
         	}
		 }
		 else
		 {
			vaxRegInfo[ucModuleId - 1].uiLogfileSize =0;
            if ((nFd = open(vaxRegInfo[ucModuleId - 1].cLogFileName, 
                             O_WRONLY| O_TRUNC , 0777)) < 0)
         	{
           	printf("Error opening log file 2\n");
           	return;
         	}
		 }

         if (write(nFd, cLogStr, strlen(cLogStr)) < 0)
         {
           printf("Error writing to log file\n");
         	 close(nFd);
           return;
         }
		 vaxRegInfo[ucModuleId - 1].uiLogfileSize += strlen(cLogStr);
         close(nFd);
      }
#endif
      va_end(ArgList);
      return;
   }

   else
   {
      return;
   }
   return;
}

#ifdef __IMSENV__
#ifdef DEV_DEBUG
void IFX_DBGA(IN uchar8 ucModuleId,IN uchar8 ucDbgLvl,IN uint16 unMsgId,...)
#else
void IFX_DBGC(IN uchar8 ucModuleId,IN uchar8 ucDbgLvl,IN uint16 unMsgId,...)
#endif
{
 va_list ArgList;
 char8 * pucFuncName="xyz";
 char8 * pucStr = vacMsgTbl[unMsgId];
 char8 cAppendStr[512];
 char8 cLogStr[512];
 int16 nFd = 0;
#ifdef DBG_TIMESTAMP
   struct timeval TimeVal;
   ulong32 ulTime;
   gettimeofday(&TimeVal, NULL);
   ulTime = TimeVal.tv_sec * 1000 + TimeVal.tv_usec / 1000;
#endif
   va_start(ArgList, unMsgId);
   if (vaxRegInfo[ucModuleId - 1].ucDbgLvl >= ucDbgLvl)
   {
      
#ifdef DBG_TIMESTAMP
      sprintf(cAppendStr, "<%lu> [%s] <%s> %s", ulTime, 
          vaxRegInfo[ucModuleId - 1].cModuleName, pucFuncName+8, pucStr);
#else
      sprintf(cAppendStr, "[%s] <%s> %s", 
             vaxRegInfo[ucModuleId - 1].cModuleName, pucFuncName+8, pucStr);
#endif
      
     
      if (vaxRegInfo[ucModuleId - 1].ucDbgType == IFX_DBG_TYPE_CONSOLE)
      {
         vprintf(cAppendStr, ArgList);
      }
#ifdef __LINUX__
      else if (vaxRegInfo[ucModuleId - 1].ucDbgType == IFX_DBG_TYPE_FILE)
      {
         vsprintf(cLogStr, cAppendStr, ArgList);
         if ((nFd = open(vaxRegInfo[ucModuleId - 1].cLogFileName, 
                             O_WRONLY | O_APPEND, 0777)) < 0)
         {
           printf("Error opening log file\n");
           return;
         }

         if (write(nFd, cLogStr, strlen(cLogStr)) < 0)
         {
           printf("Error writing to log file\n");
           return;
         }
         close(nFd);
      }
#endif
      va_end(ArgList);
      return;
   }

   else
   {
      return;
   }

   return;
 }

#if 0
void
IFX_DBG(IN uchar8 ucModuleId,
		IN uchar8 ucDbgLvl,
		IN uint16 unMsgId)
{ 
   char8 * pucFuncName="xyz";
   char8 * pucStr = vacMsgTbl[unMsgId];
   char8 cAppendStr[512];
   char8 cLogStr[512];
   int16 nFd = 0;
#ifdef DBG_TIMESTAMP
   struct timeval TimeVal;
   ulong32 ulTime;
   gettimeofday(&TimeVal, NULL);
   ulTime = TimeVal.tv_sec * 1000 + TimeVal.tv_usec / 1000;
#endif

   if (vaxRegInfo[ucModuleId - 1].ucDbgLvl >= ucDbgLvl)
   {
#ifdef DBG_TIMESTAMP
      sprintf(cAppendStr, "<%lu> [%s] <%s> %s", ulTime, 
          vaxRegInfo[ucModuleId - 1].cModuleName, pucFuncName+8, pucStr);
#else
      sprintf(cAppendStr, "[%s] <%s> %s", 
             vaxRegInfo[ucModuleId - 1].cModuleName, pucFuncName+8, pucStr);
#endif
      
      
      if (vaxRegInfo[ucModuleId - 1].ucDbgType == IFX_DBG_TYPE_CONSOLE)
      {
         printf("%s",cAppendStr);
      }
#ifdef __LINUX__
      else if (vaxRegInfo[ucModuleId - 1].ucDbgType == IFX_DBG_TYPE_FILE)
      {
         vsprintf(cLogStr, cAppendStr, ArgList);
         if ((nFd = open(vaxRegInfo[ucModuleId - 1].cLogFileName, 
                             O_WRONLY | O_APPEND, 0777)) < 0)
         {
           printf("Error opening log file\n");
           return;
         }

         if (write(nFd, cLogStr, strlen(cLogStr)) < 0)
         {
           printf("Error writing to log file\n");
           return;
         }
         close(nFd);
      }
#endif
      return;
   }

   else
   {
      return;
   }
   return;
}
#endif
#endif /* __IMSENV__*/
#endif /* DEV_DEBUG */
