/****************************************************************************************
 **   SRC_FILE          : IFIN_MLIB_Interface_Import.h
 **   PROJECT           : Memory library
 **   MODULES           : Memory library
 **   SRC VERSION       : v2.0
 **   DATE              : 
 **   AUTHOR            : Kumar Swamy .D
 **   DESCRIPTION	: 
 **   FUNCTIONS         : 
 **   COMPILER          : Microsoft Visual C++ Studio, Version 6.0
 **   REFERENCE         : Coding Guildelines for IFIN COM
			
 **   COPYRIGHT         : Infineon Technologies AG 2000-2004
 **  Version Control Section  **        
 **   $Author$    
 **   $Date$      
 **   $Revisions$ 
 **   $Log$       
*****************************************************************************************/

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <errno.h>

#ifndef __IFIN_MLIB_INTERFACE_IMPORT_H__

#define __IFIN_MLIB_INTERFACE_IMPORT_H__

/*
#include "IFIN_IAD_Common.h"
*/
#include "ifx_common_defs.h"

/* The follwoing two defines can't change dinamically with out reflecting into
    IFIN_MLIB_Main.h  */
#define IFIN_MLIB_PROTECT  								1
#define IFIN_MLIB_DEBUG        						1


#define IFIN_MLIB_USER_MEMORY        			0x01
#define IFIN_MLIB_DYNAMIC_MEMORY     			0x02
#define IFIN_MLIB_SHARED_MEMORY      			0x03

#define IFIN_MLIB_NO_WAIT     						1
#define IFIN_MLIB_WAIT_FOREVER 						0xffff

#define IFIN_MLIB_PTR_FEATURE        			0x10
#define IFIN_MLIB_PTR_OFFSET_FEATURE 			0x20


#if IFIN_MLIB_DEBUG

#define IFIN_MLIB_DEBUG_OVER_HEAD       			  4
#define IFIN_MLIB_DEBUG_OVER_HEAD_FOR_SEG			  4
#define IFIN_MLIB_DEBUG_OVER_HEAD_FOR_SEG_GRPS  12

#else

#define IFIN_MLIB_DEBUG_OVER_HEAD       			  0
#define IFIN_MLIB_DEBUG_OVER_HEAD_FOR_SEG			  0
#define IFIN_MLIB_DEBUG_OVER_HEAD_FOR_SEG_GRPS  0

#endif

#if IFIN_MLIB_PROTECT

#define IFIN_MLIB_PROTECT_OVER_HEAD			          8
#define IFIN_MLIB_PROTECT_OVER_HEAD_FOR_SEG			  1
#define IFIN_MLIB_PROTECT_OVER_HEAD_FOR_SEG_GRPS  0

#else

#define IFIN_MLIB_PROTECT_OVER_HEAD			          0
#define IFIN_MLIB_PROTECT_OVER_HEAD_FOR_SEG			  0
#define IFIN_MLIB_PROTECT_OVER_HEAD_FOR_SEG_GRPS  0

#endif





#define IFIN_MLIB_PTR_OFFSET_FEATURE_OVER_HEAD 			14
#define IFIN_MLIB_PTR_FEATURE_OVER_HEAD 			      4
#define IFIN_MLIB_NO_FEATURE_OVER_HEAD 			        2

#define IFIN_MLIB_MGT_STRUCT_SIZE     			        24


#define IFIN_MLIB_SEG_GROUP_MGT_SIZE  			        16





#define IFIN_MLIB_NULL         						0

#define IFIN_MLIB_HEAD_OFFSET  						0
#define IFIN_MLIB_TAIL_OFFSET  						1

#define IFIN_MLIB_SUCCESS                 0
#define IFIN_MLIB_FAILURE                -1    /* 65535 */

#define IFIN_MLIB_INSUFFICEINT_DATA      -2
#define IFIN_MLIB_OUT_OF_SEM_MEMORY      -3
#define IFIN_MLIB_OUT_OF_MEMORY          -4
#define IFIN_MLIB_OUT_OF_SHM             -5
#define IFIN_MLIB_WRONG_DATA             -6

#define IFIN_MLIB_ZERO_SEG_SIZE          -7
#define IFIN_MLIB_CROSSED_MAX_SIZE       -8
#define IFIN_MLIB_BUFFERS_EMPTY          -9
#define IFIN_MLIB_INVALID                -10

#define IFIN_MLIB_WRONG_SEG_NUMBER       -11
#define IFIN_MLIB_SEG_IS_ALREADY_FREED   -12



#define IFIN_MLIB_PERMS        0666

/* typedef uchar8* IFIN_MLIB_Id;*/
#define IFIN_MLIB_Id uchar8*

/********************************************************************

Required Segments information. Information will be given by user.

********************************************************************/

typedef struct
{
  uint16 unNumOfSegs;
  uint32 uiSegSize;
}x_IFIN_MLIB_SegInfo;



int16 IFIN_MLIB_Init(
                      IFIN_MLIB_Id         *pMlibId,
                      uint16               unKeyId,
                      uchar8                ucMmuType,
                      uchar8                *pucUserMemory,
                      x_IFIN_MLIB_SegInfo  *pxSegInfo,
                      uint32                uiSharedDataSize
                    ) ;

IFIN_MLIB_Id IFIN_MLIB_GetId( uint16 unKeyId);

int16 IFIN_MLIB_GetSeg( IFIN_MLIB_Id MlibId,
                         uint32 uiSegSize, uint16 *punSegNum);

#if IFIN_MLIB_DEBUG

void IFIN_MLIB_GetSideUpdateDbgInfo( IFIN_MLIB_Id        MlibId,
                                     uchar8              ucDbgIndex,
                                     uchar8              ucIndex,
                                     uint32              uiMsgSize,
                                     uint16              unSegNum
                                   );

void IFIN_MLIB_FreeSideUpdateDbgInfo(IFIN_MLIB_Id        MlibId,
                                     uint8               ucGrpNum,
                                     uint16              unSegNum
                                   );
#endif

uchar8* IFIN_MLIB_GetSegAddr (IFIN_MLIB_Id MlibId, uint16 unSegNum);

uint32 IFIN_MLIB_GetSegSize(IFIN_MLIB_Id MlibId, uint16 unSegNum);

int16 IFIN_MLIB_SetSegOffset(IFIN_MLIB_Id MlibId, uint16 unSegNum,
                              uint8 ucOffsetType,  uint32 uiOffsetValue);

int16 IFIN_MLIB_GetSegOffset(IFIN_MLIB_Id MlibId, uint16 unSegNum,
                             uint8 ucOffsetType,  uint32* puiOffsetValue);

int16 IFIN_MLIB_DupSeg(IFIN_MLIB_Id MlibId, uint16 unSegNum);

int16 IFIN_MLIB_FreeSeg(IFIN_MLIB_Id MlibId, uint16 unSegNum);

uchar8* IFIN_MLIB_AllocMem( IFIN_MLIB_Id MlibId,uint32 uiSegSize );

int16 IFIN_MLIB_GetSegNumOfAddr(IFIN_MLIB_Id MlibId,uchar8 *pucSegAddr);

uint32 IFIN_MLIB_GetMemSize(IFIN_MLIB_Id MlibId, uchar8 *pucSegAddr );

int16 IFIN_MLIB_SetMemOffset(IFIN_MLIB_Id MlibId, uchar8* pucSegAddr,
                              uint8 ucOffsetType,  uint32 uiOffsetValue);

int16 IFIN_MLIB_GetMemOffset(IFIN_MLIB_Id MlibId, uchar8* pucSegAddr,
                              uint8 ucOffsetType,  uint32* puiOffsetValue);

int16 IFIN_MLIB_DupMem(IFIN_MLIB_Id MlibId, uchar8* pucSegAddr);

int16 IFIN_MLIB_FreeMem(IFIN_MLIB_Id MlibId,uchar8 *pSegAddr);

uchar8* IFIN_MLIB_LockShm(IFIN_MLIB_Id MlibId, uint16 unWaitNum);

int16 IFIN_MLIB_UnlockShm(IFIN_MLIB_Id MlibId);

int16 IFIN_MLIB_Free(IFIN_MLIB_Id MlibId);

/*
#if IFIN_MLIB_DEBUG


void IFIN_MLIB_DbgInfo(IFIN_MLIB_Id MlibId);
#endif 
*/

#endif

