/*****************************************************************************
 **   FILE NAME       : ifx_ipc.c
 **   PROJECT         : INCA IP and ATA
 **   MODULES         : IPC Module
 **   SRC VERSION     : V0.1
 **   DATE            : 21-03-2005
 **   AUTHOR          : Hari
 **   DESCRIPTION     : This file contains all the data declarations that are
 **                     shared across the modules
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS
 **   COPYRIGHT       : Infineon Technologies AG 2003 - 2005

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
 *****************************************************************************/
#ifndef __IFX_IPC_H__
#define __IFX_IPC_H__

#define IFX_IPC_FIFO_DIR   "/tmp"

#define IFX_IPC_FIFO_PERM  0644

/* All modules write to Monitor thru this Fifo */
#define IFX_IPC_MON_FIFO     IFX_IPC_FIFO_DIR"/MonFifo"

/* All modules write to RM thru this Fifo */
#define IFX_IPC_RM_FIFO     IFX_IPC_FIFO_DIR"/RmFifo"

/* All modules write to RTP thru this Fifo */
#define IFX_IPC_RTP_APP_FIFO    IFX_IPC_FIFO_DIR"/RtpAppFifo"
#define IFX_IPC_RTP_AGENT_FIFO    IFX_IPC_FIFO_DIR"/RtpAgentFifo"

/* All modules writes to APP thru this Fifo */
/* For IIP, APP = PA: for ATA, APP = ATA */
#define IFX_IPC_APP_FIFO     IFX_IPC_FIFO_DIR"/AppFifo"
#define IFX_IPC_TIM_FIFO    IFX_IPC_FIFO_DIR"/TimFifo"
#if 0 /* CM is not used now */
/* All modules write to CM thru this Fifo */
#define IFX_IPC_CM_FIFO     IFX_IPC_FIFO_DIR"/CmFifo"
#endif
/* This FIFO is used by VMAPI and Config Agent */
#define IFX_IPC_VMAPI_FIFO     IFX_IPC_FIFO_DIR"/VmpaiFifo"

/* This FIFO is used by GwApp and voice device listening thread */
#define IFX_IPC_VDSP_FIFO     IFX_IPC_FIFO_DIR"/VdspFifo"

/* All modules write to FA thru this Fifo */
#define IFX_IPC_FAX_APP_FIFO    IFX_IPC_FIFO_DIR"/FaxAppFifo"
#define IFX_IPC_FAX_AGENT_FIFO    IFX_IPC_FIFO_DIR"/FaxAgentFifo"

/* All modules write to SS thru this Fifo */
#define IFX_IPC_SS_FIFO     IFX_IPC_FIFO_DIR"/SsFifo"
#define IFX_IPC_SSS_FIFO     IFX_IPC_FIFO_DIR"/SssFifo"

/* CM writes to WebServer thru this Fifo */
#define IFX_IPC_WEB_FIFO   IFX_IPC_FIFO_DIR"/WebFifo"

/* CM writes to SNMP Agent thru this Fifo */
#define IFX_IPC_SNMP_FIFO   IFX_IPC_FIFO_DIR"/SnmpFifo"

/* DHCP writes to CM thru this Fifo */
#define IFX_DHCP_CM_FIFO   IFX_IPC_FIFO_DIR"/DhcpFifo"


#define IFX_IPC_SUCCESS 0
#define IFX_IPC_FAIL    -1

#define IFX_IPC_APP_NAME_START  "VoIPStartup"
#define IFX_IPC_APP_NAME_PA  "PhoneApp"
#define IFX_IPC_APP_NAME_ATA  "AtaApp"
#define IFX_IPC_APP_NAME_CM    "CfgMod"
#define IFX_IPC_APP_NAME_RM    "ResMgr"
#define IFX_IPC_APP_NAME_RTP   "Rtp"
#define IFX_IPC_APP_NAME_RTPAgent   "RtpAgent"
#define IFX_IPC_APP_NAME_SRTP "Srtp"
#define IFX_IPC_APP_NAME_SIP   "SipUA"
#define IFX_IPC_APP_NAME_FAX    "Fax"
#define IFX_IPC_APP_NAME_FAXAgent "FaxAgent"
#define IFX_IPC_APP_NAME_DHCP "Dhcp"
#define IFX_IPC_APP_NAME_SNMP "Snmp"
#define IFX_IPC_APP_NAME_RTPAPP "RtpApp"
#define IFX_IPC_APP_NAME_SIPAPP "SipApp"
#define IFX_IPC_APP_NAME_DECT_TK "DectTk"


#define IFX_RM_SHARED_MEM_KEY 1234
#define IFX_CM_SHARED_MEM_KEY 2345
#define IFX_CM_SEMAPHORE_KEY  3456
#define IFX_CM_RTP_SEMAPHORE_KEY 4567

typedef enum
{
   IFX_IPC_APP_ID_START = 1,
   IFX_IPC_APP_ID_APP = 2,
   IFX_IPC_APP_ID_VMAPI = 3,
   IFX_IPC_APP_ID_RM = 4,
   IFX_IPC_APP_ID_RTP = 5,
   IFX_IPC_APP_ID_WEB = 6,
   IFX_IPC_APP_ID_SIP = 7,
   IFX_IPC_APP_ID_FA = 8,
   IFX_IPC_APP_ID_DHCP =9,
   IFX_IPC_APP_ID_SNMP =10,
   IFX_IPC_APP_ID_RTPAPP =11,
   IFX_IPC_APP_ID_RTPAGENT =12,
   IFX_IPC_APP_ID_SIPAPP =13,
   IFX_IPC_MAX_MODULES

} e_IFX_IPC_AppId;

typedef struct
{
   /* ID of the module sending the message */
   uchar8 ucFrom; 
   /* ID of the module to which the message is addressed */
   uchar8 ucTo; 
   /* ucTo may be just used for strict validation, since
      the message destined for a module will be in the 
      module's FIFO anyway
    */
   /* Size of the Message */
   uint16 unMsgSize;
   /* Reserved for future use */
   uint32 uiReserved;

} x_IFX_IPC_MsgHdr;

#define IFX_IPC_HDR_SIZE sizeof(x_IFX_IPC_MsgHdr)
#define IFX_IPC_MAX_MSG_SIZE (4192 - IFX_IPC_HDR_SIZE)

typedef struct
{
   x_IFX_IPC_MsgHdr xHdr;

   /* Buffer to contain the message */
   char8 acMsg[IFX_IPC_MAX_MSG_SIZE];
   /* Each module is expected to write a union in the acMsg part */

} x_IFX_IPC_Msg;

/* Error Codes */
typedef enum
{
   IFX_IPC_NO_ERR = 0,
   IFX_IPC_FIFO_READ_ERR = 1,
   IFX_IPC_HDR_ERR,
   IFX_IPC_FIFO_WRITE_ERR,
   IFX_IPC_MSG_ERR
} e_IFX_IPC_Error;

/* PUBLIC Functions */

EXTERN char8
IFX_IPC_SendMsg(IN int32 iFd,             /* FIFO fd */
                IN uchar8 ucFrom,         /* Module Id of the addressee */
                IN uchar8 ucTo,           /* Module Id of the addressed */
                /* ucFrom and ucTo take one of e_IFX_IPC_AppId values */
                IN uint16 unMsgSize,      /* Size of message */
                IN uint32 uiReserved,
                IN char8 * pcMsg);        /* Pointer to message */

EXTERN char8
IFX_IPC_RecvMsg(IN int32 iFd,
                OUT uchar8 * pucFrom,
                OUT uchar8 * pucTo,
                OUT uint16 * punMsgSize,
                OUT uint32 * puiReserved,
                OUT char8 * pcMsg,
                OUT char8 * pErr);

  
#endif  /* __IFX_IPC_H__ */

