/**************************************************************************
 **   FILE NAME       : ifx_voip_defs.h
 **   PROJECT         : INCA IP Phone 
 **   MODULES         : Common voip defintions
 **   SRC VERSION     : V0.1
 **   DATE            : 15-06-2005
 **   AUTHOR          : Radvajesh.M
 **   DEPENDENCIES    : ifx_common_defs.h
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS ,
 **
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_VOIP_DEFS_H__
#define __IFX_VOIP_DEFS_H__

/* Constants */
/* Number of  Fax protocols supported */
#define IFX_MAX_FAX_PROTO 2

/* Transport Address Size */
#define IFX_MAX_TSP_ADDR 128

/* Display name Size */
#define IFX_MAX_DISP_NAME 32  

/* User name Size */
#define IFX_MAX_USR_NAME 32

/*User Password */
#define IFX_MAX_USR_PASSWD 16

/* Domain Name Size */
#define IFX_MAX_DOMAIN_NAME 128

/* Sip User Agent Size */
#define IFX_MAX_USR_AGENT 255

/* SIP Message size */
#define IFX_MSG_SIZE 500

/* Max Channels supported by the hardware */

#ifdef IIP
#define IFX_MAX_ENDPTS 1
#define IFX_MAX_FXO_PORT 1
#define IFX_MAX_FXS_PORT 1
#else
#define IFX_MAX_FXS_PORT 2
#define IFX_MAX_FXO_PORT 1
#define IFX_MAX_ENDPTS IFX_MAX_FXS_PORT + IFX_MAX_FXO_PORT
#define IFX_MAX_CODERS 4
#endif

/* ON / OFF flags */
#define IFX_OFF 0
#define IFX_ON  1

/* Max International and State code size */
#define IFX_TEL_CODE_SIZE 24

/* Max Time stamp size for call logs */
#define IFX_TIME_STR_SIZE 16

/* Definitions related to Jitter Buffer */ 
#define IFX_JB_FIXED 1 
#define IFX_JB_ADAPTIVE 2 

/* Call Fwd Types*/
#define IFX_FWD_UNCOND 0x0001
#define IFX_FWD_ONBUSY 0x0002
#define IFX_FWD_NOANSW 0x0004
#define IFX_FWD_NONE 0x0008

/* Max Phone book entires  */
#ifdef IIP
  #define IFX_MAX_PB_ENTRIES 100
#else
  #define IFX_MAX_PB_ENTRIES 10
#endif

/* Max Call Registor entries per call Reg*/
#ifdef IIP
#define IFX_MAX_CR_ENTRIES 10
#else
#define IFX_MAX_CR_ENTRIES 10
#endif

/* Max Sip Messages stored */
#define IFX_MAX_MESSAGES 12

/* Max Fast Dial entries */
#define IFX_MAX_FAST_DIAL 10

/* Max Dial code Size*/
#define IFX_MAX_DIAL_CODE_SIZE 16

/* Max Train Vector -VAD support*/
#define IFX_MAX_TRAIN_VECT 10
#define IFX_MAX_TRAIN_VECT_SIZE 188

/* PPPOE Authentication Type*/
#define IFX_PPPOE_PAP 1
#define IFX_PPPOE_CHAP 2

/* Wan interface type */
#define IFX_WAN_IF_FIXED 1
#define IFX_WAN_IF_DHCPC 2
#define IFX_WAN_IF_PPPOE 4

/* Call on Hold Address*/
#define IFX_USE_ZERO_ADDR_ONHOLD 0
#define IFX_USE_RFC3264_ON_HOLD 1
 
/* Codec list */
#define IFX_RM_G711_ALAW     0x00000001
#define IFX_RM_G711_ULAW     0x00000002
#define IFX_RM_G729_8        0x00000004
#define IFX_RM_G729_E        0x00000008
#define IFX_RM_G723          0x00000010
#define IFX_RM_G723_5_3      0x00000020
#define IFX_RM_G723_6_3      0x00000040
#define IFX_RM_G728          0x00000080
#define IFX_RM_LINEAR_256    0x00000100
#define IFX_RM_LINEAR_16     0x00000200
#define IFX_RM_LINEAR_8      0x00000400
#define IFX_RM_G726_16       0x00000800
#define IFX_RM_G726_24       0x00001000
#define IFX_RM_G726_32       0x00002000
#define IFX_RM_G726_40       0x00004000
#define IFX_RM_G722_64       0x00008000
#define IFX_RM_T38           0x00010000
#define IFX_RM_T38_UDP       0x00020000
#define IFX_RM_T38_TCP       0x00040000


#define IFX_MAX_CODECS 17

/* Used for Prefered codec flag*/
#define IFX_CONF_PREF_CODEC 1
#define IFX_USE_LOW_BW_CODEC 2

/* Maximum Number of Hosts that INCA IP can Communicate*/
#define IFX_MAX_HOSTS 2

/* Key management Parmeters */
#define IFX_MAX_SRTP_LIFE_TIME 281474976710655LL /* 2^48-1 */
#define IFX_MAX_SRTCP_LIFE_TIME 2147483647 /*2^31-1*/

#define IFX_MASTER_KEY_LENGTH 32    /* 256 bits */
#define IFX_MATER_SALT_LENGTH 32   /* 256 bits */

/* Maximun Master Keys that a single SRC can have so that it can be rekeyed */
/* This value is not specified by the RFC*/
#define IFX_MAX_MASTER_KEYS 10

/* IP address string length*/
#define IFX_MAX_IP_ADDRESS_LEN 16

/* T38 protocol type*/
#define IFX_RM_T38_TRANS_PROTO_TCP 0
#define IFX_RM_T38_TRANS_PROTO_UDP 1

/* T38 Protocol Version */
#define IFX_RM_T38_VERSION 1

/* Rate management */
#define IFX_RM_CAP_FL_TCF_LOCAL 0x01
#define IFX_RM_CAP_FL_TCF_TRANSFERRED 0x02

/* Max bit Rate */
#define IFX_RM_T38_MAX_BIT_RATE             14400

/* Bit options*/
#define IFX_RM_CAP_FL_OPT_FILL_BIT_REMOVAL 0x0001
#define IFX_RM_CAP_FL_OPT_TRANSCODING_MMR  0x0002
#define IFX_RM_CAP_FL_OPT_TRANSCODING_JBIG 0x0004

/* UDP Error Correction*/
#define IFX_RM_CAP_FL_EC_REDUNDANCY 0x01
#define IFX_RM_CAP_FL_EC_FEC 0x02

/* NSX Info */
#define IFX_FA_NSX_MAX_SIZE  40

/* Preferred T38 Connection */
#define IFX_FA_T38_CONN_UDP 1
#define IFX_FA_T38_CONN_TCP 2
#define IFX_FA_T38_CONN_UDP_TCP 3
#define IFX_FA_T38_CONN_TCP_UDP 4
#define IFX_FA_T38_CONN_DYN 5

/* Version String length*/
#define IFX_MAX_VERSION_STRING 128

/* Debug Level Types*/
#define IFX_DBG_LVL_NONE 0
#define IFX_DBG_LVL_ERROR 1
#define IFX_DEBG_LVL_LOW 2
#define IFX_DEBG_LVL_NORMAL 3
#define IFX_DEBG_LVL_HIGH 4

/* Debug Types */
#define IFX_DBG_NONE 0
#define IFX_DBG_CONSOLE 1
#define IFX_DBG_FILE 2

/* Registor Status */
#define IFX_REG_INACTIVE 0
#define IFX_REG_ACTIVE 1

/* RTP Mib Information */
/* Maximum Text length for SDES */
#define IFX_RTP_MIB_TEXT_LEN      255

/* Stun Nat types */
#define IFX_NAT_TYPE_OPEN 0x00
#define IFX_NAT_TYPE_FULL 0x01
#define IFX_NAT_TYPE_RESTRICT 0x02
#define IFX_NAT_TYPE_PORTRESTRICT 0x03
#define IFX_NAT_TYPE_SYMMETRIC 0x04
#define IFX_NAT_TYPE_FIREWALL 0x05
#define IFX_NAT_TYPE_BLOCK 0x06
#define IFX_NAT_TYPE_UNKNOWN 0x07
#define IFX_NAT_TYPE_HAIRPIN 0x08
#define IFX_NAT_TYPE_NONAT 0xFF

/* Max call block list */
#define IFX_MAX_CALLBLOCK_LIST 10

/* Max Vertical service codes*/
#define IFX_MAX_DIALCODE_SIZE 11

/* Gateway modes */
#define IFX_PSTN_FWD_MODE 1
#define IFX_GATWAY_MODE 2

/* Max Dial Plan to be configured */
#define IFX_MAX_DIALPLAN_SIZE 60

/* Max Auth Info */
#define IFX_MAX_AUTHINFO 5

/* Max Profiles */
#define IFX_MAX_PROFILES 3
/* Enumerations */


/*MAX Channel in RM */
#define IFX_RM_MAXCHANNEL 2 
#define IFX_RM_FREECHANNEL 0

/*Call Forward Enum*/
typedef enum
{
  IFX_FWD_DISABLE,
  IFX_FWD_BUSY,
  IFX_FWD_NO_ANS,
  IFX_FWD_ALWAYS
}e_PAToSIP_CallFwd;

#ifndef __IFX_COMMON_DEFS_H__

/* Address Type */
typedef  enum 
{
   IFX_IP_ADDR=1,
   IFX_TEL_NUM,
   IFX_SIP_URL,
   IFX_EXTN
} e_IFX_AddrType;

/* Enumerations for Transport Type */
typedef enum
{
   IFX_TRPROTO_NONE,
   IFX_TRPROTO_UDP,
   IFX_TRPROTO_TCP
} e_IFX_TransportType;


/* Enumerations for DTMF */ 
typedef enum
{ 
   IFX_DTMF_NONE,
   IFX_DTMF_INBAND_EVENT,
   IFX_DTMF_INBAND_VOICE,
   IFX_DTMF_INFO_METHOD,
   IFX_DTMF_BOTH
} e_IFX_DtmfType; 

#endif
/* Room Type */
typedef enum
{
   IFX_ROOM_NORMAL,
   IFX_ROOM_NOISY,
   IFX_ROOM_ECHOIC
}e_IFX_RoomType;

/* Volume Levels */
typedef enum
{
   IFX_VOL_LEVEL1,
   IFX_VOL_LEVEL2,
   IFX_VOL_LEVEL3,
   IFX_VOL_LEVEL4,
   IFX_VOL_LEVEL5,
   IFX_VOL_LEVEL6,
   IFX_VOL_LEVEL7,
   IFX_VOL_LEVEL8
}e_IFX_VolLevelType;

/* Different encyrption transforms that can be used */
typedef enum
{
   IFX_NULL_ENCR =0,
   /* Advanced Encription Standard Tranforms */
   /* Counter Mode */
   IFX_AES_CM,
   IFX_AES_ECB,
   IFX_AES_CBC,
   IFX_AES_CFB,
   IFX_AES_OFB,

   /* DES Transforms */
   IFX_DES_CM,
   IFX_DES_ECB,
   IFX_DES_CBC,
   IFX_DES_CFB,
   IFX_DES_OFB,
 
   /*3DES Transforms */
   IFX_3DES_CM,
   IFX_3DES_ECB,
   IFX_3DES_CBC,
   IFX_3DES_CFB,
   IFX_3DES_OFB,
}e_IFX_EncrTransf;

/* Different Authentication Transforms*/
typedef enum
{
   IFX_NULL_AUTH =0,
   IFX_HMAC_SHA1,
}e_IFX_AuthTransf;


/* The Pseduo random function to be used for Key derivation */
typedef e_IFX_EncrTransf e_IFX_KeyDervFunc;

/* Forward Error Correction Parameters section 10 of RFC*/
typedef enum
{
   IFX_NONE,
   IFX_FIRST_FEC,
   IFX_FIRST_SRTP,
}e_IFX_FecOrder;

/* RTP MIB info types*/
typedef enum
{
  IFX_RTP_SESSION_TABLE,
  IFX_RTP_TX_TABLE,
  IFX_RTP_RX_TABLE,
  IFX_RTP_SESSION_TABLE_ERR,
  IFX_RTP_TX_TABLE_ERR,
  IFX_RTP_RX_TABLE_ERR
          
}e_IFX_RTP_MIB_InfoType;

typedef enum
{
   IFX_RTP_DOMAIN_UDP,
   IFX_RTP_DOMAIN_TCP
}e_IFX_RTP_DOMAIN;

/* Vertical Service code configurations*/
typedef enum
{
  IFX_AUTO_REDIAL_ACTIVE = 0,
  IFX_AUTO_REDIAL_DEACTIVE,
  IFX_ANON_CALLBK_ACTIVE,
  IFX_ANON_CALLBK_DEACTIVE,
  IFX_BLIND_CALL_TRANSFER,
  IFX_DIAL_VMS,
  IFX_CALL_RETURN,
  IFX_3WAY_CONF,
  IFX_TOGGLE_1CALL,
  IFX_TOGGLE_2CALL,
  IFX_DIS_LAST_ACTIVE_CALL,
  IFX_MAX_VERT_SERVICE
}e_IFX_VerticalServices;

/* Country Tone Type */
typedef enum
{
 IFX_TONE_TYPE_USA = 0,
 IFX_TONE_TYPE_JAPAN,
 IFX_TONE_TYPE_CHINA,
 IFX_TONE_TYPE_TAIWAN,
 IFX_TONE_TYPE_USA600,
 IFX_TONE_TYPE_USACMP,
 IFX_TONE_TYPE_GERMANY
} e_IFX_CountryToneType;

/* Dial plan Actions */
typedef enum
{
  IFX_LOCAL_SERVICE_CFG = 0,
  IFX_LOCAL_SERVICE_PARAM,
  IFX_SERVER_SERVICE_CFG,
  IFX_3WAY_CONF_TOG_CFG,
  IFX_SPEED_DIAL,
  IFX_LOCAL_PSTN_CALLS,
  IFX_STD_PSTN_CALLS,
  IFX_STD_VOIP_CALLS,
  IFX_ISD_PSTN_CALLS,
  IFX_ISD_VOIP_CALLS,
  IFX_EMERGENCY_CALLS,
  IFX_EXTN_DIAL_CFG,
  IFX_DIRECT_DIAL_NOPROXY,
  IFX_INTERDOMAIN_PSTN_CALLS,
  IFX_INTERDOMAIN_VOIP_CALLS,
  IFX_EXTN_CHAN_NUM_DIAL,
  IFX_MAX_DIALPLAN_ACTIONS
}e_IFX_DialPlanCfg;

#ifndef IIP
/* Voice Line Types */
typedef enum
{
   IFX_FXS =1,
   IFX_FXO,
} e_IFX_LineTypes;

/*Firmware Version */
typedef enum
{
   IFX_FW_16_X_Y,
   IFX_FW_20_X_Y,
   IFX_FW_24_X_Y
} e_IFX_FWTypes;

/* Call Type */
typedef enum
{
  IFX_PSTN_NUM,
  IFX_VOIP_NUM,
  IFX_EXTN_NUM,
  IFX_DIRECT_IPNUM,
} e_IFX_CallTypes;
#endif

/* Structures */

/* Voip System structures*/
/* Gateway mode setting */
typedef struct
{
   /* Wata can be configured in 2 modes
    * PSTN Forwarding mode
    * Gateway Mode*/
   uchar8 ucGatewayMode;

   /* PSTN G/w Enable/Disable*/
   uchar8 ucPstnGwFlag;

   /* Voip G/e Enable/Disable*/
   uchar8 ucVoipGwFlag;
} x_IFX_GatewayCfg;

   
/*Tone Settings */
typedef struct
{
   /* Country Code */
   uchar8 ucCountryCode;
   
} x_IFX_CountryToneCfg;

/* Firmware Download */
typedef struct
{
  /* FirmWare Download Choice*/
  uchar8 ucFirmwareChoice;

  /* Option 1 with the codecs supported*/
  uint32 uiOption1Codecs;

  /* Option 2 with the codec supported*/
  uint32 uiOption2Codecs;

  /* Option 3 with the codecs supported*/
  uint32 uiOption3Codecs;
  
}x_IFX_FirmwareCfg;


/* Version Data Base of S/W*/
typedef struct
{
   /* FirmWare Version */
   char8 acFirmWareVer[IFX_MAX_VERSION_STRING];

#ifdef IIP
   /* Hapi Version */
   char8 acHapiVer[IFX_MAX_VERSION_STRING];

   /* JB Version */
   char8 acJBVer[IFX_MAX_VERSION_STRING];

   /* Chip Version */
   char8 acChipVer[IFX_MAX_VERSION_STRING];
#endif /*IIP*/
   /* Driver Version */
   char8 acDrvVer[IFX_MAX_VERSION_STRING];

   /* Voip Application Version */
   char8 acAppVer[IFX_MAX_VERSION_STRING];
    
   /* RTP Version */
   char8 acRtpVer[IFX_MAX_VERSION_STRING];
    
   /* CM Version */
   char8 acCmVer[IFX_MAX_VERSION_STRING];

   /* RM Version */
   char8 acRMVer[IFX_MAX_VERSION_STRING];

   /* SIP Version */
   char8 acSipVer[IFX_MAX_VERSION_STRING];
#ifndef IIP   
   /* Fax  Version */
   char8 acFaxVer[IFX_MAX_VERSION_STRING];
#endif /* ATA */    
    
} x_IFX_VersionCfg;


/* Debug Status */
typedef struct
{
   /* Debug Level */
   uchar8 ucDbgLvl;
    
   /* Debug Type */
   uchar8 ucDbgType;
    
} x_IFX_DbgType;

typedef struct
{
   /* Voip Application Debug */
   x_IFX_DbgType xPaDbg;

   /* Rtp Debug */
   x_IFX_DbgType xRtpDbg;

   /* Cm Debug */
   x_IFX_DbgType xCmDbg;

   /* RM Debug */
   x_IFX_DbgType xRmDbg;

   /* Sip Debug */
   x_IFX_DbgType xSipDbg;
    
#ifndef IIP
   /* Fax Dbg */
    x_IFX_DbgType xFaxDbg;
#endif /*ATA*/    
    
} x_IFX_DbgCfg;

/* RTP port range */ 
typedef struct 
{ 
   /* The Lower limit of RTP port range */ 
   uint16 unStartRTPPort; 

   /* The upper limit of RTP port range */ 
   uint16 unEndRTPPort;

   /* Dscp Mark */
   uchar8 ucDSCPMark;
   
#ifdef IIP 
   /* Strict SRTP ON/OFF flag */
   uchar8 ucStrictSrtp;
   
   /* Srtp Key exchange method*/
   uchar8 ucKeyXMethod;
#endif

} x_IFX_SipRTPPortRangeCfg; 


/* SIP Parameters Information 
 * Sip Protocl Setting +
 * Sip UserAgent Setting*/ 
typedef struct 
{ 
    /* Sip Protocol Setting */
   /* Sip Connection Time Out in ms*/
   /* Intial Sip Time Out */
   uint16 unT1;

   /* Max Sip Time Out in ms*/
   uint16 unTmax;

   /* Registration Retry Time in sec*/
   uint16 unRegRetryTime;

   /* Dns Query Time out in sec*/
   uint16 unDnsQueryTimeOut;

   /* Nat Keep Alive Timer in sec*/
   uint16 unNatKeepAliveTime;

   /*DSCP Mark*/
   uchar8 ucDSCPMark;
   
   /* Sip User agent Setting */
   /* User Agent Server Sip Port*/
   uint16 unSipServerPort;
 
   /* Transport type to be used for the endpoint */ 
   uchar8 ucTransportType;

   /* Usage of compact headers */ 
   uchar8 ucUseCompactHdrs;

   /* Stun A=RTCP*/
   uchar8 ucARtcp;
  
   /* Call On Hold Address*/
   uchar8 ucCallOnHold;

   /* User Agent Header Config */
   char8 acUserAgentHdr[IFX_MAX_USR_AGENT];

   /* Accept Unsolicited Voice mail notifications */
   uchar8 ucAcceptUnSolNotify;

} x_IFX_SipParamCfg; 

/* Stun Server Configuration*/
typedef struct
{
   /* Stun Server Switch ON/OFF  */
   uchar8 ucFlag;
  
   /* Stun Server Transport Address */
   char8 acStunServer[IFX_MAX_TSP_ADDR];

   /* Stun Port Configuration*/
   uint16 unPort;

   /* Stun Username for exchange of cetificates*/
   char8 acUserName[IFX_MAX_USR_NAME];

   /* Stun Password for exchange of Certificates*/
   char8 acPassword[IFX_MAX_USR_PASSWD];
    
   /* NAT Type */
   int32 iNatType;
      
} x_IFX_StunCfg;


/* Ethernet Led */
typedef struct
{
   uchar8  ucEthPcLed; /*LED ON/OFF Value*/
   uchar8  ucEthLanLed; /*LED ON/OFF Value*/
  
}x_IFX_EthLedCfg;


/* Dial Plan */
typedef struct
{
  /*Inter-Digit  Timeout in sec*/
  int32 iInterDigitTimeout;

  /* Dial plan */
  char8 acDialPlan[IFX_MAX_DIALPLAN_ACTIONS][IFX_MAX_DIALPLAN_SIZE];
          
}x_IFX_DialPlanCfg;


/* Outgoing Call Block */
typedef struct
{
   /* Out going Call blocks*/
   uchar8 ucOutCallBlock;

}x_IFX_OutCallBlockCfg;   


/* Voip  Profile Configuration*/
/* Proxy Info */

/* Profile Type */
typedef struct
{  
   /* ON or OFF */
   uchar8 ucProfileStatus;
  
   /* Profile Identifier*/ 
   uint32 uiProfileId;

} x_IFX_ProfileCfg;

typedef struct 
{ 
   /* Enable or Disable Proxy settings*/
   uchar8 ucFlag;
   
   /* IP address of the Proxy */ 
   char8 acProxyAddr[IFX_MAX_TSP_ADDR]; 

   /* Port on which the proxy can be contacted */ 
   uint16 unProxyPort; 

   /* The protocol to be used for contacting the proxy */ 
   uchar8 ucProtocol; 
  
   /* Outbound Proxy Address*/
    char8 acOutboundProxy[IFX_MAX_TSP_ADDR];

} x_IFX_SipProxyCfg; 

 

/* Registrar Info */ 
typedef struct 
{ 

   /* Enable or Disable Registrar settings*/
   uchar8 ucFlag;

   /* IP address of the Regisrar */ 
   char8 acRegistrar[IFX_MAX_TSP_ADDR];

   /* The port to be used for Registration */ 
   uint16 unRegPort; 

   /* The protocol to be used for reg */ 
   uchar8 ucRegProtocol;

   /* Time of registration with the registrar */ 
   uint32 uiRegExpirationTime;

   /* Accept Message only from a well known Source*/
   uchar8 ucWellKnownSource;

} x_IFX_SipRegistrarCfg;

/* Country and Area code Info */
typedef struct
{
   /* Country Code */
   char8 acCountryCode[IFX_TEL_CODE_SIZE];

   /* Acess Prefix for International Calls */
   char8 acIntAccPref[IFX_TEL_CODE_SIZE];

   /* Local Area Code */
   char8 acLocAreaCode[IFX_TEL_CODE_SIZE];

   /* Acess Prefix for Local Calls */
   char8 acLongDistCallPref[IFX_TEL_CODE_SIZE];

} x_IFX_SipTelUriCfg;

/* Information for voice mail server */ 
typedef struct 
{ 
   /* Enable or Disable VoiceMail server settings*/
   uchar8 ucFlag;
   
   /* IP address of the VoiceMail server(VMS) */ 
   char8 acVMSAddr[IFX_MAX_TSP_ADDR]; 

   /* Port on which the VMS can be contacted */ 
   uint16 unVMSPort; 

   /* The protocol to be used for contacting the VMS */ 
   uchar8 ucProtocol; 

   /* Subscription Expiration time */
   uint32 uiMWIExpTime;

  
}x_IFX_VoiceMailCfg; 

/* Jitter Buffer Info */ 
typedef struct 
{   
   /* To indicate if the jitter buffer is fixed or adaptive */ 
   uchar8   ucType;

   /* This shall be any value between 0 and 16 */ 
   /* Only to be defined for Adaptive JB - To be checked */ 
   uchar8   ucScalingFactor;

   /* Initial size of JB  */ 
   uint16  unInitialSize;

   /* Max Size of JB */ 
   uint16  unMaxSize;

   /* Min Size of JB */ 
   uint16  unMinSize;

} x_IFX_JbConfig; 

#ifndef __IFX_COMMON_DEFS_H__

/* Structure used by Configuration Module to provide Config Info  */
/* RM Receive Message */
typedef struct
{
   /*Codec */
   uint32 uiCodec;
    
   /*Frame Size*/
   uchar8 ucFrameSize;
    
   /*Dynamic Payload Type*/
   uchar8 ucDynPT;

} x_IFX_Codec;

typedef struct
{
   uint16 unNoOfCodecs;
   
   x_IFX_Codec axCodec[IFX_MAX_CODECS];
   
} x_IFX_CodecList;

#endif
typedef struct  
{ 
   /* Value in Kbps */  
   uint16 unMediaBw;  
   
   /* Silence supression */ 
   uchar8 ucSilenceSupp;
   
   /* Type of DTMF supported */
   uchar8 ucDtmfType;

   /* DTMF Payload Value */
   uchar8 ucDtmfPayloadValue;
   
   /* G723 Prefered codec */
   uint32 uiG723PrefCodec;
   
   /* codec configuration*/
   x_IFX_CodecList xCodecList;

   /* announcement.  T38 TCP should be announced by SIP only if TCP is configured.
   * When dynamic is chosen, SIP may choose to announce UDP first and TCP next.
   * T.38 connection will be set up with the one chosen by the peer.
   */
   uchar8 ucT38Conn;
         
   /* Firmware Supported Codec */
   uint32 uiFwSupCodec;

} x_IFX_RmMediaCfg;


/* Structure used by CM to Configure Fax info in the RM */
typedef struct
{
   /* Protocol Type */
   uint32 auiTransportProtocol[IFX_MAX_FAX_PROTO];

   /* T38 Protocol Version */
   uchar8 aucVersion[IFX_MAX_FAX_PROTO];
   
   /* Rate managemnet*/
   uchar8 aucRateManagement[IFX_MAX_FAX_PROTO];

   /* Kilobits/s */
   uint16 aunMaxBitRate[IFX_MAX_FAX_PROTO];

   uint32 auiBitOptions[IFX_MAX_FAX_PROTO];

   /* UDP options */
   uint16 aunUDPMaxBufferSize[IFX_MAX_FAX_PROTO];
   uint16 aunUDPMaxDatagramSize[IFX_MAX_FAX_PROTO];

   /* UDP Error Correction */
   uchar8 aucUDPErrCorrection[IFX_MAX_FAX_PROTO];

} x_IFX_RM_FaxCfg;


/* Structure to Send Fax Port Info */
typedef struct
{
   /* Port Number Range for TCP/UDP Connection */
   /* Start Port */ 
   uint16 unPortStart;

   /*End Port */
   uint16 unPortEnd;
   
} x_IFX_SipFaxPortCfg;

/* Structure used by CM to Configure T38 Stack */
typedef struct
{
   uchar8 ucOldAsn1;  /* 0 - Off, 1 - On */

   /* Size of NSX Patch */
   uchar8 ucNsxSize;
 
   /* NSX Info */
   uchar8 ucNsxInfoField[IFX_FA_NSX_MAX_SIZE];

   /* Data Wait time in 10 ms */
   uchar8 ucDataWaitTime;

   /* Udp High Rate Error Recovery Packets */
   uint16 unUdpHRErrRecPkts;

   /* Udp Low Rate Error Recovery Packets */
   uint16 unUdpLRErrRecPkts;

   /* Udp Prior Packets for FEC */
   uint16 unUdpPriorFecPkts;

   /* Framelength */
   uint16 unFrameLength;

   /* Preferred T38 Connection */
   uchar8 ucT38Conn;
   
} x_IFX_FA_T38Cfg;


/* Voip Line Configuration strutures*/

/* Line Type */
typedef struct
{ 
   /* Line Id*/
   int32 iLineId;

   /* ON or OFF */
   uchar8 ucLineStatus;

   /* Line Type */
   uchar8 ucLineType;

   /* Line Password */
   char8 acLinePasswd[IFX_MAX_USR_PASSWD];

   /* Profile TID */
   uint32 uiProfileId;

} x_IFX_LineCfg;

typedef struct
{
    /* Remote domain */ 
   char8 acRealm[IFX_MAX_DOMAIN_NAME];
   
  /* User name to be used for Authentication */ 
   char8 acAuthUserName[IFX_MAX_USR_NAME];

   /* password to be used for this endpoint */ 
   char8 acPasswd[IFX_MAX_USR_PASSWD]; 
   
}x_IFX_AuthCfg;   

/* User related information */ 
typedef struct 
{ 

   /* User name to be used for this endpoint */ 
   char8 acUserName[IFX_MAX_USR_NAME];
 
   /* Display Name to be used */ 
   char8 acDisplayName[IFX_MAX_DISP_NAME];

   /* local domain */ 
   char8 acDomain[IFX_MAX_DOMAIN_NAME];
   
   /* Auth Info */
   x_IFX_AuthCfg xAuthInfo[IFX_MAX_AUTHINFO];
   
   /*Registor Status ACTIVE/INACTIVE/NOTCFG*/
   uchar8 ucRegStatus;

   /* Message waiting Indication(MWI) Subscription Status */
   uchar8 ucMWIStatus;


} x_IFX_SipUserCfg; 

#ifndef __IFX_COMMON_DEFS_H__
/* Address Info */ 
typedef struct 
{ 
   /* Type of address being given */
   uchar8  ucAddrType;

   /* Display Name of the destination */ 
   char8 acDisplayName[IFX_MAX_DISP_NAME];

   /* User Name of the destination/Phone Number */ 
   char8 acUserName[IFX_MAX_USR_NAME];

   /* IP address/FQDN */
   char8 acCalledAddr[IFX_MAX_TSP_ADDR]; 

   /* Port Number on which th destination can be reached */ 
   uint16 unPort; 
    
   /* Adddress Book Protocol can hold any value of e_IFX_SipTransportType*/
   /* signifies which protocol to be used by sip for connection establishment*/
   uchar8  ucAddrProto;

} x_IFX_CalledAddr; 
#endif

/*Structure to store the  Address */
typedef struct
{
  
#ifndef IIP
    /* DTMF index code to be dialed to select this address entry*/
    char8  acDialCode[IFX_MAX_DIAL_CODE_SIZE];

    /*Call Type*/
    e_IFX_CallTypes eCallType;

#else
    /* The index to the vector table containg training info */
    uchar8 ucVectorIndex;
#endif
  
  /* Address of relevent type */
  x_IFX_CalledAddr xAddress;
  
} x_IFX_AddressBookEntry;

/* Structure for modifying Address Book Entry */
/* To be used during
 *   Modify Request from Web
 *   Modify Request from APP (incase of IP Phone)
 *  Add an entry only the xoldAddrEntry shall be used
 *  Update an entry only the xoldAddrEntry shall be used
 */

typedef struct
{
   /* for update and delete info type we shall use only the old entry*/
   x_IFX_AddressBookEntry xOldAddrEntry;
   x_IFX_AddressBookEntry xNewAddrEntry;

} x_IFX_ModAddrBookCfg;


#ifdef IIP
/* Voice Activated Dialing*/
typedef struct
{
   /* Total number of VAD entries*/
   uchar8 ucTotVecEntries;   
  
   /* The next Free Index */
   uint16 unFreeIndex;

   /* The Speach Vector */
   uint16 unSpeechVector[IFX_MAX_TRAIN_VECT][IFX_MAX_TRAIN_VECT_SIZE];
}x_IFX_VadCfg;


/*SIP message Structure*/
typedef struct
{
   /* Message ID */
   uchar8 aucMsgId[IFX_MAX_MESSAGES];

   /* Read Flag */  
   uchar8 aucReadFlag[IFX_MAX_MESSAGES];  /*Set When Message has been read*/

   /* Message in number of pages */
   uchar8 aucTotalPage[IFX_MAX_MESSAGES];/*Total page of message*/
   
   /* From address of the message */
   x_IFX_CalledAddr axAddress[IFX_MAX_MESSAGES];/* New Added  FROM SIP*/

   /* Message */
   char8 acMsgData[IFX_MAX_MESSAGES][IFX_MSG_SIZE];/*Message Data*/
        
}x_IFX_MsgCfg;

#endif



/* Structure to store the  Call Register Info */
typedef struct
{ 
   /* Time Sent */
   char8 acTime[IFX_TIME_STR_SIZE];

   /* Date Sent */
   char8 acDate[IFX_TIME_STR_SIZE];
	
#ifndef IIP
	/*Call Type*/
	e_IFX_CallTypes eCallType;
#endif	
   
	/*Called Address*/
   x_IFX_CalledAddr xAddress;

} x_IFX_CallRegEntry;

typedef struct
{
    /* WriteIdx, the position of the next write */
    char8 cWriteIdx;
    
    /* Read Index */
    char8 cReadIdx;

    /* Call Register Entry */
    x_IFX_CallRegEntry xCallRegEntry[IFX_MAX_CR_ENTRIES];

} x_IFX_CallRegCfg;

typedef struct
{
  /* number of Phone book entries*/  
  uint16 unNoOfEntries;

  /* Addres book entries*/
  x_IFX_AddressBookEntry axAddrBookCfg[IFX_MAX_PB_ENTRIES];
        
}x_IFX_AddressBook;

/* Extension Dialing*/
typedef struct
{
   uchar8 ucExtnDialFlag; /* On/Off Value */

   /* Extension prefix digit*/
   uint16 unPrefixDigit;

} x_IFX_ExtnDial;


/* Fast Dialing */
typedef struct
{
   uchar8 ucFastDialFlag; /* On/Off Value */
   
   /* Fast Dial Display Name*/   
   char8 acFastDialName[IFX_MAX_DISP_NAME];
   
   /* Fast Dial Index */
   uint16 unIndex; 
} x_IFX_FastDial;

/*Call block List */
typedef struct
{
  /* Telephone number */
  char8 acCallBlockNum[IFX_MAX_CALLBLOCK_LIST][IFX_MAX_USR_NAME];
  
} x_IFX_CallBkList;



/* Call Forward Options */
typedef struct
{
   /* Call Forward Type */
   uchar8 ucType;

   /* Unconditional */
   x_IFX_CalledAddr xFwdAddrUncon;

   /* No Answer */
   x_IFX_CalledAddr xFwdAddrNoAns;

   /* Busy */
   x_IFX_CalledAddr xFwdAddrBusy;

   /* DnD */
   x_IFX_CalledAddr xFwdAddrDnd;

} x_IFX_FwdCfg;


/* Call Features*/
typedef struct
{
  
#ifdef IIP
   /* Extension Dial*/
   x_IFX_ExtnDial xExtnDial;
   
   /* Fast Dial */
   x_IFX_FastDial axFastDial[IFX_MAX_FAST_DIAL];
#endif /* IIP*/
    
   /* Caller ID flag ON/OFF*/
   uchar8 ucCallIdFlag;
   
   /* DND Flag */
   uchar8 ucDndFlag;  /* On/Off Value */

   /* Call waiting Flag ON/OFF*/
   uchar8 ucCallWaiting;
   
   /* Anonymous Call Block */
   uchar8 ucAnonCallBlock;

   /*Call Return*/
   char8 cCallReturn;
  
   /* Call block list */
   x_IFX_CallBkList xCallBkList;

   /* Number of Rings for no Ans*/
   uchar8 ucRingCount;

   /* Call Forwading */
   x_IFX_FwdCfg xFwd;

#ifndef IIP
   /* Echo Suppression */ 
   uchar8 ucEchoSupp;
#endif

   /* Enable subscription for voice mail indications */
   uchar8 ucSubsMWI;

   /* User name for retrieving Voice mail server */
   char8 acVMRetUsrName[IFX_MAX_USR_NAME];
  
   /* User name for depositing to voice mail server */
   char8 acVMDepUsrName[IFX_MAX_USR_NAME];

   /* Voice mail forward option */
   uint32 uiVoiceMailFwd;
  
} x_IFX_CallCfg;

/* Vertical Service Code*/
typedef struct
{
   /* Dial Code */
   char8 acCode[IFX_MAX_VERT_SERVICE][IFX_MAX_DIALCODE_SIZE];
           
}x_IFX_VerticalServCfg;

/* Acoustic Related Config param*/
typedef struct
{
   /*Room Type*/
   uchar8 ucRoomType; 
  
   /*Voice Level */
   uchar8 ucVoiceVol;

   /*Ring Volume*/
   uchar8 ucRingVol;

   /* Ring Mute ON/OFF */
   uchar8 ucRingMute;

}x_IFX_AcousticCfg;


/* Key managment Protocol for SRTP */

/* For each Master key all the below params should exist*/
typedef struct
{
   /* Master Key related parmeters */

   /* Master Key Length*/
   uint16 unMasterKeyLen;
   
   /* Master Key*/
   char8 acMasterKey[IFX_MASTER_KEY_LENGTH];
   
   /* Master Salt Key length*/
   uint16 unMasterSaltLen;
  
   /* Master Salt */
   char8 acMasterSalt[IFX_MASTER_KEY_LENGTH];

   /* n_e Session encryption Key Length */
   uint16 unSesEncrKeyLen;

   /* n_a Session Authentication Key Length*/
   uint16 unSesAuthKeyLen;

   /* n_s Session Salt Key Length*/
   uint16 unSesSaltKeyLen;

   /* Key Derivation Rate: {1,2,4,...2^24}  since its is fixed 
    * for the lifetime of the Master key section 4.3.1*/
   uint32 uiKeyDerivationRate:24; /* only 24 bit are supposed to be used */

   /*<From , To> Pair used for rekeying and identifing Master Key */
   uint64 ulFromIndex:48; /* only 48 bits are to be used */
   uint64:16;
   uint64 ulToIndex:48;   /* Only 48 bits are to be used */
   uint64:16;

   /* SRTP Master key counter to count the number of 
    * SRTP packets sent out with the same master key */
   uint64 ulSrtpMaxLifeTime;

   /* SRTCP Master key counter to count the number of 
    * SRTP packets sent out with the same master key */
   uint32 uiSrtcpMaxLifeTime;

   /*Master Key Identifier related parameters*/

   /* MKI ON or OFF */
   uchar8 ucMkiIndicator; /* ON =1 and OFF=0 */

   /* Length of the MKI*/
   uint16 unMkiLength; /* Value in Octent*/

   /* MKI Value identifying each Master key */
   uint32 uiMkiValue;

}x_IFX_MasterKeyParam;



typedef struct
{
   /* crypto content index Parameters */
  
   /* SSRC value, it it is assume we have just one RTP stream,
     if there exists more than one RTP stream this should be
     a vector of [IFX_MAX_STREAMS]
   */
   uint32 uiSsrcValue;
  
   /* Roll over counter, it is assume we have just one RTP stream,
     if there exists more than one RTP stream this 
     should be a vector of [IFX_MAX_STREAMS]
   */
   /* sender Roc */
   uint32 uiRoc;

   /* Sequence number */
   uint16 unSeqNumber;

   /* SRTCP Index */
   uint32 uiSrtcpIndex;
  
   /* Transport Address */
   char8 acIpaddress[IFX_MAX_IP_ADDRESS_LEN];
 
   /* Port Number */
   uint16 unPort;
 
}x_IFX_IndexParams;


/* Cryptographic Context Parameters*/
typedef struct
{
   /* Encryption Algorithm to be used, can hold any one 
   * of the values of e_ifx_rtp_encr_transf*/
   uchar8 ucEncrAlgo;
 
   /* Authentication Algorithm to be used, can hold any one
    *  of the values of e_ifx_rtp_auth_transf*/
   uchar8 ucAuthAlgo;

   /* Authentication Tag Length*/
   uint16 unAuthTagLen;

   /* SRTP PREFIX_LENGTH*/
   uint16 unSrtpPrefixLen;

   /*SRTP Pseudo Random Function, can hold any one 
    * of the values of e_IFX_RTP_KeyDervFunc */
   uchar8 ucPseudoRandomFunc;

   /*Masterkey or TGK  Related parameters or the 
    * information obtained in the MIKEY payload KEMAC */
   x_IFX_MasterKeyParam xMasterCryptoParam[IFX_MAX_MASTER_KEYS];
 
   /* Parameters that are partialy obtained by the Key 
    * mangement MIKEY payload SRTP ID*/
   /* Parametrs that are obtained are SSRCi, ROCi  were i is the session ID */
   x_IFX_IndexParams  xCryptoIndexParam;

   /* Relation to other RTP Profiles*/
   /*Forward Error Correction  Order can Take any one of the
    *  values of e_IFX_RTP_FecOrder*/
   /* if FIRST_FEC then FEC processing has to be performed  prior
    *  SRTP on sender side
    * and SRTP processing before FEC at the reciveing side
    */
   uchar8 ucFecOder;
  
}x_IFX_SrtpKeyCfg;


/* Structure for Configuring User Info */
/* To be used during
 * New User Id creation (in this case ucNewPasswd is not used)
 * Delete User (in this case, the passwd fields are not used)
 * Password has to be NUMERIC, should be validated at the Web
 */
typedef struct
{
   /* Password */
   char8 acPasswd[IFX_MAX_USR_PASSWD];

} x_IFX_UserCfg;

/*To be used during
 * Modify User password and
 * Modify Admin password
*/
typedef struct
{
   /* Old Password */
   char8 acOldPasswd[IFX_MAX_USR_PASSWD];

   /* New Password */
   char8 acNewPasswd[IFX_MAX_USR_PASSWD];

} x_IFX_ModUserCfg;


/* PPPOE configuration structure*/
typedef struct
{
   char8 acUserName[IFX_MAX_USR_NAME];
   char8 acPasswd[IFX_MAX_USR_PASSWD];
   char8 acServProv[IFX_MAX_USR_NAME];
   uchar8 ucAuthType;
}x_IFX_PPPOE_CFG;


/* IP Address struct */
typedef  struct
{
   /* Host Name */
   char8 acHostName[IFX_MAX_TSP_ADDR];

   /* WAN Interface Type STATIC/DYNAMIC/PPPOE*/
   uchar8 ucWanIfType; 
    
   /* Static IP address */
   char8 acIPAddress[IFX_MAX_TSP_ADDR];
    
   /* Gateway Address */
   char8 acGatewayAddress[IFX_MAX_TSP_ADDR];
 
   /* Sub Net Mask */
   char8 acSubnetMask[IFX_MAX_TSP_ADDR];

   /*PPPOE Cfg Type*/
   x_IFX_PPPOE_CFG xPppoeCfg;

} x_IFX_NetAddrCfg;


/* Modify called Address */
typedef struct
{
   /* Old address */
   x_IFX_CalledAddr xOldAddr;
   
   /* New Address */
   x_IFX_CalledAddr xNewAddr;

}x_IFX_ModifyAddr;


/* Rtp MIB data */
typedef struct
{
   /* Session Remote IP address*/
   uint32 uiRemIpAddr;

   /* Session Remote Port*/
   uint16 unRemPort;

   /* Session local Ip address*/
   uint32 uiLocIpAddr;
 
   /* Session Local Port*/
   uint16 unLocPort;


   /* Number of Senders to have 
     been joined the session*/
   uint32 uiSenderJoins;

   /* Number of Receiver to have 
     been joined the session*/
   uint32 uiReceiverJoins;

   uint32 uiNoByes;

   /* Session start time*/
   uint32 uiStartTime;

}x_IFX_RTP_SessionRow;


typedef struct
{
   /* Sender SSRC */
   uint32 uiSenderSSRC;

   /* Sender Canonical Name*/
   char8 acSenderCNAME[IFX_RTP_MIB_TEXT_LEN];

   /* Sender Ip address */
   uint32 uiSenderIpAddr;

   /* Sender Port */
   uint16 unSenderPort;

   /* count of sent Packets*/
   uint64 ulSenderPackets;

   /* count of non header octents sent*/
   uint64 ulSenderOctets;

   /*Program source of the stream*/ 
   char8 acSenderTool[IFX_RTP_MIB_TEXT_LEN];
  
   /* Count of RTCP Sender records*/
   uint32 uiSenderSRs;
    
   /* Last RTCP Sender Report sent Time*/
   uint32 uiSenderSRTime;
    
   /* Payload type*/
   int32 iSenderPT;

   /* Sender Start time*/
   uint32 uiSenderStartTime;
}x_IFX_RTP_TxRow;


typedef struct
{
   /* Receiver combined SSRC*/
   uint32 uiRcvrSRCSSRC;
  
   /* Receiver SSRC*/
   uint32 uiRcvrSSRC;
  
   /* Receiver Canonical Name*/
   char8 acRcvrCNAME[IFX_RTP_MIB_TEXT_LEN];

   /* Receiver Ip addres*/
   uint32 uiRcvrIpAddr;

   /* Receiver Port*/
   uint16 unRcvrPort;

   /* Receiver Round trip time*/
   uint32 uiRcvrRTT;

   /* Receiver Lost Packets*/
   uint64 ulRcvrLostPackets;

   /* Receiver jitter */
   uint32 uiRcvrJitter;

   /* Reciver Application source stream*/
   char8 acRcvrTool[IFX_RTP_MIB_TEXT_LEN];
 
   /* Reciver Report count*/
   uint32 uiRcvrRRs;
   
   /* Last reiver Report Time*/
   uint32 uiRcvrRRTime;

   /* Reciver Payload Type*/
   int32 iRcvrPT;

   /* count of Receiver packets recived*/
   uint64 ulRcvrPackets;

   /* count non header octents recived*/
   uint64 ulRcvrOctets;

   /* first Recived packet time*/
   uint32 uiRcvrStartTime;
}x_IFX_RTP_RxRow;


typedef union
{
   /* Session table*/
   x_IFX_RTP_SessionRow axSessionTable[IFX_MAX_ENDPTS];
    
   /* Sender table*/
   x_IFX_RTP_TxRow axTxTable[IFX_MAX_ENDPTS];
    
   /* Receiver Table*/
   x_IFX_RTP_RxRow axRxTable[IFX_MAX_ENDPTS];
    
}ux_IFX_RTP_MIB_Table;



/* RTP MIB Structure*/
typedef struct
{
   uint8 ucTableType;
    
   uint8 ucNoOfRows;
    
   ux_IFX_RTP_MIB_Table uxMIBTable;
}x_IFX_RTP_MIB_Table;

/* SUBSCRIBE/NOTIFY related defs */
/* Subscipition State*/
typedef enum
{
  IFX_SIP_SUBSC_IDLE=1,
  IFX_SIP_SUBSC_SUBSCRIBING,
  IFX_SIP_SUBSC_SUBSCRIBED,
  IFX_SIP_SUBSC_PENDING,
  IFX_SIP_SUBSC_ACTIVE,
  IFX_SIP_SUBSC_TIMEOUT,
  IFX_SIP_SUBSC_TERMINATED,
  IFX_SIP_SUBSC_UNAUTHENTICATED
}e_IFX_SIP_SUBSC_STATE;

#endif /* __IFX_VOIP_DEFS_H__ */
