/*****************************************************************************
**   FILE NAME        : ifx_rm.h
**   PROJECT          : 
**   MODULES          : Resource Manager module
**   SRC VERSION      : V0.1
**   DATE             : 
**   AUTHOR           :  
**   DESCRIPTION      : This file contains all the data declarations that are
**                     used by the Resource Management Module
**   FUNCTIONS        :
**   COMPILER         : gcc
**   REFERENCE        : Coding guide lines for VSS, DIS of RM
**   COPYRIGHT        : Copyright © 2004 Infineon Technologies AG
**                     St. Martin Strasse 53; 81669 München, Germany
**                     Any use of this Software is subject to the conclusion
**                     of a respective License Agreement.Without such a
**                     License Agreement no rights to the Software are granted.
**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
******************************************************************************/

#ifndef __IFX_RM_H__
#define __IFX_RM_H__

#define IFX_RM_FAIL -1
#define IFX_RM_SUCCESS 0

EXTERN    boolean  bChannelFlag;
EXTERN    boolean  bFreeChannelFlag;

EXTERN   char8     IFX_RM_Init(IN uint16 nGetCoder);
EXTERN   char8     IFX_RM_Shut(void);
EXTERN   char8     IFX_RM_MgtInit();
EXTERN   char8     IFX_RM_MgtShut(void);
EXTERN   int32     IFX_RM_LockCoderChannel(IN int32  iConnId1,IN  int32 iConnId2);
EXTERN   int32     IFX_RM_GetCoderChannel(IN int32 iConnId);
EXTERN   int32     IFX_RM_FreeCoderChannel(IN int32 iConnId);

#endif // __IFX_RM1_H__ 
        
