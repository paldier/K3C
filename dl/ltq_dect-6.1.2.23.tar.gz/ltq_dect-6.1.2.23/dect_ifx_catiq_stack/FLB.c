/* -- SIEMENS AG  PCT -- Process: LB          -  Mon Feb 26 14:22:27 2007 -- */
#include	"DEFINE.H"
#include <stdio.h>
# include "SYSDEF.H"
# include "FDEF.H"
# include "TYPEDEF.H"
extern void KNL_T0000(void);
# include "SYSEXT.H"

		/*
		*****************************************************************************
		*                                                                           *
		*     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
		*                   (c) 2005 IFX / INTNIX. All rights reserved.               *
		*                                                                           *
		*****************************************************************************
		*                                                                           *
		*     Workfile   :  FLB.PSL                                                 *
		*     Date       :  18 Nov, 2005                                       *
		*     Contents   :                                                          *
		*     Hardware   :  IFX 87xx                                               *
		*                                                                           *
		*****************************************************************************
		*/
		/* ========                                                             */
		/* Includes                                                             */
		/* ========                                                             */
		#include    "DEFINE.H"
		
		#include    "SYSDEF.H"
		#include    "TYPEDEF.H"
		#include    "CONF_DEF.H"
		#include    "ERROR.H"
		#include    "FGLOBAL.H"
		#include    "PCT_DEF.H"
		#include    "KNL_SYSTEM.H"
		#include    "MMU.H"
		#include    "P_TIM.H"

		#include "dect_drv_if.h"

		#ifdef DECT_DEBUG_USER_LB_PRIMITIVE
		typedef struct {
			BYTE key;
			char *string;
		} DebugStringTable_t;
		#endif

		#ifdef DECT_DEBUG_USER_LB_PRIMITIVE
		LOCAL DebugStringTable_t messageStringTable[] = {
			{LB_DL_BROADCAST_RQ_LCE, "LB_DL_BROADCAST_RQ_LCE"},
			{0xFF, "Unknown Message"}
		};
		#endif

		/* ==========================                                           */
		/* Global function definition                                           */
		/* ==========================                                           */
		EXPORT void
		LB_INIT( void )
		{
		}

		#ifdef DECT_DEBUG_USER_LB_PRIMITIVE
		LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
		{
			BYTE i;

			for (i = 0; tablePtr[i].key != 0xFF; i++) {
				if (tablePtr[i].key == key) {
					break;
				}
			}
			return tablePtr[i].string;
		}
		#endif

void DECODE_LB(void)
{

	#ifdef DECT_DEBUG_USER_LB_PRIMITIVE
	DECT_DEBUG_USER_LB_PRIMITIVE("%s, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable),
										  PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
	#endif

	switch (CurrentState) 
	{

		case LB_OPEN:
			switch (CurrentMessage) 
			{
				case LB_DL_BROADCAST_RQ_LCE:  /*  IN LINE CODE T1000    */
				{
					/* TRANSITION:      T1000                                                */
					/* EVENT:           LB_DL_BROADCAST_RQ_LCE                               */
					/* DESCRIPTION:     Broadcast request from Layer 3                       */
					/* REFERENCE:       ETS 300 175-4:1996                                   */
					/* STARTING STATE:  LB_OPEN                                              */
					/* END STATE:       LB_OPEN                                              */
					/* ----------------------------------------------------------------------*/
// TODO:  USING HLI
#ifdef FT_CLMS
               // For the CLMS paging, Parameter4 will be assigned for length of paging buffer.
          		write_to_hmac_ioctl(HMAC, MAC_PAGE_RQ_LB
                      ,PARAMETER1, 0, 0, ((struct HLI_Header *)G_PTR)->length - sizeof( struct HLI_Header )
                      ,1, 0, G_PTR, 0);		/* param 5 is G_PTR include HLI struct */
#else
          		write_to_hmac_ioctl(HMAC, MAC_PAGE_RQ_LB
                      ,PARAMETER1, 0, 0, 0
                      ,1, 0, G_PTR, 0);		/* param 5 is G_PTR include HLI struct */
#endif
				}
				return;

				default:
					 break;
 
			}										/* end of switch message				*/
 			break; 

	}												/* end of switch state					*/
	KNL_T0000();

}													/* end of DECODE_LB()					*/
