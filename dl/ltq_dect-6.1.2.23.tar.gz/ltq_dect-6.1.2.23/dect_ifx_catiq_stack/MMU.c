/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
*                   (c) 2005 IFX / INTNIX. All rights reserved.               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  MMU.C                                                   *
*     Date       :  18 Nov, 2005                                       *
*     Contents   :  Contents : Memory Management Unit                       *
*     Hardware   :  IFX 87xx                                               *
*                                                                           *
*****************************************************************************
*/
   /* ========                                                             */
   /* Includes                                                             */
   /* ========                                                             */
#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "CONF_CP.H"
#include "ERROR.H"
#ifdef FT
#include "FGLOBAL.H"
//#include "FLLME.H"
#endif
#include "MMU.H"

#ifdef LINUX
#include <malloc.h>
#endif
#ifdef SUPERTASK
#include "sys_mem.h"
#endif
#include <string.h>
   /* ==============                                                       */
   /* Local typedefs                                                       */
   /* ==============                                                       */
struct mem
{
   struct mem XDATA *next;
   WORD              len;
   BYTE              mem[1];
};

#define SM_PTR  struct mem XDATA *


   /* ===============                                                      */
   /* Local variables                                                      */
   /* ===============                                                      */

   /* ==========================                    */
   /* Global function definition                                           */
   /* ==========================                    */
/*
*****************************************************************************
*                                                                                   *
*   Function   :  Mmu_Init                                                 *
*                                                                                   *
*****************************************************************************
*                                                                                    *
*   Purpose    :  Inits the memory space.                           *
*                 The memory size is given by MEM_SIZE          *
*   Parms      :  none                                                        *
*   Returns    :  none                                                        *
*   Call Level :  Process Level                                           *
*   Remarks    :                                                               *
*                                                                                    *
*****************************************************************************
*/
EXPORT void
Mmu_Init( void )
{
  return;
}



/*
*****************************************************************************
*                                                                                                  *
*   Function   :  Mmu_Malloc                                                            *
*                                                                                                  *
*****************************************************************************
*                                                                                                  *
*   Purpose    :  Simulates the standard malloc() function call.            *
*   Parms      :  size            : length of the requested memory space  *
*   Returns    :  If successful a Pointer to the requested memory,       *
*                 otherwise NULL.                                                          *
*   Call Level :  Process Level                                                         *
*   Remarks    :                                                                             *
*                                                                                                  *
*****************************************************************************
*/
EXPORT FPTR
Mmu_Malloc( WORD word_size )
{
#ifdef LINUX
  return (FPTR)calloc(1,word_size);
#endif
#ifdef SUPERTASK
  FPTR return_ptr;

  return_ptr = SYS_MEM_MALLOC(word_size);
  memset(return_ptr,0,sizeof(word_size));
  return return_ptr;
#endif
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Mmu_Free                                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Simulates the standard free() function call.              *
*   Parms      :  return_ptr      : Pointer to the memory to be freed.      *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                      !! NOTE !!                            *
*                 The return of a NULL Pointer or the return of a already   *
*                 freed memory block shall not lead to problems !           *
*                                     !! NOTE !!                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Mmu_Free( FPTR return_ptr )
{
#if 0
	if(return_ptr == G_PTR_Array)
	{
		return_ptr = NULL;
		return;
	}
#endif
	if(return_ptr != NULL)
	{
#ifdef LINUX
		free(return_ptr);
#endif
#ifdef SUPERTASK
		SYS_MEM_FREE(return_ptr);
#endif
		return_ptr = NULL;

	}
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Mmu_Realloc                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Simulates the standard realloc() function call.           *
*   Parms      :  realloc_ptr      : Pointer to the memory to be            *
*                                    reallocated.                           *
*                 size             : new required memory space length       *
*   Return     :  If successful a Pointer to the reallocated memory,        *
*                 otherwise NULL.                                           *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Mmu_Realloc( FPTR realloc_ptr, WORD word_size )
{
#ifdef LINUX
  return realloc(realloc_ptr, word_size);
#endif
#ifdef SUPERTASK
  return SYS_MEM_REALLOC(realloc_ptr, word_size);
#endif
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Mmu_Memcpy                                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Simulates the standard memcpy() function call.            *
*   Parms      :  dest            : Pointer to the destination memory.      *
*                 source          : Pointer to the source memory.           *
*                 len             : size of the memory to be copied.        *
*   Return     :                                                            *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Mmu_Memcpy( FPTR dest_ptr, FPTR source_ptr, WORD len )
{
  memcpy(dest_ptr, source_ptr, len);
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Mmu_Memcmp_Bit                                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Compares the content of two given memory areas.           *
*                 The length to compare is given in bits !                  *
*   Parms      :  comp1           : Pointer to the first memory.            *
*                 comp2           : Pointer to the second memory.           *
*                 bit_start       : Position of start bit.                  *
*                 bit_stop        : Position of end bit.                    *
*   Return     :  TRUE if memory areas are equal, otherwise FALSE.          *
*   Call Level :  Process Level                                             *
*   Remarks    :  Memory areas are both placed in XDATA.                    *
*                                                                           *
*****************************************************************************
*/
EXPORT BIT
Mmu_Memcmp_Bit( FPTR comp1, FPTR comp2, BYTE bit_start, BYTE bit_stop )
{
   BYTE i;

                                       /* A value greater of seven for     */
                                       /* the start bit is senseless.      */
                                       /* A compare with greater values    */
                                       /* should be performed with an      */
                                       /* increment of comp1 and comp2 !   */
   if( bit_start > 7 )
      return( FALSE );

   if( bit_start >= bit_stop )
      return( FALSE );

   for( i = bit_start; i < bit_stop; )
   {
      if(( *comp1 & ( 0x80 >> ( i % 8 ))) != ( *comp2 & ( 0x80 >> ( i % 8 ))))
         return( FALSE );
      i++;
      if(( i % 8 ) == 0 )
      {
         comp1++;
         comp2++;
      }
   }
   return( TRUE );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Mmu_Memcmp                                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Compares the content of two given memory areas.           *
*   Parms      :  comp1           : Pointer to the first memory.            *
*                 comp2           : Pointer to the second memory.           *
*                 len             : length of the area to be compared       *
*   Return     :  TRUE if memory areas are equal, otherwise FALSE.          *
*   Call Level :  Process Level                                             *
*   Remarks    :  Memory areas are both placed in XDATA.                    *
*                                                                           *
*****************************************************************************
*/
EXPORT BIT
Mmu_Memcmp( FPTR comp1, FPTR comp2, BYTE len )
{
   while( len-- )
      if( comp1[ len ] != comp2[ len ] ) return( FALSE );

   return( TRUE );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Mmu_Memcmp                                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Compares the content of two given memory areas.           *
*   Parms      :  comp1           : Pointer to the first memory.            *
*                 comp2           : Pointer to the second memory.           *
*                 len             : length of the area to be compared       *
*   Return     :  TRUE if memory areas are equal, otherwise FALSE.          *
*   Call Level :  Process Level                                             *
*   Remarks    :  Memory areas are placed in XDATA and CODE.                *
*                                                                           *
*****************************************************************************
*/
EXPORT BIT
Mmu_Memcmp_Code( FPTR comp1, BYTE CODE_PTR * comp2, BYTE len )
{
   while( len-- )
      if( comp1[ len ] != comp2[ len ] ) return( FALSE );

   return( TRUE );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Mmu_Memset                                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Simulates the standard memset() function call.            *
*   Parms      :  mem_ptr         : Pointer to the memory buffer            *
*                 set_val         : set value                               *
*                 len             : size of the memory buffer               *
*   Return     :                                                            *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Mmu_Memset( FPTR mem_ptr, BYTE set_val, WORD len )
{
  memset(mem_ptr, set_val, len);
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Increment                                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Implements the modulo increment function.                 *
*   Parms      :  var        : Variable to be incremented                   *
*                 MAX_VALUE  : Maximum Value                                *
*   Returns    :  The incremented variable                                  *                                                       *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT BYTE
Increment ( BYTE var, BYTE MAX_VALUE )
{
   return( (++var) % MAX_VALUE );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Decrement                                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Implements the modulo decrement function.                 *
*   Parms      :  var        : Variable to be decremented                   *
*                 MAX_VALUE  : Maximum Value                                *
*   Returns    :  The decremented Variable                                  *                                                       *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT BYTE
Decrement ( BYTE var, BYTE MAX_VALUE )
{
   if ( var == 0 )
      return ( MAX_VALUE - 1 );
   else
      return ( --var );
}
