#include	"DEFINE.H"
#include <stdio.h>
# include "SYSDEF.H"
# include "FDEF.H"
# include "TYPEDEF.H"
extern void KNL_T0000(void);
# include "SYSEXT.H"

		/*
		*****************************************************************************
		*                                                                           *
		*                                                                           *
		*****************************************************************************
		*                                                                           *
		*     Workfile   :  FCC.PSL                                                 *
		*     Date       :  18 Nov, 2005                                         *
		*     Contents   :                                                          *
		*     Hardware   :  IFX 87xx                                               *
		*                                                                           *
		*****************************************************************************
		*/
		/* ========                                                             */
		/* Includes                                                             */
		/* ========                                                             */
		#include "DEFINE.H"
		#include "SYSDEF.H"
		#include "TYPEDEF.H"
		#include "CONF_DEF.H"
		#include "ERROR.H"
		#include "FGLOBAL.H"
		#include "PCT_DEF.H"
		#include "KNL_SYSTEM.H"
		#include "MMU.H"
		#include "P_TIM.H"
		#include "LCE_LIB.H"
		
		#include "CP_SERVER.H"
		#include "MESSAGE_DEF.H"


		/* ===============                                                      */
		/* Local variables                                                      */
		/* ===============                                                      */




		
		/* ==========================                                           */
		/* Global function definition                                           */
		/* ==========================                                           */
		EXPORT void
		CLMS_INIT( void )
		{
		}
		

void DECODE_CLMS(void)
{
   switch( CurrentState ) 
   {
      case  CLMS_OPEN:
            switch( CurrentMessage ) 
            {
               case  CLMS_MNCL_UNITDATA_RQ_SWI:
               {
                     /* TRANSITION:      T1000                                                */
                     /* EVENT:           CLMS_MNCL_UNITDATA_RQ_SWI                            */
                     /* DESCRIPTION:     Broadcast request from Layer 3                       */
                     /* REFERENCE:       ETS 300 175-5:1996                                   */
                     /* STARTING STATE:  CLMS_OPEN                                            */
                     /* END STATE:       CLMS_OPEN                                            */
                     /* ----------------------------------------------------------------------*/
                     // GPTR            = IE memory block(DATE_TIME and CLIP/CNIP)
                     // PARAMETER1 = Po_no(currentInc + 1) ==> Handset / Group ID
                     // PARAMETER2 = Signal
                     // PARAMETER3 = service_life(in sec, 0xff: no life time limit)
                     // PARAMETER4 = CLMS message type(0: Group-ring, 1:Collective-ring, 2: CLMS Fixed, 3: CLMS Variable )

#ifdef FT_CLMS
                     unsigned char  wide_flag;

                     wide_flag = (PARAMETER4 >> 4) & 0x0F;
                     if( (PARAMETER4 & 0x0F) == 0 ) // Group-ring
                     {
                        /* In case no data field(CLIP/CNIP or DATE_TIME) is available, then use the Group-ring */
                        Broadcast_CLMS_Message( PARAMETER1, // po_no
                                                U_PLAN_SERVICE_UNKNOWN_AND_RINGING,
                                                PARAMETER2, // signal
                                                PARAMETER3, // life time
                                                wide_flag,  // Indicator whether current call is WBS or NBS?
                                                G_PTR  );
                     }
                     else if( (PARAMETER4 & 0x0F) == 1 ) // Collective-ring
                     {
                        /* In case no data field(CLIP/CNIP or DATE_TIME) is available, then use the Corrective-ring */
                        Broadcast_CLMS_Message( PARAMETER1, // po_no
                                                U_PLAN_SERVICE_UNKNOWN_AND_RINGING_CBI,
                                                PARAMETER2, // signal
                                                PARAMETER3, // life time
                                                wide_flag,  // Indicator whether current call is WBS or NBS?
                                                G_PTR  );
                     }
#if 1
                     else if( (PARAMETER4 & 0x0F) == 2 ) //Fixed_CLMS
                     {
                        /* In case HLI data frame( example: CLIP/CNIP or DATE_TIME ) is available, then use the FIXED_CLMS */
                        if( (( struct HLI_Header * ) G_PTR ) -> length == 1 + sizeof( struct HLI_Header ) )
                        {
                           Broadcast_CLMS_Message( PARAMETER1, // po_no
                                                   CLMS_FIXED_STANDARD_SINGLE_SECTION,
                                                   PARAMETER2,
                                                   PARAMETER3, // life time
                                                   wide_flag,  // Indicator whether current call is WBS or NBS?
                                                   G_PTR  );
                        }
                        else
                        {
                           Broadcast_CLMS_Message( PARAMETER1, // po_no
                                                   CLMS_FIXED_STANDARD_MULTI_SECTION,
                                                   PARAMETER2,
                                                   PARAMETER3, // life time
                                                   wide_flag,  // Indicator whether current call is WBS or NBS?
                                                   G_PTR  );
                        }
                     }
#endif
                     else if( PARAMETER4 == 0xFF )    // Clear Paging queue
                     {
                        Discard_Page_Queue( PARAMETER1 );
                     }
                     else
                     {
                        Mmu_Free( G_PTR );
                     }  // Variable_CLMS not supported
#endif
                     return;
               }

               case  CLMS_MNCL_CALLER_ID_RQ_SWI:
               {
                     /* TRANSITION:      T2000                                                */
                     /* EVENT:           CLMS_MNCL_CALLER_ID_RQ_SWI                           */
                     /* DESCRIPTION:     Broadcast request from Layer 3                       */
                     /* REFERENCE:       ETS 300 175-5:1996                                   */
                     /* STARTING STATE:  CLMS_OPEN                                            */
                     /* END STATE:       CLMS_OPEN                                            */
                     /* ----------------------------------------------------------------------*/
                     return;
               }

               default:
                     break;

            }
            break;
	}												/* end of switch state					*/
	KNL_T0000();
}													/* end of DECODE_CLMS()					*/
