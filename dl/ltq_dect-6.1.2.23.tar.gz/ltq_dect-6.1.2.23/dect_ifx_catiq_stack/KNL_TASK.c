/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
*                   (c) 2005 IFX / INTNIX. All rights reserved.               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  MAIN.C                                                  *
*     Date       :  18 Nov, 2005                                      *
*     Contents   :  Contents : Program Entry Point / Main Loop              *
*     Hardware   :  IFX 87xx                                               *
*                                                                           *
*****************************************************************************
*/
   /* ========                                                             */
   /* Includes                                                             */
   /* ========                                                             */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#ifdef LINUX
#include <sys/ioctl.h>
#include <signal.h>
#include <sched.h>
#include <pthread.h>
#include <sys/time.h>
#include <unistd.h>
#endif

#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#include "FGLOBAL.H"
#include "KNL_SYSTEM.H"
#include "MMU.H"
#include "P_TIM.H"
#include "M_TIM.H"
#include "FDEF.H"
#include "SYSINIT.H"
 
//#include "FMAC_LIB.H"
//#include "FLLME.H"
#include "FBMC_DEF.H"

#include "CC_LIB.H"
#include "MM_LIB.H"

#include "CP_SERVER.H"
#include "IFX_DECT_MsgRouter.h"

//Dect Driver Header files
#include "fhmac.h"
#include "dect_drv_if.h"
#ifdef LINUX
#include "drv_timer.h"

#include "ifx_common_defs.h"
#include "ifx_os.h"
/*#include "IFX_Config.h"
#include "IFX_CallMgrIf.h"
#include "IFX_Agents_CfgIf.h"
#include "IFX_MediaMgrIf.h"*/
#endif
#include "CP_server_lib.h"

#include "MESSAGE_DEF.H"
#include "IFX_DECT_IEParser.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_MsgRouter.h"
#ifdef CATIQ_UPLANE
#include "uplane_if.h"
#include "CAT_UP.H"
static x_IPC_UPlane_Msg uplaneMsgBuf;
#ifndef UPLANE_LOOP
#error loop undefined 
#endif
#endif
#ifdef SUPERTASK
#define DECT_STACK_WAITGROUP_ID	3
#define DRIVER_STACK_EVT		0x0002
#define DBG_STACK_EVT			0x0004
#define CHECKTIME	5000	//for ms.
#define AGENT_STACK_EVT 1
extern char vcIsAVMSupport;
#endif
extern unsigned char TBR22_Test;
#ifdef FW_DOWNLOAD
#define vucLoaderMode vxGlobalInfo.xUSU.vucLoaderMode 
#endif

#define viDiagMode vxGlobalInfo.xDIAG.viDiagMode

//#include "IFX_DECT_CIF.h"

extern unsigned char VucDECT_Enable;
extern unsigned char VucRANDOM_Timer_Started;
x_IFX_DECT_IPC_Msg vxApp2StackMsg;


int timer_fd;
#define printf(...)
/* ===========================                                          */
/* Local function declarations                                          */
/* ===========================                                          */
#ifdef LINUX
int IFX_DECT_ProcessFDsAsync(fd_set *pReadFdset,fd_set *pWriteFdset,
                         fd_set *pExceptFdset,int32 *piNoOfFds);
#endif
/* ==========================                                           */
/* Global function definition                                           */
/* ==========================                                           */
unsigned char KNL_STATE_FOR_HMAC[MAX_LINK];
extern e_IFX_Return 
IFX_DECT_ReceivedFwDownloadStatus(x_IFX_DECT_LoaderFrame *pxConFrame);
extern BYTE
Get_Assigned_Po_No( BYTE cid );
#ifdef ULE_SUPPORT
IMPORT void ULEDLC_Init(void);
#endif
#ifdef CONFIG_REPEATER_SUPPORT
IMPORT uint8 * GetRepeaterSubscriptionInfoPtr(uint8 ucRepeaterNo);
#endif

//struct timeval looTp;					  // for test hiryu_20070816

void DECT_DEBUG_USER_add_time(void)
{
}
void IFX_CloseTimerDriver(void)
{
	if(timer_fd)
	{
#ifdef LINUX	
		ioctl(timer_fd, TIMER_DRV_SHUT, NULL);
		close(timer_fd);
		timer_fd=0;
#endif
	}
	return;
}
#ifdef __PIN_CODE__
EXTERN void IFX_DECT_ST_SetPinCode(char* pszPinCode);
#endif


/*! \brief  This function is used to DECT  Stack Version information. 
    \return IFX_SUCCESS / IFX_FAILURE
*/                                       
void IFX_DECT_Stack_PrintVersion()
{
	printf("[DECTSTACK] Dect stack compiled on Date:%s:%s\n",__DATE__,__TIME__);
			
}
#ifdef SUPERTASK
short IFX_DECT_Stack_GetVersion(char *pcBuff)
{
	if(pcBuff != NULL){
		sprintf(pcBuff,"%x:%s:%s",Get_Stack_Library_Version(),__DATE__,__TIME__);
	}
    return Get_Stack_Library_Version();
}
#endif
/*
*****************************************************************************
*                                                                          									*
*     Function :  init stack valiable                                                     					*
*                                                                           									*
*****************************************************************************
*                                                                           									*
*     purpose  :  dect stack array & table initial 										*
*     Parms    :  None                                                      							*
*     Returns  :  None                                                      							*
*     Remarks  :                                                            								*
*                                                                           									*
*****************************************************************************
*/

void init_proc_table(void)
{
	Init_Pro_Timer_Table ();				/* - the protocol timer table		   */
	Mmu_Init ();							/* - the MMU								*/
	KNL_INIT_TASK_QUEUE (); 				/* - the task queue 					   */
	KNL_INIT_SYSINT (); 				 	/* - state array							   */
	KNL_INIT_PROC ();					 	/* - all processes						   */
	
	//DectAgentIf_BufferInit();
}

void RESET_init_proc_table(void)
{
	Init_Pro_Timer_Table ();				/* - the protocol timer table		   */
	Mmu_Init ();							/* - the MMU								*/
	RESET_KNL_INIT_TASK_QUEUE (); 				/* - the task queue 					   */
	KNL_INIT_SYSINT (); 				 	/* - state array							   */
	RESET_KNL_INIT_PROC ();					 	/* - all processes						   */
}



/*
*****************************************************************************
*                                                                           									*
*     Function :  KNL task init                                                      						*
*                                                                           									*
*****************************************************************************
*                                                                           									*
*     purpose  :  program entry point and main loop controlling the input   				*
*     Parms    :  None                                                      							*
*     Returns  :  None                                                     								*
*     Remarks  :                                                            								*
*                                                                           									*
*****************************************************************************
*/

EXPORT void
KNL_Init (void)
{
  int cid_count = 0;


#if 0
                                     /* Initialisation of System         */
                                     /* ================================ */
  Init_Pro_Timer_Table ();            /* - the protocol timer table          */
  Mmu_Init ();                                 /* - the MMU                               */
  KNL_INIT_TASK_QUEUE ();         /* - the task queue                        */
  KNL_INIT_SYSINT ();                  /* - state array                              */
  KNL_INIT_PROC ();                     /* - all processes                           */

  DectAgentIf_BufferInit();
#endif
  init_proc_table();

#ifdef LINUX 
  //File descriptor Init -----
  if (IFX_DECT_MsgRt_Init() == IFX_FAILURE)
  {
    printf("[DECTSTACK] IFX_DECT_MsgRt_Init() failed!\n");
  }

#ifdef CATIQ_UPLANE

#if 0
  // Init FIFOs
  if(!uplane_fifos_init())
  {
    printf("[DECTSTACK] uplane_fifos_init() failed!\n");

  }
#endif
  InitUPlane(); // Init LU10 Stack

#if UPLANE_LOOP & (UPLANE_FTLOOP1 |UPLANE_FTLOOP2 | UPLANE_FTLOOP3)
  printf("[DECTSTACK] UPLANE_LOOP =%x\xd\xa",UPLANE_LOOP) ;
#if 0!=(UPLANE_LOOP & UPLANE_FTLOOP1)
  //printf("[DECTSTACK] LU10: FTLOOP1 is set\xd\xa");
#endif
#if 0!=(UPLANE_LOOP & UPLANE_FTLOOP2)
  //printf("[DECTSTACK] LU10: FTLOOP2 is set\xd\xa");
#endif
#if 0!=(UPLANE_LOOP & UPLANE_FTLOOP3)
  //printf("[DECTSTACK] LU10: FTLOOP3 is set\xd\xa");
#endif

#else
  //printf("[DECTSTACK] LU10: NO LOOPS DEFINED\xd\xa");
#endif

#endif

#ifdef CATIQ_UPLANE_FUXX
  //printf("[DECTSTACK] LU10: Doing LU01 Protocol, CATIQ_UPLANE_FU01 defined\xd\xa");
#endif
#ifdef ULE_SUPPORT
  ULEDLC_Init();
#endif

  timer_fd = open("/dev/timer_drv", O_RDWR);
  if (timer_fd < 0)
  {
    printf("[DECTSTACK] timer_drv open error!!!!\n");
  }

  if (DectDrvIfInit() == FALSE)
  {
    printf("[DECTSTACK] DectDrvIfInit() failed!\n");
  }
#endif
#ifdef SUPERTASK
  #ifdef ULE_SUPPORT
  ULEDLC_Init();
  #endif

  if (DectAgentIf_Init() == FALSE)
  {
    iprintf("DectAgentIf_FifoInit() failed!\n");
  }
  if (DectDrvIfInit() == FALSE)
  {
    iprintf("DectDrvIfInit() failed!\n");
  }
#endif
  
  for (cid_count = 0; cid_count < MAX_LINK ; cid_count++)
  {
    KNL_STATE_FOR_HMAC[cid_count] = FALSE;    //if True, KNL State is Idle.
  }
}


/* ================================ */
/* ======= K E R N E L  L O O P =======           */
/* ================================ */
EXPORT void
KNL_Task (void)
{
      Serve_Pro_Timer_Table();
                                       /* ======= Task Queue ============= */
      KNL_Serve_Task_Queue();
}

#ifdef LINUX
struct sigaction xSigInfo = {0};






char* DECT_GetSignalMsgStr( int ucMsgId)
	{
		char * pszMsgStr = 0;
		switch(ucMsgId)
		{
	
			case 1: pszMsgStr = "SIGHUP"; break;
			case 2: pszMsgStr = "SIGINT"; break;
			case 3: pszMsgStr = "SIGQUIT"; break;
			case 4:	pszMsgStr = "SIGILL"; break;
			case 5: pszMsgStr = "SIGTRAP"; break;
			case 6: pszMsgStr = "SIGABRT"; break;
			case 7: pszMsgStr = "SIGBUS"; break;
			case 8: pszMsgStr = "SIGFPE"; break;
			case 9: pszMsgStr = "SIGKILL"; break;
			case 10: pszMsgStr = "SIGUSR1"; break;
			case 11: pszMsgStr = "SIGSEGV"; break;
			case 12: pszMsgStr = "SIGUSR2"; break;
			case 13: pszMsgStr = "SIGPIPE"; break;
			case 14: pszMsgStr = "SIGALRM"; break;
			case 15: pszMsgStr = "SIGTERM"; break;
			case 17: pszMsgStr = "SIGCHLD"; break;
			case 18: pszMsgStr = "SIGCONT"; break;
			case 19: pszMsgStr = "SIGSTOP"; break;
			case 20: pszMsgStr = "SIGTSTP"; break;
			case 21: pszMsgStr = "SIGTTIN"; break;
			case 22: pszMsgStr = "SIGTTOU"; break;
			case 23: pszMsgStr = "SIGURG"; break;
			case 24: pszMsgStr = "SIGXCPU"; break;
			case 25: pszMsgStr = "SIGXFSZ"; break;
			case 26: pszMsgStr = "SIGVTALRM"; break;
			case 27: pszMsgStr = "SIGPROF"; break;
			case 28: pszMsgStr = "SIGWINCH"; break;
			case 29: pszMsgStr = "SIGIO"; break;
			case 30: pszMsgStr = "SIGPWR"; break;
			case 31: pszMsgStr = "SIGSYS"; break;
			case 33: pszMsgStr = "SIGRTMIN"; break;


			default:
				pszMsgStr = "SIGMIN OR SIGMAX"; break;
		}
	
		return pszMsgStr;
}







/*sigprocmask*/
/* SEGMENT FAULT */
void SigHandler(int num,siginfo_t *pxsigInfo,void *ptr)
{
   printf("[DECTSTACK] Dect Stack received %s\n",DECT_GetSignalMsgStr(num));
   printf("[DECTSTACK] Invalid memory access at %p\n",pxsigInfo->si_addr);
   printf("[DECTSTACK] Exiting DECT STACK PROCESS");
   exit(0);
}


int RegisterSigHdlr()
{

   int ret =0;
   struct sigaction xSig;
   //int *ptr;
   //int *ptr;
   xSigInfo.sa_sigaction = SigHandler;
   xSigInfo.sa_flags = SA_SIGINFO;
   if(sigaction(SIGSEGV,&xSigInfo,&xSig) < 0)
   {
	   printf("[DECTSTACK] Registering Segment fault handler failed\n");
	   ret = -1;
   }
   return ret;
}
#endif

#ifdef LINUX
/*
*****************************************************************************
*                                                                           *
*   Function   :  IFX_DECT_ProcessPendingQTasks                             *
*                                                                           *
*****************************************************************************
*   Purpose    :                 *
*   Parms      :                    *
*   Returns    :                                                        *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
int IFX_DECT_ProcessPendingQTasks()
{
  int iNumOfFds=0;
  fd_set xReadFdSet;
  fd_set xWriteFdSet;
  struct timeval xTv;//for test hiryu_20070816
  KNL_Task();
  //printf("\nProcess Pending Q Tasks.\n");
  while(1)
  {
   if(viDiagMode != 1){
    FD_ZERO(&xReadFdSet);
	FD_ZERO(&xWriteFdSet);
	
	FD_SET(dect_drv_fd, &xReadFdSet);// cosic drvier
	FD_SET(dect_drv_fd, &xWriteFdSet);// cosic drvier
	
	FD_SET(timer_fd, &xReadFdSet);// timer FD
	
    if (KNL_Get_TQ_Load())
    {
        xTv.tv_sec = 0;
        xTv.tv_usec = 0;
        iNumOfFds = select(FD_SETSIZE, &xReadFdSet, &xWriteFdSet, NULL, &xTv);
    } 
    else
    {
        return 0;
    }
    IFX_DECT_ProcessFDsAsync(&xReadFdSet,&xWriteFdSet,NULL,&iNumOfFds);
    KNL_Task();
   }	
  }
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  IFX_DECT_ProcessFDs                                  *
*                                                                           *
*****************************************************************************
*   Purpose    :                 *
*   Parms      :                    *
*   Returns    :                                                        *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
int IFX_DECT_ProcessFDs(fd_set *pReadFdset,fd_set *pWriteFdset,
                         fd_set *pExceptFdset,int32 *piNoOfFds){

  IFX_DECT_ProcessFDsAsync(pReadFdset,pWriteFdset,pExceptFdset,piNoOfFds);
  return IFX_DECT_ProcessPendingQTasks();
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  IFX_DECT_ProcessFDsAsync                                  *
*                                                                           *
*****************************************************************************
*   Purpose    :                 *
*   Parms      :                    *
*   Returns    :                                                        *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
int IFX_DECT_ProcessFDsAsync(fd_set *pReadFdset,fd_set *pWriteFdset,
                         fd_set *pExceptFdset,int32 *piNoOfFds)
{
   int ret_read_hmac;
   int ret_read_debug;

   //printf("----------------DECT STACK FS unblocked--------------\n");
   /* occur 20ms every time */
   if(timer_fd >0){
      if (FD_ISSET(timer_fd, pReadFdset))/* Every 20ms  */
      {
	      if( Osc_Trimming_Mode == TRUE )
         {
            unsigned char  dummy_data[ 2 ];
            dummy_data[ 0 ] = 0;
            dummy_data[ 1 ] = 0;
            trigger_cosic_driver_for_osc( dummy_data );
         }

         TA_Pro_Timer_Flag();
         (*piNoOfFds)--;
      }
      /* occur 20ms every time */
      if (FD_ISSET(timer_fd,pWriteFdset))/* Every 20ms  */
      {
	      x_IFX_DECT_IPC_Msg temp_agent_message;
	      memset(&temp_agent_message, 0x00, sizeof(x_IFX_DECT_IPC_Msg));
	      temp_agent_message.ucMsgId = FP_SOFTWARE_RESET_RQ;
	      Serve_Mail_CP(&temp_agent_message);
         (*piNoOfFds)--;
      }
   }
   
   /* get agent fifo */
   if ((iDectCplaneFifoFd)&&(FD_ISSET(iDectCplaneFifoFd, pReadFdset)))
   {
      int read_count = 0;
      int len = 0;
      memset(&vxApp2StackMsg, 0x00, sizeof(vxApp2StackMsg));
      len = sizeof(x_IFX_DECT_IPC_Msg);
      read_count = IFX_DECT_MsgRt_ReadAppMsg(IFX_IPC_DECT_C_PLANE,(unsigned char*)&vxApp2StackMsg, len);
      if (read_count == len)
      {
         #if 0	
	      if(vxApp2StackMsg->ucMsgId == IFX_DECT_DIAGMODE){
	         IFX_DECT_DIAG_ModemDiagnostics(1);
	      }else if(vxApp2StackMsg->ucMsgId == IFX_DECT_NODIAGMODE){
	         IFX_DECT_DIAG_ModemDiagnostics(0);
	      }else
         #endif	   
	      {
            Serve_Mail_CP(&vxApp2StackMsg);
	      }
      }   
      else
      {
         printf("############# read_count!=len   read from agent fifo error\n");
      }
      (*piNoOfFds)--;
   }
   
#if defined(CATIQ_UPLANE) || defined(ULE_SUPPORT)
   // Check for messages from DECT Uplane Agent
   if ((iDectUplaneFifoFd) && (FD_ISSET(iDectUplaneFifoFd, pReadFdset)))
   {
      if(Serve_UPMessage_Stack(&uplaneMsgBuf))
      {
         #ifdef CATIQ_UPLANE
         if(uplaneMsgBuf.ucMsgId== FP_MEDIA_SDU_SND_RQ)
         {     
            static FPTR fptr=0;
            uint16 len=(uplaneMsgBuf.ucPara1<<8)+uplaneMsgBuf.ucPara2;
            int rc;        

            #ifdef DECT_DEBUG_USER_CP_PRIMITIVE
            DECT_DEBUG_USER_CP_PRIMITIVE("FP_MEDIA_SDU_SND_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
                                         uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
            #endif
            if(len >0)
            {
               rc=LU10SduTxGetPtr (uplaneMsgBuf.ucInstance,&fptr);
               if(rc>=0)
               {
                  // Should add len check here...
                  memcpy(fptr,uplaneMsgBuf.acData,len);
                  #ifdef KLOCWORK
                  fptr[len] = '\0';
                  #endif
                  #if 0
                  {
                     uint16 i;
                     printf("Data ");
                     for (i=0;  i<len;  i++) {
                        if (fptr[i] <= 0x7F)
                           printf("%c", fptr[i]);
                        else
                           printf("!");                          
                     }
                     printf("[%02x%02x]\n", uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2);
                  }
                  #endif

                  #ifdef SDUSIZE
                  //rc = LU10SduTx( uplaneMsgBuf.ucInstance, len, &fptr, 1 );
                  rc = LU10SduTx( uplaneMsgBuf.ucInstance, len, &fptr, uplaneMsgBuf.ucPara3 );
            #else
                  rc = LU10SduTx( uplaneMsgBuf.ucInstance, len, &fptr );
            #endif
                  if(rc < 0)
                  {
                     DECT_DEBUG_UPLANE("SDUTx failed %d\n",rc);
                  }
                  else
                  {
                     DECT_DEBUG_UPLANE("SDUTx OK\n");
                  }
               }
               else
               {
                  DECT_DEBUG_UPLANE("failed to get SDU TX buffer, rc=%d\n",rc);
               }
            }
         }
         #endif
         #ifdef ULE_SUPPORT
         #ifdef CATIQ_UPLANE
         else
         #endif
         if(uplaneMsgBuf.ucMsgId== FP_ULE_MEDIA_SDU_SND_RQ)
         {     
            uint16 len = (uplaneMsgBuf.ucPara1 << 8) + uplaneMsgBuf.ucPara2;

            #ifdef DECT_DEBUG_USER_CP_PRIMITIVE
            DECT_DEBUG_USER_CP_PRIMITIVE("FP_ULE_MEDIA_SDU_SND_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
                                         uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
            #endif
            if (ULE_LU10SduTx(uplaneMsgBuf.ucPara4, len, uplaneMsgBuf.acData, 1)) {
               DECT_DEBUG_UPLANE("ULE SDU TX OK\n");
            } else {
               DECT_DEBUG_UPLANE("ULE SDU TX Failed\n");
            }
         } else if (uplaneMsgBuf.ucMsgId == FP_ULE_MEDIA_SDU_STOP_RQ) {
            #ifdef DECT_DEBUG_USER_CP_PRIMITIVE
            DECT_DEBUG_USER_CP_PRIMITIVE("FP_ULE_MEDIA_SDU_STOP_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
                                         uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
            #endif
            ULE_LU10SduTxStop(uplaneMsgBuf.ucPara4);
         } else if (uplaneMsgBuf.ucMsgId == FP_ULE_MEDIA_SDU_RCV_RESPONSE_RQ) {
            #ifdef DECT_DEBUG_USER_CP_PRIMITIVE
            DECT_DEBUG_USER_CP_PRIMITIVE("FP_ULE_MEDIA_SDU_RCV_RESPONSE_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
                                         uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
            #endif
            ULE_LU10SduRXResponse(uplaneMsgBuf.ucPara4, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3);
         }
         else if (uplaneMsgBuf.ucMsgId == FP_ULE_MEDIA_PAGE_RQ) {
            #ifdef DECT_DEBUG_USER_CP_PRIMITIVE
            DECT_DEBUG_USER_CP_PRIMITIVE("FP_ULE_MEDIA_PAGE_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
                                         uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
            #endif
            ULE_PageStart(uplaneMsgBuf.ucPara4, uplaneMsgBuf.ucPara3);
         } else if (uplaneMsgBuf.ucMsgId == FP_ULE_MEDIA_PAGE_STOP_RQ) {
            #ifdef DECT_DEBUG_USER_CP_PRIMITIVE
            DECT_DEBUG_USER_CP_PRIMITIVE("FP_ULE_MEDIA_PAGE_STOP_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
                                         uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
            #endif
            ULE_PageStop(uplaneMsgBuf.ucPara4, uplaneMsgBuf.ucPara3);
         }
         #endif
         else
         {
            DECT_DEBUG_UPLANE("Unknown message 0x%02x\n",uplaneMsgBuf.ucMsgId);
         }
      }
      (*piNoOfFds)--;
   }
#endif

   /* normal dect command */
   if ((dect_drv_fd)&&(FD_ISSET(dect_drv_fd,pReadFdset)))		
   {
      HMAC_QUEUES data[80/*RECEIVED_BUFFER_COUNT*/];
      int	i;
      memset(&data, 0x00, sizeof(data));
   #ifdef FW_DOWNLOAD
      if(vucLoaderMode){
        x_IFX_DECT_LoaderFrame xFrame; 
	      ioctl(dect_drv_fd,DECT_DRV_FW_READ, &xFrame);
        IFX_DECT_ReceivedFwDownloadStatus(&xFrame); 
      } else
   #endif
      {
         ret_read_hmac = read_from_hmac_ioctl(data);
         /* return value                0  :  continues data, 
                                   -1  :  last data
                                   -2  :  null data*/
     
         if(ret_read_hmac > 0)
         {
            if(ret_read_hmac > 5)
        	   printf("Too Long cnt hmac %d\n", ret_read_hmac);
            for(i=0; i<ret_read_hmac;i++)
            {
       	      /* put queue */
       	      KNL_SENDTASK_FROM_HMAC(&data[i]);
       	      #ifdef CONFIG_UPDATE_TASK_PROCESS_TIME
       	      KNL_Task();
       	      #endif
	         }
         }
         else 
         {
            //printf("[DECTSTACK] ****** dect_drv_fd FD_ISSET() no data error\n");
         }
         (*piNoOfFds)--;
      }
   }
   
   if ((dect_drv_fd)&&(FD_ISSET(dect_drv_fd, pWriteFdset)))		
   {
      DECT_MODULE_DEBUG_INFO data[10];
      int i;
      memset(&data, 0x00, sizeof(data));
      ret_read_debug = read_debug_from_module_ioctl(data);
      if(ret_read_debug > 0){
         //printf("[DECTSTACK] ret_read_debug: %02x\n", ret_read_debug);
         for(i=0; i< ret_read_debug; i++)
         {
         #if 0
	         printf("[DECTSTACK] Debug Info Ind: Data: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n",
                   data[i].G_PTR_buf[0], data[i].G_PTR_buf[1], data[i].G_PTR_buf[2], data[i].G_PTR_buf[3], data[i].G_PTR_buf[4],
                   data[i].G_PTR_buf[5], data[i].G_PTR_buf[6], data[i].G_PTR_buf[7], data[i].G_PTR_buf[8], data[i].G_PTR_buf[9],
                   data[i].G_PTR_buf[10],data[i].G_PTR_buf[11], data[i].G_PTR_buf[12],data[i].G_PTR_buf[13],data[i].G_PTR_buf[14]);
		 #endif

            Send_Message_To_APP( FP_DEBUG_INFO_IND, data[i].G_PTR_buf,
                             data[i].CurrentInc, data[i].debug_info_id,
                             0,0, Get_Assigned_Po_No(data[i].CurrentInc));
	      }
      }else
      {
	      //printf("[DECTSTACK] ****** dect_drv_fd FD_ISSET() no data error\n");
      }
      (*piNoOfFds)--;
   }
   //printf("End of DECT STACK PROCESS ret_read_hmac = %d iNumOfFds = %d \n", ret_read_hmac, *piNoOfFds);
   return IFX_SUCCESS;
}
#endif /*LINUX*/

/*
*****************************************************************************
*                                                                           *
*   Function   :  IFX_DECT_StackEntry                                  *
*                                                                           *
*****************************************************************************
*   Purpose    :                 *
*   Parms      :                    *
*   Returns    :                                                        *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef F_DECT_STACK_LIBRARY
e_IFX_Return IFX_DECT_StackEntry(IN uchar8 *paucRfpi,
                                 IN x_IFX_DECT_TransmitPowerParam *pxTpcPrams,
                                 IN x_IFX_DECT_BMCRegParams *pxBMCPrams,
                                 IN x_IFX_DECT_OscTrimVal *pxOscTrimVal,
                                 IN uint16 *punGaussianVal,
                                 IN x_IFX_DECT_SubscInfo *pxPPSubInfo,
                                 IN uchar8 ucNoOfSubscribedPPs,
                                 IN uchar8 ucCodec_Pri1,
                                 IN uchar8 ucCodec_Pri2,
                                 IN uchar8 ucNoEmo_State
                                 #ifdef __PIN_CODE__
                                 , IN char* pszPinCode 
                                 #endif
                                 )
#else

int  main (int argc, char *argv [])
#endif
{
   //fd_set xReadFdSet;
   //fd_set xExFdSet;
#ifdef LINUX	
   fd_set  xTempFdSet;//, xTempExcFdSet;
   fd_set xTempExFdSet;
   //int32   iNumOfFds;

   struct timeval xTv;						// for test hiryu_20070816
#endif
   //pid_t thread_pid;
   //struct sched_param  knl_task_param;

   int maxfd;
   //int ret_read_hmac;
   //int ret_read_debug;

   FPTR  rfpi_ptr;

   //	unsigned int iStartJiffies = 0;

   DECT_DEBUG_USER("########## DECT STACK Entry ##########\n");

   TBR22_Test =1;
   VucDECT_Enable=1;
   #ifdef F_DECT_STACK_LIBRARY
   rfpi_ptr = Get_Rfpi_Ptr( );
   rfpi_ptr[ 0 ] = paucRfpi[ 0 ];
   rfpi_ptr[ 1 ] = paucRfpi[ 1 ];
   rfpi_ptr[ 2 ] = paucRfpi[ 2 ];
   rfpi_ptr[ 3 ] = paucRfpi[ 3 ];
   rfpi_ptr[ 4 ] = paucRfpi[ 4 ];
  
   #ifdef __PIN_CODE__
	IFX_DECT_ST_SetPinCode(pszPinCode);
   #endif

	 
   memcpy( &Tpc_Param_Buf, pxTpcPrams, 7 );
   #ifdef KLOCWORK
   memcpy( &Tpc_Param_Buf1, (uchar8 *)pxTpcPrams+7, 14 ); // Need to add type-casting operation
   #else
   memcpy( &Tpc_Param_Buf1, &pxTpcPrams->ucTD1, 14 );
   #endif
   memcpy( &Tpc_Param_Buf2, &pxTpcPrams->ucTxBias, 1 );
   memcpy( &Bmc_Rssi_Settings, pxBMCPrams, sizeof( BMC_RSSI_STRUCT ) );
   memcpy( &Osc_Trim_Settings, pxOscTrimVal, sizeof( OSC_TRIM_STRUCT ) );
   Osc_Trim_H = Osc_Trim_Settings.ucOscTrimValHI;
   Osc_Trim_L = Osc_Trim_Settings.ucOscTrimValLOW;
   GFSK_Value = *punGaussianVal;

   NoEmo_StartUp_Mode = (ucNoEmo_State >> 4) & 0x0F;
   NoEmo_StartUp_Ch   = (ucNoEmo_State & 0x0F);

   #ifdef DECT_NG
   Primary_Codec = ucCodec_Pri1;
   #ifdef SUPERTASK
   Primary_Codec = 0x3;
   #endif
   #endif
   #else
   rfpi_ptr = Get_Rfpi_Ptr( );
   rfpi_ptr[ 0 ] = 0x00;
   rfpi_ptr[ 1 ] = 0x55;
   rfpi_ptr[ 2 ] = 0x00;
   rfpi_ptr[ 3 ] = 0xAA;
   rfpi_ptr[ 4 ] = 0x08;
   #endif

   KNL_Init();
   #ifdef SUPERTASK
   /* If AVM features is supported than change the EMC and mode.. dont move this code in any other place since MMINIT() resets First EMC code */
   if (vcIsAVMSupport) {
      DECT_DEBUG_USER("AVM Feature is supported\n");
      First_EMC_Code = 0x0b74;
      Model_ID=0x01;
   }
   #endif
   //RegisterSigHdlr();
   #define LOAD_SUBSCRIPTION_INFO 1
   #ifdef LOAD_SUBSCRIPTION_INFO //Mahipati : This is for loading subscription info
   {
      #if 0
      FT_SUBSCRIPTION xftSub = {0};
      char acIpui[] = {0x00, 0x79, 0x61, 0x52, 0xE6};
      char acUak[] = {0x43, 0x0d, 0x47, 0xba, 0xb3, 0x88, 0x42, 
      								0xf7, 0x3e, 0xc4, 0x1e, 0x42, 0x01, 0x97, 0x00, 0x89};
      char acDck[] = {0x5f, 0x6c, 0xa1, 0xb0, 0x13, 0x8c, 0x5c, 0x75};
      xftSub.status =  VALID;
      memcpy(xftSub.ipui_array,acIpui,5);
      //memcpy(xftSub.tpui_array,...;
      memcpy(xftSub.uak_array, acUak,16);
      memcpy(xftSub.dck_array, acDck, 8);;
      xftSub.service_class = 0x05;
      xftSub.model_id = 35;
      Subscription_LoadRegistrationData(1, &xftSub);
      #else
      
      
      //		ucNoOfSubscribedPPs = 0;
      
      int iPPno = 0;
      while( iPPno < ucNoOfSubscribedPPs ) 
      {
         Subscription_LoadRegistrationData(iPPno+1,(FPTR)(pxPPSubInfo+iPPno) );
         ++iPPno;
      }
      #ifdef ULE_SUPPORT
      Subscription_LoadULERegistrationData();
      #endif
      #endif

      #ifdef CONFIG_REPEATER_SUPPORT
      iPPno = 0;
      while( iPPno < NR_OF_REP_DEVICE ) 
      {
         // TODO_JOANTAHN. No Information from Agent. So, Repeater Registration Info. will be cleared.
         // Need to be modified.
         Subscription_LoadREPRegistrationData(iPPno+REP_DEVICE_OFFSET, (FPTR)GetRepeaterSubscriptionInfoPtr(iPPno+REP_DEVICE_OFFSET));
         ++iPPno;
      }
      #endif
	}
   #endif /*LOAD_SUBSCRIPTION_INFO*/

#ifdef LINUX
   if(vxGlobalInfo.viDECTStackMode == IFX_DECT_SYNC_MODE)
   {
      vxGlobalInfo.vxDECTSyncCallBks.pfnAddFDToSelect(timer_fd, IFX_DECT_READ_FDSET,
                                    (void (*)(fd_set *, fd_set *,fd_set *,int32 *))IFX_DECT_ProcessFDs);

      vxGlobalInfo.vxDECTSyncCallBks.pfnAddFDToSelect(timer_fd, IFX_DECT_WRITE_FDSET,
                                    (void (*)(fd_set *, fd_set *,fd_set *,int32 *))IFX_DECT_ProcessFDs);
      vxGlobalInfo.vxDECTSyncCallBks.pfnAddFDToSelect(dect_drv_fd, IFX_DECT_READ_FDSET,
                                    (void (*)(fd_set *, fd_set *,fd_set *,int32 *))IFX_DECT_ProcessFDs); 

      vxGlobalInfo.vxDECTSyncCallBks.pfnAddFDToSelect(dect_drv_fd, IFX_DECT_WRITE_FDSET,
                                    (void (*)(fd_set *, fd_set *,fd_set *,int32 *))IFX_DECT_ProcessFDs);
      IFX_DECT_ProcessPendingQTasks();  
    
	   ioctl(timer_fd, TIMER_DRV_RUNNING, 20);
    
	   DECT_DEBUG_USER("########## IN SYNC MODE RETURNING FROM DECT STACK INIT ##########\n");
      return IFX_SUCCESS;                                                     
   }
   else
   {
      int  iNumOfFds=0;	
      fd_set xReadFdSet;
      fd_set xWriteFdSet;
      //fd_set xTempReadFdSet;
      //fd_set xTempWriteFdSet;
      //uchar8 a;

	   DECT_DEBUG_USER("########## IN ASYNC MODE ##########\n");
    
	   FD_ZERO(&xReadFdSet);
      FD_ZERO(&xWriteFdSet);
    
	   FD_SET(iDectCplaneFifoFd, &xReadFdSet);// read fifo
#ifdef CATIQ_UPLANE
      FD_SET(iDectUplaneFifoFd,&xReadFdSet); // uPlane Agent
#endif

      FD_SET(timer_fd, &xReadFdSet);// timer driver
      FD_SET(timer_fd, &xWriteFdSet);// timer driver
    
	   ioctl(timer_fd, TIMER_DRV_RUNNING, 20);//20ms timer start
	   FD_SET(dect_drv_fd, &xReadFdSet);// cosic drvier
      FD_SET(dect_drv_fd, &xWriteFdSet);// cosic drvier

      //printf("dect_drv_fd:%d",dect_drv_fd);

	   maxfd = (dect_drv_fd > timer_fd)&&(dect_drv_fd>iDectCplaneFifoFd) ?
             dect_drv_fd:timer_fd > iDectCplaneFifoFd ?timer_fd:iDectCplaneFifoFd;

#ifdef CATIQ_UPLANE
      maxfd = maxfd >iDectUplaneFifoFd? maxfd:iDectUplaneFifoFd; 
#endif 


      //IFX_OS_LockAcquire(vxGlobalInfo.xDIAGApiLock);
      while(1)
      {
         if(viDiagMode != 1){
            memcpy(&xTempFdSet, &xReadFdSet, sizeof(fd_set));
            memcpy(&xTempExFdSet, &xWriteFdSet, sizeof(fd_set));
            if (KNL_Get_TQ_Load())
            {
               xTv.tv_sec = 0;
 	            xTv.tv_usec = 0;
               iNumOfFds = select(FD_SETSIZE, &xTempFdSet, &xTempExFdSet, NULL, &xTv);		// NON blocking
            } 
	         else
            {
               iNumOfFds = select(FD_SETSIZE, &xTempFdSet,&xTempExFdSet,NULL,NULL);	// blocking 
            }
            if (iNumOfFds < 0)
            {
               printf("Select System Call failing\n");
               perror("The Error is ");
            }
            IFX_DECT_ProcessFDsAsync(&xTempFdSet,&xTempExFdSet,NULL,&iNumOfFds);
            KNL_Task();
         }else{
            sleep(10);
         }
      } // while(1)
  
      // IFX_OS_LockRelease(vxGlobalInfo.xDIAGApiLock);
   
      DECT_DEBUG_USER("End of DECT STACK PROCESS iNumOfFds = %d\n", iNumOfFds);
	   DECT_DEBUG_USER("########## Exiting DECT STACK ##########\n");
      exit(0);
  }
#endif /*LINUX*/
}

#ifdef SUPERTASK
void HandleAgentMsg()
{
    //BLOCK_PREEMPTION;
	while(!DectAgentIf_IsStackMBEmpty())
	{
		memset(&vxApp2StackMsg, 0x00, sizeof(vxApp2StackMsg));
		//BLOCK_PREEMPTION;
		lock_preempt();
		clrgrp(DECT_STACK_WAITGROUP_ID,1);
		DectAgentIf_StackMBRead((unsigned char*)&vxApp2StackMsg, sizeof(vxApp2StackMsg));
	        //UNBLOCK_PREEMPTION;
		unlock_preempt();
        	Serve_Mail_CP(&vxApp2StackMsg);
	}
}

void HandleUplaneMsg()
{
	while(!DectAgentIf_IsUplaneMBEmpty())
	{
		memset(&uplaneMsgBuf, 0x00, sizeof(uplaneMsgBuf));
		//BLOCK_PREEMPTION;
		lock_preempt();
		clrgrp(DECT_STACK_WAITGROUP_ID,8);
		DectAgentIf_UplaneMBRead((unsigned char*)&uplaneMsgBuf, sizeof(uplaneMsgBuf));
		//UNBLOCK_PREEMPTION;
		unlock_preempt();

		if(uplaneMsgBuf.ucMsgId== FP_MEDIA_SDU_SND_RQ)
     	{     
			static FPTR fptr=0;
			uint16 len=(uplaneMsgBuf.ucPara1<<8)+uplaneMsgBuf.ucPara2;
			int rc;        

			#ifdef DECT_DEBUG_USER_CP_PRIMITIVE
			DECT_DEBUG_USER_CP_PRIMITIVE("FP_MEDIA_SDU_SND_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
			                             uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
       	#endif
       	if(len >0)
			{
				// call with len 0 to get current ptr
				rc=LU10SduTxGetPtr (uplaneMsgBuf.ucInstance,&fptr);
				if(rc>=0)
				{
					// Should add len check here...
					memcpy(fptr,uplaneMsgBuf.acData,len);

#ifdef SDUSIZE          
					rc = LU10SduTx( uplaneMsgBuf.ucInstance, len, &fptr, uplaneMsgBuf.ucPara3 );
#else
					rc = LU10SduTx( uplaneMsgBuf.ucInstance, len, &fptr );
#endif
					if(rc < 0)
					{
						// Error: failed to send data
						DECT_DEBUG_UPLANE("SDUTx failed %d\n",rc);
					}
					else
					{
						//DECT_DEBUG_UPLANE("SDUTx OK\n");
					}
				}
				else
				{
					// failed to get a tx buffer
					DECT_DEBUG_UPLANE("failed to get SDU TX buffer, rc=%d\n",rc);
				}
			}
		}
#ifdef ULE_SUPPORT
		else if(uplaneMsgBuf.ucMsgId== FP_ULE_MEDIA_SDU_SND_RQ)
		{
			uint16 len = (uplaneMsgBuf.ucPara1 << 8) + uplaneMsgBuf.ucPara2;

			#ifdef DECT_DEBUG_USER_CP_PRIMITIVE
			DECT_DEBUG_USER_CP_PRIMITIVE("FP_ULE_MEDIA_SDU_SND_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
			                             uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
			#endif
			if (ULE_LU10SduTx(uplaneMsgBuf.ucPara4, len, uplaneMsgBuf.acData, 1)) {
				DECT_DEBUG_UPLANE("ULE SDU TX OK\n");
			} else {
				DECT_DEBUG_UPLANE("ULE SDU TX Failed\n");
			}

		}
		else if (uplaneMsgBuf.ucMsgId == FP_ULE_MEDIA_SDU_STOP_RQ) {
			#ifdef DECT_DEBUG_USER_CP_PRIMITIVE
			DECT_DEBUG_USER_CP_PRIMITIVE("FP_ULE_MEDIA_SDU_STOP_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
			                             uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
			#endif
			ULE_LU10SduTxStop(uplaneMsgBuf.ucPara4);
		}
		else if (uplaneMsgBuf.ucMsgId == FP_ULE_MEDIA_SDU_RCV_RESPONSE_RQ) {
			#ifdef DECT_DEBUG_USER_CP_PRIMITIVE
			DECT_DEBUG_USER_CP_PRIMITIVE("FP_ULE_MEDIA_SDU_RCV_RESPONSE_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
			                             uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
			#endif
			ULE_LU10SduRXResponse(uplaneMsgBuf.ucPara4, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3);
		}
		else if (uplaneMsgBuf.ucMsgId == FP_ULE_MEDIA_PAGE_RQ) {
			#ifdef DECT_DEBUG_USER_CP_PRIMITIVE
			DECT_DEBUG_USER_CP_PRIMITIVE("FP_ULE_MEDIA_PAGE_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
			                            uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
			#endif
			ULE_PageStart(uplaneMsgBuf.ucPara4, uplaneMsgBuf.ucPara3);
		} else if (uplaneMsgBuf.ucMsgId == FP_ULE_MEDIA_PAGE_STOP_RQ) {
			#ifdef DECT_DEBUG_USER_CP_PRIMITIVE
			DECT_DEBUG_USER_CP_PRIMITIVE("FP_ULE_MEDIA_PAGE_STOP_RQ, %02x, %02x %02x %02x %02x\n", uplaneMsgBuf.ucInstance,
			                            uplaneMsgBuf.ucPara1, uplaneMsgBuf.ucPara2, uplaneMsgBuf.ucPara3, uplaneMsgBuf.ucPara4);
			#endif
			ULE_PageStop(uplaneMsgBuf.ucPara4, uplaneMsgBuf.ucPara3);
		}
#endif /* ULE_SUPPORT*/

        else
        {
          // Dont know this message yet
          DECT_DEBUG_UPLANE("Unknown message 0x%02x\n",uplaneMsgBuf.ucMsgId);
        }

      }
}

void HandleDrvMsg()
{
		HMAC_QUEUES data[80/*RECEIVED_BUFFER_COUNT*/];
	  	int	i;
		int ret_read_hmac;

      	memset(&data, 0x00, sizeof(data));

	     ret_read_hmac = read_from_hmac_ioctl(data);
		  /* return value                0  :  continues data, 
                                                      -1  :  last data
                                                      -2  :  null data		    */

		  if(ret_read_hmac > 0)// || ret_read_hmac == -1)		// continue or last
		  {
			if(ret_read_hmac > 5)
				iprintf("Too Long cnt hmac %d\n", ret_read_hmac);
		  
		  	for(i=0; i<ret_read_hmac;i++)
	  		{
		  	/* put queue */
		     	KNL_SENDTASK_FROM_HMAC(&data[i]);
		  	}

		  }
}

#endif

