/* -- SIEMENS AG  PCT -- Process: LC          -  Mon Feb 26 14:22:27 2007 -- */

#include "DEFINE.H"
# include <stdio.h>
# include <string.h>
# include "SYSDEF.H"
# include "FDEF.H"
# include "TYPEDEF.H"
extern void KNL_T0000(void);
# include "SYSEXT.H"

      /*
      *****************************************************************************
      *                                                                           *
      *     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
      *                   (c) 2005 IFX / INTNIX. All rights reserved.               *
      *                                                                           *
      *****************************************************************************
      *                                                                           *
      *     Workfile   :  FLC.PSL                                                 *
      *     Date       :  18 Nov, 2005                                       *
      *     Contents   :                                                          *
      *     Hardware   :  IFX 87xx                                               *
      *                                                                           *
      *****************************************************************************
      */
      /* ========                                                             */
      /* Includes                                                             */
      /* ========                                                             */
      #include    "DEFINE.H"

      #include    "SYSDEF.H"
      #include    "TYPEDEF.H"
      #include    "CONF_DEF.H"
      #include    "ERROR.H"
      #include    "FGLOBAL.H"
      #include    "PCT_DEF.H"
      #include    "KNL_SYSTEM.H"
      #include    "MMU.H"
      #include    "P_TIM.H"
      #include    "LC_LIB.H"
      #include "LCE_LIB.H"
      #include "CP_SERVER.H"

      #include "dect_drv_if.h"

      /* ==============                                                       */
      /* Local typedefs                                                       */
      /* ==============                                                       */
      #ifdef DECT_DEBUG_USER_LC_PRIMITIVE
      typedef struct {
         BYTE key;
         char *string;
      } DebugStringTable_t;
      #endif

      #ifdef CONFIG_UPDATE_LINK_RELEASE
      typedef struct {
         BOOL releasePending;
      } LCData_t;
      #endif

      /* ===============                                                      */
      /* Local variables                                                      */
      /* ===============                                                      */
      #ifdef DECT_DEBUG_USER_LC_PRIMITIVE
      LOCAL DebugStringTable_t stateStringTable[] = {
         {CLOSED, "CLOSED"},
         {OPEN, "OPEN"},
         {FREE, "FREE"},
         {0xFF, "Unknown State"}
      };
      /*   Messages  */

      LOCAL DebugStringTable_t messageStringTable[] = {
         {LC_REL_RQ_NORMAL_LAP, "LC_REL_RQ_NORMAL_LAP"},
         {LC_REL_RQ_ABNORMAL_LAP, "LC_REL_RQ_ABNORMAL_LAP"},
         {LC_DIS_IN_MAC, "LC_DIS_IN_MAC"},
         {LC_DIS_CFM_MAC, "LC_DIS_CFM_MAC"},
         {LC_CON_IN_MAC, "LC_CON_IN_MAC"},
         {LC_CO_DATA_DTR_MAC, "LC_CO_DATA_DTR_MAC"},
         {LC_CO_DATA_IN_MAC, "LC_CO_DATA_IN_MAC"},
         {LC_CO_DATA_RQ_LAP, "LC_CO_DATA_RQ_LAP"},
         {LC_DL_ENC_KEY_RQ_LAP, "LC_DL_ENC_KEY_RQ_LAP"},
         {LC_ENC_EKS_IND_MAC, "LC_ENC_EKS_IND_MAC"},
         {0xFF, "Unknown Message"}
      };
      #endif

      #ifdef CONFIG_UPDATE_LINK_RELEASE
      LOCAL LCData_t XDATA LCData[MAX_LINK];
      #endif

      /* ==========================                                           */
      /* Global function definition                                           */
      /* ==========================                                           */
      EXPORT void
      LC_INIT( void )
      {
      Init_Queue( LC );
      Cs_Ctrl_Init ();
      }

      /* ==========================                               */
      /* Global function definition                               */
      /* ==========================                               */
      EXPORT void
      RESET_LC_INIT( void )
      {
         unsigned char i;

         for( i = 0; i < MAX_LINK; i++ )
         {
            Discard_Queue(LC, i);      // malloc queue clear by ralph_150508
            Reset_Cs_Ctrl(i);
         }
         Init_Queue( LC );
      }

      /* =========================                                            */
      /* Local function definition                                            */
      /* =========================                                            */
      #ifdef CONFIG_UPDATE_LINK_RELEASE
      LOCAL void
      clearLCData(void)
      {
         LCData[CurrentInc].releasePending = NO;
      }
      #endif

            static void T0202( void )
            {
               /* TRANSITION:      T0202                                                */
               /* EVENT:           LC_DIS_IN_MAC                                        */
               /* DESCRIPTION:     LAP Layer requests MAC Release                       */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  CLOSED / OPEN / FREE                                 */
               /* END STATE:       CLOSED                                               */
               /* ----------------------------------------------------------------------*/
               /* The Link Release is              */
               /* reported to the LAP process.     */

               #ifdef CONFIG_UPDATE_LINK_RELEASE
               if (CurrentState == CLOSED) {
                  if (!LCData[CurrentInc].releasePending) {
                     return;
                  }
               }
               #endif

               KNL_SENDTASK_INC( LAP, LAP_REL_IN_LC, CurrentInc );
               /* Discard the LC-Queue and reset   */
               /* the Cs-Fragment Structure.       */
               Discard_Queue( LC, CurrentInc );

               Reset_Cs_Ctrl( CurrentInc );

               #ifdef CONFIG_REPEATER_SUPPORT
               KNL_SENDTASK_INC( LC_REP, LC_DIS_IN_MAC, CurrentInc );
               #endif
               #ifdef CONFIG_UPDATE_LINK_RELEASE
               clearLCData();
               #endif
               KNL_Transit( CLOSED );
            }

            static void T0200( void )
            {
               /* TRANSITION:      T0200                                                */
               /* EVENT:           LC_DIS_CFM_MAC                                       */
               /* DESCRIPTION:     MAC Layer confirms MAC Release                       */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  CLOSED                                               */
               /* END STATE:       CLOSED                                               */
               /* ----------------------------------------------------------------------*/
               /* The Link Release is              */
               /* confirmed to the LAP process.    */
               #ifdef CONFIG_UPDATE_LINK_RELEASE
               if (LCData[CurrentInc].releasePending)
               #endif
               {
               KNL_SENDTASK_INC( LAP, LAP_REL_CFM_LC, CurrentInc );
               /* Discard the LC-Queue and reset   */
               /* the Cs-Fragment Structure.       */
               Discard_Queue( LC, CurrentInc );
               Reset_Cs_Ctrl( CurrentInc );
               #ifdef CONFIG_REPEATER_SUPPORT
               KNL_SENDTASK_INC( LC_REP, LC_DIS_IN_MAC, CurrentInc );
               #endif
                  #ifdef CONFIG_UPDATE_LINK_RELEASE
                  clearLCData();
                  #endif
               KNL_Transit( CLOSED );
            }
            }

            static void T0203( void )
            {
               /* TRANSITION:      T0203                                                */
               /* EVENT:           LC_REL_RQ_NORMAL_LAP                                 */
               /* DESCRIPTION:     LAP Layer requests MAC Release                       */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  OPEN / FREE                                          */
               /* END STATE:       CLOSED / current state maintained                    */
               /* ----------------------------------------------------------------------*/
               /* The normal Link Release is only  */
               /* processed, when the LC-Queue is  */
               /* empty. Otherwise a 'reminder'    */
               /* is send.                         */
               if( Empty_Queue( LC, CurrentInc ) == TRUE )
               {
                  write_to_hmac_ioctl( HMAC, MAC_DIS_RQ_LC,
                                       CurrentInc, 0, 0, 0,
                                       0, 0 ,0, 0);
                  #ifdef CONFIG_UPDATE_LINK_RELEASE
                  LCData[CurrentInc].releasePending = YES;
                  #endif
                  KNL_Transit( CLOSED );
               }
               else
               {
               KNL_SENDTASK_INC( LC, LC_REL_RQ_NORMAL_LAP, CurrentInc );
               }
            }

            static void T0253( void )
            {
               /* TRANSITION:      T0253                                                */
               /* EVENT:           LC_REL_RQ_ABNORMAL_LAP                               */
               /* DESCRIPTION:     LAP Layer requests MAC Release                       */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  OPEN_PENDING / OPEN / FREE                           */
               /* END STATE:       CLOSED                                               */
               /* ----------------------------------------------------------------------*/
               /* Abnormal Link Release request !  */
               Discard_Queue( LC, CurrentInc );
               write_to_hmac_ioctl( HMAC, MAC_DIS_RQ_LC,
                                    CurrentInc, 0, 0, 0,
                                    0, 0, 0, 0);
               #ifdef CONFIG_UPDATE_LINK_RELEASE
               LCData[CurrentInc].releasePending = YES;
               #else
               #ifdef CONFIG_REPEATER_SUPPORT
               KNL_SENDTASK_INC( LC_REP, LC_DIS_IN_MAC, CurrentInc );
               #endif
               #endif
               KNL_Transit( CLOSED );
            }

            static void T0301( void )
            {
               /* TRANSITION:      T0301                                                */
               /* EVENT:           LC_CO_DATA_IN_MAC                                    */
               /* DESCRIPTION:     MAC Layer reports data indication                    */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  OPEN / FREE                                          */
               /* END STATE:       current state maintained                             */
               /* ----------------------------------------------------------------------*/
               FPTR temp;

               /* The received Cs-Fragment is      */
               /* stored.                          */
               DECT_DEBUG_USER_LC_DATA("[LC] Data In: %02x Data: %02x %02x %02x %02x %02x\n", CurrentInc, G_PTR[ sizeof( struct HLI_Header ) ],
               G_PTR[sizeof( struct HLI_Header ) + 1],G_PTR[sizeof( struct HLI_Header ) + 2],
               G_PTR[sizeof( struct HLI_Header ) + 3],G_PTR[sizeof( struct HLI_Header ) + 4]);
               temp = Ct_fragment_received( CurrentInc, G_PTR );
               if( temp != NULL )
               {
               /* A complete DLC-Frame is received.*/
               /* The frame is passed to the LAP   */
               /* process.                         */
               /* ---------------------------------*/
               /* CID value: Connection ID         */
               /* LCN value: logical Connection No */
               /* Only one LC process incarnation  */
               /* per DLC Layer (no Connection HOV */
               /* support at the FT side).         */
               Decode_Received_Frame( CurrentInc, CurrentInc, temp );
               }
            }

            static void T0600( void )
            {
               /* TRANSITION:      T600                                                 */
               /* EVENT:           LC_DL_ENC_KEY_RQ_LAP                                 */
               /* DESCRIPTION:     Encryption key provision                             */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  OPEN / FREE                                          */
               /* END STATE:       OPEN / FREE                                          */
               /* ----------------------------------------------------------------------*/
               /* MCEI is transferred in           */
               /* Parameter1                       */
               // TODO: pointer �ٽ� ������
               write_to_hmac_ioctl( HMAC, MAC_ENC_KEY_RQ_LC,
                                    CurrentInc, 0, 0, 0,
                                    1, 0, G_PTR, 0);
            }

            static void T0602( void )
            {
               /* TRANSITION:      T602                                                 */
               /* EVENT:           LC_ENC_EKS_IND_MAC                                   */
               /* DESCRIPTION:     Encryption mode confirmation                         */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  OPEN / FREE                                          */
               /* END STATE:       OPEN / FREE                                          */
               /* ----------------------------------------------------------------------*/
               KNL_SENDTASK_WP_INC( LAP, LAP_DL_ENC_IND_LC, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4, CurrentInc );
            }

      #ifdef DECT_DEBUG_USER_LC_PRIMITIVE
      LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
      {
         BYTE i;

         for (i = 0; tablePtr[i].key != 0xFF; i++) {
            if (tablePtr[i].key == key) {
               break;
            }
         }
         return tablePtr[i].string;
      }
      #endif

//****************************************************************************
//****************************************************************************
void DECODE_LC(void)
{
   #ifdef DECT_DEBUG_USER_LC_PRIMITIVE
   DECT_DEBUG_USER_LC_PRIMITIVE("%s, %s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable),
   getDebugStringRef(CurrentState, stateStringTable), CurrentInc, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
   #endif

   switch (CurrentState)
   {
      /**********************************
       CLOSED State
      **********************************/
      case CLOSED:
         switch (CurrentMessage)
         {
            #ifndef CONFIG_UPDATE_LINK_RELEASE
            case LC_REL_RQ_NORMAL_LAP:
            case LC_REL_RQ_ABNORMAL_LAP:  /*  IN LINE CODE T0201    */
            {
               /* TRANSITION:      T0201                                                */
               /* EVENT:           LC_REL_RQ_NORMAL_LAP                                 */
               /* DESCRIPTION:     LAP Layer requests MAC Release                       */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  CLOSED                                               */
               /* END STATE:       CLOSED                                               */
               /* ----------------------------------------------------------------------*/
               /* The LAP process requests the     */
               /* release of a non-existent link.  */
               KNL_SENDTASK_INC( LAP, LAP_REL_CFM_LC, CurrentInc );
            }
            return;
            #endif

            case LC_DIS_IN_MAC:
               T0202();
            return;

            case LC_DIS_CFM_MAC:
               T0200();
            return;

            case LC_CON_IN_MAC:  /*  IN LINE CODE T0100    */
            {
#ifdef DECT_NG
               //BYTE po_no;
#endif
               /* TRANSITION:      T0100                                                */
               /* EVENT:           LC_CON_IN_MAC                                        */
               /* DESCRIPTION:     peer MAC Layer has established MAC-Layer             */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  CLOSED                                               */
               /* END STATE:       OPEN                                                 */
               /* ----------------------------------------------------------------------*/
               /* Load the used PMID as            */
               /* Link Signature (LSIG).           */
               Load_LSIG( CurrentInc );

#ifdef DECT_NG
               //po_no = Get_Assigned_Po_No(CurrentInc);
               if(PARAMETER1 == MT_ATTRIBUTES_SLOT_TYPE_LONG)
               {
                  Required_Slot_Type_CID[CurrentInc] = 1;
               }
               else if(PARAMETER1 == MT_ATTRIBUTES_SLOT_TYPE_FULL)
               {
                  Required_Slot_Type_CID[CurrentInc] = 0;
               }
#endif

               KNL_Transit( OPEN );
            }
            return;

            case LC_CO_DATA_DTR_MAC:  /*  IN LINE CODE T0900    */
            {
               /* TRANSITION:      T0900                                                */
               /* EVENT:           LC_CO_DATA_DTR_MAC                                   */
               /* DESCRIPTION:     MAC layer flow control for MACTEST                   */
               /* REFERENCE:                                                            */
               /* STARTING STATE:  CLOSED                                               */
               /* END STATE:       CLOSED                                               */
               /* ----------------------------------------------------------------------*/
               #ifdef MACTEST
               FPTR temp;

               temp = Get_Next_Dummy_Ct_Frag( CurrentInc );
               if( temp != NULL )
               {
               KNL_SENDTASK_NP_WP( HMAC, MAC_CO_DATA_RQ_LC, temp,
               CurrentInc, 0, 0, 0 );
               }
               #endif /* MACTEST */
            }
            return;

            case LC_CO_DATA_IN_MAC:  /*  IN LINE CODE T0901    */
            {
               /* TRANSITION:      T0901                                                */
               /* EVENT:           LC_CO_DATA_IN_MAC                                    */
               /* DESCRIPTION:     MAC layer indicates received data                    */
               /* REFERENCE:       only for MACTEST !!                                  */
               /* STARTING STATE:  CLOSED                                               */
               /* END STATE:       CLOSED                                               */
               /* ----------------------------------------------------------------------*/
               #ifdef MACTEST
               /* if the receied Ct fragment does  */
               /* not look like the one expected   */
               /* the user is informed             */
               if (!Check_Received_Dummy_Ct_Frag ( CurrentInc,
               G_PTR+sizeof(struct HLI_Header) ))
               {
               Send_Response_Long( 40, 60, 5, G_PTR+sizeof(struct HLI_Header));
               }
               #endif /* MACTEST */
               Mmu_Free( G_PTR );
            }
            return;

            default:
                break;
         }                             /* end of switch message            */
         break;

      /**********************************
       OPEN State
      **********************************/
      case OPEN:
         switch (CurrentMessage)
         {
            #ifdef CONFIG_REPEATER_SUPPORT
            case LC_CON_IN_MAC:  /*  IN LINE CODE T0100    */
               /* TRANSITION:      T0100                                                */
               /* EVENT:           LC_CON_IN_MAC                                        */
               /* DESCRIPTION:     peer MAC Layer has established MAC-Layer             */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  CLOSED                                               */
               /* END STATE:       OPEN                                                 */
               /* ----------------------------------------------------------------------*/
                                                   /* Load the used PMID as            */
                                                   /* Link Signature (LSIG).           */
               Load_LSIG( CurrentInc );
               return;
            #endif

            case LC_REL_RQ_NORMAL_LAP:
               T0203();
            return;

            case LC_REL_RQ_ABNORMAL_LAP:
               T0253();
            return;

            case LC_DIS_IN_MAC:
               T0202();
            return;

            #ifndef CONFIG_UPDATE_LINK_RELEASE
            case LC_DIS_CFM_MAC:
               T0200();
            return;
            #endif

            case LC_CO_DATA_DTR_MAC:  /*  IN LINE CODE T0300    */
            {
               /* TRANSITION:      T0300                                                */
               /* EVENT:           LC_CO_DATA_DTR_MAC                                   */
               /* DESCRIPTION:     MAC Layer flow control                               */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  OPEN                                                 */
               /* END STATE:       FREE                                                 */
               /* ----------------------------------------------------------------------*/
               FPTR temp;
               FPTR malloc_temp;

               /* MAC Layer Flow Control           */
               /* -------------------------------- */
               temp = MacCoDtr_received( CurrentInc );

               if( temp != NULL )
               {
                  /* The transmission of the          */
                  /* DLC-frame is not yet completed.  */
                  /* The next Cs-Fragment is send.    */
                  malloc_temp = Mmu_Malloc(5);
                  #ifdef KLOCWORK
                  if(malloc_temp != NULL)
                  #endif
                  {
                     memset(malloc_temp, 0, 5);
                     memcpy(malloc_temp, temp, 5);

                     // TODO: NOT USE
                  write_to_hmac_ioctl( HMAC, MAC_CO_DATA_RQ_LC,
                                       CurrentInc, 0, 0, 0,
                                       0, 5, malloc_temp, 0);
                  DECT_DEBUG_USER_LC_DATA("[LC] Data Out: %02x Data: %02x %02x %02x %02x %02x\n",
                                          CurrentInc, temp[0], temp[1], temp[2], temp[3], temp[4]);
                  }
               }
               else
               {
                  /* The transmission of the          */
                  /* DLC-frame is completed.          */
                  /* Another DLC-Frame queued ?       */
                  temp = Get_Next_Queue_Entry( LC, CurrentInc );

                  if( temp != NULL )
                  {
                     /* Set Transmit Control with next   */
                     /* DLC-Frame.                       */
                     temp = Set_Tx_Ctrl( CurrentInc, temp );
                     /* Invoke transmission of first     */
                     /* Cs-Fragment.                     */

                     malloc_temp = Mmu_Malloc(5);
                     #ifdef KLOCWORK
                     if(malloc_temp != NULL)
                     #endif
                     {
                        memset(malloc_temp, 0, 5);
                        memcpy(malloc_temp, temp, 5);

                        // TODO:  not use strip  Set_Tx_Ctrl
                        write_to_hmac_ioctl( HMAC, MAC_CO_DATA_RQ_LC,
                                             CurrentInc, 0, 0, 0,
                                             0, 5, malloc_temp, 0);

                     DECT_DEBUG_USER_LC_DATA("[LC] Data Out: %02x Data: %02x %02x %02x %02x %02x\n", 
                                             CurrentInc, temp[0], temp[1], temp[2], temp[3], temp[4]);
                     }
                  }
                  else
                  {
                  /* Nothing to do.                   */
                     KNL_Transit( FREE );
                  }
               }
            }
            return;

            case LC_CO_DATA_IN_MAC:
               T0301();
            return;

            case LC_CO_DATA_RQ_LAP:  /*  IN LINE CODE T0401    */
            {
               /* TRANSITION:      T0401                                                */
               /* EVENT:           LC_CO_DATA_RQ_LAP                                    */
               /* DESCRIPTION:     Data Request from LAP-Process                        */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  OPEN_PENDING / OPEN / FREE                           */
               /* END STATE:       current state maintained                             */
               /* ----------------------------------------------------------------------*/
               /* Currently a DLC-Frame is         */
               /* transmitted, or no MAC link is   */
               /* established.                     */
               /* The DLC-Frame is stored in the   */
               /* LC-Queue.                        */
               Put_in_Queue( LC,
               CurrentInc,
               Make_Fill_Bytes_and_CRC( CurrentInc, G_PTR ));
            }
            return;

            case LC_DL_ENC_KEY_RQ_LAP:
               T0600();
            return;

            case LC_ENC_EKS_IND_MAC:
               T0602();
            return;

            default:
                break;
         }                             /* end of switch message            */
         break;

      /**********************************
       FREE State
      **********************************/
      case FREE:
         switch (CurrentMessage)
         {
            #ifdef CONFIG_REPEATER_SUPPORT
            case LC_CON_IN_MAC:  /*  IN LINE CODE T0100    */
               /* TRANSITION:      T0100                                                */
               /* EVENT:           LC_CON_IN_MAC                                        */
               /* DESCRIPTION:     peer MAC Layer has established MAC-Layer             */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  CLOSED                                               */
               /* END STATE:       OPEN                                                 */
               /* ----------------------------------------------------------------------*/
                                                   /* Load the used PMID as            */
                                                   /* Link Signature (LSIG).           */
               Load_LSIG( CurrentInc );
               return;
            #endif

            case LC_REL_RQ_NORMAL_LAP:
               T0203();
            return;

            case LC_REL_RQ_ABNORMAL_LAP:
               T0253();
            return;

            case LC_DIS_IN_MAC:
               T0202();
            return;

            #ifndef CONFIG_UPDATE_LINK_RELEASE
            case LC_DIS_CFM_MAC:
               T0200();
            return;
            #endif

            case LC_CO_DATA_IN_MAC:
               T0301();
            return;

            case LC_CO_DATA_RQ_LAP:  /*  IN LINE CODE T0403    */
            {
               /* TRANSITION:      T0403                                                */
               /* EVENT:           LC_CO_DATA_RQ_LAP                                    */
               /* DESCRIPTION:     Data Request from LAP-Process                        */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  FREE                                                 */
               /* END STATE:       OPEN                                                 */
               /* ----------------------------------------------------------------------*/
               FPTR temp;
               FPTR malloc_temp;
               /* A MAC connection is established  */
               /* and the flow control allows to   */
               /* transmit immediately the first   */
               /* Cs-Fragment.                     */
               Put_in_Queue( LC, CurrentInc, Make_Fill_Bytes_and_CRC( CurrentInc, G_PTR ));
               temp = Get_Next_Queue_Entry( LC, CurrentInc );
               if( temp != NULL )
               {
                  /* Set Transmit Control with next   */
                  /* DLC-Frame.                       */
                  temp = Set_Tx_Ctrl( CurrentInc, temp );
                  /* Invoke transmission of first     */
                  /* Cs-Fragment.                     */
                  malloc_temp = Mmu_Malloc(5);

                  #ifdef KLOCWORK
                  if(malloc_temp != NULL)
                  #endif
                  {
                     memset(malloc_temp, 0, 5);
                     memcpy(malloc_temp, temp, 5);

                     write_to_hmac_ioctl( HMAC, MAC_CO_DATA_RQ_LC,
                                          CurrentInc, 0, 0, 0,
                                          0, 5, malloc_temp, 0);
                     KNL_Transit( OPEN );

                  DECT_DEBUG_USER_LC_DATA("[LC] Data Out: %02x Data: %02x %02x %02x %02x %02x\n", 
                                          CurrentInc, temp[0], temp[1], temp[2], temp[3], temp[4]);
                  }
               }
            }
            return;

            case LC_DL_ENC_KEY_RQ_LAP:
               T0600();
            return;

            case LC_ENC_EKS_IND_MAC:
               T0602();
            return;

            default:
                break;
         }                             /* end of switch message            */
         break;
   }                                   /* end of switch state              */
   KNL_T0000();
}                                      /* end of DECODE_LC()               */
