/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V9.0       *
*                   (c) 2008 IFX / Peucon. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  testupagent.c                                           *
*     Date       :  September 2008                                          *
*     Contents   :  testapplication                                         *
*     Hardware   :  IFX 97xx                                                *
*                                                                           *
*     Description:                                                          *
*     This file is the main part of a test application that interfaces      *
*     the uplance fifos to an external application via TCP/IP               *
*     The software listens on port 9000 and relays incoming data to         *
*     the stack and forwards messages from the stack to the external        *
*     application.                                                          *
*                                                                           *
*     It is build as a separate application in the dect_stack environment   *
*     The build commands are integrated in the makefile                     *
*                                                                           *
*---------------------------------------------------------------------------*
* Change History:                                                           *
*                                                                           *
* Date         Author Description                                           *
* 20-Sep-2008  S.I.   Initial version                                       *
*****************************************************************************
*/

/** \file
 *  \brief Defines a simple test data agent.
 *
 *  Data is relayed from Uplane FIFO's via TCP to dummy agent running on PC-.
 */


#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
// #include <process.h>
#include "MESSAGE_DEF.H"
#include "uplane_if.h"

#define VERSION "0.2"
#define TUPORT 9000

#define RETURN(msg,x) {perror("FAILED " msg "\n");return x;}
#define SOCKADDR_IN struct sockaddr_in


x_IPC_UPlane_Msg upcMsg;


static void DumpMsg(const char *s,const x_IPC_UPlane_Msg *msg);
static void CheckIncoming(void);
static void HandleConnection(int client,SOCKADDR_IN *partner);


int msgSize=0;
unsigned short ourport=TUPORT;

int quiet=1;

int main(int ac, char**av)
{
  int i;
  int conn,client,addrlen;
  SOCKADDR_IN partner;
  printf("PEUCON U-Plane Dummy Agent" VERSION  "," __DATE__ "," __TIME__"\n");

  if(ac>1)
  {
    quiet=0;
  }

  if(quiet)
     printf("Running in quiet mode\n");


  if(!uplane_fifos_init())
    RETURN("uplane_fifos_init",-1);

  printf("fifos are initialized\n");

  conn=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
  if(conn<0)
     RETURN("Cant create socket",-1);

  partner.sin_family=AF_INET;
  partner.sin_addr.s_addr=INADDR_ANY;
  partner.sin_port=htons(ourport);
  if(0!=bind(conn,(struct sockaddr* )&partner,sizeof(struct sockaddr)))
     RETURN("Cant bind socket",-1);


	if(0!=listen(conn,1))
     RETURN("Cant listen on socket",-1);

  for(;;)
  {
    printf("\nwaiting for (next)client to connect...\n");
    memset(&partner,0,sizeof(partner));
    addrlen=sizeof(struct sockaddr);
    client=accept(conn,(struct sockaddr* )&partner,&addrlen);
    if(client<=0)
    {
//      printf("accept failed. rc=%d, partner : %s\n",client,inet_ntoa(partner.sin_addr));
      perror("accept failed\n");
      continue;
    }
    printf("Connected to %s\n",inet_ntoa(partner.sin_addr));
    HandleConnection(client,&partner);
    close(client);

  }

  return 0;
}



static void HandleConnection(int client,SOCKADDR_IN *partner)
{
  fd_set	set;
  int len,written;
  int nfds=client;
  int s2a=Get_UPlaneStackToAgent_FifoDescriptor();

  if(s2a>client) nfds=s2a;
  nfds++;


#if 0
  printf("s2a=%d client=%d,nfds=%d\n",s2a,client,nfds);
  written=Send_UPMessage_To_APP( 0x68, "123", 2,
                           0,  3,  0,  0);
  printf("Send dummy msg=%d\n",written);


#endif


  for(;;)
  {
    memset(&upcMsg,0,sizeof(upcMsg));
    memset(&set,0,sizeof(set));
    FD_ZERO(&set);
    FD_SET(client,&set);
    FD_SET(s2a,&set);
    
    if(select(nfds,&set,0,0,0)<=0)
    {
	    printf("Select failed\n");
	    break;
    }

    if(FD_ISSET(client,&set))
    {
      FD_CLR(client,&set);
      len=recv(client,(char*)&upcMsg,sizeof(upcMsg),0);
      if(len<=0)
      {
        printf("Connection terminated\n");
        break;
      }
      if(!quiet)
        DumpMsg("Agent->Stack",&upcMsg);
//      else
//        putchar('+');

      if(Send_UPMessage_To_Stack(&upcMsg))
      {
        if(!quiet)
          printf("Message was send to stack, totalsize=%d\n",len);
      }
      else
      {
        printf("Cant send msg to stack.\n");
        break;
      }
    }

    if(FD_ISSET(s2a,&set))
    {
      FD_CLR(s2a,&set);
      if(!quiet)
        printf("Try to receive data from DECT stack \n");
      if(Serve_UPMessage_App(&upcMsg))
      {
        if(!quiet)
          DumpMsg("Stack 2 Agent",&upcMsg);
//        else
//          putchar('-');

	      written=send(client,&upcMsg,sizeof(upcMsg),0);
	      if(written != sizeof(upcMsg))
        {
          printf("Failed to post message to client\n");
          break;
        }
        else
        {
          if(!quiet)
            printf("Message posted to client\n");
        }
    	}
      else
        printf("FIFO Readerror\n");
    }

  }

  printf("Leaving client handling\n");
}



static void DumpMsg(const char *s,const x_IPC_UPlane_Msg *msg)
{
  int i,len;
  len=(msg->ucPara1<<8)+msg->ucPara2;
  printf("%s Message: id: %d/0x%02x  inc:%d p1..4: %02x %02x %02x %02x dta: %02x %02x %02x %02x\n",
          s,
          msg->ucMsgId,msg->ucMsgId,msg->ucInstance,
          msg->ucPara1,
          msg->ucPara2,
          msg->ucPara3,
          msg->ucPara4 ,
          msg->acData[0],
          msg->acData[1],
          msg->acData[2],
          msg->acData[3]);
#if 0
  if(len)
  {
    printf("Data:");
    for(i=0;i<len;i++) 
    {
      if(((i & 0x0f)==0))
        printf("\n%03x:\t",i);
      printf("%02x ",msg->acData[i]);
    }
    putchar('\n');
  }
#endif
}

