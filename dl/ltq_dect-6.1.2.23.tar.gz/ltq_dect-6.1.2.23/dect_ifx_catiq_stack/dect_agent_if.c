#if 0 /*This full file is not required*/
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#include "SYSDEF.H"
#include "dect_agent_if.h"
#include "DECT.H"

#define FIFO_PERM 0644
#define READ_FROM_AGENT_FIFO "/tmp/DectAgentFifo"
#define WRITE_TO_AGENT_FIFO "/tmp/DectStackFifo"

int s_ReadFromAgentFifoFd;
static int s_WriteToAgentFifoFd;
//x_IFX_DECT_IPC_Msg from_agent_read_buf;
//x_IFX_DECT_IPC_Msg to_agent_write_buf;

void DectAgentIf_BufferInit(void)
{
  memset(&from_agent_read_buf,0x00, sizeof(x_IFX_DECT_IPC_Msg));
  memset(&to_agent_write_buf,0x00, sizeof(x_IFX_DECT_IPC_Msg));
}

/******************************************************************
 *  Function Name    : StackFifoInit
 *  Description      : This function creates a stack FIFO and opens it 
 *  Input Values     : None
 *  Output Values    : None
 *  Return Value     : SUCCESS/FAIL
 *  Notes            :
 ******************************************************************/
int DectAgentIf_FifoInit(void)
{
  int iRet = 0;

  if (access(READ_FROM_AGENT_FIFO, F_OK) == -1)
  {
    iRet = mkfifo(READ_FROM_AGENT_FIFO, FIFO_PERM);
    if (iRet < 0)
    {
      DECT_DEBUG_USER("make READ_FROM_AGENT_FIFO failed!!\n");
      return FALSE;
    }
  }
  s_ReadFromAgentFifoFd = open(READ_FROM_AGENT_FIFO,O_RDWR);
  if(s_ReadFromAgentFifoFd < 0)
  {
    DECT_DEBUG_USER("open READ_TO_AGENT_FIFO failed!!\n");
    return FALSE;
  }

  if (access(WRITE_TO_AGENT_FIFO, F_OK) == -1)
  {
    iRet = mkfifo(WRITE_TO_AGENT_FIFO, FIFO_PERM);
    if (iRet < 0)
    {
      DECT_DEBUG_USER("make WRITE_TO_AGENT_FIFO failed!!\n");
      return FALSE;
    }
  }
  s_WriteToAgentFifoFd = open(WRITE_TO_AGENT_FIFO,O_RDWR);
  if(s_WriteToAgentFifoFd < 0)
  {
    DECT_DEBUG_USER("open WRITE_TO_AGENT_FIFO failed!!\n");
    return FALSE;
  }
  return TRUE;
}

/******************************************************************
 *  Function Name    : DectAgentIf_FifoRead
 *  Description      : This function reads the contents from the 
 *  				 : Agent fifo -- shuld be called by the stack
 *  Input Values     : 
 *                   : buffer to be read in
 *                   : size of data to be read
 *  Output Values    : None
 *  Return Value     : Size of the actual data read,-1 if error,
 *                   : 0 if there is no furthur data to be read .
 *  Notes            :
 ******************************************************************/
int DectAgentIf_FifoRead(unsigned char *pcBuf,int iSize)
{
	return read(s_ReadFromAgentFifoFd, pcBuf, iSize);
}

/******************************************************************
 *  Function Name    : DectAgentIf_FifoWrite
 *  Description      : This function writes to a Agent fifo
 *  Input Values     : 
 *                   : data buffer to be written
 *                   : size of data to be written
 *  Output Values    : None
 *  Return Value     : Size of the actual data written, -1 if error
 *                   : 
 *  Notes            :
 ******************************************************************/
int DectAgentIf_FifoWrite(unsigned char *pcBuf,int iSize)
{
	return write(s_WriteToAgentFifoFd, pcBuf, iSize);
}

#endif  /*This full file is not required*/
