/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0       *
*                   (c) 2005 IFX / INTNIX. All rights reserved.                   *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  SYS_PARAMETER.C                                         *
*     Date       :  05 July, 2006                                           *
*     Contents   :  System parameters tables                                *
*     Hardware   :                                                          *
*                                                                           *
*****************************************************************************
*/
#include "SYSDEF.H"
#include "TYPEDEF.H"

#ifdef FT
CODE BYTE  RF_COUNTRY_PARAMETERS[] = {0x00, 0x00, 0x09}; 
CODE BYTE  OEM_CODE_PARAMETERS[] = {0x00, 0x00}; 

#ifdef ST8_EVA
   #ifdef JN_EVA
CODE BYTE  RFPI_PARAMETERS[] = {0x00, 0x12, 0x34, 0x56, 0x70};  // Identity(JN's, B11/C11, ULC board)
   #else
CODE BYTE  RFPI_PARAMETERS[] = {0x00, 0x12, 0x34, 0x56, 0x78};  // Identity(A31, JN's board)
  #endif
CODE BYTE  FT_OSCTRIM_PARAMETERS[] = {0x00, 0xAF}; // OSC trim value:P1(High),P2(Low) 
CODE BYTE  FT_GFSK_PARAMETERS[] = {0x30,0x00}; // GFSK value: only 1st byte(0x30) is valid
#elif defined(ULC_EVA)
CODE BYTE  RFPI_PARAMETERS[] = {0x00, 0x12, 0x34, 0x56, 0x88};  // Identity(B11/C11, ULC board)
CODE BYTE  FT_OSCTRIM_PARAMETERS[] = {0x04, 0x30}; // OSC trim value:P1(High),P2(Low) 
CODE BYTE  FT_GFSK_PARAMETERS[] = {0xCF,0x00}; //GFSK value::P1(Low),P2(High) => default is 0x00AF
#elif defined(COSIC)
CODE BYTE  RFPI_PARAMETERS[] = {0x00, 0x12, 0x34, 0x56, 0x88};  // Identity(B11/C11, ULC board)
CODE BYTE  FT_OSCTRIM_PARAMETERS[] = {0x04, 0x30}; // OSC trim value:P1(High),P2(Low) 
CODE BYTE  FT_GFSK_PARAMETERS[] = {0xAF,0x00}; //GFSK value::P1(Low),P2(High)
#else
CODE BYTE  RFPI_PARAMETERS[] = {0x00, 0x12, 0x34, 0x56, 0x90};  // Identity(A31, JN's board)
CODE BYTE  FT_OSCTRIM_PARAMETERS[] = {0x01, 0xF0}; // OSC trim value:P1(High),P2(Low) & GFSK value: p3
CODE BYTE  FT_GFSK_PARAMETERS[] = {0x30,0x00}; //GFSK value: only 1st byte(0x30) is valid
#endif
CODE BYTE  FT_DIAL_PARAMETERS[] =
/*
 ?T = ( LB_x + HB_x * 256 ) * 0.1ms ?
*/
{
   0x75,   /* 00 HOOK PAUSE TIME       = w3000, x * 10  */
   0x30, 
   0x4E,   /* 01 SHORT PAUSE TIME      = w2000, x * 10  */
   0x20,  
   0x01,    /* 02 PULSE MAKE TIME       = w33  , x * 10  */
   0x4A,  
   0x02,   /* 03 PULSE BREAK TIME      = w66  , x * 10 */
   0x94,  
   0x20,   /* 04 PULSE INTERDIGIT TIME = w840 , x * 10 */ 
   0xD0,  
   0x03,   /* 05 DTMF INTERDIGIT TIME  = w100 , x * 10 */  
   0x84,   
   0x03,   /* 06 DTMF TONE TIME        = w90  , x * 10 */   
   0x84,  
   0x03,   /* 07 DTMF STABILIZE TIME   = w100 , x * 10 */   
   0xE8,   
   0x03,   /* 08 SHORT FLASH1 TIME     = w98  , x * 10 */  
   0xD4,   
   0x0A,   /* 09 SHORT FLASH2 TIME     = w270 , x * 10 */   
   0x8C,   
   0x0E,   /* 10 SHORT FLASH3 TIME     = w380 , x * 10 */  
   0xD8,   
   0x00,   /* 11 CAS DURATION TIME     = w8   , x * 10   # equal & greater than 70ms CAS tone */   
   0x50,  
   0x02,   /* 12 DTMF D-TONE TIME      = w75 ,  x * 10 */   
   0xEE,  
   0x00,   /* 13 Reserved                    = w60  , 5000 / x */   
   0x00,  
   0xC3,  /* 14 MAX RING PAUSE        = w10000, x * 5     # 8s ---> 10s */
   0x50   
};

CODE BYTE   FT_RSSI_BMC_INFO_PARAMETERS[] =
{
            0x07,  /* 00 FT_RSSI_CHAN_MAP_QUIET  = b0x07  # -90dB: RSSI free */
            0x0E,  /* 01 FT_RSSI_CHAN_MAP_BUSY   = b0x0E  # -73dB: RSSI busy(b2) */
            0x14,  /* 02 FT_RSSI_DB_CHANGE_LIMIT = b0x14  # -55dB: RSSI for DB change limit  -55dB(0x14) */
            0x81,  /* 04 FT_BMC_DEFAULT_ANT        = b0x81*/  //# 0x-1  : Default diversity antenna( 1 or 0) 
                                                                                          //# 0x8- : Enable Dual scanning(  1: Dual scan, 0: Scan only the default Antenna)
                                                                                          //# 0x4- : Defeat Diversity ( 1: Defeat, 0: Active )
                                                                                          //# 0x2- : Antenna Diversity ( 1: Automatic-RSSI, 0: Manual-CRC )
                                                                                          //# 0x1- : Prolonged-preamble( 1: prolonged, 0: Normal )
            0x20,  /* 09 FT_BMC_WOPNSF                = b0x20  # Window Open Sync-Free mode/ # ; 30 < WOPNSF < 65 */
            0x08,  /* 10 FT_BMC_WWSF                   = b0x08  # Window Width Sync-Free mode/ # ; WOPNSF + 2*WWSF = 48*/
            0x00,  /* 05 FT_BMC_DRCON                  = b0x00  #  -----> Not used in COSIC  */
						0x03,
   0x04,  /* 16 FT_BMC_HO_FRAME         = b0x04  # Handover evaluation period */
   0xA4,  /* 17 FT_BMC_SYNCM_ACTIVE     = b0xA4  # 0xA8 -> 0xA5 -> 0xA4 */
            0x10,  /* 12 FT_BMC_CRRES                  = b0x10  #------> Not used in COSIC    */
            0x00,  /* 13 FT_BMC_NTP_ALGORITHM   = b0x00  # (0: Automatic, 1:User_mode_1,  2: User_mode_2 )------> New in COSIC*/
            0x03,  /* 14 FT_BMC_DVAL                   = b0x03  # PAON delay compensation -----> New in COSIC*/
            0x00,  /* 15 FT_BMC_NTP_OFFSET         = b0x00  # ( Temperature offset @NTP_ALGORITHM=0 & 1,  Direct PA biasing@NTP_ALGORITHM=2)  -----> New in COSIC  */
 
   0x77,  /* 18 FT_BMC_GENMUCON_0       = b0x73  # */
   0x11,  /* 19 FT_BMC_GENMUCON_1       = b0x11  # */
   0x77   /* 20 FT_BMC_EXTMUCON_0       = b0x77  # */
};   
#if 0
CODE BYTE   FT_RSSI_BMC_INFO_PARAMETERS[] =
{
            0x07,  /* 00 FT_RSSI_CHAN_MAP_QUIET  = b0x07  # -90dB: RSSI free */
            0x0E,  /* 01 FT_RSSI_CHAN_MAP_BUSY   = b0x0E  # -73dB: RSSI busy(b2) */
            0x14,  /* 02 FT_RSSI_DB_CHANGE_LIMIT = b0x14  # -55dB: RSSI for DB change limit  -55dB(0x14) */
            0x00,  /* 03 FT_BMC_ANTDIVHYST          = b0x00  # Antenna diversity hysterysis -> used in COSIC*/
            0x81,  /* 04 FT_BMC_DEFAULT_ANT        = b0x81*/  //# 0x-1  : Default diversity antenna( 1 or 0) 
                                                                                          //# 0x8- : Enable Dual scanning(  1: Dual scan, 0: Scan only the default Antenna)
                                                                                          //# 0x4- : Defeat Diversity ( 1: Defeat, 0: Active )
                                                                                          //# 0x2- : Antenna Diversity ( 1: Automatic-RSSI, 0: Manual-CRC )
                                                                                          //# 0x1- : Prolonged-preamble( 1: prolonged, 0: Normal )
            0x00,  /* 05 FT_BMC_DRCON                  = b0x00  #  -----> Not used in COSIC  */
            0x2E,  /* 06 FT_BMC_DSPFRMRES           = b0x2E  # DSP frame reset( 46(0x2E) )*/
            0x00,  /* 07 FT_BMC_MCTRL2                 = b0x00  # -----> Not used in COSIC */
            0x00,  /* 08 FT_BMC_CRUCON                = b0x00  # -----> Not used in COSIC  */
            0x20,  /* 09 FT_BMC_WOPNSF                = b0x20  # Window Open Sync-Free mode/ # ; 30 < WOPNSF < 65 */
            0x08,  /* 10 FT_BMC_WWSF                   = b0x08  # Window Width Sync-Free mode/ # ; WOPNSF + 2*WWSF = 48*/
            0x0E,  /* 11 FT_BMC_CRRSTART            = b0x0E  #------> Not used in COSIC    */
            0x10,  /* 12 FT_BMC_CRRES                  = b0x10  #------> Not used in COSIC    */
            0x00,  /* 13 FT_BMC_NTP_ALGORITHM   = b0x00  # (0: Automatic, 1:User_mode_1,  2: User_mode_2 )------> New in COSIC*/
            0x03,  /* 14 FT_BMC_DVAL                   = b0x03  # PAON delay compensation -----> New in COSIC*/
            0x00,  /* 15 FT_BMC_NTP_OFFSET         = b0x00  # ( Temperature offset @NTP_ALGORITHM=0 & 1,  Direct PA biasing@NTP_ALGORITHM=2)  -----> New in COSIC  */
 
   0x04,  /* 16 FT_BMC_HO_FRAME         = b0x04  # Handover evaluation period */
   0xA4,  /* 17 FT_BMC_SYNCM_ACTIVE     = b0xA4  # 0xA8 -> 0xA5 -> 0xA4 */
   0x77,  /* 18 FT_BMC_GENMUCON_0       = b0x73  # */
   0x11,  /* 19 FT_BMC_GENMUCON_1       = b0x11  # */
   0x77   /* 20 FT_BMC_EXTMUCON_0       = b0x77  # */
};   
#endif
CODE BYTE   FT_DSP_DAC_INFO_PARAMETERS[] =
{
   0x10,  /* 00 FT_BG_TONE          = b0x10 ## BG Tone Level    */
   0x10,  /* 01 FT_DSP_BEEP_VOL     = b0x09 ## DAC Beep Volume, */
   0x40,  /* 02 FT_DSP_RINGER1      = b0x01 ## Volume 1*/
   0x30,  /* 03 FT_DSP_RINGER2      = b0x03 ## Volume 2*/
   0x20,  /* 04 FT_DSP_RINGER3      = b0x06 ## volume 3*/
   0x10,  /* 05 FT_DSP_RINGER4      = b0x0E ## volume 4*/
   0x00,  /* 06 FT_DSP_RINGER5      = b0x7F ## volume 5*/
   0x06,  /* 07 FT_DAC_MIC             = b0x04 ## AFEIC = 0/0/6/12/18/24/30/36 dB*/
   0x03,  /* 08 FT_DAC_ADA             = b0x00 ## AFEOC =-18/-18/-12/-6/+0 dB*/
   0x0C,  /* 09 FT_DAC_MPCCTR       = b0x0C ## n.u */
   0x00,  /* 10 FT_DAC_MPCMV        = b0x00 ##  n.u */
   0x2B,  /* 11 FT_DSP_GX1_HB       = b0x2B ## */
   0x15,  /* 12 FT_DSP_GX1_LB       = b0x15 ## 3.01dB -> 0.11*/
   0x1B,  /* 13 FT_DSP_GX2_HB       = b0x1B ## */
   0xCB,  /* 14 FT_DSP_GX2_LB       = b0xCB ## 1.68(33A1)->-1.42(2A23)->2.43(1BCB) */
   0x1B,  /* 15 FT_DSP_GR1_HB       = b0x1B ## */
   0x30,  /* 16 FT_DSP_GR1_LB       = b0x30 ## 6.31(1215)->5.14(21BB)->2.05(1B30) */
   0x11,  /* 17 FT_DSP_GR2_HB       = b0x11 ## */
   0xBD,  /* 18 FT_DSP_GR2_LB       = b0xBD ## 9.13dB(10C1)--->7.24dB(11,43) -->6.69 */
   0x21,  /* 19 FT_DSP_DCON1H       = b0x21 ## EF2(0x40) FX(0x20) ADS2(0x08) ES(0x01) */
   0x82,  /* 20 FT_DSP_DCON1L       = b0x82 ## EC(0x80) DHPX(0x20) DHPR(0x10) GOR(0x02) */
   0x41,  /* 21 FT_DSP_DCON2H       = b0x40 ## BS(0x40) ALW1(0x10) AEN(0x01) */
   0x80,  /* 22 FT_DSP_DCON2L       = b0x80 ## ABR(0x80) EF1(0x10) ADS1(0x02) DTP(0x01) */
   0x40,  /* 23 FT_DSP_DCON3H       = b0x40 ## GOX(0x40) AL1D(0x04) AL1E(0x01) */
   0x00,  /* 24 FT_DSP_DCON3L       = b0x00 ## CDM(0x40) CDD(0x20) FXR(0x02) FXX(0x01) */
   0x80,  /* 25 FT_DSP_DCON4H       = b0x80 ## CDMD(0x80) M12(0x08) */
   0x00,  /* 26 FT_DSP_DCON4L       = b0x00 ## ALW2(0x80) AL2D(0x08) AL2E(0x02) */
   0x00,  /* 27 FT_DSP_DCON5H       = b0x00 ## ACF(0x80) */
   0x00,  /* 28 FT_DSP_DCON5L       = b0x00 ## */
   0x06,  /* 29 FT_DSP_CID_MIC      = b0x03 ##  0/0/6/12/18/24/30/36 dB*/
   0x00,  /* 30 FT_DSP_CID_GR2_HB   = b0x00 ## CID GR2: Max(18dB)*/
   0x00,  /* 31 FT_DSP_CID_GR2_LB   = b0x00 ## */
   0x00   /* 32 FT_DSP_CID_RESERVE = b0x00 ## */
};

CODE BYTE   FT_DSP_BLOCK_1_PARAMETERS[] =
{
// Len : 48
   0x00,     /* 00 FT_DSP_36_HB  A2   */
   0x00,     /* 01 FT_DSP_36_LB  A1   */
   0x00,     /* 02 FT_DSP_37_HB  K	   */
   0x00,     /* 03 FT_DSP_37_LB  GE   */
   0x00,     /* 04 FT_DSP_38_HB  --   */
   0x00,     /* 05 FT_DSP_38_LB  GTR  */ 
   0x9B,     /* 06 FT_DSP_52_HB  GD1  */
   0xAB,     /* 07 FT_DSP_52_LB  GD2  */
   0x23,     /* 08 FT_DSP_53_HB  GDR  */
   0x13,     /* 09 FT_DSP_53_LB  GDX  */
   0x00,     /* 10 FT_DSP_54_HB  FO_T */
   0x00,     /* 11 FT_DSP_54_LB  AEL  */ 
   0x10,     /* 12 FT_DSP_55_HB  FO_B */
   0x7A,     /* 13 FT_DSP_55_LB  FI_B */
   0x00,     /* 14 FT_DSP_56_HB  EF_A */
   0x10,     /* 15 FT_DSP_56_LB  FI_A */
   0x10,     /* 16 FT_DSP_57_HB  GB   */
   0x02,     /* 17 FT_DSP_57_LB  LPP  */
   0x12,     /* 18 FT_DSP_58_HB  U    */
   0x08,     /* 19 FT_DSP_58_LB  FBA  */
   0x18,     /* 20 FT_DSP_59_HB  LIM_NM       */
   0x0C,     /* 21 FT_DSP_59_LB  TIM_NM       */
   0xF8,     /* 22 FT_DSP_60_HB  DEL_PX       */
   0x20,     /* 23 FT_DSP_60_LB  LIM_PX       */
   0x00,     /* 24 FT_DSP_61_HB  --  */
   0x7F,     /* 25 FT_DSP_61_LB  LIM_PR       */
   0x41,     /* 26 FT_DSP_62_HB  LPQ          */
   0x30,     /* 27 FT_DSP_62_LB  LPDQ         */
   0x04,     /* 28 FT_DSP_63_HB  DELQ         */
   0x00,     /* 29 FT_DSP_63_LB  LIMLQ        */
   0x02,     /* 30 FT_DSP_64_HB  LIMQ         */
   0x0C,     /* 31 FT_DSP_64_LB  TIMQ         */
   0x10,     /* 32 FT_DSP_65_HB  LIM_LP2      */
   0x3E,     /* 33 FT_DSP_65_LB  LIM_SD       */
   0x20,     /* 34 FT_DSP_66_HB  LP1          */
   0x0B,     /* 35 FT_DSP_66_LB  OFFSET       */ 
   0x51,     /* 36 FT_DSP_67_HB  LP2N         */ 
   0x3F,     /* 37 FT_DSP_67_LB  PKDN         */
   0x20,     /* 38 FT_DSP_68_HB  LP2S         */
   0x60,     /* 39 FT_DSP_68_LB  PKDS         */
   0x28,     /* 40 FT_DSP_69_HB  ATT_ES       */
   0x02,     /* 41 FT_DSP_69_LB  ECHOT        */
   0x0B,     /* 42 FT_DSP_70_HB  TIM_AT       */
   0x41,     /* 43 FT_DSP_70_LB  TIMO         */
   0x50,     /* 44 FT_DSP_71_HB  LPS          */
   0x30,     /* 45 FT_DSP_71_LB  LIM_DS       */
   0x30,     /* 46 FT_DSP_81_HB  LIM_HR       */
   0x18      /* 47 FT_DSP_81_LB  LIM_LR       */
};

CODE BYTE   FT_DSP_BLOCK_2_PARAMETERS[] =
{
// Len : 48
   0x68,     /* 00 FT_DSP_82_HB  LPOR/TIMOVR  */
   0x20,     /* 01 FT_DSP_82_LB  GOR          */
   0xFA,     /* 02 FT_DSP_83_HB  FX_K         */
   0x23,     /* 03 FT_DSP_83_LB  FX_A         */
   0x34,     /* 04 FT_DSP_84_HB  LIM_HX       */  
   0x1A,     /* 05 FT_DSP_84_LB  LIM_LX       */
   0x50,     /* 06 FT_DSP_85_HB  LPOX/TIMOVX  */
   0x20,     /* 07 FT_DSP_85_LB  GOX          */ 
   0x00,     /* 08 FT_DSP_86_HB  ---          */
   0x00,     /* 09 FT_DSP_86_LB  GCN          */
   0x40,     /* 10 FT_DSP_87_HB  LIM_SP       */
   0x40,     /* 11 FT_DSP_87_LB  LIM_ID       */
   0x00,     /* 12 FT_DSP_90_HB  ---          */
   0x1A,     /* 13 FT_DSP_90_LB  ATD_LEV      */ 
   0xE8,     /* 14 FT_DSP_91_HB  ATD_F1P      */
   0xFE,     /* 15 FT_DSP_91_LB  ATD_F1M      */
   0xB0,     /* 16 FT_DSP_92_HB  ATD_F2P      */
   0xC2,     /* 17 FT_DSP_92_LB  ATD_F2M      */
   0xA1,     /* 18 FT_DSP_93_HB  ATD_ATWF2    */
   0x9B,     /* 19 FT_DSP_93_LB  ATD_ATWF1    */
            0xCB,     /* 20 FT_DSP_94_HB  CFT          */
            0x32,     /* 21 FT_DSP_94_LB  CFT          */
   0x8B,     /* 22 FT_DSP_95_HB  BWT1         */
   0xBD,     /* 23 FT_DSP_95_LB  BWT1         */
   0x8B,     /* 24 FT_DSP_96_HB  BWT2         */
   0xBD,     /* 25 FT_DSP_96_LB  BWT2         */
   0x52,     /* 26 FT_DSP_97_HB  LPTF_1/2     */ 
   0x10,     /* 27 FT_DSP_97_LB  LIM_T        */
   0x16,     /* 28 FT_DSP_98_HB  TIM_BT       */ 
   0x03,     /* 29 FT_DSP_98_LB  TIM_T        */
   0x08,     /* 30 FT_DSP_99_HB  DEL_T        */
   0x4D,     /* 31 FT_DSP_99_LB  LEV_T        */
   0x7F,     /* 32 FT_DSP_100_HB LEV_P        */
   0x03,     /* 33 FT_DSP_100_LB TIM_P        */ 
   0x42,     /* 34 FT_DSP_101_HB DPOW         */ 
   0x0D,     /* 35 FT_DSP_101_LB DTWIST       */
   0x0D,     /* 36 FT_DSP_102_HB DPHB         */
   0x14,     /* 37 FT_DSP_102_LB DTIMP        */
   0x13,     /* 38 FT_DSP_103_HB DPGB         */
   0x07,     /* 39 FT_DSP_103_LB DHYST        */
   0x1A,     /* 40 FT_DSP_104_HB DTSIG        */
   0x23,     /* 41 FT_DSP_104_LB DTPAUSE      */
   0x00,     /* 42 FT_DSP_105_HB ---          */
   0x04,     /* 43 FT_DSP_105_LB DTBRAK       */
   0x04,     /* 44 FT_DSP_106_LB CID_LEV      */
   0xF8,     /* 45 FT_DSP_106_LB CID_LEV      */   // before: 0x0068
   0x00,     /* 46 FT_DSP_107_HB CID_SEIZ     */
   0x48      /* 47 FT_DSP_107_LB CID_SEIZ     */
};

CODE BYTE   FT_DSP_BLOCK_3_PARAMETERS[] =
{
// Len : 48
   0x00,     /* FT_DSP_108_HB CID_MARK     */
   0x20,     /* FT_DSP_108_LB CID_MARK     */
   0x00,     /* FT_DSP_109_HB MTYPB2       */ 
   0x00,     /* FT_DSP_109_LB MTYPB1       */
   0x00,     /* FT_DSP_110_HB MTYPB4       */ 
   0x00,     /* FT_DSP_110_LB MTYPB3       */
   0x00,     /* FT_DSP_111_HB MTYPB6	      */
   0x00,     /* FT_DSP_111_LB MTYPB5	      */
   0x00,     /* FT_DSP_112_HB MTYPB8	      */
   0x00,     /* FT_DSP_112_LB MTYPB7	      */
   0x00,     /* FT_DSP_113_HB CID_STOP     */
   0x0A,     /* FT_DSP_113_LB CID_STOP     */
   0x00,     /* FT_DSP_114_HB CIDS_SEIZ    */
   0x01,     /* FT_DSP_114_LB CIDS_SEIZ    */
   0x00,     /* FT_DSP_115_HB CIDS_MARK    */
   0x50,     /* FT_DSP_115_LB CIDS_MARK    */
   0x3D,     /* FT_DSP_116_HB GCID         */
   0x01,     /* FT_DSP_116_LB CIDS_STOP    */
   0x7A,     /* FT_DSP_117_HB RHYSTH       */
   0x7E,     /* FT_DSP_117_LB RONLEV       */
   0x86,     /* FT_DSP_118_HB RHYSTL       */
   0x79,     /* FT_DSP_118_LB ROFFLEV      */
   0x00,     /* FT_DSP_119_HB RCNTMIN      */
   0xB3,     /* FT_DSP_119_LB RCNTMIN      */
   0x03,     /* FT_DSP_120_HB RCNTMAX      */
   0x3B,     /* FT_DSP_120_LB RCNTMAX      */
   0x32,     /* FT_DSP_121_HB RMAXTIM          */
   0x24,     /* FT_DSP_121_LB RNODER/RNODENO   */
   0x20,     /* FT_DSP_122_HB MPLEVS           */
   0x1C,     /* FT_DSP_122_LB MPLEVE           */
   0x16,     /* FT_DSP_123_HB MPTIMSMIN	       */
   0x16,     /* FT_DSP_123_LB MPTIMSMAX	       */
   0x00,     /* FT_DSP_124_HB MPTIMP		   */
   0x1C,     /* FT_DSP_124_LB LPMF             */
   0x00,     /* FT_DSP_125_HB ---		       */
   0x00,     /* FT_DSP_125_LB MPTIMB		   */
   0x88,     /* FT_DSP_126_HB SKX1/SA2X1	   */
   0x21,     /* FT_DSP_126_LB A2X1_1/A2X1_0    */
   0x80,     /* FT_DSP_127_HB SKR1/SA2R1	   */
   0x77,     /* FT_DSP_127_LB A2R1_1/A2R1_0    */
   0x08,     /* FT_DSP_128_HB SKX2/SA1X1	   */
   0x21,     /* FT_DSP_128_LB A1X1_1/A1X1_0    */
   0x80,     /* FT_DSP_129_HB SKR2/SA1R1	   */
   0x3C,     /* FT_DSP_129_LB A1R1_1/A1R1_0    */
   0x7F,     /* FT_DSP_130_HB KX2_1/KX2_0      */
   0x21,     /* FT_DSP_130_LB KX1_1/KX1_0      */
   0xE3,     /* FT_DSP_131_HB KR2_1/KR2_0      */
   0x0D      /* FT_DSP_131_LB KR1_1/KR1_0      */
};

CODE BYTE   FT_DSP_BLOCK_4_PARAMETERS[] =
{
// Len : 48
   0x00,    /* FT_DSP_132_HB SKX3/SA2X2	   */
   0x7F,    /* FT_DSP_132_LB A2X2_1/A2X2_0    */
   0x80,    /* FT_DSP_133_HB SKR3/SA2R2	   */
   0x21,    /* FT_DSP_133_LB A2R2_1/A2R2_0    */
   0x80,    /* FT_DSP_134_HB SA1X3/SA1X2      */
   0x7F,    /* FT_DSP_134_LB A1X2_1/A1X2_0    */
   0x80,    /* FT_DSP_135_HB SA1R3/SA1R2	*/
   0x94,    /* FT_DSP_135_LB A1R2_1/A1R2_0	*/
   0x7F,    /* FT_DSP_136_HB KX3_1/KX3_0	*/
   0x21,    /* FT_DSP_136_LB A1X3_1/A1X3_0	*/
   0xA1,    /* FT_DSP_137_HB KR3_1/KR3_0	*/
   0x55,    /* FT_DSP_137_LB A1R3_1/A1R3_0	*/
   0x00,    /* FT_DSP_171_HB FX2_K_1/FX2_K_0*/
   0x00,    /* FT_DSP_171_LB FX2_A_1/FX2_A_0*/
   0x00,    /* FT_DSP_172_HB GX12_3/GX12_2	*/
   0x00,    /* FT_DSP_172_LB GX12_1/GX12_0	*/
   0x00,    /* FT_DSP_173_HB GR22_3/GR22_2	*/
   0x00,    /* FT_DSP_173_LB GR22_1/GR22_0	*/
   0x00,    /* FT_DSP_174_HB --				*/
   0x00,    /* FT_DSP_174_LB AEL2			*/
   0x00,    /* FT_DSP_175_HB LIM_HIGHR2		*/
   0x00,    /* FT_DSP_175_LB LIM_LOWR2		*/
   0x00,    /* FT_DSP_176_HB LPOR2_0/TIM_OVR2  */
   0x00,    /* FT_DSP_176_LB GOR2_1/GOR2_0 	*/
   0x00,    /* FT_DSP_720_HB RDT_LEV_PD     */
   0x00,    /* FT_DSP_720_LB RDT_TIM_PD		*/
   0x00,    /* FT_DSP_721_HB RDTRG          */
   0x00,    /* FT_DSP_721_LB RDTRG			*/
   0x00,    /* FT_DSP_722_HB RDTRD          */
   0x00,    /* FT_DSP_722_LB RDTRD          */
   0x00,    /* FT_DSP_723_HB RDTDLY         */
   0x00,    /* FT_DSP_723_LB RDTDLY			*/
   0x00,    /* FT_DSP_724_HB RBWT           */
   0x00,    /* FT_DSP_724_LB RBWT           */
   0x00,    /* FT_DSP_725_HB RLPTF          */
   0x00,    /* FT_DSP_725_LB RLIM_T         */
   0x00,    /* FT_DSP_726_HB RTIM_BT        */
   0x00,    /* FT_DSP_726_LB RTIM_T         */
   0x00,    /* FT_DSP_727_HB RDEL_T         */
   0x00,    /* FT_DSP_727_LB RLEV_T         */
   0x00,    /* FT_DSP_728_HB RDEL_C         */
   0x00,    /* FT_DSP_728_LB RTIM_E         */
   0x00,    /* FT_DSP_729_HB RDTF1          */
   0x00,    /* FT_DSP_729_LB RDTF1          */
   0x00,    /* FT_DSP_730_HB RDTF2          */
   0x00,    /* FT_DSP_730_LB RDTF2          */
   0x00,    /* FT_DSP_731_HB RDTF3          */
   0x00     /* FT_DSP_731_LB RDTF3          */
};

CODE BYTE   FT_DSP_BLOCK_5_PARAMETERS[] =
{
   0x00,    /* 00 FT_DSP_732_HB RDTF4          */
   0x00,    /* 01 FT_DSP_732_LB RDTF4          */
   0x00,    /* 02 FT_DSP_733_HB RDTF5          */
   0x00,    /* 03 FT_DSP_733_LB RDTF5          */
   0x00,    /* 04 FT_DSP_734_HB RDTF6          */
   0x00,    /* 05 FT_DSP_734_LB RDTF6          */
   0x00,    /* 06 FT_DSP_735_HB RLEV_R         */
   0x00,    /* 07 FT_DSP_735_LB RLEV_R      */
#ifdef COSIC   
   0x00,    /* 08 FT_DSP_736_HB = b0x00   ##  ANS_CTRL */
   0x00,    /* 09 FT_DSP_736_LB = b0x00   ##  */
   0x00,    /* 10 FT_DSP_737_HB = b0x00   ##  ALPHASET */
   0x00,    /* 11 FT_DSP_737_LB = b0x00   ##  */
   0x00,    /* 12 FT_DSP_738_HB = b0x00   ##  VDEL */
   0x00,    /* 13 FT_DSP_738_LB = b0x00   ##  */
   0x00,    /* 14 FT_DSP_934_HB = b0x00   ##  LIM_LP2_2 */
   0x00,    /* 15 FT_DSP_934_LB = b0x00   ##  LIM_SD_2 */
   0x00,    /* 16 FT_DSP_935_HB = b0x00   ##  LP1_2 */
   0x00,    /* 17 FT_DSP_935_LB = b0x00   ##  OFFSET */
   0x00,    /* 18 FT_DSP_936_HB = b0x00   ##  LP2N_2 */
   0x00,    /* 19 FT_DSP_936_LB = b0x00   ##  PKDN_2 */
   0x00,    /* 20 FT_DSP_937_LB = b0x00   ##  LP2S_2 */
   0x00,    /* 21 FT_DSP_937_LB = b0x00   ##  PKDS_2 */
#endif   
};

#endif

