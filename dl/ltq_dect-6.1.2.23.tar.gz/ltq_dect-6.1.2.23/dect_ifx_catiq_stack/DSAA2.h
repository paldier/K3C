/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0       *
*                   (c) 2005 IFX / INTNIX. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  DSAA2.H                                                 *
*     Date       :  28 Mar, 2013                                            *
*     Contents   :  Contents : Global function declaration for 'DSAA2.C'    *
*     Hardware   :  IFX 87xx                                                *
*                                                                           *
*****************************************************************************
*/
#ifndef _INC_DSAA2
#define _INC_DSAA2

#ifdef ULE_SUPPORT
#define N_ROW                   4
#define N_COL                   4
#define N_BLOCK   (N_ROW * N_COL)
#define N_MAX_ROUNDS           14

//#define EXIT_SUCCESS   1
//#define EXIT_FAILURE   0

typedef struct {
   unsigned char ksch[(N_MAX_ROUNDS + 1) * N_BLOCK];
   unsigned char rnd;
} aes_context;

   /* ============================                                         */
   /* Global function decalaration                                         */
   /* ============================                                         */

unsigned char aes_set_key( unsigned char *key,unsigned char keylen,aes_context ctx[1] );
unsigned char aes_encrypt( unsigned char *in,unsigned char *out,aes_context ctx[1] );
void Dsaa2_1(unsigned char * d1, unsigned char * d2, unsigned char * d3, unsigned char * e);
void Dsaa2_2( unsigned char *d1, unsigned char *d2, unsigned char *d3, unsigned char * e1, unsigned char * e2 );
#endif
#endif

