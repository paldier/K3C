/* -- SIEMENS AG  PCT -- Process: MM          -  Thu Nov 22 12:46:21 2007 -- */
#include "DEFINE.H"
#include <stdio.h>
# include "SYSDEF.H"
# include "FDEF.H"
# include "TYPEDEF.H"

extern BYTE Subscription_GetRegistrationData( BYTE portableNo, FPTR pucSusbInfo );
extern void get_enc_state_from_hmac_ioctl(BYTE * data);
#ifdef CONFIG_REPEATER_SUPPORT
extern void get_rep_pmid_from_hmac_ioctl(BYTE * data);
extern void get_rep_num_from_hmac_ioctl(BYTE * data);
#endif
extern unsigned int IFX_DECT_DecodeTermCap(unsigned char ucHandset, unsigned char *ucGPTR);
extern void Subscription_SetTerminalCapability(uint32 uiTermCap, BYTE po_no);
extern void KNL_T0000(void);
# include "SYSEXT.H"

/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0       *
*                   (c) 2005 IFX / INTNIX. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  FMM.PSL                                                 *
*     Date       :  18 Nov, 2005                                            *
*     Contents   :                                                          *
*     Hardware   :  IFX 87xx                                                *
*                                                                           *
*****************************************************************************
*/

/* =======================================================================
 * Include Files
 * ======================================================================= */
#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#include "FGLOBAL.H"
#include "PCT_DEF.H"
#include "KNL_SYSTEM.H"
#include "MMU.H"
#include "P_TIM.H"
#include "CC_DEF.H"
#include "CC_LIB.H"
#include "LCE_LIB.H"

#include "MM_LIB.H"

//#include "DSP.H"

#include "CP_SERVER.H"
#include "MESSAGE_DEF.H"
#include "CP_server_lib.h"

#include "FMM.H"
#include "SYSINIT.H"

/* =======================================================================
 * External Reference
 * ======================================================================= */
IMPORT FPTR Get_Locate_Proprietary( BYTE po_no );
IMPORT BIT Check_Reg_Mode( void );
IMPORT void Clear_Reg_Mode( BYTE, BYTE );
IMPORT void Set_Reg_Mode_Ongoing( void );

/* =======================================================================
 * Definitions
 * ======================================================================= */
// #define CLEAN_A44_MODE

#define MAX_TERMINAL_CAPABILITY_IE_SIZE 23

#ifdef GIGASET_ETP
#define MAX_GIGASET_ETP_SIZE  30
#endif

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */
typedef struct MM_TABLE_ELEMENT {
   BYTE IPUI_Array [ 5        ];
   BYTE K_Array    [ K_LEN    ];
   #ifdef ULE_SUPPORT
   BYTE RS_Array   [ RS2_LEN  ];
   #else
   BYTE RS_Array   [ RS_LEN   ];
   #endif
   BYTE RAND_Array [ RAND_LEN ];
   BYTE KS_Array   [ KS_LEN   ];
   BYTE RES_Array  [ RES_LEN  ];
   #ifdef ULE_SUPPORT
   BYTE DCK_Array  [ DCK2_LEN ]; // for encryption and making default cipher key
   #else
   BYTE DCK_Array  [ DCK_LEN  ];
   #endif
   #ifdef CONFIG_EARLY_ENCRYPTION
   BOOL makingDefaultCipherKey;
   WORD defaultCipherKeyIndex;
   #endif
   #ifdef ULE_SUPPORT
   BYTE supportsDsaa2;
   BOOL makingDCKCCM;
   #endif
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   BYTE DeviceType;
   #endif
   #ifdef CONFIG_REPEATER_SUPPORT
   BYTE Repeater_Num;
   BYTE Repeater_Idx;
   BYTE Rep_PoNo;
   BYTE Rep_Lbn;
   #endif

   #ifdef GIGASET_ETP
   BYTE ETP_Array[ MAX_GIGASET_ETP_SIZE ];
   #endif
   BYTE Model_Id;
   BYTE EMC_Array [2];
   BYTE Return_Proc;
   BYTE Return_Msg;
   BYTE Return_Inc;
   BYTE Starting_State;
   BYTE Last_State;
} MM_TABLE_ELEMENT;

#ifdef DECT_DEBUG_USER_MM_PRIMITIVE
typedef struct {
   BYTE key;
   char *string;
} DebugStringTable_t;
#endif

/* =======================================================================
 * Local Variables
 * ======================================================================= */
LOCAL XDATA MM_TABLE_ELEMENT MM_Struct[ MAX_LINK ];  // 426 bytes(71 * 6hs)

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
LOCAL XDATA BYTE First_Codec[ MAX_PORTABLE ];
LOCAL XDATA BYTE Second_Codec[ MAX_PORTABLE ];
LOCAL XDATA BYTE Third_Codec[ MAX_PORTABLE ];
LOCAL XDATA BYTE Terminal_Cap[ MAX_PORTABLE ];
#else
XDATA BYTE First_Codec[ MAX_PORTABLE ];
XDATA BYTE Second_Codec[ MAX_PORTABLE ];
XDATA BYTE Third_Codec[ MAX_PORTABLE ];
XDATA BYTE Terminal_Cap[ MAX_PORTABLE ];
#endif

#ifdef CONFIG_REPEATER_SUPPORT
LOCAL XDATA BYTE  PmidBuff[5];
LOCAL XDATA BYTE  Repeater_Reg = REPEATER_REGISTRATION_STATE_IDLE;
LOCAL XDATA BYTE  Repeater_PoNo = 0xFF;
#endif

#ifdef CLEAN_A44_MODE
LOCAL BYTE Register_Cnt = 0;
#endif

#ifdef DECT_DEBUG_USER_MM_PRIMITIVE
LOCAL DebugStringTable_t stateStringTable[] = {
   {MM_OPEN, "MM_OPEN"},
   {MM_AUTH_OF_PT, "MM_AUTH_OF_PT"},
   {MM_AUTH_OF_USER, "MM_AUTH_OF_USER"},
   {MM_KEY_ALLOCATION, "MM_KEY_ALLOCATION"},
   {MM_OBTAIN_ACCESS_RIGHTS, "MM_OBTAIN_ACCESS_RIGHTS"},
   {MM_TERMINATING_ACCESS_RIGHTS, "MM_TERMINATING_ACCESS_RIGHTS"},
   {MM_LOCATION_REGISTRATION, "MM_LOCATION_REGISTRATION"},
   {MM_LOCATION_ACK_WAIT, "MM_LOCATION_ACK_WAIT"},
   {MM_LOCATION_UPDATE, "MM_LOCATION_UPDATE"},
   {MM_CIPHER_ON, "MM_CIPHER_ON"},
   {MM_CIPHER_OFF, "MM_CIPHER_OFF"},
   {MM_IDENTITY, "MM_IDENTITY"},
   {0xFF, "Unknown State"}
};

LOCAL DebugStringTable_t messageStringTable[] = {
   {MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ, "MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ"},
   {MM_MMS_AUTHENTICATE_PT_RQ, "MM_MMS_AUTHENTICATE_PT_RQ"},
   {MM_MMS_AUTHENTICATE_USER_RQ, "MM_MMS_AUTHENTICATE_USER_RQ"},
   {MM_MMS_KEY_ALLOCATION_RQ, "MM_MMS_KEY_ALLOCATION_RQ"},
   {MM_MMS_INFO_SUGGEST_RQ, "MM_MMS_INFO_SUGGEST_RQ"},
   {MM_MMS_CIPHER_ON_RQ, "MM_MMS_CIPHER_ON_RQ"},
   {MM_MMS_CIPHER_OFF_RQ, "MM_MMS_CIPHER_OFF_RQ"},
   {MM_MMS_IDENTITY_RQ, "MM_MMS_IDENTITY_RQ"},
   {MM_ACCESS_RIGHTS_REQUEST_LCE, "MM_ACCESS_RIGHTS_REQUEST_LCE"},
   {MM_ACCESS_RIGHTS_TERMINATE_REQUEST_LCE, "MM_ACCESS_RIGHTS_TERMINATE_REQUEST_LCE"},
   {MM_LOCATE_REQUEST_LCE, "MM_LOCATE_REQUEST_LCE"},
   {MM_CIPHER_SUGGEST_LCE, "MM_CIPHER_SUGGEST_LCE"},
   {MM_AUTH_REQUEST_LCE, "MM_AUTH_REQUEST_LCE"},
   {MM_AUTHENTICATE_PT_CFM, "MM_AUTHENTICATE_PT_CFM"},
   {MM_AUTHENTICATE_USER_CFM, "MM_AUTHENTICATE_USER_CFM"},
   {MM_KEY_ALLOCATION_CFM, "MM_KEY_ALLOCATION_CFM"},
   {MM_AUTHENTICATE_PT_RQ, "MM_AUTHENTICATE_PT_RQ"},
   {MM_AUTH_REPLY_LCE, "MM_AUTH_REPLY_LCE"},
   {MM_AUTH_REJECT_LCE, "MM_AUTH_REJECT_LCE"},
   {MM_TIM_AUTH_01_EXPIRED, "MM_TIM_AUTH_01_EXPIRED"},
   {MM_DL_REL_IN_LCE, "MM_DL_REL_IN_LCE"},
   {MM_AUTHENTICATE_USER_RQ, "MM_AUTHENTICATE_USER_RQ"},
   {MM_TIM_AUTH_02_EXPIRED, "MM_TIM_AUTH_02_EXPIRED"},
   {MM_KEY_ALLOCATION_RQ, "MM_KEY_ALLOCATION_RQ"},
   {MM_TIM_KEY_01_EXPIRED, "MM_TIM_KEY_01_EXPIRED"},
   {MM_TIM_LOCATE_01_EXPIRED, "MM_TIM_LOCATE_01_EXPIRED"},
   {MM_ACCESS_RIGHTS_TERMINATE_ACCEPT_LCE, "MM_ACCESS_RIGHTS_TERMINATE_ACCEPT_LCE"},
   {MM_ACCESS_RIGHTS_TERMINATE_REJECT_LCE, "MM_ACCESS_RIGHTS_TERMINATE_REJECT_LCE"},
   {MM_TIM_ACCESS_02_EXPIRED, "MM_TIM_ACCESS_02_EXPIRED"},
   {MM_TEMPORARY_IDENTITY_ASSIGN_ACK_LCE, "MM_TEMPORARY_IDENTITY_ASSIGN_ACK_LCE"},
   {MM_TEMPORARY_IDENTITY_ASSIGN_REJ_LCE, "MM_TEMPORARY_IDENTITY_ASSIGN_REJ_LCE"},
   {MM_TIM_IDENTITY_01_EXPIRED, "MM_TIM_IDENTITY_01_EXPIRED"},
   {MM_DL_ENC_IND_LCE, "MM_DL_ENC_IND_LCE"},
   {MM_CIPHER_REJECT_LCE, "MM_CIPHER_REJECT_LCE"},
   {MM_TIM_CIPHER_01_EXPIRED, "MM_TIM_CIPHER_01_EXPIRED"},
   {MM_IDENTITY_REPLY_LCE, "MM_IDENTITY_REPLY_LCE"},
   {MM_DETACH_LCE, "MM_DETACH_LCE"},
   {MM_INFO_REQUEST_LCE, "MM_INFO_REQUEST_LCE"},
   {MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ, "MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ"},
   #ifdef CONFIG_REPEATER_SUPPORT
	{MM_REP_ACCESS_CFM, "MM_REP_ACCESS_CFM"},
	{MM_MM_INFO_SENT_IN_LAP, "MM_MM_INFO_SENT_IN_LAP"},
	{MM_TIM_REPEATER_01_EXPIRED, "MM_TIM_REPEATER_01_EXPIRED"},
   #endif
   {0xFF, "Unknown Message"}
};
#endif

/* =======================================================================
 * Global Variables
 * ======================================================================= */

/* =======================================================================
 * Local Function Prototypes
 * ======================================================================= */

/* =======================================================================
 * Global Function Definitions
 * ======================================================================= */
EXPORT void
MM_INIT( void )
{
   BYTE i;

   for( i = 0; i < MAX_LINK; i++ )
   {
      MM_Struct[ i ].Return_Proc = 0xFF;
      #if !defined(ULE_SUPPORT) && !defined(CONFIG_REPEATER_SUPPORT)
      Terminal_Cap[ i ] = 0;
      First_Codec[ i ] = 0;
      Second_Codec[ i ] = 0;
      Third_Codec[ i ] = 0;
      #endif
   }

   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   for( i = 0; i < MAX_PORTABLE; i++ ) {
      Terminal_Cap[ i ] = 0;
      First_Codec[ i ] = 0;
      Second_Codec[ i ] = 0;
      Third_Codec[ i ] = 0;
   }
   #endif
}

EXPORT void
RESET_MM_INIT( void )
{
   BYTE i;

   for( i = 0;  i < MAX_LINK;  i++ )
   {
      MM_Struct[ i ].Return_Proc = 0xFF;
   }
}

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT void
Set_First_Codec(BYTE portableNo, BYTE value)
{
   #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      First_Codec[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE] = value;
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      First_Codec[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE] = value;
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      First_Codec[portableNo-1] = value;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT BYTE
Get_First_Codec(BYTE portableNo)
{
   #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      return First_Codec[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE];
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
         return First_Codec[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE];
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      return First_Codec[portableNo-1];
   } else {
      return 0;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT void
Set_Second_Codec(BYTE portableNo, BYTE value)
{
   #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      Second_Codec[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE] = value;
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      Second_Codec[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE] = value;
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      Second_Codec[portableNo-1] = value;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT BYTE
Get_Second_Codec(BYTE portableNo)
{
   #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      return Second_Codec[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE];
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      return Second_Codec[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE];
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      return Second_Codec[portableNo-1];
   } else {
      return 0;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT void
Set_Third_Codec(BYTE portableNo, BYTE value)
{
   #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      Third_Codec[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE] = value;
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      Third_Codec[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE] = value;
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      Third_Codec[portableNo-1] = value;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT BYTE
Get_Third_Codec(BYTE portableNo)
{
   #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      return Third_Codec[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE];
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      return Third_Codec[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE];
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      return Third_Codec[portableNo-1];
   } else {
      return 0;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT void
Set_Terminal_Cap(BYTE portableNo, BYTE value)
{
   #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      Terminal_Cap[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE] = value;
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      Terminal_Cap[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE] = value;
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      Terminal_Cap[portableNo-1] = value;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT BYTE
Get_Terminal_Cap(BYTE portableNo)
{
   #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      return Terminal_Cap[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE];
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      return Terminal_Cap[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE];
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      return Terminal_Cap[portableNo-1];
   } else {
      return 0;
   }
}
#endif

#if defined(CONFIG_REPEATER_SUPPORT)
EXPORT BYTE
Get_Repeater_Info(void)
{
   return Repeater_Reg;
}

EXPORT BYTE
Get_Repeater_PoNo(void)
{
   return Repeater_PoNo;
}

EXPORT void
Set_Repeater_PoNo(BYTE portableNo)
{
   Repeater_PoNo = portableNo;
}
#endif

/* =========================                                            */
/* Local function definition                                            */
/* =========================                                            */
#ifdef CONFIG_TEST_MAC_CONFIG_INFO_WITH_LOC_ACC
LOCAL BYTE XDATA * addULEMACConfigIE(BYTE po_no, BYTE XDATA * framePtr)
{
   //if (Feature_Code_CP & FEATURE_FT_ULE_SUPPORT) {
      framePtr = Add_ULE_MAC_INFO( po_no, framePtr);
   //}
   return framePtr;
}
#endif

LOCAL void
send_down_AR_Terminate_Request( BYTE po_no )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_own_PD_MM,
                                ACCESS_RIGHTS_TERMINATE_REQUEST);
   temp = Add_PORTABLE_IDENTITY( po_no, temp, IDENTITY_TYP_IPUI );
   #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
   temp = Add_FIXED_IDENTITY(0, temp, IDENTITY_TYP_PARK);
   #else
   temp = Add_FIXED_IDENTITY   ( temp, IDENTITY_TYP_PARK );
   #endif
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_down_AR_Terminate_Reject( BYTE reason )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_peer_PD_MM,
                                ACCESS_RIGHTS_TERMINATE_REJECT);
   temp = Add_IE_3(temp, REJECT_REASON, 0x01, reason);
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_down_AR_Terminate_Accept( void )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_peer_PD_MM,
                                ACCESS_RIGHTS_TERMINATE_ACCEPT);
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
#ifdef ULE_SUPPORT
#ifdef CONFIG_EARLY_ENCRYPTION
send_down_Auth_Request_UAK(FPTR rand_ptr, FPTR rs_ptr, BYTE supportsDsaa2, WORD defaultCipherKeyIndex)
#else
send_down_Auth_Request_UAK(FPTR rand_ptr, FPTR rs_ptr, BYTE supportsDsaa2)
#endif
#else
#ifdef CONFIG_EARLY_ENCRYPTION
send_down_Auth_Request_UAK(FPTR rand_ptr, FPTR rs_ptr, WORD defaultCipherKeyIndex)
#else
send_down_Auth_Request_UAK(FPTR rand_ptr, FPTR rs_ptr)
#endif
#endif
{
   FPTR temp;
   #ifdef CONFIG_EARLY_ENCRYPTION
   BYTE buffer[5];
   #endif

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_own_PD_MM,
                                AUTH_REQUEST);

   // Octet 3: Auth algorithm identifier
   //          DSAA / DSAA2
   // Octet 4: Auth. key type | Auth. key number
   //          UAK              IPUI/PARK
   // Octet 5: INC | DEF | TXC | UPC | Cipher key number
   //          0     0     0     1     0x08 (IPUI/PARK)  ; normal cipher key
   //          0     0     0     1     0x09 (IPUI/PARK)  ; DCK for CCM
   //          0     1     0     1     0x08 (IPUI/PARK)  ; default cipher key

   #ifdef ULE_SUPPORT
   if (supportsDsaa2) {
      if (MM_Struct[CurrentInc].makingDCKCCM) {
         temp = Add_IE_5(temp, AUTH_TYPE, 0x03,
                         DSAA2,
                         USER_AUTHENTICATION_KEY | 0x08,
                         0x10 | 0x09);
      } else {
         #ifdef CONFIG_EARLY_ENCRYPTION
         // Currently, ULE does not support default cipher key feature with DSAA2. But, the code is added for the future.
         if (defaultCipherKeyIndex != 0xFFFF) {
            buffer[0] = DSAA2;
            buffer[1] = USER_AUTHENTICATION_KEY | 0x08;
            buffer[2] = 0x40 | 0x10 | 0x08;
            buffer[3] = HIBYTE(defaultCipherKeyIndex);
            buffer[4] = LOBYTE(defaultCipherKeyIndex);
            temp = Append_IE(temp, AUTH_TYPE, 5, buffer);
         } else
         #endif
         {
            temp = Add_IE_5(temp, AUTH_TYPE, 0x03,
                            DSAA2,
                            USER_AUTHENTICATION_KEY | 0x08,
                            0x10 | 0x08);
         }
      }
      temp = Append_IE(temp, RAND, RAND_LEN, rand_ptr);
      temp = Append_IE(temp, RS, RS2_LEN, rs_ptr);
   } else
   #endif
   {
      #ifdef CONFIG_EARLY_ENCRYPTION
      if (defaultCipherKeyIndex != 0xFFFF) {
         buffer[0] = DSAA;
         buffer[1] = USER_AUTHENTICATION_KEY | 0x08;
         buffer[2] = 0x40 | 0x10 | 0x08;
         buffer[3] = HIBYTE(defaultCipherKeyIndex);
         buffer[4] = LOBYTE(defaultCipherKeyIndex);
         temp = Append_IE(temp, AUTH_TYPE, 5, buffer);
      } else
      #endif
      {
         temp = Add_IE_5(temp, AUTH_TYPE, 0x03,
                         DSAA,
                         USER_AUTHENTICATION_KEY | 0x08,
                         0x10 | 0x08);
      }
      temp = Append_IE(temp, RAND, RAND_LEN, rand_ptr);
      temp = Append_IE(temp, RS, RS_LEN, rs_ptr);
   }
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
#ifdef ULE_SUPPORT
send_down_Auth_Request_UPI( FPTR rand_ptr, FPTR rs_ptr, BYTE supportsDsaa2 )
#else
send_down_Auth_Request_UPI( FPTR rand_ptr, FPTR rs_ptr )
#endif
{
   FPTR temp;
   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_own_PD_MM,
                                AUTH_REQUEST);
   /* Byte 3: Authentication           */
   /* Identifier -> DSAA               */
   /* Byte 4: Key type | Key Nr.       */
   /* -> UPI | IPUI/PARK               */
   /* Byte 5: Inc = 0 | TXC = 0 |      */
   /* UPC = 0 | 0                      */
   #ifdef ULE_SUPPORT
   if (supportsDsaa2) {
      temp = Add_IE_5(temp, AUTH_TYPE, 0x03,
                      DSAA2,
                      USER_PERSONAL_IDENTITY | 0x08,
                      0x00);
      temp = Append_IE(temp, RAND, RAND_LEN, rand_ptr);
      temp = Append_IE(temp, RS, RS2_LEN, rs_ptr);
   } else
   #endif
   {
      temp = Add_IE_5(temp, AUTH_TYPE, 0x03,
                      DSAA,
                      USER_PERSONAL_IDENTITY | 0x08,
                      0x00);
      temp = Append_IE(temp, RAND, RAND_LEN, rand_ptr);
      temp = Append_IE(temp, RS, RS_LEN, rs_ptr);
   }
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_down_Auth_Reject_Key( BYTE reason )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_own_PD_MM,
                                AUTH_REJECT);
   temp = Add_IE_3(temp, REJECT_REASON, 0x01, reason);
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_down_Auth_Reject_FT( BYTE reason )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_peer_PD_MM,
                                AUTH_REJECT);
   temp = Add_IE_3(temp, REJECT_REASON, 0x01, reason);
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
#ifdef ULE_SUPPORT
send_down_Auth_Reply_Key( FPTR res_ptr,  BYTE XDATA * rand_ptr, BYTE XDATA * rs_ptr, BYTE supportsDsaa2 )
#else
send_down_Auth_Reply_Key( FPTR res_ptr )
#endif
{
   FPTR temp;
   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_own_PD_MM,
                                AUTH_REPLY);
   #ifdef ULE_SUPPORT
   if (supportsDsaa2) {
      temp = Append_IE(temp, RAND, RAND_LEN, rand_ptr);
      temp = Append_IE(temp, RES, RES_LEN, res_ptr);
      temp = Append_IE(temp, RS, RS2_LEN, rs_ptr);
   } else
   #endif
   {
      temp = Append_IE(temp, RES, RES_LEN, res_ptr);
   }
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
#ifdef ULE_SUPPORT
send_down_Auth_Reply_FT( FPTR res_ptr, FPTR rand_ptr, FPTR rs_ptr, BYTE supportsDsaa2 )
#else
send_down_Auth_Reply_FT( FPTR res_ptr, FPTR rs_ptr )
#endif
{
   FPTR temp;
   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_peer_PD_MM,
                                AUTH_REPLY);
   #ifdef ULE_SUPPORT
   if (supportsDsaa2) {
      temp = Append_IE(temp, RAND, RAND_LEN, rand_ptr);
      temp = Append_IE(temp, RES, RES_LEN, res_ptr);
      temp = Append_IE(temp, RS, RS2_LEN, rs_ptr);
   } else
   #endif
   {
      temp = Append_IE(temp, RES, RES_LEN, res_ptr);
      temp = Append_IE(temp, RS,  RS_LEN, rs_ptr);
   }
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_down_AR_Reject( BYTE reason )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_peer_PD_MM,
                                ACCESS_RIGHTS_REJECT);
   temp = Add_IE_3(temp, REJECT_REASON, 0x01, reason);
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_down_AR_Accept( BYTE po_no )
{
   FPTR temp;
   FPTR temp_prop=NULL;

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_peer_PD_MM,
                                ACCESS_RIGHTS_ACCEPT);

   #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
   if (MM_Struct[CurrentInc].DeviceType == REP_DEVICE) {
   temp = Add_PORTABLE_IDENTITY(po_no, temp, IDENTITY_TYP_IPUI);
      temp = Add_FIXED_IDENTITY(0, temp, IDENTITY_TYP_PARK);
//      temp = Add_FIXED_IDENTITY((po_no - REP_DEVICE_OFFSET + 1), temp, IDENTITY_TYP_ARI_RPN_FOR_WRS);
                                       /* Add << Service Class >> IE       */
      //temp = Add_IE_3(temp, SERVICE_CLASS, 0x01, Subscription_GetServiceClass(po_no));
   } else
   #endif
   {
      temp = Add_PORTABLE_IDENTITY( po_no, temp, IDENTITY_TYP_IPUI );
      #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
      temp = Add_FIXED_IDENTITY(0, temp, IDENTITY_TYP_PARK);
      #else
      temp = Add_FIXED_IDENTITY(temp, IDENTITY_TYP_PARK);
      #endif

      /* Add << Service Class >> IE       */
      temp = Add_IE_3(temp, SERVICE_CLASS, 0x01, Subscription_GetServiceClass(po_no));
      #ifdef CAT_IQ2_1
      //if( MM_Struct[ CurrentInc ].Model_Id != 0xFF )
      temp = Add_IE_5(temp, MODEL_IDENTIFIER,0x03, HIBYTE(First_EMC_Code), LOBYTE(First_EMC_Code), Model_ID);
      #endif

      /* Add << CODEC List >> IE       */
      #ifdef DECT_NG
      DECT_DEBUG_USER_MM_DATA("Primary_Codec = %d\n", Primary_Codec);
      //    Primary_Codec = CODEC_G722;      // for test
      temp_prop =  Get_Codec_List(0);
      temp = Add_CODEC_LIST(temp, temp_prop);
      Mmu_Free(temp_prop);
      #endif
   }
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
#ifdef ULE_SUPPORT
send_down_Key_Allocate( FPTR rand_ptr, FPTR rs_ptr, BYTE supportsDsaa2 )
#else
send_down_Key_Allocate( FPTR rand_ptr, FPTR rs_ptr )
#endif
{
   FPTR temp;
   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_own_PD_MM,
                                KEY_ALLOCATE);
   #ifdef ULE_SUPPORT
   if (supportsDsaa2) {
      temp = Add_IE_4(temp, ALLOCATION_TYPE, 0x02, DSAA2, 0x88);
      temp = Append_IE(temp, RAND, RAND_LEN, rand_ptr);
      temp = Append_IE(temp, RS, RS2_LEN, rs_ptr);
   } else
   #endif
   {
      temp = Add_IE_4(temp, ALLOCATION_TYPE, 0x02, DSAA, 0x88);
      temp = Append_IE(temp, RAND, RAND_LEN, rand_ptr);
      temp = Append_IE(temp, RS, RS_LEN, rs_ptr);
   }
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_down_Locate_Reject( BYTE reason )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_peer_PD_MM,
                                LOCATE_REJECT);
   temp = Add_IE_3(temp, REJECT_REASON, 0x01, reason);
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
#ifdef CONFIG_TEST_MAC_CONFIG_INFO_WITH_LOC_ACC
send_down_Locate_Accept(BYTE po_no, BOOL ULEDevice)
#else
send_down_Locate_Accept( BYTE po_no )
#endif
{
   FPTR temp;
   FPTR temp_prop=NULL;
   #ifdef ARI_CLASS_B
   BYTE access_right_class;
   #endif

   #if defined( CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT ) || defined( ARI_CLASS_B )
   BYTE lal=36;
   #endif

   #ifdef ARI_CLASS_B
   access_right_class=FT_Identity.rfpi_array[4] & 0x70; // Get the ARC to decide the park-length-indicator and location-area-level
   if( access_right_class > ARC_A )
      lal = 31;
   #endif

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_peer_PD_MM,
                                LOCATE_ACCEPT);

 DECT_DEBUG_USER_MM_DATA("LocAccept:%02x %02x \n",MM_Struct[CurrentInc].DeviceType, po_no);
 #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
   if (MM_Struct[CurrentInc].DeviceType == REP_DEVICE) {
      temp = Add_PORTABLE_IDENTITY(po_no, temp, IDENTITY_TYP_TPUI);
      #ifdef KLOCWORK
      //
      #else
      DECT_DEBUG_USER_MM_KEY("MM_TPUI[%02x]:%02x %02x %02x %02x %02x %02x %02x %02x\n",
                              po_no, temp[9], temp[10], temp[11], temp[12],
                              temp[13], temp[14], temp[15], temp[16]);
      #endif
      //temp = Add_PORTABLE_IDENTITY(po_no + REP_DEVICE_OFFSET, temp, IDENTITY_TYP_IPUI);
      temp = Add_IE_3(temp, LOCATION_AREA, 0x01, LAL_INCLUDED | 36);
   } else {
      temp = Add_PORTABLE_IDENTITY(po_no, temp, IDENTITY_TYP_TPUI);
      temp = Add_IE_3(temp, LOCATION_AREA, 0x01, LAL_INCLUDED | lal);
      #ifdef DECT_NG
         #ifdef ULE_SUPPORT
      if (Get_Terminal_Cap(po_no) == 1)
         #else
      if( Terminal_Cap[ po_no - 1 ] == 1 )
         #endif
      {
         temp_prop =  Get_Codec_List( 0 );
         temp = Add_CODEC_LIST( temp, temp_prop );
         Mmu_Free( temp_prop );
      }
      #endif
   }
 #else
   /* Deliver assigned TPUI          */
   /* ------------------------------ */
   temp = Add_PORTABLE_IDENTITY(po_no, temp, IDENTITY_TYP_TPUI);
   /* Default Location Area Level    */
   /* ------------------------------ */
   /* LAL = 39 Bit                   */
   temp = Add_IE_3(temp, LOCATION_AREA, 0x01, LAL_INCLUDED | 39);
   #ifdef CONFIG_TEST_MAC_CONFIG_INFO_WITH_LOC_ACC
   if (ULEDevice) {
      temp = addULEMACConfigIE(po_no, temp);
   }
   #endif
   /* Add << CODEC List >> IE       */
   #ifdef DECT_NG
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   if (Get_Terminal_Cap(po_no) == 1)   {
   #else
   if (Terminal_Cap[ po_no - 1 ] == 1) {
   #endif
      temp_prop =  Get_Codec_List(0);
      temp = Add_CODEC_LIST(temp, temp_prop);
      Mmu_Free(temp_prop);
   }
   #endif
 #endif

   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_down_Info_Suggest( void )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_own_PD_MM,
                                MM_INFO_SUGGEST);
   temp = Add_IE_3(temp, INFO_TYPE, 0x01, LOCATE_SUGGEST);

   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );

   // According to GAP (EN 300 444, V1.2.2, 1997-08, 8.29), two MM-INFO-SUGGEST messages
   // containing <<INFO-TYPE>> with "locate suggest" shall be sent.
   // The <ext> parameter shall be set to 0 in the first message and to 1 in the second message.
   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_own_PD_MM,
                                MM_INFO_SUGGEST);
   // Set the <ext> parameter (MSB) in the second INFO-SUGGEST message.
   temp = Add_IE_3(temp, INFO_TYPE, 0x01, 0x80 | LOCATE_SUGGEST);

   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

#ifdef CONFIG_REPEATER_SUPPORT
LOCAL void
send_down_MM_Info_Suggest( BYTE po_no )
{
   FPTR temp;
   FPTR DCKPtr, DCKPtr2;

   temp = Make_S_FORMAT_Message( PD_MM,
                                 TI_Value_own_PD_MM,
                                 MM_INFO_SUGGEST );

   // Set the <ext> parameter (MSB) in the second INFO-SUGGEST message.
   temp = Add_IE_3( temp, INFO_TYPE, 0x01, 0x80 | CK_TRANSFER );

   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
      #endif
      DCKPtr = &MM_Struct[CurrentInc].DCK_Array[0]; // For ULE, MSB 8 bytes are used.
      #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT)) {
      #else
   } else if (IsValidPortableNo(po_no, PORTABLE_DECT)) {
      #endif
      DCKPtr = &MM_Struct[CurrentInc].DCK_Array[DCK_LEN]; // For PP, LSB 8 bytes are used.
   }
   #else
      #ifdef KLOCWORK
   if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_DECT)) {
      #endif
      DCKPtr = &MM_Struct[CurrentInc].DCK_Array[0];
   }
   #endif
   else {
      DCKPtr = FT_RepSubscription[po_no - REP_DEVICE_OFFSET].dck_array;
   }
   DCKPtr2 = Mmu_Malloc( DCK_LEN+1);
   #ifdef KLOCWORK
   if(DCKPtr2 != NULL )
   #endif
   {
      DCKPtr2[0] = KEY_TYPE_DCK;
      Mmu_Memcpy(&DCKPtr2[1], DCKPtr, DCK_LEN);
      temp = Append_IE(temp, KEY, DCK_LEN+1, DCKPtr2);
      Mmu_Free (DCKPtr2);

      DECT_DEBUG_USER_MM_KEY("MM_INFO_DCK[%02x]:%02x %02x %02x %02x %02x %02x %02x %02x\n",
                           po_no, DCKPtr[0], DCKPtr[1], DCKPtr[2], DCKPtr[3],
                           DCKPtr[4], DCKPtr[5], DCKPtr[6], DCKPtr[7]);
   }
   KNL_SENDTASK_NP_WP_INC( LAP_REP, LAP_DL_DATA_RQ_LCE, temp, 1, 0, 0, 0, CurrentInc );
}

LOCAL void
send_down_MM_Info_Accept( FPTR IWUPtr )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message( PD_MM,
                                 TI_Value_peer_PD_MM,
                                 MM_INFO_ACCEPT );
   temp = Append_IE(temp, IWU_TO_IWU, 5, IWUPtr);

   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}
#endif

LOCAL void
send_down_Cipher_Request( BYTE mode, BYTE ti_val )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message(PD_MM,
                                ti_val,
                                CIPHER_REQUEST);
   // Only the following ciphering is supported:
   // - Cipher Algorithmus = DSCA,
   // - Key = DCK,
   // - Key nr = related to active IPUI/PARK.
   // The Y/N-Bit in the << CIPHER INFO >> IE determines if the ciphering is disabled or enabled !
   if( mode == TRUE )
   {
      // Cipher Switching 'enable' is required -> Y/N-Bit = TRUE.
      temp = Add_IE_4(temp, CIPHER_INFO, 0x02,
                      0x80 | DECT_STANDARD_CIPHER_ALGO,
                      CIPHER_KEY_TYPE_DCK | KEY_NR_RELATED_TO_IPUI_PARK);
   }
   else
   {
      // Cipher Switching 'disable' is required -> Y/N-Bit = FALSE.
      temp = Add_IE_4(temp, CIPHER_INFO, 0x02,
                      DECT_STANDARD_CIPHER_ALGO,
                      CIPHER_KEY_TYPE_DCK | KEY_NR_RELATED_TO_IPUI_PARK);
   }

   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

#ifdef CONFIG_REPEATER_SUPPORT
LOCAL void
send_down_Rep_Cipher_Request( BYTE mode, BYTE ti_val )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message( PD_MM,
                                 ti_val,
                                 CIPHER_REQUEST );
   // Only the following ciphering is supported:
   // - Cipher Algorithmus = DSCA,
   // - Key = DCK,
   // - Key nr = related to active IPUI/PARK.
   // The Y/N-Bit in the << CIPHER INFO >> IE determines if the ciphering is disabled or enabled !
   if( mode == TRUE )
   {
      // Cipher Switching 'enable' is required -> Y/N-Bit = TRUE.
      temp = Add_IE_4( temp, CIPHER_INFO, 0x02,
                       0x80 | DECT_STANDARD_CIPHER_ALGO,
                       CIPHER_KEY_TYPE_DCK | KEY_NR_RELATED_TO_IPUI_PARK );
   }
   else
   {
      // Cipher Switching 'disable' is required -> Y/N-Bit = FALSE.
      temp = Add_IE_4( temp, CIPHER_INFO, 0x02,
                       DECT_STANDARD_CIPHER_ALGO,
                       CIPHER_KEY_TYPE_DCK | KEY_NR_RELATED_TO_IPUI_PARK );
   }

   KNL_SENDTASK_NP_INC( LAP_REP, LAP_DL_DATA_RQ_LCE, temp, CurrentInc );
}
#endif

LOCAL void
send_down_Cipher_Reject( BYTE reject_reason )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_peer_PD_MM,
                                CIPHER_REJECT);
   temp = Add_IE_3(temp, REJECT_REASON, 0x01, reject_reason);
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_down_Identity_Request( void )
{
   FPTR temp;

   temp = Make_S_FORMAT_Message(PD_MM,
                                TI_Value_own_PD_MM,
                                IDENTITY_REQUEST);
   // Always the Portable Identity 'IPUI' is requested.
   temp = Add_IE_4 ( temp, IDENTITY_TYPE,
                     0x02,
                   0x80 | PORTABLE_ID_GROUP,
                   0x80 | IDENTITY_TYP_IPUI);
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_down_Cipher_Key( void )
{
   FPTR temp;
   FPTR DCKPtr;

   temp = Mmu_Malloc(8 + sizeof(struct HLI_Header));
   #ifdef KLOCWORK
   if( temp == NULL ) return;
   #endif

   ((struct HLI_Header *) temp)->length = 8 + sizeof(struct HLI_Header);

   // Copy the derivated cipher key(DCK).
   #ifdef ULE_SUPPORT
   {
         #ifdef KLOCWORK
      if (VALID_PORTABLE_ULE(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
         #else
      if (IsValidPortableNo(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
         #endif
         DCKPtr = &MM_Struct[CurrentInc].DCK_Array[0]; // For ULE, MSB 8 bytes are used.
      } else {
         DCKPtr = &MM_Struct[CurrentInc].DCK_Array[DCK_LEN]; // For PP, LSB 8 bytes are used.
      }
   }
   #else
   DCKPtr = &MM_Struct[CurrentInc].DCK_Array[0];
   #endif
   Mmu_Memcpy(&temp[sizeof(struct HLI_Header)],
              DCKPtr,
              8);
   KNL_SENDTASK_NP_INC( LCE, LCE_DL_ENC_KEY_RQ_MM, temp, CurrentInc );
}

#ifdef CONFIG_REPEATER_SUPPORT
LOCAL void
send_down_Rep_Cipher_Key( BYTE po_no )
{
   FPTR temp;
   FPTR DCKPtr;

   temp = Mmu_Malloc(8 + sizeof(struct HLI_Header));
   #ifdef KLOCWORK
   if( temp == NULL ) return;
   #endif

   ((struct HLI_Header *) temp)->length = 8 + sizeof(struct HLI_Header);

   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
      #endif
      DCKPtr = &MM_Struct[CurrentInc].DCK_Array[0]; // For ULE, MSB 8 bytes are used.
      #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT)) {
      #else
   } else if (IsValidPortableNo(po_no, PORTABLE_DECT)) {
      #endif
      DCKPtr = &MM_Struct[CurrentInc].DCK_Array[DCK_LEN]; // For PP, LSB 8 bytes are used.
   }
   #else
      #ifdef KLOCWORK
   if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_DECT)) {
      #endif
      DCKPtr = &MM_Struct[CurrentInc].DCK_Array[0];
   }
   #endif
   else {
      DCKPtr = FT_RepSubscription[po_no - REP_DEVICE_OFFSET].dck_array;
   }
   Mmu_Memcpy(&temp[sizeof(struct HLI_Header)],
              DCKPtr,
              8);
   DECT_DEBUG_USER_MM_KEY("MM_CIPHER_DCK[%02x]:%02x %02x %02x %02x %02x %02x %02x %02x\n",
                           po_no, DCKPtr[0], DCKPtr[1], DCKPtr[2], DCKPtr[3],
                           DCKPtr[4], DCKPtr[5], DCKPtr[6], DCKPtr[7]);

   KNL_SENDTASK_NP_WP_INC( LAP_REP, LAP_DL_ENC_KEY_RQ_LCE, temp, 0xFF, MM_Struct[CurrentInc].Rep_Lbn, 0, 0, CurrentInc );
}
#endif

LOCAL BIT
Check_Ti_Flag( BYTE flag )
{
   // A check for Null Pointer value must be done, because the function is also called in
   // transitions with timer expiry and link release events.
   if( G_PTR == NULL )
      return( TRUE );
   return(( G_PTR[ sizeof( struct HLI_Header )] & 0x80 ) == flag );
}

LOCAL void
send_up_Confirmation( BYTE result )
{
   BYTE po_no;

   po_no = Get_Assigned_Po_No(CurrentInc);
   // Reasonable value for po_no?
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
   if ((po_no == 0) || (po_no > MAX_PORTABLE))
   #endif
   {
      return;
   }

   /* Confirmation required ?          */
   if( MM_Struct[CurrentInc].Return_Proc >= PROCMAX )
      return;
   if( MM_Struct[CurrentInc].Return_Msg == 0xFF )
      return;
   if( MM_Struct[CurrentInc].Return_Inc >= INCMAX )
      return;

   #if defined(CONFIG_CC_ENCRYPTION) || defined(CONFIG_REPEATER_SUPPORT)
   if (MM_Struct[CurrentInc].Return_Proc == 0) // if IWU
   #endif
   {
      // Interface NTW-Layer<->App-Layer
      // P1: portable number
      // P2: result
      // P3: not used
      // P4: not used
      Send_Message_To_APP(MM_Struct[CurrentInc].Return_Msg,
                          NULL,
                          CurrentInc,
                          po_no,
                          result,
                          DUMMY_FILL,
                          DUMMY_FILL);
   }
   #if defined(CONFIG_CC_ENCRYPTION) || defined(CONFIG_REPEATER_SUPPORT)
   else
   { // For CC process
      KNL_SENDTASK_WP_INC(MM_Struct[CurrentInc].Return_Proc, MM_Struct[CurrentInc].Return_Msg, result, 0, 0, 0, MM_Struct[CurrentInc].Return_Inc);
   }
   #endif
   MM_Struct[CurrentInc].Return_Proc = 0xFF;
}

LOCAL void
send_Result( BYTE msg, BYTE result )
{
   if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
      send_up_Confirmation(result);
   } else {
      KNL_SENDTASK_WP_INC(MM,
                          msg,
                          result,
                          0,
                          0,
                          0,
                          CurrentInc);
   }
}

LOCAL void
send_dl_release_rq( BYTE release_mode )
{
   // According to GAP 300 444 / 8.39 Link release 'maintain', all MM procedures
   // (exept Location Registration) shall maintain the link !
   KNL_SENDTASK_WP_INC( LCE, LCE_DL_REL_RQ, release_mode, 0, 0, 0, CurrentInc );
}

LOCAL BYTE
Get_Encryption_State ( BYTE mcei )
{
   BYTE buffer[2];

   buffer[0] = mcei;    //mcei
   buffer[1] = 0;      //read_data
   get_enc_state_from_hmac_ioctl(buffer);
   return buffer[1];
}

#ifdef CONFIG_REPEATER_SUPPORT
LOCAL BYTE
Get_RepNum_Encryption ( BYTE mcei )
{
  BYTE buffer[2];

  buffer[0] = mcei;     // mcei
  buffer[1] = 0;        // read_data
  get_rep_num_from_hmac_ioctl(buffer);
  return buffer[1];
}

LOCAL void
Get_RepPmid_Encryption ( FPTR PmidBuf )
{
  get_rep_pmid_from_hmac_ioctl(PmidBuf);
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_EARLY_ENCRYPTION) || defined(CONFIG_REPEATER_SUPPORT)
LOCAL BYTE
getTerminalCapabilityValue(BYTE XDATA *terminalCapabilityIEPtr, BYTE octetGroup, BYTE offset)
{
   BYTE length;
   BYTE value;
   BYTE octetGroupCount;
   BYTE offsetCount;

   terminalCapabilityIEPtr++; // indicate octet 2; legnth
   length = *terminalCapabilityIEPtr++; // get length and then indicate octet 3
   octetGroupCount = 3;
   offsetCount = 0;
   while (length--) {
      value = *terminalCapabilityIEPtr++;

      if ((octetGroupCount == octetGroup) && (offsetCount == offset)) {
         return (value & 0x7F);
      }

      if (value & 0x80) { // end of octet group
         if (octetGroupCount == octetGroup) {
            return 0xFF; // no need to check more
         }
         octetGroupCount++;
         offsetCount = 0;
      } else {
         offsetCount++;
      }
   }

   return 0xFF;
}
#endif

#ifdef ULE_SUPPORT
LOCAL BYTE
isDsaa2Supported(BYTE XDATA *terminalCapabilityIEPtr)
{
   BYTE value;

   value = getTerminalCapabilityValue(terminalCapabilityIEPtr, 5, 0); // octet 5
   if ((value != 0xFF) && (value & 0x40)) { // DSAA2 bit
      return 1;
   } else {
      return 0;
   }
}
#endif

#ifdef CONFIG_EARLY_ENCRYPTION
LOCAL BOOL
isDefaultCipherKeyAssigned(BYTE portableNo)
{
   /*
    * Valid default cipher key index key index: 0x0001 ~ 0xFEFF (EN300175-3 V2.3.0, 7.2.5.7, Table 7.44b)
    */

   WORD XDATA cipherKeyIndex;

   cipherKeyIndex = Subscription_GetDefaultCipherKeyIndex(portableNo);
   if (cipherKeyIndex >= 0x0001 && cipherKeyIndex <= 0xFEFF) {
      return YES;
   }

   return NO;
}

LOCAL BOOL
isRekeyingSupported(BYTE portableNo)
{
   if (IFX_DECT_GetUserFeatures() & USER_FEATURES_EARLY_ENCRYPTION) { // Support of "Early encryption"
      if (IFX_DECT_GetUserFeatures() & USER_FEATURES_REKEYING) { // Support of "Re-keying"
         return isDefaultCipherKeyAssigned(portableNo);
      }
   }

   return NO;
}

LOCAL BOOL
isRekeyingAndEarlyEncryptionSet(BYTE XDATA *terminalCapabilityIEPtr)
{
   BYTE value;

   value = getTerminalCapabilityValue(terminalCapabilityIEPtr, 4, 6); // octet 4f
   if ((value != 0xFF) && (value & 0x10)) { // re-keying and early encryption bit
      return YES;
   } else {
      return NO;
   }
}
#endif

LOCAL void
clearMMState(void)
{
   MM_TABLE_ELEMENT XDATA *MMStructPtr;

   MMStructPtr = &MM_Struct[CurrentInc];
   MMStructPtr->EMC_Array[0] = 0;
   MMStructPtr->EMC_Array[1] = 0;
   #ifdef CONFIG_EARLY_ENCRYPTION
   MMStructPtr->makingDefaultCipherKey = NO;
   #endif
   #ifdef ULE_SUPPORT
   MMStructPtr->supportsDsaa2 = NO;
   MMStructPtr->makingDCKCCM = NO;
   MMStructPtr->DeviceType = DECT_DEVICE;
   #endif
   #ifdef CONFIG_REPEATER_SUPPORT
   MMStructPtr->Repeater_Idx = 0;
   MMStructPtr->Repeater_Num = 1                                                                                       ;
   #endif
   MMStructPtr->Starting_State = MM_OPEN;
   MMStructPtr->Last_State = MM_OPEN;
   KNL_Transit(MM_OPEN);
}

#ifdef DECT_NG
LOCAL void
evaluate_rx_codec( BYTE po_num )
{
   BYTE pos;

   /*******************************************************************
   (1)   7C : CODEC_LIST
   --------------------------------------------------------------------
   (2)   07 : length(07)
   (3)   90 : Negotiation_indicator(1)/RES
   (4)   03 : 1st codec-id(3:G722)=>highest priority
   (4a) 00 : res/MAC_DLC service( In_minimum_delay )
   (4b) 01 : C-plan(0:Cs only)/slot_size(Long slot;j=640)
   (5)   02 : last codec-id(2:G726)
   (5a) 00 : res/MAC_DLC service( In_minimum_delay )
   (5b) 84 : C-plan(0:Cs only)/slot_size(Full slot)
   *******************************************************************/
   pos = scan_IE( G_PTR, CODEC_LIST, 2, 20 );

   if( G_PTR[pos+1]  == 7 )
   {
      #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      Set_First_Codec(po_num, G_PTR[pos+3]);
      Set_Second_Codec(po_num, G_PTR[pos+6]);
      Set_Third_Codec(po_num, 0);
      #else
      First_Codec[po_num-1]  = G_PTR[pos+3];
      Second_Codec[po_num-1] = G_PTR[pos+6];
      Third_Codec[po_num-1]  = 0;
      #endif
   }
   else if( G_PTR[pos+1]  >= 10 )
   {
      #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      Set_First_Codec(po_num, G_PTR[pos+3]);
      Set_Second_Codec(po_num, G_PTR[pos+6]);
      Set_Third_Codec(po_num, G_PTR[pos+9]);
      #else
      First_Codec[po_num-1]  = G_PTR[pos+3];
      Second_Codec[po_num-1] = G_PTR[pos+6];
      Third_Codec[po_num-1]  = G_PTR[pos+9];
      #endif
   }
}
#endif

static void
T0500( void )
{
   /* TRANSITION:      T0500                                                */
   /* EVENT:           MM_LOCATE_REQUEST_LCE                                */
   /* DESCRIPTION:     Location Registration Procedure                      */
   /* REFERENCE:       ETS 300 175-5:1996 / 13.4.1                          */
   /* STARTING STATE:  MM_OPEN / MM_OBTAIN_ACCESS_RIGTHS                    */
   /* END STATE:       MM_AUTH_OF_PT / MM_OPEN                              */
   /* ----------------------------------------------------------------------*/
   BYTE pos, po_no;
   uint32 uiTermCap=0;
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   BYTE value;
   #endif
   /*BYTE i, len;*/     // for test

   Stop_Pro_Timer(TIMER_MM_LOCATE_01, CurrentInc);

   // Ignore message with wrong TI-Flag setting !
   if( ! Check_Ti_Flag( TI_Value_peer_PD_MM ))
   {
      Mmu_Free(G_PTR);
      clearMMState();
      return;
   }

   /*Separate EMC by SPP500 for DT extended feature in IWU to IWU*/
   DECT_DEBUG_USER_MM_DATA("[MM] Locate Req\n");
   pos = scan_IE(G_PTR, IWU_TO_IWU, 3, 10);
   if (pos != 0) {
      /*Check for PD user specific=0x00 and Descriminitaor for EMC=1*/
      if (((G_PTR[pos + 2] & 0x3F) == 0x00) && (((G_PTR[pos + 3] & 0x7F) == 0x01))) {
         DECT_DEBUG_USER_MM_DATA("[MM] EMC By PT: %02x %02x\n",G_PTR[pos+4],G_PTR[pos+5]);
         MM_Struct[CurrentInc].EMC_Array[0] = G_PTR[pos + 4];
         MM_Struct[CurrentInc].EMC_Array[1] = G_PTR[pos + 5];
      } else {
         DECT_DEBUG_USER_MM_DATA("[MM] Wrong EMC Encoding\n");
      }
   }

   // Not mandatory to check fixed ID(990118) TBR22_Test ?
   // Mandatory << PORTABLE ID >> IE there ?
   pos = scan_IE(G_PTR, PORTABLE_IDENTITY, 7, 7);
   if (pos == 0) {
      send_down_Locate_Reject(INFORMATION_ELEMENT_ERROR);
      Mmu_Free(G_PTR);
      send_dl_release_rq(PARTIAL_RELEASE);
      clearMMState();
      return;
   }

   // Mandatory << PORTABLE ID >> of type IPUI ?
   if (!((G_PTR[pos + 2] & 0x7F) == IDENTITY_TYP_IPUI)) {
      send_down_Locate_Reject(INVALID_IE_CONTENTS_REJ);
      Mmu_Free(G_PTR);
      send_dl_release_rq(PARTIAL_RELEASE);
      clearMMState();
      return;
   }

   #ifdef MASTER_BS
   // Subscription_ForceToRegister(&G_PTR[pos + 4], 0);
   Subscription_ForceToRegister(&G_PTR[pos + 4], 1);
   #endif

   /* Portable registered ?            */
   /* -------------------------------- */
   po_no = Subscription_GetPotableNoFromIPUI(&G_PTR[pos + 4]);
   if (po_no == 0xFF) {
      /* The portable is not registered.  */
      /* -------------------------------- */
      /* Send the Locat Reject message    */
      /* with << REJECT REASON >> IE      */
      /* ( unknown IPUI ).                */
      /* ================================ */
      /* NOTE: PT will erase registration */
      /*       if LOCATE_REJECT reason is */
      /*       IPUI_UNKNOWN ()       */
      /* ================================ */
      send_down_Locate_Reject(IPUI_UNKNOWN);

      #if 1  // For erasing registration in PT which already deregistered PT.
      {
         FPTR temp;

         temp = Make_S_FORMAT_Message( PD_MM, TI_Value_own_PD_MM,
                ACCESS_RIGHTS_TERMINATE_REQUEST );
         temp = Append_IE(temp, PORTABLE_IDENTITY, 7, &G_PTR[pos + 2]);
         #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
         temp = Add_FIXED_IDENTITY(0, temp, IDENTITY_TYP_PARK);
         #else
         temp = Add_FIXED_IDENTITY(temp, IDENTITY_TYP_PARK);
         #endif
         KNL_SENDTASK_NP_INC(LCE, LCE_DL_DATA_RQ, temp, CurrentInc);
      }
      #endif

      Mmu_Free(G_PTR);
      send_dl_release_rq(PARTIAL_RELEASE);
      clearMMState();
      return;
   }

   #ifdef CONFIG_EARLY_ENCRYPTION
   MM_Struct[CurrentInc].makingDefaultCipherKey = NO;
   #endif
   #ifdef ULE_SUPPORT
   MM_Struct[CurrentInc].supportsDsaa2 = NO;
   MM_Struct[CurrentInc].DeviceType = DECT_DEVICE;
   #endif

   #ifdef DECT_NG
   /*  << TERMINAL_CAPABILITY >> is there?  */
   /* -------------------------------- */
   pos = scan_IE(G_PTR, TERMINAL_CAPABILITY, 3, MAX_TERMINAL_CAPABILITY_IE_SIZE);

   if (pos != 0) {
      #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
         #ifdef KLOCWORK
      if (VALID_PORTABLE_ALL(po_no, PORTABLE_ALL)) {
         #else
      if (IsValidPortableNo(po_no, PORTABLE_ALL)) {
         #endif
      #else
      if ((po_no > 0) && (po_no <= MAX_PORTABLE)) {
      #endif
         uiTermCap = IFX_DECT_DecodeTermCap(po_no,&G_PTR[pos]);
         Subscription_SetTerminalCapability(uiTermCap,po_no);
      }

      if (Evaluate_Terminal_Capability_IE()) {
         #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
         Set_Terminal_Cap(po_no, 1);
         #else
         Terminal_Cap[po_no-1] = 1;
         #endif
      } else {
         #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
         Set_Terminal_Cap(po_no, 0);
         #else
         Terminal_Cap[po_no-1] = 0;
         #endif
      }

      #ifdef CONFIG_REPEATER_SUPPORT
      value = getTerminalCapabilityValue(&G_PTR[pos], 4, 2); // To check WRS supported
      DECT_DEBUG_USER_MM_DATA("[MM] CapRep %x %x \n", Feature_Repeater, value );
      if ((value != 0xFF) && (value & 0x02)) { // Repeater; WRS supported
         if (Feature_Repeater != 0) {
            MM_Struct[CurrentInc].DeviceType = REP_DEVICE;
         } else {
            send_down_AR_Reject(INCOMPATIBLE_SERVICE_REJ);
            send_dl_release_rq( PARTIAL_RELEASE );
            clearMMState();
            return;
         }
      }
      #endif

      #ifdef ULE_SUPPORT
      value = getTerminalCapabilityValue(&G_PTR[pos], 4, 8); // To check ULE supported(4h)
      DECT_DEBUG_USER_MM_DATA("[MM] CapULE %x \n", value );
      if ((value != 0xFF) && (value & 0x04)) { // ULE supported
         MM_Struct[CurrentInc].DeviceType = ULE_DEVICE;
      }
      #endif

      #ifdef ULE_SUPPORT
      if (MM_Struct[CurrentInc].DeviceType == ULE_DEVICE)
      {
         MM_Struct[CurrentInc].supportsDsaa2 = isDsaa2Supported(&G_PTR[pos]);
      }

      #ifdef CONFIG_TEST_GENERATE_DCKCCM_DURING_LOC_REG
      if (MM_Struct[CurrentInc].supportsDsaa2) {
         MM_Struct[CurrentInc].makingDCKCCM = YES;
      }
      #endif
      DECT_DEBUG_USER_MM_DATA("[MM] PT Device:%02x %02x %02x \n", MM_Struct[CurrentInc].DeviceType, MM_Struct[CurrentInc].supportsDsaa2, po_no);
      #endif

      #ifdef CONFIG_EARLY_ENCRYPTION
      DECT_DEBUG_USER_MM_DATA("[MM] PT Re-keying And Early Encryption: %02x\n", isRekeyingAndEarlyEncryptionSet(&G_PTR[pos]));
      #ifdef ULE_SUPPORT
         #ifdef KLOCWORK
      if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT))
         #else
      if (IsValidPortableNo(po_no, PORTABLE_DECT))
         #endif
      #endif
      {
         /*
            Currently, early encryption feature will not be supported for ULE devices because the resource of Modem is limited.
          */

         if (!isDefaultCipherKeyAssigned(po_no) && isRekeyingAndEarlyEncryptionSet(&G_PTR[pos]) && (IFX_DECT_GetUserFeatures() & USER_FEATURES_EARLY_ENCRYPTION)) {
            MM_Struct[CurrentInc].makingDefaultCipherKey = YES;
         }
      }
      #endif
   }
   #elif defined(ULE_SUPPORT)
   if ((pos = scan_IE(G_PTR, TERMINAL_CAPABILITY, 3, MAX_TERMINAL_CAPABILITY_IE_SIZE)) != 0) {
      value = getTerminalCapabilityValue(&G_PTR[pos], 4, 8); // To check ULE supported(4h)
      if ((value != 0xFF) && (value & 0x04)) { // ULE supported
         MM_Struct[CurrentInc].DeviceType = ULE_DEVICE;
      }
      DECT_DEBUG_USER_MM_DATA("[MM] PT ULE: %02x\n", MM_Struct[CurrentInc].ULEDevice);

      if (MM_Struct[CurrentInc].DeviceType == ULE_DEVICE)
      {
      MM_Struct[CurrentInc].supportsDsaa2 = isDsaa2Supported(&G_PTR[pos]);
      }
      #ifdef CONFIG_TEST_GENERATE_DCKCCM_DURING_LOC_REG
      if (MM_Struct[CurrentInc].supportsDsaa2) {
         MM_Struct[CurrentInc].makingDCKCCM = YES;
      }
      #endif
   }
   #endif

   #ifdef DECT_NG
   /* << CODEC_List >> is there?      */
   pos = scan_IE(G_PTR, CODEC_LIST, 2, 20);
   if (pos != 0) {
      evaluate_rx_codec(po_no);
   }
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   else if(Get_Terminal_Cap(po_no) == 0) {
      Set_First_Codec(po_no, 2);
      Set_Second_Codec(po_no, 0);
      Set_Third_Codec(po_no, 0);
   }
   #else
   else if(Terminal_Cap[po_no-1] == 0) {
      First_Codec[po_no - 1] = 2;
      Second_Codec[po_no - 1] = 0;
      Third_Codec[po_no - 1] = 0;
   }
   #endif
   #endif

                                       /* The Portable is registered.      */
                                       /* -------------------------------- */
                                       /* Check if application layer is still  */
                                       /* Assigned to the po_no, this case can */
                                       /* be exist when the PT synchronized    */
                                       /* again to the FT immediately after    */
                                       /* lost connection and sync during app  */
                                       /* layer assigned(not cleared yet)      */
                                       /* and cause app.layer maintain LINK    */
                                       /* and wrong CIPHERING(BUG!! 13.jul.98) */
   #if 0  // No Need. Jake remove this routine
   for( pos = 0; pos < MAX_LINK; pos++ )
   {
      if( Get_Assigned_Po_No( pos ) == po_no )
      {
         // we forgot the Locate registration just after obtaining access rights

         // Don't need if encryption is not running
         printf("\nwe forgot the Locate registration\n");
         if( !TBR22_Test )
         {
            if(( CurrentState != MM_OBTAIN_ACCESS_RIGHTS ) &&
               ( Get_Encryption_State ( pos ) == TRUE ))
            {
               KNL_SENDTASK_INC( LAP, LAP_DL_REL_RQ_ABNORMAL_MM, pos );
               printf("\nLAP_DL_REL_RQ_ABNORMAL_MM\n");
            }
         }
         break;
      }
   }
   #endif

   // Do the Application Layer Assignment.
   #if 1 /*SH_FIX by jonathan*/
   Discard_Page_Queue(po_no);
   #endif

   #ifdef xxxCONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT  // No Need. Repeater should be checked authentication.
   if (MM_Struct[CurrentInc].DeviceType == ULE_DEVICE) {
      Mmu_Free(G_PTR);
      Set_App_Layer_Assignment(CurrentInc, po_no); // Do the Application Layer Assignment

      Repeater_SetTPUI(po_no, ASSIGNED_TPUI);
      send_down_Locate_Accept(po_no);
                                       /* Locate Accept Timer              */
                                       /* -------------------------------- */
                                       /* Timer:    MM-<identity.1>        */
                                       /* Duration: 10 seconds             */
      DECTTimer_StartProtocolTimer(TIMER_MM_IDENTITY_01, CurrentInc);
      KNL_Transit(MM_LOCATION_ACK_WAIT);
      return;
   }
   #endif

   Set_App_Layer_Assignment(CurrentInc, po_no);

   #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
   if (MM_Struct[CurrentInc].DeviceType != REP_DEVICE) {
   #endif
      Send_Message_To_APP(FP_PROP_INFO_IN_MM,
                       G_PTR,
                       CurrentInc,
                       Get_Assigned_Po_No(CurrentInc),
                       DUMMY_FILL,
                       DUMMY_FILL,
                       DUMMY_FILL);
   #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
   }
   #endif
                                       /* NOTE: NO!, we should generate new */
                                       /* DCK during location registration  */
                                       /* otherwise, The encryption will be */
                                       /* done with wrong DCK especially at */
                                       /* the gigaset PT(2000C)             */
                                       /* Invoke the internesting          */
                                       /* Authentication of PT procedure.  */
                                       /* Only if the Authentication of    */
                                       /* PT is successful a TPUI is       */
                                       /* assigned !                       */
   MM_Struct[CurrentInc].Starting_State = MM_LOCATION_REGISTRATION;
   MM_Struct[CurrentInc].Last_State = MM_LOCATION_REGISTRATION;
   KNL_SENDTASK_INC(MM, MM_AUTHENTICATE_PT_RQ, CurrentInc);
   KNL_Transit(MM_AUTH_OF_PT);
}

static void T0420( void )
{
   /* TRANSITION:      T0420                                                */
   /* EVENT:           MM_AUTH_REQUEST_LCE                                  */
   /* DESCRIPTION:     Authentication of FT                                 */
   /* REFERENCE:       ETS 300 175-5:1996 / 13.3.3                          */
   /* STARTING STATE:  all                                                  */
   /* END STATE:       current state maintained                             */
   /* ----------------------------------------------------------------------*/
   BYTE po_no, pos;
   BYTE pos_rand;
   BYTE pos_auth;
   FPTR Temp_K_Array =NULL;
   FPTR Temp_RS_Array=NULL;
   FPTR Temp_RAND_Array=NULL;
   FPTR Temp_KS_Array=NULL;
   FPTR Temp_RES_Array=NULL;
   #ifdef ULE_SUPPORT
   BYTE supportsDsaa2 = FALSE;
   BYTE XDATA * Temp_RAND_F_Array=NULL;
   #endif

   // Ignore message with wrong TI-Flag setting !
   if( ! Check_Ti_Flag( TI_Value_peer_PD_MM ))
   {
   Mmu_Free( G_PTR );
   return;
   }

   /* Mandatory << RAND >> IE there ?  */
   /* -------------------------------- */
   pos_rand = scan_IE( G_PTR, RAND, RAND_LEN, RAND_LEN );
   if( pos_rand == 0 )
   {
   send_down_Auth_Reject_FT( INFORMATION_ELEMENT_ERROR );
   Mmu_Free( G_PTR );
   return;
   }
   /* Mandatory << AUTH >> IE there ?  */
   /* -------------------------------- */
   pos_auth = scan_IE( G_PTR, AUTH_TYPE, 3, 4 );
   if( pos_auth == 0 )
   {
   send_down_Auth_Reject_FT( INFORMATION_ELEMENT_ERROR );
   Mmu_Free( G_PTR );
   return;
   }
   /* Determine the requested          */
   /* Authentication Algorithm.        */
   /* -------------------------------- */
   /* Only DSAA/UAK, DSAA/AC are       */
   /* supported !                      */
   #ifdef ULE_SUPPORT
   if (G_PTR[ pos_auth + 2 ] == DSAA2) {
      supportsDsaa2 = TRUE;
   }

   if( ! (((  G_PTR[ pos_auth + 2 ] == DSAA) || (G_PTR[ pos_auth + 2 ] == DSAA2)) &&
         ((( G_PTR[ pos_auth + 3 ] & 0xF0 ) == USER_AUTHENTICATION_KEY ) ||
         ((  G_PTR[ pos_auth + 3 ] & 0xF0 ) == AUTHENTICATION_CODE ))))
   #else
   if( ! ((  G_PTR[ pos_auth + 2 ]          == DSAA ) &&
   ((( G_PTR[ pos_auth + 3 ] & 0xF0 ) == USER_AUTHENTICATION_KEY ) ||
   ((  G_PTR[ pos_auth + 3 ] & 0xF0 ) == AUTHENTICATION_CODE ))))
   #endif
   {
   send_down_Auth_Reject_FT( AUTH_ALGORITHM_NOT_SUPPORTED );
   Mmu_Free( G_PTR );
   return;
   }

   /* All necessary Information        */
   /* Elements are there. Answer the   */
   /* Authentication of FT request.    */
   /* NOTE: The Authentication of FT   */
   /* can be invoked at any time from  */
   /* the portable. Because a          */
   /* Authentication of FT procedure   */
   /* can be internested in a          */
   /* Authentication of PT procedure   */
   /* it is not allowed to modify the  */
   /* MM_Struct variables. All         */
   /* necessary memory must be         */
   /* allocated dynamically.           */
   po_no = 0xFF;
   /*
      << PORTABLE ID>> is not mandatory. Therefore, this IE will be checked
      when a portable number is not assigned.
      Remarks:
         In TC_FT_ME_BV_01 / TC_FT_MM_BV_AU_04 test cases, Auth of FT is initiated
         with CC process.
    */
   if ((po_no = Get_Assigned_Po_No(CurrentInc)) == 0xFF)
   {
      pos = scan_IE( G_PTR, PORTABLE_IDENTITY, 7, 7 );
      if( pos == 0 )
      {
         send_down_Auth_Reject_FT( INFORMATION_ELEMENT_ERROR );
         Mmu_Free( G_PTR );
         return;
      }
      /* Mandatory << PORTABLE ID >> of   */
      /* type IPUI ?                      */
      /* -------------------------------- */
      if( ! (( G_PTR[ pos + 2 ] & 0x7F ) == IDENTITY_TYP_IPUI ))
      {
         send_down_Auth_Reject_FT( INVALID_IE_CONTENTS_REJ );
         Mmu_Free( G_PTR );
         return;
      }

      /* Portable registered ?            */
      /* -------------------------------- */
      po_no = Subscription_GetPotableNoFromIPUI( &G_PTR[ pos + 4 ] );
      if( po_no == 0xFF )
      {
         /* The portable is not registered.  */
         /* -------------------------------- */
         /* Send the Locat Reject message    */
         /* with << REJECT REASON >> IE      */
         /* ( unknown IPUI ).                */
         /* ================================ */
         /* NOTE: PT will erase registration */
         /*       if LOCATE_REJECT reason is */
         /*       IPUI_UNKNOWN ()       */
         /* ================================ */
         send_down_Auth_Reject_FT( IPUI_UNKNOWN );
         Mmu_Free( G_PTR );
         return;
      }

      DECT_DEBUG_USER_MM_DATA("[MM] PT Device@Auth:%02x %02x \n", MM_Struct[CurrentInc].DeviceType, po_no);
      /* Do the Application Layer         */
      /* Assignment if not done.          */
      /* 24FEB2001  Missed!!!!       */
      Set_App_Layer_Assignment( CurrentInc, po_no );
   }

   Temp_K_Array    = Mmu_Malloc( K_LEN    );
      #ifdef KLOCWORK
   if(Temp_K_Array == NULL)
      goto FREE_BUFF;
      #endif
   #ifdef ULE_SUPPORT
   Temp_RS_Array   = Mmu_Malloc( RS2_LEN   );
      #ifdef KLOCWORK
   if(Temp_RS_Array == NULL)
      goto FREE_BUFF;
      #endif
   Temp_RAND_F_Array = Mmu_Malloc( RAND_LEN );
      #ifdef KLOCWORK
   if(Temp_RAND_F_Array == NULL)
      goto FREE_BUFF;
      #endif
   #else
   Temp_RS_Array   = Mmu_Malloc( RS_LEN   );
      #ifdef KLOCWORK
   if(Temp_RS_Array == NULL)
      goto FREE_BUFF;
      #endif
   #endif
   Temp_RAND_Array = Mmu_Malloc( RAND_LEN );
      #ifdef KLOCWORK
   if(Temp_RAND_Array == NULL)
      goto FREE_BUFF;
      #endif
   Temp_KS_Array   = Mmu_Malloc( KS_LEN   );
      #ifdef KLOCWORK
   if(Temp_KS_Array == NULL)
      goto FREE_BUFF;
      #endif
   Temp_RES_Array  = Mmu_Malloc( RES_LEN  );
      #ifdef KLOCWORK
   if(Temp_RES_Array == NULL)
      goto FREE_BUFF;
      #endif
   if(( G_PTR[ pos_auth + 3 ] & 0xF0 ) == USER_AUTHENTICATION_KEY )
   {
   #ifdef KLOCWORK
   BYTE XDATA * Temp_UAK_Array;
   Temp_UAK_Array = Subscription_GetUAKRef( Get_Assigned_Po_No( CurrentInc ));
   if( Temp_UAK_Array != NULL ) {
   B1_Process ( Temp_UAK_Array,
   Temp_K_Array,
   UAK_LEN );
   }
   #else
   B1_Process ( Subscription_GetUAKRef( Get_Assigned_Po_No( CurrentInc )),
   Temp_K_Array,
   UAK_LEN );
   #endif
   }
   else
   {
   B1_Process( Get_AC_Ptr( ),
   Temp_K_Array,
   AC_LEN );
   }

   /* Copy RAND_P Field !              */
   /* -------------------------------- */
   Mmu_Memcpy( Temp_RAND_Array, &G_PTR[ pos_rand + 2 ], RAND_LEN );
   /* Set RS-Array with random valus.  */
   /* -------------------------------- */
   #ifdef ULE_SUPPORT
   if (supportsDsaa2) {
      Random(Temp_RS_Array, RS_LEN, 0xA3);
      Random(&Temp_RS_Array[RS_LEN], RS_LEN, 0xA3);
      Random(Temp_RAND_F_Array, RAND_LEN, 0xE2);
   } else {
      Random(Temp_RS_Array, RS_LEN, 0xA3);
   }
   #else
   Random( Temp_RS_Array, RS_LEN, 0xA3 );
   #endif

   #ifdef ULE_SUPPORT
   if (supportsDsaa2) {
      A21_2_Process( Temp_K_Array,
                     Temp_RS_Array,
                     &Temp_RS_Array[RS_LEN],
                     Temp_KS_Array );

      A22_2_Process( Temp_KS_Array,
                     Temp_RAND_Array,
                     Temp_RAND_F_Array,
                     Temp_RES_Array );
   } else {
      A21_Process( Temp_K_Array,
                   Temp_RS_Array,
                   Temp_KS_Array );
      A22_Process( Temp_KS_Array,
                   Temp_RAND_Array,
                   Temp_RES_Array );
   }
                                      /* Send Auth Reply Message.         */
                                      /* -------------------------------- */
   send_down_Auth_Reply_FT( Temp_RES_Array, Temp_RAND_F_Array, Temp_RS_Array, supportsDsaa2 );
   #else
   A21_Process( Temp_K_Array,
   Temp_RS_Array,
   Temp_KS_Array );
   A22_Process( Temp_KS_Array,
   Temp_RAND_Array,
   Temp_RES_Array );
   /* Send Auth Reply Message.         */
   /* -------------------------------- */
   send_down_Auth_Reply_FT( Temp_RES_Array, Temp_RS_Array );
   #endif

#ifdef KLOCWORK
FREE_BUFF:
#endif
   Mmu_Free( Temp_K_Array    );
   Mmu_Free( Temp_RS_Array   );
   Mmu_Free( Temp_RAND_Array );
   #ifdef ULE_SUPPORT
   Mmu_Free( Temp_RAND_F_Array );
   #endif
   Mmu_Free( Temp_KS_Array   );
   Mmu_Free( Temp_RES_Array  );
   Mmu_Free( G_PTR );
}

static void T0999( void )
{
   /* TRANSITION:      T0999                                                */
   /* EVENT:           all MM_MMS_xx_RQ                                     */
   /* DESCRIPTION:                                                          */
   /* REFERENCE:       ETS 300 175-5:1996                                   */
   /* STARTING STATE:  inkompatible state                                   */
   /* END STATE:       current state maintained                             */
   /* ----------------------------------------------------------------------*/
   /* Interface App-Layer->NTW-Layer   */
   /* P1: return proc                  */
   /* P2: return msg                   */
   /* P3: return inc                   */
   /* P4: po_no                        */

   /* Interface NTW-Layer->App-Layer   */
   /* P1: result                       */
   /* P2: not used                     */
   /* P3: cid                          */
   /* P4: po_no                        */

   Send_Message_To_APP( PARAMETER2,
   NULL,
   CurrentInc,
   Get_Assigned_Po_No( CurrentInc ),
   FALSE,
   DUMMY_FILL,
   DUMMY_FILL );

#if 0
   KNL_SENDTASK_WP_INC( PARAMETER1,                       /* Proc  */
   PARAMETER2,                       /* msg   */
   FALSE,                            /* P1    */
   0,                                /* P2    */
   CurrentInc,                       /* P3    */
   Get_Assigned_Po_No( CurrentInc ), /* P4    */
   PARAMETER3 );                     /* inc   */
#endif
}

static void T0850( void )
{
   /* TRANSITION:      T0850                                                */
   /* EVENT:           MM_DL_REL_IN_LCE / MM_TIM_CIPHER_01_EXPIRED          */
   /* DESCRIPTION:     Ciphering Procedure                                  */
   /* REFERENCE:       ETS 300 175-5:1996 / 6.5.3                           */
   /* STARTING STATE:  MM_CIPHER_ON                                         */
   /* END STATE:       MM_OPEN                                              */
   /* ----------------------------------------------------------------------*/
   /*           !!! NOTE: !!!          */
   /* TI-Flag Check for the Cipher     */
   /* Reject message is not allowed,   */
   /* because the same transition is   */
   /* used for PT and FT initiated     */
   /* Cipher Switching !               */
   /* Fortunately this is not tested   */
   /* in TBR22. TI-Flag check is only  */
   /* tested for Auth-Reply and        */
   /* Identity-Reply message.          */
   /* (TC_FT_LC_BI_04,TC_FT_LC_BI_05)  */

   /*
   if( ! Check_Ti_Flag( TI_Value_peer_PD_MM ))
   {
   Mmu_Free( G_PTR );
   return;
   }
   */
   /* Send negative confirmation to    */
   /* application layer.               */
   send_up_Confirmation( FALSE );

   /* Stop Supervise Timer.            */
   /* -------------------------------- */
   Stop_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc );
   Mmu_Free( G_PTR );
   send_dl_release_rq( PARTIAL_RELEASE );
   MM_Struct[CurrentInc].Last_State = MM_OPEN;   /*  */
   clearMMState();
}

static void T0851( void )
{
   /* TRANSITION:      T0851                                                */
   /* EVENT:           MM_CIPHER_REJECT_LCE                                 */
   /* DESCRIPTION:     Ciphering Procedure                                  */
   /* REFERENCE:       ETS 300 175-5:1996 / 6.5.3                           */
   /* STARTING STATE:  MM_CIPHER_ON/MM_CIPHER_OFF                           */
   /* END STATE:       MM_OPEN                                              */
   /* ----------------------------------------------------------------------*/
   /*           !!! NOTE: !!!          */
   /* TI-Flag Check for the Cipher     */
   /* Reject message is not allowed,   */
   /* because the same transition is   */
   /* used for PT and FT initiated     */
   /* Cipher Switching !               */
   /* Fortunately this is not tested   */
   /* in TBR22. TI-Flag check is only  */
   /* tested for Auth-Reply and        */
   /* Identity-Reply message.          */
   /* (TC_FT_LC_BI_04,TC_FT_LC_BI_05)  */

   /*
   if( ! Check_Ti_Flag( TI_Value_peer_PD_MM ))
   {
   Mmu_Free( G_PTR );
   return;
   }
   */
   /* Stop Supervise Timer.            */
   /* -------------------------------- */
   Stop_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc );
   Mmu_Free( G_PTR );
   send_dl_release_rq( PARTIAL_RELEASE );

   /* Send negative confirmation to    */
   /* application layer.               */
   send_up_Confirmation( FALSE );
   clearMMState();
}

#ifdef DECT_DEBUG_USER_MM_PRIMITIVE
LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
{
   BYTE i;

   for (i = 0; tablePtr[i].key != 0xFF; i++) {
      if (tablePtr[i].key == key) {
         break;
      }
   }
   return tablePtr[i].string;
}
#endif

// ***********************************************************************************************
// ***********************************************************************************************
void DECODE_MM(void)
{
   // For MM message queue implemetation, the task queue is used.
   // It is not perfect solution but is enough for the current application.
   if (CurrentState != MM_OPEN) {
      switch (CurrentMessage) {
         case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
         case MM_MMS_AUTHENTICATE_PT_RQ:
         #ifdef ULE_SUPPORT
         case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
         #endif
         case MM_MMS_AUTHENTICATE_USER_RQ:
         case MM_MMS_KEY_ALLOCATION_RQ:
         case MM_MMS_INFO_SUGGEST_RQ:
         case MM_MMS_CIPHER_ON_RQ:
         case MM_MMS_CIPHER_OFF_RQ:
         case MM_MMS_IDENTITY_RQ:
            // if portable number is maintained with current instance
            //    enqueue the message again
            // else
            //    give up the message
            if (Get_Assigned_Po_No(CurrentInc) == PARAMETER4) {
               KNL_SENDTASK_NP_WP_INC(ProcId, CurrentMessage, G_PTR, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4, CurrentInc);
            } else {
               KNL_T0000();
            }
            return;

         default:
            break;
      }
   }

   #ifdef DECT_DEBUG_USER_MM_PRIMITIVE
	DECT_DEBUG_USER_MM_PRIMITIVE("[%02x]%s, %s, %02x, %02x %02x %02x %02x\n", CurrentMessage, getDebugStringRef(CurrentMessage, messageStringTable),
	getDebugStringRef(CurrentState, stateStringTable), CurrentInc, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
   #endif

   #ifdef CONFIG_REPEATER_SUPPORT
   if (CurrentMessage == MM_TIM_REPEATER_01_EXPIRED) {
      Repeater_Reg = REPEATER_REGISTRATION_STATE_IDLE;
      return;
   }
   #endif

   switch (CurrentState)
   {
      /**********************************
       MM_OPEN State
      **********************************/
      case MM_OPEN:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:  /*  IN LINE CODE T0200    */
            {
               /* TRANSITION:      T0200                                                */
               /* EVENT:           MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ                    */
               /* DESCRIPTION:     Terminating Access Rights Procedure                  */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.5.2                          */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_TERMINATING_ACCESS_RIGHTS                         */
               /* ----------------------------------------------------------------------*/
               /* Check assigned po_no.            */
               if( Get_Assigned_Po_No( CurrentInc ) != PARAMETER4 )
               return;
               /* Set return values.               */
               /* -------------------------------- */
               /* P1: return proc                  */
               /* P2: return msg                   */
               /* P3: return inc                   */
               MM_Struct[CurrentInc].Return_Proc = PARAMETER1;
               MM_Struct[CurrentInc].Return_Msg  = PARAMETER2;
               MM_Struct[CurrentInc].Return_Inc  = PARAMETER3;
               /* Invoke the Access Rights         */
               /* Terminating procedure            */
               /* -------------------------------- */
               /* Send the Access Rights Terminate */
               /* Request.                         */
               send_down_AR_Terminate_Request( Get_Assigned_Po_No( CurrentInc ));
               /* Access Rights Termination        */
               /* -------------------------------- */
               /* Timer:    <MM_access.02>         */
               /* Duration: 10 seconds             */
               Start_Pro_Timer( TIMER_MM_ACCESS_02, CurrentInc );
               KNL_Transit( MM_TERMINATING_ACCESS_RIGHTS );
            }
            return;

            case MM_MMS_AUTHENTICATE_PT_RQ:  /*  IN LINE CODE T0300    */
            {
               /* TRANSITION:      T0300                                                */
               /* EVENT:           MM_MMS_AUTHENTICATE_PT_RQ                            */
               /* DESCRIPTION:     Authentication Procedure (using UAK-Key)             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.3                            */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_AUTH_OF_PT                                        */
               /* ----------------------------------------------------------------------*/
               /* Check assigned po_no.            */
               if( Get_Assigned_Po_No( CurrentInc ) != PARAMETER4 )
               return;
               /* Set return values.               */
               /* -------------------------------- */
               /* P1: return proc                  */
               /* P2: return msg                   */
               /* P3: return inc                   */
               MM_Struct[CurrentInc].Return_Proc = PARAMETER1;
               MM_Struct[CurrentInc].Return_Msg  = PARAMETER2;
               MM_Struct[CurrentInc].Return_Inc  = PARAMETER3;

               // TODO: Now is done but later, will be more checked. checkpoint
               #ifdef ULE_SUPPORT
                  #ifdef KLOCWORK
               if (VALID_PORTABLE_ULE(PARAMETER4, PORTABLE_ULE)) {
                  #else
               if (IsValidPortableNo(PARAMETER4, PORTABLE_ULE)) {
                  #endif
                  MM_Struct[CurrentInc].supportsDsaa2 = YES;
               }
               #endif
               /* Invoke Authentication of PT      */
               /* Procedure. The UAK-Key is used   */
               /* for Authentication and a new     */
               /* DCK-Key is assigned.             */
               MM_Struct[CurrentInc].Starting_State = MM_OPEN;
               MM_Struct[CurrentInc].Last_State = MM_OPEN;                  /*  */
               KNL_SENDTASK_INC( MM, MM_AUTHENTICATE_PT_RQ, CurrentInc );
               KNL_Transit( MM_AUTH_OF_PT );
            }
            return;

            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            {
               /* TRANSITION:                                                           */
               /* EVENT:           MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ                 */
               /* DESCRIPTION:     Authentication Procedure (using UAK-Key)             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.3                            */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_AUTH_OF_PT                                        */
               /* ----------------------------------------------------------------------*/
               /* Check assigned po_no.            */
               if (Get_Assigned_Po_No(CurrentInc) != PARAMETER4) {
                  return;
               }
               /* Set return values.               */
               /* -------------------------------- */
               /* P1: return proc                  */
               /* P2: return msg                   */
               /* P3: return inc                   */
               MM_Struct[CurrentInc].Return_Proc = PARAMETER1;
               MM_Struct[CurrentInc].Return_Msg  = PARAMETER2;
               MM_Struct[CurrentInc].Return_Inc  = PARAMETER3;

               MM_Struct[CurrentInc].supportsDsaa2 = YES;
               MM_Struct[CurrentInc].makingDCKCCM = YES;

               /* Invoke Authentication of PT      */
               /* Procedure. The UAK-Key is used   */
               /* for Authentication and a new     */
               /* DCK-Key is assigned.             */
               MM_Struct[CurrentInc].Starting_State = MM_OPEN;
               MM_Struct[CurrentInc].Last_State = MM_OPEN;                  /*  */
               KNL_SENDTASK_INC( MM, MM_AUTHENTICATE_PT_RQ, CurrentInc );
               KNL_Transit( MM_AUTH_OF_PT );
            }
            return;
            #endif

            case MM_MMS_AUTHENTICATE_USER_RQ:  /*  IN LINE CODE T0301    */
            {
               /* TRANSITION:      T0301                                                */
               /* EVENT:           MM_MMS_AUTHENTICATE_USER_RQ                          */
               /* DESCRIPTION:     Authentication Procedure (using UPI-Key)             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.3                            */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_AUTH_OF_USER                                      */
               /* ----------------------------------------------------------------------*/
               /* Check assigned po_no.            */
               if( Get_Assigned_Po_No( CurrentInc ) != PARAMETER4 )
               return;
               /* Set return values.               */
               /* -------------------------------- */
               /* P1: return proc                  */
               /* P2: return msg                   */
               /* P3: return inc                   */
               MM_Struct[CurrentInc].Return_Proc = PARAMETER1;
               MM_Struct[CurrentInc].Return_Msg  = PARAMETER2;
               MM_Struct[CurrentInc].Return_Inc  = PARAMETER3;
               /* Invoke Authentication of User    */
               /* Procedure. The UPI-Key is used   */
               /* for Authentication.              */
               MM_Struct[CurrentInc].Starting_State = MM_OPEN;
               KNL_SENDTASK_INC( MM, MM_AUTHENTICATE_USER_RQ, CurrentInc );
               KNL_Transit( MM_AUTH_OF_USER );
            }
            return;

            case MM_MMS_KEY_ALLOCATION_RQ:  /*  IN LINE CODE T0400    */
            {
               /* TRANSITION:      T0400                                                */
               /* EVENT:           MM_MMS_KEY_ALLOCATION_RQ                             */
               /* DESCRIPTION:     Key Allocation Procedure                             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.6                            */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_KEY_ALLOCATION                                    */
               /* ----------------------------------------------------------------------*/
               /* Check assigned po_no.            */
               if( Get_Assigned_Po_No( CurrentInc ) != PARAMETER4 )
               return;
               /* Set return values.               */
               /* -------------------------------- */
               /* P1: return proc                  */
               /* P2: return msg                   */
               /* P3: return inc                   */
               MM_Struct[CurrentInc].Return_Proc = PARAMETER1;
               MM_Struct[CurrentInc].Return_Msg  = PARAMETER2;
               MM_Struct[CurrentInc].Return_Inc  = PARAMETER3;
               /* Invoke Key Allocation Procedure. */
               /* The AC-Key is used for           */
               /* Authentication.                  */
               MM_Struct[CurrentInc].Starting_State = MM_OPEN;
               KNL_SENDTASK_INC( MM, MM_KEY_ALLOCATION_RQ, CurrentInc );
               KNL_Transit( MM_KEY_ALLOCATION );
            }
            return;

            case MM_INFO_REQUEST_LCE:  /*  IN LINE CODE T0600    */
            {
               /* TRANSITION:      T0600                                                */
               /* EVENT:           MM_MMS_INFO_SUGGEST_RQ                               */
               /* DESCRIPTION:     Location Registration Procedure                      */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.4.3                          */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_LOCATION_UPDATE                                   */
               /* ----------------------------------------------------------------------*/
               #ifdef CONFIG_REPEATER_SUPPORT
               BYTE  pos, po_no;
               BYTE  iwuptr[10];
               FPTR  rfpi_ptr;
               WORD  length;

               struct HLI_Header* pxHeader = NULL;

               // Ignore message with wrong TI-Flag setting !
               if( ! Check_Ti_Flag( TI_Value_peer_PD_MM ))
               {
                  Mmu_Free( G_PTR );
                  return;
               }

               po_no = Get_Assigned_Po_No(CurrentInc);
               #ifdef KLOCWORK
               if (!VALID_PORTABLE_REP(po_no, PORTABLE_REP))
               #else
               if (!IsValidPortableNo(po_no, PORTABLE_REP))
               #endif
               {
                  Mmu_Free( G_PTR );
                  return;
               }

               /* Check IWU-to-IWU Info. in MM_INFO */
               pos = scan_IE(G_PTR, IWU_TO_IWU, 3, 12);
               DECT_DEBUG_USER_MM_DATA("MM Info[%02x %02x]:%02x %02x\n", po_no, Repeater_PoNo, G_PTR[pos + 2], G_PTR[pos + 3]);
               if (pos != 0) {
                  po_no = (Repeater_PoNo - REP_DEVICE_OFFSET) / MAX_INSTANCES_PER_REPEATERS;
                  /*Check for PD user specific=0x00 and Descriminitaor for EMC=1*/
                  if ((G_PTR[pos + 2] == 0xD6) && (G_PTR[pos + 3] == 0x27) && (G_PTR[pos + 4] == 0x80)) {
                     DECT_DEBUG_USER_MM_DATA("[MM] WRS OA&M / Remote Configuration Call for WRS-RPN\n");
                     Mmu_Memset(iwuptr, 0x00, 10);
                     rfpi_ptr = Get_Rfpi_Ptr( );

                     // Send Response of MM-Info Request
                     iwuptr[0] = 0xD6;
                     iwuptr[1] = 0x27;
                     iwuptr[2] = 0x80;
                     iwuptr[3] = 0x83;
                     iwuptr[4] = rfpi_ptr[4] + po_no + 1;
                     send_down_MM_Info_Accept(iwuptr);

                     if (Repeater_Reg == REPEATER_REGISTRATION_STATE_ONGOING) {
                        Repeater_Reg = REPEATER_REGISTRATION_STATE_FINISHED;
                        // Send Repeater Subscription Information to APP.
                        length = sizeof(FT_REP_SUBSCRIPTION) * MAX_INSTANCES_PER_REPEATERS + sizeof(struct HLI_Header);
                        pxHeader = (struct HLI_Header*)Mmu_Malloc (length);
                        pxHeader->length = length;
                        pxHeader->next = NULL;

                        for ( pos = 0;  pos < MAX_INSTANCES_PER_REPEATERS;  pos++) {
                           Subscription_GetRegistrationData(po_no + pos + REP_DEVICE_OFFSET,
                                                            (FPTR)((unsigned long)pxHeader) + sizeof(FT_REP_SUBSCRIPTION) * pos + sizeof(struct HLI_Header));
                        }

                        if (IFX_DBGA_GetStackModuleDebugID() & IFX_DECT_STACK_DEBUG_ID_MM_DATA )
                        {

                           FPTR RepSubsInfo;

                           RepSubsInfo = (FPTR)(pxHeader) + sizeof(struct HLI_Header);
                           printf("     HLI-Length: %04x %02x %02x %02x\n", length, sizeof(struct HLI_Header), sizeof(FT_SUBSCRIPTION), sizeof(FT_REP_SUBSCRIPTION));

                           for ( pos = 0;  pos < MAX_INSTANCES_PER_REPEATERS;  pos++) {
                                 printf("     Status: %02x\n",
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+0]);
                                 printf("     IPUI: %02x %02x %02x %02x %02x\n",
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+1],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+2],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+3],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+4],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+5]);
                                 printf("     TPUI: %02x %02x %02x\n",
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+6],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+7],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+8]);
                                 printf("     UAK: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n",
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+9],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+10],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+11],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+12],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+13],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+14],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+15],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+16],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+17],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+18],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+19],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+20],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+21],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+22],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+23],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+24]);
                                 printf("     DCK: %02x %02x %02x %02x %02x %02x %02x %02x\n",
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+25],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+26],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+27],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+28],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+29],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+30],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+31],
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+32]);
                                 printf("     Term Cap: %08x\n", 
                                                 RepSubsInfo[sizeof(FT_REP_SUBSCRIPTION)*pos+33]);
                              }
                           }

                        // Exception!! length is now bigger than MAX(250) and over the 255 and length field is cutted to short!!
                        // Temporally, limit to MAX value if it run over
                        // This must be resolved later by __attribute__((packed))!!
                        if( length > IFX_IPC_DECT_MAX_DATA_SIZE )
                           pxHeader->length = IFX_IPC_DECT_MAX_DATA_SIZE;

                        Send_Message_To_APP(FP_PORTABLE_REGISTERED_IN_MM,
                                            (FPTR)pxHeader,
                                            CurrentInc,
                                            po_no + REP_DEVICE_OFFSET,
                                            0,
                                            0,
                                            0
                                            );
                     }
                  }
               }
               #endif
               Mmu_Free(G_PTR);
            }
            return;

            case MM_MMS_INFO_SUGGEST_RQ:  /*  IN LINE CODE T0600    */
            {
               /* TRANSITION:      T0600                                                */
               /* EVENT:           MM_MMS_INFO_SUGGEST_RQ                               */
               /* DESCRIPTION:     Location Registration Procedure                      */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.4.3                          */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_LOCATION_UPDATE                                   */
               /* ----------------------------------------------------------------------*/
               /* Check assigned po_no.            */
               if( Get_Assigned_Po_No( CurrentInc ) != PARAMETER4 ) {
                  Mmu_Free(G_PTR);
                  return;
               }
               /* Set return values.               */
               /* -------------------------------- */
               /* P1: return proc                  */
               /* P2: return msg                   */
               /* P3: return inc                   */
               MM_Struct[CurrentInc].Return_Proc = PARAMETER1;
               MM_Struct[CurrentInc].Return_Msg  = PARAMETER2;
               MM_Struct[CurrentInc].Return_Inc  = PARAMETER3;
               /* Invoke the Location Registration */
               /* procedure.                       */
               /* -------------------------------- */
               send_down_Info_Suggest( );
               /* Start Locate Timer               */
               /* -------------------------------- */
               /* Timer:    MM-<locate.1>          */
               /* Duration: 10 seconds             */
               Start_Pro_Timer( TIMER_MM_LOCATE_01, CurrentInc  );
               KNL_Transit( MM_LOCATION_UPDATE );
            }
            return;

            case MM_MMS_CIPHER_ON_RQ:  /*  IN LINE CODE T0800    */
            {
               /* TRANSITION:      T0800                                                */
               /* EVENT:           MM_MMS_CIPHER_ON_RQ                                  */
               /* DESCRIPTION:     Ciphering Procedure                                  */
               /* REFERENCE:       ETS 300 175-5:1996 / 6.5.3                           */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_CIPHER_ON                                         */
               /* ----------------------------------------------------------------------*/
            #ifdef CONFIG_REPEATER_SUPPORT
               BYTE  po_no;
            #endif
               /* Check assigned po_no.            */
               if( Get_Assigned_Po_No( CurrentInc ) != PARAMETER4 )
               {
               return;
               }
               /* Set return values.               */
               /* -------------------------------- */
               /* P1: return proc                  */
               /* P2: return msg                   */
               /* P3: return inc                   */
               MM_Struct[CurrentInc].Return_Proc = PARAMETER1;
               MM_Struct[CurrentInc].Return_Msg  = PARAMETER2;
               MM_Struct[CurrentInc].Return_Inc  = PARAMETER3;

               /* Cancel Encryption if existing     */
               /* Connection is encrypted already.  */
               /* --------------------------------  */
               /* NOTE: the gigaset handy does not  */
               /* allow encryption request on the   */
               /* connection which already encrypted*/
            #ifdef CONFIG_REPEATER_SUPPORT
               DECT_DEBUG_USER_MM_DATA("[MM] CipherDevice:%02x %02x %02x\n",
                                    MM_Struct[CurrentInc].DeviceType, Get_Encryption_State ( CurrentInc ), isRekeyingSupported(PARAMETER4));
               if (MM_Struct[CurrentInc].Return_Proc != LC_REP)
            #endif
               {
                  #ifdef CONFIG_EARLY_ENCRYPTION
                  if (Get_Encryption_State(CurrentInc) && !isRekeyingSupported(PARAMETER4))
                  #else
                  if( Get_Encryption_State ( CurrentInc ))
                  #endif
                  {
                     send_up_Confirmation( TRUE );
                     return;
                  }
               }

               /* Switching Cipher on required.    */
            #ifdef CONFIG_REPEATER_SUPPORT
               {
                  MM_Struct[CurrentInc].Repeater_Idx = 0;
                  MM_Struct[CurrentInc].Repeater_Num = Get_RepNum_Encryption(CurrentInc);
                  MM_Struct[CurrentInc].Rep_Lbn = (MM_Struct[CurrentInc].Repeater_Num >> 4) & 0x0F;
                  MM_Struct[CurrentInc].Repeater_Num &= 0x0F;
                  PmidBuff[0] = CurrentInc;
                  PmidBuff[1] = MM_Struct[CurrentInc].Repeater_Idx;
                  Get_RepPmid_Encryption(PmidBuff);
                  po_no = Subscription_GetPortableNoFromPMID(&PmidBuff[2]);
                  DECT_DEBUG_USER_MM_DATA("[MM] Cipher On:%02x %02x %02x\n",
                  MM_Struct[CurrentInc].Repeater_Num, MM_Struct[CurrentInc].Rep_Lbn, po_no );
                  #ifdef KLOCWORK
                  //if ((VALID_PORTABLE_DECT(po_no, PORTABLE_DECT) || VALID_PORTABLE_REP(po_no, PORTABLE_REP)) &&
                  if ((VALID_PORTABLE_ALL(po_no, PORTABLE_ALL)) &&
                  #else
                  //if ((IsValidPortableNo(po_no, PORTABLE_DECT) || IsValidPortableNo(po_no, PORTABLE_REP)) &&
                  if ((IsValidPortableNo(po_no, PORTABLE_ALL)) &&
                  #endif
                       (MM_Struct[CurrentInc].Repeater_Num == 1)) {
                     // There is no repeater bwtween FT and PT. So, same as normal DECT connection
                     if (MM_Struct[CurrentInc].Return_Proc != LC_REP) {
                        send_down_Cipher_Key( );
                        send_down_Cipher_Request( TRUE, TI_Value_own_PD_MM );
                     } else {
                        send_down_Rep_Cipher_Key( po_no );
                        #if 1  // JONATHAN_BUG_FIX_160831
                        KNL_SENDTASK_WP_INC( MM, MM_DL_ENC_IND_LCE, TRUE, 0, 0, TRUE, CurrentInc );
                        #else
                        KNL_SENDTASK_WP_INC( MM, MM_DL_ENC_IND_LCE, CurrentInc, 0, 0, TRUE, CurrentInc );
                        #endif
                     }
                  } else {
                     MM_Struct[CurrentInc].Rep_PoNo = po_no;
                     if (MM_Struct[CurrentInc].Return_Proc != LC_REP) {
                        PARAMETER4 = 1;
                     } else if (MM_Struct[CurrentInc].Repeater_Idx+1 == MM_Struct[CurrentInc].Repeater_Num) {
                        #ifdef FAST_HANDOVER    // Fast Handover make no Bearer_CFM from Repeater to Handset
                        KNL_SENDTASK_WP_INC( MM, MM_REP_ACCESS_CFM, 0, 0, 1, 0, CurrentInc );
                        #endif
                        PARAMETER4 = 0;
                     } else {
                        #ifdef FAST_HANDOVER    // Fast Handover make no Bearer_CFM from Repeater to Handset
                        KNL_SENDTASK_WP_INC( MM, MM_REP_ACCESS_CFM, 0, 0, 1, 0, CurrentInc );
                        #endif
                        PARAMETER4 = 0;
                     }
                     KNL_SENDTASK_WP_INC( LAP_REP, LAP_REP_ACCESS_REQ, CurrentInc, MM_Struct[CurrentInc].Rep_Lbn,
                                          MM_Struct[CurrentInc].Repeater_Idx, PARAMETER4, CurrentInc );
                  }
               }
               #else
               {
                  send_down_Cipher_Key( );
                  send_down_Cipher_Request( TRUE, TI_Value_own_PD_MM );
               }
               #endif
               /* Cipher Switching Supervising     */
               /* -------------------------------- */
               /* Timer:     <MM_cipher.01>        */
               /* Duration:  10 seconds            */
               Start_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc  );
               MM_Struct[CurrentInc].Last_State = MM_OPEN;   /*  */
               KNL_Transit( MM_CIPHER_ON );
            }
            return;

            case MM_MMS_CIPHER_OFF_RQ:  /*  IN LINE CODE T0801    */
            {
               /* TRANSITION:      T0801                                                */
               /* EVENT:           MM_MMS_CIPHER_OFF_RQ                                 */
               /* DESCRIPTION:     Ciphering Procedure                                  */
               /* REFERENCE:       ETS 300 175-5:1996 / 6.5.3                           */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_CIPHER_OFF                                        */
               /* ----------------------------------------------------------------------*/
               /* Check assigned po_no.            */
               if( Get_Assigned_Po_No( CurrentInc ) != PARAMETER4 )
               return;
               /* Set return values.               */
               /* -------------------------------- */
               /* P1: return proc                  */
               /* P2: return msg                   */
               /* P3: return inc                   */
               MM_Struct[CurrentInc].Return_Proc = PARAMETER1;
               MM_Struct[CurrentInc].Return_Msg  = PARAMETER2;
               MM_Struct[CurrentInc].Return_Inc  = PARAMETER3;
               /* Switching Cipher off required.   */
               send_down_Cipher_Request( FALSE, TI_Value_own_PD_MM );
               /* Cipher Switching Supervising     */
               /* -------------------------------- */
               /* Timer:     <MM_cipher.01>        */
               /* Duration:  10 seconds            */
               Start_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc  );
               MM_Struct[CurrentInc].Last_State = MM_OPEN;   /*  */
               KNL_Transit( MM_CIPHER_OFF );
            }
            return;

            case MM_MMS_IDENTITY_RQ:  /*  IN LINE CODE T0900    */
            {
               /* TRANSITION:      T0900                                                */
               /* EVENT:           MM_MMS_IDENTITY_RQ                                   */
               /* DESCRIPTION:     Identity Request                                     */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.2.1                          */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_IDENTITY                                          */
               /* ----------------------------------------------------------------------*/
               /* Check assigned po_no.            */
               if( Get_Assigned_Po_No( CurrentInc ) != PARAMETER4 )
               return;
               /* Set return values.               */
               /* -------------------------------- */
               /* P1: return proc                  */
               /* P2: return msg                   */
               /* P3: return inc                   */
               MM_Struct[CurrentInc].Return_Proc = PARAMETER1;
               MM_Struct[CurrentInc].Return_Msg  = PARAMETER2;
               MM_Struct[CurrentInc].Return_Inc  = PARAMETER3;
               send_down_Identity_Request( );
               /* Identity Request Supervising     */
               /* -------------------------------- */
               /* Timer:     <MM_ident.01>         */
               /* Duration:  10 seconds            */
               Start_Pro_Timer( TIMER_MM_IDENTITY_01, CurrentInc  );
               KNL_Transit( MM_IDENTITY );
            }
            return;

            case MM_ACCESS_RIGHTS_REQUEST_LCE:  /*  IN LINE CODE T0100    */
            {
               /* TRANSITION:      T0100                                                */
               /* EVENT:           MM_ACCESS_RIGHTS_REQUEST_LCE                         */
               /* DESCRIPTION:     Obtaining Access Rights Procedure                    */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.5                            */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_KEY_ALLOCATION / MM_OPEN                          */
               /* ----------------------------------------------------------------------*/
               BYTE pos;
               #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
               BYTE value;
               #endif
               //BYTE len, i;
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_peer_PD_MM ))
               {
               Mmu_Free( G_PTR );
               return;
               }
               /* Base Station set to registration */
               /* mode ?                           */
               /* -------------------------------- */
               #ifdef CONFIG_REPEATER_SUPPORT
               if( !Check_Reg_Mode() && (Repeater_Reg == REPEATER_REGISTRATION_STATE_IDLE) )
               #else
               if( !Check_Reg_Mode() )
               #endif
               {
                  send_down_AR_Reject( INCOMPATIBLE_SERVICE_REJ );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }
               /* Mandatory << AUTH >> IE there ?  */
               /* -------------------------------- */
               pos = scan_IE( G_PTR, AUTH_TYPE, 3, 4 );
               if( pos == 0 )
               {
                  send_down_AR_Reject( INFORMATION_ELEMENT_ERROR );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }
               /* Determine the requested          */
               /* Authentication Algorithm.        */
               /* -------------------------------- */
               /* Only DSAA/AC Algorithm is        */
               /* supported !                      */
               #ifdef ULE_SUPPORT
               if( ! ((( G_PTR[ pos + 2 ] == DSAA ) || ( G_PTR[ pos + 2 ] == DSAA2 )) &&
                     (( G_PTR[ pos + 3 ] & 0xF0 ) == AUTHENTICATION_CODE )))
               #else
               if( ! (( G_PTR[ pos + 2 ]          == DSAA ) &&
               (( G_PTR[ pos + 3 ] & 0xF0 ) == AUTHENTICATION_CODE )))
               #endif
               {
                  send_down_AR_Reject( AUTH_ALGORITHM_NOT_SUPPORTED );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }

               #ifdef ULE_SUPPORT
               /* Remark: Speedphone-30 HS is configered "AuthAlgorithm = DSAA2" in ACCESS_RIGHTS_REQUEST and "terminal capability.DSAA2 = 1" */
               /* ==> This is ok, but our BS set auth_type=DSAA in AuthOfPT request(in next Locate-Request procedure) but Speedphone30 use the DSAA2   */
               /* Refer only the supported Algorithm here and reset again while checking the terminal capability this is not the ULE device*/
               MM_Struct[CurrentInc].supportsDsaa2 = NO;
               if( G_PTR[ pos + 2 ] == DSAA2 ) {
                 MM_Struct[CurrentInc].supportsDsaa2 = YES;
               }
               #endif

               /* Mandatory << PORTABLE ID >> IE   */
               /* there ?                          */
               /* -------------------------------- */
               pos = scan_IE( G_PTR, PORTABLE_IDENTITY, 7, 7 );
               if( pos == 0 )
               {
                  send_down_AR_Reject( INFORMATION_ELEMENT_ERROR );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }
               /* Mandatory << PORTABLE ID >> of   */
               /* type IPUI ?                      */
               /* -------------------------------- */
               if( ! (( G_PTR[ pos + 2 ] & 0x7F ) == IDENTITY_TYP_IPUI ))
               {
                  send_down_AR_Reject( INVALID_IE_CONTENTS_REJ );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }

               /* Store the received IPUI identity */
               /* -------------------------------- */
               Mmu_Memcpy( MM_Struct[CurrentInc].IPUI_Array, &G_PTR[ pos + 4 ], 5 );

               #ifdef GIGASET_ETP
               // Check ESCAPE_TO_PROPRIETARY Info. for Gigaset PP and backup it for sending to APP with FP_PORTABLE_REGISTERED_IN_MM message.
               Mmu_Memset( MM_Struct[CurrentInc].ETP_Array, 0x00, MAX_GIGASET_ETP_SIZE );
               pos = scan_IE( G_PTR, ESCAPE_TO_PROPRIETARY, 5, MAX_GIGASET_ETP_SIZE );
               if (pos != 0) {
                  Mmu_Memcpy( &MM_Struct[CurrentInc].ETP_Array[0], G_PTR, sizeof(struct HLI_Header)+2 );
                  ((struct HLI_Header *) MM_Struct[CurrentInc].ETP_Array)->length = 2 + sizeof(struct HLI_Header) + G_PTR[ pos + 1 ] + 2;
                  Mmu_Memcpy( &MM_Struct[CurrentInc].ETP_Array[sizeof(struct HLI_Header)+2], &G_PTR[ pos ], G_PTR[ pos + 1 ] + 2 );
               }
               #endif

             #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
               //MM_Struct[CurrentInc].supportsDsaa2 = NO;
               MM_Struct[CurrentInc].DeviceType = DECT_DEVICE;
               /*  << TERMINAL_CAPABILITY >> is there?  */
               /* -------------------------------- */
               pos = scan_IE(G_PTR, TERMINAL_CAPABILITY, 3, MAX_TERMINAL_CAPABILITY_IE_SIZE); // the Max_Length = 22
               if (pos == 0) {
                  send_down_AR_Reject( INFORMATION_ELEMENT_ERROR );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  DECT_DEBUG_USER_MM_DATA("[MM] No Terminal Cap IE\n");
                  return;
               }

               value = getTerminalCapabilityValue(&G_PTR[pos], 4, 8); // To check ULE supported(4h)
               if ((value != 0xFF) && (value & 0x04)) { // ULE supported
                  MM_Struct[CurrentInc].DeviceType = ULE_DEVICE;
               } else {
               /* Reset(supportDsaa2=FALSE) if the terminal capability indicate not supporting the ULE */
               /* => Workaround for the speedphone 30/50 behavior to use the DSAA */
                  MM_Struct[CurrentInc].supportsDsaa2 = NO;

                  value = getTerminalCapabilityValue(&G_PTR[pos], 4, 2); // To check WRS supported
                  if ((value != 0xFF) && (value & 0x02)) { // Repeater; WRS supported
                     #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
                     if (Feature_Repeater != 0) {
                        MM_Struct[CurrentInc].DeviceType = REP_DEVICE;
                        MM_Struct[CurrentInc].supportsDsaa2 = NO;
                     } else
                     #endif
                     {
                        send_down_AR_Reject(INCOMPATIBLE_SERVICE_REJ);
                        Mmu_Free( G_PTR );
                        send_dl_release_rq( PARTIAL_RELEASE );
                        clearMMState();
                        return;
                     }
                  }
               }
               #if defined(CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT)
               DECT_DEBUG_USER_MM_DATA("[MM] PT Device:%02x %02x %02x\n", MM_Struct[CurrentInc].DeviceType, Feature_Repeater, MM_Struct[CurrentInc].supportsDsaa2);
               #else
               DECT_DEBUG_USER_MM_DATA("[MM] PT Device:%02x %02x %02x\n", MM_Struct[CurrentInc].DeviceType, 0, MM_Struct[CurrentInc].supportsDsaa2);
               #endif

               //MM_Struct[CurrentInc].supportsDsaa2 = isDsaa2Supported(&G_PTR[pos]);
         #endif //#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)

               /* Registration slot available ?    */
               /* -------------------------------- */
               /* Registration is possible, when   */
               /* at least one slot is free, or    */
               /* the portable is already known !  */
               // Need to modification. JONATHAN_150810
               #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT)
               if ( !Subscription_IsRegistrationPossible(MM_Struct[CurrentInc].IPUI_Array,MM_Struct[CurrentInc].DeviceType) )
               #else
               if( ! Subscription_IsRegistrationPossible( MM_Struct[CurrentInc].IPUI_Array ))
               #endif
               {
                  #ifdef CONFIG_REPEATER_SUPPORT
                  DECT_DEBUG_USER_MM_DATA("[MM] RegNotPossible:%02x %02x %02x\n", MM_Struct[CurrentInc].DeviceType, Repeater_Reg, MM_Struct[CurrentInc].supportsDsaa2);
                  #endif
                  Clear_Reg_Mode(CurrentInc, INSUFFICIENT_MEMORY);
                  /*
                  KNL_SENDTASK( ME, ME_A44_CLEAR_RQ_DIS );
                  Send_Message_To_APP(FP_PORTABLE_REGISTER_FAIL_IN_MM,
                  NULL,
                  CurrentInc,
                  DUMMY_FILL,
                  DUMMY_FILL,
                  DUMMY_FILL,
                  INSUFFICIENT_MEMORY );
                  */
                  /* For TBR22 test case  */
                  /* TC_FT_LC_BI_07       */
                  send_down_AR_Reject( INSUFFICIENT_MEMORY );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }

               /* -------------------------------- */
               /* Registration is possible !       */
               /* -------------------------------- */

               /* Optional << MODEL IDENTIFIER >>  */
               /* IE there ?                       */
               /* -------------------------------- */
               /* In case of a PRODECT V2.0        */
               /* Portable, the Model Identifier   */
               /* Value is stored.                 */
               MM_Struct[CurrentInc].Model_Id = 0xFF;

               pos = scan_IE( G_PTR, MODEL_IDENTIFIER, 3, 3 );
               if( pos != 0 )
               {
               if(( G_PTR[ pos + 2 ] == HIBYTE(First_EMC_Code)) &&
               ( G_PTR[ pos + 3 ] == LOBYTE(First_EMC_Code)  ))
               {
               MM_Struct[CurrentInc].Model_Id = G_PTR[ pos + 4 ];
               }
                // Added by radvajesh.M since model id was not stored if FMC not matched
                MM_Struct[CurrentInc].Model_Id = G_PTR[ pos + 4 ];
               }
               /*Separate EMC by SPP500 for DT extended feature in IWU to IWU*/
               pos = scan_IE( G_PTR, IWU_TO_IWU, 3, 10 );
               if( pos != 0 )
               {
                  /*Check for PD user specific=0x00 and Descriminitaor for EMC=1*/
                  if(((G_PTR[ pos + 2 ] & 0x3F) == 0x00) && (((G_PTR[ pos + 3 ] & 0x7F) == 0x01)))
                  //if(1)
                  {
                     DECT_DEBUG_USER_MM_DATA("[MM] EMC By PT: %02x %02x\n",G_PTR[pos+4],G_PTR[pos+5]);
                  MM_Struct[CurrentInc].EMC_Array[0] = G_PTR[ pos + 4 ];
                  MM_Struct[CurrentInc].EMC_Array[1] = G_PTR[ pos + 5 ];
                  }
                  else
                  {
                     DECT_DEBUG_USER_MM_DATA("[MM] Wrong EMC Encoding\n");
                  }
               }

               /* Block registration of a further  */
               /* portable !                       */
               /* -------------------------------- */
               #if 0
               Set_Reg_Mode_Ongoing( );
               #else
               pos = Get_Assigned_Po_No( CurrentInc );
               KNL_SENDTASK( ME, ME_A44_CLEAR_RQ_DIS );
               #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
               if (MM_Struct[CurrentInc].DeviceType != REP_DEVICE) {
                  Send_Message_To_APP(FP_PORTABLE_REGISTER_ONGOING_IN_MM,
                                      NULL,
                                      CurrentInc,
                                      pos, //po_no
                                      MM_Struct[CurrentInc].Model_Id,
                                      DUMMY_FILL,
                                      DUMMY_FILL );
               }
               #endif
               #endif
               Mmu_Free( G_PTR );

               /* Invoke Key Allocation procedure  */
               /* -------------------------------- */
               MM_Struct[CurrentInc].Starting_State = MM_OBTAIN_ACCESS_RIGHTS;
               KNL_SENDTASK_WP_INC( MM, MM_KEY_ALLOCATION_RQ,
               MM,                    /* P1 = return process         */
               MM_KEY_ALLOCATION_CFM, /* P2 = return message         */
               CurrentInc,            /* P3 = return incarnation     */
               0xFF,                  /* P4 = portable number        */
               CurrentInc );
               KNL_Transit( MM_KEY_ALLOCATION );
            }
            return;

            case MM_ACCESS_RIGHTS_TERMINATE_REQUEST_LCE:  /*  IN LINE CODE T0220    */
            {
               /* TRANSITION:      T0220                                                */
               /* EVENT:           MM_ACCESS_RIGHTS_TERMINATE_REQUEST_LCE               */
               /* DESCRIPTION:     Terminating Access Rights Procedure                  */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.5                            */
               /* STARTING STATE:  MM_OPEN                                              */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               BYTE pos, po_no;
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if (!Check_Ti_Flag(TI_Value_peer_PD_MM))
               {
                  Mmu_Free(G_PTR);
                  return;
               }

               #if 0
               /* Mandatory << FIXED ID >> IE      */
               /* there ?                          */
               /* -------------------------------- */
               pos = scan_IE(G_PTR, FIXED_IDENTITY, 7, 7);
               if (pos == 0)
               {
                  send_down_AR_Terminate_Reject();
                  Mmu_Free(G_PTR);
                  send_dl_release_rq(PARTIAL_RELEASE);
                  return;
               }
               /* Mandatory << FIXED ID >> of      */
               /* type PARK ?                      */
               /* -------------------------------- */
               if (!((G_PTR[pos + 2] & 0x7F) == IDENTITY_TYP_PARK))
               {
                  send_down_AR_Terminate_Reject();
                  Mmu_Free(G_PTR);
                  send_dl_release_rq(PARTIAL_RELEASE);
                  return;
               }
               /* PARK-Key own ?                   */
               /* -------------------------------- */
               if (!Check_Received_PARK(&G_PTR[pos + 4]))
               {
                  send_down_AR_Terminate_Reject();
                  Mmu_Free(G_PTR);
                  send_dl_release_rq(PARTIAL_RELEASE);
                  return;
               }
               /* Mandatory << PORTABLE ID >> IE   */
               /* there ?                          */
               /* -------------------------------- */
               pos = scan_IE(G_PTR, PORTABLE_IDENTITY, 7, 7);
               if (pos == 0)
               {
                  send_down_AR_Terminate_Reject();
                  Mmu_Free(G_PTR);
                  send_dl_release_rq(PARTIAL_RELEASE);
                  return;
               }
               /* Mandatory << PORTABLE ID >> of   */
               /* type IPUI ?                      */
               /* -------------------------------- */
               if (!((G_PTR[pos + 2] & 0x7F) == IDENTITY_TYP_IPUI))
               {
                  send_down_AR_Terminate_Reject();
                  Mmu_Free(G_PTR);
                  send_dl_release_rq(PARTIAL_RELEASE);
                  return;
               }
               /* Portable registered ?            */
               /* -------------------------------- */
               po_no = Subscription_GetPotableNoFromIPUI(&G_PTR[pos + 4]);
               if (po_no != 0xFF)
               {
                  /* The Portable is registered.      */
                  /* -------------------------------- */
                  /* Send the Access Rights Terminate */
                  /* Accept message and erase the     */
                  /* registration slot.               */
                  send_down_AR_Terminate_Accept();
                  Send_Message_To_APP(FP_ACCESS_RIGHTS_TERMINATE_IND_MM, NULL, 0, po_no, 0, 0, 0);
                  Subscription_Deregister( po_no );
               }
               else
               {
                  /* The portable is not registered.  */
                  /* -------------------------------- */
                  send_down_AR_Terminate_Reject();
               }
               Mmu_Free(G_PTR);
               send_dl_release_rq(PARTIAL_RELEASE);
               #else
               // Check mandatory << PORTABLE ID >> IE.
               // The type should be IPUI.
               // -------------------------------------
               pos = scan_IE(G_PTR, PORTABLE_IDENTITY, 7, 7);
               if ((pos == 0) || !((G_PTR[pos + 2] & 0x7F) == IDENTITY_TYP_IPUI))
               {
                  if (pos == 0)
                  {
                     send_down_AR_Terminate_Reject(INFORMATION_ELEMENT_ERROR);
                  }
                  else
                  {
                     send_down_AR_Terminate_Reject(INVALID_IE_CONTENTS_REJ);
                  }
                  Mmu_Free(G_PTR);
                  send_dl_release_rq(PARTIAL_RELEASE);
                  return;
               }

               // Check if the portable is registered.
               // ------------------------------------
               po_no = Subscription_GetPotableNoFromIPUI(&G_PTR[pos + 4]);
               if (po_no != 0xFF)
               {
                  // The Portable is registered.

                  send_down_AR_Terminate_Accept();
                  Send_Message_To_APP(FP_ACCESS_RIGHTS_TERMINATE_IND_MM, NULL, 0, po_no, 0, 0, 0);
                  Subscription_Deregister(po_no);
                  #ifdef CONFIG_EARLY_ENCRYPTION
                  Subscription_UpdateDefaultCipherKeyOfModem(po_no);
                  #endif
               }
               else
               {
                  // The portable is not registered.

                  send_down_AR_Terminate_Reject(IPUI_UNKNOWN);
               }

               Mmu_Free(G_PTR);
               send_dl_release_rq(PARTIAL_RELEASE);
               #endif
            }
            return;

            case MM_LOCATE_REQUEST_LCE:
               T0500();
            return;

            case MM_CIPHER_SUGGEST_LCE:  /*  IN LINE CODE T0804    */
            {
               /* TRANSITION:      T0804                                                */
               /* EVENT:           MM_CIPHER_SUGGEST_LCE                                */
               /* DESCRIPTION:     Ciphering Procedure PT initiated                     */
               /* REFERENCE:       ETS 300 175-5:1996 / 6.5.3                           */
               /* STARTING STATE:  MM_OPEN / MM_CIPHER_ON / MM_CIPHER_OFF               */
               /* END STATE:       MM_CIPHER_ON / MM_CIPHER_OFF                         */
               /* ----------------------------------------------------------------------*/
               BYTE pos;
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_peer_PD_MM ))
               {
               Mmu_Free( G_PTR );
               return;
               }
               /* The 'CIPHER-SUGGEST' message can */
               /* only be processed, when the IPUI */
               /* is already delivered. If no IPUI */
               /* is delivered, the assigned       */
               /* portable number is not known,    */
               /* and therefore no DCK-Key is      */
               /* available !                      */
               if( Get_Assigned_Po_No( CurrentInc ) == 0xFF )
               {
               send_down_Cipher_Reject( IPUI_UNKNOWN );
               Mmu_Free( G_PTR );
               send_dl_release_rq( PARTIAL_RELEASE );
               return;
               }
               /* Mandatory << CIPHER INFO >> IE   */
               /* there ?                          */
               /* -------------------------------- */
               pos = scan_IE( G_PTR, CIPHER_INFO, 2, 3 );
               if( pos == 0 )
               {
               send_down_Cipher_Reject( INFORMATION_ELEMENT_ERROR );
               Mmu_Free( G_PTR );
               send_dl_release_rq( PARTIAL_RELEASE );
               return;
               }
               /* Only the following ciphering is  */
               /* supported:                       */
               /* Cipher Algorithmus = DSCA,       */
               /* Key = DCK,                       */
               /* Key nr = related to active       */
               /* IPUI/PARK.                       */
               /* -------------------------------- */
               if(( G_PTR[ pos + 2 ] & 0x7F ) != DECT_STANDARD_CIPHER_ALGO )
               {
               send_down_Cipher_Reject( CIPHER_ALGORITHM_NOT_SUPPORTED );
               Mmu_Free( G_PTR );
               send_dl_release_rq( PARTIAL_RELEASE );
               return;
               }

               if(( G_PTR[ pos + 3 ] & 0xF0 ) != CIPHER_KEY_TYPE_DCK         ||
               ( G_PTR[ pos + 3 ] & 0x0F ) != KEY_NR_RELATED_TO_IPUI_PARK )
               {
               send_down_Cipher_Reject( CIPHER_KEY_NOT_SUPPORTED );
               Mmu_Free( G_PTR );
               send_dl_release_rq( PARTIAL_RELEASE );
               return;
               }


               /* The desired Cipher Algorithmus   */
               /* and the Cipher Key is available. */
               /* The Y/N-Bit in the               */
               /* << CIPHER INFO >> IE determines  */
               /* if the ciphering is disabled or  */
               /* enabled !                        */
               /* -------------------------------- */
               if(( G_PTR[ pos + 2 ] & 0x80 ) == 0x80 )
               {
               /* Enabling of ciphering is         */
               /* requested.                       */
               /* -------------------------------- */
               /* The MM process has to provide    */
               /* the encryption key before the    */
               /* encryption activation is         */
               /* requested.                       */
               send_down_Cipher_Key( );
               send_down_Cipher_Request( TRUE, TI_Value_peer_PD_MM );
               KNL_Transit( MM_CIPHER_ON );
               }
               else
               {
               /* Disabling of ciphering is        */
               /* requested.                       */
               /* -------------------------------- */
               send_down_Cipher_Request( FALSE, TI_Value_peer_PD_MM );
               KNL_Transit( MM_CIPHER_OFF );
               }
               /* Cipher Switching Supervising     */
               /* -------------------------------- */
               /* Timer:     <MM_cipher.01>        */
               /* Duration:  10 seconds            */
               Start_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc  );
               Mmu_Free( G_PTR );
               MM_Struct[CurrentInc].Last_State = MM_OPEN;   /*  */
            }
            return;

            case MM_AUTH_REQUEST_LCE:
               T0420();
            return;

            default:
                break;
         }                             /* end of switch message            */
         break;

      /**********************************
       MM_AUTH_OF_PT State
      **********************************/
      case MM_AUTH_OF_PT:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
            case MM_MMS_AUTHENTICATE_PT_RQ:
            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            #endif
            case MM_MMS_AUTHENTICATE_USER_RQ:
            case MM_MMS_KEY_ALLOCATION_RQ:
            case MM_MMS_INFO_SUGGEST_RQ:
            case MM_MMS_CIPHER_ON_RQ:
            case MM_MMS_CIPHER_OFF_RQ:
            case MM_MMS_IDENTITY_RQ:
               T0999();
            return;

            case MM_AUTH_REQUEST_LCE:
               T0420();
            return;

            case MM_AUTHENTICATE_PT_RQ:  /*  IN LINE CODE T0303    */
            {
               /* TRANSITION:      T0303                                                */
               /* EVENT:           MM_AUTHENTICATE_PT_RQ                                */
               /* DESCRIPTION:     Authentication Procedure (using UAK-Key)             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.3                            */
               /* STARTING STATE:  MM_AUTH_OF_PT                                        */
               /* END STATE:       MM_AUTH_OF_PT                                        */
               /* ----------------------------------------------------------------------*/
               #ifdef CONFIG_EARLY_ENCRYPTION
               WORD cipherKeyIndex = 0xFFFF;
               #endif
               /* Entry point of the               */
               /* Authentication of PT             */
               /* procedure. For the               */
               /* Authentication the UAK-Key is    */
               /* used. A new DCK key is           */
               /* generated.                       */
               /* -------------------------------- */
               /* Set the RS-Array & RAND-F-Array  */
               /* with random values.              */
               #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
               if (MM_Struct[CurrentInc].supportsDsaa2) {    // DSAA2 is suppoted
                  Random(MM_Struct[CurrentInc].RS_Array, RS_LEN, 0x39);
                  Random(&MM_Struct[CurrentInc].RS_Array[RS_LEN], RS_LEN, 0x43);
               } else {
                  Random( MM_Struct[CurrentInc].RS_Array, RS_LEN, 0x39 );
               }
               #else
               Random( MM_Struct[CurrentInc].RS_Array, RS_LEN, 0x39 );
               #endif
               Random( MM_Struct[CurrentInc].RAND_Array, RAND_LEN, 0xE2 );
               /* Calculate the RES-Array.         */
               /* -------------------------------- */
               #ifdef KLOCWORK
               BYTE XDATA * Temp_UAK_Array;
               Temp_UAK_Array = Subscription_GetUAKRef( Get_Assigned_Po_No( CurrentInc ));
               if( Temp_UAK_Array != NULL ) {
               B1_Process (Temp_UAK_Array, MM_Struct[CurrentInc].K_Array, UAK_LEN);
               }
               #else
               B1_Process (Subscription_GetUAKRef( Get_Assigned_Po_No( CurrentInc )), MM_Struct[CurrentInc].K_Array, UAK_LEN);
               #endif
               #ifdef ULE_SUPPORT
               if (MM_Struct[CurrentInc].supportsDsaa2) {    // DSAA2 is suppoted
                  A11_2_Process(MM_Struct[CurrentInc].K_Array,
                                MM_Struct[CurrentInc].RS_Array,
                                &MM_Struct[CurrentInc].RS_Array[RS_LEN],
                                MM_Struct[CurrentInc].KS_Array);
               } else {
                  A11_Process(MM_Struct[CurrentInc].K_Array,
                              MM_Struct[CurrentInc].RS_Array,
                              MM_Struct[CurrentInc].KS_Array);

                  A12_Process(MM_Struct[CurrentInc].KS_Array,
                              MM_Struct[CurrentInc].RAND_Array,
                              MM_Struct[CurrentInc].RES_Array,
                              &MM_Struct[CurrentInc].DCK_Array[DCK_LEN]);

						DECT_DEBUG_USER_MM_KEY("[MM] RES1: %02x %02x %02x %02x\n",
													  MM_Struct[CurrentInc].RES_Array[0],
													  MM_Struct[CurrentInc].RES_Array[1],
													  MM_Struct[CurrentInc].RES_Array[2],
													  MM_Struct[CurrentInc].RES_Array[3]);
               }
               #ifdef CONFIG_EARLY_ENCRYPTION
               if (MM_Struct[CurrentInc].makingDefaultCipherKey) {
                  cipherKeyIndex = SearchNewDefaultCipherKeyIndex();
                  MM_Struct[CurrentInc].defaultCipherKeyIndex = cipherKeyIndex;
               }

               send_down_Auth_Request_UAK(MM_Struct[CurrentInc].RAND_Array,
                                          MM_Struct[CurrentInc].RS_Array,
                                          MM_Struct[CurrentInc].supportsDsaa2,
                                          cipherKeyIndex);
               #else
               send_down_Auth_Request_UAK(MM_Struct[CurrentInc].RAND_Array,
                                          MM_Struct[CurrentInc].RS_Array,
                                          MM_Struct[CurrentInc].supportsDsaa2);
               #endif
               #else
               A11_Process( MM_Struct[CurrentInc].K_Array,
               MM_Struct[CurrentInc].RS_Array,
               MM_Struct[CurrentInc].KS_Array );

               A12_Process( MM_Struct[CurrentInc].KS_Array,
               MM_Struct[CurrentInc].RAND_Array,
               MM_Struct[CurrentInc].RES_Array,
               MM_Struct[CurrentInc].DCK_Array );

					DECT_DEBUG_USER_MM_KEY("[MM] RES1: %02x %02x %02x %02x\n",
												  MM_Struct[CurrentInc].RES_Array[0],
												  MM_Struct[CurrentInc].RES_Array[1],
												  MM_Struct[CurrentInc].RES_Array[2],
												  MM_Struct[CurrentInc].RES_Array[3]);

               #ifdef CONFIG_EARLY_ENCRYPTION
               if (MM_Struct[CurrentInc].makingDefaultCipherKey) {
                  cipherKeyIndex = SearchNewDefaultCipherKeyIndex();
                  MM_Struct[CurrentInc].defaultCipherKeyIndex = cipherKeyIndex;
               }

               send_down_Auth_Request_UAK(MM_Struct[CurrentInc].RAND_Array,
                                          MM_Struct[CurrentInc].RS_Array,
                                          cipherKeyIndex);
               #else
               send_down_Auth_Request_UAK(MM_Struct[CurrentInc].RAND_Array,
                                          MM_Struct[CurrentInc].RS_Array);
               #endif
               #endif
               {
                  FPTR uak_array;

                  uak_array = Subscription_GetUAKRef( Get_Assigned_Po_No( CurrentInc ));
                  DECT_DEBUG_USER_MM_DATA("UAK2:%02x%02x %02x%02x %02x%02x %02x%02x %02x%02x %02x%02x %02x%02x %02x%02x\n",
                  uak_array[0],  uak_array[1],  uak_array[2], uak_array[3],
                  uak_array[4],  uak_array[5],  uak_array[6], uak_array[7],
                  uak_array[8],  uak_array[8],  uak_array[9], uak_array[10],
                  uak_array[12], uak_array[13], uak_array[14],uak_array[15]);
               }
               /* Authentication Supervising       */
               /* -------------------------------- */
               /* Timer:     <MM_auth.01>          */
               /* Duration:  10 seconds            */
               Start_Pro_Timer( TIMER_MM_AUTH_01, CurrentInc  );
            }
            return;

            case MM_AUTH_REPLY_LCE:  /*  IN LINE CODE T0302    */
            {
               /* TRANSITION:      T0302                                                */
               /* EVENT:           MM_AUTH_REPLY_LCE                                    */
               /* DESCRIPTION:     Authentication Procedure                             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.3                            */
               /* STARTING STATE:  MM_AUTH_OF_PT                                        */
               /* END STATE:       previous state                                       */
               /* ----------------------------------------------------------------------*/
               #ifdef ULE_SUPPORT
               FPTR rand_p = 0;
               BYTE XDATA DCKCCM[DCK2_LEN];
               #endif
               FPTR cipherKeyPtr;
               BYTE pos;
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_own_PD_MM ))
               {
                  Mmu_Free( G_PTR );
                  return;
               }

               Stop_Pro_Timer(TIMER_MM_AUTH_01, CurrentInc);

               #ifdef ULE_SUPPORT
               if (MM_Struct[CurrentInc].supportsDsaa2) {
                  pos = scan_IE( G_PTR, RAND, RAND_LEN, RAND_LEN );
                  if( pos == 0 ) {
                     send_Result( MM_AUTHENTICATE_PT_CFM, FALSE );
                     Mmu_Free( G_PTR );
                     if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                        send_dl_release_rq(PARTIAL_RELEASE);
                        clearMMState();
                     } else {
                        KNL_Transit( MM_Struct[CurrentInc].Starting_State );
                     }
                     return;
                  }

                  rand_p = Mmu_Malloc(RAND_LEN);
                  #ifdef KLOCWORK
                  if( rand_p != NULL)
                  #endif
                  {
                     Mmu_Memcpy( rand_p, &G_PTR[ pos + 2 ], RAND_LEN );
                     if (MM_Struct[CurrentInc].makingDCKCCM) {
                        A12_2_Process(MM_Struct[CurrentInc].KS_Array,
                                      MM_Struct[CurrentInc].RAND_Array,
                                      rand_p,
                                      MM_Struct[CurrentInc].RES_Array,
                                      DCKCCM);
                        if (IFX_DECT_GetUserFeatures() & USER_FEATURES_DCK_CCM_USE_FOR_MAC_ENCRYPTION) {
                           Mmu_Memcpy(MM_Struct[CurrentInc].DCK_Array, DCKCCM, DCK2_LEN);
                        }
                     } else {
                        A12_2_Process(MM_Struct[CurrentInc].KS_Array,
                                      MM_Struct[CurrentInc].RAND_Array,
                                      rand_p,
                                      MM_Struct[CurrentInc].RES_Array,
                                      MM_Struct[CurrentInc].DCK_Array);
                     }
                     Mmu_Free(rand_p);
                  }

						DECT_DEBUG_USER_MM_KEY("[MM] RES2: %02x %02x %02x %02x\n",
													  MM_Struct[CurrentInc].RES_Array[0],
													  MM_Struct[CurrentInc].RES_Array[1],
													  MM_Struct[CurrentInc].RES_Array[2],
													  MM_Struct[CurrentInc].RES_Array[3]);
               }
               #endif
               /* Mandatory << RES >> IE there ?   */
               /* -------------------------------- */
               pos = scan_IE( G_PTR, RES, RES_LEN, RES_LEN );
               if( pos == 0 )
               {
                  DECT_DEBUG_USER_MM_DATA("[MM] No RES IE\n");
                  send_Result( MM_AUTHENTICATE_PT_CFM, FALSE );
                  // commented by radvajesh Subscription_Deregister( Get_Assigned_Po_No( CurrentInc ));
                  Mmu_Free( G_PTR );
                  if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                     send_dl_release_rq( PARTIAL_RELEASE );
                     clearMMState();
                  } else {
                     KNL_Transit( MM_Struct[CurrentInc].Starting_State );
                  }
                  return;
               }

               {
                  #ifdef ULE_SUPPORT
                  if (MM_Struct[CurrentInc].supportsDsaa2) {
                     if (MM_Struct[CurrentInc].makingDCKCCM) {
                        cipherKeyPtr = DCKCCM; // [0] ~ [15] for DCK-CCM
                        if (IFX_DBGA_GetStackModuleDebugID() & (IFX_DECT_STACK_DEBUG_ID_MM_DATA | IFX_DECT_STACK_DEBUG_ID_MM_KEY)) {
                           IFX_DBG_Printf("[MM] DCK-CCM Generated");
                        }
                     } else {
                        cipherKeyPtr = MM_Struct[CurrentInc].DCK_Array; // [0] ~ [7] for encryption
                        #ifdef CONFIG_EARLY_ENCRYPTION
                        if (MM_Struct[CurrentInc].makingDefaultCipherKey) {
                           if (IFX_DBGA_GetStackModuleDebugID() & (IFX_DECT_STACK_DEBUG_ID_MM_DATA | IFX_DECT_STACK_DEBUG_ID_MM_KEY)) {
                              IFX_DBG_Printf("[MM] DefaultCK2 Generated");
                           }
                        } else
                        #endif
                        {
                           if (IFX_DBGA_GetStackModuleDebugID() & (IFX_DECT_STACK_DEBUG_ID_MM_DATA | IFX_DECT_STACK_DEBUG_ID_MM_KEY)) {
                              IFX_DBG_Printf("[MM] DCK2 Generated");
                           }
                        }
                     }
                     DECT_DEBUG_USER_MM_KEY(": %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x",
                                            cipherKeyPtr[0], cipherKeyPtr[1], cipherKeyPtr[2], cipherKeyPtr[3],
                                            cipherKeyPtr[4], cipherKeyPtr[5], cipherKeyPtr[6], cipherKeyPtr[7],
                                            cipherKeyPtr[8], cipherKeyPtr[9], cipherKeyPtr[10], cipherKeyPtr[11],
                                            cipherKeyPtr[12], cipherKeyPtr[13], cipherKeyPtr[14], cipherKeyPtr[15]);
                  } else {
                     cipherKeyPtr = &MM_Struct[CurrentInc].DCK_Array[DCK_LEN]; // [8] ~ [15] for encryption
                     #ifdef CONFIG_EARLY_ENCRYPTION
                     if (MM_Struct[CurrentInc].makingDefaultCipherKey) {
                        if (IFX_DBGA_GetStackModuleDebugID() & (IFX_DECT_STACK_DEBUG_ID_MM_DATA | IFX_DECT_STACK_DEBUG_ID_MM_KEY)) {
                           IFX_DBG_Printf("[MM] DefaultCK Generated");
                        }
                     } else
                     #endif
                     {
                        if (IFX_DBGA_GetStackModuleDebugID() & (IFX_DECT_STACK_DEBUG_ID_MM_DATA | IFX_DECT_STACK_DEBUG_ID_MM_KEY)) {
                           IFX_DBG_Printf("[MM] DCK Generated");
                        }
                     }
                     DECT_DEBUG_USER_MM_KEY(": %02x %02x %02x %02x %02x %02x %02x %02x",
                                            cipherKeyPtr[0], cipherKeyPtr[1], cipherKeyPtr[2], cipherKeyPtr[3],
                                            cipherKeyPtr[4], cipherKeyPtr[5], cipherKeyPtr[6], cipherKeyPtr[7]);
                  }
                  #else
                  cipherKeyPtr = MM_Struct[CurrentInc].DCK_Array;
                  #ifdef CONFIG_EARLY_ENCRYPTION
                  if (MM_Struct[CurrentInc].makingDefaultCipherKey) {
                     if (IFX_DBGA_GetStackModuleDebugID() & (IFX_DECT_STACK_DEBUG_ID_MM_DATA | IFX_DECT_STACK_DEBUG_ID_MM_KEY)) {
                        IFX_DBG_Printf("[MM] DefaultCK Generated");
                     }
                  } else
                  #endif
                  {
                     if (IFX_DBGA_GetStackModuleDebugID() & (IFX_DECT_STACK_DEBUG_ID_MM_DATA | IFX_DECT_STACK_DEBUG_ID_MM_KEY)) {
                        IFX_DBG_Printf("[MM] DCK Generated");
                     }
                  }
                  DECT_DEBUG_USER_MM_KEY(": %02x %02x %02x %02x %02x %02x %02x %02x",
                                         cipherKeyPtr[0], cipherKeyPtr[1], cipherKeyPtr[2], cipherKeyPtr[3],
                                         cipherKeyPtr[4], cipherKeyPtr[5], cipherKeyPtr[6], cipherKeyPtr[7]);
                  #endif
                  if (IFX_DBGA_GetStackModuleDebugID() & (IFX_DECT_STACK_DEBUG_ID_MM_DATA | IFX_DECT_STACK_DEBUG_ID_MM_KEY)) {
                     IFX_DBG_Printf("\n");
                  }
               }

               if( Mmu_Memcmp( MM_Struct[CurrentInc].RES_Array, &G_PTR[ pos + 2 ], RES_LEN ))
               {
                  /*
                     Authentication of PT always with DCK assignment!
                     - The new DCK for CCM must be stored.
                   */
                  #ifdef ULE_SUPPORT
                  if (MM_Struct[CurrentInc].makingDCKCCM) {
                     Subscription_SetDCKCCM(cipherKeyPtr, Get_Assigned_Po_No(CurrentInc));
                  }
                  #ifdef CONFIG_EARLY_ENCRYPTION
                  else
                  #endif
                  #endif
                  #ifdef CONFIG_EARLY_ENCRYPTION
                  if (MM_Struct[CurrentInc].makingDefaultCipherKey) {
                     Subscription_SetDefaultCipherKey(cipherKeyPtr, MM_Struct[CurrentInc].defaultCipherKeyIndex, Get_Assigned_Po_No(CurrentInc));
                     Subscription_UpdateDefaultCipherKeyOfModem(Get_Assigned_Po_No(CurrentInc));
                  }
                  #endif

                  #ifdef CONFIG_REPEATER_SUPPORT
                  if (MM_Struct[CurrentInc].DeviceType == REP_DEVICE) {
                     Mmu_Memcpy (FT_RepSubscription[Get_Assigned_Po_No(CurrentInc) - REP_DEVICE_OFFSET].dck_array, cipherKeyPtr, DCK_LEN);
                  }
                  #endif
                  send_Result( MM_AUTHENTICATE_PT_CFM, TRUE );
               }
               else
               {
                  DECT_DEBUG_USER_MM_DATA("[MM] RES Not Matched\n");
                  send_Result( MM_AUTHENTICATE_PT_CFM, FALSE );
                  // commented by radvajesh Subscription_Deregister( Get_Assigned_Po_No( CurrentInc ));
               }
               Mmu_Free( G_PTR );
               if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
               } else {
                  KNL_Transit( MM_Struct[CurrentInc].Starting_State );
               }
            }
            return;

            case MM_AUTH_REJECT_LCE:
            case MM_TIM_AUTH_01_EXPIRED:
            case MM_DL_REL_IN_LCE:  /*  IN LINE CODE T0350    */
            {
               /* TRANSITION:      T0350                                                */
               /* EVENT:           MM_AUTH_REJECT_LCE / MM_REL_IN_LCE                   */
               /*                  MM_TIM_AUTH_01_EXPIRED                               */
               /* DESCRIPTION:     Authentication Procedure (using UAK-Key)             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.3                            */
               /* STARTING STATE:  MM_AUTH_OF_PT                                        */
               /* END STATE:       previous state                                       */
               /* ----------------------------------------------------------------------*/
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_own_PD_MM ))
               {
               Mmu_Free( G_PTR );
               return;
               }

               Stop_Pro_Timer( TIMER_MM_AUTH_01, CurrentInc  );
               send_Result( MM_AUTHENTICATE_PT_CFM, FALSE );
               Mmu_Free( G_PTR );
               if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                  if (CurrentMessage != MM_DL_REL_IN_LCE) {
                     send_dl_release_rq( PARTIAL_RELEASE );
                  }
                  clearMMState();
               } else {
                  KNL_Transit( MM_Struct[CurrentInc].Starting_State );
               }
            }
            return;

            default:
                break;

         }                             /* end of switch message            */
         break;

      /**********************************
       MM_AUTH_OF_USER State
      **********************************/
      case MM_AUTH_OF_USER:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
            case MM_MMS_AUTHENTICATE_PT_RQ:
            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            #endif
            case MM_MMS_AUTHENTICATE_USER_RQ:
            case MM_MMS_KEY_ALLOCATION_RQ:
            case MM_MMS_INFO_SUGGEST_RQ:
            case MM_MMS_CIPHER_ON_RQ:
            case MM_MMS_CIPHER_OFF_RQ:
            case MM_MMS_IDENTITY_RQ:
               T0999();
            return;

            case MM_AUTH_REQUEST_LCE:
               T0420();
            return;

            case MM_AUTH_REPLY_LCE:  /*  IN LINE CODE T0305    */
            {
               /* TRANSITION:      T0305                                                */
               /* EVENT:           MM_AUTH_REPLY_LCE                                    */
               /* DESCRIPTION:     Authentication Procedure (using UPI-Key)             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.3.2                          */
               /* STARTING STATE:  MM_AUTH_OF_USER                                      */
               /* END STATE:       previous state                                       */
               /* ----------------------------------------------------------------------*/
               BYTE pos;
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_own_PD_MM ))
               {
               Mmu_Free( G_PTR );
               return;
               }

               Stop_Pro_Timer(TIMER_MM_AUTH_02, CurrentInc);
               /* Mandatory << RES >> IE there ?   */
               /* -------------------------------- */
               pos = scan_IE( G_PTR, RES, RES_LEN, RES_LEN );
               if( pos == 0 )
               {
                  send_Result( MM_AUTHENTICATE_USER_CFM, FALSE );
                  Mmu_Free( G_PTR );
                  if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                     send_dl_release_rq( PARTIAL_RELEASE );
                     clearMMState();
                  } else {
                     KNL_Transit( MM_Struct[CurrentInc].Starting_State );
                  }
                  return;
               }
               /* Received << RES >> value equal   */
               /* own one ?                        */
               /* -------------------------------- */
               if( Mmu_Memcmp( MM_Struct[CurrentInc].RES_Array, &G_PTR[ pos + 2 ], RES_LEN ))
                  send_Result( MM_AUTHENTICATE_USER_CFM, TRUE );
               else
                  send_Result( MM_AUTHENTICATE_USER_CFM, FALSE );

               Mmu_Free( G_PTR );
               if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
               } else {
                  KNL_Transit( MM_Struct[CurrentInc].Starting_State );
               }
            }
            return;

            case MM_AUTH_REJECT_LCE:
            case MM_DL_REL_IN_LCE:
            case MM_TIM_AUTH_02_EXPIRED:  /*  IN LINE CODE T0351    */
            {
               /* TRANSITION:      T0351                                                */
               /* EVENT:           MM_AUTH_REJECT_LCE / MM_REL_IN_LCE                   */
               /*                  MM_TIM_AUTH_02_EXPIRED                               */
               /* DESCRIPTION:     Authentication Procedure                             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.3                            */
               /* STARTING STATE:  MM_AUTH_OF_USER                                      */
               /* END STATE:       previous state                                       */
               /* ----------------------------------------------------------------------*/
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_own_PD_MM ))
               {
               Mmu_Free( G_PTR );
               return;
               }

               Stop_Pro_Timer( TIMER_MM_AUTH_02, CurrentInc  );
               send_Result( MM_AUTHENTICATE_USER_CFM, FALSE );
               Mmu_Free( G_PTR );
               if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                  if (CurrentMessage != MM_DL_REL_IN_LCE) {
                     send_dl_release_rq( PARTIAL_RELEASE );
                  }
                  clearMMState();
               } else {
                  KNL_Transit( MM_Struct[CurrentInc].Starting_State );
               }
            }
            return;

            case MM_AUTHENTICATE_USER_RQ:  /*  IN LINE CODE T0304    */
            {
               /* TRANSITION:      T0304                                                */
               /* EVENT:           MM_AUTHENTICATE_USER_RQ                              */
               /* DESCRIPTION:     Authentication Procedure (using UPI-Key)             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.3                            */
               /* STARTING STATE:  MM_AUTH_OF_USER                                      */
               /* END STATE:       MM_AUTH_OF_USER                                      */
               /* ----------------------------------------------------------------------*/
               BYTE XDATA DCK[8]; // Generated CK is not used for encryption.

               /* Entry point of the              */
               /* Authentication of User          */
               /* procedure. For the              */
               /* Authentication the UPI-Key is   */
               /* used. No DCK assignment is done.*/
               /* -------------------------------- */
               /* Set the RS-Array & RAND-F-Array  */
               /* with random values.              */
               #ifdef ULE_SUPPORT
               Random( MM_Struct[CurrentInc].RS_Array, RS_LEN, 0x39 );
               Random( &MM_Struct[CurrentInc].RS_Array[RS_LEN], RS_LEN, 0x43 );
               #else
               Random( MM_Struct[CurrentInc].RS_Array, RS_LEN, 0x39 );
               #endif
               Random( MM_Struct[CurrentInc].RAND_Array, RAND_LEN, 0xE2 );
               /* Calculate the RES-Array.         */
               /* -------------------------------- */
               B1_Process ( Get_AC_Ptr( ),
               MM_Struct[CurrentInc].K_Array,
               AC_LEN );
               #if 0 // Authentication of user using DSAA2 is option.
               #ifdef ULE_SUPPORT
               if (MM_Struct[CurrentInc].supportsDsaa2) {    // DSAA2 is suppoted
                  A11_2_Process(MM_Struct[CurrentInc].K_Array,
                                MM_Struct[CurrentInc].RS_Array,
                                &MM_Struct[CurrentInc].RS_Array[RS_LEN],
                                MM_Struct[CurrentInc].KS_Array);
               } else
               #endif
               #endif
               {
                  A11_Process(MM_Struct[CurrentInc].K_Array,
                              MM_Struct[CurrentInc].RS_Array,
                              MM_Struct[CurrentInc].KS_Array);
                  A12_Process(MM_Struct[CurrentInc].KS_Array,
                              MM_Struct[CurrentInc].RAND_Array,
                              MM_Struct[CurrentInc].RES_Array,
                              DCK);
               }
               #ifdef ULE_SUPPORT
               send_down_Auth_Request_UPI(MM_Struct[CurrentInc].RAND_Array,
                                          MM_Struct[CurrentInc].RS_Array,
                                          NO); // Authentication of user using DSAA2 is option.
               #else
               send_down_Auth_Request_UPI(MM_Struct[CurrentInc].RAND_Array,
                                          MM_Struct[CurrentInc].RS_Array);
               #endif
               /* Authentication Supervising       */
               /* -------------------------------- */
               /* Timer:     <MM_auth.02>          */
               /* Duration:  100 seconds           */
               Start_Pro_Timer( TIMER_MM_AUTH_02, CurrentInc  );
            }
            return;

            default:
                break;
         }                             /* end of switch message            */
         break;

      /**********************************
       MM_KEY_ALLOCATION State
      **********************************/
      case MM_KEY_ALLOCATION:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
            case MM_MMS_AUTHENTICATE_PT_RQ:
            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            #endif
            case MM_MMS_AUTHENTICATE_USER_RQ:
            case MM_MMS_KEY_ALLOCATION_RQ:
            case MM_MMS_INFO_SUGGEST_RQ:
            case MM_MMS_CIPHER_ON_RQ:
            case MM_MMS_CIPHER_OFF_RQ:
            case MM_MMS_IDENTITY_RQ:
               T0999();
            return;

            case MM_AUTH_REQUEST_LCE:  /*  IN LINE CODE T0402    */
            {
               /* TRANSITION:      T0402                                                */
               /* EVENT:           MM_AUTH_REQUEST_LCE                                  */
               /* DESCRIPTION:     Key Allocation Procedure                             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.6                            */
               /* STARTING STATE:  MM_KEY_ALLOCATION                                    */
               /* END STATE:       previous state                                       */
               /* ----------------------------------------------------------------------*/
               #ifdef ULE_SUPPORT
               BYTE XDATA rand[RAND_LEN];
               BYTE XDATA DCK[DCK2_LEN];
               #endif
               BYTE pos;
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if (!Check_Ti_Flag(TI_Value_own_PD_MM))
               {
                  Mmu_Free(G_PTR);
                  return;
               }
               /* Stop Key Allocation timer        */
               /* -------------------------------- */
               Stop_Pro_Timer(TIMER_MM_KEY_01, CurrentInc);
               /* Mandatory << AUTH >> IE there ?  */
               /* -------------------------------- */
               pos = scan_IE(G_PTR, AUTH_TYPE, 3, 4);
               if (pos == 0)
               {
                  send_down_Auth_Reject_Key(INFORMATION_ELEMENT_ERROR);
                  send_Result(MM_KEY_ALLOCATION_CFM, FALSE);
                  Mmu_Free(G_PTR);
                  if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                     send_dl_release_rq( PARTIAL_RELEASE );
                     clearMMState();
                  } else {
                     KNL_Transit(MM_Struct[CurrentInc].Starting_State);
                  }
                  return;
               }
               /* Determine the requested          */
               /* Authentication Algorithm.        */
               /* -------------------------------- */
               /* Only DSAA/AC is supported !      */
               #ifdef ULE_SUPPORT
               if (!(((G_PTR[pos + 2] == DSAA) || (G_PTR[pos + 2] == DSAA2)) &&
                     ((G_PTR[pos + 3] & 0xF0) == AUTHENTICATION_CODE)))
               #else
               if (!((G_PTR[pos + 2] == DSAA) &&
                     ((G_PTR[pos + 3] & 0xF0) == AUTHENTICATION_CODE)))
               #endif
               {
                  send_down_Auth_Reject_Key(AUTH_ALGORITHM_NOT_SUPPORTED);
                  send_Result(MM_KEY_ALLOCATION_CFM, FALSE);
                  Mmu_Free(G_PTR);
                  if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                     send_dl_release_rq( PARTIAL_RELEASE );
                     clearMMState();
                  } else {
                     KNL_Transit(MM_Struct[CurrentInc].Starting_State);
                  }
                  return;
               }

               #ifdef ULE_SUPPORT
               /* Mandatory << RAND >> IE there ?  */
               /* -------------------------------- */
               if (MM_Struct[CurrentInc].supportsDsaa2) {
                  pos = scan_IE(G_PTR, RAND, RAND_LEN, RAND_LEN);
                  if (pos == 0) {
                     send_down_Auth_Reject_Key( INFORMATION_ELEMENT_ERROR );
                     send_Result(MM_KEY_ALLOCATION_CFM, FALSE);
                     Mmu_Free(G_PTR);
                     if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                        send_dl_release_rq( PARTIAL_RELEASE );
                        clearMMState();
                     } else {
                        KNL_Transit(MM_Struct[CurrentInc].Starting_State);
                     }
                     return;
                  }
                  Mmu_Memcpy(rand, &G_PTR[pos + 2], RAND_LEN);
                  A12_2_Process(MM_Struct[CurrentInc].KS_Array,
                                MM_Struct[CurrentInc].RAND_Array,
                                rand,
                                MM_Struct[CurrentInc].RES_Array,
                                DCK);
               }
               #endif

               /* Mandatory << RES >> IE there ?   */
               /* -------------------------------- */
               pos = scan_IE(G_PTR, RES, RES_LEN, RES_LEN);
               if (pos == 0)
               {
                  send_down_Auth_Reject_Key(INFORMATION_ELEMENT_ERROR);
                  send_Result(MM_KEY_ALLOCATION_CFM, FALSE);
                  Mmu_Free(G_PTR);
                  if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                     send_dl_release_rq( PARTIAL_RELEASE );
                     clearMMState();
                  } else {
                     KNL_Transit(MM_Struct[CurrentInc].Starting_State);
                  }
                  return;
               }
               /* Received result equal ?          */
               /* -------------------------------- */
               if (!Mmu_Memcmp(MM_Struct[CurrentInc].RES_Array, &G_PTR[pos + 2], RES_LEN))
               {
                  send_down_Auth_Reject_Key(AUTHENTICATION_FAILED_REJ);
                  send_Result(MM_KEY_ALLOCATION_CFM, FALSE);
                  Mmu_Free(G_PTR);
                  if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                     send_dl_release_rq( PARTIAL_RELEASE );
                     clearMMState();
                  } else {
                     KNL_Transit(MM_Struct[CurrentInc].Starting_State);
                  }
                  return;
               }

               #ifdef ULE_SUPPORT
               if (!MM_Struct[CurrentInc].supportsDsaa2) {
                  /* Mandatory << RAND >> IE there ?  */
                  /* -------------------------------- */
                  pos = scan_IE(G_PTR, RAND, RAND_LEN, RAND_LEN);
                  if( pos == 0 )
                  {
                     send_down_Auth_Reject_Key(INFORMATION_ELEMENT_ERROR);
                     send_Result(MM_KEY_ALLOCATION_CFM, FALSE);
                     Mmu_Free(G_PTR);
                     if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                        send_dl_release_rq( PARTIAL_RELEASE );
                        clearMMState();
                     } else {
                        KNL_Transit(MM_Struct[CurrentInc].Starting_State);
                     }
                     return;
                  }
                  /* Copy RAND_P Field !              */
                  /* -------------------------------- */
                  Mmu_Memcpy(MM_Struct[CurrentInc].RAND_Array, &G_PTR[pos + 2], RAND_LEN);
               }
               #else
               /* Mandatory << RAND >> IE there ?  */
               /* -------------------------------- */
               pos = scan_IE(G_PTR, RAND, RAND_LEN, RAND_LEN);
               if (pos == 0)
               {
                  send_down_Auth_Reject_Key(INFORMATION_ELEMENT_ERROR);
                  send_Result(MM_KEY_ALLOCATION_CFM, FALSE);
                  Mmu_Free(G_PTR);
                  if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                     send_dl_release_rq( PARTIAL_RELEASE );
                     clearMMState();
                  } else {
                     KNL_Transit(MM_Struct[CurrentInc].Starting_State);
                  }
                  return;
               }
               /* Copy RAND_P Field !              */
               /* -------------------------------- */
               Mmu_Memcpy(MM_Struct[CurrentInc].RAND_Array, &G_PTR[ pos + 2 ], RAND_LEN);
               #endif
               /* Calculate the RES-Array !        */
               /* -------------------------------- */
               B1_Process(Get_AC_Ptr(),
                          MM_Struct[CurrentInc].K_Array,
                          AC_LEN);
               #ifdef ULE_SUPPORT
               if (MM_Struct[CurrentInc].supportsDsaa2) {
                  Random(MM_Struct[CurrentInc].RS_Array, RS_LEN, 0x39);
                  Random(&MM_Struct[CurrentInc].RS_Array[RS_LEN], RS_LEN, 0x43);
                  Random(MM_Struct[CurrentInc].RAND_Array, RAND_LEN, 0xE2);
                  A21_2_Process(MM_Struct[CurrentInc].K_Array,
                                MM_Struct[CurrentInc].RS_Array,
                                &MM_Struct[CurrentInc].RS_Array[RS_LEN],
                                MM_Struct[CurrentInc].KS_Array);

                  A22_2_Process(MM_Struct[CurrentInc].KS_Array,
                                rand,
                                MM_Struct[CurrentInc].RAND_Array,
                                MM_Struct[CurrentInc].RES_Array);
               } else {
                  A21_Process(MM_Struct[CurrentInc].K_Array,
                              MM_Struct[CurrentInc].RS_Array,
                              MM_Struct[CurrentInc].KS_Array);

                  A22_Process(MM_Struct[CurrentInc].KS_Array,
                              MM_Struct[CurrentInc].RAND_Array,
                              MM_Struct[CurrentInc].RES_Array);
               }
               send_down_Auth_Reply_Key(MM_Struct[CurrentInc].RES_Array,
                                        MM_Struct[CurrentInc].RAND_Array,
                                        MM_Struct[CurrentInc].RS_Array,
                                        MM_Struct[CurrentInc].supportsDsaa2);
               #else
               A21_Process(MM_Struct[CurrentInc].K_Array,
                           MM_Struct[CurrentInc].RS_Array,
                           MM_Struct[CurrentInc].KS_Array);

               A22_Process(MM_Struct[CurrentInc].KS_Array,
                           MM_Struct[CurrentInc].RAND_Array,
                           MM_Struct[CurrentInc].RES_Array);
               /* Send Auth Reply Message.         */
               /* -------------------------------- */
               send_down_Auth_Reply_Key(MM_Struct[CurrentInc].RES_Array);
               #endif
               send_Result( MM_KEY_ALLOCATION_CFM, TRUE );
               Mmu_Free(G_PTR);
               if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
               } else {
                  KNL_Transit(MM_Struct[CurrentInc].Starting_State);
               }
            }
            return;

            case MM_DL_REL_IN_LCE:
            case MM_TIM_KEY_01_EXPIRED:  /*  IN LINE CODE T0450    */
            {
               /* TRANSITION:      T0450                                                */
               /* EVENT:           MM_TIM_KEY_01_EXPIRED / MM_REL_IN_LCE                */
               /* DESCRIPTION:     Obtaining Access Rights Procedure                    */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.5                            */
               /* STARTING STATE:  MM_KEY_ALLOCATION                                    */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               /* Unsuccessful Key Allocation     */
               /* Procedure.                      */
               Stop_Pro_Timer( TIMER_MM_KEY_01, CurrentInc  );
               send_Result( MM_KEY_ALLOCATION_CFM, FALSE );
               if (MM_Struct[CurrentInc].Starting_State == MM_OPEN) {
                  if (CurrentMessage != MM_DL_REL_IN_LCE) {
                     send_dl_release_rq( PARTIAL_RELEASE );
                  }
                  clearMMState();
               } else {
                  KNL_Transit( MM_Struct[CurrentInc].Starting_State );
               }
            }
            return;

            case MM_KEY_ALLOCATION_RQ:  /*  IN LINE CODE T0401    */
            {
               /* TRANSITION:      T0401                                                */
               /* EVENT:           MM_KEY_ALLOCATION_RQ                                 */
               /* DESCRIPTION:     Key Allocation Procedure                             */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.6                            */
               /* STARTING STATE:  MM_KEY_ALLOCATION                                    */
               /* END STATE:       MM_KEY_ALLOCATION                                    */
               /* ----------------------------------------------------------------------*/
               BYTE XDATA DCK[8];

               /* Entry point of the              */
               /* Key Allocation procedure.       */
               /* For the Authentication the      */
               /* AC-Key is used.                 */
               /* ------------------------------- */
               /* Set the RS-Array & RAND-F-Array */
               /* with random values.             */
               #ifdef ULE_SUPPORT
               if (MM_Struct[CurrentInc].supportsDsaa2) {    // DSAA2 is suppoted
                  Random(MM_Struct[CurrentInc].RS_Array, RS_LEN, 0x39);
                  Random(&MM_Struct[CurrentInc].RS_Array[RS_LEN], RS_LEN, 0x43);
               } else {
                  Random( MM_Struct[CurrentInc].RS_Array, RS_LEN, 0x39 );
               }
               #else
               Random( MM_Struct[CurrentInc].RS_Array, RS_LEN, 0x39 );
               #endif
               Random( MM_Struct[CurrentInc].RAND_Array, RAND_LEN, 0xE2 );
               /* Calculate the RES-Array.        */
               /* ------------------------------- */
               B1_Process(Get_AC_Ptr(), MM_Struct[CurrentInc].K_Array, AC_LEN);
               #ifdef ULE_SUPPORT
               if (MM_Struct[CurrentInc].supportsDsaa2) {    // DSAA2 is suppoted
                  A11_2_Process(MM_Struct[CurrentInc].K_Array,
                                MM_Struct[CurrentInc].RS_Array,
                                &MM_Struct[CurrentInc].RS_Array[RS_LEN],
                                MM_Struct[CurrentInc].KS_Array);
               } else
               #endif
               {
                  A11_Process(MM_Struct[CurrentInc].K_Array,
                              MM_Struct[CurrentInc].RS_Array,
                              MM_Struct[CurrentInc].KS_Array);
                  A12_Process(MM_Struct[CurrentInc].KS_Array,
                              MM_Struct[CurrentInc].RAND_Array,
                              MM_Struct[CurrentInc].RES_Array,
                              DCK
                              );
               }
               #ifdef ULE_SUPPORT
               send_down_Key_Allocate(MM_Struct[CurrentInc].RAND_Array,
                                      MM_Struct[CurrentInc].RS_Array,
                                      MM_Struct[CurrentInc].supportsDsaa2);
               #else
               send_down_Key_Allocate(MM_Struct[CurrentInc].RAND_Array,
                                      MM_Struct[CurrentInc].RS_Array);
               #endif
               /* Key Allocation Timer             */
               /* -------------------------------- */
               /* Timer:    <MM_key.01>            */
               /* Duration: 10 seconds             */
               Start_Pro_Timer( TIMER_MM_KEY_01, CurrentInc  );
            }
            return;

            default:
                break;

         }                             /* end of switch message            */
         break;

      /**********************************
       MM_OBTAIN_ACCESS_RIGHTS State
      **********************************/
      case MM_OBTAIN_ACCESS_RIGHTS:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
            case MM_MMS_AUTHENTICATE_PT_RQ:
            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            #endif
            case MM_MMS_AUTHENTICATE_USER_RQ:
            case MM_MMS_KEY_ALLOCATION_RQ:
            case MM_MMS_INFO_SUGGEST_RQ:
            case MM_MMS_CIPHER_ON_RQ:
            case MM_MMS_CIPHER_OFF_RQ:
            case MM_MMS_IDENTITY_RQ:
               T0999();
            return;

            case MM_KEY_ALLOCATION_CFM:  /*  IN LINE CODE T0101    */
            {
               /* TRANSITION:      T0101                                                */
               /* EVENT:           MM_KEY_ALLOCATION_CFM                                */
               /* DESCRIPTION:     Obtaining Access Rights Procedure                    */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.5                            */
               /* STARTING STATE:  MM_OBTAIN_ACCESS_RIGTHS                              */
               /* END STATE:       MM_AUTH_OF_PT/MM_OPEN                                */
               /* ----------------------------------------------------------------------*/
               BYTE portableNo;

               if (PARAMETER1 == TRUE)
               {
                  /* Key Allocation Procedure was     */
                  /* successful. The User entered the */
                  /* correct System PIN.              */

                  /* Store subscription data.         */
                  /* -------------------------------- */
                  /* The IPUI is already loaded in    */
                  /* the IPUI-Array, the KS'-Array    */
                  /* is stored as UAK-Key.            */
                  /* The subscription data is stored  */
                  /* in the first free registration   */
                  /* slot. The slot number is equal   */
                  /* to the automatically assigned    */
                  /* internal portable number.        */
                  #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
                  portableNo = Subscription_Register(MM_Struct[CurrentInc].IPUI_Array,
                                                     MM_Struct[CurrentInc].KS_Array,
                                                     MM_Struct[CurrentInc].Model_Id,
                                                     MM_Struct[CurrentInc].DeviceType);
                  DECT_DEBUG_USER_MM_DATA("UAK1:%02x%02x %02x%02x %02x%02x %02x%02x %02x%02x %02x%02x %02x%02x %02x%02x\n",
                  MM_Struct[CurrentInc].KS_Array[0], MM_Struct[CurrentInc].KS_Array[1], MM_Struct[CurrentInc].KS_Array[2],MM_Struct[CurrentInc].KS_Array[3],
                  MM_Struct[CurrentInc].KS_Array[4], MM_Struct[CurrentInc].KS_Array[5], MM_Struct[CurrentInc].KS_Array[6],MM_Struct[CurrentInc].KS_Array[7],
                  MM_Struct[CurrentInc].KS_Array[8], MM_Struct[CurrentInc].KS_Array[8], MM_Struct[CurrentInc].KS_Array[9],MM_Struct[CurrentInc].KS_Array[10],
                  MM_Struct[CurrentInc].KS_Array[12], MM_Struct[CurrentInc].KS_Array[13], MM_Struct[CurrentInc].KS_Array[14],MM_Struct[CurrentInc].KS_Array[15]);
                  #else
                  portableNo = Subscription_Register(MM_Struct[CurrentInc].IPUI_Array,
                                                     MM_Struct[CurrentInc].KS_Array,
                                                     MM_Struct[CurrentInc].Model_Id,
                                                     MM_Struct[CurrentInc].EMC_Array);
                  #endif

                  if (IFX_DBGA_GetStackModuleDebugID() & IFX_DECT_STACK_DEBUG_ID_MM_KEY) {
                  	BYTE * uakPtr = &MM_Struct[CurrentInc].KS_Array[0];
	                IFX_DBG_Printf("[MM] UAK: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n",
                                                  uakPtr[0],uakPtr[1],uakPtr[2],uakPtr[3],
                                                  uakPtr[4],uakPtr[5],uakPtr[6],uakPtr[7],
                                                  uakPtr[8],uakPtr[9],uakPtr[10],uakPtr[11],
                                                  uakPtr[12],uakPtr[13],uakPtr[14],uakPtr[15]);
                   }

                  #ifdef CONFIG_EARLY_ENCRYPTION
                  Subscription_UpdateDefaultCipherKeyOfModem(portableNo);
                  #endif

                  /* Do the Application Layer         */
                  /* Assignment.                      */
                  Set_App_Layer_Assignment(CurrentInc, portableNo);

                  // Conclude the Access Rights Procedure with sending the Access Rights Accept message.

                  /* The PT was successfully          */
                  /* authenticated. A TPUI is now     */
                  /* assigned.                        */
                  /* Determine the assigned TPUI for  */
                  /* the Portable. Store the new TPUI */
                  /* value and inform the Portable    */
                  /* with the Locate Accept message.  */
                  #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
                  DECT_DEBUG_USER_MM_DATA("SetTpui:%02x %02x \n",MM_Struct[CurrentInc].DeviceType, portableNo );
                  Subscription_SetTPUI(portableNo, ASSIGNED_TPUI, MM_Struct[CurrentInc].DeviceType);
                  #else
                  Subscription_SetTPUI(portableNo, ASSIGNED_TPUI);
                  #endif

                  send_down_AR_Accept(portableNo);
                  #ifdef GIGASET_ETP
                     FPTR  ETP_ptr = NULL;

                     // Check ETP_Array and send to APP.
                     if (MM_Struct[CurrentInc].ETP_Array[sizeof(struct HLI_Header)+2] == ESCAPE_TO_PROPRIETARY) {
                        ETP_ptr = Mmu_Malloc( MAX_GIGASET_ETP_SIZE );
                        Mmu_Memcpy( ETP_ptr, MM_Struct[CurrentInc].ETP_Array, MAX_GIGASET_ETP_SIZE );
                     }
                     #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
                     if (MM_Struct[CurrentInc].DeviceType != REP_DEVICE) {
                        Send_Message_To_APP(FP_PORTABLE_REGISTERED_IN_MM,
                                         ETP_ptr,
                                         CurrentInc,
                                         portableNo,
                                         MM_Struct[CurrentInc].Model_Id,
                                         MM_Struct[CurrentInc].EMC_Array[0],
                                         MM_Struct[CurrentInc].EMC_Array[1]);
                     }
                     else
                     {
                        Repeater_Reg = REPEATER_REGISTRATION_STATE_ONGOING;
                        Repeater_PoNo = portableNo;
                        Start_Pro_Timer( TIMER_MM_REPEATER_01, CurrentInc  );
                     }
                     #else
                        Send_Message_To_APP(FP_PORTABLE_REGISTERED_IN_MM,
                                         ETP_ptr,
                                         CurrentInc,
                                         portableNo,
                                         MM_Struct[CurrentInc].Model_Id,
                                         MM_Struct[CurrentInc].EMC_Array[0],
                                         MM_Struct[CurrentInc].EMC_Array[1]);
                     #endif
                  #else
                     #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
                  if (MM_Struct[CurrentInc].DeviceType != REP_DEVICE) {
                     Send_Message_To_APP(FP_PORTABLE_REGISTERED_IN_MM,
                                 NULL,
                                 CurrentInc,
                                 portableNo,
                                 MM_Struct[CurrentInc].Model_Id,
                                 MM_Struct[CurrentInc].EMC_Array[0],
                                 MM_Struct[CurrentInc].EMC_Array[1]);
                  }
                  else
                  {
                        Repeater_Reg = REPEATER_REGISTRATION_STATE_ONGOING;
                        Repeater_PoNo = portableNo;
					      Start_Pro_Timer( TIMER_MM_REPEATER_01, CurrentInc  );
                  }
                     #else
                       Send_Message_To_APP(FP_PORTABLE_REGISTERED_IN_MM,
                                 NULL,
                                 CurrentInc,
                                 portableNo,
                                 MM_Struct[CurrentInc].Model_Id,
                                 MM_Struct[CurrentInc].EMC_Array[0],
                                 MM_Struct[CurrentInc].EMC_Array[1]);

                     #endif
                   #endif
                  KNL_SENDTASK(ME, ME_A44_CLEAR_RQ_DIS);
                  send_dl_release_rq(PARTIAL_RELEASE);
                  clearMMState();
               }
               else
               {
                  /* Key Allocation Procedure failed, */
                  /* because the User entered the     */
                  /* wrong System PIN. Abort Access   */
                  /* Rights Procedure.                */
                  Clear_Reg_Mode(CurrentInc, AUTHENTICATION_FAILED_REJ);
                  /*
                  KNL_SENDTASK( ME, ME_A44_CLEAR_RQ_DIS );
                  Send_Message_To_APP(FP_PORTABLE_REGISTER_FAIL_IN_MM,
                  NULL,
                  CurrentInc,
                  DUMMY_FILL,
                  DUMMY_FILL,
                  DUMMY_FILL,
                  AUTHENTICATION_FAILED_REJ );
                  */
                  send_down_AR_Reject(AUTHENTICATION_FAILED_REJ);
                  send_dl_release_rq(PARTIAL_RELEASE);
                  clearMMState();
                  //added by radvajesh to support easy pairing
                  KNL_SENDTASK( ME, ME_A44_SET_RQ_DIS);
               }
            }
            return;

            case MM_DL_REL_IN_LCE:
            {
               /* TRANSITION:      T0150                                                */
               /* EVENT:           MM_DL_REL_IN_LCE / MM_TIM_LOCATE_01_EXPIRED          */
               /* DESCRIPTION:     Obtaining Access Rights Procedure                    */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.5                            */
               /* STARTING STATE:  MM_OBTAIN_ACCESS_RIGTHS                              */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               clearMMState();
            }
            return;

            default:
                break;

         }                             /* end of switch message            */
         break;

      /**********************************
       MM_TERMINATING_ACCESS_RIGHTS State
      **********************************/
      case MM_TERMINATING_ACCESS_RIGHTS:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
            case MM_MMS_AUTHENTICATE_PT_RQ:
            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            #endif
            case MM_MMS_AUTHENTICATE_USER_RQ:
            case MM_MMS_KEY_ALLOCATION_RQ:
            case MM_MMS_INFO_SUGGEST_RQ:
            case MM_MMS_CIPHER_ON_RQ:
            case MM_MMS_CIPHER_OFF_RQ:
            case MM_MMS_IDENTITY_RQ:
               T0999();
            return;

            case MM_AUTH_REQUEST_LCE:
               T0420();
            return;

            case MM_DL_REL_IN_LCE:
            case MM_ACCESS_RIGHTS_TERMINATE_REJECT_LCE:
            case MM_TIM_ACCESS_02_EXPIRED:  /*  IN LINE CODE T0250    */
            {
               /* TRANSITION:      T0250                                                */
               /* EVENT:           MM_ACCESS_RIGHTS_TERMINATE_REJECT_LCE /              */
               /*                  MM_REL_IN_LCE / MM_TIM_ACCESS_02_EXPIRED             */
               /* DESCRIPTION:     Terminating Access Rights Procedure                  */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.5.2                          */
               /* STARTING STATE:  MM_TERMINATING_ACCESS_RIGHTS                         */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_own_PD_MM ))
               {
                  Mmu_Free( G_PTR );
                  return;
               }
               /* Stop Access Rights Terminate     */
               /* timer.                           */
               /* -------------------------------- */
               send_up_Confirmation( FALSE );
               Subscription_Deregister( Get_Assigned_Po_No( CurrentInc ));
               #ifdef CONFIG_EARLY_ENCRYPTION
               Subscription_UpdateDefaultCipherKeyOfModem(Get_Assigned_Po_No(CurrentInc));
               #endif
               Stop_Pro_Timer( TIMER_MM_ACCESS_02, CurrentInc );
               Mmu_Free( G_PTR );
               send_dl_release_rq( PARTIAL_RELEASE );
               clearMMState();
            }
            return;

            case MM_ACCESS_RIGHTS_TERMINATE_ACCEPT_LCE:  /*  IN LINE CODE T0201    */
            {
               /* TRANSITION:      T0201                                                */
               /* EVENT:           MM_ACCESS_RIGHTS_TERMINATE_ACCEPT_LCE                */
               /* DESCRIPTION:     Terminating Access Rights Procedure                  */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.5.2                          */
               /* STARTING STATE:  MM_TERMINATING_ACCESS_RIGHTS                         */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_own_PD_MM ))
               {
               Mmu_Free( G_PTR );
               return;
               }
               /* stop Access Rights Terminate     */
               /* timer.                           */
               /* -------------------------------- */
               #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
               if (MM_Struct[CurrentInc].DeviceType != REP_DEVICE)
               #endif
               send_up_Confirmation( TRUE );

               Subscription_Deregister( Get_Assigned_Po_No( CurrentInc ));
               #ifdef CONFIG_EARLY_ENCRYPTION
               Subscription_UpdateDefaultCipherKeyOfModem(Get_Assigned_Po_No(CurrentInc));
               #endif
               Stop_Pro_Timer( TIMER_MM_ACCESS_02, CurrentInc );
               Mmu_Free( G_PTR );
               send_dl_release_rq( PARTIAL_RELEASE );
               clearMMState();
            }
            return;

            default:
                break;

         }                             /* end of switch message            */
         break;

      /**********************************
      MM_LOCATION_REGISTRATION State
      **********************************/
      case MM_LOCATION_REGISTRATION:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
            case MM_MMS_AUTHENTICATE_PT_RQ:
            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            #endif
            case MM_MMS_AUTHENTICATE_USER_RQ:
            case MM_MMS_KEY_ALLOCATION_RQ:
            case MM_MMS_INFO_SUGGEST_RQ:
            case MM_MMS_CIPHER_ON_RQ:
            case MM_MMS_CIPHER_OFF_RQ:
            case MM_MMS_IDENTITY_RQ:
               T0999();
            return;

            case MM_AUTHENTICATE_PT_CFM:  /*  IN LINE CODE T0502    */
            {
               /* TRANSITION:      T0502                                                */
               /* EVENT:           MM_AUTHENTICATE_PT_CFM                               */
               /* DESCRIPTION:     Authentication of PT                                 */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.3.1                          */
               /* STARTING STATE:  MM_LOCATION_REGISTRATION                             */
               /* END STATE:       MM_LOCATION_ACK_WAIT / MM_OPEN                       */
               /* ----------------------------------------------------------------------*/
               if( PARAMETER1 == TRUE )
               {
               DECT_DEBUG_USER_MM_DATA("[MM] Locate Accept\n");
               /* The PT was successfully          */
               /* authenticated. A TPUI is now     */
               /* assigned.                        */
               /* Determine the assigned TPUI for  */
               /* the Portable. Store the new TPUI */
               /* value and inform the Portable    */
               /* with the Locate Accept message.  */
#if 0 // For Philips DECT Handset, TPUI will be assigned during registration only.
               // During Locate Registration, no assignment TPUI.
               Subscription_SetTPUI( Get_Assigned_Po_No( CurrentInc ), ASSIGNED_TPUI );
#endif
               #ifdef CONFIG_TEST_MAC_CONFIG_INFO_WITH_LOC_ACC
                  send_down_Locate_Accept( Get_Assigned_Po_No( CurrentInc ), MM_Struct[CurrentInc].DeviceType );
               #else
               send_down_Locate_Accept( Get_Assigned_Po_No( CurrentInc ));
               #endif
               /* Locate Accept Timer              */
               /* -------------------------------- */
               /* Timer:    MM-<identity.1>        */
               /* Duration: 10 seconds             */
               Start_Pro_Timer( TIMER_MM_IDENTITY_01, CurrentInc  );
               KNL_Transit( MM_LOCATION_ACK_WAIT );
               }
               else
               {
                  /* The Authentication of PT failed! */
                  /* The Location Update is rejected! */
                  /* -------------------------------- */
                  /* Send the Locat Reject message    */
                  /* with << REJECT REASON >> IE      */
                  DECT_DEBUG_USER_MM_DATA("[MM] Locate Reject\n");
                  send_down_Locate_Reject( AUTHENTICATION_FAILED_REJ );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
               }
            }
            return;

            case MM_DL_REL_IN_LCE:  /*  IN LINE CODE T0550    */
            {
               /* TRANSITION:      T0550                                                */
               /* EVENT:           MM_REL_IN_LCE                                        */
               /* DESCRIPTION:     Location Registration Procedure                      */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.4.3                          */
               /* STARTING STATE:  MM_LOCATION_REGISTRATION                             */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               clearMMState();
            }
            return;

            default:
                break;
         }                             /* end of switch message            */
         break;

      /**********************************
       MM_LOCATION_ACK_WAIT State
       **********************************/
      case MM_LOCATION_ACK_WAIT:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
            case MM_MMS_AUTHENTICATE_PT_RQ:
            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            #endif
            case MM_MMS_AUTHENTICATE_USER_RQ:
            case MM_MMS_KEY_ALLOCATION_RQ:
            case MM_MMS_INFO_SUGGEST_RQ:
            case MM_MMS_CIPHER_ON_RQ:
            case MM_MMS_CIPHER_OFF_RQ:
            case MM_MMS_IDENTITY_RQ:
               T0999();
            return;

            case MM_DL_REL_IN_LCE:
            case MM_TEMPORARY_IDENTITY_ASSIGN_REJ_LCE:
            case MM_TIM_IDENTITY_01_EXPIRED:  /*  IN LINE CODE T0551    */
            {
               /* TRANSITION:      T0551                                                */
               /* EVENT:           MM_REL_IN_LCE / MM_TIM_IDENTITY_01_EXPIRED           */
               /*                  MM_TEMPORARY_IDENTITY_ASSIGN_REJ_LCE                 */
               /* DESCRIPTION:     Location Registration Procedure                      */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.4                            */
               /* STARTING STATE:  MM_LOCATION_ACK_WAIT                                 */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_peer_PD_MM ))
               {
                  Mmu_Free( G_PTR );
                  return;
               }
               /* Stop Locate Accept Timer         */
               /* -------------------------------- */
               Stop_Pro_Timer( TIMER_MM_IDENTITY_01, CurrentInc  );
               #if 1
               // Do not set TPUI to default TPUI because PP will restart location registration.
               #else
               /* The Location Registration        */
               /* Procedure was not successful.    */
               /* (unexpected link release/timeout)*/
               /* The TPUI value ist set to        */
               /* default again.                   */
               #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT)
               Subscription_SetTPUI( Get_Assigned_Po_No( CurrentInc ), DEFAULT_TPUI, MM_Struct[CurrentInc].DeviceType );
               #else
               Subscription_SetTPUI( Get_Assigned_Po_No( CurrentInc ), DEFAULT_TPUI );
               #endif
               #endif
               Mmu_Free( G_PTR );

               send_dl_release_rq( PARTIAL_RELEASE );
               clearMMState();
            }
            return;

            case MM_TEMPORARY_IDENTITY_ASSIGN_ACK_LCE:  /*  IN LINE CODE T0501    */
            {
               /* TRANSITION:      T0501                                                */
               /* EVENT:           MM_TEMPORARY_IDENTITY_ASSIGN_ACK_LCE                       */
               /* DESCRIPTION:     Location Registration Procedure                      */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.4                            */
               /* STARTING STATE:  MM_LOCATION_ACK_WAIT                                 */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_peer_PD_MM ))
               {
                  Mmu_Free( G_PTR );
                  return;
               }
               /* The portable is reporting the    */
               /* receipt of the assigned TPUI     */
               /* value.                           */

               /* Stop Locate Accept Timer         */
               /* -------------------------------- */
               Stop_Pro_Timer( TIMER_MM_IDENTITY_01, CurrentInc  );
               #if 1 /*def XXX SBB*/
               /* Issue sfound with sinus handsets if the link is released immidiately */
               send_dl_release_rq( PARTIAL_RELEASE );
               #else
               /* List access full slot, immidiately calling will use same slot if not released immidiately.
                  If we use partial release hanset/base has to do service change */
               send_dl_release_rq( NORMAL ); // release fast to allow better access other pp's
               #endif

               #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
               if (MM_Struct[CurrentInc].DeviceType != REP_DEVICE)
               #endif
               /* If the DIS process is in PAGE    */
               /* MODE the paging of the current   */
               /* PT is initiated if it is not     */
               /* already paged (see FSWI.PSL).    */
               {
                  //Mahipati : Sending registration info
                  struct HLI_Header* pxHeader=0;
                  BYTE portableNo;

                  portableNo = Get_Assigned_Po_No(CurrentInc);
                  #ifdef ULE_SUPPORT
                     #ifdef KLOCWORK
                  if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
                     #else
                  if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
                     #endif
                     pxHeader  = (struct HLI_Header*)Mmu_Malloc( sizeof(FT_ULE_SUBSCRIPTION) + sizeof( struct HLI_Header ) );
                     #ifdef KLOCWORK
                     if(pxHeader != NULL)
                     #endif
                     {
                        pxHeader->length = sizeof(struct HLI_Header)+sizeof(FT_ULE_SUBSCRIPTION);
                        pxHeader->next=0;
                        Subscription_GetRegistrationData(portableNo, (FPTR)((unsigned long)pxHeader) + sizeof(struct HLI_Header));
                     }
                  } else
                  #endif
                  {
                     pxHeader  = (struct HLI_Header*)Mmu_Malloc( sizeof(FT_SUBSCRIPTION) + sizeof( struct HLI_Header ) );
                     #ifdef KLOCWORK
                     if(pxHeader != NULL)
                     #endif
                     {
                        pxHeader->length = sizeof(struct HLI_Header)+sizeof(FT_SUBSCRIPTION);
                        pxHeader->next=0;
                        Subscription_GetRegistrationData(portableNo, (FPTR)((unsigned long)pxHeader) + sizeof(struct HLI_Header));
                     }
                  }

                  Send_Message_To_APP(FP_PORTABLE_ATTACHED_IN_MM,
                                   (FPTR)pxHeader,
                                   CurrentInc,
                                   portableNo,
                                   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
                                   Get_First_Codec(portableNo),
                                   Get_Second_Codec(portableNo),
                                   Get_Third_Codec(portableNo)
                                   #else
                                   First_Codec[portableNo - 1],
                                   Second_Codec[portableNo - 1],
                                   Third_Codec[portableNo - 1]
                                   #endif
                                   );
               }
               Mmu_Free( G_PTR );
               clearMMState();
            }
            return;

            default:
                break;
         }                             /* end of switch message            */
         break;

      /**********************************
       MM_LOCATION_UPDATE State
      **********************************/
      case MM_LOCATION_UPDATE:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
            case MM_MMS_AUTHENTICATE_PT_RQ:
            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            #endif
            case MM_MMS_AUTHENTICATE_USER_RQ:
            case MM_MMS_KEY_ALLOCATION_RQ:
            case MM_MMS_INFO_SUGGEST_RQ:
            case MM_MMS_CIPHER_ON_RQ:
            case MM_MMS_CIPHER_OFF_RQ:
            case MM_MMS_IDENTITY_RQ:
               T0999();
            return;

            case MM_LOCATE_REQUEST_LCE:  /*  IN LINE CODE T0601    */
            {
               /* TRANSITION:      T0601                                                */
               /* EVENT:           MM_LOCATE_REQUEST_LCE                                */
               /* DESCRIPTION:     Location Update Procedure                            */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.4.3                          */
               /* STARTING STATE:  MM_LOCATION_UPDATE                                   */
               /* END STATE:       MM_LOCATION_ACK_WAIT / MM_OPEN                       */
               /* ----------------------------------------------------------------------*/
               BYTE pos, po_no;
               #ifdef ULE_SUPPORT
               BYTE value;
               #endif
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_peer_PD_MM ))
               {
               Mmu_Free( G_PTR );
               return;
               }
               /* Stop Supervise Timer             */
               /* -------------------------------- */
               Stop_Pro_Timer( TIMER_MM_LOCATE_01, CurrentInc  );

               #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT)
               MM_Struct[CurrentInc].supportsDsaa2 = NO;
               MM_Struct[CurrentInc].DeviceType = DECT_DEVICE;
               #endif
               #ifdef ULE_SUPPORT
               if ((pos = scan_IE(G_PTR, TERMINAL_CAPABILITY, 3, MAX_TERMINAL_CAPABILITY_IE_SIZE)) != 0) {
                  value = getTerminalCapabilityValue(&G_PTR[pos], 4, 8); // To check ULE supported(4h)
                  if ((value != 0xFF) && (value & 0x04)) { // ULE supported
                     MM_Struct[CurrentInc].DeviceType = ULE_DEVICE;
                  }
						DECT_DEBUG_USER_MM_DATA("[MM] PT ULE: %02x %02x \n", MM_Struct[CurrentInc].DeviceType, value);

                  #if 1
                  if (MM_Struct[CurrentInc].DeviceType == ULE_DEVICE)
                  #endif
                  {
                     MM_Struct[CurrentInc].supportsDsaa2 = isDsaa2Supported(&G_PTR[pos]);
                  }
               }
               #endif
               /* Not mandatory to check fixed ID(990118)   */
               #ifdef XXXX
               /* Mandatory << FIXED ID >> IE      */
               /* there ?                          */
               /* -------------------------------- */
               pos = scan_IE( G_PTR, FIXED_IDENTITY, 7, 7 );
               if( pos == 0 )
               {
                  send_up_Confirmation( FALSE );
                  send_down_Locate_Reject( INFORMATION_ELEMENT_ERROR );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }
               /* Mandatory << FIXED ID >> of      */
               /* type ARI+RPN ?                   */
               /* -------------------------------- */
               if( ! (( G_PTR[ pos + 2 ] & 0x7F ) == IDENTITY_TYP_ARI_RPN ))
               {
                  send_up_Confirmation( FALSE );
                  send_down_Locate_Reject( INVALID_IE_CONTENTS_REJ );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }

               /* Received ARI+RPN own ?           */
               /* -------------------------------- */
               if( ! Check_Received_ARI_RPN( &G_PTR[ pos + 4 ] ))
               {
                  send_up_Confirmation( FALSE );
                  send_down_Locate_Reject( INVALID_IE_CONTENTS_REJ );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }
               #endif //XXXX
               /* Mandatory << PORTABLE ID >> IE   */
               /* there ?                          */
               /* -------------------------------- */
               pos = scan_IE( G_PTR, PORTABLE_IDENTITY, 7, 7 );
               if( pos == 0 )
               {
                  send_up_Confirmation( FALSE );
                  send_down_Locate_Reject( INFORMATION_ELEMENT_ERROR );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }
               /* Mandatory << PORTABLE ID >> of   */
               /* type IPUI ?                      */
               /* -------------------------------- */
               if( ! (( G_PTR[ pos + 2 ] & 0x7F ) == IDENTITY_TYP_IPUI ))
               {
                  send_up_Confirmation( FALSE );
                  send_down_Locate_Reject( INVALID_IE_CONTENTS_REJ );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }

               #ifdef MASTER_BS
               //Subscription_ForceToRegister( &G_PTR[ pos + 4 ], 0 );
               Subscription_ForceToRegister( &G_PTR[ pos + 4 ], 1 );
               #endif
               /* Portable registered ?            */
               /* -------------------------------- */
               po_no = Subscription_GetPotableNoFromIPUI( &G_PTR[ pos + 4 ] );
               if( po_no == 0xFF )
               {
                  /* The portable is not registered.  */
                  /* -------------------------------- */
                  /* Send the Locat Reject message    */
                  /* with << REJECT REASON >> IE      */
                  /* ( unknown IPUI ).                */
                  /* ================================ */
                  /* NOTE: PT will erase registration */
                  /*       if LOCATE_REJECT reason is */
                  /*       IPUI_UNKNOWN ()       */
                  /* ================================ */
                  send_up_Confirmation( FALSE );
                  send_down_Locate_Reject( IPUI_UNKNOWN );
                  Mmu_Free( G_PTR );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }

               /* Do the Application Layer         */
               /* Assignment if not done.          */
               /* 24FEB2001  Missed!!!!       */
               if( Get_Assigned_Po_No( CurrentInc ) == 0xFF )
               {
                  Set_App_Layer_Assignment( CurrentInc, po_no );
               }

               send_up_Confirmation( TRUE );
               /* A TPUI is now assigned !         */
               /* Determine the assigned TPUI for  */
               /* the Portable. Store the new TPUI */
               /* value and inform the Portable    */
               /* with the Locate Accept message.  */
               #ifdef ULE_SUPPORT
               Subscription_SetTPUI( Get_Assigned_Po_No( CurrentInc ), ASSIGNED_TPUI, MM_Struct[CurrentInc].DeviceType );
               #else
               Subscription_SetTPUI( Get_Assigned_Po_No( CurrentInc ), ASSIGNED_TPUI );
               #endif
               #ifdef CONFIG_TEST_MAC_CONFIG_INFO_WITH_LOC_ACC
               send_down_Locate_Accept( Get_Assigned_Po_No( CurrentInc ), MM_Struct[CurrentInc].DeviceType );
               #else
               send_down_Locate_Accept( Get_Assigned_Po_No( CurrentInc ));
               #endif
               /* Locate Accept Timer              */
               /* -------------------------------- */
               /* Timer:    MM-<identity.1>        */
               /* Duration: 10 seconds             */
               Start_Pro_Timer( TIMER_MM_IDENTITY_01, CurrentInc  );
               Mmu_Free( G_PTR );
               KNL_Transit( MM_LOCATION_ACK_WAIT );
            }
            return;

            case MM_DL_REL_IN_LCE:
            case MM_TIM_LOCATE_01_EXPIRED:  /*  IN LINE CODE T0650    */
            {
               /* TRANSITION:      T0650                                                */
               /* EVENT:           MM_REL_IN_LCE / MM_TIM_LOCATE_01_EXPIRED             */
               /* DESCRIPTION:     Location Update Procedure                            */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.4.3                          */
               /* STARTING STATE:  MM_LOCATION_UPDATE                                   */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               /* Stop Supervise Timer.            */
               /* -------------------------------- */
               send_up_Confirmation( FALSE );
               Stop_Pro_Timer( TIMER_MM_LOCATE_01, CurrentInc );
               send_dl_release_rq( PARTIAL_RELEASE );
               clearMMState();
            }
            return;

            default:
                break;

         }                             /* end of switch message            */
         break;

      /**********************************
       MM_CIPHER_ON State
      **********************************/
      case MM_CIPHER_ON:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
            case MM_MMS_AUTHENTICATE_PT_RQ:
            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            #endif
            case MM_MMS_AUTHENTICATE_USER_RQ:
            case MM_MMS_KEY_ALLOCATION_RQ:
            case MM_MMS_INFO_SUGGEST_RQ:
            case MM_MMS_CIPHER_ON_RQ:
            case MM_MMS_CIPHER_OFF_RQ:
            case MM_MMS_IDENTITY_RQ:
               T0999();
            return;

            case MM_AUTH_REQUEST_LCE:
               T0420();
            return;

            case MM_DL_REL_IN_LCE:
            case MM_TIM_CIPHER_01_EXPIRED:
               T0850();
            return;

            #ifdef CONFIG_REPEATER_SUPPORT
            case MM_REP_ACCESS_CFM:
            {
               if (PARAMETER3 == FALSE) {
                  send_up_Confirmation( FALSE );
                                                   /* Stop Supervise Timer.            */
                                                   /* -------------------------------- */
                  Stop_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }

               if ((MM_Struct[CurrentInc].Repeater_Idx+1) == MM_Struct[CurrentInc].Repeater_Num) {
                  if (MM_Struct[CurrentInc].Return_Proc == LC_REP) {
                     send_up_Confirmation( TRUE );
                     Stop_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc );
                     send_dl_release_rq( PARTIAL_RELEASE );
                     clearMMState();
                  } else {
                     if (MM_Struct[CurrentInc].Repeater_Idx == 0) {
                        send_down_Cipher_Key( );
                     }
                     send_down_Cipher_Request( TRUE, TI_Value_own_PD_MM );
                  }
                  return;
               }

               if (MM_Struct[CurrentInc].Repeater_Idx == 0) {
                  #ifdef KLOCWORK
                  if (!VALID_PORTABLE_REP(MM_Struct[CurrentInc].Rep_PoNo, PORTABLE_REP)) {
                  #else
                  if (!IsValidPortableNo(MM_Struct[CurrentInc].Rep_PoNo, PORTABLE_REP)) {
                  #endif
                     Stop_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc );
                     send_dl_release_rq( PARTIAL_RELEASE );
                     clearMMState();
                     return;
                  }
                  send_down_Rep_Cipher_Key( MM_Struct[CurrentInc].Rep_PoNo );
               }
               send_down_Rep_Cipher_Request( TRUE, TI_Value_own_PD_MM );
            }
            return;

            case MM_MM_INFO_SENT_IN_LAP:
            {
               //BYTE po_no;

               #if 0
               if (((MM_Struct[CurrentInc].Repeater_Idx+1) == MM_Struct[CurrentInc].Repeater_Num) &&
                   (MM_Struct[CurrentInc].Return_Proc == LC_REP)) {
                  send_up_Confirmation( TRUE );
                  Stop_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }
               #endif

               #if 0
               MM_Struct[CurrentInc].Repeater_Idx++;
               PmidBuff[0] = CurrentInc;
               PmidBuff[1] = MM_Struct[CurrentInc].Repeater_Idx;
               Get_RepPmid_Encryption(PmidBuff);
               po_no = Subscription_GetPortableNoFromPMID(&PmidBuff[2]);
               MM_Struct[CurrentInc].Rep_PoNo = po_no;
               #endif

               if (MM_Struct[CurrentInc].Return_Proc != LC_REP) {
                  PARAMETER4 = 1;
               } else if (MM_Struct[CurrentInc].Repeater_Idx+1 == MM_Struct[CurrentInc].Repeater_Num) {
                  #ifdef FAST_HANDOVER    // Fast Handover make no Bearer_CFM from Repeater to Handset
                  KNL_SENDTASK_WP_INC( MM, MM_REP_ACCESS_CFM, 0, 0, 1, 0, CurrentInc );
                  #endif
                  PARAMETER4 = 0;
               } else {
                  #ifdef FAST_HANDOVER    // Fast Handover make no Bearer_CFM from Repeater to Handset
                  KNL_SENDTASK_WP_INC( MM, MM_REP_ACCESS_CFM, 0, 0, 1, 0, CurrentInc );
                  #endif
                  PARAMETER4 = 0;
               }
               KNL_SENDTASK_WP_INC( LAP_REP, LAP_REP_ACCESS_REQ, CurrentInc, MM_Struct[CurrentInc].Rep_Lbn,
                                    MM_Struct[CurrentInc].Repeater_Idx, PARAMETER4, CurrentInc );
            }
            return;
            #endif

            case MM_DL_ENC_IND_LCE:  /*  IN LINE CODE T0802    */
            {
               /* TRANSITION:      T0802                                                */
               /* EVENT:           MM_DL_ENC_IND_LCE                                    */
               /* DESCRIPTION:     Ciphering Procedure                                  */
               /* REFERENCE:       ETS 300 175-5:1996 / 6.5.3                           */
               /* STARTING STATE:  MM_CIPHER_ON                                         */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
            #ifdef CONFIG_REPEATER_SUPPORT
               BYTE po_no;

               if ((MM_Struct[CurrentInc].Repeater_Idx+1) == MM_Struct[CurrentInc].Repeater_Num) {
               //if (((MM_Struct[CurrentInc].Repeater_Idx+1) == MM_Struct[CurrentInc].Repeater_Num) &&
               //    (MM_Struct[CurrentInc].Return_Proc != LC_REP)) {
                  if( PARAMETER1 == TRUE && PARAMETER4 == TRUE ) {
                     send_up_Confirmation( TRUE );
                  } else {
                     send_up_Confirmation( FALSE );
                  }
                  Stop_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  clearMMState();
                  return;
               }

               MM_Struct[CurrentInc].Repeater_Idx++;
               PmidBuff[0] = CurrentInc;
               PmidBuff[1] = MM_Struct[CurrentInc].Repeater_Idx;
               Get_RepPmid_Encryption(PmidBuff);
               po_no = Subscription_GetPortableNoFromPMID(&PmidBuff[2]);
               MM_Struct[CurrentInc].Rep_PoNo = po_no;
               DECT_DEBUG_USER_MM_DATA("[MM] Cipher On:%02x[%02x%02x%02x]\n", po_no, PmidBuff[2], PmidBuff[3], PmidBuff[4] );
               send_down_MM_Info_Suggest( po_no );
               Start_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc  );
            #else
               /* Send confirmation to application */
               /* layer.                           */
               /* P1 = result                      */
               /* P4 = crypt / clear mode          */
               if( PARAMETER1 == TRUE && PARAMETER4 == TRUE ) {
                  send_up_Confirmation( TRUE );
               } else {
                  send_up_Confirmation( FALSE );
               }
               /* Stop Supervise Timer.            */
               /* -------------------------------- */
               Stop_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc );
               send_dl_release_rq( PARTIAL_RELEASE );
               clearMMState();
            #endif
            }
            return;

            case MM_CIPHER_REJECT_LCE:
               T0851();
            return;

            default:
                break;
         }                             /* end of switch message            */
         break;

      /**********************************
       MM_CIPHER_OFF State
      **********************************/
      case MM_CIPHER_OFF:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
            case MM_MMS_AUTHENTICATE_PT_RQ:
            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            #endif
            case MM_MMS_AUTHENTICATE_USER_RQ:
            case MM_MMS_KEY_ALLOCATION_RQ:
            case MM_MMS_INFO_SUGGEST_RQ:
            case MM_MMS_CIPHER_ON_RQ:
            case MM_MMS_CIPHER_OFF_RQ:
            case MM_MMS_IDENTITY_RQ:
               T0999();
            return;

            case MM_AUTH_REQUEST_LCE:
               T0420();
            return;

            case MM_DL_REL_IN_LCE:
            case MM_TIM_CIPHER_01_EXPIRED:
               T0850();
            return;

            case MM_DL_ENC_IND_LCE:  /*  IN LINE CODE T0803    */
            {
               /* TRANSITION:      T0803                                                */
               /* EVENT:           MM_DL_ENC_IND_LCE                                    */
               /* DESCRIPTION:     Ciphering Procedure                                  */
               /* REFERENCE:       ETS 300 175-5:1996 / 6.5.3                           */
               /* STARTING STATE:  MM_CIPHER_OFF                                        */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               /* Send confirmation to application */
               /* layer.                           */
               /* P1 = result                      */
               /* P4 = crypt / clear mode          */
               if( PARAMETER1 == TRUE && PARAMETER4 == FALSE )
                  send_up_Confirmation( TRUE );
               else
                  send_up_Confirmation( FALSE );
               /* Stop Supervise Timer.            */
               /* -------------------------------- */
               Stop_Pro_Timer( TIMER_MM_CIPHER_01, CurrentInc );
               send_dl_release_rq( PARTIAL_RELEASE );
               clearMMState();
            }
            return;

            case MM_CIPHER_REJECT_LCE:
               T0851();
            return;

            default:
                break;

         }                             /* end of switch message            */
         break;

      /**********************************
       MM_IDENTITY State
      **********************************/
      case MM_IDENTITY:
         switch (CurrentMessage)
         {
            case MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ:
            case MM_MMS_AUTHENTICATE_PT_RQ:
            #ifdef ULE_SUPPORT
            case MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ:
            #endif
            case MM_MMS_AUTHENTICATE_USER_RQ:
            case MM_MMS_KEY_ALLOCATION_RQ:
            case MM_MMS_INFO_SUGGEST_RQ:
            case MM_MMS_CIPHER_ON_RQ:
            case MM_MMS_CIPHER_OFF_RQ:
            case MM_MMS_IDENTITY_RQ:
               T0999();
            return;

            case MM_AUTH_REQUEST_LCE:
               T0420();
            return;

            case MM_DL_REL_IN_LCE:
            case MM_TIM_IDENTITY_01_EXPIRED:  /*  IN LINE CODE T0950    */
            {
               /* TRANSITION:      T0950                                                */
               /* EVENT:           MM_DL_REL_IN_LCE / MM_TIM_IDENTITY_01_EXPIRED        */
               /* DESCRIPTION:     Identity Procedure                                   */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.2.1                          */
               /* STARTING STATE:  MM_IDENTIY                                           */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               /* Stop Identity Request Timer      */
               /* -------------------------------- */
               Stop_Pro_Timer( TIMER_MM_IDENTITY_01, CurrentInc  );
               /* Send negative confirmation to    */
               /* application layer.               */
               send_up_Confirmation( FALSE );
               clearMMState();
            }
            return;

            case MM_IDENTITY_REPLY_LCE:  /*  IN LINE CODE T0901    */
            {
               /* TRANSITION:      T0901                                                */
               /* EVENT:           MM_IDENTITY_REPLY                                    */
               /* DESCRIPTION:     Identity Request                                     */
               /* REFERENCE:       ETS 300 175-5:1996 / 13.2.1                          */
               /* STARTING STATE:  MM_IDENTITY                                          */
               /* END STATE:       MM_OPEN                                              */
               /* ----------------------------------------------------------------------*/
               BYTE pos;
               BYTE po_no;
               /* Ignore message with wrong        */
               /* TI-Flag setting !                */
               if( ! Check_Ti_Flag( TI_Value_own_PD_MM ))
               {
                  Mmu_Free( G_PTR );
                  return;
               }
               /* Stop Identity Request Timer      */
               /* -------------------------------- */
               Stop_Pro_Timer( TIMER_MM_IDENTITY_01, CurrentInc  );
               /* Mandatory << PORTABLE IDENTITY >>*/
               /* included ?                       */
               /* -------------------------------- */
               pos = scan_IE( G_PTR, PORTABLE_IDENTITY, 7, 7 );
               if( pos == 0 )
               {
                  /* Send negative confirmation to    */
                  /* application layer.               */
                  send_up_Confirmation( FALSE );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  Mmu_Free( G_PTR );
                  clearMMState();
                  return;
               }

               #ifdef MASTER_BS
               //Subscription_ForceToRegister( &G_PTR[ pos + 4 ], 0 );
               Subscription_ForceToRegister( &G_PTR[ pos + 4 ], 1 );
               #endif
               /* Content of                       */
               /* << PORTABLE IDENTITY>> correct ? */
               /* -------------------------------- */
               /* The registration of the portable */
               /* is checked.                      */
               po_no = Subscription_GetPotableNoFromIPUI( &G_PTR[ pos + 4 ] );
               if( po_no == 0xFF )
               {
                  /* Send negative confirmation to    */
                  /* application layer.               */
                  send_up_Confirmation( FALSE );
                  send_dl_release_rq( PARTIAL_RELEASE );
                  Mmu_Free( G_PTR );
                  clearMMState();
                  return;
               }
               /* Send positive confirmation to    */
               /* application layer.               */
               send_up_Confirmation( TRUE );
               send_dl_release_rq( PARTIAL_RELEASE );
               Mmu_Free( G_PTR );
               clearMMState();
            }
            return;

            case MM_DETACH_LCE:
            case MM_INFO_REQUEST_LCE:  /*  IN LINE CODE T0001    */
            {
               /* TRANSITION:      T0001                                                */
               /* EVENT:           Unexpected Event                                     */
               /* DESCRIPTION:                                                          */
               /* REFERENCE:                                                            */
               /* STARTING STATE:                                                       */
               /* END STATE:                                                            */
               /* ----------------------------------------------------------------------*/
               if( G_PTR != NULL )
               Mmu_Free( G_PTR );
            }
            return;

            default:
                break;

         }                             /* end of switch message            */
         break;

   }                                   /* end of switch state              */
   KNL_T0000();

}                                      /* end of DECODE_MM()               */

