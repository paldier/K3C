/* -- SIEMENS AG  PCT -- Process: LCE         -  Mon Feb 26 14:22:29 2007 -- */
#include	"DEFINE.H"
#include <stdio.h>
# include "SYSDEF.H"
# include "FDEF.H"
# include "TYPEDEF.H"
extern void KNL_T0000(void);
extern void get_pmid_from_hmac_ioctl(BYTE * data);

# include "SYSEXT.H"

/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
*                   (c) 2005 IFX / INTNIX. All rights reserved.               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  FLCE.PSL                                                *
*     Date       :  18 Nov, 2005                                       *
*     Contents   :                                                          *
*     Hardware   :  IFX 87xx                                               *
*                                                                           *
*****************************************************************************
*/
/* ========                                                             */
/* Includes                                                             */
/* ========                                                             */
#include    "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#include "SYSINIT.H"
#include "FGLOBAL.H"
#include "PCT_DEF.H"
#include "KNL_SYSTEM.H"
#include "MMU.H"
#include "P_TIM.H"
#include "CC_DEF.H"
#include "CC_LIB.H"
#include "MM_LIB.H"

#include "LCE_LIB.H"
#ifdef printf
#undef printf
#endif

/* ==============                                                       */
/* Local typedefs                                                       */
/* ==============                                                       */
#ifdef DECT_DEBUG_USER_LCE_PRIMITIVE
typedef struct {
   BYTE key;
   char *string;
} DebugStringTable_t;
#endif

/* ===============                                                      */
/* Local variables                                                      */
/* ===============                                                      */
#ifdef DECT_DEBUG_USER_LCE_PRIMITIVE
LOCAL DebugStringTable_t stateStringTable[] = {
   {LINK_RELEASED, "LINK_RELEASED"},
   {LINK_ESTABLISHED, "LINK_ESTABLISHED"},
   {RELEASE_INDICATION, "RELEASE_INDICATION"},
   {RELEASE_PENDING, "RELEASE_PENDING"},
   {0xFF, "Unknown State"}
};

LOCAL DebugStringTable_t messageStringTable[] = {
   {LCE_DL_REL_IN_LAP, "LCE_DL_REL_IN_LAP"},
   {LCE_DL_REL_CFM_LAP, "LCE_DL_REL_CFM_LAP"},
   {LCE_DL_EST_IN_LAP, "LCE_DL_EST_IN_LAP"},
   {LCE_TIM_03_EXPIRED, "LCE_TIM_03_EXPIRED"},
   {LCE_DL_DATA_IN_LAP, "LCE_DL_DATA_IN_LAP"},
   {LCE_DL_DATA_RQ, "LCE_DL_DATA_RQ"},
   {LCE_DL_REL_RQ, "LCE_DL_REL_RQ"},
   {LCE_PAGE_RESPONSE_LCE, "LCE_PAGE_RESPONSE_LCE"},
   {LCE_REL_INVOKED_LCE, "LCE_REL_INVOKED_LCE"},
   {LCE_TIM_02_EXPIRED, "LCE_TIM_02_EXPIRED"},
   {LCE_TIM_SUPERVISE_EXPIRED, "LCE_TIM_SUPERVISE_EXPIRED"},
   {LCE_DL_ENC_KEY_RQ_MM, "LCE_DL_ENC_KEY_RQ_MM"},
   {LCE_DL_ENC_IND_LAP, "LCE_DL_ENC_IND_LAP"},
   {LCE_REL_ROUND_LCE, "LCE_REL_ROUND_LCE"},
   {LCE_TIM_01_EXPIRED, "LCE_TIM_01_EXPIRED"},
   {0xFF, "Unknown Message"}
};
#endif

/* ==========================                                           */
/* Global function definition                                           */
/* ==========================                                           */
EXPORT void
LCE_INIT( void )
{
   Init_Switching_Structs( );
}

/* ==========================                                           */
/* Global function definition                                           */
/* ==========================                                           */
EXPORT void
RESET_LCE_INIT( void )
{
   RESET_Init_Switching_Structs( );
}
		
/* =========================                                            */
/* Local function definition                                            */
/* =========================                                            */
LOCAL void
send_down_Page_Reject( FPTR ipui_ptr, BYTE reject_reason )
{
   FPTR temp;
                                       /* The function forwards the        */
                                       /* << LCE_PAGE_REJECT >> msg.       */

                                       /* Assembly the reject msg !        */
   temp = Make_S_FORMAT_Message( PD_LCE,
   TI_Value_peer_PD_LCE,
   LCE_PAGE_REJECT );
   if( ipui_ptr != NULL )
      temp = Append_IE( temp, PORTABLE_IDENTITY, 7, ipui_ptr );
   if( reject_reason != DUMMY_FILL )
      temp = Add_IE_3 ( temp, REJECT_REASON, 0x01, reject_reason );
   KNL_SENDTASK_NP_INC( LAP, LAP_DL_DATA_RQ_LCE, temp, CurrentInc );
}


static void T0252( void )
{
   /* TRANSITION:      T252                                                 */
   /* EVENT:           LCE_TIM_03_EXPIRED                                   */
   /* DESCRIPTION:     Request Page Timer expired                           */
   /* REFERENCE:       ETS 300 175-5:1996                                   */
   /* STARTING STATE:  all states                                           */
   /* END STATE:       current state maintained                             */
   /* ----------------------------------------------------------------------*/
                                       /* Request Paging Timer expired.    */
                                       /* -------------------------------- */
                                       /* Note:                            */
                                       /* CurrentInc is equal to link no!  */
   Paging_Timer_Expired(CurrentInc);
}

#ifdef DECT_DEBUG_USER_LCE_PRIMITIVE
LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
{
   BYTE i;

   for (i = 0; tablePtr[i].key != 0xFF; i++) {
      if (tablePtr[i].key == key) {
         break;
      }
   }
   return tablePtr[i].string;
}
#endif

void DECODE_LCE(void)
{
   #ifdef DECT_DEBUG_USER_LCE_PRIMITIVE
   DECT_DEBUG_USER_LCE_PRIMITIVE("%s, %s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable), 
   getDebugStringRef(CurrentState, stateStringTable), CurrentInc, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
   #endif

   switch (CurrentState) 
   {
      case LINK_RELEASED:
         switch (CurrentMessage) 
         {
            #ifndef CONFIG_UPDATE_LINK_RELEASE
            case LCE_DL_REL_IN_LAP: 
            case LCE_DL_REL_CFM_LAP:  /*  IN LINE CODE T0200    */
            {
               /* TRANSITION:      T200                                                 */
               /* EVENT:           LCE_DL_REL_IN_LAP / LCE_DL_REL_CFM_LAP               */
               /* DESCRIPTION:     Data Link release                                    */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_RELEASED                                        */
               /* END STATE:       LINK_RELEASED                                        */
               /* ----------------------------------------------------------------------*/
                                                   /* The DLC-Layer is reporting the   */
                                                   /* release of a link.               */
                                                   /* -------------------------------- */
                                                   /* The event is unexpected.         */
                                                   /* But to go sure, the link release */
                                                   /* is reported to the NTW-Layer     */
                                                   /* processes CC and MM.             */
               KNL_SENDTASK_INC( CC, CC_DL_REL_IN_LCE, CurrentInc );
               KNL_SENDTASK_INC( MM, MM_DL_REL_IN_LCE, CurrentInc );
                                                   /* The assignment to the            */
                                                   /* Application layer is cleared.    */
               Clear_App_Layer_Assignment( CurrentInc );
                                                   /* Stop Link Release Timer          */
               Stop_Pro_Timer( TIMER_LCE_01, CurrentInc );
                                                   /* Stop Link Maintain Timer         */
               Stop_Pro_Timer( TIMER_LCE_02, CurrentInc );
                                                   /* Stop Link Supervise Timer        */
               Stop_Pro_Timer( TIMER_LCE_SUPERVISE, CurrentInc );

               KNL_Transit( LINK_RELEASED );
            }
            return;
            #endif

            case LCE_DL_EST_IN_LAP:  /*  IN LINE CODE T0100    */
            {
               /* TRANSITION:      T100                                                 */
               /* EVENT:           LCE_DL_EST_IN_LAP                                    */
               /* DESCRIPTION:     Data Link established                                */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_RELEASED                                        */
               /* END STATE:       LINK_ESTABLISHED                                     */
               /* ----------------------------------------------------------------------*/
                                                   /* The DLC-Layer is reporting a new */
                                                   /* link establishment.              */
                                                   /* -------------------------------- */

                                                   /* The Link Supervise Timer is      */
                                                   /* started, in order to allow link  */
                                                   /* release in case of a unexpected  */
                                                   /* or incompatible message.         */
                                                   /* Link Supervise Timer             */
                                                   /* -------------------------------- */
                                                   /* Timer:    <LCE_Supervise>        */
                                                   /* Duration: 30 seconds             */
               Start_Pro_Timer( TIMER_LCE_SUPERVISE, CurrentInc );

                                                   /* In case of a Indirect FT         */
                                                   /* initiated link establishment     */
                                                   /* procedure (GAP 300 444 / 8.35),  */
                                                   /* the DL_EST_IN primitive is       */
                                                   /* carrying the LCE_PAGE_RESPONSE   */
                                                   /* message.                         */
               if( G_PTR != NULL ) {
                  Decode_L3_Frame( G_PTR, CurrentInc );
               }
               //#ifdef CONFIG_TEST_TBR22_TC_FT_MM_BV_AR_03
               else {
                  // For pass of TC_FT_MM_BV_AR_03, the portable number is got from PMID
                  // and assigned for app layer.
                  BYTE pmidBuf[4];
                  BYTE portableNo;
                  
                  // set connection id (CurrentInc) to buffer as parameter for request
                  pmidBuf[0] = CurrentInc;
                  get_pmid_from_hmac_ioctl(pmidBuf);
                  #ifdef DECT_DEBUG_USER_LCE_PRIMITIVE
                  printf("LCE_DL_EST_IN_LAP PMID:%02x:%02x %02x %02x\n", pmidBuf[0], pmidBuf[1], pmidBuf[2], pmidBuf[3]);
                  #endif
                  if (pmidBuf[1] != 0x0E) { // if not default PMID
                     portableNo = Subscription_GetPortableNoFromPMID(&pmidBuf[1]);
                     #ifdef DECT_DEBUG_USER_LCE_PRIMITIVE
                     printf("LCE_DL_EST_IN_LAP PortableNo:%02x\n", portableNo);
                     #endif
                     if (portableNo != 0xFF) {
                        Set_App_Layer_Assignment(CurrentInc, portableNo);
                     }
                  }
               }
               //#endif
      
               KNL_Transit( LINK_ESTABLISHED );
            }
            return;
      
            case LCE_TIM_03_EXPIRED: 
               T0252();
               return;
      
            default:
               break;
         }										/* end of switch message				*/
         break; 

      case LINK_ESTABLISHED:
         switch (CurrentMessage) 
         {
            case LCE_DL_REL_IN_LAP:   /*  IN LINE CODE T0201    */ 
            #ifndef CONFIG_UPDATE_LINK_RELEASE
            case LCE_DL_REL_CFM_LAP:  /*  IN LINE CODE T0201    */
            #endif
            {
               /* TRANSITION:      T201                                                 */
               /* EVENT:           LCE_DL_REL_IN_LAP / LCE_DL_REL_CFM_LAP               */
               /* DESCRIPTION:     Data Link release                                    */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_ESTABLISHED                                     */
               /* END STATE:       RELEASE_INDICATION                                   */
               /* ----------------------------------------------------------------------*/
                                                   /* The DLC-Layer is reporting the   */
                                                   /* release of a link.               */
                                                   /* -------------------------------- */
                                                   /* The NTW-Layer processes CC and   */
                                                   /* MM are informed.                 */
               KNL_SENDTASK_INC( CC,  CC_DL_REL_IN_LCE, CurrentInc );
               KNL_SENDTASK_INC( MM,  MM_DL_REL_IN_LCE, CurrentInc );
                                                   /* Start the link release           */
                                                   /* procedure.                       */
               Lock_App_Layer_Assignment( CurrentInc );

               // The upper layers (CC/MM) will use the portable number for application layer.
               // So, the portable number can be cleared. It is cleared with the LCE_REL_ROUND_LCE message.
               KNL_SENDTASK_INC( LCE, LCE_REL_ROUND_LCE, CurrentInc );
               KNL_Transit( RELEASE_INDICATION );
            }
            return;

            case LCE_TIM_03_EXPIRED: 
               T0252();
               return;

            case LCE_DL_DATA_IN_LAP:  /*  IN LINE CODE T0300    */
            {
               /* TRANSITION:      T300                                                 */
               /* EVENT:           LCE_DL_DATA_IN_LAP                                   */
               /* DESCRIPTION:     Layer-3 information received                         */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_ESTABLISHED                                     */
               /* END STATE:       LINK_ESTABLISHED                                     */
               /* ----------------------------------------------------------------------*/
                                                   /* The received Layer-3 information */
                                                   /* is decoded.                      */
                                                   /* -------------------------------- */
               if( G_PTR != NULL )
                  Decode_L3_Frame( G_PTR, CurrentInc );
                                                   /* Restart the Link Supervising     */
                                                   /* Timer.                           */
                                                   /* Link Supervise Timer             */
                                                   /* -------------------------------- */
                                                   /* Timer:    <LCE_Supervise>        */
                                                   /* Duration: 30 seconds             */
               Start_Pro_Timer( TIMER_LCE_SUPERVISE, CurrentInc );
            }
            return;

            case LCE_DL_DATA_RQ:  /*  IN LINE CODE T0400    */
            {
               /* TRANSITION:      T400                                                 */
               /* EVENT:           LCE_DL_DATA_RQ                                       */
               /* DESCRIPTION:     Data request from CC / MM                            */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_ESTABLISHED                                     */
               /* END STATE:       LINK_ESTABLISHED                                     */
               /* ----------------------------------------------------------------------*/
                                                   /* The Layer-3 frame is forwarded   */
                                                   /* to the DLC-Layer.                */
                                                   /* -------------------------------- */
               KNL_SENDTASK_NP_INC( LAP, LAP_DL_DATA_RQ_LCE, G_PTR, CurrentInc );
            }
            return;

            case LCE_DL_REL_RQ:  /*  IN LINE CODE T0250    */
            {
               /* TRANSITION:      T250                                                 */
               /* EVENT:           LCE_DL_REL_RQ                                        */
               /* DESCRIPTION:     DLC release request from higher layers               */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_ESTABLISHED                                     */
               /* END STATE:       LINK_ESTABLISHED                                     */
               /* ----------------------------------------------------------------------*/
                                                   /* If all two NTW-Layer processes   */
                                                   /* are in state idle and the        */
                                                   /* normal release mode is requested,*/
                                                   /* the DLC link is given up !       */
               if(( KNL_STATE_ARRAY[ CC ][ CurrentInc ] == F00 )     &&
                  ( KNL_STATE_ARRAY[ MM ][ CurrentInc ] == MM_OPEN ))
               {
                  if( PARAMETER1 == NORMAL )
                  {
                                                   /* Normal link release requested !  */

                                                   /* The assignment to the            */
                                                   /* Application layer is suspended.  */
                     Suspend_App_Layer_Assignment( CurrentInc );
                                                   /* Start normal link release        */
                                                   /* procedure.                       */
                                                   /* -------------------------------- */
                     KNL_SENDTASK_INC( LCE, LCE_REL_INVOKED_LCE, CurrentInc );
                  }
                  else
                  {
                                                   /* Partial link release requested ! */

                                                   /* Start Link Maintain Timer        */
                                                   /* -------------------------------- */
                                                   /* Timer:    <LCE_maintain.02>      */
                                                   /* Duration: 10 seconds             */
                     Start_Pro_Timer( TIMER_LCE_02, CurrentInc );
                  }
               }
               else
               {
                                                   /* Restart Link Supervise Timer     */
                                                   /* -------------------------------- */
                                                   /* Timer:    <LCE_Supervise>        */
                                                   /* Duration: 30 seconds             */
                  Start_Pro_Timer( TIMER_LCE_SUPERVISE, CurrentInc );
               }
            }
            return;

            case LCE_PAGE_RESPONSE_LCE:  /*  IN LINE CODE T0301    */
            {
               /* TRANSITION:      T301                                                 */
               /* EVENT:           LCE_PAGE_RESPONSE_LCE                                */
               /* DESCRIPTION:     Layer-3 information received                         */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_ESTABLISHED                                     */
               /* END STATE:       LINK_ESTABLISHED / RELEASE_PENDING                   */
               /* ----------------------------------------------------------------------*/
               BYTE pos, po_no;
                                                   /* Indirect FT initiated link       */
                                                   /* establishment procedure.         */
                                                   /* -------------------------------- */
                                                   /* In case of an unknown portable,  */
                                                   /* the PAGE-REJECT message must be  */
                                                   /* send !                           */

                                                   /* Mandatory << PORTABLE IDENTITY >>*/
                                                   /* included ?                       */
                                                   /* -------------------------------- */
               pos = scan_IE( G_PTR, PORTABLE_IDENTITY, 7, 7 );

               if( pos == 0 )
               {
                  send_down_Page_Reject( NULL, INFORMATION_ELEMENT_ERROR );
                                                   /* Start normal link release        */
                                                   /* procedure.                       */
                                                   /* -------------------------------- */
                  KNL_SENDTASK_INC( LAP, LAP_DL_REL_RQ_NORMAL_LCE, CurrentInc );
                                                   /* Link Release Timer               */
                                                   /* -------------------------------- */
                                                   /* Timer:    <LCE_release.01>       */
                                                   /* Duration: 5 seconds              */
                  Start_Pro_Timer( TIMER_LCE_01, CurrentInc );
                  Mmu_Free( G_PTR );
                  KNL_Transit( RELEASE_PENDING );
                  return;
               }
                                                   /* Content of                       */
                                                   /* << PORTABLE IDENTITY>> correct ? */
                                                   /* -------------------------------- */
                                                   /* The registration of the portable */
                                                   /* is checked.                      */
               #ifdef MASTER_BS
               //Subscription_ForceToRegister( &G_PTR[ pos + 4 ], 0 );
               Subscription_ForceToRegister( &G_PTR[ pos + 4 ], 1 );
               #endif
               po_no = Subscription_GetPotableNoFromIPUI( &G_PTR[ pos + 4 ] );

               if( po_no == 0xFF )
               {
                                                   /* The portable is not known, the   */
                                                   /* link establihsment is rejected.  */
                  send_down_Page_Reject( &G_PTR[ pos + 2 ], DUMMY_FILL );
                                                   /* Start normal link release        */
                                                   /* procedure.                       */
                                                   /* -------------------------------- */
                  KNL_SENDTASK_INC( LAP, LAP_DL_REL_RQ_NORMAL_LCE, CurrentInc );
                                                   /* Link Release Timer               */
                                                   /* -------------------------------- */
                                                   /* Timer:    <LCE_release.01>       */
                                                   /* Duration: 5 seconds              */
                  Start_Pro_Timer( TIMER_LCE_01, CurrentInc );
                  Mmu_Free( G_PTR );
                  KNL_Transit( RELEASE_PENDING );
                  return;
               }
					
                                                   /* Correct PAGE-RESPONSE message    */
                                                   /* was received.                    */
                                                   /* -------------------------------- */
                                                   /* The assignment to the            */
                                                   /* Application layer is set !       */
               Set_App_Layer_Assignment( CurrentInc, po_no );
               Mmu_Free( G_PTR );
               KNL_Transit( LINK_ESTABLISHED );
            }
            return;

            case LCE_REL_INVOKED_LCE:  /*  IN LINE CODE T0204    */
            {
               /* TRANSITION:      T204                                                 */
               /* EVENT:           LCE_REL_INVOKED_LCE                                  */
               /* DESCRIPTION:     Data Link release procedure                          */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_ESTABLISHED                                     */
               /* END STATE:       LINK_ESTABLISHED / RELEASE_PENDING                   */
               /* ----------------------------------------------------------------------*/
                                                   /* If all two NTW-Layer processes   */
                                                   /* are in state idle, and the       */
                                                   /* Application Layer Assignment is  */
                                                   /* still in suspend mode, the DLC   */
                                                   /* link is given up !               */
               if(( KNL_STATE_ARRAY[ CC ][ CurrentInc ] == F00     ) &&
                  ( KNL_STATE_ARRAY[ MM ][ CurrentInc ] == MM_OPEN ) &&
                  ( App_Layer_Assignment_Suspended( CurrentInc ) == TRUE ))
               {
                                                   /* The assignment to the            */
                                                   /* Application layer is cleared.    */
                  Clear_App_Layer_Assignment( CurrentInc );
                                                   /* Start normal link release        */
                                                   /* procedure.                       */
                                                   /* -------------------------------- */
                  KNL_SENDTASK_INC( LAP, LAP_DL_REL_RQ_NORMAL_LCE, CurrentInc );
                                                   /* Link Release Timer               */
                                                   /* -------------------------------- */
                                                   /* Timer:    <LCE_release.01>       */
                                                   /* Duration: 5 seconds              */
                  Start_Pro_Timer( TIMER_LCE_01, CurrentInc );
                  KNL_Transit( RELEASE_PENDING );
               }
               else
               {
                                                   /* Restart Link Supervise Timer     */
                                                   /* -------------------------------- */
                                                   /* Timer:    <LCE_Supervise>        */
                                                   /* Duration: 30 seconds             */
                  Start_Pro_Timer( TIMER_LCE_SUPERVISE, CurrentInc );
               }
            }
            return;

            case LCE_TIM_02_EXPIRED:  /*  IN LINE CODE T0253    */
            {
               /* TRANSITION:      T253                                                 */
               /* EVENT:           LCE_TIM_02_EXPIRED                                   */
               /* DESCRIPTION:     Link Maintain Timer expired                          */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_ESTABLISHED                                     */
               /* END STATE:       LINK_ESTABLISHED                                     */
               /* ----------------------------------------------------------------------*/
                                                   /* If all two NTW-Layer processes   */
                                                   /* are in state idle the DLC link   */
                                                   /* is given up !                    */
               if(( KNL_STATE_ARRAY[ CC ][ CurrentInc ] == F00 )     &&
                  ( KNL_STATE_ARRAY[ MM ][ CurrentInc ] == MM_OPEN ))
               {
                                                   /* The assignment to the            */
                                                   /* Application layer is suspended.  */
                  Suspend_App_Layer_Assignment( CurrentInc );
                                                   /* Start normal link release        */
                                                   /* procedure.                       */
                                                   /* -------------------------------- */
                  KNL_SENDTASK_INC( LCE, LCE_REL_INVOKED_LCE, CurrentInc );
               }
               else
               {
                                                   /* Restart Link Supervise Timer     */
                                                   /* -------------------------------- */
                                                   /* Timer:    <LCE_Supervise>        */
                                                   /* Duration: 30 seconds             */
                  Start_Pro_Timer( TIMER_LCE_SUPERVISE, CurrentInc );
               }
            }
            return;

            case LCE_TIM_SUPERVISE_EXPIRED:  /*  IN LINE CODE T0500    */
            {
               /* TRANSITION:      T500                                                 */
               /* EVENT:           LCE_TIM_SUPERVISE_EXPIRED ( Link Supervise Timeout ) */
               /* DESCRIPTION:     Timer Link Supervise expired                         */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_ESTABLISHED                                     */
               /* END STATE:       LINK_ESTABLISHED                                     */
               /* ----------------------------------------------------------------------*/
                                                   /* If all two NTW-Layer processes   */
                                                   /* are in state idle the DLC link   */
                                                   /* is given up !                    */
                                                   /* -------------------------------- */
               if(( KNL_STATE_ARRAY[ CC ][ CurrentInc ] == F00 )     &&
                  ( KNL_STATE_ARRAY[ MM ][ CurrentInc ] == MM_OPEN ))
               {
                                                   /* The assignment to the            */
                                                   /* Application layer is suspended.  */
                  Suspend_App_Layer_Assignment( CurrentInc );
                                                   /* Start normal link release        */
                                                   /* procedure.                       */
                                                   /* -------------------------------- */
                  KNL_SENDTASK_INC( LCE, LCE_REL_INVOKED_LCE, CurrentInc );
               }
               else
               {
                                                   /* Restart Link Supervise Timer     */
                                                   /* -------------------------------- */
                                                   /* Timer:    <LCE_Supervise>        */
                                                   /* Duration: 30 seconds             */
                  Start_Pro_Timer( TIMER_LCE_SUPERVISE, CurrentInc );
               }
            }
            return;

            case LCE_DL_ENC_KEY_RQ_MM:  /*  IN LINE CODE T0600    */
            {
               /* TRANSITION:      T600                                                 */
               /* EVENT:           LCE_DL_ENC_KEY_RQ_MM                                 */
               /* DESCRIPTION:     Encryption key provision                             */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_ESTABLISHED                                     */
               /* END STATE:       LINK_ESTABLISHED                                     */
               /* ----------------------------------------------------------------------*/
               KNL_SENDTASK_NP_INC( LAP, LAP_DL_ENC_KEY_RQ_LCE, G_PTR, CurrentInc );
            }
            return;

            case LCE_DL_ENC_IND_LAP:  /*  IN LINE CODE T0602    */
            {
               /* TRANSITION:      T602                                                 */
               /* EVENT:           LCE_DL_ENC_IND_LAP                                   */
               /* DESCRIPTION:     Encryption mode confirmation                         */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  LINK_ESTABLISHED                                     */
               /* END STATE:       LINK_ESTABLISHED                                     */
               /* ----------------------------------------------------------------------*/
               KNL_SENDTASK_WP_INC( MM, MM_DL_ENC_IND_LCE, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4, CurrentInc );
            }
            return;

            default:
               break;
         }										/* end of switch message				*/
         break; 

      case RELEASE_INDICATION:
         switch (CurrentMessage) 
         {
            case LCE_TIM_03_EXPIRED: 
               T0252();
               return;

            case LCE_REL_ROUND_LCE:  /*  IN LINE CODE T0203    */
            {
               /* TRANSITION:      T203                                                 */
               /* EVENT:           LCE_REL_ROUND_LCE                                    */
               /* DESCRIPTION:     Data Link release                                    */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  RELEASE_INDICATION                                   */
               /* END STATE:       LINK_RELEASED                                        */
               /* ----------------------------------------------------------------------*/
                                                   /* The assignment to the            */
                                                   /* Application layer is cleared.    */
               Clear_App_Layer_Assignment( CurrentInc );
                                                   /* Stop Link Release Timer          */
               Stop_Pro_Timer( TIMER_LCE_01, CurrentInc );
                                                   /* Stop Link Maintain Timer         */
               Stop_Pro_Timer( TIMER_LCE_02, CurrentInc );
                                                   /* Stop Link Supervise Timer        */
               Stop_Pro_Timer( TIMER_LCE_SUPERVISE, CurrentInc );

               KNL_Transit( LINK_RELEASED );
            }
            return;

            case LCE_DL_EST_IN_LAP:
            {
               // This message can be received during the RELEASE_INDICATION state.
               // The messsage is enqueued again.
               KNL_SENDTASK_INC( LCE, LCE_DL_EST_IN_LAP, CurrentInc );
            }
            return;

            case LCE_DL_DATA_IN_LAP:
            {
               // This message can be received during the RELEASE_INDICATION state.
               // The messsage is enqueued again.
               KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_IN_LAP, G_PTR, CurrentInc );
            }
            return;

            default:
               break;
         }										/* end of switch message				*/
         break; 

      case RELEASE_PENDING:
         switch (CurrentMessage) 
         {
            case LCE_DL_REL_IN_LAP: 
            case LCE_DL_REL_CFM_LAP:  /*  IN LINE CODE T0202    */
            {
               /* TRANSITION:      T202                                                 */
               /* EVENT:           LCE_DL_REL_IN_LAP / LCE_DL_REL_CFM_LAP               */
               /* DESCRIPTION:     Data Link release                                    */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  RELEASE_PENDING                                      */
               /* END STATE:       LINK_RELEASED                                        */
               /* ----------------------------------------------------------------------*/
                                                   /* The DLC-Layer is confirming the  */
                                                   /* link release.                    */
                                                   /* -------------------------------- */
                                                   /* Stop Link Release Timer          */
               Stop_Pro_Timer( TIMER_LCE_01, CurrentInc );
                                                   /* Stop Link Maintain Timer         */
               Stop_Pro_Timer( TIMER_LCE_02, CurrentInc );
                                                   /* Stop Link Supervise Timer        */
               Stop_Pro_Timer( TIMER_LCE_SUPERVISE, CurrentInc );

               KNL_Transit( LINK_RELEASED );
            }
            return;

            case LCE_TIM_03_EXPIRED: 
               T0252();
               return;

            case LCE_TIM_01_EXPIRED:  /*  IN LINE CODE T0251    */
            {
               /* TRANSITION:      T251                                                 */
               /* EVENT:           LCE_TIM_01_EXPIRED                                   */
               /* DESCRIPTION:     Link Release Timer expired                           */
               /* REFERENCE:       ETS 300 175-5:1996                                   */
               /* STARTING STATE:  RELEASE_PENDING                                      */
               /* END STATE:       LINK_RELEASED                                        */
               /* ----------------------------------------------------------------------*/
                                                   /* Link Release Timer expired.      */
                                                   /* -------------------------------- */
                                                   /* Start abnormal link release      */
                                                   /* procedure.                       */
               KNL_SENDTASK_INC( LAP, LAP_DL_REL_RQ_ABNORMAL_LCE, CurrentInc );
               #ifndef CONFIG_UPDATE_LINK_RELEASE
                                                   /* Stop Link Release Timer          */
               Stop_Pro_Timer( TIMER_LCE_01, CurrentInc );
                                                   /* Stop Link Maintain Timer         */
               Stop_Pro_Timer( TIMER_LCE_02, CurrentInc );
                                                   /* Stop Link Supervise Timer        */
               Stop_Pro_Timer( TIMER_LCE_SUPERVISE, CurrentInc );

               KNL_Transit( LINK_RELEASED );
               #endif
            }
            return;

            default:
               break;
         }										/* end of switch message				*/
         break; 
   }												/* end of switch state					*/
   KNL_T0000();
}													/* end of DECODE_LCE()					*/
