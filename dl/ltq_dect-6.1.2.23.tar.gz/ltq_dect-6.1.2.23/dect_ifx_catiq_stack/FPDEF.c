#include "SYSDEF.H" 
#include "FDEF.H" 
#include "TYPEDEF.H" 
#include "SYSEXT.H" 
extern void KNL_T0000(void); 

extern void  DECODE_ME(void); 
extern void  ME_INIT  (void);
 
extern void  DECODE_LAP(void); 
extern void  LAP_INIT  (void);
extern void  RESET_LAP_INIT	(void);

extern void  DECODE_LC(void); 
extern void  LC_INIT  (void);
extern void  RESET_LC_INIT  (void);

//#ifdef CONFIG_REPEATER_SUPPORT
extern void  DECODE_LAP_REP(void); 
extern void  LAP_REP_INIT  (void);
extern void  RESET_LAP_REP_INIT	(void);

extern void  DECODE_LC_REP(void); 
extern void  LC_REP_INIT  (void);
extern void  RESET_LC_REP_INIT  (void);
//#endif

extern void  DECODE_LB(void); 
extern void  LB_INIT  (void);
#ifdef FT_CLMS 
extern void  DECODE_CLMS(void); 
extern void  CLMS_INIT  (void);
#endif
extern void  DECODE_LCE(void); 
extern void  LCE_INIT  (void);
extern void  RESET_LCE_INIT  (void);

extern void  DECODE_CC(void); 
extern void  CC_INIT  (void);
 
extern void  DECODE_MM(void); 
extern void  MM_INIT  (void);
extern void  RESET_MM_INIT (void); 

void   KNL_DECODE(void)
{ 
    switch ( ProcId ) 
    {
            case  ME : DECODE_ME(); 
//					printf("%s:DECODE_ME: Exit\n",__FUNCTION__);
						return; 
            case  LAP : DECODE_LAP(); 
//					printf("%s:DECODE_LAP: Exit\n",__FUNCTION__);
						return; 
            case  LC : DECODE_LC(); 
//					printf("%s:DECODE_LC: Exit\n",__FUNCTION__);
						return; 
            //#ifdef CONFIG_REPEATER_SUPPORT
            case  LAP_REP : DECODE_LAP_REP();
//					printf("%s:DECODE_LAP: Exit\n",__FUNCTION__);
						return; 
            case  LC_REP : DECODE_LC_REP();
//					printf("%s:DECODE_LC: Exit\n",__FUNCTION__);
						return; 
            //#endif
            case  LB : DECODE_LB(); 
//					printf("%s:DECODE_LB: Exit\n",__FUNCTION__);
						return;
#ifdef FT_CLMS
            case  CLMS :
                  DECODE_CLMS( );
				  return; 
#endif
            case  LCE : DECODE_LCE(); 
//					printf("%s:DECODE_LCE: Exit\n",__FUNCTION__);
						return; 
            case  CC : DECODE_CC(); 
//					printf("%s:DECODE_CC: Exit\n",__FUNCTION__);
						return; 
            case  MM : DECODE_MM(); 
//					printf("%s:DECODE_MM: Exit\n",__FUNCTION__);
						return; 
            default   : KNL_T0000();      return; 
    }                            /* end of switch ( ProcId ) */ 
}                                /* end of function DECODE */ 


void   KNL_INIT_PROC(void)
{ 
           ME_INIT(); 
           LAP_INIT(); 
           LC_INIT(); 
           //#ifdef CONFIG_REPEATER_SUPPORT
           LAP_REP_INIT();
           LC_REP_INIT();
           //#endif
           LB_INIT(); 
           LCE_INIT(); 
           CC_INIT(); 
           MM_INIT(); 
}/* end of function KNL_INIT_PROC */ 


void   RESET_KNL_INIT_PROC(void)
{ 

           ME_INIT(); 
           RESET_LAP_INIT(); 
           RESET_LC_INIT(); 
           //#ifdef CONFIG_REPEATER_SUPPORT
           RESET_LAP_REP_INIT();
           RESET_LC_REP_INIT();
           //#endif
           LB_INIT(); 
           RESET_LCE_INIT(); 
           CC_INIT(); 
           RESET_MM_INIT(); 
}/* end of function RESET_KNL_INIT_PROC */ 



