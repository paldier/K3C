/* -- SIEMENS AG  PCT -- Process: LC          -  Mon Feb 26 14:22:27 2007 -- */

#include "DEFINE.H"
# include <stdio.h>
# include <string.h>
# include "SYSDEF.H"
# include "FDEF.H"
# include "TYPEDEF.H"
#include <unistd.h>
extern void KNL_T0000(void);
# include "SYSEXT.H"

/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0       *
*                   (c) 2005 IFX / INTNIX. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  FLC.PSL                                                 *
*     Date       :  18 Nov, 2005                                            *
*     Contents   :                                                          *
*     Hardware   :  IFX 87xx                                                *
*                                                                           *
*****************************************************************************
*/
/* ========                                                             */
/* Includes                                                             */
/* ========                                                             */
#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#include "FGLOBAL.H"
#include "PCT_DEF.H"
#include "KNL_SYSTEM.H"
#include "MMU.H"
#include "P_TIM.H"
#include "LC_LIB.H"
#include	"LCE_LIB.H"
#include	"CP_SERVER.H"

#include "dect_drv_if.h"

/* ==============                                                       */
/* Local typedefs                                                       */
/* ==============                                                       */
#ifdef DECT_DEBUG_USER_LC_REP_PRIMITIVE
typedef struct {
   BYTE key;
   char *string;
} DebugStringTable_t;
#endif

/* ===============                                                      */
/* Local variables                                                      */
/* ===============                                                      */
#ifdef DECT_DEBUG_USER_LC_REP_PRIMITIVE
LOCAL DebugStringTable_t stateStringTable[] = {
   {CLOSED, "CLOSED"},
   {OPEN, "OPEN"},
   {FREE, "FREE"},
   {0xFF, "Unknown State"}
};
/*   Messages	*/

LOCAL DebugStringTable_t messageStringTable[] = {
   {LC_REL_RQ_NORMAL_LAP, "LC_REP_REL_RQ_NORMAL_LAP"},
   {LC_REL_RQ_ABNORMAL_LAP, "LC_REP_REL_RQ_ABNORMAL_LAP"},
   {LC_DIS_IN_MAC, "LC_REP_DIS_IN_MAC"},
   {LC_DIS_CFM_MAC, "LC_REP_DIS_CFM_MAC"},
   {LC_CON_IN_MAC, "LC_REP_CON_IN_MAC"},
   {LC_CO_DATA_DTR_MAC, "LC_REP_CO_DATA_DTR_MAC"},
   {LC_CO_DATA_IN_MAC, "LC_REP_CO_DATA_IN_MAC"},
   {LC_CO_DATA_RQ_LAP, "LC_REP_CO_DATA_RQ_LAP"},
   {LC_DL_ENC_KEY_RQ_LAP, "LC_REP_DL_ENC_KEY_RQ_LAP"},
   {LC_ENC_EKS_IND_MAC, "LC_REP_ENC_EKS_IND_MAC"},
   #ifdef CONFIG_REPEATER_SUPPORT
   {LC_REP_ACCESS_REQ, "LC_REP_ACCESS_REQ"},
   {LC_REP_ACCESS_CFM, "LC_REP_ACCESS_CFM"},
   {LC_REP_CIPHER_CFM_ON, "LC_REP_CIPHER_CFM_ON"},
   {LC_REP_CIPHER_RQ, "LC_REP_CIPHER_RQ"},
   #endif
   {0xFF, "Unknown Message"}
};
#endif

#ifdef CONFIG_REPEATER_SUPPORT
LOCAL XDATA BYTE  Repeater_Idx = 0;
LOCAL XDATA BYTE  Repeater_Lbn = 0xFF;
#endif

/* ==========================                                           */
/* Global function definition                                           */
/* ==========================                                           */
EXPORT void
LC_REP_INIT( void )
{
   Init_Queue( LC_REP );
   #ifdef CONFIG_REPEATER_SUPPORT
   Rep_Cs_Ctrl_Init ();
   #endif
}

/* ==========================											*/
/* Global function definition											*/
/* ==========================											*/
EXPORT void
RESET_LC_REP_INIT( void )
{
   unsigned char i;

   for( i = 0; i < MAX_LINK; i++ )
   {
      Discard_Queue(LC_REP, i);		// malloc queue clear by ralph_150508
      #ifdef CONFIG_REPEATER_SUPPORT
      Rep_Reset_Cs_Ctrl(i);
      #endif
   }
   Init_Queue( LC_REP );
}

#ifdef DECT_DEBUG_USER_LC_REP_PRIMITIVE
LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
{
   BYTE i;

   for (i = 0; tablePtr[i].key != 0xFF; i++) {
      if (tablePtr[i].key == key) {
         break;
      }
   }
   return tablePtr[i].string;
}
#endif

//****************************************************************************
//****************************************************************************
void
DECODE_LC_REP(void)
{
   #ifdef DECT_DEBUG_USER_LC_REP_PRIMITIVE
   DECT_DEBUG_REPEAT("LC_REP:%s, %s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable),
   getDebugStringRef(CurrentState, stateStringTable), CurrentInc, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
   #endif

   #ifdef CONFIG_REPEATER_SUPPORT
   switch (CurrentMessage)
   {
      case LC_REL_RQ_NORMAL_LAP:
      case LC_REL_RQ_ABNORMAL_LAP:
      case LC_DIS_IN_MAC:
      case LC_DIS_CFM_MAC:
         Repeater_Idx = 0;
         Repeater_Lbn = 0xFF;
         Discard_Queue( LC_REP, CurrentInc );
         Rep_Reset_Cs_Ctrl( CurrentInc );
         KNL_SENDTASK_WP_INC( LAP_REP, LAP_REL_IN_LC, 0, 0, 0, 0, CurrentInc );
         return;

      #ifdef CONFIG_REPEATER_SUPPORT
      case LC_REP_ACCESS_REQ:
         Repeater_Lbn = PARAMETER2;
         Repeater_Idx = PARAMETER3;
         write_to_hmac_ioctl( HMAC, MAC_REP_ACCESS_REQ,
                              CurrentInc, PARAMETER2, PARAMETER3, PARAMETER4,
                              0, 0, 0, 0);
         #ifdef FAST_HANDOVER    // Fast Handover make no Bearer_CFM from Repeater to Handset
         if (PARAMETER4 == 0) {
            Rep_Load_LSIG(CurrentInc, Repeater_Idx);
            DECT_DEBUG_REPEAT("RLSIG:%02x %02x\n", HIBYTE( RLSIG_Value[ CurrentInc ] ), LOBYTE( RLSIG_Value[ CurrentInc ] ));
            Discard_Queue(LC_REP, CurrentInc);
            Rep_Reset_Cs_Ctrl(CurrentInc);
         }
         #endif
         break;

      case LC_REP_ACCESS_CFM:
         Rep_Load_LSIG(CurrentInc, Repeater_Idx);
         DECT_DEBUG_REPEAT("RLSIG:%02x %02x\n", HIBYTE( RLSIG_Value[ CurrentInc ] ), LOBYTE( RLSIG_Value[ CurrentInc ] ));
         Discard_Queue(LC_REP, CurrentInc);
         Rep_Reset_Cs_Ctrl(CurrentInc);
         KNL_SENDTASK_WP_INC( LAP_REP, LAP_REP_ACCESS_CFM, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4, CurrentInc );
         break;

      case LC_REP_CIPHER_RQ:
         KNL_SENDTASK_WP_INC(MM, MM_MMS_CIPHER_ON_RQ, LC_REP, LC_REP_CIPHER_CFM_ON, CurrentInc, Get_Assigned_Po_No(CurrentInc), CurrentInc);
         break;

      case LC_REP_CIPHER_CFM_ON:
         usleep(5000);
         write_to_hmac_ioctl( HMAC, MAC_CIPHER_CFM_ON,
                              CurrentInc, PARAMETER1, PARAMETER2, PARAMETER4,
                              0, 0, NULL, CurrentInc);
         break;
      #endif

      case LC_CO_DATA_DTR_MAC:  /*  IN LINE CODE T0300    */
      {
         /* TRANSITION:      T0300                                                */
         /* EVENT:           LC_CO_DATA_DTR_MAC                                   */
         /* DESCRIPTION:     MAC Layer flow control                               */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  OPEN                                                 */
         /* END STATE:       FREE                                                 */
         /* ----------------------------------------------------------------------*/
         FPTR temp;
         FPTR malloc_temp;

                                             /* MAC Layer Flow Control           */
                                             /* -------------------------------- */
         temp = Rep_MacCoDtr_received( CurrentInc );

			if( temp != NULL )
			{
                                             /* The transmission of the          */
                                             /* DLC-frame is not yet completed.  */
                                             /* The next Cs-Fragment is send.    */
            malloc_temp = Mmu_Malloc(5);

            #ifdef KLOCWORK
            if( malloc_temp != NULL )
            #endif
            {
               memset(malloc_temp, 0, 5);
               memcpy(malloc_temp, temp, 5);

               // TODO: NOT USE
               write_to_hmac_ioctl( HMAC, MAC_REP_CO_DATA_RQ_LC,
                                 CurrentInc, Repeater_Lbn, 0, 0,
                                 0, 5, malloc_temp, 0);
               DECT_DEBUG_USER_LC_DATA("[LC] Data Out: %02x Data: %02x %02x %02x %02x %02x\n",
                                 CurrentInc, temp[0], temp[1], temp[2], temp[3], temp[4]);
            }
         }
         else
         {
                                             /* The transmission of the          */
                                             /* DLC-frame is completed.          */
                                             /* Another DLC-Frame queued ?       */
            temp = Get_Next_Queue_Entry( LC_REP, CurrentInc );

            if( temp != NULL )
            {
                                             /* Set Transmit Control with next   */
                                             /* DLC-Frame.                       */
               temp = Rep_Set_Tx_Ctrl( CurrentInc, temp );
                                             /* Invoke transmission of first     */
                                             /* Cs-Fragment.                     */

               malloc_temp = Mmu_Malloc(5);
               #ifdef KLOCWORK
               if( malloc_temp != NULL )
               #endif
               {
                  memset(malloc_temp, 0, 5);
                  memcpy(malloc_temp, temp, 5);

                  // TODO:  not use strip  Set_Tx_Ctrl
                  write_to_hmac_ioctl( HMAC, MAC_REP_CO_DATA_RQ_LC,
                                    CurrentInc, Repeater_Lbn, 0, 0,
                                    0, 5, malloc_temp, 0);

                  DECT_DEBUG_USER_LC_DATA("[LC] Data Out: %02x Data: %02x %02x %02x %02x %02x\n",
                                             CurrentInc, temp[0], temp[1], temp[2], temp[3], temp[4]);
               }
            }
         }
      }
      return;

      case LC_CO_DATA_IN_MAC:
      {
         /* TRANSITION:      T0301                                                */
         /* EVENT:           LC_CO_DATA_IN_MAC                                    */
         /* DESCRIPTION:     MAC Layer reports data indication                    */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  OPEN / FREE                                          */
         /* END STATE:       current state maintained                             */
         /* ----------------------------------------------------------------------*/
         FPTR temp;
                                             /* The received Cs-Fragment is      */
                                             /* stored.                          */
         DECT_DEBUG_REPEAT("[LC_REP] Data In: %02x Data: %02x %02x %02x %02x %02x\n", CurrentInc, G_PTR[ sizeof( struct HLI_Header ) ],
                           G_PTR[sizeof( struct HLI_Header ) + 1],G_PTR[sizeof( struct HLI_Header ) + 2],
                           G_PTR[sizeof( struct HLI_Header ) + 3],G_PTR[sizeof( struct HLI_Header ) + 4]);
         temp = Rep_Ct_fragment_received( CurrentInc, G_PTR );

         if( temp != NULL )
         {
                                             /* A complete DLC-Frame is received.*/
                                             /* The frame is passed to the LAP   */
                                             /* process.                         */
                                             /* ---------------------------------*/
                                             /* CID value: Connection ID         */
                                             /* LCN value: logical Connection No */
                                             /* Only one LC process incarnation  */
                                             /* per DLC Layer (no Connection HOV */
                                             /* support at the FT side).         */
            Rep_Decode_Received_Frame( CurrentInc, CurrentInc, temp );
         }
      }
      return;

      case LC_CO_DATA_RQ_LAP:  /*  IN LINE CODE T0401    */
      {
         /* TRANSITION:      T0401                                                */
         /* EVENT:           LC_CO_DATA_RQ_LAP                                    */
         /* DESCRIPTION:     Data Request from LAP-Process                        */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  OPEN_PENDING / OPEN / FREE                           */
         /* END STATE:       current state maintained                             */
         /* ----------------------------------------------------------------------*/
         FPTR temp;
         FPTR malloc_temp;
                                             /* A MAC connection is established  */
                                             /* and the flow control allows to   */
                                             /* transmit immediately the first   */
                                             /* Cs-Fragment.                     */
         Put_in_Queue( LC_REP, CurrentInc, Make_Fill_Bytes_and_CRC( CurrentInc, G_PTR ));

         if( RCS_ctrl[CurrentInc].txCframe_length == 0 )
         {
            temp = Get_Next_Queue_Entry( LC_REP, CurrentInc );
            if( temp != NULL )
            {
                                                /* Set Transmit Control with next   */
                                                /* DLC-Frame.                       */
               temp = Rep_Set_Tx_Ctrl( CurrentInc, temp );
                                                /* Invoke transmission of first     */
                                                /* Cs-Fragment.                     */
               malloc_temp = Mmu_Malloc(5);
               #ifdef KLOCWORK
               if( malloc_temp != NULL )
               #endif
               {
                  memset(malloc_temp, 0, 5);
                  memcpy(malloc_temp, temp, 5);

                  write_to_hmac_ioctl( HMAC, MAC_REP_CO_DATA_RQ_LC,
                                    CurrentInc, Repeater_Lbn, 0, 0,
                                    0, 5, malloc_temp, 0);
                  DECT_DEBUG_USER_LC_DATA("[LC] Data Out: %02x Data: %02x %02x %02x %02x %02x\n",
                                             CurrentInc, temp[0], temp[1], temp[2], temp[3], temp[4]);
               }
            }
         }
      }
      return;

      case LC_DL_ENC_KEY_RQ_LAP:
         write_to_hmac_ioctl( HMAC, MAC_ENC_KEY_RQ_LC,
                              CurrentInc, PARAMETER1, PARAMETER2, 0,
                              1, 0, G_PTR, 0);
         return;

      case LC_ENC_EKS_IND_MAC:
         KNL_SENDTASK_WP_INC( LAP_REP, LAP_DL_ENC_IND_LC, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4, CurrentInc );
         return;

      default:
         break;
   }										/* end of switch message				*/
   #endif //#ifdef CONFIG_REPEATER_SUPPORT
   KNL_T0000();
}													/* end of DECODE_LC()					*/
