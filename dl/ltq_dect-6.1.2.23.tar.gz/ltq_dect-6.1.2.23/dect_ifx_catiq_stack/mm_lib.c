/* =======================================================================
 * Copyright (C) 2013 LANTIQ. All rights reserved.
 * Copyright (C) 2013 INTNIX. All rights reserved.
 * ======================================================================= */

/* =======================================================================
 * File:                   MM_LIB.c
 *
 * Programmer:
 * Created:                2005-11-18
 *
 * Description:            Library for Process 'MOBILE MANAGEMENT (MM)'
 * Module:
 * Controlling Document:
 * System Dependencies:
 *
 * Remarks:
 * ======================================================================= */

/* =======================================================================
 * Include Files
 * ======================================================================= */
#include<stdio.h>
#include<string.h>
#include <stdlib.h>

#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#include "FDEF.H"
#include "KNL_SYSTEM.H"
#include "MMU.H"

#ifdef CONFIG_EARLY_ENCRYPTION
#include "dect_drv_if.h"
#endif

#include "CC_DEF.H"
#include "CC_LIB.H"
#ifdef FT
#include "FGLOBAL.H"
#include "FBMC_DEF.H"
#endif
#include "ENI_LIB.H"
//#include "PROP.H"
#ifdef ULE_SUPPORT
#include "ULE_DLC.h"
#endif
#include "MM_LIB.H"
#include "FMM.H"

#include "DSAA.H"    /* DSAA object include */
#ifdef ULE_SUPPORT
#include "DSAA2.h"
#include "PCT_DEF.H"
#include "CP_SERVER.H"
#include "MESSAGE_DEF.H"
#endif

//#define printf(...)

/* =======================================================================
 * External Reference
 * ======================================================================= */
#ifdef SMART_HOME_DEMO
extern uint32 SBBflg;
#endif

#ifdef CAT_IQ2_0
extern uint32 IFX_DECT_CheckWB(uint32 uiTermCap);
#endif

/* =======================================================================
 * Definitions
 * ======================================================================= */
/*
   TPUI Structure: 20 bits
   -----------------------
   1st nibble: TPUI type - From Spec
      - 0: Assigned individual (0 ~ B)
      - E: Default individual
   2nd nibble: Device type for assigned individual type - 0 ~ B, Internal use
      - 1: Normal DECT PP
      - 2: ULE DECT PP
   3nd nibble: The same value as 2nd nibble
   4th ~ 5th nibble: ID for assigned individual type
      - 1 ~ 6: Normal DECT PP
      - 7 ~ 255: ULE DECT PP
 */
// Device type for assigned individual type
#define NORMAL_DECT_TPUI_TYPE 0x11
#define ULE_DECT_TPUI_TYPE 0x22
#define REP_DECT_TPUI_TYPE    0x33

#ifdef CONFIG_TEST_DIALOG_LIMITED_TPUI
#define GET_BIT_OFFSET(p) (p - ULE_DEVICE_OFFSET + 1) // 1 ~ n
#else
#define GET_BIT_OFFSET(p) Subscription_GetBitOffset(p)
#endif

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */
#ifdef ULE_SUPPORT
typedef enum {
   IFX_DECT_ULE_NONE = 0,/*!< No Device type*/
   IFX_DECT_ULE_SENSOR = 1, /*!< SENSOR ULE Device type*/
   IFX_DECT_ULE_SLOWACTUATOR = 2, /*!< Slow Actuator ULE Device type*/
   IFX_DECT_ULE_FASTACTUATOR = 3 /*!< Fast Actuator ULE Device type*/
} e_IFX_DECT_ULE_Type;

typedef struct {
   uint32 uiSensorPageCycle; /*!< Paging cycles for Sensors type devices */
   uint32 uiStart_MFN_Sensor; /*!< MFN for Sensors type devices */
   uint8 ucStart_FCNT_Sensor;/*!< FCNT for Sensors type devices */
   uint8 ucActiveChnlSensor;/*!< Active Channel used for paging Sensors type devices */

   uint32 uiSlowActuatorPageCycle; /*!< Paging cycles for Slow Actuators type devices */
   uint32 uiStart_MFN_SlowAct;/*!< MFN for Slow Actuators type devices */
   uint8 ucStart_FCNT_SlowAct;/*!< FCNT for Slow Actuators type devices */
   uint8 ucActiveChnlSlowAct;/*!< Active Channel used for paging Slow Actuators type devices */

   uint32 uiFastActuatorPageCycle; /*!< Paging cycles for Fast Actuators type devices */
   uint32 uiStart_MFN_FastAct;/*!< MFN for  Fast Actuators type devices */
   uint8 ucStart_FCNT_FastAct;/*!< FCNT for Fast Actuators type devices */
   uint8 ucActiveChnlFastAct;/*!< Active Channel used for paging Fast Actuators type devices */

   uint32 uiStayAliveCycle; /*!< Stay Alive cycles for all ULE devices */
   uint32 uiSDUSize; /*!< Max SDU size supported by FP */
   uchar8 ucWindowSize; /*!< Max Window size supported by FP for LU14/LU13 Data packets*/
} FT_ULE_PAGE_DESCRIPTION;
#endif

/* =======================================================================
 * Local Variables
 * ======================================================================= */
/* -----------------------------------------------------------------------
 * Name: LocalVar
 * Description:
 * ----------------------------------------------------------------------- */
#ifdef FT
   #ifdef ULE_SUPPORT
LOCAL FT_SUBSCRIPTION XDATA FT_Subscription[NR_OF_PORTABLE];
   #else
LOCAL FT_SUBSCRIPTION XDATA FT_Subscription[MAX_PORTABLE];
   #endif
  #ifdef CONFIG_REPEATER_SUPPORT
GLOBAL FT_REP_SUBSCRIPTION XDATA FT_RepSubscription[NR_OF_REP_DEVICE];
  #endif
LOCAL FT_IDENTITY XDATA FT_Identity;
LOCAL BYTE XDATA AC_Array[4] = {0xFF, 0xFF, 0,0};
#endif

LOCAL BYTE XDATA d1[16];
LOCAL BYTE XDATA d2[8];
LOCAL BYTE XDATA e[16];

/* =======================================================================
 * Global Variables
 * ======================================================================= */
GLOBAL BYTE Freq_Run = 0x09; // DECT frequency carrier number range for different band (begin 0 ~ end 9)
GLOBAL BYTE Freq_TX_Offset = 0; // frequency offset for different Tx band (usa= 18, korea = 9(n2=0))
GLOBAL BYTE Freq_RX_Offset = 0; // frequency offset for different Rx band (usa= 18, korea = 10(n2=0))

GLOBAL BYTE Osc_Trim_H = 0x00;
GLOBAL BYTE Osc_Trim_L = 0x07;

GLOBAL WORD GFSK_Value;

GLOBAL BYTE Tpc_Param_Buf[43];
GLOBAL BYTE Tpc_Param_Buf1[43];
GLOBAL BYTE Tpc_Param_Buf2[43];
GLOBAL BMC_RSSI_STRUCT Bmc_Rssi_Settings;
GLOBAL OSC_TRIM_STRUCT Osc_Trim_Settings;
GLOBAL BYTE NoEmo_StartUp_Mode = 0;
GLOBAL BYTE NoEmo_StartUp_Ch = 8;

/* =======================================================================
 * Local Function Prototypes
 * ======================================================================= */
/* -----------------------------------------------------------------------
 * Function    :
 * Descriptions: Open DLC for data transmit/receive
 * Parameters  : aMCEI - MCEI
 *               aPMIDPtr - Pointer to PMID
 * Return Value: YES / NO
 * Remarks     :
 * Requirments :
 * Call Level  :
 * ----------------------------------------------------------------------- */
#if 0
LOCAL void Write_EEPROM_Subscription_Data(BYTE reg_no);
#endif
#ifdef ULE_SUPPORT
LOCAL BYTE getPotableNoFromIPUIWithPotableType(BYTE XDATA * ipui_ptr, BOOL ULEType);
#endif

/* =======================================================================
 * Local Function Definitions
 * ======================================================================= */
/*
*****************************************************************************
*                                                                           *
*   Function   :  Write_EEPROM_Subscription_Data( BYTE reg_no )         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  to save code                                              *
*   Parms      :  po_no         : target po no                              *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#if 0
LOCAL void
Write_EEPROM_Subscription_Data( BYTE reg_no )
{
                                       /* Write new registration slot data */
                                       /* to EEPROM.                       */
   // It should be checkd. Some message should be sent to Dect Agent.
   #ifdef F_NEED_CHECK_DECT_STACK
   #ifdef FT
   Insert_I2C_Write_Job_EEPROM(  sizeof( FT_SUBSCRIPTION ),
                                 HIBYTE((WORD) &((FT_SUBSCRIPTION *)SYS_FT_EEP_ADDR->Subscription)[ reg_no - 1 ]),
                                 LOBYTE((WORD) &((FT_SUBSCRIPTION *)SYS_FT_EEP_ADDR->Subscription)[ reg_no - 1 ]),
                                 (FPTR) &FT_Subscription[ reg_no - 1 ] );
   #endif
   #endif
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
LOCAL BYTE
getPotableNoFromIPUIWithPotableType(BYTE XDATA * ipui_ptr, BOOL DeviceType)
{
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   BYTE regNo;

   if (ipui_ptr == NULL) {
      return (0xFF);
   }

   switch (DeviceType) {
      #ifdef ULE_SUPPORT
      case ULE_DEVICE:
         for (regNo = 0; regNo < NR_OF_ULE_DEVICE; regNo++) {
            #ifdef KLOCWORK
            uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(regNo);
            #else
            uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(regNo+ULE_DEVICE_OFFSET);
            #endif
            if((uleSubscriptionPtr->status == VALID) && (Mmu_Memcmp(ipui_ptr, uleSubscriptionPtr->ipui_array, 5))) {
               return (regNo + ULE_DEVICE_OFFSET);
            }
         }
         break;
      #endif

      #ifdef CONFIG_REPEATER_SUPPORT
      case REP_DEVICE:
         for (regNo = 0; regNo < NR_OF_REP_DEVICE; regNo++) {
            if((FT_RepSubscription[regNo].status == VALID) && (Mmu_Memcmp(ipui_ptr, FT_RepSubscription[regNo].ipui_array, 5))) {
                  return (regNo + REP_DEVICE_OFFSET);
            }
         }
         break;
      #endif

      default:
         for (regNo = 0; regNo < NR_OF_PORTABLE; regNo++) {
            if((FT_Subscription[regNo].status == VALID) && (Mmu_Memcmp(ipui_ptr, FT_Subscription[regNo].ipui_array, 5))) {
               return (regNo + 1);
            }
         }
         break;
   }

   // The portable is not known, return 0xFF!
   return (0xFF);
}
#endif

/* =======================================================================
 * Global Function Definitions
 * ======================================================================= */
/*
*****************************************************************************
*                                                                           *
*   Function   :  Load_FT_Identity                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The FT Identity structure is loaded with data from        *
*                 EEPROM.                                                   *
*   Parms      :  ptr             : pointer to the read EEPROM data         *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Load_FT_Identity( FPTR ptr )
{
   Mmu_Memcpy( (FPTR) &FT_Identity, ptr, sizeof( FT_IDENTITY ));
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Get_Rfpi_Ptr                                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function returns the RFPI of the FT.                  *
*   Parms      :  none                                                      *
*   Returns    :  Pointer to the five byte RFPI array.                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT FPTR
Get_Rfpi_Ptr( void )
{
// FT_Identity.rfpi_array[0] = 0x00;      /* temp */
// FT_Identity.rfpi_array[1] = 0x55;      /* temp */
// FT_Identity.rfpi_array[2] = 0x00;      /* temp */
// FT_Identity.rfpi_array[3] = 0xAA;      /* temp */
// FT_Identity.rfpi_array[4] = 0x08;      /* temp */

   return( FT_Identity.rfpi_array );
}
#endif

#ifdef FT
EXPORT void
Set_Repeater_Rfpi( BYTE on_off )
{
   if (on_off == ON) {
      FT_Identity.rfpi_array[4] |=  0x01;
   } else {
      FT_Identity.rfpi_array[4] &= ~0x07;
   }
}
#endif


/*
*****************************************************************************
*                                                                           *
*   Function   :  Check_Received_ARI_RPN                                    *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions checks the received ARI+RPN element.        *
*   Parms      :  Pointer         : Pointer to the received ARI+RPN element.*
*   Returns    :  TRUE / FALSE                                              *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef XXXXXFT
EXPORT BIT
Check_Received_ARI_RPN( FPTR ari_rpn_ptr )
{
                                       /* PRODECT Version 2.0 is designed  */
                                       /* to fulfill all requirements for  */
                                       /* a Home System. The E-Bit (Sari   */
                                       /* List available) should be never  */
                                       /* set. The received ARI+RPN can    */
                                       /* therefore directly be compared   */
                                       /* with the RFPI.                   */
   return( Mmu_Memcmp( FT_Identity.rfpi_array, ari_rpn_ptr, 5 ));
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Check_Received_PARK                                       *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions checks the received PARK element.           *
*   Parms      :  Pointer         : Pointer to the received PARK element.   *
*   Returns    :  TRUE / FALSE                                              *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BIT
Check_Received_PARK( FPTR park_ptr )
{
                                       /* PRODECT Version 2.0 is designed  */
                                       /* to fulfill all requirements for  */
                                       /* a Home System.                   */
                                       /* The received PARK-Key has the    */
                                       /* default Park Length Indicator of */
                                       /* 36. The first bit is always set  */
                                       /* to zero and therefore not        */
                                       /* evaluated.                       */
                                       /* The assigend PARK-Key is         */
                                       /* identically to the used PARI     */
                                       /* included in the RFPI.            */
   return( Mmu_Memcmp_Bit( FT_Identity.rfpi_array, park_ptr, 1, 37 ));
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT BOOL
IsValidPortableNo(BYTE portableNo, BYTE whichPortable)
{
   switch(whichPortable) {
      case PORTABLE_DECT:
         if ((portableNo > 0) && (portableNo <= NR_OF_PORTABLE)) {
            return TRUE;
         }
         break;

      case PORTABLE_ULE:
         if ((portableNo >= ULE_DEVICE_OFFSET) && (portableNo < (ULE_DEVICE_OFFSET + NR_OF_ULE_DEVICE))) {
            return TRUE;
         }
         break;

      case PORTABLE_REP:
         if ((portableNo >= REP_DEVICE_OFFSET) && (portableNo < (REP_DEVICE_OFFSET + NR_OF_REP_DEVICE))) {
            return TRUE;
         }
         break;

      case PORTABLE_ALL:
         if (((portableNo > 0) && (portableNo <= NR_OF_PORTABLE)) ||
             ((portableNo >= ULE_DEVICE_OFFSET) && (portableNo < (ULE_DEVICE_OFFSET + NR_OF_ULE_DEVICE))) ||
             ((portableNo >= REP_DEVICE_OFFSET) && (portableNo < (REP_DEVICE_OFFSET + NR_OF_REP_DEVICE)))) {
            return TRUE;
         }
         break;
   }

   return FALSE;
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_Deregister                                   *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions delets the specified Registration Slot.     *
*   Parms      :  po_no           : internal portable number                *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Subscription_Deregister(BYTE po_no)
{
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   struct HLI_Header *headerPtr;
   #endif

   // Reasonable value for po_no?
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
   if ((po_no == 0) || (po_no > MAX_PORTABLE))
   #endif
   {
      return;
   }

   // Delete all fields
   #ifdef ULE_SUPPORT
#ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
#else
   if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
#endif
      Mmu_Memset((FPTR)uleSubscriptionPtr, 0, sizeof(FT_ULE_SUBSCRIPTION));

      headerPtr = (struct HLI_Header *)Mmu_Malloc(sizeof(struct HLI_Header) + sizeof(FT_ULE_SUBSCRIPTION));
#ifdef KLOCWORK
      if(headerPtr == NULL)
         return;
#endif
      headerPtr->length = sizeof(struct HLI_Header) + sizeof(FT_ULE_SUBSCRIPTION);
      headerPtr->next = 0;
      Subscription_GetRegistrationData(po_no, (FPTR)((unsigned long)headerPtr) + sizeof(struct HLI_Header));
      Send_Message_To_APP(FP_SUBSCRIPTION_INFO_UPDATED_MM,
                          (FPTR)headerPtr,
                          DUMMY_FILL,
                          po_no,
                          DUMMY_FILL,
                          DUMMY_FILL,
                          DUMMY_FILL);
      goto exit_01;
   }
   #endif

   #ifdef CONFIG_REPEATER_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_REP(po_no, PORTABLE_REP)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_REP)) {
      #endif /* KLOCWORK */
      Mmu_Memset((FPTR)&FT_RepSubscription[po_no - REP_DEVICE_OFFSET], 0, sizeof(FT_REP_SUBSCRIPTION));
      //Temporally to match the sizeof(FT_REP_SUBSCRIPTION) with the GWApp definition
      FT_RepSubscription[ po_no - REP_DEVICE_OFFSET ].defaultCipherKeyIndex = 0xFF;
      FT_RepSubscription[ po_no - REP_DEVICE_OFFSET ].defaultCipherKeyIndex_1 = 0xFF;
      // Write_EEPROM_Subscription_Data( po_no );
      goto exit_01;
   }
   #endif

   #ifdef KLOCWORK
   //if (IsValidPortableNo(po_no, PORTABLE_DECT))
   if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT))
   #endif /* KLOCWORK */
   {
      Mmu_Memset((FPTR)&FT_Subscription[po_no - 1], 0, sizeof(FT_SUBSCRIPTION));
      #ifdef CONFIG_EARLY_ENCRYPTION
      FT_Subscription[ po_no - 1 ].defaultCipherKeyIndex = 0xFFFF;
      #endif
      // Write_EEPROM_Subscription_Data( po_no );
   }

exit_01:
   // PROBLEM_ISSUE_40
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   Set_First_Codec(po_no, 0);
   Set_Second_Codec(po_no, 0);
   Set_Third_Codec(po_no, 0);
   Set_Terminal_Cap(po_no, 0);
   #else
   Terminal_Cap[po_no - 1] = 0;
   First_Codec [po_no - 1] = 0;
   Second_Codec[po_no - 1] = 0;
   Third_Codec [po_no - 1] = 0;
   #endif
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_IsRegistrationPossible                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions checks if the registration of a further     *
*                 portable is possible or not. Registration is possible,    *
*                 when at least one registration slot is free or the        *
*                 portable is already known.                                *
*   Parms      :  ipui_ptr        : pointer to the received IPUI Array      *
*   Returns    :  TRUE / FALSE                                              *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
extern char vcMaxHandset;
EXPORT BIT
#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
Subscription_IsRegistrationPossible(BYTE XDATA * ipui_ptr, BOOL ULEDevice)
#else
Subscription_IsRegistrationPossible(FPTR ipui_ptr)
#endif
{
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   #endif
   BYTE reg_no;

                                       /* Frame there ?                    */
   if( ipui_ptr == NULL )
      return( FALSE );
                                       /* Registration slot free ?         */
 #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   switch (ULEDevice) {
      #ifdef ULE_SUPPORT
      case ULE_DEVICE:
         for (reg_no = 0; reg_no < NR_OF_ULE_DEVICE; reg_no++) {
#ifdef KLOCWORK
            uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(reg_no);
#else
            uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(reg_no+ULE_DEVICE_OFFSET);
#endif
            if (uleSubscriptionPtr->status == INVALID) {
               return (TRUE);
            }
         }
         break;
      #endif

      #ifdef CONFIG_REPEATER_SUPPORT
      case REP_DEVICE:
      {
         BYTE rep_info;

         rep_info = Get_Repeater_Info( );
         if (rep_info == REPEATER_REGISTRATION_STATE_IDLE) {
            for (reg_no = 0; reg_no < NR_OF_REP_DEVICE; reg_no += MAX_INSTANCES_PER_REPEATERS) {
               if (FT_RepSubscription[reg_no].status == INVALID) {
                  /* clear rest of reg-slot belongs to this repeater */
                 /*( because these are not cleared by Agent when de-register a Repeater through the WEB ) */
                  FT_RepSubscription[reg_no+1].status = INVALID;
                  FT_RepSubscription[reg_no+2].status = INVALID;
                  FT_RepSubscription[reg_no+3].status = INVALID;
                  FT_RepSubscription[reg_no+4].status = INVALID;
                  FT_RepSubscription[reg_no+5].status = INVALID;
                  return (TRUE);
               }
            }
         } else {
            reg_no = Get_Repeater_PoNo( ) - REP_DEVICE_OFFSET;
            for ( ; reg_no < MAX_INSTANCES_PER_REPEATERS; reg_no++) {
               if (FT_RepSubscription[reg_no].status == INVALID) {
                  return (TRUE);
               }
            }
         }
         break;
      }
      #endif

      default:
         for (reg_no = 0; reg_no < NR_OF_PORTABLE; reg_no++) {
            if (FT_Subscription[reg_no].status == INVALID) {
               return (TRUE);
            }
         }
         break;
   }
                                       /* Portable already known ?         */
   if (getPotableNoFromIPUIWithPotableType(ipui_ptr, ULEDevice) != 0xFF) {
      return (TRUE);
   }
   #else
   //for( reg_no = 0; reg_no < MAX_PORTABLE; reg_no ++ )
   for (reg_no = 0; reg_no < vcMaxHandset; reg_no++) {
      if( FT_Subscription[reg_no].status == INVALID) {
         return (TRUE);
      }
   }
                                       /* Portable already known ?         */
   if (Subscription_GetPotableNoFromIPUI(ipui_ptr) != 0xFF) {
      return (TRUE);
   }
   #endif
                                       /* All registration slots are       */
                                       /* occupied and the portable is not */
                                       /* known ! Registration of a        */
                                       /* further portable is not          */
                                       /* possible.                        */
   return (FALSE);
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_IsRegistered                                   *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions checks if a portable is assigned to the     *
*                 specified internal portable number.                       *
*   Parms      :  po_no           : internal portable number                *
*   Returns    :  TRUE / FALSE                                              *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BIT
Subscription_IsRegistered(BYTE po_no)
{
 #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;

                                       /* Reasonable value for po_no ?     */
      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
      #endif
      return (uleSubscriptionPtr->status == VALID);
   }
   #endif

   #ifdef CONFIG_REPEATER_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_REP(po_no, PORTABLE_REP)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_REP)) {
      #endif
      return (FT_RepSubscription[po_no - REP_DEVICE_OFFSET].status == VALID);
   }
   #endif

   #ifdef KLOCWORK
   if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT)) {
   #else
   if (IsValidPortableNo(po_no, PORTABLE_DECT)) {
   #endif
      return (FT_Subscription[po_no - 1].status == VALID);
   }

   return (FALSE);

   #else //#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
                                       /* Reasonable value for po_no ?     */
   if ((po_no == 0) || (po_no > MAX_PORTABLE)) {
      return (FALSE);
   }
                                       /* Registration slot occupied ?     */
   return (FT_Subscription[po_no - 1].status == VALID);
   #endif //#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_Register                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions stores the subscription data after a        *
*                 successful registration procedure.                        *
*                 The data for an already known portable is stored in the   *
*                 'old' registration slot. For an unknown portable the      *
*                 registration data is stored to the next free slot.        *
*                 Storing the registration data in a specific slot assigns  *
*                 automatically the internal portable number to the new     *
*                 registered portable.                                      *
*                 registration slot number + 1 = internal portable number   *
*   Parms      :  ipui_ptr        : pointer to the IPUI Array               *
*                 uak_ptr         : pointer to the UAK Array                *
*                 model_id        : model identifier                        *
*   Returns    :  assigned internal portable number                         *
*   Call Level :  Process Level                                             *
*   Remarks    :  For a PRODECT V2.0 PT the model id is set to 0x20. For    *
*                 all other DECT equipments, the model id is set to 0xFF.   *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BYTE
#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
Subscription_Register(BYTE XDATA * ipui_ptr, BYTE XDATA * uak_ptr, BYTE model_id, BOOL ULEDevice)
#else
Subscription_Register(FPTR ipui_ptr, FPTR uak_ptr, BYTE model_id, FPTR EMC_Array)
#endif
{
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   #endif
   BYTE registrationSlot;

   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   registrationSlot = getPotableNoFromIPUIWithPotableType(ipui_ptr,ULEDevice);
   #else
   registrationSlot = Subscription_GetPotableNoFromIPUI(ipui_ptr);
   #endif

   if (registrationSlot != 0xFF) {
      // The portable is known.
      // The same registration slot must be used.
      switch (ULEDevice) {
         #ifdef ULE_SUPPORT
         case ULE_DEVICE:
            registrationSlot -= ULE_DEVICE_OFFSET;
            break;
         #endif

         #ifdef CONFIG_REPEATER_SUPPORT
         case REP_DEVICE:
            registrationSlot -= REP_DEVICE_OFFSET;
            break;
         #endif

         default:
         registrationSlot -= 1;
            break;
      }
   } else {
      // The portable is not known!
      // A free registration slot must be found.
      switch (ULEDevice) {
         #ifdef ULE_SUPPORT
         case ULE_DEVICE:
            for (registrationSlot = 0; registrationSlot < NR_OF_ULE_DEVICE; registrationSlot++) {
               #ifdef KLOCWORK
               uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(registrationSlot);
               #else
               uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(registrationSlot+ULE_DEVICE_OFFSET);
               #endif
               if (uleSubscriptionPtr->status == INVALID) {
                  break;
               }
            }
            if (registrationSlot >= NR_OF_ULE_DEVICE) {
               return 0xFF;
            }
            break;
         #endif

         #ifdef CONFIG_REPEATER_SUPPORT
         case REP_DEVICE:
         {
            BYTE rep_info;

            rep_info = Get_Repeater_Info( );
            if (rep_info == REPEATER_REGISTRATION_STATE_IDLE) {
               for (registrationSlot = 0; registrationSlot < NR_OF_REP_DEVICE; registrationSlot += 6) {
                  if (FT_RepSubscription[registrationSlot].status == INVALID) {
                     break;
                  }
               }
               if (registrationSlot >= NR_OF_REP_DEVICE) {
                  return 0xFF;
               }
            } else {
               registrationSlot = Get_Repeater_PoNo( ) - REP_DEVICE_OFFSET;
               for ( ; registrationSlot < MAX_INSTANCES_PER_REPEATERS; registrationSlot++) {
                  if (FT_RepSubscription[registrationSlot].status == INVALID) {
                     break;
                  }
               }
               if (registrationSlot >= MAX_INSTANCES_PER_REPEATERS) {
                  return 0xFF;
               }
            }
            break;
         }
         #endif

         default:
            for (registrationSlot = 0; registrationSlot < NR_OF_PORTABLE; registrationSlot++) {
               if (FT_Subscription[registrationSlot].status == INVALID) {
                  break;
               }
            }
            if (registrationSlot >= NR_OF_PORTABLE) {
               return 0xFF;
            }
            break;
       }
   }

   #ifdef ULE_SUPPORT
   if (ULEDevice == ULE_DEVICE) {
      #ifdef KLOCWORK
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(registrationSlot);
      #else
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(registrationSlot+ULE_DEVICE_OFFSET);
      #endif
      uleSubscriptionPtr->status = VALID;
      Mmu_Memcpy(uleSubscriptionPtr->ipui_array, ipui_ptr, 5);
      uleSubscriptionPtr->tpui_array[0] = 0x0E;
      uleSubscriptionPtr->tpui_array[1] = ipui_ptr[3];
      uleSubscriptionPtr->tpui_array[2] = ipui_ptr[4];
      Mmu_Memcpy(uleSubscriptionPtr->uak_array, uak_ptr, UAK_LEN);
      Mmu_Memset(uleSubscriptionPtr->dck_array, 0, DCK2_LEN);
      uleSubscriptionPtr->service_class = INTERNATIONAL_CALLS_ALLOWED;
      uleSubscriptionPtr->model_id = model_id;
      Mmu_Memset(uleSubscriptionPtr->lastSSN, 0, ULE_DLC_SN_SIZE);
      Mmu_Memset(uleSubscriptionPtr->lastRSN, 0, ULE_DLC_SN_SIZE);
      uleSubscriptionPtr->ULEType = 0;
      uleSubscriptionPtr->SDUSize = 32;
      uleSubscriptionPtr->windowSize = 0x10;
      uleSubscriptionPtr->resumesULENWK = NO;
      uleSubscriptionPtr->deviceNo = 0;

      return (registrationSlot + ULE_DEVICE_OFFSET);
   } else
   #endif

   #ifdef CONFIG_REPEATER_SUPPORT
   if (ULEDevice == REP_DEVICE) {
      FT_RepSubscription[registrationSlot].status = VALID;
      Mmu_Memcpy(FT_RepSubscription[registrationSlot].ipui_array, ipui_ptr, 5);
      FT_RepSubscription[registrationSlot].tpui_array[0] = 0x0E;
      FT_RepSubscription[registrationSlot].tpui_array[1] = ipui_ptr[3];
      FT_RepSubscription[registrationSlot].tpui_array[2] = ipui_ptr[4];
      Mmu_Memcpy(FT_RepSubscription[registrationSlot].uak_array, uak_ptr, UAK_LEN);
      Mmu_Memset(FT_RepSubscription[registrationSlot].dck_array, 0, DCK_LEN);
      //Temporally to match the sizeof(FT_REP_SUBSCRIPTION) with the GWApp definition
      FT_RepSubscription[registrationSlot].defaultCipherKeyIndex = 0xFF;
      FT_RepSubscription[registrationSlot].defaultCipherKeyIndex_1 = 0xFF;

      // Write_EEPROM_Subscription_Data(registrationSlot + REP_DEVICE_OFFSET);
      return (registrationSlot + REP_DEVICE_OFFSET);
   }
   #endif

      FT_Subscription[registrationSlot].status = VALID;
      Mmu_Memcpy(FT_Subscription[registrationSlot].ipui_array, ipui_ptr, 5);
      FT_Subscription[registrationSlot].tpui_array[0] = 0x0E;
      FT_Subscription[registrationSlot].tpui_array[1] = ipui_ptr[3];
      FT_Subscription[registrationSlot].tpui_array[2] = ipui_ptr[4];
      Mmu_Memcpy(FT_Subscription[registrationSlot].uak_array, uak_ptr, UAK_LEN);
      Mmu_Memset(FT_Subscription[registrationSlot].dck_array, 0, DCK_LEN);
      #ifdef CONFIG_EARLY_ENCRYPTION
      FT_Subscription[registrationSlot].defaultCipherKeyIndex = 0xFFFF;
      #endif
      FT_Subscription[registrationSlot].service_class = INTERNATIONAL_CALLS_ALLOWED;
      FT_Subscription[registrationSlot].model_id = model_id;

      // Write_EEPROM_Subscription_Data(registrationSlot + 1);
      return (registrationSlot + 1); // real potable number
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_ForceToRegister                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions stores the subscription data from the ATE   *
*   Parms      :  ipui_ptr        : pointer to the IPUI Array               *
*                 reg_no          : desired slot no to be registered        *
*   Returns    :  NONE                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  For a PRODECT V2.0 PT the model id is set to 0x20. For    *
*                 all other DECT equipments, the model id is set to 0xFF.   *
*****************************************************************************
*/
#ifdef FT
EXPORT void
#ifdef CONFIG_EARLY_ENCRYPTION
Subscription_ForceToRegister( FPTR ipui_ptr, FPTR defaultCipherKeyPtr, WORD defaultCipherKeyIndex, BYTE reg_no)
#else
Subscription_ForceToRegister( FPTR ipui_ptr, BYTE reg_no )
#endif
{
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   #endif
   BYTE po_no;

                                       /* Is the portable already known ?  */
   po_no = Subscription_GetPotableNoFromIPUI(ipui_ptr); //po_no = 1..6(DECT) or 32 .. 231(ULE)
   if (po_no != 0xFF) {
                                       /* -------------------------------- */
                                        /* In that case, the old            */
                                        /* registration slot is deleted !   */
      Subscription_Deregister(po_no);
   }
                                       /* The registration data is stored  */
                                       /* in the first free registration   */
                                       /* slot !                           */
 #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(reg_no, PORTABLE_ULE)) {
      #else
   if (IsValidPortableNo(reg_no, PORTABLE_ULE)) {
      #endif

      #ifdef KLOCWORK
      //if (IsValidPortableNo(po_no, PORTABLE_ULE))
      if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE))
      #endif /* KLOCWORK */
      {
         #ifdef KLOCWORK
         uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
         #else
         uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
         #endif /* KLOCWORK */

         uleSubscriptionPtr->status          = VALID;
         Mmu_Memcpy(uleSubscriptionPtr->ipui_array, ipui_ptr, 5);
         uleSubscriptionPtr->tpui_array[ 0 ] = 0x0E;
         uleSubscriptionPtr->tpui_array[ 1 ] = ipui_ptr[ 3 ];
         uleSubscriptionPtr->tpui_array[ 2 ] = ipui_ptr[ 4 ];
         Mmu_Memset(uleSubscriptionPtr->uak_array, 0, UAK_LEN);
         Mmu_Memset(uleSubscriptionPtr->dck_array, 0, DCK2_LEN);
         uleSubscriptionPtr->service_class   = INTERNATIONAL_CALLS_ALLOWED;
         uleSubscriptionPtr->model_id        = Model_ID;
         Mmu_Memset(uleSubscriptionPtr->lastSSN, 0, ULE_DLC_SN_SIZE);
         Mmu_Memset(uleSubscriptionPtr->lastRSN, 0, ULE_DLC_SN_SIZE);
         uleSubscriptionPtr->ULEType = 0;
         uleSubscriptionPtr->SDUSize = 32;
         uleSubscriptionPtr->windowSize = 0x10;
         uleSubscriptionPtr->resumesULENWK = NO;
         uleSubscriptionPtr->deviceNo = 0;
         return;
      }
   }
   #endif //#ifdef ULE_SUPPORT

   #ifdef CONFIG_REPEATER_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_REP(reg_no, PORTABLE_REP)) {
      #else
   if (IsValidPortableNo(reg_no, PORTABLE_REP)) {
      #endif
      FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].status          = VALID;
      Mmu_Memcpy(FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].ipui_array, ipui_ptr, 5);
      FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].tpui_array[ 0 ] = 0x0E;
      FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].tpui_array[ 1 ] = ipui_ptr[ 3 ];
      FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].tpui_array[ 2 ] = ipui_ptr[ 4 ];
      Mmu_Memset(FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].uak_array, 0, UAK_LEN);
      #ifdef CONFIG_EARLY_ENCRYPTION
      if (defaultCipherKeyPtr == NULL) {
         Mmu_Memset(FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].dck_array, 0, DCK_LEN);
         //Temporally to match the sizeof(FT_REP_SUBSCRIPTION) with the GWApp definition
         FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].defaultCipherKeyIndex = 0xFF;
         FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].defaultCipherKeyIndex_1 = 0xFF;
      } else {
         Mmu_Memcpy(FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].dck_array, defaultCipherKeyPtr, DCK_LEN);
         FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].defaultCipherKeyIndex = defaultCipherKeyIndex;
      }
      #else
      Mmu_Memset(FT_RepSubscription[reg_no - REP_DEVICE_OFFSET].dck_array, 0, DCK_LEN);
      #endif

      //Write_EEPROM_Subscription_Data(reg_no - REP_DEVICE_OFFSET);
      return;
   }
   #endif //#ifdef CONFIG_REPEATER_SUPPORT

       #ifdef KLOCWORK
   if (VALID_PORTABLE_DECT(reg_no+1, PORTABLE_DECT))
      #else
   if (IsValidPortableNo(reg_no+1, PORTABLE_DECT))
      #endif
   #else //  #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   if( reg_no < MAX_PORTABLE )
   #endif // #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   {
      FT_Subscription[ reg_no ].status          = VALID;
      Mmu_Memcpy(FT_Subscription[ reg_no ].ipui_array, ipui_ptr, 5);
      FT_Subscription[ reg_no ].tpui_array[ 0 ] = 0x0E;
      FT_Subscription[ reg_no ].tpui_array[ 1 ] = ipui_ptr[ 3 ];
      FT_Subscription[ reg_no ].tpui_array[ 2 ] = ipui_ptr[ 4 ];
      Mmu_Memset(FT_Subscription[ reg_no ].uak_array, 0, UAK_LEN);
      #ifdef CONFIG_EARLY_ENCRYPTION
      if (defaultCipherKeyPtr == NULL) {
         Mmu_Memset(FT_Subscription[ reg_no ].dck_array, 0, DCK_LEN);
         FT_Subscription[reg_no].defaultCipherKeyIndex = 0xFFFF;
      } else {
         Mmu_Memcpy(FT_Subscription[ reg_no ].dck_array, defaultCipherKeyPtr, DCK_LEN);
         FT_Subscription[reg_no].defaultCipherKeyIndex = defaultCipherKeyIndex;
      }
      #else
      Mmu_Memset(FT_Subscription[ reg_no ].dck_array, 0, DCK_LEN);
      #endif
      FT_Subscription[ reg_no ].service_class   = INTERNATIONAL_CALLS_ALLOWED;
      FT_Subscription[ reg_no ].model_id        = Model_ID;

      // Write_EEPROM_Subscription_Data(reg_no + 1);
   }
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_SwapRegistrationData                             *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions swaps two registration slots.               *
*   Parms      :  source_po_no    : old portable/slot number                *
*                 dest_po_no      : new portable/slot number                *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  The base station allows the user to select the internal   *
*                 portable number when a PRODECT V2.0 PT is registered.     *
*                 After selection of a new number the registration slots    *
*                 are swapped.                                              *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Subscription_SwapRegistrationData( BYTE source_po_no, BYTE dest_po_no )
{
                                       /* Reasonable value for po_no ?     */
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_DECT(source_po_no, PORTABLE_DECT))
      #else
   if (!IsValidPortableNo(source_po_no, PORTABLE_DECT))
      #endif
   #else
   if ((source_po_no == 0) || (source_po_no > MAX_PORTABLE))
   #endif
   {
      return;
   }

   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_DECT(dest_po_no, PORTABLE_DECT))
      #else
   if (!IsValidPortableNo(dest_po_no, PORTABLE_DECT))
      #endif
   #else
   if ((dest_po_no == 0) || (dest_po_no > MAX_PORTABLE))
   #endif
   {
      return;
   }
   if (source_po_no == dest_po_no) {
      return;
   }
                                       /* Copy content from source to      */
                                       /* destination slot.                */
    Mmu_Memcpy( (FPTR) &FT_Subscription[ dest_po_no - 1 ],
                (FPTR) &FT_Subscription[ source_po_no - 1 ],
                sizeof( FT_SUBSCRIPTION ));
                                       /* Erase old source slot.           */
    Subscription_Deregister( source_po_no );
                                       /* Store new destination slot to    */
                                       /* EEPORM.                          */
    // Write_EEPROM_Subscription_Data( dest_po_no );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_SetServiceClass                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function sets the assigned Service Class value        *
*                 during an Obtain Access Rights Procedure.                 *
*   Parms      :  po_no           : portable number                         *
*                 value           : assigned service class value            *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Subscription_SetServiceClass( BYTE po_no, BYTE value )
{
                                       /* Reasonable value for po_no ?     */
 #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
      #endif
      uleSubscriptionPtr->service_class = value;
      return;
   }
   #endif

   #ifdef KLOCWORK
   if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT)) {
   #else
   if (IsValidPortableNo(po_no, PORTABLE_DECT)) {
   #endif
      FT_Subscription[ po_no - 1 ].service_class = value;
   }
   #else
   if ((po_no == 0) || (po_no > MAX_PORTABLE)) {
      return;
   }

   FT_Subscription[ po_no - 1 ].service_class = value;
   #endif
                                       /* Write new registration slot data */
                                       /* to EEPROM.                       */
   // Write_EEPROM_Subscription_Data( po_no );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_SetTPUI                                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function sets the TPUI value of a specified           *
*                 portable                                                  *
*   Parms      :  po_no           : portable number                         *
*                 typ             : ASSIGNED_TPUI / DEFAULT_TPUI            *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  The assigned TPUI values may range between                *
*                 0x000A1-0x000A7.                                          *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
Subscription_SetTPUI(BYTE po_no, BYTE typ, BOOL ULEDevice)
#else
Subscription_SetTPUI(BYTE po_no, BYTE typ)
#endif
{
 #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   BYTE reg_no;
   BYTE org_tpui[3], new_tpui[3];

   // Reasonable value for po_no?
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
      return;

#ifdef KLOCWORK
   uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
#else
   uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
#endif

   switch (ULEDevice) {
      #ifdef ULE_SUPPORT
      case ULE_DEVICE:
         Mmu_Memcpy(org_tpui, uleSubscriptionPtr->tpui_array, 3);
         break;
      #endif

      #ifdef CONFIG_REPEATER_SUPPORT
      case REP_DEVICE:
         #ifdef KLOCWORK
         if (VALID_PORTABLE_REP(po_no, PORTABLE_REP))
         #endif
            Mmu_Memcpy(org_tpui, FT_RepSubscription[po_no - REP_DEVICE_OFFSET].tpui_array, 3);
         break;
      #endif

      default:
      #ifdef KLOCWORK
         if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT))
      #endif
            Mmu_Memcpy(org_tpui, FT_Subscription[po_no - 1].tpui_array, 3);
         break;
   }

   if (typ == ASSIGNED_TPUI) {
      // Set 1st digit to assigned individual TPUI type.
      new_tpui[0] = (ASSIGNED_INDIVIDUAL_TPUI >> 4);


      DECT_DEBUG_USER_MM_DATA("SetTpui1:%02x %02x \n",ULEDevice, po_no);

      switch (ULEDevice) {
         #ifdef ULE_SUPPORT
         case ULE_DEVICE:
            #ifdef CONFIG_TEST_DIALOG_LIMITED_TPUI
            new_tpui[1] = ULE_DECT_TPUI_TYPE;
            new_tpui[2] = po_no - ULE_DEVICE_OFFSET + 1; // 1 ~ n
            #else
            new_tpui[1] = ULE_DECT_TPUI_TYPE;
            new_tpui[2] = po_no;
            #endif
            break;
         #endif

         #ifdef CONFIG_REPEATER_SUPPORT
         case REP_DEVICE:
            /*
               The low byte is set to an unused value.
               Start value is 0x00.
               The assigned value may range from 1 to 6.
             */
            new_tpui[1] = REP_DECT_TPUI_TYPE;
            new_tpui[2] = po_no - REP_DEVICE_OFFSET;
            break;
         #endif

         default:
         #ifdef KLOCWORK
         if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT))
         #endif
         {
            /*
               The low byte is set to an unused value.
               Start value is 0x00.
               The assigned value may range from 1 to 6.
             */
            new_tpui[1] = NORMAL_DECT_TPUI_TYPE;
            new_tpui[2] = 0x00;
            do {
               new_tpui[2]++;
               for (reg_no = 0; reg_no < NR_OF_PORTABLE; reg_no++) {
                  if (reg_no == po_no - 1) {
                     continue;
                  }
                  if (Mmu_Memcmp(new_tpui,FT_Subscription[reg_no].tpui_array,3)) {
                     break;
                  }
               }
            } while (reg_no < NR_OF_PORTABLE);
         }
         break;
      }
   } else {
      // Set first byte to default indication!
      new_tpui[0] = (DEFAULT_INDIVIDUAL_TPUI >> 4);
      // Default TPUI value is derivated from the IPUI identity type N.
      switch (ULEDevice) {
         #ifdef ULE_SUPPORT
         case ULE_DEVICE:
            Mmu_Memcpy(&new_tpui[1], &uleSubscriptionPtr->ipui_array[3], 2);
            break;
         #endif

         #ifdef CONFIG_REPEATER_SUPPORT
         case REP_DEVICE:
            #ifdef KLOCWORK
            if (VALID_PORTABLE_REP(po_no, PORTABLE_REP))
            #endif
            Mmu_Memcpy(&new_tpui[1], &FT_RepSubscription[po_no - REP_DEVICE_OFFSET].ipui_array[3], 2);
            break;
         #endif

         default:
            #ifdef KLOCWORK
            if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT))
            #endif
            Mmu_Memcpy(&new_tpui[1], &FT_Subscription[po_no - 1].ipui_array[3], 2);
            break;
      }
   }
                                       /* Normally the new TPUI must       */
                                       /* not be stored in EEPROM.         */
                                       /* If a basestation reset is        */
                                       /* performed, the portable is       */
                                       /* forced to start the Location     */
                                       /* Registration Procedure anyway    */
                                       /* (a38 bit always set !).          */
                                       /* Unfortunately not all GAP        */
                                       /* equipment perform the Location   */
                                       /* Registration Procedure after a   */
                                       /* 'short' reset of the base        */
                                       /* station. As a concession to      */
                                       /* those equipment the DCK and TPUI */
                                       /* values are stored nevertheless   */
                                       /* to EEPROM. To decrease the MMU   */
                                       /* load, the storing is done only   */
                                       /* after TPUI assignment            */
                                       /* (not after DCK and TPUI).        */

                                       /* Write new registration slot data */
                                       /* to EEPROM (DCK and TPUI).        */
   DECT_DEBUG_USER_MM_DATA("SetTpui2:%02x %02x \n",ULEDevice, po_no);
   switch (ULEDevice) {
      #ifdef ULE_SUPPORT
      case ULE_DEVICE:
         Mmu_Memcpy(uleSubscriptionPtr->tpui_array, new_tpui, 3);
         break;
      #endif

      #ifdef CONFIG_REPEATER_SUPPORT
      case REP_DEVICE:
         #ifdef KLOCWORK
         if (VALID_PORTABLE_REP(po_no, PORTABLE_REP))
         #endif
         Mmu_Memcpy(FT_RepSubscription[po_no - REP_DEVICE_OFFSET].tpui_array, new_tpui, 3);
         if (Mmu_Memcmp(org_tpui, new_tpui, 3) == FALSE) {
            // Write_EEPROM_Subscription_Data(po_no);
         }
         break;
      #endif

      default:
         #ifdef KLOCWORK
         if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT))
         #endif
         Mmu_Memcpy(FT_Subscription[po_no - 1].tpui_array, new_tpui, 3);
         if (Mmu_Memcmp(org_tpui, new_tpui, 3) == FALSE) {
         // Write_EEPROM_Subscription_Data(po_no);
         }
         break;
   }

   #else // #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)

   BYTE reg_no;
   BYTE org_tpui[3];

   // Reasonable value for po_no?
   if ((po_no == 0) || (po_no > MAX_PORTABLE)) {
      return;
   }

   Mmu_Memcpy(org_tpui, FT_Subscription[po_no - 1].tpui_array, 3);

   if (typ == ASSIGNED_TPUI) {
      // Set 1st digit to assigned individual TPUI type.
      FT_Subscription[po_no - 1].tpui_array[0] = (ASSIGNED_INDIVIDUAL_TPUI >> 4);

      /*
         The low byte is set to an unused value.
         Start value is 0x00.
         The assigned value may range from 1 to 6.
       */
      FT_Subscription[po_no - 1].tpui_array[1] = NORMAL_DECT_TPUI_TYPE;
      FT_Subscription[po_no - 1].tpui_array[2] = 0x00;
      do {
         FT_Subscription[po_no - 1].tpui_array[2]++;
         for (reg_no = 0; reg_no < NR_OF_PORTABLE; reg_no++) {
            if (reg_no == po_no - 1) {
               continue;
            }
            if (Mmu_Memcmp(FT_Subscription[po_no - 1].tpui_array,
                           FT_Subscription[reg_no].tpui_array,
                           3)) {
               break;
            }
         }
      } while (reg_no < NR_OF_PORTABLE);
   } else {
      // Set first byte to default indication!
      FT_Subscription[po_no - 1].tpui_array[0] = (DEFAULT_INDIVIDUAL_TPUI >> 4);
      // Default TPUI value is derivated from the IPUI identity type N.
      Mmu_Memcpy(&FT_Subscription[po_no - 1].tpui_array[1],
                 &FT_Subscription[po_no - 1].ipui_array[3],
                 2);
   }
                                       /* Normally the new TPUI must       */
                                       /* not be stored in EEPROM.         */
                                       /* If a basestation reset is        */
                                       /* performed, the portable is       */
                                       /* forced to start the Location     */
                                       /* Registration Procedure anyway    */
                                       /* (a38 bit always set !).          */
                                       /* Unfortunately not all GAP        */
                                       /* equipment perform the Location   */
                                       /* Registration Procedure after a   */
                                       /* 'short' reset of the base        */
                                       /* station. As a concession to      */
                                       /* those equipment the DCK and TPUI */
                                       /* values are stored nevertheless   */
                                       /* to EEPROM. To decrease the MMU   */
                                       /* load, the storing is done only   */
                                       /* after TPUI assignment            */
                                       /* (not after DCK and TPUI).        */

                                       /* Write new registration slot data */
                                       /* to EEPROM (DCK and TPUI).        */
   if (Mmu_Memcmp(org_tpui, FT_Subscription[po_no - 1].tpui_array, 3) == FALSE) {
      // Write_EEPROM_Subscription_Data(po_no);
   }
   #endif // #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
}
#endif

#ifdef FT
#ifdef CONFIG_EARLY_ENCRYPTION
EXPORT void
Subscription_SetDefaultCipherKey(FPTR defaultCipherKeyPtr, WORD defaultCipherKeyIndex, BYTE portableNo)
{
   // Reasonable value for repeater ?
   #ifdef CONFIG_REPEATER_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP))
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_REP))
      #endif
   {
      Mmu_Memcpy(FT_RepSubscription[portableNo - REP_DEVICE_OFFSET].dck_array, defaultCipherKeyPtr, DCK_LEN);
      FT_RepSubscription[portableNo - REP_DEVICE_OFFSET].defaultCipherKeyIndex = defaultCipherKeyIndex;
      return;
   }
   #endif

   // Reasonable value for po_no ?
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT))
      #else
   if (!IsValidPortableNo(portableNo, PORTABLE_DECT))
      #endif
   #else
   if((portableNo == 0) || (portableNo > MAX_PORTABLE))
   #endif
   {
      return;
   }

   Mmu_Memcpy(FT_Subscription[portableNo - 1].dck_array, defaultCipherKeyPtr, DCK_LEN);
   FT_Subscription[portableNo - 1].defaultCipherKeyIndex = defaultCipherKeyIndex;
}
#endif
#endif

#ifdef CONFIG_EARLY_ENCRYPTION
/*
*****************************************************************************
*                                                                           *
*   Function   :  SearchNewDefaultCipherKeyIndex                            *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Search new default cipher key index                       *
*                 EEPROM.                                                   *
*   Parms      :  none                                                      *
*   Returns    :  new default cipher key index                              *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT WORD
SearchNewDefaultCipherKeyIndex(void)
{
   /*
    * Default cipher key index: EN300175-3 V2.3.0, 7.2.5.7, Table 7.44b
    * Valid default cipher key index: 0x0001 ~ 0xFEFF
    * Low byte value of Key index will be limited with MAX_PORTABLE for convenience: 0x01 ~ 0x06
    * High byte value of Key index will be got from timer
    */

   BYTE i;
   BYTE bitMask;
   BYTE highByteValue;
   BYTE cipherKeyIndex;
   BYTE cipherKeyIndexMap;

   // Get key index mapping data
   cipherKeyIndexMap = 0x00;
   for (i = 0; i < NR_OF_PORTABLE; i++) {
      if (FT_Subscription[i].status == VALID) {
         cipherKeyIndex = LOBYTE(FT_Subscription[i].defaultCipherKeyIndex);
         if (cipherKeyIndex >= 0x01 && cipherKeyIndex <= NR_OF_PORTABLE) {
            bitMask = 1 << (cipherKeyIndex - 1);
            cipherKeyIndexMap |= bitMask;
         }
      }
   }

   // Find unused key index
   if (cipherKeyIndexMap != 0x3F) {
      for (i = 1; i < (NR_OF_PORTABLE + 1); i++) {
         if ((cipherKeyIndexMap & 0x01) == 0) {
            break;
         } else {
            cipherKeyIndexMap >>= 1;
         }
      }

      if ((highByteValue = (BYTE)random()) > 0xFE) {
         highByteValue = 0xFE; // Limit value of hi byte of key index
      }
      return (((WORD)highByteValue << 8) | i);
   } else {
      // It will be not happend because this function will be called after checking the possibility of registration.
      // For safety, this code is implemented.
      return 0xFFFF;
   }
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_SetDCKCCM                                    *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function sets the generated DCK-Key during an         *
*                 Authentication of PT Procedure.                           *
*   Parms      :  po_no           : portable number                         *
*                 ptr             : pointer to generated DCK-Key            *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
#ifdef ULE_SUPPORT
EXPORT void
Subscription_SetDCKCCM(FPTR aDCKPtr, BYTE portableNo)
{
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   struct HLI_Header *headerPtr;
                                       /* Reasonable value for po_no ?     */
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      #else
   if (!IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      #endif
      return;
   }

#ifdef KLOCWORK
   uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET);
#else
   uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo);
#endif
   Mmu_Memcpy(uleSubscriptionPtr->dck_array, aDCKPtr, DCK2_LEN);
   headerPtr = (struct HLI_Header *)Mmu_Malloc(sizeof(struct HLI_Header) + sizeof(FT_ULE_SUBSCRIPTION));
#ifdef KLOCWORK
   if(headerPtr == NULL)
         return;
#endif
   headerPtr->length = sizeof(struct HLI_Header) + sizeof(FT_ULE_SUBSCRIPTION);
   headerPtr->next = 0;
   Subscription_GetRegistrationData(portableNo, (FPTR)((unsigned long)headerPtr) +sizeof(struct HLI_Header));
   Send_Message_To_APP(FP_SUBSCRIPTION_INFO_UPDATED_MM,
                       (FPTR)headerPtr,
                       DUMMY_FILL,
                       portableNo,
                       DUMMY_FILL,
                       DUMMY_FILL,
                       DUMMY_FILL);
}
#endif
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_LoadRegistrationData                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The FT Subscription structure is loaded with data from    *
*                 EEPROM.                                                   *
*   Parms      :  po_no           : slot number                             *
*                 ptr             : pointer to the read EEPROM data         *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void Subscription_SetTerminalCapability(uint32 uiTermCap, BYTE po_no)
{
 #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
      #endif
      uleSubscriptionPtr->uiTermCap = uiTermCap;
      return;
   }
   #endif

   #ifdef CONFIG_REPEATER_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_REP(po_no, PORTABLE_REP)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_REP)) {
      #endif
      FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uiTermCap = uiTermCap;
      return;
   }
   #endif

      #ifdef KLOCWORK
   if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT))
      #else
   if (IsValidPortableNo(po_no, PORTABLE_DECT))
      #endif
   #endif //#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   {
      FT_Subscription[po_no - 1].uiTermCap = uiTermCap;
   }

   return;
}

EXPORT void
Subscription_LoadRegistrationData( BYTE po_no, FPTR ptr )
{
                                       /* Reasonable value for po_no ?     */
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_DECT(po_no, PORTABLE_DECT))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_DECT))
      #endif
   #else
   if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
   #endif
      return;

   Mmu_Memcpy( (FPTR) &FT_Subscription[ po_no - 1 ], ptr, sizeof( FT_SUBSCRIPTION ));
   #ifdef CONFIG_TEST_EARLY_ENCRYPTION
   FT_Subscription[po_no - 1].defaultCipherKeyIndex = 0xFFFF;
   #endif
   /*Check WB support and then set CapBit which helps incase LocateReq is not sent by HS*/
   if(IFX_DECT_CheckWB(((uint32) FT_Subscription[ po_no - 1 ].uiTermCap)))
   {
      #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      Set_Terminal_Cap(po_no, 1);
      #else
      Terminal_Cap[po_no - 1]=1;
      #endif
   }
   else
   {
      #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      Set_Terminal_Cap(po_no, 0);
      #else
      Terminal_Cap[po_no - 1]=0;
      #endif
   }

   if (IFX_DBGA_GetStackModuleDebugID() & IFX_DECT_STACK_DEBUG_ID_MM_DATA ) {
      printf("\n[MM] Populating Portable No: %02x\n",po_no);
      printf("     Status: %02x\n", FT_Subscription[po_no - 1].status);
      printf("     IPUI: %02x %02x %02x %02X %02X\n",
             FT_Subscription[po_no - 1].ipui_array[0],
             FT_Subscription[po_no - 1].ipui_array[1],
             FT_Subscription[po_no - 1].ipui_array[2],
             FT_Subscription[po_no - 1].ipui_array[3],
             FT_Subscription[po_no - 1].ipui_array[4]);
      printf("     TPUI: %02x %02x %02x\n",
             FT_Subscription[po_no - 1].tpui_array[0],
             FT_Subscription[po_no - 1].tpui_array[1],
             FT_Subscription[po_no - 1].tpui_array[2]);
      DECT_DEBUG_USER_MM_KEY("     UAK: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n",
                             FT_Subscription[po_no - 1].uak_array[0],
                             FT_Subscription[po_no - 1].uak_array[1],
                             FT_Subscription[po_no - 1].uak_array[2],
                             FT_Subscription[po_no - 1].uak_array[3],
                             FT_Subscription[po_no - 1].uak_array[4],
                             FT_Subscription[po_no - 1].uak_array[5],
                             FT_Subscription[po_no - 1].uak_array[6],
                             FT_Subscription[po_no - 1].uak_array[7],
                             FT_Subscription[po_no - 1].uak_array[8],
                             FT_Subscription[po_no - 1].uak_array[9],
                             FT_Subscription[po_no - 1].uak_array[10],
                             FT_Subscription[po_no - 1].uak_array[11],
                             FT_Subscription[po_no - 1].uak_array[12],
                             FT_Subscription[po_no - 1].uak_array[13],
                             FT_Subscription[po_no - 1].uak_array[14],
                             FT_Subscription[po_no - 1].uak_array[15]);
      DECT_DEBUG_USER_MM_KEY("     DCK: %02x %02x %02x %02x %02x %02x %02x %02x\n",
                             FT_Subscription[po_no - 1].dck_array[0],
                             FT_Subscription[po_no - 1].dck_array[1],
                             FT_Subscription[po_no - 1].dck_array[2],
                             FT_Subscription[po_no - 1].dck_array[3],
                             FT_Subscription[po_no - 1].dck_array[4],
                             FT_Subscription[po_no - 1].dck_array[5],
                             FT_Subscription[po_no - 1].dck_array[6],
                             FT_Subscription[po_no - 1].dck_array[7]);
      printf("     Term Cap: %08x\n", FT_Subscription[po_no - 1].uiTermCap);
   }
#if 0
   // For Philips DECT Handset, TPUI will be assigned during registration only.
   // During Locate Registration, no assignment TPUI.
   // So, DECT Stack will not initialize TPUI during start-up in order to use assigned
   // TPUI which assigned during registration.
                                       /* Set TPUI to default after power  */
                                       /* up.                              */
#if 1  // TODO : It is only for test purpose. Should be removed in actual software.
   if( FT_Subscription[ po_no - 1 ].status == 1 )
   {
      FT_Subscription[ po_no - 1 ].tpui_array[ 0 ] = 0x00;
      FT_Subscription[ po_no - 1 ].tpui_array[ 1 ] = 0x00;
      FT_Subscription[ po_no - 1 ].tpui_array[ 2 ] = 0xA0 + po_no;
   }
#else
      // For Philips DECT Handset, TPUI will be assigned during registration only.
        // During Locate Registration, no assignment TPUI.
          // So, DECT Stack will not initialize TPUI during start-up in order to use assigned
            // TPUI which assigned during registration.
   FT_Subscription[ po_no - 1 ].tpui_array[ 0 ] = 0x0E;
   FT_Subscription[ po_no - 1 ].tpui_array[ 1 ] = FT_Subscription[ po_no - 1 ].ipui_array[ 3 ];
   FT_Subscription[ po_no - 1 ].tpui_array[ 2 ] = FT_Subscription[ po_no - 1 ].ipui_array[ 4 ];
#endif
   #endif
}
#endif

#ifdef CONFIG_REPEATER_SUPPORT
EXPORT void
Subscription_LoadREPRegistrationData( BYTE po_no, FPTR ptr )
{
                                       /* Reasonable value for po_no ?     */
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_REP(po_no, PORTABLE_REP))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_REP))
      #endif /* KLOCWORK */
      return;

   if (ptr == NULL) {
      Mmu_Memset( (FPTR) &FT_RepSubscription[po_no - REP_DEVICE_OFFSET], 0x00, sizeof( FT_REP_SUBSCRIPTION ));
   } else {
      Mmu_Memcpy( (FPTR) &FT_RepSubscription[po_no - REP_DEVICE_OFFSET], ptr, sizeof( FT_REP_SUBSCRIPTION ));
   }

   #ifdef CONFIG_TEST_EARLY_ENCRYPTION
   //Temporally to match the sizeof(FT_REP_SUBSCRIPTION) with the GWApp definition
   FT_RepSubscription[po_no - REP_DEVICE_OFFSET].defaultCipherKeyIndex = 0xFF;
   FT_RepSubscription[po_no - REP_DEVICE_OFFSET].defaultCipherKeyIndex_1 = 0xFF;
   #endif

   Set_Terminal_Cap(po_no, 0);
   
   if (IFX_DBGA_GetStackModuleDebugID() & IFX_DECT_STACK_DEBUG_ID_MM_DATA ) {
      printf("\n[MM] Populating Repeater Portable No: %02x\n",po_no);
      printf("     Status: %02x\n", FT_RepSubscription[po_no - REP_DEVICE_OFFSET].status);
      if( FT_RepSubscription[po_no - REP_DEVICE_OFFSET].status ) {
         printf("     IPUI: %02x %02x %02x %02x %02x\n",
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].ipui_array[0],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].ipui_array[1],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].ipui_array[2],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].ipui_array[3],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].ipui_array[4]);
         printf("     TPUI: %02x %02x %02x\n",
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].tpui_array[0],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].tpui_array[1],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].tpui_array[2]);
         //#if 0
         printf("     UAK: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n",
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[0],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[1],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[2],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[3],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[4],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[5],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[6],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[7],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[8],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[9],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[10],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[11],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[12],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[13],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[14],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array[15]);
         printf("     DCK: %02x %02x %02x %02x %02x %02x %02x %02x\n",
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].dck_array[0],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].dck_array[1],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].dck_array[2],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].dck_array[3],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].dck_array[4],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].dck_array[5],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].dck_array[6],
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].dck_array[7]);
         //#endif
         printf("     Term Cap: %08x\n",
                            FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uiTermCap);
      }
   }
}
#endif

#ifdef ULE_SUPPORT
EXPORT void
Subscription_LoadULERegistrationData(void)
{
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   BYTE reg_no;
   for (reg_no = 0; reg_no < NR_OF_ULE_DEVICE; reg_no++) {
#ifdef KLOCWORK
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(reg_no);
#else
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(reg_no+ULE_DEVICE_OFFSET);
#endif
      if(IFX_DECT_CheckWB(((uint32) uleSubscriptionPtr->uiTermCap))) {
         Set_Terminal_Cap(reg_no+ULE_DEVICE_OFFSET, 1);
      } else {
         Set_Terminal_Cap(reg_no+ULE_DEVICE_OFFSET, 0);
      }

      if (uleSubscriptionPtr->status) {
         if (IFX_DBGA_GetStackModuleDebugID() & IFX_DECT_STACK_DEBUG_ID_MM_DATA ) {
            printf("\n[MM] Populating ULE Portable No: %02x\n", reg_no + ULE_DEVICE_OFFSET);
            printf("     Status: %02x\n", uleSubscriptionPtr->status);
            printf("     IPUI: %02x %02x %02x %02x %02x\n",
                   uleSubscriptionPtr->ipui_array[0],
                   uleSubscriptionPtr->ipui_array[1],
                   uleSubscriptionPtr->ipui_array[2],
                   uleSubscriptionPtr->ipui_array[3],
                   uleSubscriptionPtr->ipui_array[4]);
            printf("     TPUI: %02x %02x %02x\n",
                   uleSubscriptionPtr->tpui_array[0],
                   uleSubscriptionPtr->tpui_array[1],
                   uleSubscriptionPtr->tpui_array[2]);
            printf("     Term Cap: %08x\n", uleSubscriptionPtr->uiTermCap);
         }
      }
   }
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_GetServiceClass                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Returns the assigned Service Class value.                 *
*   Parms      :  po_no           : portable number                         *
*   Returns    :  Service Class value                                       *
*   Call Level :  Process Level                                             *
*   Remarks    :  According to ETS 300 175-5, the Auth Reply message        *
*                 must contain the assigned Service Class value.            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BYTE
Subscription_GetServiceClass( BYTE po_no )
{
 #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
                                       /* Reasonable value for po_no ?     */
      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
      #endif
      return( uleSubscriptionPtr->service_class );
   }
   #endif

      #ifdef KLOCWORK
   if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_DECT)) {
      #endif
      return( FT_Subscription[ po_no - 1 ].service_class );
   } else {
      return 0;
   }
   #else
                                       /* Reasonable value for po_no ?     */
   if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
      return(0);

   return( FT_Subscription[ po_no - 1 ].service_class );
   #endif
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_GetModelID                                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Returns the model identifier.                             *
*   Parms      :  po_no           : portable number                         *
*   Returns    :  Model identifier                                          *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BYTE
Subscription_GetModelID( BYTE po_no )
{
 #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   BYTE model_id = 0xFF;

   #ifdef ULE_SUPPORT

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
      #endif
      model_id = uleSubscriptionPtr->model_id;
   }
   #endif

      #ifdef KLOCWORK
   if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_DECT)) {
      #endif
      model_id = FT_Subscription[ po_no - 1 ].model_id;
   }
   #else
   BYTE model_id;
                                       /* Reasonable value for po_no ?     */
   if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
      return(0);

   model_id = FT_Subscription[ po_no - 1 ].model_id;
   #endif

   if ( model_id == 0xFF ) // undefined;
   {
      return 0;
   }
   else
   {
      return model_id;
   }
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_GetTPUIRef                                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Returns the pointer to the TPUI array.                    *
*   Parms      :  po_no           : internal portable number                *
*   Returns    :  Pointer to the TPUI array                                 *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT FPTR
Subscription_GetTPUIRef( BYTE po_no )
{
 #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
                                       /* Reasonable value for po_no ?     */
      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
      #endif
      return( uleSubscriptionPtr->tpui_array );
   }
   #endif

   #ifdef CONFIG_REPEATER_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_REP(po_no, PORTABLE_REP)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_REP)) {
      #endif
      return( FT_RepSubscription[po_no - REP_DEVICE_OFFSET].tpui_array );
   }
   #endif

      #ifdef KLOCWORK
   if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_DECT)) {
      #endif
      return( FT_Subscription[ po_no - 1 ].tpui_array );
   } else {
      return( NULL );
   }
   #else
                                       /* Reasonable value for po_no ?     */
   if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
      return( NULL );

   return( FT_Subscription[ po_no - 1 ].tpui_array );
   #endif
}
#endif

#ifdef CONFIG_EARLY_ENCRYPTION
EXPORT WORD
Subscription_GetDefaultCipherKeyIndex(BYTE portableNo)
{
   // Reasonable value for repeater ?
   #ifdef CONFIG_REPEATER_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP))
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_REP))
      #endif
   {
      return FT_RepSubscription[portableNo - REP_DEVICE_OFFSET].defaultCipherKeyIndex;
   }
   #endif

   // Reasonable value for po_no ?
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT))
      #else
   if (!IsValidPortableNo(portableNo, PORTABLE_DECT))
      #endif
   #else
   if((portableNo == 0) || (portableNo > MAX_PORTABLE))
   #endif
   {
      return 0;
   }

   return FT_Subscription[portableNo - 1].defaultCipherKeyIndex;
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_GetDCKCCMRef                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Returns the pointer to the DCK-CCM array.                 *
*   Parms      :  portableNo - internal portable number                     *
*   Returns    :  Pointer to the DCK-CCM array                              *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
#ifdef ULE_SUPPORT
EXPORT FPTR
Subscription_GetDCKCCMRef(BYTE portableNo)
{
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
                                       /* Reasonable value for po_no ?     */
      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo);
      #endif
      return (uleSubscriptionPtr->dck_array);
   } else {
      return(NULL);
   }
   #endif
}
#endif
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_GetUAKRef                                    *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Returns the pointer to the UAK array.                     *
*   Parms      :  po_no           : internal portable number                *
*   Returns    :  Pointer to the UAK array                                  *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT FPTR
Subscription_GetUAKRef( BYTE po_no )
{
 #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
                                       /* Reasonable value for po_no ?     */
      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
      #endif
      return (uleSubscriptionPtr->uak_array);
   }
   #endif

   #ifdef CONFIG_REPEATER_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_REP(po_no, PORTABLE_REP)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_REP)) {
      #endif
      return (FT_RepSubscription[po_no - REP_DEVICE_OFFSET].uak_array);
   }
   #endif

      #ifdef KLOCWORK
   if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT)) {
      #else
   if (IsValidPortableNo(po_no, PORTABLE_DECT)) {
      #endif
      return (FT_Subscription[po_no - 1].uak_array);
   } else {
      return (NULL);
   }
   #else
                                       /* Reasonable value for po_no ?     */
   if ((po_no == 0) || (po_no > MAX_PORTABLE)) {
      return (NULL);
   }

   return (FT_Subscription[po_no - 1].uak_array);
   #endif
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_GetPotableNoFromIPUI                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions trys to find the assigned internal portable *
*                 number for a delivered IPUI.                              *
*   Parms      :  ipui_ptr        : pointer to the received IPUI Array      *
*   Returns    :  internal portable number / 0xFF                           *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BYTE
Subscription_GetPotableNoFromIPUI( FPTR ipui_ptr )
{
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   #endif
   BYTE reg_no;

   if (ipui_ptr == NULL) {
      return (0xFF);
   }

   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   for (reg_no = 0; reg_no < NR_OF_PORTABLE; reg_no++)
   #else
   for (reg_no = 0; reg_no < MAX_PORTABLE; reg_no++)
   #endif
   {
      if ((FT_Subscription[reg_no].status == VALID) && (Mmu_Memcmp(ipui_ptr, FT_Subscription[reg_no].ipui_array, 5))) {
         return( reg_no + 1 );
      }
   }

   #ifdef CONFIG_REPEATER_SUPPORT
   for (reg_no = 0; reg_no < NR_OF_REP_DEVICE; reg_no++)
   {
      if ((FT_RepSubscription[reg_no].status == VALID) && (Mmu_Memcmp(ipui_ptr, FT_RepSubscription[reg_no].ipui_array, 5))) {
         return( reg_no + REP_DEVICE_OFFSET );
      }
   }
   #endif

   #ifdef ULE_SUPPORT
   for (reg_no = 0; reg_no < NR_OF_ULE_DEVICE; reg_no++) {
      #ifdef KLOCWORK
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(reg_no);
      #else
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(reg_no+ULE_DEVICE_OFFSET);
      #endif
      if ((uleSubscriptionPtr->status == VALID) && (Mmu_Memcmp(ipui_ptr, uleSubscriptionPtr->ipui_array, 5))) {
         return( reg_no + ULE_DEVICE_OFFSET );
      }
   }
   #endif

   // The portable is not known, return 0xFF!
   return (0xFF);
}
#endif

#ifdef CATIQ_VE
/*
*****************************************************************************
*                                                                           *
*   Function   :  Subscription_GetPortableNoFromPMID                                       *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions trys to find the assigned internal portable *
*                 number for a delivered PMID (compare with TPUI).          *
*   Parms      :  pmid_ptr        : pointer to the received PMID Array      *
*   Returns    :  internal portable number / 0xFF                           *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BYTE
Subscription_GetPortableNoFromPMID( FPTR pmid_ptr )
{
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   #endif
   unsigned char* pTpui;
   BYTE reg_no;
                                          /* Frame there ?                 */
   if (pmid_ptr == NULL) {
      return (0xFF);
   }
                                       /* PRODECT Version 2.0 is designed  */
                                       /* to fulfill all requirements for  */
                                       /* a Home System.                   */
                                       /* The IPUI Length Indicator should */
                                       /* be always set to 40 bits.        */
                                       /* (->Mmu_Memcmp of 5 Bytes)        */
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   for (reg_no = 0; reg_no < NR_OF_PORTABLE; reg_no++)
   #else
   for (reg_no = 0; reg_no < MAX_PORTABLE; reg_no++)
   #endif
   {
      pTpui = FT_Subscription[ reg_no ].tpui_array;

      if( ( FT_Subscription[ reg_no ].status == VALID ) &&
          ( (pTpui[0]&0x0F) == (pmid_ptr[0]&0x0F) && ( pTpui[1] == pmid_ptr[1]) && ( pTpui[2] == pmid_ptr[2]) ) )
      {
         return( reg_no + 1 );
      }
   }

   #ifdef CONFIG_REPEATER_SUPPORT
   for (reg_no = 0; reg_no < NR_OF_REP_DEVICE; reg_no++)
   {
      pTpui = FT_RepSubscription[ reg_no ].tpui_array;

      if( ( FT_RepSubscription[ reg_no ].status == VALID ) &&
          ( (pTpui[0]&0x0F) == (pmid_ptr[0]&0x0F) && ( pTpui[1] == pmid_ptr[1]) && ( pTpui[2] == pmid_ptr[2]) ) )
      {
         return( reg_no + REP_DEVICE_OFFSET );
      }
   }
   #endif

   #ifdef ULE_SUPPORT
   for( reg_no = 0; reg_no < NR_OF_ULE_DEVICE; reg_no ++ ) {
      #ifdef KLOCWORK
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(reg_no);
      #else
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(reg_no+ULE_DEVICE_OFFSET);
      #endif
      pTpui = uleSubscriptionPtr->tpui_array;
      if((uleSubscriptionPtr->status == VALID) &&
         ((pTpui[0]&0x0F) == (pmid_ptr[0]&0x0F) && ( pTpui[1] == pmid_ptr[1]) && ( pTpui[2] == pmid_ptr[2]))) {
         return( reg_no + ULE_DEVICE_OFFSET );
      }
   }
   #endif
                                       /* The portable is not known,       */
                                       /* return 0xFF !                    */
   return( 0xFF );
} // Subscription_GetPortableNoFromPMID()
#endif
#endif

#ifdef FT
/*
 * Mahipati: This function copies subscription info into given buffer pucSusbInfo
 * Note that pucSusbInfo must have enough memory.
 */
EXPORT BYTE
Subscription_GetRegistrationData( BYTE portableNo, FPTR pucSusbInfo )
{
   /*
      BYTE          status;
      BYTE          ipui_array  [ 5  ];
      BYTE          tpui_array  [ 3  ];
      BYTE          uak_array   [ 16 ];
      BYTE          dck_array   [ 8  ];
      BYTE          service_class;
      BYTE          model_id;
    */
 #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;

   #ifdef KLOCWORK
   if(pucSusbInfo == NULL) return 0;
   #endif

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET);
      #else
    if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
     uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo);
      #endif
      memcpy(pucSusbInfo, uleSubscriptionPtr, sizeof(FT_ULE_SUBSCRIPTION));
      return 0;
   }
   #endif

   #ifdef CONFIG_REPEATER_SUPPORT
    #ifdef KLOCWORK
   if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
      #endif
      memcpy(pucSusbInfo, &FT_RepSubscription[portableNo-REP_DEVICE_OFFSET], sizeof(FT_REP_SUBSCRIPTION));
      return 0;
   }
   #endif

    #ifdef KLOCWORK
   if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT))
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_DECT))
      #endif
 #endif //#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
   {
      memcpy(pucSusbInfo, &FT_Subscription[portableNo-1], sizeof(FT_SUBSCRIPTION));
   }

   return 0;
}
#endif //#ifdef FT 

#ifdef CONFIG_EARLY_ENCRYPTION
EXPORT void
Subscription_UpdateDefaultCipherKeyOfModem(BYTE portableNo)
{
   FPTR cipherKeyPtr;
   FT_SUBSCRIPTION XDATA *subscriptionPtr;

   // Reasonable value for repeater ?
   #ifdef CONFIG_REPEATER_SUPPORT
      #ifdef KLOCWORK
   if (VALID_PORTABLE_REP(portableNo, PORTABLE_REP))
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_REP))
      #endif
   {
      cipherKeyPtr = Mmu_Malloc(8);
	  #ifdef KLOCWORK
	  if(cipherKeyPtr != NULL)
	  #endif
	  {
         Mmu_Memcpy(cipherKeyPtr, FT_RepSubscription[portableNo - REP_DEVICE_OFFSET].dck_array, 8);
         write_to_hmac_ioctl(HMAC, MAC_DEFAULT_CK_SET_REQ, portableNo, FT_RepSubscription[portableNo - REP_DEVICE_OFFSET].status,
                          HIBYTE(FT_RepSubscription[portableNo - REP_DEVICE_OFFSET].defaultCipherKeyIndex),
                          LOBYTE(FT_RepSubscription[portableNo - REP_DEVICE_OFFSET].defaultCipherKeyIndex),
                          0, 8, cipherKeyPtr,
                          0);
      }
	  return;
   }
   #endif

   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT))
      #else
   if (!IsValidPortableNo(portableNo, PORTABLE_DECT))
      #endif
   #else
   if((portableNo == 0) || (portableNo > MAX_PORTABLE))
   #endif
   {
      return;
   }

   subscriptionPtr = &FT_Subscription[portableNo - 1];
   {
      if (IFX_DBGA_GetStackModuleDebugID() & (IFX_DECT_STACK_DEBUG_ID_MM_DATA | IFX_DECT_STACK_DEBUG_ID_MM_KEY)) {
         IFX_DBG_Printf("[MM] DefaultCK for Modem: %d, %02x, %04x", portableNo, subscriptionPtr->status, subscriptionPtr->defaultCipherKeyIndex);
      }
      DECT_DEBUG_USER_MM_KEY(", %02x %02x %02x %02x %02x %02x %02x %02x",
                             subscriptionPtr->dck_array[0], subscriptionPtr->dck_array[1], subscriptionPtr->dck_array[2], subscriptionPtr->dck_array[3],
                             subscriptionPtr->dck_array[4], subscriptionPtr->dck_array[5], subscriptionPtr->dck_array[6], subscriptionPtr->dck_array[7]);
      if (IFX_DBGA_GetStackModuleDebugID() & (IFX_DECT_STACK_DEBUG_ID_MM_DATA | IFX_DECT_STACK_DEBUG_ID_MM_KEY)) {
         IFX_DBG_Printf("\n");
      }
   }
   cipherKeyPtr = Mmu_Malloc(8);
   #ifdef KLOCWORK
   if(cipherKeyPtr != NULL)
   #endif
   {
      Mmu_Memcpy(cipherKeyPtr, subscriptionPtr->dck_array, 8);
      write_to_hmac_ioctl(HMAC, MAC_DEFAULT_CK_SET_REQ, portableNo, subscriptionPtr->status, HIBYTE(subscriptionPtr->defaultCipherKeyIndex), LOBYTE(subscriptionPtr->defaultCipherKeyIndex),
                       0, 8, cipherKeyPtr,
                       0);
   }
}
#endif

#ifdef ULE_SUPPORT
EXPORT BOOL
Subscription_ResumesULENWK(BYTE portableNo)
{
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo);
      #endif
      return uleSubscriptionPtr->resumesULENWK;
   }
   return NO;
}

EXPORT void
Subscription_SetResumesULENWK(BYTE resumes, BYTE portableNo)
{
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
     uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo);
      #endif

      uleSubscriptionPtr->resumesULENWK = resumes;

      if (resumes) {
         Mmu_Memset(uleSubscriptionPtr->lastSSN, 0, ULE_DLC_SN_SIZE);
         Mmu_Memset(uleSubscriptionPtr->lastRSN, 0, ULE_DLC_SN_SIZE);
      }

      // TODO: send up subcription info checkpoint
      {
         struct HLI_Header *headerPtr;

         headerPtr = (struct HLI_Header *)Mmu_Malloc(sizeof(struct HLI_Header) + sizeof(FT_ULE_SUBSCRIPTION));
         #ifdef KLOCWORK
         if(headerPtr != NULL)
         #endif
         {
            headerPtr->length = sizeof(struct HLI_Header) + sizeof(FT_ULE_SUBSCRIPTION);
            headerPtr->next = 0;
            Subscription_GetRegistrationData(portableNo, (FPTR)((unsigned long)headerPtr) +sizeof(struct HLI_Header));
            Send_Message_To_APP(FP_SUBSCRIPTION_INFO_UPDATED_MM,
                                (FPTR)headerPtr,
                                DUMMY_FILL,
                                portableNo,
                                DUMMY_FILL,
                                DUMMY_FILL,
                                DUMMY_FILL);
         }
      }
   }
}


EXPORT void
Subscription_SetSN(BYTE XDATA *SSNPtr, BYTE XDATA *RSNPtr, BYTE portableNo)
{
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo);
      #endif

      Mmu_Memcpy(uleSubscriptionPtr->lastSSN, SSNPtr, ULE_DLC_SN_SIZE);
      Mmu_Memcpy(uleSubscriptionPtr->lastRSN, RSNPtr, ULE_DLC_SN_SIZE);

      // TODO: send up subcription info checkpoint
      #ifdef SMART_HOME_DEMO
      // if (SBBflg)
      #endif
      #if 0
      {
         struct HLI_Header *headerPtr;

         headerPtr = (struct HLI_Header *)Mmu_Malloc(sizeof(struct HLI_Header) + sizeof(FT_ULE_SUBSCRIPTION));
         #ifdef KLOCWORK
         if(headerPtr != NULL)
         #endif
         {
            headerPtr->length = sizeof(struct HLI_Header) + sizeof(FT_ULE_SUBSCRIPTION);
            headerPtr->next = 0;
            Subscription_GetRegistrationData(portableNo, (FPTR)((unsigned long)headerPtr) +sizeof(struct HLI_Header));
            Send_Message_To_APP(FP_SUBSCRIPTION_INFO_UPDATED_MM,
                                (FPTR)headerPtr,
                                DUMMY_FILL,
                                portableNo,
                                DUMMY_FILL,
                                DUMMY_FILL,
                                DUMMY_FILL);
            #ifdef SMART_HOME_DEMO
            SBBflg=0;
            #endif
         }
      }
      #endif
   }
}

EXPORT BYTE XDATA *Subscription_GetSSNRef(BYTE portableNo)
{
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo);
      #endif
      return uleSubscriptionPtr->lastSSN;
   }
   return NULL;
}

EXPORT BYTE XDATA *Subscription_GetRSNRef(BYTE portableNo)
{
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo);
      #endif
      return uleSubscriptionPtr->lastRSN;
   }
   return NULL;
}

EXPORT BYTE Subscription_GetWindowSize(BYTE portableNo)
{
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo);
      #endif
      return uleSubscriptionPtr->windowSize;
   }
   return 0;
}

EXPORT BYTE Subscription_GetBitOffset(BYTE portableNo)
{
   /*
      The range of nubmer of bit offset is 0 ~ 87.
      But for vaild check purpose, 1 ~ 88 is used interally so, deduct 1.
    */
   BYTE bitOffset;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      bitOffset = ((FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET))->deviceNo;
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      bitOffset = ((FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo))->deviceNo;
      #endif
      #if 0 // TODO: checkpoint
      if (bitOffset) {
         bitOffset--;
      }
      #endif
      return bitOffset;
   }
   return 0;
}

EXPORT void
Subscription_SetULEParameters(FPTR subscriptionPtr, BYTE updatedParametersFlag, BYTE portableNo)
{
   /*
      Only the following parameters of FT_ULE_SUBSCRIPTION will be updated.
      .lastSSN    - 0x01
      .lastRSN    - 0x02
      .ULEType    - 0x04
      .SDUSize    - 0x08
      .windowSize - 0x10
    */

   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo);
      #endif
      if (updatedParametersFlag & 0x01) {
         Mmu_Memcpy(uleSubscriptionPtr->lastSSN, ((FT_ULE_SUBSCRIPTION *)subscriptionPtr)->lastSSN, ULE_DLC_SN_SIZE);
      }
      if (updatedParametersFlag & 0x02) {
         Mmu_Memcpy(uleSubscriptionPtr->lastRSN, ((FT_ULE_SUBSCRIPTION *)subscriptionPtr)->lastRSN, ULE_DLC_SN_SIZE);
      }
      if (updatedParametersFlag & 0x04) {
         uleSubscriptionPtr->ULEType = ((FT_ULE_SUBSCRIPTION *)subscriptionPtr)->ULEType;
      }
      if (updatedParametersFlag & 0x08) {
         uleSubscriptionPtr->SDUSize = ((FT_ULE_SUBSCRIPTION *)subscriptionPtr)->SDUSize;
      }
      if (updatedParametersFlag & 0x10) {
         uleSubscriptionPtr->windowSize = ((FT_ULE_SUBSCRIPTION *)subscriptionPtr)->windowSize;
      }
   }
}

EXPORT void Subscription_SetULEType(BYTE deviceType, BYTE deviceNo, BYTE portableNo)
{
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET);
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo);
      #endif

      uleSubscriptionPtr->ULEType = deviceType;
      uleSubscriptionPtr->deviceNo = deviceNo;

      // Send up subcription info for flash update
      {
         struct HLI_Header *headerPtr;

         headerPtr = (struct HLI_Header *)Mmu_Malloc(sizeof(struct HLI_Header) + sizeof(FT_ULE_SUBSCRIPTION));
         #ifdef KLOCWORK
         if(headerPtr != NULL)
         #endif
         {
            headerPtr->length = sizeof(struct HLI_Header) + sizeof(FT_ULE_SUBSCRIPTION);
            headerPtr->next = 0;
            Subscription_GetRegistrationData(portableNo, (FPTR)((unsigned long)headerPtr) +sizeof(struct HLI_Header));
            Send_Message_To_APP(FP_SUBSCRIPTION_INFO_UPDATED_MM,
                                (FPTR)headerPtr,
                                DUMMY_FILL,
                                portableNo,
                                DUMMY_FILL,
                                DUMMY_FILL,
                                DUMMY_FILL);
         }
      }
   }
}
#endif

#ifdef ULE_SUPPORT
EXPORT BYTE
PageDescription_GetChannelPeriodicity(BYTE portableNo)
{
   FT_ULE_PAGE_DESCRIPTION *pageDescriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      #endif
      pageDescriptionPtr = (FT_ULE_PAGE_DESCRIPTION *)GetULEConfigPtr();

         #ifdef KLOCWORK
      switch (((FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET))->ULEType) {
         #else
      switch (((FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo))->ULEType) {
         #endif
         case IFX_DECT_ULE_SENSOR:
            return (BYTE)pageDescriptionPtr->uiSensorPageCycle;

         case IFX_DECT_ULE_SLOWACTUATOR:
            return (BYTE)pageDescriptionPtr->uiSlowActuatorPageCycle;

         case IFX_DECT_ULE_FASTACTUATOR:
            return (BYTE)pageDescriptionPtr->uiFastActuatorPageCycle;

         default:
            return 0;
      }
   }

   return 0;
}

EXPORT WORD
PageDescription_GetStartMultiframeNumber(BYTE portableNo)
{
   FT_ULE_PAGE_DESCRIPTION *pageDescriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      #endif
      pageDescriptionPtr = (FT_ULE_PAGE_DESCRIPTION *)GetULEConfigPtr();

         #ifdef KLOCWORK
      switch (((FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET))->ULEType) {
         #else
      switch (((FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo))->ULEType) {
         #endif
         case IFX_DECT_ULE_SENSOR:
            return (WORD)pageDescriptionPtr->uiStart_MFN_Sensor;

         case IFX_DECT_ULE_SLOWACTUATOR:
            return (WORD)pageDescriptionPtr->uiStart_MFN_SlowAct;

         case IFX_DECT_ULE_FASTACTUATOR:
            return (WORD)pageDescriptionPtr->uiStart_MFN_FastAct;

         default:
            return 0;
      }
   }

   return 0;
}

EXPORT BYTE
PageDescription_GetStartFrameNumber(BYTE portableNo)
{
   FT_ULE_PAGE_DESCRIPTION *pageDescriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      #endif
      pageDescriptionPtr = (FT_ULE_PAGE_DESCRIPTION *)GetULEConfigPtr();

         #ifdef KLOCWORK
      switch (((FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET))->ULEType) {
         #else
      switch (((FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo))->ULEType) {
         #endif
         case IFX_DECT_ULE_SENSOR:
            return pageDescriptionPtr->ucStart_FCNT_Sensor;

         case IFX_DECT_ULE_SLOWACTUATOR:
            return pageDescriptionPtr->ucStart_FCNT_SlowAct;

         case IFX_DECT_ULE_FASTACTUATOR:
            return pageDescriptionPtr->ucStart_FCNT_FastAct;

         default:
            return 0;
      }
   }

   return 0;
}

EXPORT BYTE
PageDescription_GetChannelActiveMask(BYTE portableNo)
{
   FT_ULE_PAGE_DESCRIPTION *pageDescriptionPtr;

      #ifdef KLOCWORK
   if (VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
      #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
      #endif
      pageDescriptionPtr = (FT_ULE_PAGE_DESCRIPTION *)GetULEConfigPtr();

         #ifdef KLOCWORK
      switch (((FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo-ULE_DEVICE_OFFSET))->ULEType) {
         #else
      switch (((FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(portableNo))->ULEType) {
         #endif
         case IFX_DECT_ULE_SENSOR:
            return pageDescriptionPtr->ucActiveChnlSensor;

         case IFX_DECT_ULE_SLOWACTUATOR:
            return pageDescriptionPtr->ucActiveChnlSlowAct;

         case IFX_DECT_ULE_FASTACTUATOR:
            return pageDescriptionPtr->ucActiveChnlFastAct;

         default:
            return 0xFF;
      }
   }

   return 0xFF;
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Add_ULE_MAC_INFO                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Appends the required ULE_MAC_CONFIG_INFO to the frame     *
*   Parms      :  frame_ptr       : Pointer to which the ULE_MAC_CONFIG_INFO *
*                                   IE shall be added.                      *
*   Returns    :  Pointer to the frame                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef ULE_SUPPORT
     /*!< DEFINITIONS according to Ref.: TS 102 939-1 */

/* Coding standard */
#define DECT_ULE_PART1 0x00

/* Control */
#define REPLACE_ALL_DESCRIPTORS 0x00
#define APPENDS_NEW_DESCRIPTORS 0x01

/* Channel descriminator type */
#define DESCRIPTOR_TYPE_BROADCAST 0x10 // 0001 xxxx
#define DESCRIPTOR_TYPE_PAGING    0x20 // 0010 xxxx

EXPORT BYTE XDATA *
Add_ULE_MAC_INFO( BYTE po_no, BYTE XDATA * frame_ptr  )
{
   BYTE current_pos;
   BYTE dataLength;
   #ifdef KLOCWORK
   BYTE XDATA * temp_ptr;
   #endif

      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ULE)) {
      #endif
      return frame_ptr;
   }

   if (PageDescription_GetChannelActiveMask(po_no) == 0xFF) { // if no page channel assigned
      return frame_ptr;
   }

   if (frame_ptr == NULL) {
      return frame_ptr;
   }

   dataLength = 3 + (5 * 1);
   current_pos = ((struct HLI_Header *)frame_ptr)->length;
   #ifdef KLOCWORK
   temp_ptr   = Mmu_Realloc(frame_ptr, current_pos + dataLength);
   if(temp_ptr == NULL) {
      return frame_ptr;
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr   = Mmu_Realloc(frame_ptr, current_pos + dataLength);
   #endif

   frame_ptr[current_pos++] = ULE_MAC_CONFIG_INFO;
   frame_ptr[current_pos++] = dataLength - 2; // length of contents
   // Coding standard and Control
   frame_ptr[current_pos++] = 0x80 | DECT_ULE_PART1 | REPLACE_ALL_DESCRIPTORS;

   // 1st ULE MAC Configuration
   frame_ptr[current_pos++] = DESCRIPTOR_TYPE_PAGING | PageDescription_GetChannelActiveMask(po_no); // Channel Descriptor Type | Channel Active Mask
   frame_ptr[current_pos++] = PageDescription_GetChannelPeriodicity(po_no); // Channel Periodicity
   frame_ptr[current_pos++] = (BYTE)(PageDescription_GetStartMultiframeNumber(po_no) >> 4); // Start MFN4
   frame_ptr[current_pos++] = ((BYTE)(PageDescription_GetStartMultiframeNumber(po_no) << 4)) | PageDescription_GetStartFrameNumber(po_no); // Start MFN | Start FCNT
   frame_ptr[current_pos++] = 0x80 | GET_BIT_OFFSET(po_no); // Continuation | BitOffset

   ((struct HLI_Header *)frame_ptr)->length = current_pos;

   return(frame_ptr);
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Add_PORTABLE_IDENTITY                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Appends the required PORTABLE_IDENTITY to the frame       *
*   Parms      :  po_no           : internal portable number                *
*   Parms      :  frame_ptr       : pointer to which the PORTABLE_IDENTITY  *
*                                   IE shall be added.                      *
*                 identity_type   : type of the required Identity           *
*                                   (IPUI, IPEI, TPUI)                      *
*   Returns    :  Pointer to the frame                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT FPTR
Add_PORTABLE_IDENTITY( BYTE po_no, FPTR frame_ptr, BYTE identity_type )
{
   #ifdef ULE_SUPPORT
   FT_ULE_SUBSCRIPTION * uleSubscriptionPtr;
   #endif
   BYTE current_pos;

                                       /* Reasonable value for po_no ?      */
   #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
   if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
   #endif
      return( frame_ptr );
                                       /* Frame there ?                    */
   if( frame_ptr == NULL )
      return( frame_ptr );

   switch( identity_type )
   {
      case IDENTITY_TYP_IPUI:

               current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;

               frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + 9 );

               #ifdef KLOCWORK
               if(frame_ptr != NULL)
               #endif
               {
                  frame_ptr[ current_pos++ ] = PORTABLE_IDENTITY;
                                          /* IE identifier field and length   */
                                          /* fieled is not counted !          */
                  frame_ptr[ current_pos++ ] = 7;
                  frame_ptr[ current_pos++ ] = 0x80 | IDENTITY_TYP_IPUI;
                                          /* 40 bits                          */
                  frame_ptr[ current_pos++ ] = 0x80 | 0x28;
                  /*                         Copy IPUI Number
                  ������������������������������������������������������������?
                  �typeN| EMC ?EMC | EMC ?EMC | PSN ?PSN | PSN ?PSN | PSN ?
                  ������������������������������������������������������������?
                  */
             #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
                  #ifdef ULE_SUPPORT
                     #ifdef KLOCWORK
                  if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
                     uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
                     #else
                  if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
                     uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
                     #endif
                     Mmu_Memcpy( &frame_ptr[ current_pos ],
                                 uleSubscriptionPtr->ipui_array,
                                 5 );
                  }
                  #endif

                  #ifdef CONFIG_REPEATER_SUPPORT
                  #ifdef KLOCWORK
                  if (VALID_PORTABLE_REP(po_no, PORTABLE_REP)) {
                  #else
                  if (IsValidPortableNo(po_no, PORTABLE_REP)) {
                  #endif
                     Mmu_Memcpy( &frame_ptr[ current_pos ],
                              FT_RepSubscription[po_no - REP_DEVICE_OFFSET].ipui_array,
                              5 );
                  }
                  #endif

                  #ifdef KLOCWORK
                  if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT))
                  #else
                  if (IsValidPortableNo(po_no, PORTABLE_DECT))
                  #endif
                  #endif
                  {
                     Mmu_Memcpy( &frame_ptr[ current_pos ],
                                 FT_Subscription[ po_no - 1 ].ipui_array,
                                 5 );
                  }
                                       /* Update length field !            */
                  (( struct HLI_Header * ) frame_ptr ) -> length += 9;
               }
               break;

      case IDENTITY_TYP_IPEI:

               current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;

               frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + 9 );

               #ifdef KLOCWORK
               if(frame_ptr != NULL)
               #endif
               {
                  frame_ptr[ current_pos++ ] = PORTABLE_IDENTITY;
                                          /* IE identifier field and length   */
                                          /* fieled is not counted !          */
                  frame_ptr[ current_pos++ ] = 7;
                  frame_ptr[ current_pos++ ] = 0x80 | IDENTITY_TYP_IPEI;
                                          /* 40 bits                          */
                  frame_ptr[ current_pos++ ] = 0x80 | 0x28;
                  /*                         Copy IPEI Number
                  ������������������������������������������������������������?
                  ?   0| EMC ?EMC | EMC ?EMC | PSN ?PSN | PSN ?PSN | PSN ?
                  ������������������������������������������������������������?
                  */
             #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
                  #ifdef ULE_SUPPORT
                     #ifdef KLOCWORK
                  if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
                     uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
                     #else
                  if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
                     uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
                     #endif
                     Mmu_Memcpy( &frame_ptr[ current_pos ],
                                 uleSubscriptionPtr->ipui_array,
                                 5 );
                  }
                  #endif

                  #ifdef CONFIG_REPEATER_SUPPORT
                     #ifdef KLOCWORK
                  if (VALID_PORTABLE_REP(po_no, PORTABLE_REP)) {
                     #else
                  if (IsValidPortableNo(po_no, PORTABLE_REP)) {
                     #endif
                     Mmu_Memcpy( &frame_ptr[ current_pos ],
                                 FT_RepSubscription[po_no - REP_DEVICE_OFFSET].ipui_array,
                                 5 );
                  }
                  #endif

                  #ifdef KLOCWORK
                  if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT))
                  #else
                  if (IsValidPortableNo(po_no, PORTABLE_DECT))
                  #endif
                #endif
                  {
                        Mmu_Memcpy( &frame_ptr[ current_pos ],
                                 FT_Subscription[ po_no - 1 ].ipui_array,
                                 5 );
                  }
                                          /* Delete first four bits for the   */
                                          /* IPEI delivery !                  */
                  frame_ptr[ current_pos ] &= 0x0F;

                                          /* Update length field !            */
                  (( struct HLI_Header * ) frame_ptr ) -> length += 9;
               }
               break;

      case IDENTITY_TYP_TPUI:

               current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;

               frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + 7 );

               #ifdef KLOCWORK
               if(frame_ptr != NULL)
               #endif
               {
                  frame_ptr[ current_pos++ ] = PORTABLE_IDENTITY;
                                          /* IE identifier field and length   */
                                          /* fieled is not counted !          */
                  frame_ptr[ current_pos++ ] = 5;
                  frame_ptr[ current_pos++ ] = 0x80 | IDENTITY_TYP_TPUI;
                                          /* 20 bits                          */
                  frame_ptr[ current_pos++ ] = 0x80 | 0x14;

                  /*                         Copy TPUI number
                  ������������������������������������?
                  ?   | 1 dgt?PSN | PSN ?PSN | PSN ?
                  ������������������������������������?
                  */
             #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
                  #ifdef ULE_SUPPORT
                     #ifdef KLOCWORK
                  if (VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
                     uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no-ULE_DEVICE_OFFSET);
                     #else
                  if (IsValidPortableNo(po_no, PORTABLE_ULE)) {
                     uleSubscriptionPtr = (FT_ULE_SUBSCRIPTION *)GetULESubscriptionInfoPtr(po_no);
                     #endif
                     Mmu_Memcpy( &frame_ptr[ current_pos ],
                                 uleSubscriptionPtr->tpui_array,
                                 3 );
                  }
                  #endif

                  #ifdef CONFIG_REPEATER_SUPPORT
                     #ifdef KLOCWORK
                  if (VALID_PORTABLE_REP(po_no, PORTABLE_REP)) {
                     #else
                  if (IsValidPortableNo(po_no, PORTABLE_REP)) {
                     #endif
                     Mmu_Memcpy( &frame_ptr[ current_pos ],
                                 FT_RepSubscription[po_no - REP_DEVICE_OFFSET].tpui_array,
                                 3 );
                  }
                  #endif

                  #ifdef KLOCWORK
                  if (VALID_PORTABLE_DECT(po_no, PORTABLE_DECT))
                  #else
                  if (IsValidPortableNo(po_no, PORTABLE_DECT))
                  #endif
              #endif
                  {
                     Mmu_Memcpy( &frame_ptr[ current_pos ],
                                 FT_Subscription[ po_no - 1 ].tpui_array,
                                 3 );
                  }
                                          /* Update length field !            */
                  (( struct HLI_Header * ) frame_ptr ) -> length += 7;
               }
               break;
      default:
               break;
   }
   return( frame_ptr );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Add_FIXED_IDENTITY                                        *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Appends the required FIXED_IDENTITY to the frame          *
*   Parms      :  frame_ptr       : Pointer to which the FIXED_IDENTITY     *
*                                   IE shall be added.                      *
*                 identity_type   : Type of the required Identity           *
*                                   (ARI, ARI+RPN, PARK)                    *
*   Returns    :  Pointer to the frame                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT FPTR
#ifdef CONFIG_REPEATER_SUPPORT
Add_FIXED_IDENTITY( BYTE rpnForWRS, FPTR frame_ptr, BYTE identity_type )
#else
Add_FIXED_IDENTITY( FPTR frame_ptr, BYTE identity_type )
#endif
{
   BYTE current_pos;

                                       /* Frame there ?                    */
   if( frame_ptr == NULL )
      return( frame_ptr );

   switch( identity_type )
   {
      case IDENTITY_TYP_ARI:
      case IDENTITY_TYP_ARI_RPN:
               break;

      #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
      case IDENTITY_TYP_ARI_RPN_FOR_WRS:
      #endif
      case IDENTITY_TYP_PARK:
               current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;

               frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + 9 );

               #ifdef KLOCWORK
               if(frame_ptr != NULL)
               #endif
               {
                  frame_ptr[ current_pos++ ] = FIXED_IDENTITY;
                                          /* IE identifier field and length   */
                                          /* fieled is not counted !          */
                  frame_ptr[ current_pos++ ] = 7;
                  #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
                  frame_ptr[ current_pos++ ] = 0x80 | identity_type;
                  if (identity_type == IDENTITY_TYP_ARI_RPN_FOR_WRS) {
                     frame_ptr[current_pos++] = 0x80 | 0x28;   // ARI + RPN; 40
                  } else {
                     frame_ptr[current_pos++] = 0x80 | 0x25;   // PARK Lenght Indicator + 1; 36(or 31) + 1
                  }
                  #else
                  frame_ptr[ current_pos++ ] = 0x80 | IDENTITY_TYP_PARK;
                                          /* bits = PARK Lenght Indicator + 1 */
                                          /* bits = 36 + 1                    */
                  frame_ptr[ current_pos++ ] = 0x80 | 0x25;
                  #endif
                                          /* Copy PARK-Key                    */
                  Mmu_Memcpy( &frame_ptr  [ current_pos ],
                              FT_Identity.rfpi_array,
                              5 );
                  #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
                  frame_ptr[ current_pos+ 4 ] &= ~0x07;
                  if (identity_type == IDENTITY_TYP_ARI_RPN_FOR_WRS) {
                  frame_ptr[ current_pos+ 4 ] |= rpnForWRS;
                  }
                  #endif
                                          /* Update length field !            */
                  (( struct HLI_Header * ) frame_ptr ) -> length += 9;
               }
               break;

      default:
               break;
   }
   return( frame_ptr );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Assign_PO_NO_Possible                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions checks if a portable is already get the assigned TPUI by Location registration   *
*                 and ready to assign PO number.                       *
*   Parms      :  po_no           : internal portable number                *
*   Returns    :  TRUE / FALSE                                              *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BIT
Assign_PO_NO_Possible( BYTE po_no )
{
     FPTR temp;
                                       /* Check if the portable has        */
                                       /* already invoked the Location     */
                                       /* Registration Procdure in the     */
                                       /* 'background'. If the procedure   */
                                       /* is not yet finished, the         */
                                       /* assigned TPUI would not be       */
                                       /* swapped with the other content   */
                                       /* of the registration slot. Paging */
                                       /* of the portable would not be     */
                                       /* possible anymore. As long as the */
                                       /* procedure is not finished all    */
                                       /* user inputs are ignored. The     */
                                       /* indication for the finished      */
                                       /* Location Registration Procedure  */
                                       /* is the assigned TPUI indication  */
                                       /* (0x00) in the first byte of the  */
                                       /* tpui array.                      */
     temp = Subscription_GetTPUIRef( po_no );
     #ifdef KLOCWORK
     if(temp == NULL) return FALSE;
     #endif
     if( temp[ 0 ] != 0x00 )
         return FALSE;
     else
         return TRUE;
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Set_AC                                                    *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function provides the Authentication Code bitstring   *
*                 mapping as specified in GAP 300 444 / 14.2.               *
*   Parms      :  value           : inserted digit by the user (ASCII-Coded)*
*                 cnt             : count value                             *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
/* Function for populating the AC_Array with the PIN CODE */
#ifdef __PIN_CODE__
void IFX_DECT_ST_SetPinCode(char* pszPinCode)
{
   /*Copy the same into the AC_Array global array*/
   BYTE i = 0,iLen;
   BYTE acByte[9] = " ";

   iLen = strlen(pszPinCode);
   DECT_DEBUG_USER_MM_AC("[MM] %s: Length: %d\n", __FUNCTION__, iLen);
   if (iLen > 8) {
      memcpy(acByte, pszPinCode, 8);
      acByte[8] = '\0';
   } else {
      #ifdef KLOCWORK
      pszPinCode[iLen] = '\0';
      #endif
      strcpy((char*)acByte, pszPinCode);
   }
   for (i = 0; i < strlen((char*)acByte); i++) {
      Set_AC(acByte[i], i);
   }
   DECT_DEBUG_USER_MM_AC("[MM] %s: AC: %s, %02x %02x %02x %02x\n", __FUNCTION__, acByte, AC_Array[0], AC_Array[1], AC_Array[2], AC_Array[3]);
   #if 0
   AC_Array[0]=0xF1;
   AC_Array[1]=0x23;
   AC_Array[2]=0x45;
   AC_Array[3]=0x67;
   #endif
}
#endif

#ifdef FT
EXPORT void
Set_AC( BYTE value, BYTE cnt )
{
                                       /* Example:                         */
                                       /* An entry of the PIN '1234' would */
                                       /* be translated into a bitstring   */
                                       /* AC of the following value:       */
                                       /* 1111 1111 1111 1111              */
                                       /* 0001 0010 0011 0100              */
                                       /* An entry of the PIN '12345678'   */
                                       /* 0001 0010 0011 0100              */
                                       /* 0101 0110 0111 1000              */
   value |= 0xF0;
   // PIN number digits = max 8 digits
   if( cnt == 0 )
   {
      AC_Array[ 0 ]  = 0xFF;
      AC_Array[ 1 ]  = 0xFF;
      AC_Array[ 2 ]  = 0xFF;
      AC_Array[ 3 ]  = 0xFF;
      AC_Array[ 3 ]  &= value;
   }
   else
   {
      AC_Array[ 0 ] <<= 4;
      AC_Array[ 0 ] |= 0x0F;
      AC_Array[ 0 ] &=
      (((AC_Array[ 1 ] >> 4) & 0x0F) | 0xF0);
      AC_Array[ 1 ] <<= 4;
      AC_Array[ 1 ] |= 0x0F;
      AC_Array[ 1 ] &=
      (((AC_Array[ 2 ] >> 4) & 0x0F) | 0xF0);
      AC_Array[ 2 ] <<= 4;
      AC_Array[ 2 ] |= 0x0F;
      AC_Array[ 2 ] &=
      (((AC_Array[ 3 ] >> 4) & 0x0F) | 0xF0);
      AC_Array[ 3 ] <<= 4;
      AC_Array[ 3 ] |= 0x0F;
      AC_Array[ 3 ] &= value;
   }

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Get_AC_Ptr                                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Returns the pointer to the AC array.                      *
*   Parms      :  none                                                      *
*   Returns    :  Pointer to the AC array                                   *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT FPTR
Get_AC_Ptr( void )
{
                                       /* Example:                         */
                                       /* An entry of the PIN '1234' would */
                                       /* be translated into a bitstring   */
                                       /* AC of the following value:       */
                                       /* 1111 1111 1111 1111              */
                                       /* 0001 0010 0011 0100              */
#ifdef xxx
   AC_Array[ 0 ]  = 0xFF;
   AC_Array[ 1 ]  = 0xFF;
   AC_Array[ 2 ]  = 0;
   AC_Array[ 3 ]  = 0;
   AC_Array[ 2 ] |= ( Get_FT_Settings_Value( FT_BASESTATION_UPI_1 ) & 0x0F ) << 4;
   AC_Array[ 2 ] |= ( Get_FT_Settings_Value( FT_BASESTATION_UPI_2 ) & 0x0F );
   AC_Array[ 3 ] |= ( Get_FT_Settings_Value( FT_BASESTATION_UPI_3 ) & 0x0F ) << 4;
   AC_Array[ 3 ] |= ( Get_FT_Settings_Value( FT_BASESTATION_UPI_4 ) & 0x0F );
#endif
   return( AC_Array );
}
#endif

/*
--------------------------------------------------()
PT/FT-Section-------------------------------------()
--------------------------------------------------()
*/


/*
*****************************************************************************
*                                                                           *
*   Function   :  Random                                                    *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Calculates random values from BMC register                *
*   Parms      :  set_ptr         : array pointer to store the values       *
*                 amount          : amounts of random values                *
*                 start_val       : start value                             *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Random( FPTR set_ptr, BYTE amount, BYTE start_val )
{
#ifdef CONFIG_TEST_AUTH_WITH_NO_RANDOM_VALUE
   BYTE i;

   start_val = start_val;
   for (i = 0; i < amount; i++) {
     set_ptr[i] = 0;
   }
#else
   BYTE i;
   static XDATA BYTE rand_start = 0x43;

   for( i = 0; i < amount; i++ )
   {
      set_ptr[ i ]  = (BYTE)random();
      set_ptr[ i ] += set_ptr[ i ] + i + start_val + rand_start;

      start_val  += (BYTE)(random());
      rand_start += (BYTE)(random()) & 0x0F;
   }
#endif
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Random2                                                   *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Calculates random values from equipment identities        *
*   Parms      :  none                                                      *
*   Returns    :  Random value                                              *
*   Call Level :  Process Level                                             *
*   Remarks    :  With this function a different behavior of different      *
*                 equipment can be achieved, e.g. after a reset (which      *
*                 might affect several equipments; think of a power failure)*
*                 PT's should not select the same channel.                  *
*                                                                           *
*****************************************************************************
*/
EXPORT BYTE
Random2( void )
{
   BYTE i;
   FPTR ident;
   static XDATA BYTE temp = 0;

#ifdef FT
   ident = Get_Rfpi_Ptr();
#endif
if(!temp){
   for (i=0; i<5; i++)
   {
      temp ^= *ident++;
   }
}else{

  temp >>= 1;
}
   return temp;
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  B1_Process                                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Implements the B1_Process as defined in                   *
*                 ETS 300 175-7 / page 26                                   *
*   Parms      :  ptr             : pointer to the UAK-Array / AC-Array     *
*                 k_ptr           : pointer to the K-Array                  *
*                 len             : length                                  *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
B1_Process( FPTR ptr, FPTR k_ptr, BYTE len )
{
   BYTE i;

   for( i = 0; i < K_LEN; i++ )
        k_ptr[ i ] = ptr[ i % len ];
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  A11_Process                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Implements the A11_Process as defined in                  *
*                 ETS 300 175-7 / page 27                                   *
*   Parms      :  k_ptr           : pointer to the K-Array                  *
*                 rs_ptr          : pointer to the RS-Array                 *
*                 ks_ptr          : pointer to the KS-Array                 *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  The A11_Process is a part of the DECT Standard            *
*                 Authentication Algorithm (DSAA).                          *
*                                                                           *
*                              ��������������Ŀ                             *
*                 K  (16) ����ĳ              ?                            *
*                              ?A11 Process  ����?  KS (16)               *
*                 RS (8)  ����ĳ              ?                            *
*                              ����������������                             *
*                                                                           *
*****************************************************************************
*/
EXPORT void
A11_Process( FPTR k_ptr, FPTR rs_ptr, FPTR ks_ptr )
{
   BYTE i;

   for( i = 0; i < 16; i++ )
      d1[ i ] = k_ptr[ 15 - i ];


   for( i = 0; i < 8; i++ )
      d2[ i ] = rs_ptr[ 7 - i ];

   Dsaa( (unsigned char*)d1, (unsigned char*)d2, (unsigned char*)e );

   for( i = 0; i < 16; i++ )
      ks_ptr[ i ] = e[ 15 - i ];
}

#ifdef ULE_SUPPORT
EXPORT void
A11_2_Process( BYTE XDATA * k_ptr, BYTE XDATA * rs1_ptr,  BYTE XDATA * rs2_ptr, BYTE XDATA * ks_ptr )
{
   Dsaa2_1( k_ptr, rs1_ptr, rs2_ptr, ks_ptr );

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  A12_Process                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Implements the A12_Process as defined in                  *
*                 ETS 300 175-7 / page 27                                   *
*   Parms      :  ks_ptr          : pointer to the KS-Array                 *
*                 rand_ptr        : pointer to the RAND-Array               *
*                 res1_ptr        : pointer to the RES1-Array               *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  The A12_Process is a part of the DECT Standard            *
*                 Authentication Algorithm (DSAA).                          *
*                                                                           *
*                              ��������������Ŀ                             *
*                 KS (16) ����ĳ              ?                            *
*                              ?A12 Process  ����?  RES1 (4)              *
*                 RAND (8)����ĳ              ?                            *
*                              ����������������                             *
*                                                                           *
*****************************************************************************
*/
EXPORT void
A12_Process( FPTR ks_ptr, FPTR rand_ptr, FPTR res1_ptr, FPTR dck_ptr )
{
   BYTE i;

   for( i = 0; i < 16; i++ )
      d1[ i ] = ks_ptr[ 15 - i ];

   for( i = 0; i < 8; i++ )
      d2[ i ] = rand_ptr[ 7 - i ];

   Dsaa( (unsigned char*)d1, (unsigned char*)d2, e );

   for( i = 0; i < 4; i++ )
      res1_ptr[ i ] = e[ 3 - i ];

   for( i = 0; i < 8; i++ )
      dck_ptr[ i ] = e[ 7 + 4 - i ];
}

#ifdef ULE_SUPPORT
EXPORT void
A12_2_Process( BYTE XDATA * ks_ptr, BYTE XDATA * rand_f_ptr, BYTE XDATA * rand_p_ptr, BYTE XDATA * res1_ptr, BYTE XDATA * dck_ptr )
{
   Dsaa2_2( ks_ptr, rand_f_ptr, rand_p_ptr, res1_ptr, dck_ptr );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  A21_Process                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Implements the A21_Process as defined in                  *
*                 ETS 300 175-7 / page 27                                   *
*   Parms      :  k_ptr           : pointer to the K-Array                  *
*                 rs_ptr          : pointer to the RS-Array                 *
*                 ks_ptr          : pointer to the KS-Array                 *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  The A21_Process is a part of the DECT Standard            *
*                 Authentication Algorithm (DSAA).                          *
*                                                                           *
*                              ��������������Ŀ                             *
*                 K  (16) ����ĳ              ?                            *
*                              ?A21 Process  ����?  KS (16)               *
*                 RS (8)  ����ĳ              ?                            *
*                              ����������������                             *
*                                                                           *
*****************************************************************************
*/
EXPORT void
A21_Process( FPTR k_ptr, FPTR rs_ptr, FPTR ks_ptr )
{
   BYTE i;

   for( i = 0; i < 16; i++ )
      d1[ i ] = k_ptr[ 15 - i ];

   for( i = 0; i < 8; i++ )
      d2[ i ] = rs_ptr[ 7 - i ];

   Dsaa( (unsigned char*)d1, d2, e );

   for( i = 0; i < 16; i++ )
      ks_ptr[ i ] = e[ 15 - i ] ^ 0xAA;
}

#ifdef ULE_SUPPORT
EXPORT void
A21_2_Process( BYTE XDATA * k_ptr, BYTE XDATA * rs1_ptr, BYTE XDATA * rs2_ptr, BYTE XDATA * ks_ptr )
{
   Dsaa2_1( k_ptr, rs1_ptr, rs2_ptr, ks_ptr );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  A22_Process                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Implements the A22_Process as defined in                  *
*                 ETS 300 175-7 / page 27                                   *
*   Parms      :  ks_ptr          : pointer to the KS-Array                 *
*                 rand_ptr        : pointer to the RAND-Array               *
*                 res1_ptr        : pointer to the RES1-Array               *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  The A22_Process is a part of the DECT Standard            *
*                 Authentication Algorithm (DSAA).                          *
*                                                                           *
*                              ��������������Ŀ                             *
*                 KS (16) ����ĳ              ?                            *
*                              ?A22 Process  ����?  RES1 (4)              *
*                 RAND (8)����ĳ              ?                            *
*                              ����������������                             *
*                                                                           *
*****************************************************************************
*/
EXPORT void
A22_Process( FPTR ks_ptr, FPTR rand_ptr, FPTR res2_ptr )
{
   BYTE i;

   for( i = 0; i < 16; i++ )
      d1[ i ] = ks_ptr[ 15 - i ];

   for( i = 0; i < 8; i++ )
      d2[ i ] = rand_ptr[ 7 - i ];

   Dsaa( (unsigned char*)d1, (unsigned char*)d2, (unsigned char*)e );

   for( i = 0; i < 4; i++ )
      res2_ptr[ i ] = e[ 3 - i ];
}

#ifdef ULE_SUPPORT
EXPORT void
A22_2_Process( BYTE XDATA * ks_ptr, BYTE XDATA * rand_p_ptr, BYTE XDATA * rand_f_ptr, BYTE XDATA * res2_ptr )
{
   Dsaa2_2( ks_ptr, rand_p_ptr, rand_f_ptr, res2_ptr, e );
}
#endif

