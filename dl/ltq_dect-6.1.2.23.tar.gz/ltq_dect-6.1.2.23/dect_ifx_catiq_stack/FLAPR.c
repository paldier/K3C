/* -- SIEMENS AG  PCT -- Process: LAP         -  Mon Feb 26 14:22:28 2007 -- */
#include	"DEFINE.H"
#include <stdio.h>
# include "SYSDEF.H"
# include "FDEF.H"
# include "TYPEDEF.H"
extern void KNL_T0000(void);
# include "SYSEXT.H"
# include "SYSINIT.H"

/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0       *
*                   (c) 2005 IFX / INTNIX. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  FLAP.PSL                                                *
*     Date       :  18 Nov, 2005                                            *
*     Contents   :                                                          *
*     Hardware   :  IFX 87xx                                                *
*                                                                           *
*****************************************************************************
*/
/* ========                                                             */
/* Includes                                                             */
/* ========                                                             */
#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#include "FGLOBAL.H"
#include "PCT_DEF.H"
#include "KNL_SYSTEM.H"
#include "MMU.H"
#include "P_TIM.H"
#include "CC_DEF.H"
#include "CC_LIB.H"
#include "LC_LIB.H"

#include "LAP_LIB.H"

#include "DECT.H"		/* for debugging */
		
/* ==============                                                       */
/* Local typedefs                                                       */
/* ==============                                                       */
typedef struct
{
   BYTE NR;
   BYTE NS;
   BYTE RC200;
   BYTE VS;
   BYTE VA;
   BYTE VR;
   BYTE Ack_Pending;
   BYTE Ack_Needed;
   BYTE L3_Length;
   FPTR L3_Frame;
} LAP_REP_TABLE_ELEMENT;

#ifdef DECT_DEBUG_USER_LAP_REP_PRIMITIVE
typedef struct {
   BYTE key;
   char *string;
} DebugStringTable_t;
#endif
		
/* ===============                                                      */
/* Local Variables                                                      */
/* ===============                                                      */
LOCAL XDATA LAP_REP_TABLE_ELEMENT LAPR_Struct[ MAX_LINK ];
#ifdef CONFIG_REPEATER_SUPPORT
LOCAL XDATA BYTE Ack_Flag = 0;
#endif

#ifdef DECT_DEBUG_USER_LAP_REP_PRIMITIVE
LOCAL DebugStringTable_t stateStringTable[] = {
   {ULI_RELEASED, "ULI_RELEASED"},
   {ULI_CLASS_A_ESTABLISHED, "ULI_CLASS_A_ESTABLISHED"},
   {0xFF, "Unknown State"}
};

LOCAL DebugStringTable_t messageStringTable[] = {
   {LAP_DL_REL_RQ_NORMAL_LCE, "LAP_REP_DL_REL_RQ_NORMAL_LCE"},
   {LAP_DL_REL_RQ_ABNORMAL_LCE, "LAP_REP_DL_REL_RQ_ABNORMAL_LCE"},
   {LAP_I_FRAME_NLF_LC, "LAP_REP_I_FRAME_NLF_LC"},
   {LAP_REL_IN_LC, "LAP_REP_REL_IN_LC"},
   {LAP_REL_CFM_LC, "LAP_REP_REL_CFM_LC"},
   {LAP_DL_DATA_RQ_LCE, "LAP_REP_DL_DATA_RQ_LCE"},
   {LAP_I_FRAME_LC, "LAP_REP_I_FRAME_LC"},
   {LAP_RR_FRAME_LC, "LAP_REP_RR_FRAME_LC"},
   {LAP_RR_FRAME_NLF_LC, "LAP_REP_RR_FRAME_NLF_LC"},
   {LAP_PRO_ERR_LC, "LAP_REP_PRO_ERR_LC"},
   {LAP_TIM_DL_04_EXPIRED, "LAP_REP_TIM_DL_04_EXPIRED"},
   {LAP_DL_ENC_KEY_RQ_LCE, "LAP_REP_DL_ENC_KEY_RQ_LCE"},
   {LAP_DL_ENC_IND_LC, "LAP_REP_DL_ENC_IND_LC"},
   {LAP_DL_REL_RQ_ABNORMAL_MM, "LAP_REP_DL_REL_RQ_ABNORMAL_MM"},
   {LAP_REP_ACCESS_REQ, "LAP_REP_ACCESS_REQ"},
   {LAP_REP_ACCESS_CFM, "LAP_REP_ACCESS_CFM"},
   {0xFF, "Unknown Message"}
};
#endif

/* ==========================                                           */
/* Global function definition                                           */
/* ==========================                                           */
EXPORT void
LAP_REP_INIT( void )
{
   BYTE i;

   Init_Queue( LAP_REP );
   for( i = 0; i < MAX_LINK; i++ ) {
      LAPR_Struct[ i ].L3_Frame = NULL;
   }
}

/* ==========================                                           */
/* Global function definition                                           */
/* ==========================                                           */
EXPORT void
RESET_LAP_REP_INIT( void )
{
   BYTE i;

   for( i = 0; i < MAX_LINK; i++ )
      Discard_Queue(LAP_REP, i);		// malloc queue clear by ralph_150508
   Init_Queue( LAP_REP );
   for( i = 0; i < MAX_LINK; i++ ) {
      LAPR_Struct[ i ].L3_Frame = NULL;
   }
}

/* =========================                                            */
/* Local function definition                                            */
/* =========================                                            */
#ifdef DECT_DEBUG_USER_LAP_REP_PRIMITIVE
LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
{
   BYTE i;

   for (i = 0; tablePtr[i].key != 0xFF; i++) {
      if (tablePtr[i].key == key) {
         break;
      }
   }
   return tablePtr[i].string;
}
#endif

#ifdef CONFIG_REPEATER_SUPPORT
LOCAL BIT
I_queue_empty( void )
{
   return( Empty_Queue( LAP_REP, CurrentInc ));
}

LOCAL void
discard_I_queue( void )
{
   Discard_Queue( LAP_REP, CurrentInc );
}

LOCAL FPTR
construct_RR_frame( BYTE nlf_bit )
{
   FPTR temp;

   temp = Construct_L2_Frame( nlf_bit, LLN_CLASS_A, S_SAP,
                              RESPONSE_TX, RR_TYP, M_BIT_CLEARED );
   #ifdef KLOCWORK
   if( temp == NULL )   {
      return( temp );
   }
   #endif
                                       /* The control field is updated !   */
   temp[ 1 + sizeof( struct HLI_Header ) ] |= ( LAPR_Struct[ CurrentInc ].VR << 5  );
   return( temp );
}

LOCAL FPTR
get_next_I_queue_entry( void )
{
   FPTR temp;

                                       /* Only a 'copy' of the oldest      */
                                       /* LAP queue entry is requested. In */
                                       /* case of an unsuccessful          */
                                       /* transmission the I-frame must be */
                                       /* repeated !                       */
   temp = Get_Next_Queue_Entry_Copy( LAP_REP, CurrentInc );
   #ifdef KLOCWORK
   if( temp == NULL )   {
      return( temp );
   }
   #endif
                                       /* The control field is updated !   */
   temp[ 1 + sizeof( struct HLI_Header ) ] |= ( LAPR_Struct[ CurrentInc ].VR << 5  ) | ( LAPR_Struct[ CurrentInc ].VS << 1 );
   return( temp );
}

LOCAL void
set_received_NR_value( void )
{
   LAPR_Struct[ CurrentInc ].NR = ( G_PTR[ 1 + sizeof( struct HLI_Header ) ] >> 5 ) & 0x07;
}

LOCAL void
set_received_NR_NS_value( void )
{
   LAPR_Struct[ CurrentInc ].NR = ( G_PTR[ 1 + sizeof( struct HLI_Header ) ] >> 5 ) & 0x07;
   LAPR_Struct[ CurrentInc ].NS = ( G_PTR[ 1 + sizeof( struct HLI_Header ) ] >> 1 ) & 0x07;
}

LOCAL void
release_I_frame( void )
{
   Mmu_Free( Get_Next_Queue_Entry( LAP_REP, CurrentInc ));
}

LOCAL FPTR
Assembly_L3_Frame( FPTR frame_ptr )
{
   BIT  M_Bit;
   BYTE Li;
   FPTR temp;

                                       /* Get the M-Bit setting !          */
   M_Bit = (frame_ptr[ 2 + sizeof( struct HLI_Header ) ] & 0x02) ? 1:0;
                                       /* Get L3 Frame Length !            */
   Li = ( frame_ptr[ 2 + sizeof( struct HLI_Header ) ] >> 2 ) & 0x3F;
                                       /* NTW Layer frame there ?          */
   if( Li == 0 )
   {
      Mmu_Free( frame_ptr );
      return( NULL );
   }
                                       /* Get the memory for the new       */
                                       /* L3 segment.                      */
   if( LAPR_Struct[ CurrentInc ].L3_Frame == NULL )
   {
                                       /* No segment is stored. The        */
                                       /* Mmu_Malloc allocates memory for  */
                                       /* the first segment plus HLI       */
                                       /* Header size.                     */
      LAPR_Struct[ CurrentInc ].L3_Length = sizeof( struct HLI_Header );
      LAPR_Struct[ CurrentInc ].L3_Frame  = Mmu_Malloc( sizeof( struct HLI_Header ) + Li );
   }
   else
   {
                                       /* A segment is already stored. The */
                                       /* Mmu_Realloc function is called   */
                                       /* to adjust the memory.            */
      LAPR_Struct[ CurrentInc ].L3_Frame = Mmu_Realloc( LAPR_Struct[ CurrentInc ].L3_Frame, LAPR_Struct[ CurrentInc ].L3_Length + Li );
   }
                                       /* Overflow condition.              */
                                       /* -------------------------------- */
                                       /* The whole MMU concept is based   */
                                       /* on a byte length indicator.      */
                                       /* If the L3-frame exceeds the      */
                                       /* maximum length, the frame is     */
                                       /* ignored !                        */
   if( LAPR_Struct[ CurrentInc ].L3_Length + Li > 250 )
   {
      Mmu_Free( frame_ptr );
      Mmu_Free( LAPR_Struct[ CurrentInc ].L3_Frame );
      LAPR_Struct[ CurrentInc ].L3_Frame = NULL;
      LAPR_Struct[ CurrentInc ].L3_Length = 0;
      return( NULL );
   }
                                       /* Copy frame content.              */
   Mmu_Memcpy( &LAPR_Struct[ CurrentInc ].L3_Frame[ LAPR_Struct[ CurrentInc ].L3_Length ],
               &frame_ptr[ CS_HEADER_LENGTH + sizeof( struct HLI_Header ) ], Li );
                                       /* Adjust new L3-Frame length.      */
   LAPR_Struct[ CurrentInc ].L3_Length += Li;
                                       /* Release received I-frame buffer. */
   Mmu_Free( frame_ptr );

   if( M_Bit == M_BIT_CLEARED )
   {
                                       /* If the last segment is received, */
                                       /* the whole L3-Frame is returned.  */
      temp = LAPR_Struct[ CurrentInc ].L3_Frame;
      (( struct HLI_Header * ) temp ) -> length = LAPR_Struct[ CurrentInc ].L3_Length;
      LAPR_Struct[ CurrentInc ].L3_Frame  = NULL;
      LAPR_Struct[ CurrentInc ].L3_Length = 0;
      return( temp );
   }
   else
   {
                                       /* Assembly of the L3-Frame not yet */
                                       /* completed. Wait for the next     */
                                       /* segement to receive.             */
      return( NULL );
   }
}

LOCAL void
reset_LAP_Struct( void )
{
   LAPR_Struct[ CurrentInc ].NR          = 0;
   LAPR_Struct[ CurrentInc ].NS          = 0;
   LAPR_Struct[ CurrentInc ].RC200       = 0;
   LAPR_Struct[ CurrentInc ].VS          = 0;
   LAPR_Struct[ CurrentInc ].VA          = 0;
   LAPR_Struct[ CurrentInc ].VR          = 0;
   LAPR_Struct[ CurrentInc ].Ack_Pending = FALSE;
   LAPR_Struct[ CurrentInc ].L3_Length   = 0;
   if( LAPR_Struct[ CurrentInc ].L3_Frame != NULL )
      Mmu_Free( LAPR_Struct[ CurrentInc ].L3_Frame );
   LAPR_Struct[ CurrentInc ].L3_Frame = NULL;
}
#endif //#ifdef CONFIG_REPEATER_SUPPORT

void 
DECODE_LAP_REP(void)
{
   #ifdef DECT_DEBUG_USER_LAP_REP_PRIMITIVE
   //if (CurrentMessage != LAP_DL_REL_RQ_NORMAL_LCE) {
      DECT_DEBUG_REPEAT("LAP_REP:%s, %s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable),
      getDebugStringRef(CurrentState, stateStringTable), CurrentInc, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
   //}
   #endif

   // Repeater MEssage should be exchenged only Link is established state.
   #ifdef CONFIG_REPEATER_SUPPORT
   switch (CurrentMessage) 
   {
      case LAP_DL_REL_RQ_NORMAL_LCE:  /*  IN LINE CODE T0200    */
      case LAP_DL_REL_RQ_ABNORMAL_LCE:  /*  IN LINE CODE T0250    */
      case LAP_DL_REL_RQ_ABNORMAL_MM:  /*  IN LINE CODE T0251    */
      case LAP_REL_IN_LC: 
      case LAP_PRO_ERR_LC: 
      case LAP_REL_CFM_LC: 
      {
         /* TRANSITION:      T250                                                 */
         /* EVENT:           LAP_DL_REL_RQ_ABNORMAL_LCE                           */
         /* DESCRIPTION:     Data Link Release Request, abnormal                  */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  all                                                  */
         /* END STATE:       ULI_RELEASED                                         */
         /* ----------------------------------------------------------------------*/
         discard_I_queue();
                                             /* Reset LAP Process Structure.     */
         reset_LAP_Struct();
                                             /* Stop all DLC-Timer.              */
         Stop_Pro_Timer( TIMER_DL_REP, CurrentInc );
         #ifdef CONFIG_REPEATER_SUPPORT
         if (KNL_STATE_ARRAY[MM][CurrentInc] == MM_CIPHER_ON) {
            KNL_SENDTASK_INC(MM, MM_DL_REL_IN_LCE, CurrentInc);
         }
         #endif
      }
      return;

      #ifdef CONFIG_REPEATER_SUPPORT
      case LAP_REP_ACCESS_REQ:
         KNL_SENDTASK_WP_INC( LC_REP, LC_REP_ACCESS_REQ, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4, CurrentInc );
         break;

      case LAP_REP_ACCESS_CFM:
         discard_I_queue();
         reset_LAP_Struct();
         Discard_Queue(LAP_REP, CurrentInc);
         KNL_SENDTASK_WP_INC( MM, MM_REP_ACCESS_CFM, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4, CurrentInc );
         break;
      #endif
      
      case LAP_I_FRAME_NLF_LC: 
      {
         /* TRANSITION:      T100                                                 */
         /* EVENT:           LAP_I_FRAME_NLF_LC                                   */
         /* DESCRIPTION:     Data Link Establish Request, CLASS A                 */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  ULI_RELEASED                                         */
         /* END STATE:       ULI_RELEASED / ULI_CLASS_A_ESTABLISHED               */
         /* ----------------------------------------------------------------------*/
         FPTR temp;
                                             /* Discard I-Queue.                 */
         discard_I_queue();
                                             /* Reset LAP Process Structure.     */
         reset_LAP_Struct();
                                             /* Stop all DLC-Timer.              */
         Stop_Pro_Timer( TIMER_DL_REP, CurrentInc );

         set_received_NR_NS_value();
                                             /* The Receive State Variable V(R)  */
                                             /* denotes the sequence number of   */
                                             /* the next-in-sequence I-frame     */
                                             /* expected to be received.         */
                                             /* The I-frame is only in-sequence, */
                                             /* when the Receive State Variable  */
                                             /* V(R) and the Send Sequence       */
                                             /* Number N(S) are equal.           */
         if( LAPR_Struct[ CurrentInc ].NS == LAPR_Struct[ CurrentInc ].VR )
         {
                                             /* The received I-frame is          */
                                             /* in-sequence !                    */
                                             /* -------------------------------- */
                                             /* The Receive State Variable V(R)  */
                                             /* is incremented.                  */
            LAPR_Struct[ CurrentInc ].VR = Increment( LAPR_Struct[ CurrentInc ].VR, SEQUENCEMAX );
                                             /* Report the link reestablishment  */
                                             /* to the LCE process.              */
            //KNL_SENDTASK_INC( LCE, LCE_DL_EST_IN_LAP, CurrentInc );
                                             /* Assembly the received L3-Frame.  */
                                             /* -------------------------------- */
            temp = Assembly_L3_Frame( G_PTR );
                                             /* The L3 frame is only transferred */
                                             /* to the NTW-Layer when the last   */
                                             /* segment is received.             */
            if( temp != NULL )
            {
               //KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_IN_LAP, temp, CurrentInc );
            }
                                             /* The I-frame must be acknowledged */
                                             /* with a RR-frame.                 */
            KNL_SENDTASK_NP_INC( LC_REP, LC_CO_DATA_RQ_LAP, construct_RR_frame( NLF_SET ), CurrentInc );
         }
         else
         {
                                             /* The received I-frame is NOT      */
                                             /* in-sequence !                    */
                                             /* -------------------------------- */
                                             /* The I-frame is ignored.          */
            Mmu_Free( G_PTR );
         }
      }
      return;

      case LAP_DL_DATA_RQ_LCE:  /*  IN LINE CODE T0400    */
      {
         /* TRANSITION:      T400                                                 */
         /* EVENT:           LAP_DL_DATA_RQ_LCE                                   */
         /* DESCRIPTION:     Data Request from LCE Process                        */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
         /* END STATE:       ULI_CLASS_A_ESTABLISHED                              */
         /* ----------------------------------------------------------------------*/
         FPTR temp;
         BYTE ntw_len, ntw_index;

                                             /* Frame there ?                    */
         if( G_PTR == NULL )
         return;
                                       /* Get the Layer 3 frame length !   */
         ntw_len = ((( struct HLI_Header * ) G_PTR ) -> length ) - sizeof( struct HLI_Header );
         DECT_DEBUG_REPEAT("LAP_REP(TX Length):%02x\n", ntw_len);
                                             /* NTW-Layer Frame too short ?      */
                                             /* Protocol Discriminator,          */
                                             /* Transaction Field and Message    */
                                             /* Field must be always there !     */
         if( ntw_len < 2 )
         {
            Mmu_Free( G_PTR );
            return;
         }
         #ifdef CONFIG_REPEATER_SUPPORT
         Ack_Flag = PARAMETER1;
         #endif
                                             /* Set the Index to first byte of   */
                                             /* the NTW-Layer frame !            */
         ntw_index =  sizeof( struct HLI_Header );
                                             /* Segmentation of the NTW-Layer    */
                                             /* Message.                         */
                                             /* -------------------------------- */
                                             /* The M-Bit is set to indicate     */
                                             /* that the information field only  */
                                             /* contains part of a NWK layer     */
                                             /* message - there is more to       */
                                             /* follow.                          */
         for( ; ntw_len > MAXIMUM_INFORMATION; )
         {
            temp = Construct_L2_Frame( NLF_CLEARED, LLN_CLASS_A, S_SAP,
                                       COMMAND_TX, I_TYP, M_BIT_SET );
            temp = Conc_L2_Fr_with_L3_Info( temp, &G_PTR[ ntw_index ], MAXIMUM_INFORMATION );
            Put_in_Queue( LAP_REP, CurrentInc, temp );
            ntw_len   -= MAXIMUM_INFORMATION;
            ntw_index += MAXIMUM_INFORMATION;
         }
                                             /* Last Segment is send with        */
                                             /* cleared M-Bit !                  */
         temp = Construct_L2_Frame( NLF_CLEARED, LLN_CLASS_A, S_SAP,
                                    COMMAND_TX, I_TYP, M_BIT_CLEARED );
         temp = Conc_L2_Fr_with_L3_Info( temp, &G_PTR[ ntw_index ], ntw_len );

         Put_in_Queue( LAP_REP, CurrentInc, temp );
                                             /* Free NTW-Layer frame.            */
         Mmu_Free( G_PTR );

                                             /* If currently no acknowledgment   */
                                             /* is outstanding, the first        */
                                             /* I-frame is send.                 */
         LAPR_Struct[CurrentInc].Ack_Needed = TRUE;
         if( LAPR_Struct[ CurrentInc ].Ack_Pending == FALSE )
         {
            KNL_SENDTASK_NP_INC( LC_REP, LC_CO_DATA_RQ_LAP, get_next_I_queue_entry(), CurrentInc );
                                             /* Go to state 'Acknowledge         */
                                             /* Pending'.                        */
            LAPR_Struct[ CurrentInc ].Ack_Pending = TRUE;
                                             /* Increment the Send State         */
                                             /* Variable V(S).                   */
            LAPR_Struct[ CurrentInc ].VS = Increment( LAPR_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                                             /* Start Retransmission Timer       */
                                             /* -------------------------------- */
                                             /* Timer:     <DL.04>               */
                                             /* Duration:  2 seconds             */
            Start_Pro_Timer( TIMER_DL_REP, CurrentInc );
         }
      }
      return;

      case LAP_I_FRAME_LC:  /*  IN LINE CODE T0301    */
      {
         /* TRANSITION:      T301                                                 */
         /* EVENT:           LAP_I_FRAME_LC                                       */
         /* DESCRIPTION:     I_Frame received                                     */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
         /* END STATE:       ULI_CLASS_A_ESTABLISHED                              */
         /* ----------------------------------------------------------------------*/
         //FPTR temp;/*commented to remove warnings error*/

         set_received_NR_NS_value();
                                             /* The Receive State Variable V(R)  */
                                             /* denotes the sequence number of   */
                                             /* the next-in-sequence I-frame     */
                                             /* expected to be received.         */
                                             /* The I-frame is only in-sequence, */
                                             /* when the Receive State Variable  */
                                             /* V(R) and the Send Sequence       */
                                             /* Number N(S) are equal.           */
         if( LAPR_Struct[ CurrentInc ].NS == LAPR_Struct[ CurrentInc ].VR )
         {
                                             /* The received I-frame is          */
                                             /* in-sequence !                    */
                                             /* -------------------------------- */
                                             /* The Receive State Variable V(R)  */
                                             /* is incremented.                  */
            LAPR_Struct[ CurrentInc ].VR = Increment( LAPR_Struct[ CurrentInc ].VR, SEQUENCEMAX );
                                             /* Assembly the received L3-Frame.  */
                                             /* -------------------------------- */
            /*temp =*/ Assembly_L3_Frame( G_PTR );
                                             /* The L3 frame is only transferred */
                                             /* to the NTW-Layer when the last   */
                                             /* segment is received.             */
            //if( temp != NULL )
            //   KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_IN_LAP, temp, CurrentInc );

                                             /* The I-frame is acknowledged      */
                                             /* with a RR-frame.                 */
            KNL_SENDTASK_NP_INC( LC_REP, LC_CO_DATA_RQ_LAP, construct_RR_frame( NLF_CLEARED ), CurrentInc );
         }
         else
         {
                                             /* The received I-frame is NOT      */
                                             /* in-sequence !                    */
                                             /* -------------------------------- */
                                             /* The I-frame is ignored and a     */
                                             /* RR-frame with the correct        */
                                             /* Receive State Variable V(R) is   */
                                             /* send back.                       */
            Mmu_Free( G_PTR );
            KNL_SENDTASK_NP_INC( LC_REP, LC_CO_DATA_RQ_LAP, construct_RR_frame( NLF_CLEARED ), CurrentInc );
         }
                              					/* The I-frame can be used to carry */
                              					/* a valid acknowledgment. Evaluate */
                              					/* the Receive Sequence Number      */
                              					/* N(R).                            */
                              					/* According to ETS 300 175-4 /     */
                              					/* 7.5.2.2 Send state Variable      */
                              					/* V(S), the windowsize k is fixed  */
                              					/* to 1 for class A operations.     */
                              					/* Therefore the Receive Sequence   */
                              					/* Number N(R) must be equal to the */
                              					/* Send State Variable V(S).        */
         if(( LAPR_Struct[ CurrentInc ].NR == LAPR_Struct[ CurrentInc ].VS ) &&
            ( LAPR_Struct[ CurrentInc ].VA != LAPR_Struct[ CurrentInc ].NR ))
         {
                                             /* Valid acknowledgment received.   */
                                             /* -------------------------------- */
                                             /* The I-frame is released and the  */
                                             /* Acknowledge State Variable V(A)  */
                                             /* is adjusted.                     */
            release_I_frame();
                                             /* Reset Acknowledge Pending State. */
            LAPR_Struct[ CurrentInc ].Ack_Pending = FALSE;
            LAPR_Struct[ CurrentInc ].VA = LAPR_Struct[ CurrentInc ].NR;

            if (LAPR_Struct[CurrentInc].Ack_Needed == TRUE) {
               LAPR_Struct[CurrentInc].Ack_Needed = FALSE;
            }
                                             /* Stop Acknowledgment Timer        */
                                             /* -------------------------------- */
            Stop_Pro_Timer( TIMER_DL_REP, CurrentInc );
                                             /* In case of queued I-frames, the  */
                                             /* next frame is send !             */
                                             /* -------------------------------- */
            if( I_queue_empty() == FALSE )
            {
                                             /* The next I-frame is send !       */
               KNL_SENDTASK_NP_INC( LC_REP, LC_CO_DATA_RQ_LAP, get_next_I_queue_entry(), CurrentInc );
                                             /* Go to state 'Acknowledge         */
                                             /* Pending'.                        */
               LAPR_Struct[ CurrentInc ].Ack_Pending = TRUE;
                                             /* Increment the Send State         */
                                             /* Variable V(S).                   */
               LAPR_Struct[ CurrentInc ].VS = Increment( LAPR_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                                             /* Reset I-frame Repeat Counter.    */
               LAPR_Struct[ CurrentInc ].RC200 = 0;
                                             /* Start Retransmission Timer       */
                                             /* -------------------------------- */
                                             /* Timer:     <DL.04>               */
                                             /* Duration:  2 seconds             */
               Start_Pro_Timer( TIMER_DL_REP, CurrentInc );
            }
            #ifdef CONFIG_REPEATER_SUPPORT
            else if (Ack_Flag == 1) {
               Ack_Flag = 0;
               KNL_SENDTASK_INC( MM, MM_MM_INFO_SENT_IN_LAP, CurrentInc );
            }
            #endif
         }
      }
      return;

      case LAP_RR_FRAME_LC:  /*  IN LINE CODE T0302    */
      {
         /* TRANSITION:      T302                                                 */
         /* EVENT:           LAP_RR_FRAME_LC                                      */
         /* DESCRIPTION:     RR_Frame received                                    */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
         /* END STATE:       ULI_CLASS_A_ESTABLISHED                              */
         /* ----------------------------------------------------------------------*/
         set_received_NR_value();
                                             /* According to ETS 300 175-4 /     */
                                             /* 7.5.2.2 Send state Variable      */
                                             /* V(S), the windowsize k is fixed  */
                                             /* to 1 for class A operations.     */
                                             /* Therefore the Receive Sequence   */
                                             /* Number N(R) must be equal to the */
                                             /* Send State Variable V(S).        */
         if(( LAPR_Struct[ CurrentInc ].NR == LAPR_Struct[ CurrentInc ].VS ) &&
            ( LAPR_Struct[ CurrentInc ].VA != LAPR_Struct[ CurrentInc ].NR ))
         {
                                             /* Valid acknowledgment received.   */
                                             /* -------------------------------- */
                                             /* The I-frame is released and the  */
                                             /* Acknowledge State Variable V(A)  */
                                             /* is adjusted.                     */
            release_I_frame();
                                             /* Reset Acknowledge Pending State. */
            LAPR_Struct[ CurrentInc ].Ack_Pending = FALSE;
            LAPR_Struct[ CurrentInc ].VA = LAPR_Struct[ CurrentInc ].NR;
            if (LAPR_Struct[CurrentInc].Ack_Needed == TRUE) {
               LAPR_Struct[CurrentInc].Ack_Needed = FALSE;
            }
                                             /* Stop Acknowledgment Timer        */
                                             /* -------------------------------- */
            Stop_Pro_Timer( TIMER_DL_REP, CurrentInc );
                                             /* In case of queued I-frames, the  */
                                             /* next frame is send !             */
                                             /* -------------------------------- */
            if( I_queue_empty() == FALSE )
            {
                                             /* The next I-frame is send !       */
               KNL_SENDTASK_NP_INC( LC_REP, LC_CO_DATA_RQ_LAP, get_next_I_queue_entry(), CurrentInc );
                                             /* Go to state 'Acknowledge         */
                                             /* Pending'.                        */
               LAPR_Struct[ CurrentInc ].Ack_Pending = TRUE;
                                             /* Increment the Send State         */
                                             /* Variable V(S).                   */
               LAPR_Struct[ CurrentInc ].VS = Increment( LAPR_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                                             /* Reset I-frame Repeat Counter.    */
               LAPR_Struct[ CurrentInc ].RC200 = 0;
                                             /* Start Retransmission Timer       */
                                             /* -------------------------------- */
                                             /* Timer:     <DL.04>               */
                                             /* Duration:  2 seconds             */
               Start_Pro_Timer( TIMER_DL_REP, CurrentInc );
            }
            #ifdef CONFIG_REPEATER_SUPPORT
            else if (Ack_Flag == 1) {
               Ack_Flag = 0;
               KNL_SENDTASK_INC( MM, MM_MM_INFO_SENT_IN_LAP, CurrentInc );
            }
            #endif
         }
         Mmu_Free( G_PTR );
      }
      return;

      case LAP_RR_FRAME_NLF_LC:  /*  IN LINE CODE T0303    */
      {
         /* TRANSITION:      T303                                                 */
         /* EVENT:           LAP_RR_FRAME_NLF_LC                                  */
         /* DESCRIPTION:     RR_Frame received with NLF set                       */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
         /* END STATE:       current state maintained                             */
         /* ----------------------------------------------------------------------*/
         set_received_NR_value();
                                             /* According to ETS 300 175-4 /     */
                                             /* 7.5.2.2 Send state Variable      */
                                             /* V(S), the windowsize k is fixed  */
                                             /* to 1 for class A operations.     */
                                             /* Therefore the Receive Sequence   */
                                             /* Number N(R) must be equal to the */
                                             /* Send State Variable V(S).        */
         if(( LAPR_Struct[ CurrentInc ].NR == LAPR_Struct[ CurrentInc ].VS ) &&
            ( LAPR_Struct[ CurrentInc ].VA != LAPR_Struct[ CurrentInc ].NR ))
         {
                                             /* Valid acknowledgment received.   */
                                             /* -------------------------------- */
                                             /* The I-frame is released and the  */
                                             /* Acknowledge State Variable V(A)  */
                                             /* is adjusted.                     */
            release_I_frame();
                                             /* Reset Acknowledge Pending State. */
            LAPR_Struct[ CurrentInc ].Ack_Pending = FALSE;
            LAPR_Struct[ CurrentInc ].VA = LAPR_Struct[ CurrentInc ].NR;
            if (LAPR_Struct[CurrentInc].Ack_Needed == TRUE) {
               LAPR_Struct[CurrentInc].Ack_Needed = FALSE;
            }
                                             /* Stop Acknowledgment Timer        */
                                             /* -------------------------------- */
            Stop_Pro_Timer( TIMER_DL_REP, CurrentInc );
                                             /* Report Re-establishment to LCE   */
                                             /* process.                         */
            //KNL_SENDTASK_INC( LCE, LCE_DL_EST_IN_LAP, CurrentInc );
                                             /* In case of queued I-frames, the  */
                                             /* next frame is send !             */
                                             /* -------------------------------- */
            if( I_queue_empty() == FALSE )
            {
                                             /* The next I-frame is send !       */
               KNL_SENDTASK_NP_INC( LC_REP, LC_CO_DATA_RQ_LAP, get_next_I_queue_entry(), CurrentInc );
                                             /* Go to state 'Acknowledge         */
                                             /* Pending'.                        */
               LAPR_Struct[ CurrentInc ].Ack_Pending = TRUE;
                                             /* Increment the Send State         */
                                             /* Variable V(S).                   */
               LAPR_Struct[ CurrentInc ].VS = Increment( LAPR_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                                             /* Reset I-frame Repeat Counter.    */
               LAPR_Struct[ CurrentInc ].RC200 = 0;
                                             /* Start Retransmission Timer       */
                                             /* -------------------------------- */
                                             /* Timer:     <DL.04>               */
                                             /* Duration:  2 seconds             */
               Start_Pro_Timer( TIMER_DL_REP, CurrentInc );
            }
            #ifdef CONFIG_REPEATER_SUPPORT
            else if (Ack_Flag == 1) {
               Ack_Flag = 0;
               KNL_SENDTASK_INC( MM, MM_MM_INFO_SENT_IN_LAP, CurrentInc );
            }
            #endif
         }
         Mmu_Free( G_PTR );
      }
      return;

      case LAP_TIM_DL_04_EXPIRED:  /*  IN LINE CODE T0454    */
      {
         /* TRANSITION:      T454                                                 */
         /* EVENT:           LAP_TIM_DL_04_EXPIRED ( Retransmission Timer )       */
         /* DESCRIPTION:     Timer P-<DL.04> expired                              */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
         /* END STATE:       ULI_RELEASED / ULI_CLASS_A_ESTABLISHED               */
         /* ----------------------------------------------------------------------*/
         if( LAPR_Struct[ CurrentInc ].RC200 == N250 )
         {
                                             /* Maximum number of                */
                                             /* retransmissions reached, the     */
                                             /* link is given up !               */
            discard_I_queue();
                                             /* Reset LAP Process Structure.     */
            reset_LAP_Struct();
                                             /* Stop all DLC-Timer.              */
            Stop_Pro_Timer( TIMER_DL_REP, CurrentInc );
            //KNL_SENDTASK_INC( LC, LC_REL_RQ_ABNORMAL_LAP, CurrentInc );
            //KNL_SENDTASK_INC( LCE, LCE_DL_REL_IN_LAP, CurrentInc );
         }
         else
         {
            if( I_queue_empty() == FALSE )
            {
                                             /* The I-frame is retransmitted     */
                                             /* with the same Send State         */
                                             /* Variable V(S).                   */
               LAPR_Struct[ CurrentInc ].VS = Decrement( LAPR_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                                             /* The I-frame is send again !      */
               KNL_SENDTASK_NP_INC( LC_REP, LC_CO_DATA_RQ_LAP, get_next_I_queue_entry(), CurrentInc );
                                             /* Go to state 'Acknowledge         */
                                             /* Pending'.                        */
               LAPR_Struct[ CurrentInc ].Ack_Pending = TRUE;
                                             /* Increment the Send State         */
                                             /* Variable V(S).                   */
               LAPR_Struct[ CurrentInc ].VS = Increment( LAPR_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                                             /* Increment I-frame Repeat Counter.*/
               LAPR_Struct[ CurrentInc ].RC200++;
                                             /* Start Retransmission Timer       */
                                             /* -------------------------------- */
                                             /* Timer:     <DL.04>               */
                                             /* Duration:  2 seconds             */
               Start_Pro_Timer( TIMER_DL_REP, CurrentInc );
            }
         }
      }
      return;

      case LAP_DL_ENC_KEY_RQ_LCE:  /*  IN LINE CODE T0600    */
      {
         /* TRANSITION:      T600                                                 */
         /* EVENT:           LAP_DL_ENC_KEY_RQ_LCE                                */
         /* DESCRIPTION:     Encryption key provision                             */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
         /* END STATE:       ULI_CLASS_A_ESTABLISHED                              */
         /* ----------------------------------------------------------------------*/
         KNL_SENDTASK_NP_WP_INC( LC_REP, LC_DL_ENC_KEY_RQ_LAP, G_PTR, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4, CurrentInc );
      }
      return;

      case LAP_DL_ENC_IND_LC:  /*  IN LINE CODE T0602    */
      {
         /* TRANSITION:      T602                                                 */
         /* EVENT:           LAP_DL_ENC_IND_LC                                    */
         /* DESCRIPTION:     Encryption mode confirmation                         */
         /* REFERENCE:       ETS 300 175-4:1996                                   */
         /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
         /* END STATE:       ULI_CLASS_A_ESTABLISHED                              */
         /* ----------------------------------------------------------------------*/
         KNL_SENDTASK_WP_INC( MM, MM_DL_ENC_IND_LCE, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4, CurrentInc );
      }
      return;


      default:
         break;
   }												/* end of switch state					*/
   #endif //#ifdef CONFIG_REPEATER_SUPPORT
   KNL_T0000();
}													/* end of DECODE_LAP()					*/
