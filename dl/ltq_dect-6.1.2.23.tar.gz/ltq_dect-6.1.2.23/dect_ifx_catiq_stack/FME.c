/* -- SIEMENS AG  PCT -- Process: ME          -  Mon Feb 26 14:22:26 2007 -- */
#include "DEFINE.H"
# include <stdio.h>
# include <string.h>
#include <unistd.h>
#ifdef LINUX
#include <sys/ioctl.h>
#endif
# include "SYSDEF.H"
# include "FDEF.H"
# include "TYPEDEF.H"
# include "fhmac.h"
#include "CP_SERVER.H"
extern void KNL_T0000(void);
extern unsigned char VucDECT_Enable;
extern unsigned char VucRANDOM_Timer_Started;
extern unsigned char vucDownloadBmcOnBootInd;
#ifdef CONFIG_UPDATE_QT_HANDLIING
extern void IFX_DECT_GetFTCap(void * pFTCapability);
#endif
extern void IFX_DECT_CosicModuleInitilized(void);
extern void   Set_Reg_Flag( void );
extern void   Clear_Reg_Flag( void );
extern BIT
Send_Message_To_APP( BYTE msg, FPTR ptr, BYTE inc
                            , BYTE parameter1,  BYTE parameter2,  BYTE parameter3,  BYTE parameter4 );
# include "SYSEXT.H"

      /*
      *****************************************************************************
      *                                                                           *
      *     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
      *                   (c) 2005 IFX / INTNIX. All rights reserved.               *
      *                                                                           *
      *****************************************************************************
      *                                                                           *
      *     Workfile   :  FME.PSL                                                 *
      *     Date       :  18 Nov, 2005                                       *
      *     Contents   :                                                          *
      *     Hardware   :  IFX 87xx                                               *
      *                                                                           *
      *****************************************************************************
      */
      /* ========                                                             */
      /* Includes                                                             */
      /* ========                                                             */

      #include "DEFINE.H"

      #include "SYSDEF.H"
      #include "TYPEDEF.H"
      #include "CONF_DEF.H"
      #include "ERROR.H"
      #include "FGLOBAL.H"
      #include "KNL_SYSTEM.H"
      #include "PCT_DEF.H"
      #include "P_TIM.H"
      #include "MMU.H"
      #include "MM_LIB.H"

    #include "dect_drv_if.h"

#ifdef CATIQ_NOEMO
      #include "MESSAGE_DEF.H"
#endif

#ifdef CONFIG_UPDATE_QT_HANDLIING
enum {
   DECT_Q0_MESSAGE_INDEX = 0, // System Info
   DECT_Q3_MESSAGE_INDEX, // FP Capabilities
   DECT_Q6_MESSAGE_INDEX, // Multiframe number
   DECT_Q4_MESSAGE_INDEX, // Extended FP Capabilities
   DECT_QC_MESSAGE_INDEX, // Extended FP Capabilities Part 2
};
typedef BYTE DECTQtMessageIndex_e;

typedef struct {
  BYTE fpCapability[5];/*!< Higher Layer Capabilities */
  BYTE extendedFPCapability[5];/*!< Extended Higher Layer Capabilities*/
  BYTE extendedFPCapability2[5];/*!< Extended Higher layer Capabilities*/
} FPCapability_t;
#endif

#ifdef DECT_DEBUG_USER_ME_PRIMITIVE
typedef struct {
   BYTE key;
   char *string;
} DebugStringTable_t;
#endif

#ifdef DECT_DEBUG_USER_ME_PRIMITIVE
LOCAL DebugStringTable_t messageStringTable[] = {
   {ME_SET_TO_DEFAULT_RQ_MEM, "ME_SET_TO_DEFAULT_RQ_MEM"},
   {ME_RFP_PRELOAD_DIS, "ME_RFP_PRELOAD_DIS"},
   {ME_A44_SET_RQ_DIS, "ME_A44_SET_RQ_DIS"},
   {ME_A44_CLEAR_RQ_DIS, "ME_A44_CLEAR_RQ_DIS"},
   {ME_RANDOM_TIMER_EXPIRY, "ME_RANDOM_TIMER_EXPIRY"},
   {ME_SYSTEM_RESET, "ME_SYSTEM_RESET"},
   {ME_MAC_NOEMO_RQ, "ME_MAC_NOEMO_RQ"},
   {ME_NOEMO_IN_MAC, "ME_NOEMO_IN_MAC"},
   {0xFF, "Unknown Message"}
};
#endif

#ifdef DECT_DEBUG_USER_ME_PRIMITIVE
LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
{
   BYTE i;

   for (i = 0; tablePtr[i].key != 0xFF; i++) {
      if (tablePtr[i].key == key) {
         break;
      }
   }
   return tablePtr[i].string;
}
#endif

      /* ==========================                                           */
      /* Global function definition                                           */
      /* ==========================                                           */

      /*
      ***************************************************************************
      *                                                                         *
      *     Function :  ME_INIT                                                 *
      *                                                                         *
      ***************************************************************************
      *                                                                         *
      *     Purpose  :  Initialization of the ME process.                       *
      *     Parms    :  none                                                    *
      *     Returns  :  none                                                    *
      *     Remarks  :                                                          *
      *                                                                         *
      ***************************************************************************
      */
      static int initDone=0;
      EXPORT void
      ME_INIT( void )
      {
      }


void DECODE_ME(void)
{
   #ifdef DECT_DEBUG_USER_ME_PRIMITIVE
   DECT_DEBUG_USER_ME_PRIMITIVE("%s, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable),
                                PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
   #endif
   switch (CurrentState)
   {

      case DUMMY_STATE:
         switch (CurrentMessage)
         {
            case ME_SET_TO_DEFAULT_RQ_MEM:  /*  IN LINE CODE T0126    */
            {
               /* TRANSITION:      T126                                                 */
               /* EVENT:           ME_SET_TO_DEFAULT_RQ_MEM                             */
               /* DESCRIPTION:     The process MEM signals that the user has finished   */
               /*                  the 'Set-To-Default' Procedure.                      */
               /*                  All registration slots are erased.                   */
               /* REMARK:                                                               */
               /* ----------------------------------------------------------------------*/
               BYTE i;

               for( i = 1; i <= NR_OF_PORTABLE; i++ ) {
                  Subscription_Deregister( i );
               }

               #ifdef ULE_SUPPORT
               for( i = ULE_DEVICE_OFFSET; i < (ULE_DEVICE_OFFSET + NR_OF_ULE_DEVICE); i++ ) {
                  Subscription_Deregister( i );
               }
               #endif

               #ifdef CONFIG_REPEATER_SUPPORT
               for( i = REP_DEVICE_OFFSET; i < (REP_DEVICE_OFFSET + NR_OF_REP_DEVICE); i++ ) {
                  Subscription_Deregister( i );
               }
               #endif
            }
            return;

            case ME_RFP_PRELOAD_DIS:  /*  IN LINE CODE T0300    */
            {

               /* TRANSITION:      T0300                                                */
               /* EVENT:           ME_RFP_PRELOAD_DIS                                   */
               /* DESCRIPTION:     Preload of the FT's RFPI                             */
               /* PARAMETER:       none                                                 */
               /* REFERENCE:                                                            */
               /* ----------------------------------------------------------------------*/
               DECT_DEBUG_USER_ME_DATA("[ME] ########## COSIC Modem Detected ##########\n");

               if (vucDownloadBmcOnBootInd) {
               // if (VucDECT_Enable) {
                  // if(!VucRANDOM_Timer_Started)
                  {
                     Start_Pro_Timer( TIMER_ME_RANDOM, 0 );
                     VucRANDOM_Timer_Started =1;
                  }
               }
            }
            return;

            case ME_A44_SET_RQ_DIS:  /*  IN LINE CODE T0301    */
            {
               /* TRANSITION:      T0301                                                */
               /* EVENT:           ME_A44_SET_RQ_DIS                                    */
               /* DESCRIPTION:     The FT starts supporting 'access rights requests'.   */
               /* PARAMETER:       none                                                 */
               /* REFERENCE:       ETS 300175-5, annex F1                               */
               /* REMARKS:         Bit a44 in the Q3 message is set.                    */
               /* ----------------------------------------------------------------------*/
               /* the MAC is requested to switch A44 mode   */
               Set_Reg_Flag( );
               write_to_hmac_ioctl(HMAC, MAC_A44_SET_RQ_ME
               ,TRUE, 0, 0, 0
               ,0, 0, 0, 0);
            }
            return;

            case ME_A44_CLEAR_RQ_DIS:  /*  IN LINE CODE T0302    */
            {
               /* TRANSITION:      T0302                                                */
               /* EVENT:           ME_A44_CLEAR_RQ_DIS                                  */
               /* DESCRIPTION:     The FT stops supporting 'access rights requests'.    */
               /* PARAMETER:       none                                                 */
               /* REFERENCE:       ETS 300175-5, annex F1                               */
               /* REMARKS:         Bit a44 in the Q3 message is reset.                  */
               /* ----------------------------------------------------------------------*/
               /* the MAC is requested to clear A44 mode   */

               Clear_Reg_Flag( );
               write_to_hmac_ioctl(HMAC, MAC_A44_SET_RQ_ME
               ,FALSE, 0, 0, 0
               ,0, 0, 0, 0);

            }
            return;

            #ifdef CATIQ_NOEMO
            case ME_MAC_NOEMO_RQ:  /*  IN LINE CODE T0302    */
            {
               /* EVENT:           ME_MAC_NOEMO_RQ                                      */
               /* DESCRIPTION:     no emmision mode request from application to MAC     */
               /* PARAMETER:       none                                                 */
               /* REFERENCE:                                                            */
               /* REMARKS:                                                              */
               /* ----------------------------------------------------------------------*/
               /* MAC request no emission mode */
               write_to_hmac_ioctl(HMAC, MAC_NOEMO_RQ_ME
               ,PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4
               ,0, 0, NULL, 0);
            }
            return;
            #endif

            case ME_RANDOM_TIMER_EXPIRY:  /*  IN LINE CODE T0303    */
            {
               /* TRANSITION:      T0303                                                */
               /* EVENT:           ME_RANDOM_TIMER_EXPIRY                               */
               /* DESCRIPTION:     After a random time has expired the MAC is requested */
               /*                  to start sending a dummy.                            */
               /* PARAMETER:       none                                                 */
               /* REFERENCE:                                                            */
               /* ----------------------------------------------------------------------*/
               BYTE i;
               BYTE *temp;
               FPTR rfpi_ptr;
               FPTR malloc_temp;
               uint32 userFeatures;
               DECT_MODULE_DEBUG_INFO send_data;
               /*int ret=0,j=0;*/
               unsigned short int unAddr = 0x04F7;
               unsigned short int unAddr1 = 0x1DF6;
               unsigned short int unAddr2 = 0x01F9;
               #ifdef CONFIG_UPDATE_QT_HANDLIING
               FPCapability_t fpCapability;
               #endif

               DECT_DEBUG_USER_ME_DATA("[ME] ########## COSIC Modem Parameters Downloaded ##########\n");

               // Send this TBR6 test mode first so that Modem can handle the frequency in different way in case TBR6 mode
               if (MAC_Test_Mode == TRUE) {
                  write_to_hmac_ioctl(HMAC, MAC_TBR6_MODE_RQ_ME
                  ,TRUE, 0, 0, 0
                  ,0, 0, 0, 0);
               }

               //
               Freq_TX_Offset = Bmc_Rssi_Settings.ucGENMUTCTRL0;
               Freq_RX_Offset = Bmc_Rssi_Settings.ucGENMUTCTRL1;
               Freq_Run = Bmc_Rssi_Settings.ucEXTMUTCTRL0 & 0x7F;
               malloc_temp = Mmu_Malloc(4);

               #ifdef KLOCWORK
               if(malloc_temp != NULL)
               #endif
               {
                  userFeatures = IFX_DECT_GetUserFeatures();
                  malloc_temp[3] = (BYTE)userFeatures; // LSB
                  userFeatures >>= 8;
                  malloc_temp[2] = (BYTE)userFeatures;
                  userFeatures >>= 8;
                  malloc_temp[1] = (BYTE)userFeatures;
                  userFeatures >>= 8;
                  malloc_temp[0] = (BYTE)userFeatures; // MSB
                  #ifdef CONFIG_REPEATER_SUPPORT
                  if ((malloc_temp[3] & 0x10) == 0x10) {
                     Feature_Repeater = 1;
                  } else {
                     Feature_Repeater = 0;
                  }
                  Set_Repeater_Rfpi (Feature_Repeater);
                  #endif 
                  DECT_DEBUG_USER_ME_DATA("[ME] UserFeatures: %02x %02x %02x %02x\n", malloc_temp[0], malloc_temp[1], malloc_temp[2], malloc_temp[3]);
                  DECT_DEBUG_USER_ME_DATA("[ME] RFCountry: %02x %02x %02x\n", Freq_TX_Offset, Freq_RX_Offset, Freq_Run);
                  write_to_hmac_ioctl(HMAC, MAC_BOOT_RQ_ME, Freq_TX_Offset, Freq_RX_Offset, Freq_Run, 0,
                                      0, 4, malloc_temp,
                                      0);
               }
               //
               malloc_temp = Mmu_Malloc(10);
               #ifdef KLOCWORK
               if(malloc_temp != NULL)
               #endif
               {
                  memset((FPTR)malloc_temp, 0, 10);
                  memcpy(&malloc_temp[0],&Bmc_Rssi_Settings,10);
                  #if 0
                  write_to_hmac_ioctl(HMAC, MAC_PARAMETER_PRELOAD_RQ_ME,
                  Bmc_Rssi_Settings.ucReserved_0, Bmc_Rssi_Settings.ucReserved_1, Bmc_Rssi_Settings.ucReserved_2, Bmc_Rssi_Settings.ucReserved_3,
                  0, 10, malloc_temp, 0);
                  #endif
                  write_to_hmac_ioctl(HMAC, MAC_PARAMETER_PRELOAD_RQ_ME, 0, 0, 0, 0,
                                      0, 10, malloc_temp,
                                      0);
               }
               DECT_DEBUG_USER_ME_DATA("[ME] BMC: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n",
               ((BYTE *)&Bmc_Rssi_Settings)[0],
               ((BYTE *)&Bmc_Rssi_Settings)[1],
               ((BYTE *)&Bmc_Rssi_Settings)[2],
               ((BYTE *)&Bmc_Rssi_Settings)[3],
               ((BYTE *)&Bmc_Rssi_Settings)[4],
               ((BYTE *)&Bmc_Rssi_Settings)[5],
               ((BYTE *)&Bmc_Rssi_Settings)[6],
               ((BYTE *)&Bmc_Rssi_Settings)[7],
               ((BYTE *)&Bmc_Rssi_Settings)[8],
               ((BYTE *)&Bmc_Rssi_Settings)[9]);

               //
               write_to_hmac_ioctl(HMAC, MAC_OSC_SET_RQ_ME, Osc_Trim_H, Osc_Trim_L, 0, 0,
                                   0, 0, 0,
                                   0);
               DECT_DEBUG_USER_ME_DATA("[ME] OSC: %02x %02x\n", Osc_Trim_H, Osc_Trim_L);

               //
               write_to_hmac_ioctl(HMAC, MAC_GFSK_SET_RQ_ME, (BYTE)(GFSK_Value & 0x00FF), (BYTE)((GFSK_Value >> 8) & 0x00FF), 0, 0,
                                   0, 0, 0,
                                   0);
               DECT_DEBUG_USER_ME_DATA("[ME] GFSK: %02x %02x\n", (BYTE)(GFSK_Value & 0x00FF), (BYTE)((GFSK_Value >> 8) & 0x00FF));

               //
               #ifdef CONFIG_EARLY_ENCRYPTION
               DECT_DEBUG_USER_ME_DATA("[ME] DefaultCK for Modem\n");
               for (i = 1; i <= NR_OF_PORTABLE; i++) { // Only for normal DECT
                  Subscription_UpdateDefaultCipherKeyOfModem(i);
               }
               #endif

               #ifdef CONFIG_UPDATE_QT_HANDLIING
               // Qt messages must be sent before MAC_SEND_DUMMY_RQ_ME
               IFX_DECT_GetFTCap(&fpCapability);
               malloc_temp = Mmu_Malloc(6); // 1(dummy) + 5 for MAC_QT_SET_RQ_ME
               memcpy(&malloc_temp[1], fpCapability.fpCapability, 5);
               write_to_hmac_ioctl(HMAC, MAC_QT_SET_RQ_ME, DECT_Q3_MESSAGE_INDEX, 0, 0, 0,
                                   0, 5, &malloc_temp[1],
                                   0);
               malloc_temp = Mmu_Malloc(6); // 1(dummy) + 5 for MAC_QT_SET_RQ_ME
               memcpy(&malloc_temp[1], fpCapability.extendedFPCapability, 5);
               write_to_hmac_ioctl(HMAC, MAC_QT_SET_RQ_ME, DECT_Q4_MESSAGE_INDEX, 0, 0, 0,
                                   0, 5, &malloc_temp[1],
                                   0);
               malloc_temp = Mmu_Malloc(6); // 1(dummy) + 5 for MAC_QT_SET_RQ_ME
               memcpy(&malloc_temp[1], fpCapability.extendedFPCapability2, 5);
               write_to_hmac_ioctl(HMAC, MAC_QT_SET_RQ_ME, DECT_QC_MESSAGE_INDEX, 0, 0, 0,
                                   0, 5, &malloc_temp[1],
                                   0);
					DECT_DEBUG_USER_ME_DATA("[ME] Q3: %02x %02x %02x %02x %02x\n",
					                         fpCapability.fpCapability[0],
					                         fpCapability.fpCapability[1],
					                         fpCapability.fpCapability[2],
					                         fpCapability.fpCapability[3],
					                         fpCapability.fpCapability[4]);
					DECT_DEBUG_USER_ME_DATA("[ME] Q4: %02x %02x %02x %02x %02x\n",
					                         fpCapability.extendedFPCapability[0],
					                         fpCapability.extendedFPCapability[1],
					                         fpCapability.extendedFPCapability[2],
					                         fpCapability.extendedFPCapability[3],
					                         fpCapability.extendedFPCapability[4]);
					DECT_DEBUG_USER_ME_DATA("[ME] QC: %02x %02x %02x %02x %02x\n",
					                         fpCapability.extendedFPCapability2[0],
					                         fpCapability.extendedFPCapability2[1],
					                         fpCapability.extendedFPCapability2[2],
					                         fpCapability.extendedFPCapability2[3],
					                         fpCapability.extendedFPCapability2[4]);
               #endif
               //
               temp = Get_Rfpi_Ptr();
               rfpi_ptr = Mmu_Malloc(5);

               #ifdef KLOCWORK
               if(rfpi_ptr != NULL)
               #endif
               {
                  if (MAC_Test_Mode == TRUE) {
                     // In TBR6-Test the RFPI is 0x 00 00 00 00 08
                     Mmu_Memset((FPTR) rfpi_ptr, 0x00, 5);
                     rfpi_ptr[4] = 0x08;
                  } else {
                     for (i = 0; i < 5; i++) {
                        rfpi_ptr[i] = temp[i];
                     }
                  }
                  DECT_DEBUG_USER_ME_DATA("[ME] RFPI: %02x %02x %02x %02x %02x\n", rfpi_ptr[0],rfpi_ptr[1], rfpi_ptr[2], rfpi_ptr[3], rfpi_ptr[4]);
                  write_to_hmac_ioctl(HMAC, MAC_SEND_DUMMY_RQ_ME, NoEmo_StartUp_Mode, NoEmo_StartUp_Ch, 0, 0,
                                      0, 5, rfpi_ptr,
                                      0);
               }
               #if 0
               write_to_hmac_ioctl(HMAC, MAC_SEND_DUMMY_RQ_ME
               ,0, 0, 0, 0
               ,0, 5, rfpi_ptr, 0);
               #endif
               DECT_DEBUG_USER_ME_DATA("[ME] NoEMO: %02x %02x\n", NoEmo_StartUp_Mode, NoEmo_StartUp_Ch);

               #ifdef SUPERTASK  // 2.4 interrupt rate
               memset(&send_data, 0x00, sizeof(DECT_MODULE_DEBUG_INFO));
               send_data.G_PTR_buf[0] = SPI_SETUP_PACKET; // Setup
               send_data.G_PTR_buf[1] = 24;
               send_data.G_PTR_buf[2] = 1;
               send_data.G_PTR_buf[3] = 0x38;
               send_data.debug_info_id = BMC_REGISTER_READ_REQ;
               send_data.rw_indicator = 1;
               send_data.CurrentInc = 0;
               dect_drv_ioctl(DECT_DRV_DEBUG_INFO, &send_data);
               // ret = ioctl(dect_drv_fd,DECT_DRV_DEBUG_INFO, &send_data);
               #endif
               initDone = 1;

               IFX_DECT_CosicModuleInitilized();

               /*Sending TPC parameters*/
               sleep(3);

               memset(&send_data, 0x00, sizeof(DECT_MODULE_DEBUG_INFO));
               send_data.G_PTR_buf[0] = 0x01; // xram
               send_data.G_PTR_buf[1] = (unAddr & 0xff00) >> 8;
               send_data.G_PTR_buf[2] = (unAddr & 0x00ff);

               send_data.debug_info_id = MEMORY_INFOMATION;
               send_data.rw_indicator = 1;
               send_data.CurrentInc = 7;
               memcpy(&send_data.G_PTR_buf[3], &Tpc_Param_Buf[0], 7);//G_PTR_MAX_DEBUG_COUNT);
               #ifdef LINUX
               /*ret = */ioctl(dect_drv_fd,DECT_DRV_DEBUG_INFO, &send_data);
               #endif
               #ifdef SUPERTASK
               dect_drv_ioctl(DECT_DRV_DEBUG_INFO, &send_data);
               #endif
               DECT_DEBUG_USER_ME_DATA("[ME] TPC: %02x %02x %02x %02x %02x-%02x %02x\n",
               Tpc_Param_Buf[0],
               Tpc_Param_Buf[1],
               Tpc_Param_Buf[2],
               Tpc_Param_Buf[3],
               Tpc_Param_Buf[4],
               Tpc_Param_Buf[5],
               Tpc_Param_Buf[6]);
               usleep(2000);

               memset(&send_data, 0x00, sizeof(DECT_MODULE_DEBUG_INFO));
               send_data.G_PTR_buf[0] = 0x01; // xram
               send_data.G_PTR_buf[1] = (unAddr1 & 0xff00) >> 8;
               send_data.G_PTR_buf[2] = (unAddr1 & 0x00ff);

               send_data.debug_info_id = MEMORY_INFOMATION;
               send_data.rw_indicator = 1;
               send_data.CurrentInc = 14;
               memcpy(&send_data.G_PTR_buf[3], &Tpc_Param_Buf1[0], 14);//G_PTR_MAX_DEBUG_COUNT);
               #ifdef LINUX
               /*ret = */ioctl(dect_drv_fd,DECT_DRV_DEBUG_INFO, &send_data);
               #endif
               #ifdef SUPERTASK
               dect_drv_ioctl(DECT_DRV_DEBUG_INFO, &send_data);
               #endif
               DECT_DEBUG_USER_ME_DATA("[ME] TPC1: %02x %02x %02x %02x %02x-%02x %02x %02x %02x %02x-%02x %02x %02x %02x\n",
               Tpc_Param_Buf1[0],
               Tpc_Param_Buf1[1],
               Tpc_Param_Buf1[2],
               Tpc_Param_Buf1[3],
               Tpc_Param_Buf1[4],
               Tpc_Param_Buf1[5],
               Tpc_Param_Buf1[6],
               Tpc_Param_Buf1[7],
               Tpc_Param_Buf1[8],
               Tpc_Param_Buf1[9],
               Tpc_Param_Buf1[10],
               Tpc_Param_Buf1[11],
               Tpc_Param_Buf1[12],
               Tpc_Param_Buf1[13]);
               usleep(2000);

               memset(&send_data, 0x00, sizeof(DECT_MODULE_DEBUG_INFO));
               send_data.G_PTR_buf[0] = 0x01; // xram
               send_data.G_PTR_buf[1] = (unAddr2 & 0xff00) >> 8;
               send_data.G_PTR_buf[2] = (unAddr2 & 0x00ff);

               send_data.debug_info_id = MEMORY_INFOMATION;
               send_data.rw_indicator = 1;
               send_data.CurrentInc = 1;
               memcpy(&send_data.G_PTR_buf[3], &Tpc_Param_Buf2[0], 1);//G_PTR_MAX_DEBUG_COUNT);
               #ifdef LINUX
               /*ret = */ioctl(dect_drv_fd,DECT_DRV_DEBUG_INFO, &send_data);
               #endif
               #ifdef SUPERTASK
               dect_drv_ioctl(DECT_DRV_DEBUG_INFO, &send_data);
               #endif
               DECT_DEBUG_USER_ME_DATA("[ME] TPC2: %02x\n", Tpc_Param_Buf2[0]);
               usleep(2000);

               VucRANDOM_Timer_Started = 0;
               DECT_DEBUG_USER_ME_DATA("[ME] ########## COSIC Modem Parameters Done To Download ##########\n");
            }
            return;

            case ME_SYSTEM_RESET:  /*  IN LINE CODE T1000    */
            {
               /* TRANSITION:      T1000                                                */
               /* EVENT:           ME_SYSTEM_RESET                                      */
               /* DESCRIPTION:     Reset of the BMC and ECO                             */
               /* REFERENCE:                                                            */
               /* ----------------------------------------------------------------------*/
               #ifdef MACTEST
               System_Reset ();
               #endif /* MACTEST */
            }
            return;

            #ifdef CATIQ_NOEMO
            case ME_NOEMO_IN_MAC:
               Send_Message_To_APP( FP_MAC_NOEMO_IN_ME, G_PTR, 0, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4 );
               #ifdef SUPERTASK
               sleep(1);
               #endif
            return;
            #endif

            default:
                break;

         }                             /* end of switch message            */
         break;

   }                                   /* end of switch state              */
   KNL_T0000();

}                                      /* end of DECODE_ME()               */

int getCosicStatus(void)
{
   return initDone;
}
