#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>

int  main (int argc, char *argv [])
{
  printf("aaaaaaaaaaaaaaaaaaaaaaaaaaaa\n");
  exit(0);
}