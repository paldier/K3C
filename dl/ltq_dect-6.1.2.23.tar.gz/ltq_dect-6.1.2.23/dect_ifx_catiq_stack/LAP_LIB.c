/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
*                   (c) 2005 IFX / INTNIX. All rights reserved.               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  LAP_LIB.C                                               *
*     Date       :  18 Nov, 2005                                       *
*     Contents   :  Contents : Library for Process 'LINK ACCESS PROCEDURE ( LAP )'                                                                                                                                                                                                                                                          *
*     Hardware   :  IFX 87xx                                               *
*                                                                           *
*****************************************************************************
*/
   /* ========                                                             */
   /* Includes                                                             */
   /* ========                                                             */
#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#ifdef FT
#include "FGLOBAL.H"
#endif

#include "KNL_SYSTEM.H"
#include "MMU.H"
#include "FDEF.H"
#include "LC_LIB.H"

#include "LAP_LIB.H"

   /* ==========================                                           */
   /* Global function definition                                           */
   /* ==========================                                           */
/*
*****************************************************************************
*                                                                           *
*   Function   :  Construct_L2_Frame                                        *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Builds the requested Layer 2 frame header.                *
*   Parms      :  NLF_Bit         : New Link Flag                           *
*                 LLN             : Logical Link Number                     *
*                 SAPI            : Service Access Point Identifier         *
*                 Command_TX      : C/R Bit                                 *
*                 L2_Typ          : requested Layer 2 Frame Typ             *
*                 M_Bit           : More Bit                                *
*   Return     :  Pointer to the requested Layer 2 frame header             *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef DECT_NG
EXPORT FPTR
Construct_L2_Frame( BYTE NLF_Bit, BYTE LLN, BYTE SAPI, BYTE Command_TX, BYTE L2_Typ, BYTE M_Bit )
#else
EXPORT FPTR
Construct_L2_Frame( BIT NLF_Bit, BYTE LLN, BYTE SAPI, BYTE Command_TX, BYTE L2_Typ, BIT M_Bit )
#endif
{
   BYTE AD_byte;
   BYTE length_indicator_byte;
   FPTR temp_ptr;
   BYTE size_HLI_Header;

   size_HLI_Header = sizeof( struct HLI_Header );



                      /* |  8  |  7  |  6  |  5  |  4  | 3  |  2  |  1 |   */
                      /* -----------------------------------------------   */
                      /* | NLF |        LLN      |    SAPI  | C/R | RES|   */
                      /* -----------------------------------------------   */
                                       /* NLF : New Link Flag              */
                                       /* LLN : Logical Link Number        */
                                       /* SAPI: Service Access Point Idt.  */
                                       /* C/R : Cmd/Rsp-Bit                */
                                       /* RES : Reserved-Bit               */

                                       /* Set NLF-Bit & RES-Bit !          */
                                       /* RES-Bit shall be set to "1"      */
#ifdef DECT_NG
    if ( NLF_Bit == NLF_SET) AD_byte = 0x81;
#else
   if ( NLF_Bit ) AD_byte = 0x81;
#endif
   else           AD_byte = 0x01;
                                       /* Set LLN !                        */
   AD_byte |= (LLN & 0x07) << 4;
                                       /* Set SAPI !                       */
   AD_byte |= (SAPI & 0x03) << 2;
                                       /* Set C_R_Bit !                    */
   AD_byte |= Command_TX;
                                       /* Build Length Indicator field !   */
                                       /* ( not extended !! )              */
                                       /* -------------------------------- */

                      /* |  8  |  7  |  6  |  5  |  4  | 3  |  2  |  1 |   */
                      /* -----------------------------------------------   */
                      /* |              Li                  |  M  | N=1|   */
                      /* -----------------------------------------------   */
                                       /* Li  : Length of information      */
                                       /*       field ( not extended ! )   */
                                       /* M   : More data bit              */
                                       /* N   : Li extension bit ( = 1 )   */

                                       /* Set M-Bit & N-Bit !              */
                                       /* N-Bit shall be set to "1"        */
                                       /* Li is set to 0                   */
#ifdef DECT_NG
   if ( M_Bit == M_BIT_SET ) length_indicator_byte = 0x03;
#else
   if ( M_Bit ) length_indicator_byte = 0x03;
#endif
   else         length_indicator_byte = 0x01;

                                       /* Request a memory block           */
   temp_ptr = Mmu_Malloc( CS_HEADER_LENGTH + size_HLI_Header);

#ifdef KLOCWORK
   if(temp_ptr != NULL)
#endif
   {
                                          /* Set total Length                 */
      (( struct HLI_Header * ) temp_ptr) -> length =
         CS_HEADER_LENGTH + size_HLI_Header;

                                          /* Write to Address field           */
      temp_ptr[ size_HLI_Header ]     = AD_byte;
                                          /* Write to Control field           */
      temp_ptr[ 1 + size_HLI_Header ] = L2_Typ;
                                          /* Write to Length Indicator field  */
      temp_ptr[ 2 + size_HLI_Header ] = length_indicator_byte;
   }
   return ( temp_ptr );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Conc_L2_Fr_with_L3_Info                                   *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Concates the Layer 3 information with a Layer 2 frame.    *
*                 dest_ptr (Pointer to the L2 frame):                       *
*                 ��������������������������������Ŀ                        *
*                 ?HLI_Header ?Adr. ?Ctrl.?Li  ?                       *
*                 ����������������������������������                        *
*                 source_ptr (Pointer to the L3 frame):                     *
*                 ��������������������������������Ŀ                        *
*                 ? Layer 3 frame                 ?                       *
*                 ����������������������������������                        *
*   Parms      :  dest_ptr        : Pointer to the L2-frame                 *
*                 source_ptr      : Pointer to the L3-frame                 *
*                 Li              : Length of L3-frame                      *
*   Return     :  The Layer 2 frame concated with the Layer 3 information   *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Conc_L2_Fr_with_L3_Info( FPTR dest_ptr, FPTR source_ptr, BYTE Li )
{
	BYTE	size_HLI_Header;
	size_HLI_Header = sizeof( struct HLI_Header );


   ASSERT( Li <= MAXIMUM_INFORMATION, "L3_INFO_TOO_LONG" );
                                       /* Request memory for the new       */
                                       /* content.                         */
   dest_ptr = Mmu_Realloc( dest_ptr, size_HLI_Header + 3 + Li );

#ifdef KLOCWORK
   if(dest_ptr != NULL)
#endif
   {
                                       /* Copy the content of the L3 frame */
                                       /* to the L2 frame.                 */
      Mmu_Memcpy( &dest_ptr[ size_HLI_Header + 3 ],
                  source_ptr,
                  Li );

                                       /* Update Li field                  */
      dest_ptr[ 2 + size_HLI_Header ] |=  ( Li << 2 ) & 0xFC ;

                                       /* Update length field              */
      ( ( struct HLI_Header * ) dest_ptr ) -> length =
          size_HLI_Header + 3 + Li;
   }
   return( dest_ptr );
}

