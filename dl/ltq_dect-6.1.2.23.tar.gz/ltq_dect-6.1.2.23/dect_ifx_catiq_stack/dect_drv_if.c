#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#ifdef LINUX
#include <sys/ioctl.h>
#include <unistd.h>
#endif

#include "dect_drv_if.h"
#include "DECT.H"
#include "fhmac.h"
#include "FDEF.H"

#define DECT_DEVICE_NAME "/dev/dect_drv"
#define DECT_SPI_NAME	"/dev/ssc"

int dect_spi_fd;
int dect_drv_fd;
extern void
Mmu_Free( FPTR return_ptr );
//extern int vuidect_drv_fd;
int DectDrvIfInit(void)
{
#if 0
  dect_spi_fd = open(DECT_SPI_NAME, O_RDWR);
  if (dect_spi_fd < 0)
  {
    return FALSE;
  }
#endif
#ifdef LINUX
  dect_drv_fd = open(DECT_DEVICE_NAME, O_RDWR);
  if (dect_drv_fd < 0)
  {
    return FALSE;
  }
#endif
#ifdef SUPERTASK
  /*
  dect_drv_fd = dect_drv_open();
  if (dect_drv_fd < 0)
  {
    return FALSE;
  }
  */
#endif
  return TRUE;
}
int DectDrvIfShut(void)
{
#ifdef LINUX
	int iRet= FALSE;
	if(dect_drv_fd)
	{
  	iRet=ioctl(dect_drv_fd, DECT_DRV_SHUTDOWN, NULL);
		close(dect_drv_fd);
		dect_drv_fd=0;
	}
	return iRet;
#endif
#ifdef SUPERTASK
   return TRUE;
#endif
}

#if 0
void write_FU10_data_to_hmac_ioctl(BYTE lln,unsigned short len,FPTR data)
{
  UPLANE_PACKET send_data;
  memset(&send_data, 0x00, sizeof(send_data));
  send_data.Length=len;
  send_data.Mcei=lln;
  send_data.MSG=MAC_FU10_DATA_RQ;
  //send_data.Status=0;
  memcpy(send_data.Uplan,data,len);
  ioctl(dect_drv_fd, DECT_DRV_TO_HMAC_MSG,(HMAC_QUEUES*) &send_data);

}

#endif

/******************************************************************
 *  Function Name  : 
 *  Description    : This function parses the data from DECT Stack(LU10,,,,) to
 *                   HMAC 
 *  Input Values   : ..data buffer
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
/* if pdata being,  param5 is HLI_struct indicator, param6 is pdata length(only noting param 5) */
void write_to_hmac_ioctl(BYTE procid, BYTE msgnr
                  ,BYTE param1, BYTE param2, BYTE param3, BYTE param4
                  ,BYTE param5, BYTE param6, FPTR pdata, BYTE inc)
{
  //unsigned long i;
  HMAC_QUEUES send_data;
  memset(&send_data, 0x00, sizeof(HMAC_QUEUES));
  send_data.PROCID = procid;
  send_data.MSG = msgnr;
  send_data.Parameter1 = param1;
  send_data.Parameter2 = param2;
  send_data.Parameter3 = param3;
  send_data.Parameter4 = param4;

  
  if (pdata != NULL)
  {
  	if(param5)	/* include HLI_Header pointer */
	    memcpy(send_data.G_PTR_buf, &pdata[sizeof( struct HLI_Header )], (((struct HLI_Header *)pdata)->length) - sizeof( struct HLI_Header ));
	  else /*	Not HLI_Header            param6 is length */
		  memcpy(send_data.G_PTR_buf, pdata, param6);
  
  } 
  send_data.CurrentInc = inc;

#ifdef LINUX
  ioctl(dect_drv_fd, DECT_DRV_TO_HMAC_MSG, &send_data);
#endif
#ifdef SUPERTASK
  dect_drv_ioctl(DECT_DRV_TO_HMAC_MSG, &send_data);
#endif
  if(send_data.MSG==MAC_QT_SET_RQ_ME){
	  	  Mmu_Free(pdata-1);
		  return;
  }

  if( (pdata!=NULL) && (send_data.MSG!= MAC_FU10_DATA_RQ))
	  Mmu_Free(pdata);
}




/* this function for debug infomatin and another information */
void wrtie_to_debug_info_ioctl(BYTE info_id, BYTE rw_indicator, BYTE inc, FPTR pdata)
{
	DECT_MODULE_DEBUG_INFO send_data;
//	unsigned long i;


	memset(&send_data, 0x00, sizeof(DECT_MODULE_DEBUG_INFO));


	send_data.debug_info_id = info_id;
	send_data.rw_indicator = rw_indicator;
	send_data.CurrentInc = inc;


	if (pdata != NULL)
	{
		memcpy(send_data.G_PTR_buf, pdata, G_PTR_MAX_DEBUG_COUNT);
		Mmu_Free(pdata);
	}


#ifdef LINUX
	ioctl(dect_drv_fd, DECT_DRV_DEBUG_INFO, &send_data);
#endif
#ifdef SUPERTASK
	dect_drv_ioctl(DECT_DRV_DEBUG_INFO,&send_data);
#endif

#ifdef KLOCWORK
      //Done already
#else
	  if(pdata!=NULL)
		Mmu_Free(pdata);	
#endif

}



int read_from_hmac_ioctl(HMAC_QUEUES *data)
{
	int ret;
#ifdef LINUX
	ret = ioctl(dect_drv_fd, DECT_DRV_FROM_HMAC_MSG, data);
#endif
#ifdef SUPERTASK
	ret = dect_drv_ioctl(DECT_DRV_FROM_HMAC_MSG,data);
#endif
	return ret;
}



int read_debug_from_module_ioctl(DECT_MODULE_DEBUG_INFO *data)
{
	int ret;
#ifdef LINUX
	ret = ioctl(dect_drv_fd, DECT_DRV_DEBUG_INFO_FROM_MODULE, data);
#endif
#ifdef SUPERTASK
	ret = dect_drv_ioctl(DECT_DRV_DEBUG_INFO_FROM_MODULE,data);
#endif
	return ret;
}

void get_pmid_from_hmac_ioctl(BYTE * data)
{
#ifdef LINUX
  ioctl(dect_drv_fd, DECT_DRV_GET_PMID, data);
#endif
#ifdef SUPERTASK
  dect_drv_ioctl(DECT_DRV_GET_PMID,data);
#endif
}

#ifdef CONFIG_REPEATER_SUPPORT
void get_rep_pmid_from_hmac_ioctl(BYTE * data)
{
#ifdef LINUX
  ioctl(dect_drv_fd, DECT_DRV_GET_REP_PMID, data);
#endif
#ifdef SUPERTASK
  dect_drv_ioctl(DECT_DRV_GET_REP_PMID,data);
#endif
}

void get_rep_num_from_hmac_ioctl(BYTE * data)
{
#ifdef LINUX
  ioctl(dect_drv_fd, DECT_DRV_GET_REP_NUM, data);
#endif
#ifdef SUPERTASK
  dect_drv_ioctl(DECT_DRV_GET_REP_NUM, data);
#endif
}
#endif

void get_enc_state_from_hmac_ioctl(BYTE * data)
{
#ifdef LINUX
  ioctl(dect_drv_fd, DECT_DRV_GET_ENC_STATE, data);
#endif
#ifdef SUPERTASK
  dect_drv_ioctl(DECT_DRV_GET_ENC_STATE,data);
#endif
}

void set_knl_state_to_hmac_ioctl(BYTE * data)
{
#ifdef LINUX
  ioctl(dect_drv_fd, DECT_DRV_SET_KNL_STATE, data);
#endif
#ifdef SUPERTASK
  dect_drv_ioctl(DECT_DRV_SET_KNL_STATE,data);
#endif
}

void trigger_cosic_driver_for_osc( BYTE *data )
{
#ifdef LINUX
  ioctl( dect_drv_fd, DECT_DRV_TRIGGER_COSIC_DRV, data );
#endif
#ifdef SUPERTASK
  dect_drv_ioctl(DECT_DRV_TRIGGER_COSIC_DRV,data);
#endif
}
