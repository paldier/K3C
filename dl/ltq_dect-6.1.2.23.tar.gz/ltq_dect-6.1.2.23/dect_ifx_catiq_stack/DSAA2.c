/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0       *
*                   (c) 2005 IFX / INTNIX. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  DSAA2.c                                                 *
*     Date       :  28 Mar, 2013                                            *
*     Contents   :  Contents : Library for Dect standard authentication algorithm 2       *                                                                                                                                                                                                                                                               *
*     Hardware   :  IFX 87xx                                                *
*                                                                           *
*****************************************************************************
*/
   /* ========                                                             */
   /* Includes                                                             */
   /* ========                                                             */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "DEFINE.H"
#ifdef ULE_SUPPORT
#include "DSAA2.h"

   /* ==============                                                       */
   /* Local typedefs                                                       */
   /* ==============                                                       */
#define WPOLY   0x011b
#define BPOLY     0x1b
#define DPOLY   0x008d

#define f1(x)   (x)
#define f2(x)   ((x << 1) ^ ((unsigned short)((x >> 7) & 1) * WPOLY))

#define f3(x)   (f2(x) ^ x)

#define sb_data(w) {    /* S Box data values */                            \
   w(0x63), w(0x7c), w(0x77), w(0x7b), w(0xf2), w(0x6b), w(0x6f), w(0xc5),\
   w(0x30), w(0x01), w(0x67), w(0x2b), w(0xfe), w(0xd7), w(0xab), w(0x76),\
   w(0xca), w(0x82), w(0xc9), w(0x7d), w(0xfa), w(0x59), w(0x47), w(0xf0),\
   w(0xad), w(0xd4), w(0xa2), w(0xaf), w(0x9c), w(0xa4), w(0x72), w(0xc0),\
   w(0xb7), w(0xfd), w(0x93), w(0x26), w(0x36), w(0x3f), w(0xf7), w(0xcc),\
   w(0x34), w(0xa5), w(0xe5), w(0xf1), w(0x71), w(0xd8), w(0x31), w(0x15),\
   w(0x04), w(0xc7), w(0x23), w(0xc3), w(0x18), w(0x96), w(0x05), w(0x9a),\
   w(0x07), w(0x12), w(0x80), w(0xe2), w(0xeb), w(0x27), w(0xb2), w(0x75),\
   w(0x09), w(0x83), w(0x2c), w(0x1a), w(0x1b), w(0x6e), w(0x5a), w(0xa0),\
   w(0x52), w(0x3b), w(0xd6), w(0xb3), w(0x29), w(0xe3), w(0x2f), w(0x84),\
   w(0x53), w(0xd1), w(0x00), w(0xed), w(0x20), w(0xfc), w(0xb1), w(0x5b),\
   w(0x6a), w(0xcb), w(0xbe), w(0x39), w(0x4a), w(0x4c), w(0x58), w(0xcf),\
   w(0xd0), w(0xef), w(0xaa), w(0xfb), w(0x43), w(0x4d), w(0x33), w(0x85),\
   w(0x45), w(0xf9), w(0x02), w(0x7f), w(0x50), w(0x3c), w(0x9f), w(0xa8),\
   w(0x51), w(0xa3), w(0x40), w(0x8f), w(0x92), w(0x9d), w(0x38), w(0xf5),\
   w(0xbc), w(0xb6), w(0xda), w(0x21), w(0x10), w(0xff), w(0xf3), w(0xd2),\
   w(0xcd), w(0x0c), w(0x13), w(0xec), w(0x5f), w(0x97), w(0x44), w(0x17),\
   w(0xc4), w(0xa7), w(0x7e), w(0x3d), w(0x64), w(0x5d), w(0x19), w(0x73),\
   w(0x60), w(0x81), w(0x4f), w(0xdc), w(0x22), w(0x2a), w(0x90), w(0x88),\
   w(0x46), w(0xee), w(0xb8), w(0x14), w(0xde), w(0x5e), w(0x0b), w(0xdb),\
   w(0xe0), w(0x32), w(0x3a), w(0x0a), w(0x49), w(0x06), w(0x24), w(0x5c),\
   w(0xc2), w(0xd3), w(0xac), w(0x62), w(0x91), w(0x95), w(0xe4), w(0x79),\
   w(0xe7), w(0xc8), w(0x37), w(0x6d), w(0x8d), w(0xd5), w(0x4e), w(0xa9),\
   w(0x6c), w(0x56), w(0xf4), w(0xea), w(0x65), w(0x7a), w(0xae), w(0x08),\
   w(0xba), w(0x78), w(0x25), w(0x2e), w(0x1c), w(0xa6), w(0xb4), w(0xc6),\
   w(0xe8), w(0xdd), w(0x74), w(0x1f), w(0x4b), w(0xbd), w(0x8b), w(0x8a),\
   w(0x70), w(0x3e), w(0xb5), w(0x66), w(0x48), w(0x03), w(0xf6), w(0x0e),\
   w(0x61), w(0x35), w(0x57), w(0xb9), w(0x86), w(0xc1), w(0x1d), w(0x9e),\
   w(0xe1), w(0xf8), w(0x98), w(0x11), w(0x69), w(0xd9), w(0x8e), w(0x94),\
   w(0x9b), w(0x1e), w(0x87), w(0xe9), w(0xce), w(0x55), w(0x28), w(0xdf),\
   w(0x8c), w(0xa1), w(0x89), w(0x0d), w(0xbf), w(0xe6), w(0x42), w(0x68),\
   w(0x41), w(0x99), w(0x2d), w(0x0f), w(0xb0), w(0x54), w(0xbb), w(0x16) }

static const unsigned char sbox2[256]  =  sb_data(f1);

static const unsigned char gfm2_sbox[256] = sb_data(f2);
static const unsigned char gfm3_sbox[256] = sb_data(f3);

#define s_box(x)     sbox2[(x)]
#define gfm2_sb(x)   gfm2_sbox[(x)]
#define gfm3_sb(x)   gfm3_sbox[(x)]

#define block_copy_nn(d, s, l) copy_block_nn(d, s, l)
#define block_copy(d, s)    copy_block(d, s)

   /* ===============                                                      */
   /* Local variables                                                      */
   /* ===============                                                      */

   /* ==========================                                           */
   /* Local function declaration                                           */
   /* ==========================                                           */

static void copy_block( void *d, const void *s )
{
   ((unsigned char*)d)[ 0] = ((unsigned char*)s)[ 0];
   ((unsigned char*)d)[ 1] = ((unsigned char*)s)[ 1];
   ((unsigned char*)d)[ 2] = ((unsigned char*)s)[ 2];
   ((unsigned char*)d)[ 3] = ((unsigned char*)s)[ 3];
   ((unsigned char*)d)[ 4] = ((unsigned char*)s)[ 4];
   ((unsigned char*)d)[ 5] = ((unsigned char*)s)[ 5];
   ((unsigned char*)d)[ 6] = ((unsigned char*)s)[ 6];
   ((unsigned char*)d)[ 7] = ((unsigned char*)s)[ 7];
   ((unsigned char*)d)[ 8] = ((unsigned char*)s)[ 8];
   ((unsigned char*)d)[ 9] = ((unsigned char*)s)[ 9];
   ((unsigned char*)d)[10] = ((unsigned char*)s)[10];
   ((unsigned char*)d)[11] = ((unsigned char*)s)[11];
   ((unsigned char*)d)[12] = ((unsigned char*)s)[12];
   ((unsigned char*)d)[13] = ((unsigned char*)s)[13];
   ((unsigned char*)d)[14] = ((unsigned char*)s)[14];
   ((unsigned char*)d)[15] = ((unsigned char*)s)[15];
}

static void copy_block_nn( void * d, const void *s, unsigned char nn )
{
   unsigned char i;

   for (i=0; i<nn; i++) {
      ((unsigned char*)d)[i] = ((unsigned char*)s)[i];
   }
   //while( nn-- )
   //   *((unsigned char*)d)++ = *((unsigned char*)s)++;
}

static void xor_block( void *d, const void *s )
{
   ((unsigned char*)d)[ 0] ^= ((unsigned char*)s)[ 0];
   ((unsigned char*)d)[ 1] ^= ((unsigned char*)s)[ 1];
   ((unsigned char*)d)[ 2] ^= ((unsigned char*)s)[ 2];
   ((unsigned char*)d)[ 3] ^= ((unsigned char*)s)[ 3];
   ((unsigned char*)d)[ 4] ^= ((unsigned char*)s)[ 4];
   ((unsigned char*)d)[ 5] ^= ((unsigned char*)s)[ 5];
   ((unsigned char*)d)[ 6] ^= ((unsigned char*)s)[ 6];
   ((unsigned char*)d)[ 7] ^= ((unsigned char*)s)[ 7];
   ((unsigned char*)d)[ 8] ^= ((unsigned char*)s)[ 8];
   ((unsigned char*)d)[ 9] ^= ((unsigned char*)s)[ 9];
   ((unsigned char*)d)[10] ^= ((unsigned char*)s)[10];
   ((unsigned char*)d)[11] ^= ((unsigned char*)s)[11];
   ((unsigned char*)d)[12] ^= ((unsigned char*)s)[12];
   ((unsigned char*)d)[13] ^= ((unsigned char*)s)[13];
   ((unsigned char*)d)[14] ^= ((unsigned char*)s)[14];
   ((unsigned char*)d)[15] ^= ((unsigned char*)s)[15];
}

static void copy_and_key( void *d, const void *s, const void *k )
{
   ((unsigned char*)d)[ 0] = ((unsigned char*)s)[ 0] ^ ((unsigned char*)k)[ 0];
   ((unsigned char*)d)[ 1] = ((unsigned char*)s)[ 1] ^ ((unsigned char*)k)[ 1];
   ((unsigned char*)d)[ 2] = ((unsigned char*)s)[ 2] ^ ((unsigned char*)k)[ 2];
   ((unsigned char*)d)[ 3] = ((unsigned char*)s)[ 3] ^ ((unsigned char*)k)[ 3];
   ((unsigned char*)d)[ 4] = ((unsigned char*)s)[ 4] ^ ((unsigned char*)k)[ 4];
   ((unsigned char*)d)[ 5] = ((unsigned char*)s)[ 5] ^ ((unsigned char*)k)[ 5];
   ((unsigned char*)d)[ 6] = ((unsigned char*)s)[ 6] ^ ((unsigned char*)k)[ 6];
   ((unsigned char*)d)[ 7] = ((unsigned char*)s)[ 7] ^ ((unsigned char*)k)[ 7];
   ((unsigned char*)d)[ 8] = ((unsigned char*)s)[ 8] ^ ((unsigned char*)k)[ 8];
   ((unsigned char*)d)[ 9] = ((unsigned char*)s)[ 9] ^ ((unsigned char*)k)[ 9];
   ((unsigned char*)d)[10] = ((unsigned char*)s)[10] ^ ((unsigned char*)k)[10];
   ((unsigned char*)d)[11] = ((unsigned char*)s)[11] ^ ((unsigned char*)k)[11];
   ((unsigned char*)d)[12] = ((unsigned char*)s)[12] ^ ((unsigned char*)k)[12];
   ((unsigned char*)d)[13] = ((unsigned char*)s)[13] ^ ((unsigned char*)k)[13];
   ((unsigned char*)d)[14] = ((unsigned char*)s)[14] ^ ((unsigned char*)k)[14];
   ((unsigned char*)d)[15] = ((unsigned char*)s)[15] ^ ((unsigned char*)k)[15];
}

static void add_round_key( unsigned char d[N_BLOCK], const unsigned char k[N_BLOCK] )
{
   xor_block(d, k);
}

static void shift_sub_rows( unsigned char st[N_BLOCK] )
{
   unsigned char tt;

   st[ 0] = s_box(st[ 0]); st[ 4] = s_box(st[ 4]);
   st[ 8] = s_box(st[ 8]); st[12] = s_box(st[12]);

   tt = st[1]; st[ 1] = s_box(st[ 5]); st[ 5] = s_box(st[ 9]);
   st[ 9] = s_box(st[13]); st[13] = s_box( tt );

   tt = st[2]; st[ 2] = s_box(st[10]); st[10] = s_box( tt );
   tt = st[6]; st[ 6] = s_box(st[14]); st[14] = s_box( tt );

   tt = st[15]; st[15] = s_box(st[11]); st[11] = s_box(st[ 7]);
   st[ 7] = s_box(st[ 3]); st[ 3] = s_box( tt );
}

static void mix_sub_columns( unsigned char dt[N_BLOCK] )
{
   unsigned char st[N_BLOCK];
   block_copy(st, dt);
   dt[ 0] = gfm2_sb(st[0]) ^ gfm3_sb(st[5]) ^ s_box(st[10]) ^ s_box(st[15]);
   dt[ 1] = s_box(st[0]) ^ gfm2_sb(st[5]) ^ gfm3_sb(st[10]) ^ s_box(st[15]);
   dt[ 2] = s_box(st[0]) ^ s_box(st[5]) ^ gfm2_sb(st[10]) ^ gfm3_sb(st[15]);
   dt[ 3] = gfm3_sb(st[0]) ^ s_box(st[5]) ^ s_box(st[10]) ^ gfm2_sb(st[15]);

   dt[ 4] = gfm2_sb(st[4]) ^ gfm3_sb(st[9]) ^ s_box(st[14]) ^ s_box(st[3]);
   dt[ 5] = s_box(st[4]) ^ gfm2_sb(st[9]) ^ gfm3_sb(st[14]) ^ s_box(st[3]);
   dt[ 6] = s_box(st[4]) ^ s_box(st[9]) ^ gfm2_sb(st[14]) ^ gfm3_sb(st[3]);
   dt[ 7] = gfm3_sb(st[4]) ^ s_box(st[9]) ^ s_box(st[14]) ^ gfm2_sb(st[3]);

   dt[ 8] = gfm2_sb(st[8]) ^ gfm3_sb(st[13]) ^ s_box(st[2]) ^ s_box(st[7]);
   dt[ 9] = s_box(st[8]) ^ gfm2_sb(st[13]) ^ gfm3_sb(st[2]) ^ s_box(st[7]);
   dt[10] = s_box(st[8]) ^ s_box(st[13]) ^ gfm2_sb(st[2]) ^ gfm3_sb(st[7]);
   dt[11] = gfm3_sb(st[8]) ^ s_box(st[13]) ^ s_box(st[2]) ^ gfm2_sb(st[7]);

   dt[12] = gfm2_sb(st[12]) ^ gfm3_sb(st[1]) ^ s_box(st[6]) ^ s_box(st[11]);
   dt[13] = s_box(st[12]) ^ gfm2_sb(st[1]) ^ gfm3_sb(st[6]) ^ s_box(st[11]);
   dt[14] = s_box(st[12]) ^ s_box(st[1]) ^ gfm2_sb(st[6]) ^ gfm3_sb(st[11]);
   dt[15] = gfm3_sb(st[12]) ^ s_box(st[1]) ^ s_box(st[6]) ^ gfm2_sb(st[11]);
}

/*  Set the cipher key for the pre-keyed version */
unsigned char aes_set_key( unsigned char *key, unsigned char keylen, aes_context ctx[1] )
{
   unsigned char cc, rc, hi;

   switch( keylen ) {
      case 16:
      case 128:
         keylen = 16;
         break;
      case 24:
      case 192:
         keylen = 24;
         break;
      default:
         ctx->rnd = 0;
         return 0;
   }
   block_copy_nn(ctx->ksch, key, keylen);
   hi = (keylen + 28) << 2;
   ctx->rnd = (hi >> 4) - 1;
   for( cc = keylen, rc = 1; cc < hi; cc += 4 )  {
      unsigned char tt, t0, t1, t2, t3;

      t0 = ctx->ksch[cc - 4];
      t1 = ctx->ksch[cc - 3];
      t2 = ctx->ksch[cc - 2];
      t3 = ctx->ksch[cc - 1];
      if( cc % keylen == 0 ) {
         tt = t0;
         t0 = s_box(t1) ^ rc;
         t1 = s_box(t2);
         t2 = s_box(t3);
         t3 = s_box(tt);
         rc = f2(rc);
      } else if( keylen > 24 && cc % keylen == 16 ) {
         t0 = s_box(t0);
         t1 = s_box(t1);
         t2 = s_box(t2);
         t3 = s_box(t3);
      }
      tt = cc - keylen;
      ctx->ksch[cc + 0] = ctx->ksch[tt + 0] ^ t0;
      ctx->ksch[cc + 1] = ctx->ksch[tt + 1] ^ t1;
      ctx->ksch[cc + 2] = ctx->ksch[tt + 2] ^ t2;
      ctx->ksch[cc + 3] = ctx->ksch[tt + 3] ^ t3;
   }
   return 1;
}

/*  Encrypt a single block of 16 bytes */
unsigned char aes_encrypt( unsigned char *in, unsigned char *out, aes_context ctx[1] )
{
   if( ctx->rnd ) {
      unsigned char s1[N_BLOCK], r;
      copy_and_key( s1, in, ctx->ksch );

      for( r = 1 ; r < ctx->rnd ; ++r ) {
         mix_sub_columns( s1 );
         add_round_key( s1, ctx->ksch + r * N_BLOCK);
      }
      shift_sub_rows( s1 );
      copy_and_key( out, s1, ctx->ksch + r * N_BLOCK );
   }
   else
      return 0;
   return 1;
}

void Dsaa2_1( unsigned char *d1, unsigned char *d2, unsigned char *d3, unsigned char * e )
{
   aes_context ctx[1];
   unsigned char p1[N_BLOCK];
   unsigned char p2[N_BLOCK];
   unsigned char i;

   aes_set_key(d1, N_BLOCK, ctx);
   for (i=0; i<8; i++) {
      p1[i] = d2[i];
   }
   for (i=0; i<8; i++) {
      p1[8+i] = d3[i];
   }
   aes_encrypt(p1,p2,ctx);
   aes_encrypt(p2,e,ctx);
}

void Dsaa2_2( unsigned char *d1, unsigned char *d2, unsigned char *d3, unsigned char * e1, unsigned char * e2 )
{
   aes_context ctx[1];
   unsigned char p1[N_BLOCK];
   unsigned char p2[N_BLOCK];
   unsigned char i;

   aes_set_key(d1, N_BLOCK, ctx);
   for (i=0; i<8; i++) {
      p1[i] = d2[i];
   }
   for (i=0; i<8; i++) {
      p1[8+i] = d3[i];
   }
   aes_encrypt(p1,p2,ctx);
   for (i=0; i<4; i++) {
      e1[i] = p2[i];
   }
   p2[15] ^= 0x01;
   aes_encrypt(p2,e2,ctx);
}
#endif
