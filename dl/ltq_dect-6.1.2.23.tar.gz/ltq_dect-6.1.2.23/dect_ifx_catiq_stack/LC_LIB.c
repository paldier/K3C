/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
*                   (c) 2005 IFX / INTNIX. All rights reserved.               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  LC_LIB.C                                                *
*     Date       :  18 Nov, 2005                                       *
*     Contents   :  Contents : Library for Process 'LOWER FUNCTIONS ( LC )' *
*     Hardware   :  IFX 87xx                                               *
*                                                                           *
*****************************************************************************
*/
   /* ========                                                             */
   /* Includes                                                             */
   /* ========                                                            */
#include <stdio.h>
#include "DEFINE.H"

#include    "SYSDEF.H"
#include    "TYPEDEF.H"
#include    "CONF_DEF.H"
#include    "ERROR.H"
#ifdef FT
#include "FGLOBAL.H"
//#include "FMAC_LIB.H"
//#include "FLLME.H"
#endif

#include    "FDEF.H"
#include    "KNL_SYSTEM.H"
#include    "MMU.H"
#include    "LAP_LIB.H"

#include    "LC_LIB.H"

   /* ==========================                                           */
   /* Local macros & definitions                                           */
   /* ==========================                                           */
#define  RECEIVER_IDLE     1
#define  RECEIVING_DATA    2
#define printf(...)
#if 0
#ifdef printf
#undef printf
#endif
#endif

   /* ==============                                                       */
   /* Local typedefs                                                       */
   /* ==============                                                       */
#ifndef CONFIG_REPEATER_SUPPORT
typedef struct
{
   FPTR  Cframe_tx_ptr;                /*    start of Cs data frame        */
   FPTR  Cframe_rx_ptr;                /*    start of received Cs frame    */
   FPTR  current_tx_ptr;               /*    current transmit data pointer */
   FPTR  current_rec_ptr;              /*    current receive data pointer  */

   BYTE  txCframe_length;              /*    length of transmit data frame */
   BYTE  rxCframe_length;              /*    length of received data frame */
   BYTE  received_Cs_octets;           /*    current number of received    */
                                       /*    bytes                         */
   BYTE  Ct_Receive_State;
}
CS_CHANNEL;
#endif

   /* ===============                                                      */
   /* Local variables                                                      */
   /* ===============                                                      */
LOCAL XDATA CS_CHANNEL CS_ctrl   [ MAX_LINK ];
LOCAL XDATA WORD       LSIG_Value[ MAX_LINK ];
#ifdef CONFIG_REPEATER_SUPPORT
EXPORT XDATA CS_CHANNEL RCS_ctrl   [ MAX_LINK ];
EXPORT XDATA WORD       RLSIG_Value[ MAX_LINK ];
#endif
   /* ===========================                                          */
   /* Local function declarations                                          */
   /* ===========================                                          */
LOCAL BYTE Determine_Frame_Typ ( BYTE );

LOCAL FPTR Fill_Checksum_Field ( BYTE, FPTR, BYTE );
LOCAL BIT  Check_Checksum_Field( BYTE, FPTR, BYTE );

   /* ===========================                                          */
   /* Global function definitions                                          */
   /* ===========================                                          */

extern void get_pmid_from_hmac_ioctl(BYTE * data);
#ifdef CONFIG_REPEATER_SUPPORT
extern void get_rep_pmid_from_hmac_ioctl(BYTE * data);
#endif
EXPORT void
Load_LSIG( BYTE cid )
{
  BYTE buffer[4];
                                       /* Provision of link signature      */
                                       /* (LSIG)                           */
                                       /* -------------------------------- */
                                       /* According to ETS 300 175-4 /     */
                                       /* 10.3.1 the link signature is     */
                                       /* derivated from the MAC layer PT  */
                                       /* identitiy as follows:            */
                                       /*                                  */
                                       /* a) if the PT does not have an    */
                                       /* assigned PMID or the link is     */
                                       /* associated to a connectionless   */
                                       /* MAC service:                     */
                                       /*    LSIG = 0x0000                 */
                                       /*                                  */
                                       /* b) if the PT has an assigned     */
                                       /* PMID for the relevant FT and the */
                                       /* link is associated to a          */
                                       /* connection oritented MAC         */
                                       /* service:                         */
                                       /*    LSIG = lower 16 bits of PMID  */
  buffer[0] = cid;    //cid
  buffer[1] = 0;      //first pmid
  buffer[2] = 0;      //second pmid
  buffer[3] = 0;      //third pmid

  get_pmid_from_hmac_ioctl(buffer);
//  if(( buffer[2] & 0x0F ) == 0x0E )		// check first byte
  if(( buffer[1] & 0x0F ) == 0x0E )		// check first pmid
  {
                                     /* The PMID is of type arbitrary    */
                                     /* -> LSIG = 0x0000                 */
                                     /* -------------------------------- */
    LSIG_Value[ cid ] = 0;
  }
  else
  {
                                     /* The PMID is of type assigned     */
                                     /* -> LSIG == PMID                  */
                                     /* -------------------------------- */
    LSIG_Value[ cid ]  = 0;
#if 0
    buffer[0] = cid;    //cid
    buffer[1] = 1;      //pos
    buffer[2] = 0;      //read_data
    get_pmid_from_hmac_ioctl(buffer);
#endif
    LSIG_Value[ cid ]  = buffer[2] << 8;	// set second byte

#if 0
    buffer[0] = cid;    //cid
    buffer[1] = 2;      //pos
    buffer[2] = 0;      //read_data
    get_pmid_from_hmac_ioctl(buffer);
#endif

    LSIG_Value[ cid ] |= buffer[3];			// set third byte

  }
}

#ifdef CONFIG_REPEATER_SUPPORT
EXPORT void
Rep_Load_LSIG( BYTE cid, BYTE idx )
{
  BYTE buffer[5];
  
  buffer[0] = cid;    // cid
  buffer[1] = idx;    // index
  buffer[2] = 0;      // first pmid
  buffer[3] = 0;      // second pmid
  buffer[4] = 0;      // third pmid

  get_rep_pmid_from_hmac_ioctl(buffer);
  if(( buffer[1] & 0x0F ) == 0x0E )		// check first pmid
  {
                                     /* The PMID is of type arbitrary    */
                                     /* -> LSIG = 0x0000                 */
                                     /* -------------------------------- */
    RLSIG_Value[ cid ] = 0;
  }
  else
  {
                                     /* The PMID is of type assigned     */
                                     /* -> LSIG == PMID                  */
                                     /* -------------------------------- */
    RLSIG_Value[ cid ]  = 0;
    RLSIG_Value[ cid ]  = buffer[3] << 8;    // set second byte
    RLSIG_Value[ cid ] |= buffer[4];         // set third byte

  }
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Decode_Received_Frame                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  This function is called to decode the received message    *
*                 fragment from the MAC-Layer. The message is mapped to     *
*                 the according Layer 2 Message types.                      *
*   Parms      :  cid             : CID value of the LC process             *
*             lcn             : LCN value of the LC process          *
*                 frame_ptr       : Pointer to the received frame           *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  !! NOTE: According to spec. ETS 300 444 (GAP) only the    *
*                 class A message service is supported. Therefore only      *
*                 the I-Frame and RR-Frame messages are processed .         *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Decode_Received_Frame( BYTE cid, BYTE lcn, FPTR frame_ptr )
{
   BYTE frame_length, Li;
   BYTE min_frame_length, CS_fill_field_length;
#ifdef DECT_NG
   BYTE  c_r_bit_identifier, p_f_bit_identifier;
   BYTE  NLF_bit;
#else
   BIT  c_r_bit_identifier, p_f_bit_identifier;
   BIT  NLF_bit;
#endif
   BYTE ctrl;
   BYTE size_HLI_Header;
   //BYTE frame_len;
#ifdef KLOCWORK
   FPTR temp_ptr;
#endif

   size_HLI_Header = sizeof(struct HLI_Header );

                                       /* Check of DLC-Checksum            */
                                       /* =====================            */

                                       /* If the checksum is not correct   */
                                       /* the frame is discarded !         */
                                       /* Ref.: ETS 300 175-4, 7.9         */

                                       /* Get the DLC frame length !       */
   frame_length = ((( struct HLI_Header * ) frame_ptr ) -> length ) -
                      size_HLI_Header;

   ASSERT( frame_length >= MINIMUM_FLEN, "No DLC-Frame delivered !" );

   if( ! Check_Checksum_Field( cid, frame_ptr, frame_length ))
   {
     	printf("[LC] LC_CRC_ERROR 1\n");

#if 0
		for(frame_len=0; frame_len < (frame_length + size_HLI_Header);frame_len++) {
         if (frame_len != 0 && (frame_len % 32) == 0) {
            printf("\n");
         }
			printf(" %02x", frame_ptr[frame_len]);
      }
		printf("\n");
#endif
      Mmu_Free( frame_ptr );
      return;
   }
                                      /* Setting of all control elements  */
                                      /* ===============================  */

#ifdef DECT_NG
                                       /* Determine NLF_bit                */
   NLF_bit = ( frame_ptr[ size_HLI_Header ]  & 0x80);// ? 1:0;

                                       /* Determine C_R_Bit                */
   c_r_bit_identifier = (frame_ptr[ size_HLI_Header ] & 0x02);// ? 1:0;

                                       /* Determine P_F_Bit                */
   p_f_bit_identifier = (frame_ptr[ 1 + size_HLI_Header ] & 0x10);// ? 1:0;
#else
NLF_bit = ( frame_ptr[ size_HLI_Header ]  & 0x80) ? 1:0;

									/* Determine C_R_Bit				*/
c_r_bit_identifier = (frame_ptr[ size_HLI_Header ] & 0x02) ? 1:0;

									/* Determine P_F_Bit				*/
p_f_bit_identifier = (frame_ptr[ 1 + size_HLI_Header ] & 0x10) ? 1:0;

#endif



                                       /* Determine CTRL-field             */
   ctrl = Determine_Frame_Typ( frame_ptr[ 1 + size_HLI_Header ] );

                                       /* Get NTW Layer 3 frame length !   */
   Li = ( frame_ptr[ 2 + size_HLI_Header ] >> 2 ) & 0x3F;

                                       /* Set min. DLC frame length !      */
   min_frame_length     = Li + CS_HEADER_LENGTH + CHECKSUM_FIELD_LENGTH;

                                       /* determine CS_fill_field_length   */
   CS_fill_field_length = ( CS_FLEN_QUANT -
                          ( min_frame_length % CS_FLEN_QUANT ))
                          % CS_FLEN_QUANT;

                                       /* Check of Logical Link Number     */
                                       /* ============================     */

                                       /* CLASS A operation -> LLN = '1'   */
                                       /* If the LLN value is not correct  */
                                       /* the frame is discarded !         */
                                       /* Ref.: ETS 300 175-4, 7.3.5       */

                                       /* Exception: if a request for      */
                                       /* CLASS B operation is refused,    */
                                       /* the I-frame requesting CLASS B   */
                                       /* operation may be treated as      */
                                       /* though is was a CLASS A frame.   */
                                       /* Ref.: ETS 300 175-4, 9.2.2.1     */
#ifdef DECT_NG
   if( NLF_bit == 0x80 && ctrl == I_TYP )
#else
   if( NLF_bit == TRUE && ctrl == I_TYP )
#endif
   {
                                       /* I-Frame with NLF set.            */
                                       /* LLN value is not checked, CLASS  */
                                       /* B is treated as CLASS A frame !  */
		printf("\n I-frame NLF set \n");
   }
   else
   {
                                       /* For all other frames the LLN     */
                                       /* value is checked. Only a LLN     */
                                       /* value of '1' is allowed !        */
      if(( frame_ptr[ size_HLI_Header ] & 0x70 ) != 0x10 )
      {

      	printf("[LC] LC_CRC_ERROR 2\n" );
         Mmu_Free( frame_ptr );
         return;
      }
   }
                                       /* Check correct C_R_Bit setting    */
                                       /* =============================    */

                                       /* I-Frame always a Command !       */
#ifdef DECT_NG
   if( ctrl == I_TYP && c_r_bit_identifier != COMMAND_RC )
#else
   if( ctrl == I_TYP && c_r_bit_identifier != COMMAND )
#endif
   {
                              /* P1: Logical Connection Number    */
      KNL_SENDTASK_WP_INC( LAP, LAP_PRO_ERR_LC, lcn, 0, 0, 0, cid );
	   DECT_DEBUG_USER_LC_DATA("[LC] LC_CRC_ERROR 3\n" );
	   printf("[LC] LC_CRC_ERROR 3\n" );

      Mmu_Free( frame_ptr );
      return;
   }
                                       /* RR-Frame always a Response !     */
#ifdef DECT_NG
   if( ctrl == RR_TYP && c_r_bit_identifier != RESPONSE_RC )
#else
   if( ctrl == RR_TYP && c_r_bit_identifier != RESPONSE )
#endif
   {
                              /* P1: Logical Connection Number    */
      KNL_SENDTASK_WP_INC( LAP, LAP_PRO_ERR_LC, lcn, 0, 0, 0, cid );
      Mmu_Free( frame_ptr );
	   printf("[LC] LC_CRC_ERROR 4\n" );
      return;
   }
                                       /* Check correct P_F_Bit setting    */
                                       /* =============================    */

                                       /* P/F-Bit is always '0', Class A   */
   if( p_f_bit_identifier != 0 )
   {
                              /* P1: Logical Connection Number    */
      KNL_SENDTASK_WP_INC( LAP, LAP_PRO_ERR_LC, lcn, 0, 0, 0, cid );
      Mmu_Free( frame_ptr );
	   printf("[LC] LC_CRC_ERROR 5\n" );
      return;
   }
                                       /* Discard Fill - & Checksum field  */
                                       /* ===============================  */

                                       /* The Fill - and Checksum field is */
                                       /* not used anymore and can be      */
                                       /* discarded in order to reduce the */
                                       /* MMU load !                       */

                                       /* Adjust new frame size !          */
   frame_length -= CS_fill_field_length;
   frame_length -= CHECKSUM_FIELD_LENGTH;
   #ifdef KLOCWORK
   temp_ptr     = Mmu_Realloc( frame_ptr,
                             frame_length + size_HLI_Header);
   if(temp_ptr == NULL) {
      Mmu_Free( frame_ptr );
      return;
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr     = Mmu_Realloc( frame_ptr,
                                frame_length + size_HLI_Header);

   #endif
                                       /* Set length in HLI_Header         */
   (( struct HLI_Header * ) frame_ptr ) -> length =
      frame_length + size_HLI_Header;

	printf("ctrl= %x, NLF_bit=%x \n",ctrl,NLF_bit);

   switch ( ctrl ) {

      case RR_TYP :
                                       /* Send RR-Frame to LAP process     */
#ifdef DECT_NG
            if( NLF_bit == 0x80 )
#else
            if ( NLF_bit )
#endif
            {
                              /* P1: Logical Connection Number    */
               KNL_SENDTASK_NP_WP_INC( LAP,
                                   LAP_RR_FRAME_NLF_LC,
                                   frame_ptr,
                           lcn,
                           0,
                           0,
                           0,
                                   cid );
            }
            else
            {
                              /* P1: Logical Connection Number    */
               KNL_SENDTASK_NP_WP_INC( LAP,
                                   LAP_RR_FRAME_LC,
                                   frame_ptr,
                           lcn,
                           0,
                           0,
                           0,
                           cid );
            }
            return;

      case I_TYP :

                                       /* Send I-Frame to LAP process      */
#ifdef DECT_NG
            if( NLF_bit == 0x80 )
#else
            if ( NLF_bit )
#endif
            {
                              /* P1: Logical Connection Number    */
               KNL_SENDTASK_NP_WP_INC( LAP,
                                   LAP_I_FRAME_NLF_LC,
                                   frame_ptr,
                           lcn,
                           0,
                           0,
                           0,
                                   cid );
            }
            else
            {
                              /* P1: Logical Connection Number    */
               KNL_SENDTASK_NP_WP_INC( LAP,
                                   LAP_I_FRAME_LC,
                                   frame_ptr,
                           lcn,
                           0,
                           0,
                           0,
                                   cid );
            }
            return;

      default:
                                       /* Unkown Control field             */
                              /* P1: Logical Connection Number    */
            KNL_SENDTASK_WP_INC( LAP, LAP_PRO_ERR_LC, lcn, 0, 0, 0, cid );
            Mmu_Free( frame_ptr );
            return;
   }
}

#ifdef CONFIG_REPEATER_SUPPORT
EXPORT void
Rep_Decode_Received_Frame( BYTE cid, BYTE lcn, FPTR frame_ptr )
{
   BYTE frame_length, Li;
   BYTE min_frame_length, CS_fill_field_length;
   BYTE  c_r_bit_identifier, p_f_bit_identifier;
   BYTE  NLF_bit;
   BYTE ctrl;
   BYTE size_HLI_Header;
   //BYTE frame_len;
   #ifdef KLOCWORK
   FPTR temp_ptr;
   #endif


   size_HLI_Header = sizeof(struct HLI_Header );

   frame_length = ((( struct HLI_Header * ) frame_ptr ) -> length ) -
                      size_HLI_Header;

   ASSERT( frame_length >= MINIMUM_FLEN, "No DLC-Frame delivered !" );

   if( ! Check_Checksum_Field( cid, frame_ptr, frame_length ))
   {
     	printf("[LC] LC_CRC_ERROR 1\n");
      Mmu_Free( frame_ptr );
      return;
   }
                                      /* Setting of all control elements  */
                                      /* ===============================  */
                                       /* Determine NLF_bit                */
   NLF_bit = ( frame_ptr[ size_HLI_Header ]  & 0x80);// ? 1:0;

                                       /* Determine C_R_Bit                */
   c_r_bit_identifier = (frame_ptr[ size_HLI_Header ] & 0x02);// ? 1:0;

                                       /* Determine P_F_Bit                */
   p_f_bit_identifier = (frame_ptr[ 1 + size_HLI_Header ] & 0x10);// ? 1:0;
                                       /* Determine CTRL-field             */
   ctrl = Determine_Frame_Typ( frame_ptr[ 1 + size_HLI_Header ] );

                                       /* Get NTW Layer 3 frame length !   */
   Li = ( frame_ptr[ 2 + size_HLI_Header ] >> 2 ) & 0x3F;

                                       /* Set min. DLC frame length !      */
   min_frame_length     = Li + CS_HEADER_LENGTH + CHECKSUM_FIELD_LENGTH;

                                       /* determine CS_fill_field_length   */
   CS_fill_field_length = ( CS_FLEN_QUANT -
                          ( min_frame_length % CS_FLEN_QUANT ))
                          % CS_FLEN_QUANT;

   if( NLF_bit == 0x80 && ctrl == I_TYP )
   {
		printf("\n I-frame NLF set \n");
   }
   else
   {
      if(( frame_ptr[ size_HLI_Header ] & 0x70 ) != 0x10 )
      {
      	printf("[LC] LC_CRC_ERROR 2\n" );
         Mmu_Free( frame_ptr );
         return;
      }
   }

   if( ctrl == I_TYP && c_r_bit_identifier != COMMAND_RC )
   {
                              /* P1: Logical Connection Number    */
      KNL_SENDTASK_WP_INC( LAP_REP, LAP_PRO_ERR_LC, lcn, 0, 0, 0, cid );
	   DECT_DEBUG_USER_LC_DATA("[LC] LC_CRC_ERROR 3\n" );
	   printf("[LC] LC_CRC_ERROR 3\n" );

      Mmu_Free( frame_ptr );
      return;
   }
                                       /* RR-Frame always a Response !     */
   if( ctrl == RR_TYP && c_r_bit_identifier != RESPONSE_RC )
   {
                              /* P1: Logical Connection Number    */
      KNL_SENDTASK_WP_INC( LAP_REP, LAP_PRO_ERR_LC, lcn, 0, 0, 0, cid );
      Mmu_Free( frame_ptr );
	   printf("[LC] LC_CRC_ERROR 4\n" );
      return;
   }
                                       /* Check correct P_F_Bit setting    */
                                       /* =============================    */

                                       /* P/F-Bit is always '0', Class A   */
   if( p_f_bit_identifier != 0 )
   {
                              /* P1: Logical Connection Number    */
      KNL_SENDTASK_WP_INC( LAP_REP, LAP_PRO_ERR_LC, lcn, 0, 0, 0, cid );
      Mmu_Free( frame_ptr );
	   printf("[LC] LC_CRC_ERROR 5\n" );
      return;
   }
                                       /* Adjust new frame size !          */
   frame_length -= CS_fill_field_length;
   frame_length -= CHECKSUM_FIELD_LENGTH;

   #ifdef KLOCWORK
   temp_ptr     = Mmu_Realloc( frame_ptr,
                             frame_length + size_HLI_Header);
   if(temp_ptr == NULL) {
      Mmu_Free( frame_ptr );
      return;
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr     = Mmu_Realloc( frame_ptr,
                                frame_length + size_HLI_Header);
   #endif

                                       /* Set length in HLI_Header         */
   (( struct HLI_Header * ) frame_ptr ) -> length =
      frame_length + size_HLI_Header;

	printf("ctrl= %x, NLF_bit=%x \n",ctrl,NLF_bit);
   switch ( ctrl ) {

      case RR_TYP :
                                       /* Send RR-Frame to LAP process     */
            if( NLF_bit == 0x80 )
            {
                              /* P1: Logical Connection Number    */
               KNL_SENDTASK_NP_WP_INC( LAP_REP,
                                   LAP_RR_FRAME_NLF_LC,
                                   frame_ptr,
                                   lcn,
                                   0,
                                   0,
                                   0,
                                   cid );
            }
            else
            {
                              /* P1: Logical Connection Number    */
               KNL_SENDTASK_NP_WP_INC( LAP_REP,
                                   LAP_RR_FRAME_LC,
                                   frame_ptr,
                                   lcn,
                                   0,
                                   0,
                                   0,
                                   cid );
            }
            return;

      case I_TYP :

                                       /* Send I-Frame to LAP process      */
            if( NLF_bit == 0x80 )
            {
                              /* P1: Logical Connection Number    */
               KNL_SENDTASK_NP_WP_INC( LAP_REP,
                                   LAP_I_FRAME_NLF_LC,
                                   frame_ptr,
                                   lcn,
                                   0,
                                   0,
                                   0,
                                   cid );
            }
            else
            {
                              /* P1: Logical Connection Number    */
               KNL_SENDTASK_NP_WP_INC( LAP_REP,
                                   LAP_I_FRAME_LC,
                                   frame_ptr,
                                   lcn,
                                   0,
                                   0,
                                   0,
                                   cid );
            }
            return;

      default:
                                       /* Unkown Control field             */
                              /* P1: Logical Connection Number    */
            KNL_SENDTASK_WP_INC( LAP_REP, LAP_PRO_ERR_LC, lcn, 0, 0, 0, cid );
            Mmu_Free( frame_ptr );
            return;
   }
}
#endif
/*
*****************************************************************************
*                                                                           *
*   Function   :  Make_Fill_Bytes_and_CRC                                   *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  This function is called by the LC-process before the      *
*                 frame is overtaken to the MAC-Layer. The Fill field       *
*                 length is calculated and filled with balanced data (0xF0) *
*                 The Checksum field is filled by a function call to the    *
*                 function Fill_Checksum_Field().                           *
*   Parms      :  frame_ptr           : Pointer to the Frame to be filled   *
*   Returns    :  Pointer to the Layer 2 Frame.                             *
*   Call Level :  Process Level                                             *
*   Remarks    :  !! NOTE: Memory space for the Fill field and the Checksum *
*                 Field must be alloceted by a call to Mmu_Realloc() !      *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Make_Fill_Bytes_and_CRC( BYTE cid, FPTR frame_ptr )
{
   BYTE i;
   BYTE Li;
   BYTE min_frame_length;
   BYTE CS_fill_field_length;
   BYTE CS_frame_length;

   BYTE size_HLI_Header;
#ifdef KLOCWORK
   FPTR temp_ptr;
#endif
   size_HLI_Header = sizeof( struct HLI_Header );

   Li = ( frame_ptr[ 2 + size_HLI_Header ] >> 2 ) & 0x3F;
   min_frame_length     = Li + CS_HEADER_LENGTH + CHECKSUM_FIELD_LENGTH;
                                       /* determine CS_fill_field_length   */
   CS_fill_field_length = ( CS_FLEN_QUANT -
                          ( min_frame_length % CS_FLEN_QUANT ))
                          % CS_FLEN_QUANT;

                                       /* determine CS_frame_length        */
   CS_frame_length = min_frame_length + CS_fill_field_length;

                                       /* Request additional memory for    */
                                       /* the Checksum field and the Fill  */
                                       /* field.                           */
   #ifdef KLOCWORK
   temp_ptr = Mmu_Realloc( frame_ptr,
                            CS_frame_length + size_HLI_Header);
   if(temp_ptr == NULL) {
      return( frame_ptr );
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr = Mmu_Realloc( frame_ptr,
                            CS_frame_length + size_HLI_Header);
   #endif

                                       /* Set length in HLI_Header         */
   (( struct HLI_Header * ) frame_ptr ) -> length =
      CS_frame_length + size_HLI_Header;

                                       /* Write to Fill field              */
                                       /* ( balanced data "1111 0000" )    */
   for( i = 0; i < CS_fill_field_length; i++)
      frame_ptr[ i + size_HLI_Header + CS_HEADER_LENGTH + Li ] = 0xF0;

                                       /* Write to Checksum field          */
   frame_ptr = Fill_Checksum_Field( cid, frame_ptr, CS_frame_length );
   return( frame_ptr );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Cs_Ctrl_Init                                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  initialises the Cs channel RX/TX control elements         *
*   Parms      :  none                                                      *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Cs_Ctrl_Init (void)
{
   BYTE index;

   for (index = 0; index < MAX_LINK; index++)
      Reset_Cs_Ctrl_init (index);
}

#ifdef CONFIG_REPEATER_SUPPORT
EXPORT void
Rep_Cs_Ctrl_Init (void)
{
   BYTE index;

   for (index = 0; index < MAX_LINK; index++)
      Rep_Reset_Cs_Ctrl_init (index);
}
#endif
/*
*****************************************************************************
*                                                                           *
*   Function   :  Reset_Cs_Ctrl                                             *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  initialises one Cs channel RX/TX control element          *
*   Parms      :  cid_value                                                 *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Reset_Cs_Ctrl (BYTE cid_value)
{
   if (CS_ctrl[cid_value].Cframe_tx_ptr != NULL)
   {
      Mmu_Free (CS_ctrl[cid_value].Cframe_tx_ptr);
      CS_ctrl[cid_value].Cframe_tx_ptr = NULL;
	  CS_ctrl[cid_value].current_tx_ptr = NULL; 			 /* add hiryu_20070911 */

   }

   if (CS_ctrl[cid_value].Cframe_rx_ptr != NULL)
   {
      Mmu_Free (CS_ctrl[cid_value].Cframe_rx_ptr);
      CS_ctrl[cid_value].Cframe_rx_ptr = NULL;
	  CS_ctrl[cid_value].current_rec_ptr = NULL;			  /* add hiryu_20070911 */

   }

   CS_ctrl[cid_value].txCframe_length    =
   CS_ctrl[cid_value].rxCframe_length    =
   CS_ctrl[cid_value].received_Cs_octets = 0;

   CS_ctrl[cid_value].Ct_Receive_State = RECEIVER_IDLE;
}

#ifdef CONFIG_REPEATER_SUPPORT
EXPORT void
Rep_Reset_Cs_Ctrl (BYTE cid_value)
{
   if (RCS_ctrl[cid_value].Cframe_tx_ptr != NULL)
   {
      Mmu_Free (RCS_ctrl[cid_value].Cframe_tx_ptr);
      RCS_ctrl[cid_value].Cframe_tx_ptr = NULL;
	  RCS_ctrl[cid_value].current_tx_ptr = NULL; 			 /* add hiryu_20070911 */

   }

   if (RCS_ctrl[cid_value].Cframe_rx_ptr != NULL)
   {
      Mmu_Free (RCS_ctrl[cid_value].Cframe_rx_ptr);
      RCS_ctrl[cid_value].Cframe_rx_ptr = NULL;
	  RCS_ctrl[cid_value].current_rec_ptr = NULL;			  /* add hiryu_20070911 */

   }

   RCS_ctrl[cid_value].txCframe_length    =
   RCS_ctrl[cid_value].rxCframe_length    =
   RCS_ctrl[cid_value].received_Cs_octets = 0;

   RCS_ctrl[cid_value].Ct_Receive_State = RECEIVER_IDLE;
}
#endif

/*
*****************************************************************************
*                                                                           									*
*   Function   :  Reset_Cs_Ctrl_init                                           						  *
*                                                                         									  *
*****************************************************************************
*                                                                           									*
*   Purpose    :  first initialises one Cs channel RX/TX control element         				 *
*   Parms      :  cid_value                                                 							*
*   Returns    :  none                                                      							*
*   Call Level :  Process Level                                            							 *
*   Remarks    :                                                            								*
*                                                                           									*
*****************************************************************************
*/
EXPORT void
Reset_Cs_Ctrl_init (BYTE cid_value)
{
	CS_ctrl[cid_value].Cframe_tx_ptr = NULL;
	CS_ctrl[cid_value].Cframe_rx_ptr = NULL;

	/* add hiryu_20070911 */
	CS_ctrl[cid_value].current_tx_ptr = NULL;				/*	  current transmit data pointer */
	CS_ctrl[cid_value].current_rec_ptr = NULL;				/*	  current receive data pointer	*/


	CS_ctrl[cid_value].txCframe_length    =
	CS_ctrl[cid_value].rxCframe_length    =
	CS_ctrl[cid_value].received_Cs_octets = 0;
	CS_ctrl[cid_value].Ct_Receive_State = RECEIVER_IDLE;
}

#ifdef CONFIG_REPEATER_SUPPORT
EXPORT void
Rep_Reset_Cs_Ctrl_init (BYTE cid_value)
{
	RCS_ctrl[cid_value].Cframe_tx_ptr = NULL;
	RCS_ctrl[cid_value].Cframe_rx_ptr = NULL;

	RCS_ctrl[cid_value].current_tx_ptr = NULL;				/*	  current transmit data pointer */
	RCS_ctrl[cid_value].current_rec_ptr = NULL;				/*	  current receive data pointer	*/

	RCS_ctrl[cid_value].txCframe_length    =
	RCS_ctrl[cid_value].rxCframe_length    =
	RCS_ctrl[cid_value].received_Cs_octets = 0;
	RCS_ctrl[cid_value].Ct_Receive_State = RECEIVER_IDLE;
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Set_Tx_Ctrl                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  initialises the elements controlling the transmission     *
*                 of the Cs data addressed by 'frame'                       *
*   Parms      :  cid_value       : CID value of the LCE process            *
*                 frame_ptr       : Pointer to frame                        *
*   Returns    :  pointer to first Cs fragment to be sent                   *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Set_Tx_Ctrl (BYTE cid_value, FPTR frame )
{
   CS_CHANNEL XDATA  *Cs;

   BYTE size_HLI_Header;
   size_HLI_Header = sizeof( struct HLI_Header );


   Cs = &CS_ctrl [cid_value];

   Cs->current_tx_ptr  = frame + size_HLI_Header;
   Cs->Cframe_tx_ptr   = frame;
   Cs->txCframe_length = ((struct HLI_Header *)frame)->length -
                                                size_HLI_Header;

   /* correct length ?                 */
   if((Cs->txCframe_length % 5))
   	printf("[LC] WRONG CS LENGTH\n");
   if(!(Cs->txCframe_length <= 70))
   	printf("[LC] CS TOO LONG\n");

   return (Cs->current_tx_ptr);
}


#ifdef CONFIG_REPEATER_SUPPORT
EXPORT FPTR
Rep_Set_Tx_Ctrl (BYTE cid_value, FPTR frame )
{
   CS_CHANNEL XDATA  *Cs;

   BYTE size_HLI_Header;
   size_HLI_Header = sizeof( struct HLI_Header );


   Cs = &RCS_ctrl [cid_value];

   Cs->current_tx_ptr  = frame + size_HLI_Header;
   Cs->Cframe_tx_ptr   = frame;
   Cs->txCframe_length = ((struct HLI_Header *)frame)->length -
                                                size_HLI_Header;

   /* correct length ?                 */
   if((Cs->txCframe_length % 5))
   	printf("[LC] WRONG CS LENGTH\n");
   if(!(Cs->txCframe_length <= 70))
   	printf("[LC] CS TOO LONG\n");

   return (Cs->current_tx_ptr);
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  MacCoDtr_received                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  checks if fragments of a Cs frame are still to be sent    *
*   Parms      :  cid_value       : CID value of the LCE process            *
*   Returns    :  pointer to Cs fragment, NULL                              *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
MacCoDtr_received (BYTE cid_value)
{
   CS_CHANNEL XDATA  *Cs = &CS_ctrl [cid_value];

                                       /* already finished sending         */
                                       /* fragments                        */

   if (Cs->txCframe_length == 0)
      return NULL;

   Cs->current_tx_ptr += 5;
   Cs->txCframe_length -= 5;

                                       /* last Cs fragment transmitted ?   */
   if (Cs->txCframe_length == 0)
   {
      Mmu_Free (Cs->Cframe_tx_ptr);
      Cs->Cframe_tx_ptr = NULL;
//      Cs->current_tx_ptr = NULL;		/* add hiryu_20070911 */
      return NULL;
   }

   return (Cs->current_tx_ptr);
}

#ifdef CONFIG_REPEATER_SUPPORT
EXPORT FPTR
Rep_MacCoDtr_received (BYTE cid_value)
{
   CS_CHANNEL XDATA  *Cs = &RCS_ctrl [cid_value];

                                       /* already finished sending         */
                                       /* fragments                        */

   if (Cs->txCframe_length == 0)
      return NULL;

   Cs->current_tx_ptr += 5;
   Cs->txCframe_length -= 5;

                                       /* last Cs fragment transmitted ?   */
   if (Cs->txCframe_length == 0)
   {
      Mmu_Free (Cs->Cframe_tx_ptr);
      Cs->Cframe_tx_ptr = NULL;
//      Cs->current_tx_ptr = NULL;		/* add hiryu_20070911 */
      return NULL;
   }

   return (Cs->current_tx_ptr);
}

#endif
/*
*****************************************************************************
*                                                                           *
*   Function   :  Ct_fragment_received                                      *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  handles received Ct fragment                              *
*   Parms      :  cid_value       : CID value of the LCE process            *
*                 fragment        : pointer to Cs queue element             *
*   Returns    :  pointer to Cs frame if it is completely assembled         *
*                 NULL if a frame is yet to be completed                    *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Ct_fragment_received (BYTE cid_value, FPTR fragment)
{

//	unsigned long	long_loop;
   BYTE  Min_Frame_Length, CS_Fill_field_Length, index;

   CS_CHANNEL XDATA  *Cs = &CS_ctrl [cid_value];
   FPTR              temp;
   BYTE size_HLI_header;

   size_HLI_header = sizeof( struct HLI_Header);

   if (Cs->Ct_Receive_State == RECEIVER_IDLE)
   {
      #ifdef CONFIG_CS_HANDLING_IN_LC
      {
         /*
            Check if the first Cs data is correct or not for the specific Giagaset hansets.
            The following fields are checked.
            * EN 300 175-4 (7)

            1. The valid values of Address field
               - 10010001 - I command; NLF = 1, LLN = 1, C/R = 0, RES = 1
               - 00010001 - I command; NLF = 0, LLN = 1, C/R = 0, RES = 1
               - 00010011 - R response; NLF = 0, LLN = 1, C/R = 1, RES = 1

            2. Control field
               - For I command with NLF = 1, the value must be 0x00.
               - For I command with NLF = 0, the value & 0xDD must be 0x00.
               - For R response, the value & 0xDF must be 0x01.

            3. Length indicator field
               - For I command, the paramenter N must be 1 and the length must not 1.
               - For R response, the value must be 0x01.
          */
         FPTR dataPtr;
         BYTE len;

         dataPtr = &fragment[size_HLI_header];
         switch (dataPtr[0]) { // Address field
            case 0x91: // I command; NLF = 1, LLN = 1, C/R = 0, RES = 1
            case 0x11: // I command; NLF = 0, LLN = 1, C/R = 0, RES = 1
               // Control field
               if (((dataPtr[0] == 0x91) && (dataPtr[1] != 0x00)) ||          // receive number = 0, P = 0, send number = 0, Bit0 = 0
                   ((dataPtr[0] == 0x11) && ((dataPtr[1] & 0xDD) != 0x00))) { // receive number = 0 or 1, P = 0, send number = 0 or 1, Bit0 = 0
                  Mmu_Free(fragment);
                  return NULL;
               }

               // Length indicator field
               if ((dataPtr[2] & 0x01) != 0x01) { // N = 1
                  Mmu_Free(fragment);
                  return NULL;
               }
               len = (dataPtr[2] >> 2) & 0x3F;
               if (len == 1) { // if (len != 0 && len < 2)
                  Mmu_Free(fragment);
                  return NULL;
               }
               break;

            case 0x13: // R response; NLF = 0, LLN = 1, C/R = 1, RES = 1
               if ((dataPtr[1] & 0xDF) != 0x01) { // receive number = 0 or 1, P/F = 0, Bit3 ~ 0 = 1
                  Mmu_Free(fragment);
                  return NULL;
               }

               // Length indicator field
               if (dataPtr[2] != 0x01) { // length = 0, M = 0, N = 1
                  Mmu_Free(fragment);
                  return NULL;
               }
               break;

            default:
				/*Jake fix to handle Gigaset erroneous case and handle GAP Test case TC_A_AC_007*/
				if ((dataPtr[0] & 0x8F) != 0x81) { // NLF = 1, SAP = 0, C/R = 0, Reserved = 1; Except LLN
					Mmu_Free(fragment);
					return NULL;
				}

				if (dataPtr[1] != 0x00) { // receive number = 0, P = 0, send number = 0, Bit0 = 0
						Mmu_Free(fragment);
						return NULL;
				}

				// Length indicator field
				if ((dataPtr[2] & 0x01) != 0x01) { // N = 1
					Mmu_Free(fragment);
					return NULL;
				}
				len = (dataPtr[2] >> 2) & 0x3F;
				if (len == 1) { // if (len != 0 && len < 2)
					Mmu_Free(fragment);
					return NULL;
				}
				break;

#if 0
               Mmu_Free(fragment);
               return NULL;
#endif
				/*Jake fix to handle Gigaset erroneous case and handle GAP Test case TC_A_AC_007*/
         }
      }
      #endif

                                       /* get length indicator             */
                                       /* and request MMU buffer           */
      Min_Frame_Length = (( fragment[ 2 + size_HLI_header] >> 2 ) & 0x3F) +
                            CS_HEADER_LENGTH + CHECKSUM_FIELD_LENGTH;

                                       /* determine CS_Fill_field_Length   */
      CS_Fill_field_Length = ( CS_FLEN_QUANT -
                                 ( Min_Frame_Length % CS_FLEN_QUANT ))
                                 % CS_FLEN_QUANT;

                                       /* determine CS_Frame_Length        */
      Cs->rxCframe_length = Min_Frame_Length + CS_Fill_field_Length;

      if (Cs->rxCframe_length == 0 || Cs->rxCframe_length > 70)
      {
         printf("[LC] Error Cs->rxCframe_length: %02x\n",Cs->rxCframe_length);

//		 sleep(1);		/* for test  hiryu_20070920   I think    this is some problem */

         Mmu_Free( fragment );
         return NULL;
      }

      Cs->Cframe_rx_ptr = Mmu_Malloc ((WORD)((Cs->rxCframe_length) +
                                          size_HLI_header));

      #ifdef KLOCWORK
      if(Cs->Cframe_rx_ptr == NULL) {
         Mmu_Free( fragment );
         return( NULL );
      }
      #endif

      ((struct HLI_Header *)(Cs->Cframe_rx_ptr))->length =
                           Cs->rxCframe_length + size_HLI_header;


      Cs->Ct_Receive_State   = RECEIVING_DATA;
      Cs->received_Cs_octets = 0;
      Cs->current_rec_ptr    = Cs->Cframe_rx_ptr + size_HLI_header;

   }

   for (index = 0; index < 5; index++) {
      Cs->current_rec_ptr[ index ] = fragment[ index + size_HLI_header];
   }

   Mmu_Free (fragment);

   Cs->current_rec_ptr    += 5;
   Cs->received_Cs_octets += 5;

   //printf("[LC] : %02x %02x\n", Cs->received_Cs_octets, Cs->rxCframe_length);
   if (Cs->received_Cs_octets == Cs->rxCframe_length)
   {
                                       /* A complete frame was received and*/
                                       /* assembled. So it can now be      */
                                       /* forwarded to the upper layers.   */
                                       /* The Cs Struct has to be initial- */
                                       /* ized so that a new element can be*/
                                       /* received again                   */
      temp = Cs->Cframe_rx_ptr;

      Cs->Cframe_rx_ptr = NULL;
      Cs->Ct_Receive_State = RECEIVER_IDLE;
      CS_ctrl[cid_value].rxCframe_length    =
      CS_ctrl[cid_value].received_Cs_octets = 0;

      return (temp);                   /* Note that the upper layers will  */
                                       /* free the block after processing  */
                                       /* it.                              */
   }

   return NULL;
}

#ifdef CONFIG_REPEATER_SUPPORT
EXPORT FPTR
Rep_Ct_fragment_received (BYTE cid_value, FPTR fragment)
{

//	unsigned long	long_loop;
   BYTE  Min_Frame_Length, CS_Fill_field_Length, index;

   CS_CHANNEL XDATA  *Cs = &RCS_ctrl [cid_value];
   FPTR              temp;
   BYTE size_HLI_header;

   size_HLI_header = sizeof( struct HLI_Header);

   if (Cs->Ct_Receive_State == RECEIVER_IDLE)
   {
      #ifdef CONFIG_CS_HANDLING_IN_LC
      {
         /*
            Check if the first Cs data is correct or not for the specific Giagaset hansets.
            The following fields are checked.
            * EN 300 175-4 (7)

            1. The valid values of Address field
               - 10010001 - I command; NLF = 1, LLN = 1, C/R = 0, RES = 1
               - 00010001 - I command; NLF = 0, LLN = 1, C/R = 0, RES = 1
               - 00010011 - R response; NLF = 0, LLN = 1, C/R = 1, RES = 1

            2. Control field
               - For I command with NLF = 1, the value must be 0x00.
               - For I command with NLF = 0, the value & 0xDD must be 0x00.
               - For R response, the value & 0xDF must be 0x01.

            3. Length indicator field
               - For I command, the paramenter N must be 1 and the length must not 1.
               - For R response, the value must be 0x01.
          */
         FPTR dataPtr;
         BYTE len;

         dataPtr = &fragment[size_HLI_header];
         switch (dataPtr[0]) { // Address field
            case 0x91: // I command; NLF = 1, LLN = 1, C/R = 0, RES = 1
            case 0x11: // I command; NLF = 0, LLN = 1, C/R = 0, RES = 1
               // Control field
               if (((dataPtr[0] == 0x91) && (dataPtr[1] != 0x00)) ||          // receive number = 0, P = 0, send number = 0, Bit0 = 0
                   ((dataPtr[0] == 0x11) && ((dataPtr[1] & 0xDD) != 0x00))) { // receive number = 0 or 1, P = 0, send number = 0 or 1, Bit0 = 0
                  Mmu_Free(fragment);
                  return NULL;
               }

               // Length indicator field
               if ((dataPtr[2] & 0x01) != 0x01) { // N = 1
                  Mmu_Free(fragment);
                  return NULL;
               }
               len = (dataPtr[2] >> 2) & 0x3F;
               if (len == 1) { // if (len != 0 && len < 2)
                  Mmu_Free(fragment);
                  return NULL;
               }
               break;

            case 0x13: // R response; NLF = 0, LLN = 1, C/R = 1, RES = 1
               if ((dataPtr[1] & 0xDF) != 0x01) { // receive number = 0 or 1, P/F = 0, Bit3 ~ 0 = 1
                  Mmu_Free(fragment);
                  return NULL;
               }

               // Length indicator field
               if (dataPtr[2] != 0x01) { // length = 0, M = 0, N = 1
                  Mmu_Free(fragment);
                  return NULL;
               }
               break;

            default:
				/*Jake fix to handle Gigaset erroneous case and handle GAP Test case TC_A_AC_007*/
					if ((dataPtr[0] & 0x8F) != 0x81) { // NLF = 1, SAP = 0, C/R = 0, Reserved = 1; Except LLN
						Mmu_Free(fragment);
						return NULL;
					}

               if (dataPtr[1] != 0x00) { // receive number = 0, P = 0, send number = 0, Bit0 = 0
                  Mmu_Free(fragment);
                  return NULL;
               }

               // Length indicator field
               if ((dataPtr[2] & 0x01) != 0x01) { // N = 1
                  Mmu_Free(fragment);
                  return NULL;
               }
               len = (dataPtr[2] >> 2) & 0x3F;
               if (len == 1) { // if (len != 0 && len < 2)
                  Mmu_Free(fragment);
                  return NULL;
               }
					break;

#if 0
               Mmu_Free(fragment);
               return NULL;
#endif
				/*Jake fix to handle Gigaset erroneous case and handle GAP Test case TC_A_AC_007*/
         }
      }
      #endif

                                       /* get length indicator             */
                                       /* and request MMU buffer           */
      Min_Frame_Length = (( fragment[ 2 + size_HLI_header] >> 2 ) & 0x3F) +
                            CS_HEADER_LENGTH + CHECKSUM_FIELD_LENGTH;

                                       /* determine CS_Fill_field_Length   */
      CS_Fill_field_Length = ( CS_FLEN_QUANT -
                                 ( Min_Frame_Length % CS_FLEN_QUANT ))
                                 % CS_FLEN_QUANT;

                                       /* determine CS_Frame_Length        */
      Cs->rxCframe_length = Min_Frame_Length + CS_Fill_field_Length;

      if (Cs->rxCframe_length == 0 || Cs->rxCframe_length > 70)
      {
         printf("[LC] Error Cs->rxCframe_length: %02x\n",Cs->rxCframe_length);

//		 sleep(1);		/* for test  hiryu_20070920   I think    this is some problem */

         Mmu_Free( fragment );
         return NULL;
      }

      Cs->Cframe_rx_ptr = Mmu_Malloc ((WORD)((Cs->rxCframe_length) +
                                          size_HLI_header));
      #ifdef KLOCWORK
      if ( Cs->Cframe_rx_ptr == NULL) {
         Mmu_Free( fragment );
         return NULL;
      }
      #endif

      ((struct HLI_Header *)(Cs->Cframe_rx_ptr))->length =
                           Cs->rxCframe_length + size_HLI_header;


      Cs->Ct_Receive_State   = RECEIVING_DATA;
      Cs->received_Cs_octets = 0;
      Cs->current_rec_ptr    = Cs->Cframe_rx_ptr + size_HLI_header;

   }

   for (index = 0; index < 5; index++) {
      Cs->current_rec_ptr[ index ] = fragment[ index + size_HLI_header];
   }

   Mmu_Free (fragment);

   Cs->current_rec_ptr    += 5;
   Cs->received_Cs_octets += 5;

   if (Cs->received_Cs_octets == Cs->rxCframe_length)
   {
                                       /* A complete frame was received and*/
                                       /* assembled. So it can now be      */
                                       /* forwarded to the upper layers.   */
                                       /* The Cs Struct has to be initial- */
                                       /* ized so that a new element can be*/
                                       /* received again                   */
      temp = Cs->Cframe_rx_ptr;

      Cs->Cframe_rx_ptr = NULL;
      Cs->Ct_Receive_State = RECEIVER_IDLE;
      RCS_ctrl[cid_value].rxCframe_length    =
      RCS_ctrl[cid_value].received_Cs_octets = 0;

      return (temp);                   /* Note that the upper layers will  */
                                       /* free the block after processing  */
                                       /* it.                              */
   }

   return NULL;
}
#endif

   /* ==========================                                           */
   /* Local function definitions                                           */
   /* ==========================                                           */
/*
*****************************************************************************
*                                                                           *
*   Function   :  Determine_Frame_Typ                                       *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Returns the Layer 2 Frame typ (Acc. ETS 300 175-4 / 7.11) *
*   Parms      :  control_field   : Control Field of the received Layer 2   *
*                                   Frame                                   *
*   Returns    :  Layer 2 Frame typ                                         *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
LOCAL BYTE
Determine_Frame_Typ( BYTE control_field )
{
   if( ( control_field & 0x01 ) == I_TYP   ) return I_TYP;
   if( ( control_field & 0x0F ) == RR_TYP  ) return RR_TYP;
#ifdef CLASS_B
   if( ( control_field & 0x0F ) == RNR_TYP ) return RNR_TYP;
   if( ( control_field & 0x0F ) == REJ_TYP ) return REJ_TYP;
   if( ( control_field & 0xEF ) == SABM_TYP) return SABM_TYP;
   if( ( control_field & 0xEF ) == DM_TYP  ) return DM_TYP;
   if( ( control_field & 0xEF ) == UI_TYP  ) return UI_TYP;
   if( ( control_field & 0xEF ) == DISC_TYP) return DISC_TYP;
   if( ( control_field & 0xEF ) == UA_TYP  ) return UA_TYP;
#endif
   return( 0xFF );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Fill_Checksum_Field                                       *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Fills the Checksum field with the Checksum Octets X       *
*                 and Y.                                                    *
*                 The checksum Octets shall contain two elements:           *
*                 - a link signature (LSIG) and                             *
*                 - an underlying checksum                                  *
*                 For a detailed description, please refer to               *
*                 Ref.: ETS 300 175-4 / 7.10  Checksum field                *
*                       ETS 300 175-4 Annex B Checksum algorithms           *
*   Parms      :  frame_ptr       : Pointer to the Frame to be filled       *
*                 frame_length    : Length of the CS-Frame                  *
*   Return     :  Pointer to the filled Frame.                              *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
LOCAL FPTR
Fill_Checksum_Field( BYTE cid, FPTR frame_ptr, BYTE frame_length )
{
   BYTE i;
   int  c0, c1;
   BYTE temp_X, temp_Y;
   BYTE size_HLI_Header;
   size_HLI_Header = sizeof( struct HLI_Header );
                                       /* Checksum setting a)              */
                                       /* Build underlaying checksum       */
                                       /* -------------------------------- */

                                       /* B.2 Coding algorithm, step a     */
   frame_ptr[ frame_length + size_HLI_Header - 2 ] = 0x00;
   frame_ptr[ frame_length + size_HLI_Header - 1 ] = 0x00;
                                       /* B.2 Coding algorithm, step b     */
   c0 = c1 = 0;
                                       /* B.2 Coding algorithm, step c     */
   for ( i=0; i < frame_length; i++)
   {
      c0 = ( c0 + frame_ptr[ i + size_HLI_Header ] ) % 255;
      c1 = ( c1 + c0 ) % 255;
   }
                                       /* B.2 Coding algorithm, step d     */
   temp_X = (( c0 - c1 )  + 255 ) % 255;
   temp_Y = (-2 * c0 + c1 + 510  ) % 255;

                                       /* Checksum setting b)              */
                                       /* Combine with the link signature  */
                                       /* -------------------------------- */
   #ifdef CONFIG_REPEATER_SUPPORT
   if (ProcId == LC_REP) {
      frame_ptr[ frame_length + size_HLI_Header - 2 ] = temp_X ^ HIBYTE( RLSIG_Value[ cid ] );
      frame_ptr[ frame_length + size_HLI_Header - 1 ] = temp_Y ^ LOBYTE( RLSIG_Value[ cid ] );
   } else
   #endif
   {
      frame_ptr[ frame_length + size_HLI_Header - 2 ] = temp_X ^ HIBYTE( LSIG_Value[ cid ] );
      frame_ptr[ frame_length + size_HLI_Header - 1 ] = temp_Y ^ LOBYTE( LSIG_Value[ cid ] );
   }

   return( frame_ptr );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Check_Checksum_Field                                      *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Checks the Checksum of the received frame.                *
*   Parms      :  frame_ptr       : Pointer to the Frame to be checked      *
*                 frame_length    : Length of the CS-Frame                  *
*   Returns    :  TRUE / FALSE                                              *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
LOCAL BIT
Check_Checksum_Field( BYTE cid, FPTR frame_ptr, BYTE frame_length )
{
   BYTE i;
   int  c0, c1;
   BYTE temp_X, temp_Y;
   BYTE size_HLI_Header;
   size_HLI_Header = sizeof( struct HLI_Header );
                                       /* Checksum testing a)              */
                                       /* Remove the link signature        */
                                       /* -------------------------------- */
   #ifdef CONFIG_REPEATER_SUPPORT
   if (ProcId == LC_REP) {
	   //printf("RLSIG:%02x %02x\n", HIBYTE( RLSIG_Value[ cid ] ), LOBYTE( RLSIG_Value[ cid ] ));
      temp_X = frame_ptr[ frame_length + size_HLI_Header - 2 ] ^ HIBYTE( RLSIG_Value[ cid ] );
      temp_Y = frame_ptr[ frame_length + size_HLI_Header - 1 ] ^ LOBYTE( RLSIG_Value[ cid ] );
   } else
   #endif
   {
	   //printf("LSIG:%02x %02x\n", HIBYTE( LSIG_Value[ cid ] ), LOBYTE( LSIG_Value[ cid ] ));
      temp_X = frame_ptr[ frame_length + size_HLI_Header - 2 ] ^ HIBYTE( LSIG_Value[ cid ] );
      temp_Y = frame_ptr[ frame_length + size_HLI_Header - 1 ] ^ LOBYTE( LSIG_Value[ cid ] );
   }

   frame_ptr[ frame_length + size_HLI_Header - 2 ] = temp_X;
   frame_ptr[ frame_length + size_HLI_Header - 1 ] = temp_Y;

                                       /* Checksum testing b)              */
                                       /* Ceck underlaying checksum        */
                                       /* -------------------------------- */

                                       /* B.3 Decoding algorithm, step b   */
   c0 = c1 = 0;
                                       /* B.3 Decoding algorithm, step c   */
   for ( i=0; i < frame_length; i++)
   {
      c0 = ( c0 + frame_ptr[ i + size_HLI_Header ] ) % 255;
      c1 = ( c1 + c0 ) % 255;
   }
                                       /* If one or both of the Parameters */
                                       /* c0 and c1 do not have the value  */
                                       /* zero, the checksum formulae      */
                                       /* defined in ETS 300 174-4         */
                                       /* subclause 7.10 have not been     */
                                       /* satisfied.                       */
   if( c0 == 0 && c1 == 0 )
      return ( TRUE );
   else
      return ( FALSE );
}
