/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0       *
*                   (c) 2005 IFX / INTNIX. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  CP_server.C                                             *
*     Date       :  29 Nov, 2005                                            *
*     Contents   :  Mailbox definition for connection API and DECT library  *
*     Hardware   :                                                          *
*                                                                           *
*****************************************************************************
*/

/* =======================================================================
 * Include Files
 * ======================================================================= */
#include <stdio.h>
#include <string.h>
#ifdef LINUX
#include <pthread.h>
#endif
#include <unistd.h>
#include "DEFINE.H"

#include "PCT_DEF.H"
#include "FDEF.H"
#include "SYSDEF.H"
#include "CONF_DEF.H"
#include "TYPEDEF.H"
#include "ERROR.H"
#include "KNL_SYSTEM.H"
#include "MMU.H"
#include "CC_DEF.H"
#include "CC_LIB.H"
#include "MM_LIB.H"
#ifdef FT
#include "FGLOBAL.H"
#endif
#ifdef FT
//#include "FMAC_LIB.H"
#include "LCE_LIB.H"
#endif

#include "CP_SERVER.H"
#include "MESSAGE_DEF.H"

#include "REVISION_CP.H"

#include "dect_drv_if.h"
#include "IFX_DECT_MsgRouter.h"


#ifdef DECT_NG
#include "CP_server_lib.h"
#include "CONF_DEF.H"
#include "FMM.H"

#ifdef CATIQ_UPLANE
#include "CAT_UP.H"
#endif
#endif

/* =======================================================================
 * External Reference
 * ======================================================================= */
#ifdef __PIN_CODE__
IMPORT void IFX_DECT_ST_SetPinCode(char* pszPinCode);
#endif
IMPORT void IFX_CloseTimerDriver(void);

/* =======================================================================
 * Definitions
 * ======================================================================= */

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */
#if defined(DECT_DEBUG_USER_CP_PRIMITIVE) || defined(DECT_DEBUG_USER_APP_PRIMITIVE)
typedef struct {
   BYTE key;
   char *string;
} DebugStringTable_t;
#endif

#ifdef DECT_DEBUG_USER_CP_PRIMITIVE
LOCAL DebugStringTable_t messageStringTable[] = {
   {FP_CC_SETUP_RQ, "FP_CC_SETUP_RQ"},
   {FP_CC_SETUP_ACK_RQ, "FP_CC_SETUP_ACK_RQ"},
   {FP_CC_ALERT_RQ, "FP_CC_ALERT_RQ"},
   {FP_CC_CONNECT_RQ, "FP_CC_CONNECT_RQ"},
   {FP_CC_CONNECT_ACK_RQ, "FP_CC_CONNECT_ACK_RQ"},
   {FP_CC_INFO_RQ, "FP_CC_INFO_RQ"},
   {FP_CC_CALL_PROC_RQ, "FP_CC_CALL_PROC_RQ"},
   {FP_CC_RELEASE_RQ, "FP_CC_RELEASE_RQ"},
   {FP_CC_REJECT_RQ, "FP_CC_REJECT_RQ"},
   {FP_CC_INFO_BYPASS_RQ, "FP_CC_INFO_BYPASS_RQ"},
   {FP_CC_IWU_INFO_RQ, "FP_CC_IWU_INFO_RQ"},
   {FP_CC_SERVICE_CHANGE_RQ, "FP_CC_SERVICE_CHANGE_RQ"},
   {FP_CC_SERVICE_ACCEPT_RQ, "FP_CC_SERVICE_ACCEPT_RQ"},
   {FP_CC_SERVICE_REJECT_RQ, "FP_CC_SERVICE_REJECT_RQ"},
   {FP_CRSS_FACILITY_RQ, "FP_CRSS_FACILITY_RQ"},
   {FP_MM_ACCESS_RIGHTS_TERMINATE_RQ, "FP_MM_ACCESS_RIGHTS_TERMINATE_RQ"},
   {FP_MM_ACCESS_CODE_LOAD_RQ, "FP_MM_ACCESS_CODE_LOAD_RQ"},
   {FP_MM_INFO_SUGGEST_RQ, "FP_MM_INFO_SUGGEST_RQ"},
   {FP_MM_CIPHER_ON_RQ, "FP_MM_CIPHER_ON_RQ"},
   {FP_MM_CIPHER_OFF_RQ, "FP_MM_CIPHER_OFF_RQ"},
   {FP_MM_IDENTITY_RQ, "FP_MM_IDENTITY_RQ"},
   {FP_MM_AUTH_PT_RQ, "FP_MM_AUTH_PT_RQ"},
   {FP_MM_AUTH_USER_RQ, "FP_MM_AUTH_USER_RQ"},
   {FP_MM_KEY_ALLOC_RQ, "FP_MM_KEY_ALLOC_RQ"},
   #ifdef FT_CLMS
   {FP_CLMS_UNITDATA_RQ, "FP_CLMS_UNITDATA_RQ"},
   #endif
   {FP_CLSS_FACILITY_RQ, "FP_CLSS_FACILITY_RQ"},
   {FP_ME_RFP_LOAD_RQ, "FP_ME_RFP_LOAD_RQ"},
   {FP_ME_REGISTRATION_RESET_RQ, "FP_ME_REGISTRATION_RESET_RQ"},
   {FP_ME_A44_SET_RQ, "FP_ME_A44_SET_RQ"},
   {FP_ME_A44_CLEAR_RQ, "FP_ME_A44_CLEAR_RQ"},
   {FP_ME_MAC_NOEMO_RQ, "FP_ME_MAC_NOEMO_RQ"},
   {FP_ME_QT_SET_RQ, "FP_ME_QT_SET_RQ"},
   {FP_MAC_ENABLE_VOICE_EXTERNAL_RQ, "FP_MAC_ENABLE_VOICE_EXTERNAL_RQ"},
   {FP_MAC_DISABLE_VOICE_EXTERNAL_RQ, "FP_MAC_DISABLE_VOICE_EXTERNAL_RQ"},
   {FP_MAC_ENABLE_VOICE_INTERNAL_RQ, "FP_MAC_ENABLE_VOICE_INTERNAL_RQ"},
   {FP_MAC_DISABLE_VOICE_INTERNAL_RQ, "FP_MAC_DISABLE_VOICE_INTERNAL_RQ"},
   {FP_MAC_ENABLE_VOICE_CONFERENCE_RQ, "FP_MAC_ENABLE_VOICE_CONFERENCE_RQ"},
   {FP_MAC_DISABLE_VOICE_CONFERENCE_RQ, "FP_MAC_DISABLE_VOICE_CONFERENCE_RQ"},
   {FP_MAC_PAGE_CANCEL_RQ, "FP_MAC_PAGE_CANCEL_RQ"},
   {FP_MAC_SLOTTYPE_MOD_RQ, "FP_MAC_SLOTTYPE_MOD_RQ"},
   {FP_MAC_ENABLE_DATA_RQ, "FP_MAC_ENABLE_DATA_RQ"},
   {FP_MAC_DISABLE_DATA_RQ, "FP_MAC_DISABLE_DATA_RQ"},
   #ifdef __PIN_CODE__
   {FP_PIN_CH_RQ, "FP_PIN_CH_RQ"},
   #endif
   #ifdef ULE_SUPPORT
   {FP_ULE_SERVICE_RESUME_RQ, "FP_ULE_SERVICE_RESUME_RQ"},
   {FP_ULE_SERVICE_SUSPEND_RQ, "FP_ULE_SERVICE_SUSPEND_RQ"},
   {FP_ULE_TEMP_SUB_UPDATE_RQ, "FP_ULE_TEMP_SUB_UPDATE_RQ"},
   {FP_ULE_DEVICE_TYPE_UPDATE_RQ, "FP_ULE_DEVICE_TYPE_UPDATE_RQ"},
   #endif
   {FP_DEBUG_INFO_RQ, "FP_DEBUG_INFO_RQ"},
   {FP_TBR6_ACTIVATE_RQ, "FP_TBR6_ACTIVATE_RQ"},
   {FP_SOFTWARE_RESET_RQ, "FP_SOFTWARE_RESET_RQ"},
   {FP_HARDWARE_RESET_RQ, "FP_HARDWARE_RESET_RQ"},
   #ifdef CAT_IQ2_1
   {FP_MM_MODEL_ID_SET_RQ, "FP_MM_MODEL_ID_SET_RQ"},
   #endif
   {IFX_DECT_ENABLE, "IFX_DECT_ENABLE"},
   {IFX_DECT_SHUTDOWN, "IFX_DECT_SHUTDOWN"},
   {0xFF, "Unknown Message"}
};
#endif

#ifdef DECT_DEBUG_USER_APP_PRIMITIVE
LOCAL DebugStringTable_t appMessageStringTable[] = {
   {FP_SETUP_IN_CC, "FP_SETUP_IN_CC"},
   {FP_ALERT_IN_CC, "FP_ALERT_IN_CC"},
   {FP_CONNECT_IN_CC, "FP_CONNECT_IN_CC"},
   {FP_INFO_IN_CC, "FP_INFO_IN_CC"},
   {FP_RELEASE_IN_CC, "FP_RELEASE_IN_CC"},
   {FP_IWU_INFO_IN_CC, "FP_IWU_INFO_IN_CC"},
   {FP_SERVICE_CHANGE_IN_CC, "FP_SERVICE_CHANGE_IN_CC"},
   {FP_SERVICE_ACCEPT_IN_CC, "FP_SERVICE_ACCEPT_IN_CC"},
   {FP_SERVICE_REJECT_IN_CC, "FP_SERVICE_REJECT_IN_CC"},
   {FP_FACILITY_IN_CRSS, "FP_FACILITY_IN_CRSS"},
   {FP_ACCESS_RIGHTS_TERMINATE_CFM_MM, "FP_ACCESS_RIGHTS_TERMINATE_CFM_MM"},
   {FP_PORTABLE_REGISTERED_IN_MM, "FP_PORTABLE_REGISTERED_IN_MM"},
   {FP_PORTABLE_ATTACHED_IN_MM, "FP_PORTABLE_ATTACHED_IN_MM"},
   {FP_PROP_INFO_IN_MM, "FP_PROP_INFO_IN_MM"},
   {FP_PORTABLE_REGISTER_ONGOING_IN_MM, "FP_PORTABLE_REGISTER_ONGOING_IN_MM"},
   {FP_PORTABLE_REGISTER_FAIL_IN_MM, "FP_PORTABLE_REGISTER_FAIL_IN_MM"},
   {FP_CIPHER_ON_CFM_MM, "FP_CIPHER_ON_CFM_MM"},
   {FP_CIPHER_OFF_CFM_MM, "FP_CIPHER_OFF_CFM_MM"},
   {FP_SLOTTYPE_MOD_IN_MAC, "FP_SLOTTYPE_MOD_IN_MAC"},
   {FP_AUTHENTICATE_PT_CFM_MM, "FP_AUTHENTICATE_PT_CFM_MM"},
   {FP_AUTHENTICATE_USER_CFM_MM, "FP_AUTHENTICATE_USER_CFM_MM"},
   #ifdef ULE_SUPPORT
   {FP_SUBSCRIPTION_INFO_UPDATED_MM, "FP_SUBSCRIPTION_INFO_UPDATED_MM"},
   #endif
   {FP_ACCESS_RIGHTS_TERMINATE_IND_MM, "FP_ACCESS_RIGHTS_TERMINATE_IND_MM"},
   {FP_FACILITY_IN_CLSS, "FP_FACILITY_IN_CLSS"},
   {FP_MAC_NOEMO_IN_ME, "FP_MAC_NOEMO_IN_ME"},
   {FP_DEBUG_INFO_IND, "FP_DEBUG_INFO_IND"},
   {FP_DEBUG_MESSAGE_IND, "FP_DEBUG_MESSAGE_IND"},
   {FP_MODEM_BOOT_IND, "FP_MODEM_BOOT_IND"},
   {0xFF, "Unknown Message"}
};
#endif

/* =======================================================================
 * Local Variables
 * ======================================================================= */
#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
LOCAL BYTE Service_Change_State[MAX_PORTABLE];
LOCAL BYTE Required_Slot_Type[MAX_PORTABLE];
LOCAL BYTE Actual_Slot_Type[MAX_PORTABLE];
#endif

/* =======================================================================
 * Global Variables
 * ======================================================================= */
GLOBAL XDATA BYTE ProcId;
GLOBAL XDATA BYTE CurrentState;
GLOBAL XDATA BYTE CurrentMessage;
GLOBAL XDATA BYTE CurrentInc;
GLOBAL XDATA BYTE PARAMETER1;
GLOBAL XDATA BYTE PARAMETER2;
GLOBAL XDATA BYTE PARAMETER3;
GLOBAL XDATA BYTE PARAMETER4;
GLOBAL XDATA BYTE PARAMETER5;
GLOBAL XDATA BYTE PARAMETER6;
GLOBAL FPTR G_PTR;

GLOBAL XDATA BYTE G_PTR_Array[29]; // unused

GLOBAL BIT MAC_Test_Mode = 0;
GLOBAL BIT TBR22_Test = TRUE;

GLOBAL XDATA WORD First_EMC_Code = 0x0050;
GLOBAL XDATA BYTE Model_ID;

#if !defined(ULE_SUPPORT) && !defined(CONFIG_REPEATER_SUPPORT)
GLOBAL BYTE Service_Change_State[MAX_PORTABLE];
GLOBAL BYTE Required_Slot_Type[MAX_PORTABLE];
GLOBAL BYTE Actual_Slot_Type[MAX_PORTABLE];
#endif
GLOBAL BYTE Required_Slot_Type_CID[MAX_LINK];
GLOBAL BYTE Current_Tapi_Ch1[MAX_LINK];

GLOBAL BYTE Osc_Trimming_Mode = FALSE;

GLOBAL unsigned char VucDECT_Enable;
GLOBAL unsigned char VucRANDOM_Timer_Started;
GLOBAL x_IFX_DECT_IPC_Msg vxStack2AppMsg;

#ifdef LINUX		 
GLOBAL unsigned int Exitval = 0;
GLOBAL unsigned int *ValPtr = NULL;
#endif

#ifdef CONFIG_REPEATER_SUPPORT
GLOBAL XDATA BYTE Feature_Repeater = 0;
#endif
/* =======================================================================
 * Local Function Prototypes
 * ======================================================================= */

/* =======================================================================
 * Function Definitions
 * ======================================================================= */
#if defined(DECT_DEBUG_USER_CP_PRIMITIVE) || defined(DECT_DEBUG_USER_APP_PRIMITIVE)
LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
{
	BYTE i;

	for (i = 0; tablePtr[i].key != 0xFF; i++) {
		if (tablePtr[i].key == key) {
			break;
		}
	}
	return tablePtr[i].string;
}
#endif

extern FPTR
Add_CODEC_LIST1(FPTR frame_ptr, FPTR source_ptr);

void Enable_DECT(unsigned char ucEnableFlg)
{
	 if(ucEnableFlg)
	 {
	 	VucDECT_Enable = 1;
	}
	else
	 {
	 	VucDECT_Enable = 0;
	}
}


/*
*****************************************************************************
*                                                                           *
*   Function   :  Serve_Mail_CP ()                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Check Mail Messages from Application             *
*   Parms      :  none                                                      *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Serve_Mail_CP(x_IFX_DECT_IPC_Msg* recv_buf)
{
   FPTR   temp, temp_prop;
   BYTE   mcei_1, mcei_2, data_len/*, test_p*/;
   BYTE   cur_index, osc_trim_flag, osc_index;

   /* Copy Queue entry to global variables ! */
   CurrentMessage  = recv_buf->ucMsgId;
   CurrentInc      = recv_buf->ucInstance;
   PARAMETER1      = recv_buf->ucPara1;
   PARAMETER2      = recv_buf->ucPara2;
   PARAMETER3      = recv_buf->ucPara3;
   PARAMETER4      = recv_buf->ucPara4;
   data_len =  ((DATA_FRAME *)(recv_buf->acData))->length;
   G_PTR = NULL;

	if (FP_DEBUG_INFO_RQ == CurrentMessage) {
	   G_PTR = Mmu_Malloc(43);

        #ifdef KLOCWORK
        if(G_PTR != NULL)
        #endif
        {
	   memcpy(G_PTR, recv_buf->acData, 43);
        }
	} else if (data_len > 0) {
      G_PTR = Mmu_Malloc(250);
      #ifdef KLOCWORK
      if(G_PTR != NULL)
      #endif
      {
      memset(G_PTR,0x00,250);
      memcpy(G_PTR, recv_buf->acData, data_len+1);
      }
      memset(recv_buf, 0x00, sizeof(x_IFX_DECT_IPC_Msg));
   }

   // ======================
   // Serve FT mail messages
   // ======================
   #ifdef DECT_DEBUG_USER_CP_PRIMITIVE
   DECT_DEBUG_USER_CP_PRIMITIVE("%s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable), CurrentInc,
                                PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
   #endif
   switch (CurrentMessage) {
      #ifdef FT_CLMS
      case FP_CLMS_UNITDATA_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block(DATE_TIME or  CLIP/CNIP or others but the length must by within)
         // PARAMETER1 = Po_no(currentInc + 1) ==> Handset / Group ID
         // PARAMETER2 = Signal
         // PARAMETER3 = service life time(in sec, 0xff: no life time limit)
         // PARAMETER4 = CLMS message type(0: Group-ring, 1:Collective-ring, 2: CLMS Fixed, 3: CLMS Variable)
         //////////////////////////////////////////////////////////////////////////
         {
            #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
            if ((Get_Terminal_Cap(PARAMETER1) == 0) || ((PARAMETER4 & 0x0F) == 1)) {
            #else
            if ((Terminal_Cap[PARAMETER1 - 1] == 0) || ((PARAMETER4 & 0x0F) == 1)) {
            #endif
               if ((PARAMETER4 & 0xF0) == 0x10) {
                  PARAMETER4 &= 0x0F;
               }
            }

            KNL_SENDTASK_NP_WP(CLMS, CLMS_MNCL_UNITDATA_RQ_SWI, G_PTR, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
         }
         break;
      #endif
      
      case FP_CC_SETUP_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = Signal
         //////////////////////////////////////////////////////////////////////////
         {
                                               /* The function forwards the        */
                                               /* << CC_SETUP >> msg.              */
                                               /* for External Call & Internal Call*/

                                               /* Assembly the setup frame !       */
            temp = Construct_MNCC_Primitive();
            temp = Add_PORTABLE_IDENTITY(PARAMETER1, temp, IDENTITY_TYP_IPUI);
            #ifdef CONFIG_REPEATER_SUPPORT_WITH_ACCESS_RIGHT
            temp = Add_FIXED_IDENTITY(0, temp, IDENTITY_TYP_PARK);
            #else
            temp = Add_FIXED_IDENTITY(temp, IDENTITY_TYP_PARK);
            #endif
                                              /* -------------------------------- */
                                              /* !!! Gigaset 1000S concession !!! */
                                              /* -------------------------------- */
                                              /* The Gigaset 1000S does only      */
                                              /* accept Setups with BASIC_SERVICE */
                                              /* coded as EXTERNAL_CALL.          */
                                              /* Therefore we always use this     */
                                              /* coding. In case of an internal   */
                                              /* call request, we append the      */
                                              /* Proprietary Code 'Call type -    */
                                              /* Internal Call' to overwrite the  */
                                              /* Call Struct Setting in a PRODECT */
                                              /* V2.0 Portable.                   */
            #ifdef DECT_NG
            /* Check Terminal Capability of Handset, if Handset does not support Long Slot,
               Base have to change Service Call Type to Narrow-Band Call and Codec Info to
               G.726.      */
            #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
            if (Get_Terminal_Cap(PARAMETER1) == 0) {
            #else
            if (Terminal_Cap[PARAMETER1 - 1] == 0) {
            #endif
               if (PARAMETER4 == WBS_EXTERNAL_CALL) {
                  PARAMETER4 = EXTERNAL_CALL;
               } else if (PARAMETER4 == WBS_INTERNAL_CALL) {
                  PARAMETER4 = INTERNAL_CALL;
               }
               // PARAMETER3 = CODEC_G726;
            }
            temp = Add_IE_2(temp, BASIC_SERVICE, PARAMETER4);
            #endif

            if (PARAMETER2 != DUMMY_FILL) {
               temp = Add_IE_2(temp, SIGNAL, PARAMETER2);
            }

            #ifdef DECT_NG
            /* Add IE <<CODEC_LIST>> to negotiate CODEC according to NG */
            #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
            if ((PARAMETER3 != DUMMY_FILL) && (Get_Terminal_Cap(PARAMETER1) == 1)) {
            #else
            if ((PARAMETER3 != DUMMY_FILL) && (Terminal_Cap[PARAMETER1 - 1] == 1)) {
            #endif
               if ((PARAMETER3 == 0) || (PARAMETER3 == 1) || (PARAMETER3 == CODEC_G722) || (PARAMETER3 == CODEC_G726)) {
                  temp_prop = Get_Codec_List(PARAMETER3);
                  if (G_PTR == NULL) {
                     G_PTR = Mmu_Malloc(250);
                     #ifdef KLOCWORK
                     if( G_PTR != NULL )
                     #endif
                     {
                     memset(G_PTR,0x00,250);
                  }
                  }
                  G_PTR = Add_CODEC_LIST1(G_PTR, temp_prop);
            	   Mmu_Free(temp_prop);
               }
            }

            if (((PARAMETER3 == 0) || (PARAMETER3 == CODEC_G722)) && ((PARAMETER4 & 0x0F) != 0x00)) {
               #ifdef ULE_SUPPORT
               Set_Required_Slot_Type(PARAMETER1, 1);
               #else
               Required_Slot_Type[PARAMETER1 - 1] = 1;
               #endif
            } else {
               #ifdef ULE_SUPPORT
               Set_Required_Slot_Type(PARAMETER1, 0);
               #else
               Required_Slot_Type[PARAMETER1 - 1] = 0;
               #endif
            }
            #endif

            if (G_PTR != NULL) {
               #ifdef CAT_IQ2_1
               temp = Add_TRANSPARENT(temp, G_PTR);
               #else
               temp = Add_PROPRIETARY(temp, G_PTR);
               #endif
               Mmu_Free(G_PTR);
            }


            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_MNCCS_SETUP_RQ_SWI,
                              temp,
                              FALSE,
                              0, // IWU = 0
                              FP_RELEASE_IN_CC,
                              CurrentInc); // It should be replaced to po_no if fail by time out
         }
         break;

      case FP_CC_SETUP_ACK_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = Signal
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                         /* The function forwards the        */
                                         /* << CC_SETUP >> msg.              */
                                         /* for External Call & Internal Call*/

                                         /* Assembly the setup frame !       */
            temp = Construct_MNCC_Primitive();

            if (PARAMETER2 != DUMMY_FILL) {
               temp = Add_IE_2(temp, SIGNAL, PARAMETER2);
            }

            if (G_PTR != NULL) {
               #ifdef CAT_IQ2_1
               temp = Add_TRANSPARENT(temp, G_PTR);
               #else
               temp = Add_PROPRIETARY(temp, G_PTR);
               #endif
               Mmu_Free(G_PTR);
            }

            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_MNCCS_SETUP_ACK_RQ_SWI,
                              temp,
                              FALSE,
                              0, // IWU = 0
                              FP_RELEASE_IN_CC,
                              CurrentInc); // It should be replaced to po_no if fail by time out
         }
         break;

      case FP_CC_ALERT_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = nul
         //////////////////////////////////////////////////////////////////////////
         {
                                         /* The function forwards the        */
                                         /* << CC_SETUP >> msg.              */
                                         /* for External Call & Internal Call*/

                                         /* Assembly the setup frame !       */
            temp = Construct_MNCC_Primitive();

            if (G_PTR != NULL) {
               #ifdef CAT_IQ2_1
               temp = Add_TRANSPARENT(temp, G_PTR);
               #else
               temp = Add_PROPRIETARY(temp, G_PTR);
               #endif
               Mmu_Free(G_PTR);
            }

            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_MNCCS_ALERT_RQ_SWI,
                              temp,
                              FALSE,
                              0, // IWU = 0
                              FP_RELEASE_IN_CC,
                              CurrentInc); // It should be replaced to po_no if fail by time out
         }
         break;

      case FP_CC_INFO_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = Signal
         //////////////////////////////////////////////////////////////////////////
         {
                                            /* The function forwards the        */
                                            /* << CC_SETUP >> msg.              */
                                            /* for External Call & Internal Call*/

                                            /* Assembly the setup frame !       */
            temp = Construct_MNCC_Primitive();
                                           /* -------------------------------- */
                                           /* !!! Gigaset 1000S concession !!! */
                                           /* -------------------------------- */
                                           /* The Gigaset 1000S does only      */
                                           /* accept Setups with BASIC_SERVICE */
                                           /* coded as EXTERNAL_CALL.          */
                                           /* Therefore we always use this     */
                                           /* coding. In case of an internal   */
                                           /* call request, we append the      */
                                           /* Proprietary Code 'Call type -    */
                                           /* Internal Call' to overwrite the  */
                                           /* Call Struct Setting in a PRODECT */
                                           /* V2.0 Portable.                   */
            if (PARAMETER4 != DUMMY_FILL) {
               temp_prop=Get_Progress_Indicator();
               temp = Add_PROGRESS_INDICATOR(temp, temp_prop);
               Mmu_Free(temp_prop);
            }


            if (PARAMETER2 != DUMMY_FILL) {
               temp = Add_IE_2(temp, SIGNAL, PARAMETER2);
            }

            #ifdef DECT_NG
            /* Add IE <<CODEC_LIST>> to negotiate CODEC according to NG */
            #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
            if ((PARAMETER3 != DUMMY_FILL) && (Get_Terminal_Cap(PARAMETER1) == 1)) {
            #else
            if ((PARAMETER3 != DUMMY_FILL) && (Terminal_Cap[PARAMETER1 - 1] == 1)) {
            #endif
               if ((PARAMETER3 == 0) || (PARAMETER3 == CODEC_G722) || (PARAMETER3 == CODEC_G726)) {
                  temp_prop = Get_Codec_List(PARAMETER3);

                  if(G_PTR == NULL){
                     G_PTR = Mmu_Malloc(250);
                     #ifdef KLOCWORK
                     if( G_PTR != NULL )
                     #endif
                     {
                     memset(G_PTR,0x00,250);
                  }
                  }
                  G_PTR = Add_CODEC_LIST1(G_PTR, temp_prop);
                  Mmu_Free(temp_prop);
               }
            }
            #endif

            if (G_PTR != NULL) {
               #ifdef CAT_IQ2_1
               temp = Add_TRANSPARENT(temp, G_PTR);
               #else
               temp = Add_PROPRIETARY(temp, G_PTR);
               #endif
               Mmu_Free(G_PTR);
            }


            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_MNCCS_INFO_RQ_SWI,
                              temp,
                              FALSE,
                              0, // IWU = 0
                              FP_RELEASE_IN_CC,
                              CurrentInc); // It should be replaced to po_no if fail by time out
         }
         break;

      #ifdef DECT_NG
      case FP_CLSS_FACILITY_RQ:
          //////////////////////////////////////////////////////////////////////////
          // GPTR            = IE memory block
          // PARAMETER1 = Po_no(currentInc + 1)
          //////////////////////////////////////////////////////////////////////////
         {
            /* Assembly of frame !       */
            temp = Construct_MNCC_Primitive();

            if (G_PTR != NULL) {
               // G_PTR contains list of all information elements, add this to message as it is
               #ifdef CAT_IQ2_1
               temp = Add_TRANSPARENT(temp, G_PTR);
               #else
               temp = Add_PROPRIETARY(temp, G_PTR);
               #endif
               Mmu_Free(G_PTR);
            }

            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_CLSS_FACILITY_RQ_SWI,
                              temp,
                              FALSE,
                              DUMMY_FILL,
                              DUMMY_FILL,
                              CurrentInc);
         }
         break;
      #endif

      #ifdef CATIQ_VE
      case FP_CRSS_FACILITY_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         //////////////////////////////////////////////////////////////////////////
         {
            /* Assembly of frame !       */
            temp = Construct_MNCC_Primitive();

            if (G_PTR != NULL) {
               // G_PTR contains list of all information elements, add this to message as it is
               #ifdef CAT_IQ2_1
               temp = Add_TRANSPARENT(temp, G_PTR);
               #else
               temp = Add_PROPRIETARY(temp, G_PTR);
               #endif
               Mmu_Free(G_PTR);
            }

            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_CRSS_FACILITY_RQ_SWI,
                              temp,
                              FALSE,
                              DUMMY_FILL,
                              DUMMY_FILL,
                              CurrentInc);
         }
         break;
      #endif

      case FP_CC_IWU_INFO_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = Signal
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                                       /* The function forwards the        */
                                                       /* << CC_SETUP >> msg.              */
                                                       /* for External Call & Internal Call*/

                                                       /* Assembly the setup frame !       */
            temp = Construct_MNCC_Primitive();
            #ifdef KLOCWORK
            if(temp == NULL) {
              Mmu_Free(G_PTR);
              break;
            }
            #endif
                                                      /* -------------------------------- */
                                                      /* !!! Gigaset 1000S concession !!! */
                                                      /* -------------------------------- */
                                                      /* The Gigaset 1000S does only      */
                                                      /* accept Setups with BASIC_SERVICE */
                                                      /* coded as EXTERNAL_CALL.          */
                                                      /* Therefore we always use this     */
                                                      /* coding. In case of an internal   */
                                                      /* call request, we append the      */
                                                      /* Proprietary Code 'Call type -    */
                                                      /* Internal Call' to overwrite the  */
                                                      /* Call Struct Setting in a PRODECT */
                                                      /* V2.0 Portable.                   */
            #ifdef ULE_SUPPORT
            #ifdef KLOCWORK
            if (VALID_PORTABLE_ULE(PARAMETER1, PORTABLE_ULE)) {
            #else
            if (IsValidPortableNo(PARAMETER1, PORTABLE_ULE)) {
            #endif
               if (G_PTR != NULL) {
                  temp = Add_TRANSPARENT(temp, G_PTR);
                  Mmu_Free(G_PTR);
               }
            } else
            #endif
            {
               if (G_PTR != NULL) {
                  int iCount;
                  if (((DATA_FRAME *)G_PTR)->dat[0] != 0x77) {
                     temp = Add_IWU_PROPRIETARY(temp, G_PTR);
                  } else {
                     iCount = ((struct HLI_Header *)temp)->length;
                     /* Get memory for the IE.           */
                     temp = Mmu_Realloc(temp, iCount + ((DATA_FRAME *) G_PTR)->length);
                    #ifdef KLOCWORK
                     if(temp != NULL)
                    #endif
                     {
                     /* Append the IE.                   */
                     Mmu_Memcpy(&temp[iCount], ((DATA_FRAME *)G_PTR)->dat, ((DATA_FRAME *)G_PTR)->length);
                     /* Update of HLI_Header.            */
                     ((struct HLI_Header *)temp)->length = iCount + ((DATA_FRAME *) G_PTR)->length;
                  }
                  }
                  Mmu_Free(G_PTR);
               }

               #ifdef DECT_NG
               /* Add IE <<CODEC_LIST>> to negotiate CODEC according to NG */
               #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
               if ((PARAMETER3 != DUMMY_FILL) && (Get_Terminal_Cap(PARAMETER1) == 1)) {
               #else
               if ((PARAMETER3 != DUMMY_FILL) && (Terminal_Cap[PARAMETER1 - 1] == 1)) {
               #endif
                  if ((PARAMETER3 == 0) || (PARAMETER3 == CODEC_G722) || (PARAMETER3 == CODEC_G726)) {
                     temp_prop = Get_Codec_List(PARAMETER3);
                     temp = Add_CODEC_LIST(temp, temp_prop);
                     Mmu_Free(temp_prop);
                  }
               
                  #ifdef ULE_SUPPORT
                  if (Get_Service_Change_State(PARAMETER1) != SVC_IDLE) {
                     Set_Service_Change_State(PARAMETER1, SVC_IDLE);
                  }
                  DECT_DEBUG_USER_CP_DATA("[CP] Service Change State: %02x CODEC: %02x\n", Get_Service_Change_State(PARAMETER1), PARAMETER3);
                  #else
                  if (Service_Change_State[PARAMETER1 - 1] != SVC_IDLE) {
                     Service_Change_State[PARAMETER1 - 1] = SVC_IDLE;
                  }
                  DECT_DEBUG_USER_CP_DATA("[CP] Service Change State: %02x CODEC: %02x\n", Service_Change_State[PARAMETER1 - 1], PARAMETER3);
                  #endif
               }
               #endif
            }

            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_MNCCS_IWU_INFO_RQ_SWI,
                              temp,
                              FALSE,
                              0, // IWU = 0
                              FP_RELEASE_IN_CC,
                              CurrentInc); // It should be replaced to po_no if fail by time out
         }
         break;

      case FP_CC_CALL_PROC_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = Signal
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                            /* The function forwards the        */
                                            /* << CC_SETUP >> msg.              */
                                            /* for External Call & Internal Call*/

                                            /* Assembly the setup frame !       */
            temp = Construct_MNCC_Primitive();

            if (PARAMETER2 != DUMMY_FILL) {
               temp = Add_IE_2(temp, SIGNAL, PARAMETER2);
            }


            #ifdef xxxDECT_NG
            temp_prop=Get_Progress_Indicator();
            temp = Add_PROGRESS_INDICATOR(temp, temp_prop);
            Mmu_Free(temp_prop);

            /* Add IE <<CODEC_LIST>> to negotiate CODEC according to NG */
            #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
            if ((PARAMETER3 != DUMMY_FILL) && (Get_Terminal_Cap(PARAMETER1) == 1)) {
            #else
            if ((PARAMETER3 != DUMMY_FILL) && (Terminal_Cap[PARAMETER1 - 1] == 1)) {
            #endif
               if ((PARAMETER3 == 0) || (PARAMETER3 == CODEC_G722) || (PARAMETER3 == CODEC_G726)) {
                  temp_prop = Get_Codec_List(PARAMETER3);

                  if (G_PTR == NULL) {
                     G_PTR = Mmu_Malloc(250);
                     memset(G_PTR,0x00,250);
                  }
                  G_PTR = Add_CODEC_LIST1(G_PTR, temp_prop);
                  Mmu_Free(temp_prop);
               }
            }
            #endif

			   if(G_PTR != NULL)
            {
               #ifdef CAT_IQ2_1
               temp = Add_TRANSPARENT(temp, G_PTR);
               #else
               temp = Add_PROPRIETARY(temp, G_PTR);
               #endif
               Mmu_Free(G_PTR);
            }


            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_MNCCS_CALL_PROC_RQ_SWI,
                              temp,
                              FALSE,
                              0, // IWU = 0
                              FP_RELEASE_IN_CC,
                              CurrentInc); // It should be replaced to po_no if fail by time out
         }
         break;

      case FP_CC_CONNECT_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = Signal
         // PARAMETER3 = Codec chosen or Data_Call indicator(0x80)
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                            /* The function forwards the        */
                                            /* << CC_SETUP >> msg.              */
                                            /* for External Call & Internal Call*/

                                            /* Assembly the setup frame !       */
            temp = Construct_MNCC_Primitive();
            #ifdef KLOCWORK
            if(temp == NULL) {
              Mmu_Free(G_PTR);
              break;
            }
            #endif

            #ifdef CATIQ_UPLANE
            if (0x80 == PARAMETER3) { // Data Connect
              temp = GetIWU_ATTRIBUTES(temp);
              temp = GetCALL_ATTRIBUTES(temp);
              temp = GetCONNECTION_ATTRIBUTES(temp);
              temp = GetTRANSIT_DELAY(temp);
              temp = GetWINDOW_SIZE(temp);
            } else
            #endif
            { // Voice Connect
               if (PARAMETER2 != DUMMY_FILL) {
                  temp = Add_IE_2(temp, SIGNAL, PARAMETER2);
               }

               #ifdef DECT_NG
               /* Add IE <<CODEC_LIST>> to negotiate CODEC according to NG */
               #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
               if ((PARAMETER3 != DUMMY_FILL) && (Get_Terminal_Cap(PARAMETER1) == 1)) {
               #else
               if ((PARAMETER3 != DUMMY_FILL) && (Terminal_Cap[PARAMETER1 - 1] == 1)) {
               #endif
				      if((PARAMETER3 == 0) || (PARAMETER3 == CODEC_G722) || (PARAMETER3 == CODEC_G726)) {
                     temp_prop = Get_Codec_List(PARAMETER3);

                     if(G_PTR == NULL){
                        G_PTR = Mmu_Malloc(250);
                        #ifdef KLOCWORK
                        if( G_PTR != NULL )
                        #endif
                        {
                        memset(G_PTR,0x00,250);
                     }
                     }
                     G_PTR = Add_CODEC_LIST1(G_PTR, temp_prop);
				         // temp = Add_CODEC_LIST(temp, temp_prop);
                     Mmu_Free(temp_prop);
			         }
               }
               #endif
            }

            if (G_PTR!= NULL) {
               #ifdef CAT_IQ2_1
               temp = Add_TRANSPARENT(temp, G_PTR);
               #else
               temp = Add_PROPRIETARY(temp, G_PTR);
               #endif
              Mmu_Free(G_PTR);
            }

            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_MNCCS_CONNECT_RQ_SWI,
                              temp,
                              FALSE,
                              0, // IWU = 0
                              FP_RELEASE_IN_CC,
                              CurrentInc); // It should be replaced to po_no if fail by time out
         }
         break;

      case IFX_DECT_ENABLE:
         {
            Enable_DECT(PARAMETER3);
         }
         break;
      case IFX_DECT_SHUTDOWN:
         {
            #ifdef LINUX
            IFX_CloseTimerDriver();
            DectDrvIfShut();
            sleep(1);
            {
               // int iVal=0;
               ValPtr=&Exitval;
               pthread_exit(&ValPtr);
            }
            #endif
         }
         break;

      case FP_CC_CONNECT_ACK_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = Signal
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                            /* The function forwards the        */
                                            /* << CC_SETUP >> msg.              */
                                            /* for External Call & Internal Call*/

                                            /* Assembly the setup frame !       */
            temp = Construct_MNCC_Primitive();
            if (PARAMETER2 != DUMMY_FILL) {
               temp = Add_IE_2(temp, SIGNAL, PARAMETER2);
            }


            if(G_PTR != NULL)
            {
               #ifdef CAT_IQ2_1
               temp = Add_TRANSPARENT(temp, G_PTR);
               #else
               temp = Add_PROPRIETARY(temp, G_PTR);
               #endif
               Mmu_Free(G_PTR);
            }

            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_MNCCS_CONNECT_ACK_RQ_SWI,
                              temp,
                              FALSE,
                              0, // IWU = 0
                              FP_RELEASE_IN_CC,
                              CurrentInc); // It should be replaced to po_no if fail by time out
         }
         break;

      case FP_CC_RELEASE_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = Reason
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                            /* The function forwards the        */
                                            /* << CC_SETUP >> msg.              */
                                            /* for External Call & Internal Call*/

                                            /* Assembly the setup frame !       */
            temp = Construct_MNCC_Primitive();
			   temp = Add_IE_2(temp, RELEASE_REASON, PARAMETER2 );

            if (G_PTR != NULL) {
               #ifdef CAT_IQ2_1
               temp = Add_TRANSPARENT(temp, G_PTR);
               #else
               temp = Add_PROPRIETARY(temp, G_PTR);
               #endif
               Mmu_Free(G_PTR);
            }

            if(PARAMETER2 != 0x41){
               Send_To_NTW_Layer(PARAMETER1,
                                 CC,
                                 CC_MNCCS_RELEASE_RQ_SWI,
                                 temp,
                                 TRUE,    // TODO: hiryu080109 check why true setting ????
                                 0, // IWU = 0
                                 FP_RELEASE_IN_CC,
                                 CurrentInc); // It should be replaced to po_no if fail by time out
            } else {
               Send_To_NTW_Layer(PARAMETER1,
                                 CC,
                                 CC_MNCCS_REJECT_RQ_SWI,
                                 temp,
                                 TRUE,      // TODO: hiryu080109 check why true setting ????
                                 0, // IWU = 0
                                 FP_RELEASE_IN_CC,
                                 CurrentInc); // It should be replaced to po_no if fail by time out
            }
         }
         break;

      case FP_CC_REJECT_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = IE memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = Reason
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                            /* The function forwards the        */
                                            /* << CC_SETUP >> msg.              */
                                            /* for External Call & Internal Call*/

                                            /* Assembly the setup frame !       */
            temp = Construct_MNCC_Primitive();

            temp = Add_IE_2(temp, RELEASE_REASON, PARAMETER2);
            if (G_PTR != NULL) {
               #ifdef CAT_IQ2_1
               temp = Add_TRANSPARENT(temp, G_PTR);
               #else
               temp = Add_PROPRIETARY(temp, G_PTR);
               #endif
               Mmu_Free(G_PTR);
            }

            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_MNCCS_REJECT_RQ_SWI,
                              temp,
                              TRUE,      // TODO: hiryu080109 check why true setting ????
                              0, // IWU = 0
                              FP_RELEASE_IN_CC,
                              CurrentInc); // It should be replaced to po_no if fail by time out
         }
         break;

      case FP_CC_INFO_BYPASS_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = CC_INFO Info memory block(Bypassing)
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         if(G_PTR != NULL)
         {
            Send_To_NTW_Layer(PARAMETER1,
                              CC,
                              CC_MNCCS_INFO_RQ_SWI,
                              G_PTR,
                              FALSE,
                              0, // IWU = 0
                              FP_RELEASE_IN_CC,
                              CurrentInc); // It should be replaced to po_no if fail by time out
         }
         break;

      #ifdef DECT_NG
      case FP_CC_SERVICE_CHANGE_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = CC_SERVICE_CHANGE Info memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         #if 0
         mcei_1 = Get_Assigned_CID(PARAMETER1);
         write_to_hmac_ioctl(HMAC, MAC_DISABLE_VOICE_EXTERNAL_SWI
                             ,mcei_1, mcei_1, 0, 0
                             ,0, 0, 0, 0);
         #endif
                                   /* The function forwards the        */
                                   /* << CC_SERVICE_CHANGE >> msg.              */

                                   /* Assembly the SERVICE_CHANGE frame !       */
         temp = Construct_MNCC_Primitive();
                                   /* Portable identity is mandatory IE !       */
         temp = Add_PORTABLE_IDENTITY(PARAMETER1, temp, IDENTITY_TYP_IPUI);

         #ifdef ULE_SUPPORT
            #ifdef KLOCWORK
         if(VALID_PORTABLE_DECT(PARAMETER1, PORTABLE_DECT))
            #else
         if (IsValidPortableNo(PARAMETER1, PORTABLE_DECT)) // Normal Poratable Device
         #endif
         #endif
         {
                                   /* Service change info is mandatory IE !     */
                                  /********************************************
                                   (1)   16 : SERVICE_CHANGE_INFO
                                   --------------------------------------------
                                   (2)   01 : length(01)
                                   (3)   8D : DECT standar coding(00),initiate side is master(0)
                                                 /Change mode=Audio codec change(1101
                                   ********************************************/
            temp = Add_IE_3(temp, SERVICE_CHANGE_INFO, 1,  0x0D |0x80);

            /* Add IE <<CODEC_LIST>> to negotiate CODEC according to NG */
            #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
            if ((PARAMETER3 != DUMMY_FILL) && (Get_Terminal_Cap(PARAMETER1) == 1)) {
            #else
            if ((PARAMETER3 != DUMMY_FILL) && (Terminal_Cap[PARAMETER1 - 1] == 1)) {
            #endif
	            if ((PARAMETER3 == 0) || (PARAMETER3 == CODEC_G722) || (PARAMETER3 == CODEC_G726)) {
                  temp_prop = Get_Codec_List(PARAMETER3);
                  temp = Add_CODEC_LIST(temp, temp_prop);
                  Mmu_Free(temp_prop);
	            }
            }
			}

         #ifdef CAT_IQ2_1
         if (G_PTR != NULL) {
            temp = Add_TRANSPARENT(temp, G_PTR);
            Mmu_Free(G_PTR);
         }
         #elif defined(ULE_SUPPORT)
         if (G_PTR != NULL) {
            #ifdef KLOCWORK
            if(VALID_PORTABLE_ULE(PARAMETER1, PORTABLE_ULE))
            #else
            if (IsValidPortableNo(PARAMETER1, PORTABLE_ULE))
            #endif
            {
               temp = Add_TRANSPARENT(temp, G_PTR);
            }
            Mmu_Free(G_PTR);
         }
         #endif
         
			#ifdef ULE_SUPPORT
            #ifdef KLOCWORK
         if(VALID_PORTABLE_ULE(PARAMETER1, PORTABLE_ULE)) {
            #else
         if (IsValidPortableNo(PARAMETER1, PORTABLE_ULE)) { // ULE device
            #endif
            temp = Add_ULE_MAC_INFO(PARAMETER1, temp);
         }
			#endif
         
         Send_To_NTW_Layer(PARAMETER1,
                           CC,
                           CC_MNCCS_SERVICE_CHANGE_RQ_SWI,
                           temp,
                           FALSE,
                           0, // IWU = 0
                           FP_RELEASE_IN_CC,
                           CurrentInc); // It should be replaced to po_no if fail by time out
         break;

      case FP_CC_SERVICE_ACCEPT_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = CC_SERVICE_ACCEPT Info memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
                                      /* The function forwards the        */
                                      /* << CC_SERVICE_ACCEPT >> msg.              */

                                      /* Assembly the SERVICE_ACCEPT frame !       */
         temp = Construct_MNCC_Primitive();
         #ifdef CAT_IQ2_1
         if (G_PTR != NULL) {
            temp = Add_TRANSPARENT(temp, G_PTR);
            Mmu_Free(G_PTR);
         }
         #elif defined(ULE_SUPPORT)
         if (G_PTR != NULL) {
            #ifdef KLOCWORK
            if(VALID_PORTABLE_ULE(PARAMETER1, PORTABLE_ULE))
            #else
            if (IsValidPortableNo(PARAMETER1, PORTABLE_ULE))
            #endif
            {
               temp = Add_TRANSPARENT(temp, G_PTR);
            }
            Mmu_Free(G_PTR);
         }
         #endif

         #ifdef ULE_SUPPORT
            #ifdef KLOCWORK
         if(VALID_PORTABLE_ULE(PARAMETER1, PORTABLE_ULE)) {
            #else
         if (IsValidPortableNo(PARAMETER1, PORTABLE_ULE)) { // ULE device
            #endif
            temp = Add_ULE_MAC_INFO(PARAMETER1, temp);
         }
         #endif

         Send_To_NTW_Layer(PARAMETER1,
                           CC,
                           CC_MNCCS_SERVICE_ACCEPT_RQ_SWI,
                           temp,
                           FALSE,
                           0, // IWU = 0
                           FP_RELEASE_IN_CC,
                           CurrentInc); // It should be replaced to po_no if fail by time out
         break;

      case FP_CC_SERVICE_REJECT_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = CC_SERVICE_REJECT Info memory block
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
                                   /* The function forwards the        */
                                   /* << CC_SERVICE_REJECT >> msg.              */

                                   /* Assembly the SERVICE_REJECT frame !       */
         temp = Construct_MNCC_Primitive();
         #ifdef CAT_IQ2_1
         if (G_PTR != NULL) {
            temp = Add_TRANSPARENT(temp, G_PTR);
            Mmu_Free(G_PTR);
         }
         #elif defined(ULE_SUPPORT)
         if (G_PTR != NULL) {
            #ifdef KLOCWORK
            if(VALID_PORTABLE_ULE(PARAMETER1, PORTABLE_ULE))
            #else
            if (IsValidPortableNo(PARAMETER1, PORTABLE_ULE))
            #endif
            {
               temp = Add_TRANSPARENT(temp, G_PTR);
            }
            Mmu_Free(G_PTR);
         }
         #endif
         Send_To_NTW_Layer(PARAMETER1,
                           CC,
                           CC_MNCCS_SERVICE_REJECT_RQ_SWI,
                           temp,
                           FALSE,
                           0, // IWU = 0
                           FP_RELEASE_IN_CC,
                           CurrentInc); // It should be replaced to po_no if fail by time out
         break;
      #endif

      case FP_ME_RFP_LOAD_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = n.u
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         KNL_SENDTASK(ME, ME_RFP_PRELOAD_DIS);
         break;

      case FP_MM_INFO_SUGGEST_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         Send_To_NTW_Layer(PARAMETER1,
                           MM,
                           MM_MMS_INFO_SUGGEST_RQ,
                           NULL,
                           FALSE,
                           0xFF,
                           0xFF,
                           CurrentInc);
         break;

      case FP_MM_ACCESS_RIGHTS_TERMINATE_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         Send_To_NTW_Layer(PARAMETER1,
                           MM,
                           MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ,
                           NULL,
                           FALSE,
                           0, // IWU = 0
                           FP_ACCESS_RIGHTS_TERMINATE_CFM_MM,
                           CurrentInc); // It should be replaced to po_no if fail by time out
         break;

      case FP_MM_ACCESS_CODE_LOAD_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = AC memory block(limited upto 8 digits)
         // PARAMETER1 = n.u
         // PARAMETER2 = AC counter(number of AC deliverd..normal 4..8)
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
            BYTE i, ac_len=4;
            #ifdef KLOCWORK
            if(G_PTR == NULL) {
               break;
            }
            #endif

            if (PARAMETER2!=0) {
               ac_len = PARAMETER2 % 9;
            }
            for (i = 0;  i < ac_len; i++) {
               Set_AC(G_PTR[i], i);
            }
         }
         break;

      case   FP_MM_CIPHER_ON_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR = n.u
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
                         /* The function invokes the         */
                         /* Cipher Switching On Procedure.   */
         #ifdef CONFIG_TEST_CC_ENCRYPTION
         Send_Message_To_APP(FP_CIPHER_ON_CFM_MM,
                             NULL,
                             CurrentInc,
                             PARAMETER1,
                             TRUE,
                             DUMMY_FILL,
                             DUMMY_FILL);
         #else
         Send_To_NTW_Layer(PARAMETER1,
                           MM,
                           MM_MMS_CIPHER_ON_RQ,
                           NULL,
                           FALSE,
                           0, // IWU = 0
                           FP_CIPHER_ON_CFM_MM,
                           CurrentInc); // It should be replaced to po_no if fail by time out
         #endif
         break;

      case   FP_MM_CIPHER_OFF_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR = n.u
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         /* The function invokes the         */
         /* Cipher Switching Off Procedure.   */
         Send_To_NTW_Layer(PARAMETER1,
                           MM,
                           MM_MMS_CIPHER_OFF_RQ,
                           NULL,
                           FALSE,
                           0, // IWU = 0
                           FP_CIPHER_OFF_CFM_MM,
                           CurrentInc); // It should be replaced to po_no if fail by time out
         break;

      case FP_MM_IDENTITY_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR = n.u
         // PARAMETER1 = n.u
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         // Only for the TBR22 test case..(TC_FT_MM_BV_ID_01 / TC_FT_MM_TI_01)
         KNL_SENDTASK_WP_INC(MM, MM_MMS_KEY_ALLOCATION_RQ, 0xFF, 0xFF, 0xFF, 1, 0); //(test PP should be the HS=1, CID =0(first assigned))
         break;

      #if 1  // AUTH_PT_BEFORE_CIPHERING
      case FP_MM_AUTH_PT_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR = n.u
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = DCK-CCM flag
         //////////////////////////////////////////////////////////////////////////
         {
            // This invokes the Authentication of PT procedure
            #ifdef ULE_SUPPORT
            if (PARAMETER4 == 1) {
               Send_To_NTW_Layer(PARAMETER1,
                                 MM,
                                 MM_MMS_AUTHENTICATE_PT_FOR_DCKCCM_RQ,
                                 NULL,
                                 FALSE,
                                 0, // IWU = 0
                                 FP_AUTHENTICATE_PT_CFM_MM,
                                 CurrentInc); //PARAMETER1); // It should be replaced to po_no if fail by time out
            } else
            #endif
            {
               #ifdef CONFIG_TEST_CC_ENCRYPTION
               Send_Message_To_APP(FP_AUTHENTICATE_PT_CFM_MM,
                                   NULL,
                                   CurrentInc,
                                   PARAMETER1,
                                   TRUE,
                                   DUMMY_FILL,
                                   DUMMY_FILL);
               #else
               Send_To_NTW_Layer(PARAMETER1,
                                 MM,
                                 MM_MMS_AUTHENTICATE_PT_RQ,
                                 NULL,
                                 FALSE,
                                 0, // IWU = 0
                                 FP_AUTHENTICATE_PT_CFM_MM,
                                 CurrentInc); //PARAMETER1); // It should be replaced to po_no if fail by time out
               #endif
            }
         }
         break;

      case FP_MM_AUTH_USER_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR = n.u
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
            // This invokes the Authentication of User procedure
            Send_To_NTW_Layer(PARAMETER1,
                              MM,
                              MM_MMS_AUTHENTICATE_USER_RQ,
                              NULL,
                              FALSE,
                              0, // IWU = 0
                              FP_AUTHENTICATE_USER_CFM_MM,
                              CurrentInc); //PARAMETER1); // It should be replaced to po_no if fail by time out
         }
         break;

      #else
      case FP_MM_AUTH_PT_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR = n.u
         // PARAMETER1 = n.u
         // PARAMETER2 = n.u
         //////////////////////////////////////////////////////////////////////////
         // Only for the TBR22 test case..(TC_FT_MM_BV_AU_01 / TC_FT_MM_TI_02)
         KNL_SENDTASK_WP_INC(MM, MM_MMS_AUTHENTICATE_PT_RQ, 0xFF, 0xFF, 0xFF, 1, 0); //(test PP should be the HS=1, CID =0(first assigned))
         break;

      case FP_MM_AUTH_USER_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR = n.u
         // PARAMETER1 = n.u
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         // Only for the TBR22 test case..(TC_FT_MM_BV_AU_03 / TC_FT_MM_TI_03)
         KNL_SENDTASK_WP_INC(MM, MM_MMS_AUTHENTICATE_USER_RQ, 0xFF, 0xFF, 0xFF, 1, 0); //(test PP should be the HS=1, CID =0(first assigned))
         break;
      #endif

      case FP_MM_KEY_ALLOC_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR = n.u
         // PARAMETER1 = n.u
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         // Only for the TBR22 test case..(TC_FT_MM_BV_KA_01 & 02 / TC_FT_MM_TI_05)
         KNL_SENDTASK_WP_INC(MM, MM_MMS_KEY_ALLOCATION_RQ, 0xFF, 0xFF, 0xFF, 1, 0); //(test PP should be the HS=1, CID =0(first assigned))
         break;

      case FP_ME_REGISTRATION_RESET_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = n.u
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         KNL_SENDTASK(ME, ME_SET_TO_DEFAULT_RQ_MEM);
         break;

      case FP_ME_A44_SET_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = n.u
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         KNL_SENDTASK(ME, ME_A44_SET_RQ_DIS);
         break;

      case FP_ME_A44_CLEAR_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = n.u
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         KNL_SENDTASK(ME, ME_A44_CLEAR_RQ_DIS);
         break;

      #ifdef CATIQ_NOEMO
      case FP_ME_MAC_NOEMO_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = status
         // PARAMETER2 = channel
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         KNL_SENDTASK_WP(ME, ME_MAC_NOEMO_RQ, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
         break;
      #endif

      #ifdef ULE_SUPPORT
      case FP_ULE_SERVICE_RESUME_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR       = n.u
         // PARAMETER1 = po_no
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         Subscription_SetResumesULENWK(YES, PARAMETER1);
         break;

      case FP_ULE_SERVICE_SUSPEND_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR       = n.u
         // PARAMETER1 = po_no
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         Subscription_SetResumesULENWK(NO, PARAMETER1);
         break;

      case FP_ULE_TEMP_SUB_UPDATE_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR       = FT_SUBSCRIPTION structure data
         // PARAMETER1 = po_no
         // PARAMETER2 = updatedParametersFlag - bitwise flag
         //              .lastSSN[6] - 0x01
         //              .lastRSN[6] - 0x02
         //              .ULEType    - 0x04
         //              .SDUSize    - 0x08
         //              .windowSize - 0x10
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         Subscription_SetULEParameters(((DATA_FRAME *)G_PTR)->dat, PARAMETER2, PARAMETER1);
         Mmu_Free(G_PTR);
      	break;

      case FP_ULE_DEVICE_TYPE_UPDATE_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR       = FT_SUBSCRIPTION structure data
         // PARAMETER1 = portableNo
         // PARAMETER2 = deviceType
         // PARAMETER3 = deviceNo - Bitoffset
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         Subscription_SetULEType(PARAMETER2, PARAMETER3, PARAMETER1);
         break;
      #endif

      case FP_MAC_ENABLE_VOICE_EXTERNAL_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                                 /* Convert party_a -> mcei 1        */
                                                 /* Convert party_b -> mcei 2        */
                                                 /* Note: CID = MCEI !               */
            mcei_1 = Get_Assigned_CID(PARAMETER1);
                                                 /* Note: in case a protocol stem    */
                                                 /* has been already released the    */
                                                 /* MCEI is 0xFF                     */

            if (mcei_1 < MAX_MCEI) {         // Protection for invalid memory access
               Current_Tapi_Ch1[mcei_1] = PARAMETER2;
            }
            write_to_hmac_ioctl(HMAC, MAC_ENABLE_VOICE_EXTERNAL_SWI
                               ,mcei_1, PARAMETER2, 0, 0
                               ,0, 0, 0, 0);
         }
         break;

      case FP_MAC_DISABLE_VOICE_EXTERNAL_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                                /* Convert party_a -> mcei 1        */
                                                /* Convert party_b -> mcei 2        */
                                                /* Note: CID = MCEI !               */
            mcei_1 = Get_Assigned_CID(PARAMETER1);
            if (mcei_1 < MAX_MCEI) {        // Protection for invalid memory access
               Current_Tapi_Ch1[mcei_1] = 0xFF;
            }
                                                /* Note: in case a protocol stem    */
                                                /* has been already released the    */
                                                /* MCEI is 0xFF                     */
  
            write_to_hmac_ioctl(HMAC, MAC_DISABLE_VOICE_EXTERNAL_SWI
                                ,mcei_1, PARAMETER2, 0, 0
                                ,0, 0, 0, 0);
         }
         break;
      #ifdef CATIQ_UPLANE
      case FP_MAC_ENABLE_DATA_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                                 /* Convert party_a -> mcei 1        */
                                                 /* Convert party_b -> mcei 2        */
                                                 /* Note: CID = MCEI !               */
            mcei_1 = Get_Assigned_CID(PARAMETER1);
                                                 /* Note: in case a protocol stem    */
                                                 /* has been already released the    */
                                                 /* MCEI is 0xFF                     */

            if (mcei_1 < MAX_MCEI) { // Protection for invalid memory access
               Current_Tapi_Ch1[mcei_1] = PARAMETER2;
            }
            write_to_hmac_ioctl(HMAC, MAC_ENABLE_VOICE_EXTERNAL_SWI
                                ,mcei_1, 0xFF, 1, 0
                                ,0, 0, 0, 0);
            InitLlnUPlane(mcei_1);
         }
         break;

      case FP_MAC_DISABLE_DATA_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                                 /* Convert party_a -> mcei 1        */
                                                 /* Convert party_b -> mcei 2        */
                                                 /* Note: CID = MCEI !               */
            mcei_1 = Get_Assigned_CID(PARAMETER1);
            if (mcei_1 < MAX_MCEI) { // Protection for invalid memory access
               Current_Tapi_Ch1[mcei_1] = 0xFF;
            }
                                                 /* Note: in case a protocol stem    */
                                                 /* has been already released the    */
                                                 /* MCEI is 0xFF                     */
            DeInitLlnUPlane(mcei_1);

             write_to_hmac_ioctl(HMAC, MAC_DISABLE_VOICE_EXTERNAL_SWI
                                 ,mcei_1, PARAMETER2, 1, 0
                                 ,0, 0, 0, 0);
         }
         break;
      #endif

      case FP_MAC_ENABLE_VOICE_INTERNAL_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = Po_no(currentInc + 1), own
         // PARAMETER2 = Other party(po_no)
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                         /* Convert party_a -> mcei 1        */
                                         /* Convert party_b -> mcei 2        */
                                         /* Note: CID = MCEI !               */
            mcei_1 = Get_Assigned_CID(PARAMETER1);
            mcei_2 = Get_Assigned_CID(PARAMETER2);
                                         /* Note: in case a protocol stem    */
                                         /* has been already released the    */
                                         /* MCEI is 0xFF                     */

            write_to_hmac_ioctl(HMAC, MAC_ENABLE_VOICE_INTERNAL_SWI
                                ,mcei_1, mcei_2, 0, 0
                                ,0, 0, 0, 0);
         }
         break;

      case FP_MAC_DISABLE_VOICE_INTERNAL_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = Po_no(currentInc + 1), own
         // PARAMETER2 = Other party(po_no)
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
                                             /* Convert party_a -> mcei 1        */
                                             /* Convert party_b -> mcei 2        */
                                             /* Note: CID = MCEI !               */
            mcei_1 = Get_Assigned_CID(PARAMETER1);
            mcei_2 = Get_Assigned_CID(PARAMETER2);
                                             /* Note: in case a protocol stem    */
                                             /* has been already released the    */
                                             /* MCEI is 0xFF                     */

            write_to_hmac_ioctl(HMAC, MAC_DISABLE_VOICE_INTERNAL_SWI
                                ,mcei_1, mcei_2, 0, 0
                                ,0, 0, 0, 0);
         }
         break;

      case FP_MAC_ENABLE_VOICE_CONFERENCE_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = Po_no(currentInc + 1), own
         // PARAMETER2 = Other party(po_no)
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         {
            // EnableVoice2();
                                             /* Convert party_a -> mcei 1        */
                                             /* Convert party_b -> mcei 2        */
                                             /* Note: CID = MCEI !               */
            mcei_1 = Get_Assigned_CID(PARAMETER1);
            mcei_2 = Get_Assigned_CID(PARAMETER2);
                                             /* Note: in case a protocol stem    */
                                             /* has been already released the    */
                                             /* MCEI is 0xFF                     */
            write_to_hmac_ioctl(HMAC, MAC_ENABLE_VOICE_CONFERENCE_SWI
                                ,mcei_1, mcei_2, 0, 0
                                ,0, 0, 0, 0);
         }
         break;


      case FP_MAC_DISABLE_VOICE_CONFERENCE_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = Po_no(currentInc + 1), own
         // PARAMETER2 = Other party(po_no)
         //////////////////////////////////////////////////////////////////////////
         {
                                             /* Convert party_a -> mcei 1        */
                                             /* Convert party_b -> mcei 2        */
                                             /* Note: CID = MCEI !               */
            mcei_1 = Get_Assigned_CID(PARAMETER1);
            mcei_2 = Get_Assigned_CID(PARAMETER2);
                                             /* Note: in case a protocol stem    */
                                             /* has been already released the    */
                                             /* MCEI is 0xFF                     */
            write_to_hmac_ioctl(HMAC, MAC_DISABLE_VOICE_CONFERENCE_SWI
                                ,mcei_1, mcei_2, 0, 0
                                ,0, 0, 0, 0);
         }
         break;

      case FP_MAC_PAGE_CANCEL_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = n.u
         // PARAMETER2 = n.u
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
         write_to_hmac_ioctl(HMAC, MAC_PAGE_CANCEL_LB
                             ,0, 0, 0, 0
                             ,0, 0, 0, 0);

         break;

      #ifdef DECT_NG
      case  FP_MAC_SLOTTYPE_MOD_RQ:
         //////////////////////////////////////////////////////////////////////////
         // GPTR            = n.u
         // PARAMETER1 = Po_no(currentInc + 1)
         // PARAMETER2 = SLOT_TYPE(1:LONG_SLOT, 0:FULL_SLOT)
         // PARAMETER3 = n.u
         // PARAMETER4 = n.u
         //////////////////////////////////////////////////////////////////////////
		   mcei_1 = Get_Assigned_CID(PARAMETER1);
         /*
         KNL_SENDTASK_WP(HMAC,
                         MAC_SLOTTYPE_MOD_RQ_SWI,
                         mcei_1, //P1
                         0,
                         0,
                         PARAMETER2);
         */
         DECT_DEBUG_USER_CP_DATA("[CP] Slot Mode Req: MCEI: %02x\n", mcei_1);

         write_to_hmac_ioctl(HMAC, MAC_SLOTTYPE_MOD_RQ_SWI
                             ,mcei_1, 0, 0, PARAMETER2
                             ,0, 0, 0, 0);
   	   break;
      #endif

      #ifdef __PIN_CODE__
      case FP_PIN_CH_RQ:
			{
            // char szPin[9] = {0};
            // strcpy(szPin,G_PTR);
            #if 0
            szPin[0] = PARAMETER1 ;
            szPin[1] = PARAMETER2 ;
            szPin[2] = PARAMETER3 ;
            szPin[3] = PARAMETER4 ;
            #endif
            #ifdef KLOCWORK
            if(G_PTR == NULL) {
               break;
            }
            #endif
				IFX_DECT_ST_SetPinCode((char*)G_PTR);
			}
			break;
      #endif

      /* debug infomation request */
      case FP_DEBUG_INFO_RQ:
   		//////////////////////////////////////////////////////////////////////////
   		// GPTR 	  = DEBUG MESSAGE
   		// PARAMETER1 = HANDSET NO
   		// PARAMETER2 = DEBUG INFO ID
   		//			enum {
   		//				BMC_REGISTER_READ_REQ = 0x01,
   		// 				BMC_BEARER_READ_REQ,
   		//				MEMORY_INFOMATION,
   		//				PATCH_RAM_INFORMATION,
   		//				DEBUG_MSSAGE_INFORMATION,
   		//			} DEBUG_INFO_ID;
   		// PARAMETER3 = READ  / WRITE INDICATOR
   		// PARAMETER4 = n.u
   		//////////////////////////////////////////////////////////////////////////
         #ifdef KLOCWORK
         if(G_PTR == NULL) {
            break;
         }
         #endif
         DECT_DEBUG_USER_CP_DATA("[CP] Debug Info Req: Data: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n",
                                 G_PTR[0], G_PTR[1], G_PTR[2], G_PTR[3], G_PTR[4], G_PTR[5], G_PTR[6], G_PTR[7], G_PTR[8], G_PTR[9],
                                 G_PTR[10], G_PTR[11], G_PTR[12], G_PTR[13], G_PTR[14]);

         if ((PARAMETER2 == BMC_REGISTER_READ_REQ) && (PARAMETER3 == 1)) {
            cur_index = 0;
            osc_trim_flag = 0;
            osc_index = 0;
            while (cur_index < 40) {
               switch(G_PTR[cur_index]) {
                  case  BMC_REGISTER:
                        cur_index += 15;
                        break;

                  case  OSC_TRIMMING_VAL:
                        osc_trim_flag = 1;
                        osc_index = cur_index;

                  case  GFSK_VALUE:
                        cur_index += 3;
                        break;

                  case  RF_TEST_MODE_SET:
                  case  SPI_SETUP_PACKET:
                        cur_index += 4;
                        break;

                  case  DEBUG_MESSAGE_ONOFF:
                        cur_index += 2;
                        break;

                  default:
                        cur_index++;
                        break;
               }
            }

            if (osc_trim_flag == 1) {
               if (Osc_Trimming_Mode == FALSE) {
                  unsigned char  dummy_data[2];
                  dummy_data[0] = 1;
                  dummy_data[1] = 1;
                  trigger_cosic_driver_for_osc(dummy_data);
                  Osc_Trimming_Mode = TRUE;
               }

               write_to_hmac_ioctl(HMAC, MAC_OSC_SET_RQ_ME,
                                   G_PTR[osc_index + 1], G_PTR[osc_index + 2], 0, 1,
                                   0, 0, 0, 0);

               cur_index = osc_index;
               do {
                  G_PTR[cur_index] = G_PTR[cur_index + 3];
                  cur_index++;
               } while(cur_index < 40);

               while(cur_index < 43) {
                  G_PTR[cur_index++] = 0x00;
               }

               DECT_DEBUG_USER_CP_DATA("[CP] Modified Debug Info Req: Data: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n",
                                       G_PTR[0], G_PTR[1], G_PTR[2], G_PTR[3], G_PTR[4], G_PTR[5], G_PTR[6], G_PTR[7], G_PTR[8], G_PTR[9],
                                       G_PTR[10], G_PTR[11], G_PTR[12], G_PTR[13], G_PTR[14]);

               osc_trim_flag = 0;
               for (cur_index = 0; cur_index < 43; cur_index++) {
                  if (G_PTR[cur_index] != 0x00) {
                     osc_trim_flag = 1;
                  }
               }
               if (osc_trim_flag == 0) {
                  break;
               }
            }
         }
		   wrtie_to_debug_info_ioctl(PARAMETER2, PARAMETER3, CurrentInc, G_PTR);
		   break;

	   /* Qt Message Modification request */
	   case FP_ME_QT_SET_RQ:
   		//////////////////////////////////////////////////////////////////////////
   		// GPTR 	  = Qt Message Contents
   		// PARAMETER1 = Handset No
   		// PARAMETER2 = Qt Message Type
   		//			enum {
   		//				Q0_MESSAGE = 0x00,
   		// 			Q3_MESSAGE,
   		//				Q6_MESSAGE,
   		//				Q4_MESSAGE,
   		//				QC_MESSAGE,
   		//			} QT_MESSAGE_ID;
   		// PARAMETER3 = n.u
   		// PARAMETER4 = n.u
   		//////////////////////////////////////////////////////////////////////////
         if (IFX_DBGA_GetStackModuleDebugID() & IFX_DECT_STACK_DEBUG_ID_CP_DATA) {
            printf("[CP] ");
			#ifdef KLOCWORK
			if(G_PTR != NULL)
			#endif
			{
               switch (PARAMETER2) {
                  case 0: printf("Q0: %02x %02x %02x %02x %02x\n", G_PTR[1], G_PTR[2], G_PTR[3], G_PTR[4], G_PTR[5]); break;
                  case 1: printf("Q3: %02x %02x %02x %02x %02x\n", G_PTR[1], G_PTR[2], G_PTR[3], G_PTR[4], G_PTR[5]); break;
                  case 2: printf("Q6: %02x %02x %02x %02x %02x\n", G_PTR[1], G_PTR[2], G_PTR[3], G_PTR[4], G_PTR[5]); break;
                  case 3: printf("Q4: %02x %02x %02x %02x %02x\n", G_PTR[1], G_PTR[2], G_PTR[3], G_PTR[4], G_PTR[5]); break;
                  case 4: printf("Qc: %02x %02x %02x %02x %02x\n", G_PTR[1], G_PTR[2], G_PTR[3], G_PTR[4], G_PTR[5]); break;
               }
			}
         }

         #ifdef xxxCONFIG_REPEATER_SUPPORT
         if (PARAMETER2 == 3) {
            if ((G_PTR[1] & 0x0C) == 0x0C) {
               Feature_Repeater = 0;
            } else {
               Feature_Repeater = 1;
            }
         }
         #endif
         write_to_hmac_ioctl(HMAC, MAC_QT_SET_RQ_ME,
                             PARAMETER2, 0, 0, 0,
                             0, 5, &G_PTR[1], 0);
   		break;

	   /* TBR6 mode activate setting */
	   case FP_TBR6_ACTIVATE_RQ:
   		//////////////////////////////////////////////////////////////////////////
   		// GPTR 	  = N.U
   		// PARAMETER1 = TBR6 TEST MODE SETING (1 : 0N / 0: OFF)
   		// PARAMETER2 = N.U
   		// PARAMETER3 = N.U
   		// PARAMETER4 = n.u
   		//////////////////////////////////////////////////////////////////////////

         if (MAC_Test_Mode) { //  test mode ?
            if (!PARAMETER1) { // if TBR6 mode off
               MAC_Test_Mode = 0;
               write_to_hmac_ioctl(HMAC, MAC_SOFT_RESET_RQ_LMAC
                                   ,0, 0, 0, 0
                                   ,0, 0, 0, 0);
            }
         } else {
      		if (PARAMETER1) { //  if  TBR6 mode on
      			MAC_Test_Mode = 1;
      			write_to_hmac_ioctl(HMAC, MAC_SOFT_RESET_RQ_LMAC
      					  ,0, 0, 0, 0
      					  ,0, 0, 0, 0);
      		}
      	}
      	break;

      /* SOFTWARE RESET */
      case FP_SOFTWARE_RESET_RQ:
         write_to_hmac_ioctl(HMAC, MAC_SOFT_RESET_RQ_LMAC
                             ,0, 0, 0, 0
                             ,0, 0, 0, 0);
         break;

      case FP_HARDWARE_RESET_RQ:
         write_to_hmac_ioctl(HMAC, MAC_HARD_RESET_RQ_LMAC
                             ,0, 0, 0, 0
                             ,0, 0, 0, 0);
         break;

      #ifdef CAT_IQ2_1
      case FP_MM_MODEL_ID_SET_RQ:
         if((PARAMETER1 != 0) && (PARAMETER2 != 0)) {
            First_EMC_Code = (WORD)(PARAMETER2 << 8) + PARAMETER1;
         }
         Model_ID = PARAMETER3;
         break;
      #endif

      default:
         Mmu_Free(G_PTR);
         break;
   }
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Send_Message_To_APP ()                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Send Task Message to Application Layer.             *
*   Parms      :  parameter1= , parameter2=         *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef TEMP_AGENT_REMOVE
EXPORT BIT
Send_Message_To_APP(BYTE msg, FPTR ptr, BYTE inc, BYTE parameter1,  BYTE parameter2,  BYTE parameter3,  BYTE parameter4)
{
   BYTE data_len;
   BYTE po_no, mcei, tapi_ch;
   BYTE mcei_1;
   FPTR temp;

   po_no = 1;
   switch (to_agent_write_buf.ucMsgId) {
      case FP_SETUP_IN_CC:
         /* The function forwards the <<CC_SETUP>> msg.  */
         /* for External Call & Internal Call.           */

         /* Assembly the setup frame !                   */
         temp = Construct_MNCC_Primitive();
#error
         Send_To_NTW_Layer(po_no,
                           CC,
                           CC_MNCCS_CONNECT_RQ_SWI,
                           temp,
                           FALSE,
                           0,
                           FP_RELEASE_IN_CC,
                           to_agent_write_buf.ucInstance);

         /* Convert party_a -> mcei 1.                   */
         /* Note: CID = MCEI !                           */
         mcei_1 = Get_Assigned_CID(po_no);
         tapi_ch = 0;


         /* Send Mcei number and TAPI channel number to HMAC directly */
         write_to_hmac_ioctl(HMAC, MAC_ENABLE_VOICE_EXTERNAL_SWI,
                              mcei_1, tapi_ch, 0, 0, 0, 0, 0, 0);
         break;
#error
      case FP_RELEASE_IN_CC:
         /* Convert party_a -> mcei 1.                   */
         /* Note: CID = MCEI !                           */
         mcei_1 = Get_Assigned_CID(po_no);
         tapi_ch = 0;

         /* Send Mcei number and TAPI channel number to HMAC directly */
         write_to_hmac_ioctl(HMAC, MAC_DISABLE_VOICE_EXTERNAL_SWI,
                              mcei_1, tapi_ch, 0, 0, 0, 0, 0, 0);
         break;

      default:
         /* No need further actions for this message.    */
         break;
   }

   Mmu_Free(ptr);
   return TRUE;
}
#else
/* Add here new definition for External Network Interface */

EXPORT BIT
Send_Message_To_APP(BYTE msg, FPTR ptr, BYTE inc, BYTE parameter1,  BYTE parameter2,  BYTE parameter3,  BYTE parameter4)
{
   BYTE data_len = 0;
   BYTE mcei_1;

   #ifdef DECT_DEBUG_USER_APP_PRIMITIVE
   DECT_DEBUG_USER_APP_PRIMITIVE("%s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(msg, appMessageStringTable), inc,
                                parameter1, parameter2, parameter3, parameter4);
   #endif

   memset((unsigned char*)&vxStack2AppMsg, 0x00, sizeof(x_IFX_DECT_IPC_Msg));

   vxStack2AppMsg.ucMsgId = msg;
   vxStack2AppMsg.ucInstance = inc;
   vxStack2AppMsg.ucPara1 = parameter1;
   vxStack2AppMsg.ucPara2 = parameter2;
   vxStack2AppMsg.ucPara3 = parameter3;
   vxStack2AppMsg.ucPara4 = parameter4;

   if(msg == FP_RELEASE_IN_CC)
   {
		mcei_1 = Get_Assigned_CID(parameter1);
										   /* Note: in case a protocol stem    */
										   /* has been already released the    */
										   /* MCEI is 0xFF					   */

      #if 1  // TODOJonathan
      if(mcei_1 < MAX_MCEI)         // Protection for invalid memory access
      {
         Current_Tapi_Ch1[mcei_1] = 0xFF;
      }
      write_to_hmac_ioctl(HMAC, MAC_DISABLE_VOICE_EXTERNAL_SWI,
                           mcei_1, 0xFF, 0, 0,
                           0, 0, 0, 0);
      #endif
   }
   if (ptr != NULL)
   {
	   if(FP_DEBUG_INFO_IND == msg)
	   {
		   memcpy(vxStack2AppMsg.acData, ptr, 43);
	   }
	   else if(msg == FP_MODEM_BOOT_IND)
      {
         memcpy(vxStack2AppMsg.acData, ptr, 10);
      }
	   else
	   {
             #ifdef DECT_DEBUG_USER_APP_PRIMITIVE
             DECT_DEBUG_USER_APP_PRIMITIVE("HLI-length=%02x \n", data_len);
             #endif
             data_len = ((struct HLI_Header *)ptr)->length % (IFX_IPC_DECT_MAX_DATA_SIZE+1);
         // STIW: This looks rather rotten to me,
         // memcpy should rather be:
         // memcpy(to_agent_write_buf.acData,&((struct HLI_Header *)ptr)->length, data_len+1);
	      memcpy(vxStack2AppMsg.acData, ptr, data_len);
	      Mmu_Free(ptr);
	   }
   }
#ifdef SUPERTASK
   iprintf("Calling Message Router Post to Stack\n");
#endif
   IFX_DECT_MsgRt_ProcessStackMessage(IFX_IPC_DECT_C_PLANE,&vxStack2AppMsg);

   return TRUE;
}
#endif
/*
*****************************************************************************
*                                                                           *
*   Function   :  Get_Stack_Library_Version()                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Get the (Stack-library) version                           *
*   Parms      :  none                                                      *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT WORD
Get_Stack_Library_Version(void)
{
   return Library_ver[0];
}

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT void
Set_Service_Change_State(BYTE portableNo, BYTE state)
{
   #ifdef KLOCWORK
   if(VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      Service_Change_State[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE] = state;
   #ifdef KLOCWORK
   } else if(VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      Service_Change_State[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE] = state;
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      Service_Change_State[portableNo-1] = state;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT BYTE
Get_Service_Change_State(BYTE portableNo)
{
   #ifdef KLOCWORK
   if(VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      return Service_Change_State[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE];
   #ifdef KLOCWORK
   } else if(VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      return  Service_Change_State[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE];
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      return Service_Change_State[portableNo-1];
   } else {
      return 0;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT void
Set_Required_Slot_Type(BYTE portableNo, BYTE value)
{
   #ifdef KLOCWORK
   if(VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      Required_Slot_Type[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE] = value;
   #ifdef KLOCWORK
   } else if(VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      Required_Slot_Type[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE] = value;
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      Required_Slot_Type[portableNo-1] = value;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT BYTE
Get_Required_Slot_Type(BYTE portableNo)
{
   #ifdef KLOCWORK
   if(VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      return Required_Slot_Type[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE];
   #ifdef KLOCWORK
   } else if(VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      return Required_Slot_Type[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE];
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      return Required_Slot_Type[portableNo-1];
   } else {
      return 0;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT void
Set_Actual_Slot_Type(BYTE portableNo, BYTE value)
{
   #ifdef KLOCWORK
   if(VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      Actual_Slot_Type[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE] = value;
   #ifdef KLOCWORK
   } else if(VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      Actual_Slot_Type[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE] = value;
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      Actual_Slot_Type[portableNo-1] = value;
   }
}
#endif

#if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
EXPORT BYTE
Get_Actual_Slot_Type(BYTE portableNo)
{
   #ifdef KLOCWORK
   if(VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      return Actual_Slot_Type[portableNo-ULE_DEVICE_OFFSET+NR_OF_PORTABLE];
   #ifdef KLOCWORK
   } else if(VALID_PORTABLE_REP(portableNo, PORTABLE_REP)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_REP)) {
   #endif
      return Actual_Slot_Type[portableNo-REP_DEVICE_OFFSET+NR_OF_PORTABLE+NR_OF_ULE_DEVICE];
   #ifdef KLOCWORK
   } else if (VALID_PORTABLE_DECT(portableNo, PORTABLE_DECT)) {
   #else
   } else if (IsValidPortableNo(portableNo, PORTABLE_DECT)) {
   #endif
      return Actual_Slot_Type[portableNo-1];
   } else {
      return 0;
   }
}
#endif
