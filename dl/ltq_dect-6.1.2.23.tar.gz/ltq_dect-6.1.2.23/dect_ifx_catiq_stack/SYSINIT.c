
# include "SYSDEF.H"

# include "TYPEDEF.H"

# include "FDEF.H"


CODE BYTE subset_version[] = "PROT: FIXED PART";

BYTE XDATA KNL_STATE_ARRAY[PROCMAX][INCMAX];


void KNL_INIT_SYSINT()
{
  BYTE i; 
  BYTE j;

	for ( i = 0; i < PROCMAX; i++ )
			for ( j = 0; j < INCMAX; j++ )
				KNL_STATE_ARRAY[i][j] = 0;

}
