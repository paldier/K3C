/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
*                   (c) 2005 IFX / INTNIX. All rights reserved.               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  P_TIM.C                                                 *
*     Date       :  18 Nov, 2005                                        *
*     Contents   :  Software Timer Table for protocol timers                *
*                                                                           *
*****************************************************************************
*/
   /* ========                                                             */
   /* Includes                                                             */
   /* ========                                                             */
#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#include "FGLOBAL.H"
#include "MM_LIB.H"

#include "FDEF.H"
#include "KNL_SYSTEM.H"
//#include "FMAC_LIB.H"
#include "P_TIM.H"
#ifdef LINUX
#include <sys/select.h>
#include "ifx_common_defs.h"
#include "ifx_os.h"
#include "IFX_DECT_IEParser.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_GlobalInfo.h"
#endif

   /* ==============                                                       */
   /* Local typedefs                                                       */
   /* ==============                                                       */
typedef struct
{
   WORD InitValue;
   BYTE ProcID;
   BYTE MsgID;
} PRO_TIMER_TABLE_ELEMENT;

   /* ===============                                                      */
   /* Local variables                                                      */
   /* ===============                                                      */

                                       /* The flag is incremented every    */
                                       /* << 20ms >> by Timer A.           */
LOCAL XDATA BYTE Pro_Timer_Flag;

                                       /* Every slot of the software       */
                                       /* timer matrix                     */
                                       /* 'Pro_CurrentTimerValue' holds    */
                                       /* the current timer value of a     */
                                       /* running timer.                   */
                                       /* A timer not running is           */
                                       /* determined by a slot entry set   */
                                       /* to zero.                         */
                                       /* The row index of the matrix is   */
                                       /* equal to the different timer     */
                                       /* types supported by this module.  */
                                       /* Every column of the matrix       */
                                       /* supportes a multiple timer       */
                                       /* incarnation of every timer type  */
                                       /* (up to 'INCMAX').                */
LOCAL XDATA WORD Pro_CurrentTimerValue[ INCMAX ][ NR_OF_PRO_TIMERS ];
                                       /* When a timer is started, the     */
                                       /* initialization value is copied   */
                                       /* from the 'Pro_Timer_Table' to    */
                                       /* the 'Pro_CurrentTimerValue'      */
                                       /* matrix.                          */
                                       /* The timer duration is given      */
                                       /* by the following equation:       */
                                       /* Timer A system tick:             */
                                       /* 1 / 9.97 kHz * 0x0028 =          */
                                       /* 4.0120361 ms                     */
                                       /* System tick for Protocol Timer   */
                                       /* Table:                           */
                                       /* 4.0120361 ms * 5 =               */
                                       /* 20.06018                        */
                                       /* ������������������������������Ŀ */
                                       /* ?Duration =                   ?*/
                                       /* ?20.06018ms * (InitValue - 1)?*/
                                       /* �������������������������������� */
                                       /* Additional the table holds the   */
                                       /* process / message ID for every   */
                                       /* timer.                           */
                                       /* The ID's are used for the Task   */
                                       /* Queue entry, when the expiry     */
                                       /* of a timer is reported to the    */
                                       /* the protocol process.            */
                                       /* ==============!!!=============== */
                                       /*            IMPORTANT             */
                                       /* ==============!!!=============== */
                                       /* The timer index of the           */
                                       /* 'Pro_Timer_Table' must           */
                                       /* correspond to the definition in  */
                                       /* the 'P_TIM.H' header file.       */
/*
Sequence Order in the Timer Table:
==================================
��������������������������������������������������Ŀ
?Timer Duration ?   ProcID      ?    MsgID      
����������������������������������������������������
*/
CODE PRO_TIMER_TABLE_ELEMENT Pro_Timer_Table[ NR_OF_PRO_TIMERS ] = {
#ifdef LINUX
/* 0:  2s   TIMER_DL_04                */ { 0x0065, LAP, LAP_TIM_DL_04_EXPIRED              },
								 //{ 0x00CA, LAP, LAP_TIM_DL_04_EXPIRED              },   // 2s -> 4s change 20071226

/* 1:  5s   TIMER_LCE_01               */ { 0x00FB, LCE, LCE_TIM_01_EXPIRED                 },
/* 2:  10s  TIMER_LCE_02               */ { 0x01F5, LCE, LCE_TIM_02_EXPIRED                 },
/* 3:  3s   TIMER_LCE_03               */ { 0x0097, LCE, LCE_TIM_03_EXPIRED                 },
/* 4:  30s  TIMER_LCE_SUPERVISE        */ { 0x05DD, LCE, LCE_TIM_SUPERVISE_EXPIRED          },
/* 5:  20s  TIMER_CC_01                */ { 0x03E9, CC,  CC_TIM_01_EXPIRED                  },
/* 6:  36s  TIMER_CC_02                */ { 0x0709, CC,  CC_TIM_02_EXPIRED                  },
/* 7:  20s  TIMER_CC_03                */ { 0x03E9, CC,  CC_TIM_03_EXPIRED                  },
#ifdef CONFIG_CC_ENCRYPTION
/*  :  15s  TIMER_CC_SECURITY_WATCH    */ { 0x02EF, CC, CC_TIM_SECURITY_WATCH_EXPIRED       },
#endif
#ifdef CONFIG_EARLY_ENCRYPTION
/*  :  60s	TIMER_CC_REKEYING 			*/ { 0x0BB9, CC, CC_AUTHENTICATE_PT_RQ 				  },
#endif
/* 8:  10s  TIMER_MM_ACCESS_02         */ { 0x01F5, MM,  MM_TIM_ACCESS_02_EXPIRED           },
/* 9:  10s  TIMER_MM_AUTH_01           */ { 0x01F5, MM,  MM_TIM_AUTH_01_EXPIRED             },
/* 10: 100s TIMER_MM_AUTH_02           */ { 0x1389, MM,  MM_TIM_AUTH_02_EXPIRED             },
/* 11: 10s  TIMER_MM_KEY_01            */ { 0x01F5, MM,  MM_TIM_KEY_01_EXPIRED              },
/* 12: 10s  TIMER_MM_IDENTITY_01       */ { 0x01F2, MM,  MM_TIM_IDENTITY_01_EXPIRED         },
/* 13: 10s  TIMER_MM_CIPHER_01         */ { 0x01F5, MM,  MM_TIM_CIPHER_01_EXPIRED           },
/* 14: 10s  TIMER_MM_LOCATE_01         */ { 0x01F5, MM,  MM_TIM_LOCATE_01_EXPIRED           },
/* 15: 1s   TIMER_ME_RANDOM            */ { 0x0014, ME,  ME_RANDOM_TIMER_EXPIRY             },
#ifdef CONFIG_REPEATER_SUPPORT
/* 16: 3s   TIMER_MM_REPEATER_01       */ { 0x0097, MM, MM_TIM_REPEATER_01_EXPIRED          },
/* 17: 2s   TIMER_DL_REP               */ { 0x0065, LAP_REP, LAP_TIM_DL_04_EXPIRED          },
#endif
#endif
#ifdef SUPERTASK
/* 0:  2s   TIMER_DL_04                */ { 0x002, LAP, LAP_TIM_DL_04_EXPIRED              },
								 //{ 0x00CA, LAP, LAP_TIM_DL_04_EXPIRED              },   // 2s -> 4s change 20071226

/* 1:  5s   TIMER_LCE_01               */ { 0x005, LCE, LCE_TIM_01_EXPIRED                 },
/* 2:  10s  TIMER_LCE_02               */ { 0x0A, LCE, LCE_TIM_02_EXPIRED                 },
/* 3:  3s   TIMER_LCE_03               */ { 0x003, LCE, LCE_TIM_03_EXPIRED                 },
/* 4:  30s  TIMER_LCE_SUPERVISE        */ { 0x01E, LCE, LCE_TIM_SUPERVISE_EXPIRED          },
/* 5:  20s  TIMER_CC_01                */ { 0x014, CC,  CC_TIM_01_EXPIRED                  },
/* 6:  36s  TIMER_CC_02                */ { 0x024, CC,  CC_TIM_02_EXPIRED                  },
/* 7:  20s  TIMER_CC_03                */ { 0x014, CC,  CC_TIM_03_EXPIRED                  },
#ifdef CONFIG_CC_ENCRYPTION
/*  :  15s	TIMER_CC_SECURITY_WATCH 	*/ { 0x000F, CC, CC_TIM_SECURITY_WATCH_EXPIRED		 },
#endif
#ifdef CONFIG_EARLY_ENCRYPTION
/*  :  60s	TIMER_CC_REKEYING 			*/ { 0x003C, CC, CC_AUTHENTICATE_PT_RQ 				 },
#endif
/* 8:  10s  TIMER_MM_ACCESS_02         */ { 0x00A, MM,  MM_TIM_ACCESS_02_EXPIRED           },
/* 9:  10s  TIMER_MM_AUTH_01           */ { 0x00A, MM,  MM_TIM_AUTH_01_EXPIRED             },
/* 10: 100s TIMER_MM_AUTH_02           */ { 0x064, MM,  MM_TIM_AUTH_02_EXPIRED             },
/* 11: 10s  TIMER_MM_KEY_01            */ { 0x00A, MM,  MM_TIM_KEY_01_EXPIRED              },
/* 12: 10s  TIMER_MM_IDENTITY_01       */ { 0x00A, MM,  MM_TIM_IDENTITY_01_EXPIRED         },
/* 13: 10s  TIMER_MM_CIPHER_01         */ { 0x00A, MM,  MM_TIM_CIPHER_01_EXPIRED           },
/* 14: 10s  TIMER_MM_LOCATE_01         */ { 0x00A, MM,  MM_TIM_LOCATE_01_EXPIRED           },
/* 15: 1s   TIMER_ME_RANDOM            */ { 0x001, ME,  ME_RANDOM_TIMER_EXPIRY             },
#ifdef CONFIG_REPEATER_SUPPORT
/* 16: 2s   TIMER_DL_REP               */ { 0x002, LAP_REP, LAP_TIM_DL_04_EXPIRED          },
#endif
#endif
};

   /* ===========================                                          */
   /* Global function definitions                                          */
   /* ===========================                                          */

/*
*****************************************************************************
*                                                                           *
*   Function   :  Init_Pro_Timer_Table                                      *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Initializes the timer and the local variables for the     *
*                 process timer software table.                             *
*   Parms      :  none                                                      *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Init_Pro_Timer_Table( void )
{
   BYTE incarnation, i;

   Pro_Timer_Flag = 0;
                                       /* Loop over all incarnations !     */
   for( incarnation = 0; incarnation < INCMAX; incarnation++ )
   {
                                       /* Set all timer inactiv !          */
      for( i = 0; i < NR_OF_PRO_TIMERS; i++ )
      {
         Pro_CurrentTimerValue[ incarnation ][ i ] = 0;
      }
   }
}

/*
*****************************************************************************
*                                                                           *
*   Function   :   Start_Pro_Timer                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Starts the specified protocol software timer              *
*   Parms      :  timer           : timer typ                               *
*                 incarnation     : corresponding incarnation               *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Start_Pro_Timer( BYTE timer, BYTE incarnation )
{
	static int cnt=0;
                                       /* Set corresponding value in timer */
                                       /* table !                          */
   if(( timer < NR_OF_PRO_TIMERS ) && ( incarnation < INCMAX ))
      Pro_CurrentTimerValue[ incarnation ][ timer ] = Pro_Timer_Table[ timer ].InitValue;

   if( (timer == TIMER_ME_RANDOM) && (cnt ==0) )
   {
       //Pro_CurrentTimerValue[ incarnation ][ timer ] += Random2()%128;
       if(Pro_CurrentTimerValue[ incarnation ][ timer ] == 0)
       Pro_CurrentTimerValue[ incarnation ][ timer ] =  Pro_Timer_Table[ timer ].InitValue ;
       cnt++;
       //iprintf(" Strating Random timer with %d %d\n",Pro_Timer_Table[ timer ].InitValue ,Pro_CurrentTimerValue[ incarnation ][ timer ]);
   }
   #if 0
   if( timer == TIMER_ME_RANDOM )
       Pro_CurrentTimerValue[ incarnation ][ timer ] += (Random2()%8);
   #endif
}

/*
*****************************************************************************
*                                                                           *
*   Function   :   Stop_Pro_Timer                                           *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Stops the specified software timer                        *
*   Parms      :  timer           : timer typ                               *
*                 incarnation     : corresponding incarnation               *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Stop_Pro_Timer( BYTE timer, BYTE incarnation )
{
                                       /* Reset corresponding value in     */
                                       /* timer table !                    */
   if(( timer < NR_OF_PRO_TIMERS ) && ( incarnation < INCMAX ))
      Pro_CurrentTimerValue[ incarnation ][ timer ] = 0;
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Serve_Pro_Timer_Table                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Periodically called by the process level (main loop).     *
*   Parms      :  none                                                      *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  The routine works its way through a two dimensional array *
*                 which can be very time consuming. Therefore the routine   *
*                 has been optimized in a way that keeps the runtime as     *
*                 short as possible.                                        *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Serve_Pro_Timer_Table( void )
{
   BYTE to_do_flag, timer, incarnation;
   WORD XDATA *tim_pointer;
   FPTR end;
   WORD temp;

   to_do_flag = Pro_Timer_Flag;
   Pro_Timer_Flag = 0;

   if ( !to_do_flag )
      return;
                                       /* Access to the timer table is done*/
                                       /* via a pointer to keep the run    */
                                       /* time of the routine shorter.     */
   tim_pointer = (WORD*)Pro_CurrentTimerValue;
   end = (FPTR)Pro_CurrentTimerValue + (INCMAX * NR_OF_PRO_TIMERS * sizeof(WORD));
   while ( (FPTR)tim_pointer < end )
   {
                                       /* Work only on active timer.       */
      if (*tim_pointer > 0)
      {
         if ( *tim_pointer <= to_do_flag ){
            *tim_pointer = 0;
         }else{
            *tim_pointer -= to_do_flag;
           }                            /* Send message if the timer has    */
                                       /* expired                          */
         if (*tim_pointer == 0)
         {
                                       /* get the index within the table   */
            temp = ( (FPTR)tim_pointer - (FPTR)Pro_CurrentTimerValue) / sizeof(WORD);
            incarnation = temp / NR_OF_PRO_TIMERS;
            timer = temp % NR_OF_PRO_TIMERS;
            KNL_SENDTASK_INC( Pro_Timer_Table[ timer ].ProcID,
                             Pro_Timer_Table[ timer ].MsgID,
                             incarnation );
         }
      }
      ++tim_pointer;
   }
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  TA_Pro_Timer_Flag                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Periodically called by Timer A Interrupt (every 20ms).    *
*   Parms      :  none                                                      *
*   Returns    :  none                                                      *
*   Call Level :  ISR Level - Timer A                                       *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
TA_Pro_Timer_Flag( void )
{
  Pro_Timer_Flag++;
}

