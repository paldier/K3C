/* =======================================================================
 * Copyright (C) 2013 LANTIQ. All rights reserved.
 * Copyright (C) 2013 INTNIX. All rights reserved.
 * ======================================================================= */

/* =======================================================================
 * File:                   LCE_LIB.c
 *
 * Programmer:
 * Created:                2005-11-18
 *
 * Description:            Library for Process 'LINK CONTROL ENTITY (LCE)'
 * Module:
 * Controlling Document:
 * System Dependencies:
 *
 * Remarks:
 * ======================================================================= */

/* =======================================================================
 * Include Files
 * ======================================================================= */
#include <stdio.h>
#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "PCT_DEF.H"
#include "ERROR.H"
#ifdef FT
#include "FGLOBAL.H"
#endif
#include "FDEF.H"
#include "SYSINIT.H"
#include "KNL_SYSTEM.H"
#include "MMU.H"
#include "P_TIM.H"
#include "CC_DEF.H"
#include "CC_LIB.H"
#include "MM_LIB.H"

#include "LCE_LIB.H"

#include "CP_SERVER.H"
#include "MESSAGE_DEF.H"

#include "FMM.H"

/* =======================================================================
 * External Reference
 * ======================================================================= */
extern void write_to_hmac_ioctl(BYTE procid, BYTE msgnr,
                                BYTE param1, BYTE param2, BYTE param3, BYTE param4, BYTE param5, BYTE param6,
                                FPTR pdata,
                                BYTE inc);

/* =======================================================================
 * Definitions
 * ======================================================================= */
// Status definitions for the status element of the APP Layer Assignment Element.
#ifdef FT
#define LINK_OPEN 0
#define LINK_LOCKED 1
#define LINK_SUSPENDED 2
#endif

#define LINK_NO linkNo

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */
// PAGE QUEUE Element
#ifdef FT
typedef struct page_queue_element {
   // hiryu_20070918 add dummy 8byte. I don't konw what process change struct upper 8 byte access
   BYTE dummy1; /* just dummy */
   BYTE dummy2; /* just dummy */
   BYTE dummy3; /* just dummy */
   BYTE dummy4; /* just dummy */
   BYTE dummy5; /* just dummy */
   BYTE dummy6; /* just dummy */
   BYTE dummy7; /* just dummy */
   BYTE dummy8; /* just dummy */

   BYTE proc;
   BYTE msg;
   BYTE fail_proc;
   BYTE fail_msg;
   BYTE fail_inc;
   FPTR frame_ptr;
   struct page_queue_element * next;  
} PAGE_QUEUE_ELEMENT;
#endif

// LINK ESTABLISH Element
#ifdef FT
typedef struct {
   BYTE portableNo; // 0xFF: Not used
   // #ifdef FT_CLMS
   BYTE                        page_pattern;
   // #endif
   BYTE                        page_service;
   BYTE                        page_cnt;
   struct page_queue_element * pHead;
   struct page_queue_element * pEnd;
} LINK_ESTABLISH_ELEMENT;
#endif

// APP LAYER ASSIGNMENT Element
#ifdef FT
typedef struct {
   BYTE po_no;
   BYTE status;
} APP_LAYER_ASSIGNMENT_ELEMENT;
#endif

/* =======================================================================
 * Local Variables
 * ======================================================================= */
/* -----------------------------------------------------------------------
 * Name: LocalVar
 * Description:
 * ----------------------------------------------------------------------- */
#ifdef FT
LOCAL LINK_ESTABLISH_ELEMENT XDATA Link_Establish[MAX_LINK]; // The variable to handle indirect link establishment.
LOCAL APP_LAYER_ASSIGNMENT_ELEMENT XDATA App_Layer_Assignment[MAX_LINK];
#endif

/* =======================================================================
 * Global Variables
 * ======================================================================= */

/* =======================================================================
 * Local Function Prototypes
 * ======================================================================= */
/* -----------------------------------------------------------------------
 * Function    :
 * Descriptions: Open DLC for data transmit/receive
 * Parameters  : aMCEI - MCEI
 *               aPMIDPtr - Pointer to PMID
 * Return Value: YES / NO
 * Remarks     :
 * Requirments :
 * Call Level  :
 * ----------------------------------------------------------------------- */
// Message decoding
// ----------------
LOCAL void LCE_Message_Decode(FPTR frame_ptr, BYTE cid_value);
LOCAL void CC_Message_Decode(FPTR frame_ptr, BYTE cid_value);
LOCAL void MM_Message_Decode(FPTR frame_ptr, BYTE cid_value);
#ifdef FT_CLMS         
LOCAL void CLMS_Message_Decode(FPTR frame_ptr, BYTE cid_value);
#endif
#ifdef CATIQ_VE
LOCAL void SS_Message_Decode(FPTR frame_ptr, BYTE cid_value);
#endif

// Paging
// ------
#ifdef FT_CLMS
LOCAL FPTR Construct_Paging_Message(BYTE service, BYTE ring_pattern, FPTR tpui_ptr, BYTE po_no);
#else
LOCAL FPTR Construct_Paging_Message(BYTE service, FPTR tpui_ptr, BYTE po_no);
#endif
LOCAL void Put_In_Page_Queue(BYTE po_no, BYTE proc, BYTE msg, FPTR frame_ptr, BYTE fail_proc, BYTE fail_msg, BYTE fail_inc);
LOCAL void Send_Page_Queue(BYTE po_no, BYTE cid);

/* =======================================================================
 * Local Function Definitions
 * ======================================================================= */
LOCAL BYTE getActiveLinkNo(BYTE portableNo)
{
   BYTE i;

   for (i = 0; i < MAX_LINK; i++) {
      if (Link_Establish[i].portableNo == portableNo) {
         return i;
      }
   }

   return 0xFF;
}

LOCAL BYTE allocateLinkNo(BYTE portableNo)
{
   BYTE i;

   for (i = 0; i < MAX_LINK; i++) {
      if (Link_Establish[i].portableNo == 0xFF) {
         Link_Establish[i].portableNo = portableNo;
         return i;
      }
   }

   return 0xFF;
}

/*
*****************************************************************************
*                                                                           *
*   Function    :  LCE_Message_Decode                                       *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  This function is called by the central decoding           *
*                 function Decode_L3_Frame() when a frame with a LCE        *
*                 Protocol Discriminator was received.                      *
*                 According to the S-FORMAT Message type element the        *
*                 appropriate L3 Message is generated and send to the LCE   *
*                 process.                                                  *
*   Params     :  frame_ptr       : Pointer to the received frame           *
*                 cid_calue       : CID value of the LCE Process            *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
LOCAL void
LCE_Message_Decode(FPTR frame_ptr, BYTE cid_value)
{
   BYTE message = 0;

                                       /* Invert Transaction Flag !        */
                                       /* The Variable "TI_Value_PD_LCE"   */
                                       /* always stores the call reference */
                                       /* value to be sent.                */
   frame_ptr[ sizeof( struct HLI_Header )] ^= 0x80;

                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.3.1 Unsupported TI Format     */
                                       /* ================================ */
                                       /* For PD_LCE only TI_Value '0' is  */
                                       /* allowed !                        */
   if ((frame_ptr[sizeof(struct HLI_Header)] & 0x70 ) != 0) {
      Mmu_Free(frame_ptr);
      return;
   }

                                       /* Switch over LCE Message Type.    */
   switch (frame_ptr[1 + sizeof(struct HLI_Header)]) {
      #ifdef FT
      case LCE_PAGE_RESPONSE:
         message = LCE_PAGE_RESPONSE_LCE;
         break;
      #endif
      default:
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.4.4 MM message error          */
                                       /* ================================ */
                                       /* Unrecognized Message, ignore !   */
         Mmu_Free( frame_ptr );
         return;
   }

   KNL_SENDTASK_NP_INC(LCE, message, frame_ptr, cid_value);
   return;
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  CC_Message_Decode                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  This function is called by the central decoding           *
*                 function Decode_L3_Frame() when a frame with a CC         *
*                 Protocol Discriminator was received.                      *
*                 According to the S-FORMAT Message type element the        *
*                 appropriate L3 Message is generated and send to the CC    *
*                 process.                                                  *
*   Parms      :  frame_ptr       : Pointer to the received frame           *
*                 cid_calue       : CID value of the LCE Process            *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
LOCAL void
CC_Message_Decode(FPTR frame_ptr, BYTE cid_value)
{
   BYTE message = 0;
   BYTE TI_Value_temp;

                                       /* Invert Transaction Flag !        */
                                       /* The Variable "TI_Value_temp"     */
                                       /* always stores the call reference */
                                       /* value to be sent.                */
   TI_Value_temp = frame_ptr[sizeof(struct HLI_Header)] & 0xF0;
   TI_Value_temp ^= 0x80;
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.3.1 Unsupported TI Format     */
                                       /* ================================ */
                                       /* For PD_CC all TI_Values from '0' */
                                       /* to '6' are allowed.              */
                                       /* Only '7' is reserved !           */
   if ((TI_Value_temp & 0x70) == 0x70) {
      Mmu_Free(frame_ptr);
      return;
   }
                                       /* MESSAGE RELATES TO AN            */
                                       /* ACTIVE CALL ?                    */
                                       /* ================================ */
   #ifdef FT
   if ((TI_Value_temp == TI_Value_PD_CC[cid_value]) &&
       #ifdef CATIQ_VE
       (KNL_STATE_ARRAY[CC][cid_value] != F99) &&
       #endif
       (KNL_STATE_ARRAY[CC][cid_value] != F00))
       #endif
   {

                                       /* Switch over MESSAGE TYP          */
      switch (frame_ptr[1 + sizeof(struct HLI_Header)]) {
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.3.2.1 Unknown active CC-call  */
                                       /* ================================ */
                                       /* Ignore CC-SETUP relating to an   */
                                       /* active call.                     */
         case CC_SETUP:
            Mmu_Free( frame_ptr );
            return;
         case CC_INFO:
            message = CC_INFO_LCE;
            break;
         case CC_ALERTING:
            message = CC_ALERTING_LCE;
            break;
         case CC_CONNECT:
            message = CC_CONNECT_LCE;
            break;
         case CC_RELEASE:
            message = CC_RELEASE_LCE;
            break;
         case CC_RELEASE_COM:
            message = CC_RELEASE_COM_LCE;
            break;
         case IWU_INFO:
            message = CC_IWU_INFO_LCE;
            break;
         #ifdef DECT_NG                              
         case CC_SERVICE_CHANGE:
            message = CC_SERVICE_CHANGE_LCE;
            break;
         case CC_SERVICE_ACCEPT:
            message = CC_SERVICE_ACCEPT_LCE;
            break;
         case CC_SERVICE_REJECT:
            message = CC_SERVICE_REJECT_LCE;
            break;
         #endif                              
         #ifdef CATIQ_VE
         #if 0
         case SS_HOLD:
            message = CC_CRSS_HOLD_IN_LCE;
            break;
         case SS_HOLD_ACK:
            message = CC_CRSS_HOLD_ACK_IN_LCE;
            break;
         case SS_HOLD_REJECT:
            message = CC_CRSS_HOLD_REJECT_IN_LCE;
            break;
         case SS_RETRIEVE:
            message = CC_CRSS_RETRIEVE_IN_LCE;
            break;
         case SS_RETRIEVE_ACK:
            message = CC_CRSS_RETRIEVE_ACK_IN_LCE;
            break;
         case SS_RETRIEVE_REJECT:
            message = CC_CRSS_RETRIEVE_REJECT_IN_LCE;
            break;
         #endif
         case SS_FACILITY:
            message = CC_CRSS_FACILITY_IN_LCE;
            break;

         #endif
         default:
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.4.1 CC message error          */
                                       /* ================================ */
                                       /* Unrecognized Message, ignore !   */
            Mmu_Free(frame_ptr);
            return;
      }
      KNL_SENDTASK_NP_INC(CC, message, frame_ptr, cid_value);
      return;
   }
                                       /* MESSAGE DOES NOT RELATE TO AN    */
                                       /* ACTIVE CALL !                    */
                                       /* ================================ */

                                       /* Switch over MESSAGE TYP          */
   switch (frame_ptr[1 + sizeof(struct HLI_Header)]) {
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.3.2.1 Unknown active CC-call  */
                                       /* ================================ */
                                       /* Ignore CC_SETUP if TI-Flag is    */
                                       /* incorrectly set to '1'.          */
                                       /* NOTE: TI-Flag is inverted above. */
      case CC_SETUP:
         if (!(TI_Value_temp & 0x80)) {
            Mmu_Free(frame_ptr);
            return;
         }
                     /* SETUP Delivery                   */
                     /* ================================ */
         KNL_SENDTASK_NP_INC(CC, CC_SETUP_LCE, frame_ptr, cid_value);
         return;

      case CC_RELEASE:
      case CC_RELEASE_COM:
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.3.2.1 Unknown active CC-call  */
                                       /* ================================ */
                                       /* Ignore CC_RELEASE and            */
                                       /* CC_RELEASE_COM when not relating */
                                       /* to an active call.               */
         Mmu_Free(frame_ptr);
         return;

      #ifdef ULE_SUPPORT
      case IWU_INFO:
      case CC_SERVICE_CHANGE:
      case CC_SERVICE_ACCEPT:
      case CC_SERVICE_REJECT:
         if ((TI_Value_temp & 0xF0) != 0x50) { // if not ULE transtraction; TF = 1 (-> 0) and TV = 5
            Mmu_Free(frame_ptr);
            frame_ptr = Make_S_FORMAT_Message(PD_CC, TI_Value_temp, CC_RELEASE_COM);
            frame_ptr = Add_IE_2(frame_ptr, RELEASE_REASON, UNKNOWN_TRANSACTION_IDENTIFIER);
            KNL_SENDTASK_NP_INC(LAP, LAP_DL_DATA_RQ_LCE, frame_ptr, cid_value);
            return;
         }

         switch (frame_ptr[1 + sizeof(struct HLI_Header)]) {
            case IWU_INFO:            
               message = CC_IWU_INFO_LCE;
               break;

            case CC_SERVICE_CHANGE:
               message = CC_SERVICE_CHANGE_LCE;
               break;

            case CC_SERVICE_ACCEPT:
               message = CC_SERVICE_ACCEPT_LCE;
               break;

            case CC_SERVICE_REJECT:
               message = CC_SERVICE_REJECT_LCE;
               break;
         }
         KNL_SENDTASK_NP_INC(CC, message, frame_ptr, cid_value);
         return;
      #endif
         
      case CC_INFO:
      case CC_ALERTING:
      case CC_CONNECT:
      #ifdef DECT_NG
      #ifndef ULE_SUPPORT
      case IWU_INFO:
      case CC_SERVICE_CHANGE:
      case CC_SERVICE_ACCEPT:
      case CC_SERVICE_REJECT:
      #endif
      #endif
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.3.2.1 Unknown active CC-call  */
                                       /* ================================ */
                                       /* For all other messages Clearing  */
                                       /* is intiated by sending a         */
                                       /* CC-RELEASE-COMPLETE message.     */
         Mmu_Free(frame_ptr);
         frame_ptr = Make_S_FORMAT_Message(PD_CC, TI_Value_temp, CC_RELEASE_COM);
         frame_ptr = Add_IE_2(frame_ptr, RELEASE_REASON, UNKNOWN_TRANSACTION_IDENTIFIER);
         KNL_SENDTASK_NP_INC(LAP, LAP_DL_DATA_RQ_LCE, frame_ptr, cid_value);
         return;

      default:
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.4.1 CC-Message Error          */
                                       /* ================================ */
                                       /* Ignore unrecognised CC Message.  */
         Mmu_Free(frame_ptr);
         return;
   }
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  MM_Message_Decode                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  This function is called by the central decoding           *
*                 function Decode_L3_Frame() when a frame with a MM         *
*                 Protocol Discriminator was received.                      *
*                 According to the S-FORMAT Message type element the        *
*                 appropriate L3 Message is generated and send to the MM    *
*                 process.                                                  *
*   Parms      :  frame_ptr       : Pointer to the received frame           *
*                 cid_calue       : CID value of the LCE Process            *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
LOCAL void
MM_Message_Decode(FPTR frame_ptr, BYTE cid_value)
{
   BYTE message = 0;

                                       /* Invert Transaction Flag !        */
   frame_ptr[sizeof(struct HLI_Header)] ^= 0x80;

                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.3.1 Unsupported TI Format     */
                                       /* ================================ */
                                       /* For PD_MM only TI_Value '0' is   */
                                       /* allowed !                        */
   if ((frame_ptr[sizeof(struct HLI_Header)] & 0x70) != 0) {
      Mmu_Free(frame_ptr);
      return;
   }

                                       /* Switch over MM Message Type.     */
   switch (frame_ptr[1 + sizeof(struct HLI_Header)]) {
                                       /* Identity Messages                */
                                       /* ================================ */
      #ifdef FT
      case TEMPORARY_IDENTITY_ASSIGN_ACK:
         message = MM_TEMPORARY_IDENTITY_ASSIGN_ACK_LCE;
         break;

      case TEMPORARY_IDENTITY_ASSIGN_REJ:
         message = MM_TEMPORARY_IDENTITY_ASSIGN_REJ_LCE;
         break;

      case IDENTITY_REPLY:
         message = MM_IDENTITY_REPLY_LCE;
         break;
      #endif

                                       /* Authentication Messages          */
                                       /* ================================ */
      case AUTH_REQUEST:
         message = MM_AUTH_REQUEST_LCE;
         break;

      case AUTH_REPLY:
         message = MM_AUTH_REPLY_LCE;
         break;

      case AUTH_REJECT:
         message = MM_AUTH_REJECT_LCE;
         break;

                                       /* Location Messages                */
                                       /* ================================ */
      #ifdef FT
      case LOCATE_REQUEST:
         message = MM_LOCATE_REQUEST_LCE;
         break;

      case DETACH:
         message = MM_DETACH_LCE;
         break;
      #endif

                                       /* Access Rights Messages           */
                                       /* ================================ */
      #ifdef FT
      case ACCESS_RIGHTS_REQUEST:
         message = MM_ACCESS_RIGHTS_REQUEST_LCE;
         break;
      #endif

      case ACCESS_RIGHTS_TERMINATE_REQUEST:
         message = MM_ACCESS_RIGHTS_TERMINATE_REQUEST_LCE;
         break;

      case ACCESS_RIGHTS_TERMINATE_ACCEPT:
         message = MM_ACCESS_RIGHTS_TERMINATE_ACCEPT_LCE;
         break;

      case ACCESS_RIGHTS_TERMINATE_REJECT:
         message = MM_ACCESS_RIGHTS_TERMINATE_REJECT_LCE;
         break;

                                       /* Parameter Retrieval Messages     */
                                       /* ================================ */
      #ifdef FT
      case MM_INFO_REQUEST:
         message = MM_INFO_REQUEST_LCE;
         break;
      #endif

                                       /* Ciphering Messages               */
                                       /* ================================ */
      #ifdef FT
      case CIPHER_SUGGEST:
         message = MM_CIPHER_SUGGEST_LCE;
         break;

      case CIPHER_REJECT:
         message = MM_CIPHER_REJECT_LCE;
         break;
      #endif

      default:
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.4.4 MM message error          */
                                       /* ================================ */
                                       /* Unrecognized Message, ignore !   */
         Mmu_Free(frame_ptr);
         return;
   }

   KNL_SENDTASK_NP_INC(MM, message, frame_ptr, cid_value);
   return;
}

/*
*****************************************************************************
*                                                                           *
*   Function    :  CLMS_Message_Decode                                       *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  This function is called by the central decoding           *
*                 function Decode_L3_Frame() when a frame with a LCE        *
*                 Protocol Discriminator was received.                      *
*                 According to the S-FORMAT Message type element the        *
*                 appropriate L3 Message is generated and send to the LCE   *
*                 process.                                                  *
*   Parms      :  frame_ptr       : Pointer to the received frame           *
*                 cid_calue       : CID value of the LCE Process            *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT_CLMS
LOCAL void
CLMS_Message_Decode(FPTR frame_ptr, BYTE cid_value)
{
   BYTE message = 0;

                                       /* Invert Transaction Flag !        */
                                       /* The Variable "TI_Value_PD_LCE"   */
                                       /* always stores the call reference */
                                       /* value to be sent.                */
   frame_ptr[sizeof(struct HLI_Header)] ^= 0x80;

                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.3.1 Unsupported TI Format     */
                                       /* ================================ */
                                       /* For PD_CLMS only TI_Value '0' is  */
                                       /* allowed !                        */
   if ((frame_ptr[sizeof(struct HLI_Header)] & 0x70) != 0) {
      Mmu_Free(frame_ptr);
      return;
   }

                                       /* Switch over LCE Message Type.    */
   switch (frame_ptr[1 + sizeof(struct HLI_Header)]) {
      default:
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.4.4 CLMS message error          */
                                       /* ================================ */
                                       /* Unrecognized Message, ignore !   */
      Mmu_Free(frame_ptr);
      return;
   }

   KNL_SENDTASK_NP_INC(CLMS, message, frame_ptr, cid_value);
   return;
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  SS_Message_Decode                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  This function is called by the central decoding           *
*                 function Decode_L3_Frame() when a frame with a CISS       *
*                 Protocol Discriminator was received.                      *
*                 According to the S-FORMAT Message type element the        *
*                 appropriate L3 Message is generated and send to the CC    *
*                 process.                                                  *
*   Params     :  frame_ptr       : Pointer to the received frame           *
*                 cid_calue       : CID value of the LCE Process            *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef CATIQ_VE
LOCAL void
SS_Message_Decode(FPTR frame_ptr, BYTE cid_value)
{
   BYTE message = 0;
   BYTE TI_Value_temp;

                                       /* Invert Transaction Flag !        */
                                       /* The Variable "TI_Value_temp"     */
                                       /* always stores the call reference */
                                       /* value to be sent.                */
   TI_Value_temp = frame_ptr[sizeof(struct HLI_Header)] & 0xF0;
   TI_Value_temp ^= 0x80;
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.3.1 Unsupported TI Format     */
                                       /* ================================ */
                                       /* For PD_CISS all TI_Values from '0' */
                                       /* to '6' are allowed.              */
                                       /* Only '7' is reserved !           */
   if ((TI_Value_temp & 0x70) == 0x70) {
      Mmu_Free(frame_ptr);
      return;
   }
                                       /* MESSAGE RELATES TO AN            */
                                       /* ACTIVE CALL ?                    */
                                       /* ================================ */

   // handle only connectionless facilitiy message
   if ((TI_Value_temp & 0x70) == TI_TV_CONNLESS) {
    
   /* Switch over MESSAGE TYP          */
   switch (frame_ptr[1 + sizeof(struct HLI_Header)]) {
      case SS_FACILITY:
         message = CC_CLSS_FACILITY_IN_LCE;
         break;

      default:
         // not handled message
         Mmu_Free(frame_ptr);
         return;
    }

    KNL_SENDTASK_NP_INC(CC, message, frame_ptr, cid_value);
    return;
  }
  
  // nothing to handle => free frame_ptr
  Mmu_Free(frame_ptr);
  return;

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Construct_Paging_Message                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Constructs the Header of a B-FORMAT (short) Message as    *
*                 specified in ETS 300 175-5 / 8.2.1                        *
*                 This message is only used by the LCE process for the      *
*                 BROADCAST Service                                         *
*   Parms      :  service         : requested service type                  *
*                 tpui_ptr        : pointer to the TPUI array               *
*   Return     :  Pointer to the constructed B-FORMAT Message               *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
#ifdef FT_CLMS
LOCAL FPTR
Construct_Paging_Message(BYTE service, BYTE ring_pattern, FPTR tpui_ptr, BYTE po_no)
{
   ///////////////////////////////////////////////////////////////////////////////
   //////////////////////  Make LONG_FORMAT_Message for WBS /////////////////////////
   //////////////////////////////////////////////////////////////////////////////
                                       /* According to ETS 300 175-5 /     */
                                          /* 8.2.2 the long format message   */
                                       /* has the following                */
                                       /* format:                          */
                                     
                                       /* W-Bit = '1': default TPUI( 20 bits complete TPUI )         */
                                       /* W-Bit = '0': assigned TPUI( lowest of 28 bits of IPUI) => Not available */
                                       
                                          /* << TPUI(W=1) address structure >> */
                                          /* ------------------------------  */
                                          /*| x | x | x | x |W=1| LCE Header  |  */
                                          /* ------------------------------  */
                                          /*|Field 1(Slottype)|   TPUI addr      |  */
                                          /* ------------------------------  */
                                          /*|                TPUI addr                    |  */
                                          /* ------------------------------  */
                                          /*|                TPUI addr                    |  */
                                          /* ------------------------------  */
                                          /*|Field 2(msg_type) |  Field 3          |  */
                                          /* ------------------------------  */

                                       /* LCE Header : requested U-plane   */
                                          /* service(100):0x04                                */
                                          /* Slottype: Long slot;j=640(0001):0x01   */
                                          /* msg_type : Type of Layer 3 Message     */
                                          /* ( LCE_REQUEST_PAGE or CLMS_FIXED) */
                                       
                                       /* if LCE header == esc(010), then  */                                           
                                        /*
                                        |  8 |  7 |  6 |  5 |  4 |  3 |  2 |  1   |
                                        |------------------------------|
                                        |  x    x    x    x   |W=1| LCE Header(010)|
                                        |------------------------------|
                                        |Discriminator(ring)|TPUI Address    |
                                        |------------------------------|
                                        |  TPUI Address(cont)                      |
                                        |------------------------------|
                                        |  TPUI Address(cont)                      |
                                        |------------------------------|
                                        |  spare(0000)   |Connection Identity|
                                        |------------------------------|
                                        */

   FPTR long_page;
   BYTE page_type = service & 0xF0;
   BYTE service_type = service & 0x0F;
   po_no = po_no;

                                       /* Allocate memory for the long         */
                                       /* B-Format message (Length = 5).   */
   if(page_type == PT_SHORT_PAGE )
   {
                                          /* According to ETS 300 175-5 /     */
                                          /* 8.2.1 the short paging message   */
                                          /* has the following                */
                                          /* format:                          */
                                           /*
                                           |  8 |  7 |  6 |  5 |  4 |  3 |  2 |  1   |
                                           |------------------------------|
                                           |  x    x    x    x   |W  | LCE Header|
                                           |------------------------------|
                                           |  TPUI Address(cont)                      |
                                           |------------------------------|
                                           |  TPUI Address(cont)                      |
                                           |------------------------------|
                                           */
                                          /* W-Bit = '0': default TPUI        */
                                          /* W-Bit = '1': assigned TPUI       */

                                          /* LCE Header : requested U-plane   */
                                          /* service.                         */

                                          /* Allocate memory for the short    */
                                          /* B-Format message (Length = 3).   */
      long_page = Mmu_Malloc( 3 + sizeof( struct HLI_Header ));
      #ifdef KLOCWORK
      if(long_page == NULL) return NULL;
      #endif
                                          /* Adjust HLI-Length information.   */
      (( struct HLI_Header * ) long_page ) -> length = 3 + sizeof( struct HLI_Header );
   }
   else
   {
                                          /* According to ETS 300 175-5 /     */
                                          /* 8.2.2 the long format message   */
                                          /* has the following                       */
                                          /* format:                                    */

                                          /* W-Bit = '1': default TPUI( 20 bits complete TPUI )         */
                                          /* W-Bit = '0': assigned TPUI( lowest of 28 bits of IPUI) => Not available */

                                          /* << TPUI(W=1) address structure >> */
                                          /* ------------------------------  */
                                          /*| x | x | x | x |W=1| LCE Header  |  */
                                          /* ------------------------------  */
                                          /*|Field 1(Slottype)|   TPUI addr      |  */
                                          /* ------------------------------  */
                                          /*|                TPUI addr                    |  */
                                          /* ------------------------------  */
                                          /*|                TPUI addr                    |  */
                                          /* ------------------------------  */
                                          /*|Field 2(msg_type) |  Field 3          |  */
                                          /* ------------------------------  */
                                                                 
                                          /* LCE Header : requested U-plane           */
                                          /* service(100):0x04                                */
                                          /* Slottype: Long slot;j=640(0001):0x01   */
                                          /* msg_type : Type of Layer 3 Message     */
                                          /* ( LCE_REQUEST_PAGE or CLMS_FIXED) */

                                          /* if LCE header == esc(010), then  */                                           
                                           /*
                                           |  8 |  7 |  6 |  5 |  4 |  3 |  2 |  1   |
                                           |------------------------------|
                                           |  x    x    x    x   |W=1| LCE Header(010)|
                                           |------------------------------|
                                           |Discriminator(ring)|TPUI Address    |
                                           |------------------------------|
                                           |  TPUI Address(cont)                      |
                                           |------------------------------|
                                           |  TPUI Address(cont)                      |
                                           |------------------------------|
                                           |  spare(0000)   |Connection Identity|
                                           |------------------------------|
                                           */
      long_page = Mmu_Malloc( 5 + sizeof( struct HLI_Header ));
      #ifdef KLOCWORK
      if(long_page == NULL) return NULL;
      #endif
                                       /* Adjust HLI-Length information.   */
      (( struct HLI_Header * ) long_page ) -> length = 5 + sizeof( struct HLI_Header );
   }
                                       /* Check TPUI type.                 */
                                       /* -------------------------------- */
   if( tpui_ptr[ 0 ] == 0x00 )
   {
                                       /* The TPUI to be used is of type   */
                                       /* assigned -> W-Bit = '1'.         */
      long_page[ sizeof( struct HLI_Header ) ] = 0x08;
   }
   else
   {
                                       /* The TPUI to be used is of type   */
                                       /* default -> W-Bit = '0'.          */
      long_page[ sizeof( struct HLI_Header ) ] = 0x00;
   }
   
                                       /* Set the LCE Header & W-bit element   */
                                       /* Add the requested U-plane        */
                                       /* service type.                    */
   long_page[ sizeof( struct HLI_Header )     ] |= ( service & 0x07 );

   switch( service_type )
   {
      case U_PLAN_SERVICE_UNKNOWN_AND_RINGING:
      case CLMS_FIXED_STANDARD_SINGLE_SECTION:
      case CLMS_FIXED_STANDARD_MULTI_SECTION:
      /* The broadcast message is "CLMS_FIXED" message => e.g. Extended format */
      case CLMS_FIXED_ALPHANUMERIC_SINGLE_SECTION:
      case CLMS_FIXED_ALPHANUMERIC_MULTI_SECTION:
      {
         if( tpui_ptr[ 0 ] == 0x00 )
            long_page[ sizeof( struct HLI_Header ) ] &= ~0x08; /* assigned Connectionless TPUI -> W-Bit = '0'.  */
         else
            long_page[ sizeof( struct HLI_Header ) ] |= 0x08;  /* group mask -> W-Bit = '1'.          */

         /* Set Ring pattern address. ( if you want )      */
         if( page_type == PT_SHORT_PAGE )
         {
            long_page[ sizeof( struct HLI_Header ) + 1 ] = ((ring_pattern & 0x0F ) << 4) | (tpui_ptr[ 1 ] & 0x0F);
            long_page[ sizeof( struct HLI_Header ) + 2 ] = tpui_ptr[ 2 ];
         }
         else
         {
            long_page[ sizeof( struct HLI_Header ) + 1 ] = (ring_pattern & 0x0F );
            long_page[ sizeof( struct HLI_Header ) + 2 ] = tpui_ptr[ 1 ];
            long_page[ sizeof( struct HLI_Header ) + 3 ] = tpui_ptr[ 2 ];
            /* Set the Field 1( Attributes-slot type) element     */
            long_page[ sizeof( struct HLI_Header ) + 1 ] |= 0x01 << 4;  // Field-1 : slottype=Long-slot(0001), Full-slot(0100)
            long_page[ sizeof( struct HLI_Header ) + 4 ]  = 0x30;       // Default setup and default LCE
         }
         break;
      }

      default: // service == U_PLAN_IN_MIN_DELAY
      {
         /* Set TPUI address.                */
         if( page_type == PT_SHORT_PAGE )
         {
            long_page[ sizeof( struct HLI_Header ) + 1 ] = tpui_ptr[ 1 ];
            long_page[ sizeof( struct HLI_Header ) + 2 ] = tpui_ptr[ 2 ];
         }
         else
         {
            long_page[ sizeof( struct HLI_Header ) + 1 ] = (tpui_ptr[ 0 ] & 0x0F);
            long_page[ sizeof( struct HLI_Header ) + 2 ] = tpui_ptr[ 1 ];
            long_page[ sizeof( struct HLI_Header ) + 3 ] = tpui_ptr[ 2 ];
            /* Set the Field 1( Attributes-slot type) element     */
            long_page[ sizeof( struct HLI_Header ) + 1 ] |= 0x01 << 4;  // Field-1 : slottype=Long-slot(0001), Full-slot(0100) 
            long_page[ sizeof( struct HLI_Header ) + 4 ]  = 0x00;       // N.U
         }
         break;
      }
   }

   return( long_page );
}

#else  // FT_CLMS

LOCAL FPTR
Construct_Paging_Message(BYTE service, FPTR tpui_ptr, BYTE po_no)
{
   #ifdef DECT_NG_FULL_PAGE
   ///////////////////////////////////////////////////////////////////////////////
   //////////////////////  Make LONG_FORMAT_Message for WBS /////////////////////////
   //////////////////////////////////////////////////////////////////////////////
                                       /* According to ETS 300 175-5 /     */
                                          /* 8.2.2 the long format message   */
                                       /* has the following                */
                                       /* format:                          */
                                     
                                       /* W-Bit = '1': default TPUI( 20 bits complete TPUI )         */
                                       /* W-Bit = '0': assigned TPUI( lowest of 28 bits of IPUI) => Not available */
                                       
                                          /* << TPUI(W=1) address structure >> */
                                          /* ------------------------------  */
                                          /*| x | x | x | x |W=1| LCE Header  |  */
                                          /* ------------------------------  */
                                          /*|Field 1(Slottype)|   TPUI addr      |  */
                                          /* ------------------------------  */
                                          /*|                TPUI addr                    |  */
                                          /* ------------------------------  */
                                          /*|                TPUI addr                    |  */
                                          /* ------------------------------  */
                                          /*|Field 2(msg_type) |  Field 3          |  */
                                          /* ------------------------------  */

                                       /* LCE Header : requested U-plane   */
                                          /* service(100):0x04                                */
                                          /* Slottype: Long slot;j=640(0001):0x01   */
                                          /* msg_type : Type of Layer 3 Message     */
                                          /* ( LCE_REQUEST_PAGE or CLMS_FIXED) */
                                       
                                       /* if LCE header == esc(010), then  */                                           
                                        /*
                                        |  8 |  7 |  6 |  5 |  4 |  3 |  2 |  1   |
                                        |------------------------------|
                                        |  x    x    x    x   |W=1| LCE Header(010)|
                                        |------------------------------|
                                        |Discriminator(ring)|TPUI Address    |
                                        |------------------------------|
                                        |  TPUI Address(cont)                      |
                                        |------------------------------|
                                        |  TPUI Address(cont)                      |
                                        |------------------------------|
                                        |  spare(0000)   |Connection Identity|
                                        |------------------------------|
                                        */

   FPTR long_page;
   BYTE temp_mode;

   #ifdef ULE_SUPPORT
   if( Get_Required_Slot_Type(po_no) == 1 )
   #else
   if( Required_Slot_Type[po_no-1] == 1 )
   #endif
       temp_mode = 5;
   else
       temp_mode = 3;
                                       /* Allocate memory for the long    */
                                       /* B-Format message (Length = 5).   */
   long_page = Mmu_Malloc( temp_mode + sizeof( struct HLI_Header ));
                                       
   #ifdef KLOCWORK
   if(long_page == NULL) return NULL;
   #endif
                                       /* Adjust HLI-Length information.   */
   (( struct HLI_Header * ) long_page ) -> length = temp_mode + sizeof( struct HLI_Header );

                                       /* Check TPUI type.                 */
                                       /* -------------------------------- */
   if( tpui_ptr[ 0 ] == 0x00 )
   {
                                       /* The TPUI to be used is of type   */
                                       /* assigned -> W-Bit = '1'.         */
      long_page[ sizeof( struct HLI_Header ) ] = 0x08;
   }
   else
   {
                                       /* The TPUI to be used is of type   */
                                       /* default -> W-Bit = '0'.          */
      long_page[ sizeof( struct HLI_Header ) ] = 0x00;
   }
   
                                       /* Set the LCE Header & W-bit element   */
                                       /* Add the requested U-plane        */
                                       /* service type.                    */
   long_page[ sizeof( struct HLI_Header )     ] |= ( service & 0x07 );

   if( service == U_PLAN_SERVICE_UNKNOWN_AND_RINGING )
   {
      /* Set Ring pattern address. ( if you want )      */
      if( temp_mode == 5 )
      {
         long_page[ sizeof( struct HLI_Header ) + 1 ] = (tpui_ptr[ 0 ] & 0x0F);
         long_page[ sizeof( struct HLI_Header ) + 2 ] = tpui_ptr[ 1 ];
         long_page[ sizeof( struct HLI_Header ) + 3 ] = tpui_ptr[ 2 ];
      }
      else
      {
         long_page[ sizeof( struct HLI_Header ) + 1 ] = tpui_ptr[ 1 ];
         long_page[ sizeof( struct HLI_Header ) + 2 ] = tpui_ptr[ 2 ];
      }
   }
   else //service == U_PLAN_IN_MIN_DELAY
   {
                                       /* Set TPUI address.                */
      if( temp_mode == 5 )
      {
         long_page[ sizeof( struct HLI_Header ) + 1 ] = (tpui_ptr[ 0 ] & 0x0F);
         long_page[ sizeof( struct HLI_Header ) + 2 ] = tpui_ptr[ 1 ];
         long_page[ sizeof( struct HLI_Header ) + 3 ] = tpui_ptr[ 2 ];
      }
      else
      {
         long_page[ sizeof( struct HLI_Header ) + 1 ] = tpui_ptr[ 1 ];
         long_page[ sizeof( struct HLI_Header ) + 2 ] = tpui_ptr[ 2 ];
      }
   }

   /* Set the Field 1( Attributes-slot type) element     */
   if( temp_mode == 5 )
   {
      long_page[ sizeof( struct HLI_Header ) + 1 ] |= 0x01<<4; // Field-1 : slottype=Long-slot(0001), Full-slot(0100) 
      long_page[ sizeof( struct HLI_Header ) + 4 ]  = 0x00;    // For Advanced Connection 
   }

   return( long_page );  
   #else
   ///////////////////////////////////////////////////////////////////////////////
   //////////////////////  Make_S_FORMAT_Message for normal ////////////////////////
   //////////////////////////////////////////////////////////////////////////////
   FPTR short_page;
                                       /* According to ETS 300 175-5 /     */
                                       /* 8.2.1 the short paging message   */
                                       /* has the following                */
                                       /* format:                          */
                                  /*
                                        |  8 |  7 |  6 |  5 |  4 |  3 |  2 |  1   |
                                        |------------------------------|
                                        |  x    x    x    x   |W  | LCE Header|
                                        |------------------------------|
                                        |  TPUI Address(cont)                      |
                                        |------------------------------|
                                        |  TPUI Address(cont)                      |
                                        |------------------------------|
                                  */
                                       /* W-Bit = '0': default TPUI        */
                                       /* W-Bit = '1': assigned TPUI       */

                                       /* LCE Header : requested U-plane   */
                                       /* service.                         */

                                       /* Allocate memory for the short    */
                                       /* B-Format message (Length = 3).   */
   short_page = Mmu_Malloc( 3 + sizeof( struct HLI_Header ));
   #ifdef KLOCWORK
   if(short_page == NULL) return NULL;
   #endif
                                       /* Adjust HLI-Length information.   */
   (( struct HLI_Header * ) short_page ) -> length = 3 + sizeof( struct HLI_Header );

                                       /* Check TPUI type.                 */
                                       /* -------------------------------- */
   if( tpui_ptr[ 0 ] == 0x00 )
   {
                                       /* The TPUI to be used is of type   */
                                       /* assigned -> W-Bit = '1'.         */
      short_page[ sizeof( struct HLI_Header ) ] = 0x08;
   }
   else
   {
                                       /* The TPUI to be used is of type   */
                                       /* default -> W-Bit = '0'.          */
      short_page[ sizeof( struct HLI_Header ) ] = 0x00;
   }
                                       /* Add the requested U-plane        */
                                       /* service type.                    */
   short_page[ sizeof( struct HLI_Header )     ] |= ( service & 0x07 );

   if( service == U_PLAN_SERVICE_UNKNOWN_AND_RINGING )
   {
                                          /* Set Ring pattern address. ( if you want )      */
      short_page[ sizeof( struct HLI_Header ) + 1 ] = tpui_ptr[ 1 ];
      short_page[ sizeof( struct HLI_Header ) + 2 ] = tpui_ptr[ 2 ];

   }
   else
   {
                                       /* Set TPUI address.                */
      short_page[ sizeof( struct HLI_Header ) + 1 ] = tpui_ptr[ 1 ];
      short_page[ sizeof( struct HLI_Header ) + 2 ] = tpui_ptr[ 2 ];
   }
   return( short_page );
   #endif
}
#endif  // FT_CLMS
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Put_In_Page_Queue                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function stores a network layer frame in the paging   *
*                 queue until a link to the portable is established.        *
*   Parms      :  po_no           : 'sending' portable                      *
*                 proc            : receiver process of NTW layer (CC,MM)   *
*                 msg             : message for the NTW layer               *
*                 frame_ptr       : pointer to NTW layer frame              *
*                 reset_flag:     : reset flag                              *
*                 fail_proc       : process id to be informed in case of a  *
*                                   paging expiry                           *
*                 fail_msg        : fail message to be send                 *
*                 fail_inc        : incarnation of fail process             *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
LOCAL void
Put_In_Page_Queue(BYTE po_no, BYTE proc, BYTE msg, FPTR frame_ptr, BYTE fail_proc, BYTE fail_msg, BYTE fail_inc)
{
   PAGE_QUEUE_ELEMENT * pHead;
   PAGE_QUEUE_ELEMENT * pEnd;
   PAGE_QUEUE_ELEMENT * pNew;
   BYTE linkNo;

                                       /* Reasonable value for po_no ?     */
   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
   if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
   #endif
      return;

                                       /* Get the Head and End pointer of  */
                                       /* the list.                        */
   linkNo = getActiveLinkNo(po_no);
#ifdef KLOCWORK
   if( linkNo == 0xFF ) {
      return;
   }
#endif

   pHead = Link_Establish[LINK_NO].pHead;
   pEnd  = Link_Establish[LINK_NO].pEnd;
                                       /* Allocate memory for the new      */
                                       /* paging queue element.            */
   pNew = ( PAGE_QUEUE_ELEMENT * ) Mmu_Malloc( sizeof( PAGE_QUEUE_ELEMENT ));

                                       /* Set all members of the queue     */
                                       /* element.                         */

   #ifdef KLOCWORK
   if(pNew == NULL) return;
   #endif
   pNew -> next      = NULL;
   pNew -> proc      = proc;
   pNew -> msg       = msg;
   pNew -> frame_ptr = frame_ptr;
   pNew -> fail_proc = fail_proc;
   pNew -> fail_msg  = fail_msg;
   pNew -> fail_inc  = fail_inc;

   pNew->dummy1 = 0;
   pNew->dummy2 = 0;
   pNew->dummy3 = 0;
   pNew->dummy4 = 0;
   pNew->dummy5 = 0;
   pNew->dummy6 = 0;
   pNew->dummy7 = 0;
   pNew->dummy8 = 0;

                                       /* The new element is inserted in   */
                                       /* the paging queue !               */
   if( pHead == NULL )
   {
                                       /* Paging queue is empty !          */
      pHead = pNew;
      pEnd  = pNew;
   }
   else
   {
                                       /* New element is inserted at the   */
                                       /* end of the paging queue.         */
      pEnd -> next = pNew;
      pEnd         = pNew;
   }
                                       /* Set new Head and End pointers.   */
   Link_Establish[LINK_NO].pHead = pHead;
   Link_Establish[LINK_NO].pEnd  = pEnd;
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Send_Page_Queue                                           *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function forwards all frames stored in the paging     *
*                 queue to the network layer after link establishment.      *
*   Parms      :  po_no           : portable number                         *
*                 cid             : CID value                               *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
LOCAL void
Send_Page_Queue(BYTE po_no, BYTE cid)
{
   PAGE_QUEUE_ELEMENT * pHead;
   PAGE_QUEUE_ELEMENT * pTemp;
   BYTE linkNo;

                                       /* Reasonable value for po_no ?     */
   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
   if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
   #endif
      return;

   linkNo = getActiveLinkNo(po_no);
                                       /* Get the Head pointer of the list.*/
   if (linkNo != 0xFF) {
      pHead = Link_Establish[LINK_NO].pHead;
   } else {
      pHead = NULL;
   }
                                       /* All stored NTW-Layer messages    */
                                       /* are send to the specified        */
                                       /* NTW-Layer entity (=cid)          */
   while( pHead != NULL )
   {
                                       /* Interface App-Layer<->NTW-Layer  */
                                       /* P1: return proc                  */
                                       /* P2: return msg                   */
                                       /* P3: return inc                   */
                                       /* P4: po_no                        */
      KNL_SENDTASK_NP_WP_INC(pHead -> proc,
                             pHead -> msg,
                             pHead -> frame_ptr,
                             pHead -> fail_proc,
                             pHead -> fail_msg,
                             pHead -> fail_inc,
                             po_no,
                             cid);
                                       /* Store pointer to old queue       */
                                       /* element.                         */
      pTemp = pHead;
                                       /* Move to next element.            */
      pHead = pHead -> next;
                                       /* Free memory of the old queue     */
                                       /* element.                         */
      Mmu_Free( (FPTR) pTemp );
   }
                                       /* Reset Link Establishment         */
                                       /* Structure.                       */
   if (linkNo != 0xFF)
   {
      Link_Establish[LINK_NO].portableNo = 0xFF;
      Link_Establish[LINK_NO].page_service = 0xFF;
      Link_Establish[LINK_NO].page_cnt = 0;
      Link_Establish[LINK_NO].pHead = NULL;
      Link_Establish[LINK_NO].pEnd = NULL;
   }
}
#endif

/* =======================================================================
 * Global Function Definitions
 * ======================================================================= */
/*
Message-Decoding----------------------------------------()
*/
/*
*****************************************************************************
*                                                                           *
*   Function   :  Decode_L3_Frame                                           *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  This is the central decoding function. All received       *
*                 frames by the process LCE are processed by a call to      *
*                 this function.                                            *
*                 According to the Protocol Discriminator the               *
*                 corresponding Decodefunction is called.                   *
*   Params     :  frame_ptr       : Pointer to the received frame           *
*                 cid_calue       : CID value of the LCE Process            *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Decode_L3_Frame( FPTR frame_ptr, BYTE cid_value )
{
                                       /* No frame there !                 */
   if ( frame_ptr == NULL ) return;

                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.2 Message too short           */
                                       /* ================================ */
                                       /* Ignore Message !                 */
   if ((( struct HLI_Header * ) frame_ptr ) -> length <
          2 + sizeof( struct HLI_Header ))
   {
      Mmu_Free( frame_ptr );
      return;
   }
                                       /* HANDLING OF ERROR CONDITIONS     */
                                       /* 17.1 PD Error                    */
                                       /* ================================ */
                                       /* Ignore Message !                 */
   switch ( frame_ptr[ sizeof( struct HLI_Header ) ] & 0x0F )
   {
      case PD_LCE:
         LCE_Message_Decode( frame_ptr, cid_value );
         return;

      case PD_CC:
         CC_Message_Decode( frame_ptr, cid_value );
         return;

      case PD_MM:
         MM_Message_Decode( frame_ptr, cid_value );
         return;

      case PD_CISS:
         #ifdef CATIQ_VE
         SS_Message_Decode( frame_ptr, cid_value );
         return;
         #endif

      case PD_CLMS:
         #ifdef FT_CLMS         
         CLMS_Message_Decode( frame_ptr, cid_value );
         return;
         #endif

      case PD_COMS:
      default:
         Mmu_Free( frame_ptr );
         return;
   }
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Broadcast_CLMS_Message                   *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function provides for the application layer the       *
*                 facility to transfer messages to the application layer directly via broadcasting.       *
*                 Regardless the current link status, the paging is invoked always      *
*                 invoked, the message is stored in the paging queue or the *
*                 message is directly transferred to the network layer.     *
*   Parms      :  po_no           : 'sending' portable                      *
*                     service           : CLMS service tyep   *
*                     ring_pattern    : ring pattern               *
*                     life:                : continue how long(reset flag)                              *
*                 frame_ptr       : pointer to NTW layer frame              *
*   Return     :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT_CLMS
EXPORT void
Broadcast_CLMS_Message( BYTE po_no, BYTE service, BYTE ring_pattern, BYTE life, BYTE wide_flag, FPTR frame_ptr  )
{
   FPTR tpui_ptr;
   FPTR temp_ptr;
   BYTE hli_length;
   BYTE page_type;
   BYTE linkNo;

   #if 0  // No Full paging for CLMS
   if( wide_flag == 1 )
      page_type = (service & 0x87) | PT_FULL_PAGE;
   else
   #endif
      page_type = (service & 0x87) | PT_SHORT_PAGE;

   switch( service )
   {
      /* The broadcast message is LCE "Short Page Format" message */
      case U_PLAN_SERVICE_NONE:
      case U_PLAN_SERVICE_UNKNOWN_AND_RINGING:
      case U_PLAN_SERVICE_UNKNOWN_AND_RINGING_CBI:
         {
            // write_to_hmac_ioctl(HMAC, MAC_PAGE_CANCEL_LB, 0, 0, 0, 0, 0, 0, 0, 0 ); // Clean-up the paging queues
            Discard_Page_Queue(po_no);
            linkNo = allocateLinkNo(po_no);
            if (linkNo == 0xFF) {
               Mmu_Free(frame_ptr);
            } else {
               #ifdef KLOCWORK
               tpui_ptr = Subscription_GetTPUIRef(po_no);
               if(tpui_ptr== NULL) {
                  return;
               }
               #endif
               temp_ptr = Construct_Paging_Message((page_type & 0x7F),
                                                   ring_pattern,
                                                   #ifdef KLOCWORK
                                                   tpui_ptr,
                                                   #else
                                                   Subscription_GetTPUIRef(po_no),
                                                   #endif
                                                   po_no);

               if( service == U_PLAN_SERVICE_UNKNOWN_AND_RINGING_CBI )  // collective-ring?
               {
                  temp_ptr[1+sizeof( struct HLI_Header )] |= 0x0F;
                  temp_ptr[2+sizeof( struct HLI_Header )] =  0xFF;
               }
                                                 /* Request Paging Timer             */
                                                 /* -------------------------------- */
                                                 /* Timer:    <LCE_page.03>          */
                                                 /* Duration: 3 seconds              */
               Start_Pro_Timer( TIMER_LCE_03, LINK_NO );
               KNL_SENDTASK_NP( LB, LB_DL_BROADCAST_RQ_LCE, temp_ptr );
                                                   /* The NTW-Layer message is stored  */
                                                   /* in the paging queue.             */
                                                   /* -------------------------------- */
               Put_In_Page_Queue( po_no, CLMS, service, frame_ptr, 0xff, 0xff, 0xff );
               Link_Establish[LINK_NO].page_service = page_type;
               Link_Establish[LINK_NO].page_pattern = ring_pattern;
               Link_Establish[LINK_NO].page_cnt = life;
               if (life != 0xff) {
                  Link_Establish[LINK_NO].page_cnt = (Link_Establish[LINK_NO].page_cnt) / 3; //
               }
            }
         }
         break;
               
      case CLMS_FIXED_STANDARD_SINGLE_SECTION:
      case CLMS_FIXED_STANDARD_MULTI_SECTION:
                                          /* The broadcast message is "CLMS_FIXED" message => e.g. Extended format */
      case CLMS_FIXED_ALPHANUMERIC_SINGLE_SECTION:
      case CLMS_FIXED_ALPHANUMERIC_MULTI_SECTION:
         {
            // write_to_hmac_ioctl(HMAC, MAC_PAGE_CANCEL_LB, 0, 0, 0, 0, 0, 0, 0, 0 ); // Clean-up the paging queues
            Discard_Page_Queue(po_no);
            linkNo = allocateLinkNo(po_no);
            if (linkNo == 0xFF) {
               Mmu_Free(frame_ptr);
            } else {
               hli_length = (( struct HLI_Header * ) frame_ptr ) -> length - sizeof( struct HLI_Header );
                                                      /* rebuild the CLMS message( address section + data section ) */
                                                      /* Note:  the field "Length indicator/Data" in address section & "CLMS header" in data section */ 
                                                      /* => will be handled by in paging response mechanism in MAC */ 
                                                      /* therefore we need only 4 byte address section header in this section */
               temp_ptr = Mmu_Malloc(4 + hli_length + sizeof( struct HLI_Header ) ); 
               Mmu_Memcpy( &temp_ptr[4+sizeof( struct HLI_Header )], &frame_ptr[sizeof( struct HLI_Header )], hli_length);
                                                      /* adjust the length field */
               (( struct HLI_Header * ) temp_ptr ) -> length  = 4 + hli_length + sizeof( struct HLI_Header );

                                                         /* Set the A-bit for addresss section      */
               temp_ptr[ sizeof( struct HLI_Header )     ]  = 0x08;
               temp_ptr[ sizeof( struct HLI_Header )     ] |= ( service & 0x07 ) | PT_LONG_PAGE_FIRST_BITS;
                                                         /* Address field: lowest 16s bit of the assigned TPUI */
               tpui_ptr = Subscription_GetTPUIRef( po_no );
               temp_ptr[ 1+sizeof( struct HLI_Header )     ] =  tpui_ptr[1];
               temp_ptr[ 2+sizeof( struct HLI_Header )     ] =  tpui_ptr[2];
                                                         /* PD field: DECT IE coding */
               temp_ptr[ 3+sizeof( struct HLI_Header )     ] =  0x01;
               //if( service ==STANDARD_SINGLE_SECTION )
                  //temp_ptr[ 4+sizeof( struct HLI_Header )     ] =  0x00;
                                                         /* Length indicator / data field: This will be handled in paging response in MAC  */                                                         
               //temp_ptr[ 4+sizeof( struct HLI_Header )     ] =  0x00;
                                                         
                                       /* Send paging request to the LB    */
                                       /* process.                         */
                                       /* -------------------------------- */
               KNL_SENDTASK_NP( LB, LB_DL_BROADCAST_RQ_LCE, temp_ptr );
                                                 /* Request Paging Timer             */
                                                 /* -------------------------------- */
                                                 /* Timer:    <LCE_page.03>          */
                                                 /* Duration: 3 seconds              */
               Start_Pro_Timer( TIMER_LCE_03, LINK_NO );
               KNL_SENDTASK_NP( LB, LB_DL_BROADCAST_RQ_LCE, temp_ptr );
                                                   /* The NTW-Layer message is stored  */
                                                   /* in the paging queue.             */
                                                   /* -------------------------------- */
               Put_In_Page_Queue( po_no, CLMS, service, frame_ptr, 0xff, 0xff, 0xff );
               Link_Establish[LINK_NO].page_service = (service & 0x87)  | PT_LONG_PAGE_FIRST_BITS; //U_PLAN_SERVICE_UNKNOWN_AND_RINGING;
               Link_Establish[LINK_NO].page_pattern = ring_pattern;
               Link_Establish[LINK_NO].page_cnt = life; //Continue until request to stop
               if( life != 0xff )
                  Link_Establish[LINK_NO].page_cnt = (Link_Establish[LINK_NO].page_cnt) / 3; //
           }
         }
         break;
   }                                   
}
#endif         

/*
*****************************************************************************
*                                                                           *
*   Function   :  Send_To_NTW_Layer                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function provides for the application layer the       *
*                 facility to transfer messages to the network layer.       *
*                 Depending on the current link status, the paging is       *
*                 invoked, the message is stored in the paging queue or the *
*                 message is directly transferred to the network layer.     *
*   Parms      :  po_no           : 'sending' portable                      *
*                 proc            : receiver process of NTW layer (CC,MM)   *
*                 msg             : message for the NTW layer               *
*                 frame_ptr       : pointer to NTW layer frame              *
*                 reset_flag:     : reset flag                              *
*                 fail_proc       : process id to be informed in case of a  *
*                                   paging expiry                           *
*                 fail_msg        : fail message to be send                 *
*                 fail_inc        : incarnation of fail process             *
*   Return     :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Send_To_NTW_Layer( BYTE po_no, BYTE proc, BYTE msg, FPTR frame_ptr, BYTE reset_flag,
                   BYTE fail_proc, BYTE fail_msg, BYTE fail_inc )
{
   BYTE cid,temp_slot_mode;
   FPTR temp;
   BYTE linkNo;
                                       /* Function parameter checking      */
                                       /* -------------------------------- */

                                       /* Check for reasonable proc        */
                                       /* values. Only CC and MM process   */
                                       /* are supported !                  */
   #ifdef FT_CLMS         
   if(( proc != CC ) && ( proc != MM ) && (proc != CLMS) )
   #else      
   if(( proc != CC ) && ( proc != MM ) )
   #endif      
   {
      Mmu_Free( frame_ptr );
      return;
   }
                                       /* Reasonable value for po_no ?     */
   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
   if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
   #endif
   {
      Mmu_Free( frame_ptr );
      return;
   }

                                          /* Does already a NTW-Layer         */
                                       /* assignment exists to the         */
                                       /* portable ?                       */
                                       /* -------------------------------- */
   for( cid = 0; cid < MAX_LINK; cid++ )
   {
      if( App_Layer_Assignment[ cid ].po_no == po_no )
      {
                                       /* A NTW-Layer entity is already    */
                                       /* assigned to the sending          */
                                       /* portable.                        */
                                       /* -------------------------------- */
                                       /* Check the current link status.   */
         if( App_Layer_Assignment[ cid ].status == LINK_OPEN )
         {
                                       /* Link status is open, the message */
                                       /* can directly be transferred to   */
                                       /* the NTW-Layer.                   */
                                       /* -------------------------------- */
                                       /* Interface App-Layer<->NTW-Layer  */
                                       /* P1: return proc                  */
                                       /* P2: return msg                   */
                                       /* P3: return inc                   */
                                       /* P4: po_no                        */
            KNL_SENDTASK_NP_WP_INC(proc,
                                   msg,
                                   frame_ptr,
                                   fail_proc,
                                   fail_msg,
                                   fail_inc,
                                   po_no,
                                   cid);

            return;
         }
         else
         {

            if( App_Layer_Assignment[ cid ].status == LINK_SUSPENDED )
            {
                                       /* The LCE process has started the  */
                                       /* link release procedure. Inform   */
                                       /* the LCE process by resetting the */
                                       /* link status, that the link is    */
                                       /* required again.                  */
               App_Layer_Assignment[ cid ].status = LINK_OPEN;
                                       /* Interface App-Layer<->NTW-Layer  */
                                       /* P1: return proc                  */
                                       /* P2: return msg                   */
                                       /* P3: return inc                   */
                                       /* P4: po_no                        */
               KNL_SENDTASK_NP_WP_INC(proc,
                                      msg,
                                      frame_ptr,
                                      fail_proc,
                                      fail_msg,
                                      fail_inc,
                                      po_no,
                                      cid);
               return;
            }
            else
            {
                                       /* The link is locked by the LCE    */
                                       /* process. An release indication   */
                                       /* was received by the LCE process. */
                                       /* The release indication for the   */
                                       /* application layer is on way.     */
                                       /* There is no sense to transfer    */
                                       /* the NTW-Layer message.           */
                                       /* -------------------------------- */
                                       /* Interface NTW-Layer<->App-Layer  */
                                       /* P1: result                       */
                                       /* P2: not used                     */
                                       /* P3: cid (no link -> 0xFF)        */
                                       /* P4: po_no                        */

                                       /* Return message required ?        */
               if( fail_proc != 0xFF )
               {
                  Send_Message_To_APP( fail_msg, 
                                       NULL, 
                                       fail_inc,  
                                       po_no,
                                       fail_proc,
                                       DUMMY_FILL,
                                       DUMMY_FILL);
               }

               Mmu_Free( frame_ptr );
               return;
            }
         }
      }
   }
                                       /* No NTW-Layer entity is assigned  */
                                       /* to the portable !                */
                                       /* -------------------------------- */

                                       /* Evaluate the reset flag setting. */
                                       /* -------------------------------- */
                                       /* In case of an unassigned         */
                                       /* NTW-Layer, the reset flag        */
                                       /* indicates the wish of the        */
                                       /* application layer to abort the   */
                                       /* link establishment procedure.    */
                                       /* The paging queue is discarded    */
                                       /* and all fail messages are send   */
                                       /* to the application layer.        */

   if( reset_flag == TRUE )
   {
      Discard_Page_Queue( po_no );
                                       /* Interface NTW-Layer<->App-Layer  */
                                       /* P1: result                       */
                                       /* P2: not used                     */
                                       /* P3: cid (no link -> 0xFF)        */
                                       /* P4: po_no                        */

                                       /* Return message required ?        */
      if( fail_proc != 0xFF )
      {
         Send_Message_To_APP(fail_msg, 
                             NULL, 
                             fail_inc, 
                             po_no, 
                             fail_proc,
                             DUMMY_FILL,
                             DUMMY_FILL);

      }

      Mmu_Free( frame_ptr );
      return;
   }

   linkNo = getActiveLinkNo(po_no);
   if (linkNo == 0xFF) { // Indirect link is not running
      linkNo = allocateLinkNo(po_no);
      if (linkNo == 0xFF) { // No free link
         if (fail_proc != 0xFF) {
            Send_Message_To_APP(fail_msg, 
                                NULL, 
                                fail_inc,  
                                po_no,
                                0,
                                DUMMY_FILL,
                                DUMMY_FILL);
         }
         Mmu_Free(frame_ptr);

         if ((proc == MM) &&
             (msg == MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ) &&
             (fail_msg == FP_ACCESS_RIGHTS_TERMINATE_CFM_MM)) {
            Subscription_Deregister(po_no);
            #ifdef CONFIG_EARLY_ENCRYPTION
            Subscription_UpdateDefaultCipherKeyOfModem(po_no);
            #endif
         }
         return;
      } else { // Found free link
                                          /* The paging queue is empty !      */
                                          /* The portable is not yet paged.   */
                                          /* Start the Indirect FT initiated  */
                                          /* link establishment procedure.    */
                                          /* -------------------------------- */
                                          /* Depending on the requested       */
                                          /* service the appropriate          */
                                          /* LCE-Header must be set.          */
                                          /* (GAP 300 444 / 8.35)             */
                                          /* CC-Proc -> U_PLAN_IN_MIN_DELAY   */
                                          /*            page cnt = N300       */
                                          /* MM-Proc -> U_PLAN_SERVICE_NONE   */
                                          /*            page cnt = 1          */
   
                                          /*            !!!                   */
                                          /* Problem with the R&S Tester      */
                                          /* TS1220 and GAP Tests ITA_v07.    */
                                          /* The tester does not process page */
                                          /* service 'U_PLAN_SERVICE_NONE'    */
                                          /* correctly. All paging message    */
                                          /* are send therefore with page     */
                                          /* service 'U_PLAN_IN_MIN_DELAY' !  */
                                          /*            !!!                   */

         Link_Establish[LINK_NO].page_service = U_PLAN_IN_MIN_DELAY;
   
         #ifdef FT_CLMS         
         if (proc == CLMS) {
            Link_Establish[LINK_NO].page_service = msg | PT_LONG_PAGE_FIRST_BITS; // U_PLAN_SERVICE_UNKNOWN_AND_RINGING;
            Link_Establish[LINK_NO].page_cnt = 1;
         } else 
         #endif       
         {  
            if (proc == CC) {
               // Link_Establish[LINK_NO].page_service = U_PLAN_IN_MIN_DELAY;
               Link_Establish[LINK_NO].page_cnt = N300;
            } else {
               // Link_Establish[LINK_NO].page_service = U_PLAN_SERVICE_NONE;
               Link_Establish[LINK_NO].page_cnt = 1;
            }
         }
   
         #ifdef KLOCWORK
         temp = Subscription_GetTPUIRef(po_no);
         if(temp== NULL) {
            return;
         }
         #endif
                                            /* Assembly the paging message      */
         #ifdef FT_CLMS
         temp = Construct_Paging_Message((Link_Establish[LINK_NO].page_service & 0x7F),
                                          Link_Establish[LINK_NO].page_pattern,
                                          #ifdef KLOCWORK
                                          temp,
                                          #else
                                          Subscription_GetTPUIRef(po_no),
                                          #endif
                                          po_no);
         #else
         temp = Construct_Paging_Message(Link_Establish[LINK_NO].page_service,
                                          #ifdef KLOCWORK
                                          temp,
                                          #else
                                         Subscription_GetTPUIRef(po_no),
                                          #endif
                                         po_no);
         #endif
                                          /* Send paging request to the LB    */
                                          /* process.                         */
                                          /* -------------------------------- */
         #ifdef DECT_NG_WBS
            #ifdef ULE_SUPPORT
         if(Get_Required_Slot_Type(po_no) == 1)
            #else
         if (Required_Slot_Type[po_no - 1] == 1)
            #endif
            temp_slot_mode = 1;
         else
            temp_slot_mode = 0;
         #else
            #ifdef ULE_SUPPORT
         if (Get_Terminal_Cap(po_no) == 1)
            #else
         if (Terminal_Cap[po_no - 1] == 1 )
            #endif
            temp_slot_mode = 1;
         else
            temp_slot_mode = 0;
         #endif
                                 
         KNL_SENDTASK_NP_WP( LB, LB_DL_BROADCAST_RQ_LCE, temp, temp_slot_mode, 0, 0, 0 );
                                             /* Request Paging Timer             */
                                          /* -------------------------------- */
                                          /* Timer:    <LCE_page.03>          */
                                          /* Duration: 3 seconds              */
                                          /*                                  */
                                          /* NOTE:                            */
                                          /* The incarnation is for all       */
                                          /* protocol timer equal to the CID  */
                                          /* value. For the Request Page      */
                                          /* Timer the incarnation value is   */
                                          /* equal to the portable number     */
                                          /* (po_no) !                        */
   
         Start_Pro_Timer( TIMER_LCE_03, LINK_NO );
      }
   }

                                          /* in the paging queue.             */
                                          /* -------------------------------- */
   Put_In_Page_Queue(po_no, proc, msg, frame_ptr, fail_proc, fail_msg, fail_inc);
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Lock_App_Layer_Assignment                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function locks the application layer assignment.      *
*   Parms      :  cid               : Connection ID of LCE process          *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  Called by the LCE process after receiving a link release  *
*                 indication.                                               *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Lock_App_Layer_Assignment( BYTE cid )
{
                                       /* Reasonable value for cid ?       */
   if( cid >= MAX_LINK )
      return;

   App_Layer_Assignment[ cid ].status = LINK_LOCKED;
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Suspend_App_Layer_Assignment                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function suspends the application layer assignment.   *
*   Parms      :  cid               : Connection ID of LCE process          *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  Called by the LCE process when invoking the FT initiated  *
*                 link release procedure.                                   *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Suspend_App_Layer_Assignment( BYTE cid )
{
                                       /* Reasonable value for cid ?       */
   if( cid >= MAX_LINK )
      return;

   App_Layer_Assignment[ cid ].status = LINK_SUSPENDED;
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  App_Layer_Assignment_Suspended                            *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function checks, if the application layer assignment  *
*                 is still suspended.                                       *
*   Parms      :  cid               : Connection ID of LCE process          *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  If the functions returns TRUE, the LCE process can        *
*                 continue with the FT initiated link release procedure.    *                               *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BIT
App_Layer_Assignment_Suspended( BYTE cid )
{
                                       /* Reasonable value for cid ?       */
   if( cid >= MAX_LINK )
      return( FALSE );

   return( App_Layer_Assignment[ cid ].status == LINK_SUSPENDED );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Clear_App_Layer_Assignment                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function clears the application layer assignment.     *
*   Parms      :  cid               : Connection ID of LCE process          *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  Called by the LCE process during link release procedure.  *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Clear_App_Layer_Assignment( BYTE cid )
{
                                      /* Reasonable value for cid ?       */
   if( cid >= MAX_LINK )
      return;

   App_Layer_Assignment[ cid ].po_no  = 0xFF;
   App_Layer_Assignment[ cid ].status = 0xFF;
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Set_App_Layer_Assignment                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function sets the application layer assignment.       *
*   Parms      :  cid               : Connection ID of LCE process          *
*                 po_no             : portable number                       *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  Called by a NTW layer process (LCE,CC,MM) when the first  *
*                 IPUI portable identity is received within a network layer *
*                 frame.                                                    *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Set_App_Layer_Assignment( BYTE cid, BYTE po_no )
{
   BYTE linkNo;
   #ifdef FT_CLMS
   BYTE service_type;
   #endif

   linkNo = getActiveLinkNo(po_no);

   #ifdef FT_CLMS
   if (linkNo != 0xFF) {
      service_type = Link_Establish[LINK_NO].page_service & 0x07;
   } else {
      service_type = 0xFF & 0x07;
   }
   #endif

                                       /* Reasonable value for cid ?       */
   if( cid >= MAX_LINK )
      return;
                                       /* Reasonable value for po_no ?     */
   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
   if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
   #endif
      return;

   App_Layer_Assignment[ cid ].po_no  = po_no;
   App_Layer_Assignment[ cid ].status = LINK_OPEN;

   #ifdef DECT_NG
   #ifdef ULE_SUPPORT
   Set_Required_Slot_Type(po_no, Required_Slot_Type_CID[cid]);
   #else
   Required_Slot_Type[po_no-1]  = Required_Slot_Type_CID[cid];
   #endif
   #endif

   #if 1  // CODEC_CHANGE1
      #ifdef ULE_SUPPORT
   Set_Actual_Slot_Type(po_no, Required_Slot_Type_CID[cid]);
      #else
   Actual_Slot_Type[po_no-1]  = Required_Slot_Type_CID[cid];
      #endif
   #endif

                                       /* In case of a Indirekt FT         */
                                       /* initiated link establishment     */
                                       /* procedure, the paging timer is   */
                                       /* stopped and all NTW-Layer        */
                                       /* messages stored in the paging    */
                                       /* queue are immediately send.      */
                                       /* -------------------------------- */
   #ifdef FT_CLMS
   if( (ProcId == MM) &&  ((service_type == U_PLAN_SERVICE_UNKNOWN_AND_RINGING) ||
       (( service_type >= CLMS_FIXED_STANDARD_SINGLE_SECTION) && ( service_type <=CLMS_FIXED_ALPHANUMERIC_MULTI_SECTION ))))
       return;
   #endif

   if ((linkNo != 0xFF))
   {
      Stop_Pro_Timer(TIMER_LCE_03, LINK_NO);
      Send_Page_Queue(po_no, cid);
   }
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Get_Assigned_CID                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function returns the assigned network layer CID value *
*                 for a specific application layer instance.                *
*   Parms      :  po_no             : portable number                       *
*   Returns    :  assigned CID value                                        *
*   Call Level :  Process Level                                             *
*   Remarks    :  The SWI process requires the assigned CID value for       *
*                 the voice enable/disable command to the MAC layer.        *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BYTE
Get_Assigned_CID( BYTE po_no )
{
   BYTE cid;

                                             /* Reasonable value for po_no ?     */
   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
   if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
   #endif
      return( 0xFF );

   for( cid = 0; cid < MAX_LINK; cid++ )
      if( App_Layer_Assignment[ cid ].po_no == po_no )
         return( cid );

   return( 0xFF );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Get_Assigned_Po_No                                        *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function returns the assigned portable for a specific *
*                 network layer instance.                                   *
*   Parms      :  cid               : CID value                             *
*   Returns    :  assigned CID value                                        *
*   Call Level :  Process Level                                             *
*   Remarks    :  The network layer process CC requires the assigned        *
*                 portable number to route all incoming messags to the      *
*                 application layer instance.                               *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BYTE
Get_Assigned_Po_No( BYTE cid )
{
                                       /* Reasonable value for cid ?       */
   if( cid >= MAX_LINK )
      return( 0xFF );

   return( App_Layer_Assignment[ cid ].po_no );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Paging_Timer_Expired                                      *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function is called by the LCE process, when the       *
*                 paging timer <LCE.03> is expired.                         *
*   Parms      :  po_no             : portable number                       *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :  The incarnation of the calling LCE process instance does  *
*                 not correspond to the CID value. The incarnation is used  *
*                 to refer to the portable number !                         *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Paging_Timer_Expired(BYTE linkNo)
{
   FPTR temp;
   BYTE temp_slot_mode;
   BYTE po_no;

   po_no = Link_Establish[linkNo].portableNo;
                                        /* Reasonable value for po_no ?     */
   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL)) {
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL)) {
      #endif
   #else
   if ((po_no == 0) || (po_no > MAX_PORTABLE)) {
   #endif
      return;
   }

                                        /* Request Paging Timer expired.    */
                                        /* -------------------------------- */

                                        /* Paging queue still there ?       */
   if (Link_Establish[LINK_NO].pHead == NULL) {
      return;
   }
   
                                       /* All requested paging requests    */
                                        /* done ?                           */
   if( Link_Establish[LINK_NO].page_cnt != 0 )
   {
      Link_Establish[LINK_NO].page_cnt--;
   }

   if (Link_Establish[LINK_NO].page_cnt == 0)
   {
                                        /* The paging queue is discarded.   */
                                        /* The application layer is         */
                                        /* informed through the fail        */
                                        /* messages stored in the paging    */
                                        /* queue.                           */
      Discard_Page_Queue(po_no);
   } else {
                                        /* Maximum of paging requests not   */
                                        /* reached, try again.              */

                                        /* Request Paging Timer             */
                                        /* -------------------------------- */
                                        /* Timer:    <LCE_page.03>          */
                                        /* Duration: 3 seconds              */
      Start_Pro_Timer(TIMER_LCE_03, LINK_NO);
                                        /* Assembly the paging message      */
      #ifdef KLOCWORK
      temp = Subscription_GetTPUIRef(po_no);
      if(temp== NULL) {
         return;
      }
      #endif
      #ifdef FT_CLMS
      if ((Link_Establish[LINK_NO].page_pattern == 0x48) || (Link_Establish[LINK_NO].page_pattern == 0x4F)){
         Link_Establish[LINK_NO].page_pattern = Link_Establish[LINK_NO].page_pattern == 0x48 ? 0x4F:0x48;
      }
      temp = Construct_Paging_Message(Link_Establish[LINK_NO].page_service & 0x7F,
                                      Link_Establish[LINK_NO].page_pattern,
                                      #ifdef KLOCWORK
                                      temp,
                                      #else
                                      Subscription_GetTPUIRef(po_no),
                                      #endif
                                      po_no);
      if ((Link_Establish[LINK_NO].page_service & 0x87) == U_PLAN_SERVICE_UNKNOWN_AND_RINGING_CBI)
      {   // collective-ring?
         temp[1+sizeof( struct HLI_Header )] |= 0x0F;
         temp[2+sizeof( struct HLI_Header )]  = 0xFF;
      }
      #else
      temp = Construct_Paging_Message(Link_Establish[LINK_NO].page_service,
                                      #ifdef KLOCWORK
                                      temp,
                                      #else
                                      Subscription_GetTPUIRef(po_no),
                                      #endif
                                      po_no);
      #endif
                                        /* Send paging request to the LB    */
                                        /* process.                         */
                                        /* -------------------------------- */
      #ifdef ULE_SUPPORT
      if (Get_Required_Slot_Type(po_no) == 1) {
      #else
      if (Required_Slot_Type[po_no - 1] == 1) {
      #endif
         temp_slot_mode = 1;
      } else {
         temp_slot_mode = 0;
      }

      KNL_SENDTASK_NP_WP(LB, LB_DL_BROADCAST_RQ_LCE, temp, temp_slot_mode, 0, 0, 0);
      // KNL_SENDTASK_NP(LB, LB_DL_BROADCAST_RQ_LCE, temp);
   }
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Init_Switching_Structs                                    *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function initializes the Link Establish and           *
*                 Application Layer Assignment structures.                  *
*   Parms      :  none                                                      *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Init_Switching_Structs( void )
{
   /* 
      Init 'Link Establish' structure and 'App_Layer_Addignment.
    */

   BYTE i;

   for (i = 0; i < MAX_LINK; i++)
   {
      Link_Establish[i].portableNo = 0xFF;
      Link_Establish[i].page_service = 0xFF;
      Link_Establish[i].page_cnt     = 0;
      Link_Establish[i].pHead        = NULL;
      Link_Establish[i].pEnd         = NULL;

      //App_Layer_Assignment[i].po_no  = 0xFF;
      //App_Layer_Assignment[i].status = 0xFF;
   }
                                       /* Init 'App_Layer_Assignment'      */
                                       /* structure.                       */
   for( i = 0; i < MAX_LINK; i++ )
   {
      App_Layer_Assignment[i].po_no  = 0xFF;
      App_Layer_Assignment[i].status = 0xFF;
   }
}
#endif


#ifdef FT
EXPORT void
RESET_Init_Switching_Structs( void )
{
   BYTE i;

   /* link list clear by ralph_150508	[[ */
   PAGE_QUEUE_ELEMENT * pHead;
   PAGE_QUEUE_ELEMENT * pTemp;


   for (i = 0; i < MAX_LINK; i++)
   {
      pHead = Link_Establish[i].pHead;
      while( pHead != NULL )
      {
                                       /* Store pointer to old queue */
                                       /* element.                   */
         pTemp = pHead;
                                       /* Move to next element.      */
         pHead = pHead->next;
                                       /* Free memory of the stored  */
                                       /* NTW-Layer message.         */
         if( pTemp->frame_ptr != NULL)
            Mmu_Free( pTemp->frame_ptr );
                                       /* Free memory of the old     */
                                       /* queue element.             */

         if( pTemp != NULL)
            Mmu_Free( (FPTR) pTemp );
      }
   }
   /* link list clear by ralph_150508	]] */

   for (i = 0; i < MAX_LINK; i++) {
      // Init 'Link Establish' structure.
      Link_Establish[i].portableNo = 0xFF;
      Link_Establish[i].page_service = 0xFF;
      Link_Establish[i].page_cnt = 0;
      Link_Establish[i].pHead = NULL;
      Link_Establish[i].pEnd = NULL;

      // Init 'App_Layer_Assignment' structure.
      App_Layer_Assignment[i].po_no = 0xFF;
      App_Layer_Assignment[i].status = 0xFF;
   }
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Discard_Page_Queue                                        *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function discards the paging queue and sends all      *
*                 fail messages to the application layer.                   *
*   Parms      :  po_no           : portable number                         *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT void
Discard_Page_Queue( BYTE po_no )
{
   PAGE_QUEUE_ELEMENT * pHead;
   PAGE_QUEUE_ELEMENT * pTemp;
   BYTE linkNo;
                                       /* Reasonable value for po_no ?     */
   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
   if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
   #endif
      return;
                                       /* Get the Head pointer of the list.*/
   linkNo = getActiveLinkNo(po_no);

   if (linkNo != 0xFF) {
      pHead = Link_Establish[LINK_NO].pHead;
   } else {
      pHead = NULL;
   }
                                       /* For all stored NTW-Layer         */
                                       /* messages the 'fail' Task Queue   */
                                       /* entries are done and the memory  */
                                       /* is freed.                        */
   while( pHead != NULL )
   {
                                       /* Send fail message !              */
                                       /* -------------------------------- */
                                       /* Interface NTW-Layer<->App-Layer  */
                                       /* P1: result                       */
                                       /* P2: not used                     */
                                       /* P3: cid (no link -> 0xFF)        */
                                       /* P4: po_no                        */

                                       /* Return message required ?        */
      if( pHead->fail_proc != 0xFF )
      {
         Send_Message_To_APP( pHead->fail_msg, 
                              NULL, 
                              pHead->fail_inc, 
                              po_no, // pHead -> fail_inc, // po_no, 
                              pHead->fail_proc,
                              DUMMY_FILL,
                              DUMMY_FILL);

         #if 1  // PROBLEM_ISSUE_41
         if ((pHead->proc == MM) &&
             (pHead->msg == MM_MMS_ACCESS_RIGHTS_TERMINATE_RQ) &&
             (pHead->fail_msg == FP_ACCESS_RIGHTS_TERMINATE_CFM_MM)) {
            Subscription_Deregister(po_no); // po_no = 1 ~ 6
            #ifdef CONFIG_EARLY_ENCRYPTION
            Subscription_UpdateDefaultCipherKeyOfModem(po_no);
            #endif
         }
         #endif
      }
                                       /* Store pointer to old queue       */
                                       /* element.                         */
      pTemp = pHead;
                                       /* Move to next element.            */
      pHead = pHead->next;
                                       /* Free memory of the stored        */
                                       /* NTW-Layer message.               */
      Mmu_Free( pTemp->frame_ptr );
                                       /* Free memory of the old queue     */
                                       /* element.                         */
      Mmu_Free( (FPTR) pTemp );
   }
                                       /* Reset Link Establishment         */
                                       /* Structure.                       */
   if (linkNo != 0xFF) 
   {
      Stop_Pro_Timer(TIMER_LCE_03, LINK_NO);

      Link_Establish[LINK_NO].portableNo = 0xFF;
      Link_Establish[LINK_NO].page_service = 0xFF;
      Link_Establish[LINK_NO].page_cnt = 0;
      Link_Establish[LINK_NO].pHead = NULL;
      Link_Establish[LINK_NO].pEnd = NULL;
   }

   // When paging queue for all handsets are empty, send paging queue of HMAC clear command
   for (linkNo = 0; linkNo < MAX_LINK; linkNo++) {
      if (Link_Establish[LINK_NO].portableNo != 0xFF) // if ((Link_Establish[LINK_NO].pHead != NULL) && (Link_Establish[LINK_NO].pEnd != NULL)) 
      {
         break;
      }
   }

   if (linkNo == MAX_LINK) {
      write_to_hmac_ioctl( HMAC, MAC_PAGE_CANCEL_LB, 0, 0, 0, 0, 0, 0, 0, 0 );
   }
}
#endif

