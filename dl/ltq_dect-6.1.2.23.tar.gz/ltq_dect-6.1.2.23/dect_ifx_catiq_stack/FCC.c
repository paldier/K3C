/* -- SIEMENS AG  PCT -- Process: CC          -  Mon Feb 26 14:22:29 2007 -- */
#include "DEFINE.H"
#include <stdio.h>
# include "SYSDEF.H"
# include "FDEF.H"
# include "TYPEDEF.H"
extern void KNL_T0000(void);
# include "SYSEXT.H"

/*
*****************************************************************************
*                                                                           *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  FCC.PSL                                                 *
*     Date       :  18 Nov, 2005                                            *
*     Contents   :                                                          *
*     Hardware   :  IFX 87xx                                                *
*                                                                           *
*****************************************************************************
*/
/* =======================================================================
 * Include Files
 * ======================================================================= */
#include "DEFINE.H"
#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#include "FGLOBAL.H"
#include "PCT_DEF.H"
#include "KNL_SYSTEM.H"
#include "MMU.H"
#include "P_TIM.H"
#include "LCE_LIB.H"
#include "MM_LIB.H"
#include "SYSINIT.H"
#include "CC_DEF.H"
#include "CC_LIB.H"

#include "CP_SERVER.H"
#include "MESSAGE_DEF.H"

#ifdef CATIQ_UPLANE
#include "CAT_UP.H"
#endif
/* =======================================================================
 * External Reference
 * ======================================================================= */
#ifndef ULE_SUPPORT
extern XDATA BYTE First_Codec[ MAX_PORTABLE ];
#endif

#ifdef DECT_NG
extern BYTE Evaluate_CODEC_LIST_IE( void );
#endif
extern void get_pmid_from_hmac_ioctl(BYTE * data);

/* =======================================================================
 * Definitions
 * ======================================================================= */
#if defined(CONFIG_CC_ENCRYPTION) || defined(CONFIG_CALL_SETUP_COLLISION)
#define SET_BITS(var,bits) ((var) |= (bits))
#define TST_BITS(var,bits) ((var) & (bits))
#define CLR_BITS(var,bits) ((var) &= ~(bits))
#endif

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */
#if defined(CONFIG_CC_ENCRYPTION) || defined(CONFIG_CALL_SETUP_COLLISION)
enum {
	FLAG_FIRST_AUTHENTICATION_DONE = BIT0,
   #ifdef CONFIG_EARLY_ENCRYPTION
	FLAG_REKEYING_RUNNING = BIT1,
	#endif
	#ifdef CONFIG_CALL_SETUP_COLLISION
	FLAG_CALL_SETUP_COLLISION = BIT2
	#endif
};
#endif

#ifdef DECT_DEBUG_USER_CC_PRIMITIVE
typedef struct {
	BYTE key;
	char *string;
} DebugStringTable_t;
#endif

/* =======================================================================
 * Local Variables
 * ======================================================================= */
#if defined(CONFIG_CC_ENCRYPTION) || defined(CONFIG_CALL_SETUP_COLLISION)
LOCAL BYTE XDATA flags[MAX_LINK];
#endif
#ifdef CONFIG_CALL_SETUP_COLLISION
LOCAL FPTR backupCCSetupReqDataPtr[MAX_LINK];
#endif

#ifdef DECT_DEBUG_USER_CC_PRIMITIVE
LOCAL DebugStringTable_t stateStringTable[] = {
	{F00, "F00"},
	{F01, "F01"},
	{F02, "F02"},
	{F03, "F03"},
	{F04, "F04"},
	{F06, "F06"},
	{F07, "F07"},
	{F10, "F10"},
	{F19, "F19"},
	{F99, "F99"},
	{0xFF, "Unknown State"}
};

LOCAL DebugStringTable_t messageStringTable[] = {
	{CC_MNCCS_SETUP_RQ_SWI, "CC_MNCCS_SETUP_RQ_SWI"},
	{CC_SETUP_LCE, "CC_SETUP_LCE"},
	{CC_MNCCS_SETUP_ACK_RQ_SWI, "CC_MNCCS_SETUP_ACK_RQ_SWI"},
	{CC_MNCCS_ALERT_RQ_SWI, "CC_MNCCS_ALERT_RQ_SWI"},
	{CC_MNCCS_CONNECT_RQ_SWI, "CC_MNCCS_CONNECT_RQ_SWI"},
	{CC_MNCCS_CALL_PROC_RQ_SWI, "CC_MNCCS_CALL_PROC_RQ_SWI"},
	{CC_MNCCS_REJECT_RQ_SWI, "CC_MNCCS_REJECT_RQ_SWI"},
	{CC_MNCCS_RELEASE_RQ_SWI, "CC_MNCCS_RELEASE_RQ_SWI"},
	{CC_RELEASE_LCE, "CC_RELEASE_LCE"},
	{CC_RELEASE_COM_LCE, "CC_RELEASE_COM_LCE"},
	{CC_DL_REL_IN_LCE, "CC_DL_REL_IN_LCE"},
	{CC_MNCCS_INFO_RQ_SWI, "CC_MNCCS_INFO_RQ_SWI"},
	{CC_MNCCS_IWU_INFO_RQ_SWI, "CC_MNCCS_IWU_INFO_RQ_SWI"},
	{CC_INFO_LCE, "CC_INFO_LCE"},
	{CC_IWU_INFO_LCE, "CC_IWU_INFO_LCE"},
	{CC_TIM_01_EXPIRED, "CC_TIM_01_EXPIRED"},
	{CC_MNCCS_CONNECT_ACK_RQ_SWI, "CC_MNCCS_CONNECT_ACK_RQ_SWI"},
	{CC_ALERTING_LCE, "CC_ALERTING_LCE"},
	{CC_CONNECT_LCE, "CC_CONNECT_LCE"},
	{CC_TIM_03_EXPIRED, "CC_TIM_03_EXPIRED"},
	{CC_MNCCS_SERVICE_CHANGE_RQ_SWI, "CC_MNCCS_SERVICE_CHANGE_RQ_SWI"},
	{CC_MNCCS_SERVICE_ACCEPT_RQ_SWI, "CC_MNCCS_SERVICE_ACCEPT_RQ_SWI"},
	{CC_MNCCS_SERVICE_REJECT_RQ_SWI, "CC_MNCCS_SERVICE_REJECT_RQ_SWI"},
	{CC_SERVICE_CHANGE_LCE, "CC_SERVICE_CHANGE_LCE"},
	{CC_SERVICE_ACCEPT_LCE, "CC_SERVICE_ACCEPT_LCE"},
	{CC_SERVICE_REJECT_LCE, "CC_SERVICE_REJECT_LCE"},
	{CC_TIM_02_EXPIRED, "CC_TIM_02_EXPIRED"},
	{CC_CLSS_FACILITY_RQ_SWI, "CC_CLSS_FACILITY_RQ_SWI"},
	{CC_CLSS_FACILITY_IN_LCE, "CC_CLSS_FACILITY_IN_LCE"},
	{CC_CRSS_FACILITY_RQ_SWI, "CC_CRSS_FACILITY_RQ_SWI"},
	{CC_CRSS_FACILITY_IN_LCE, "CC_CRSS_FACILITY_IN_LCE"},
	#ifdef CONFIG_CC_ENCRYPTION
	{CC_AUTHENTICATE_PT_RQ, "CC_AUTHENTICATE_PT_RQ"},
	{CC_MNCCS_AUTHENTICATE_PT_CFM, "CC_MNCCS_AUTHENTICATE_PT_CFM"},
	{CC_CIPHER_REQ_ON, "CC_CIPHER_REQ_ON"},
	{CC_MNCCS_CIPHER_CFM_ON, "CC_MNCCS_CIPHER_CFM_ON"},
	{CC_TIM_SECURITY_WATCH_EXPIRED, "CC_TIM_SECURITY_WATCH_EXPIRED"},
	#endif
	{0xFF, "Unknown Message"}
};
#endif

/* =======================================================================
 * Global Variables
 * ======================================================================= */

/* =======================================================================
 * Local Function Prototypes
 * ======================================================================= */

/* =======================================================================
 * Local Function Definitions
 * ======================================================================= */

/* =======================================================================
 * Global Function Definitions
 * ======================================================================= */
EXPORT void
CC_INIT( void )
{
   BYTE  i;

   #if !defined(ULE_SUPPORT) && !defined(CONFIG_REPEATER_SUPPORT)
   for( i = 0;  i < MAX_LINK;  i++ )
   {
      Service_Change_State[ i ] = SVC_IDLE;
   }
   #endif

   #ifdef ULE_SUPPORT
   for( i = ULE_DEVICE_OFFSET; i < (ULE_DEVICE_OFFSET + NR_OF_ULE_DEVICE); i++ ) {
      Set_Service_Change_State(i, SVC_IDLE);
   }
   #endif

   #ifdef CONFIG_REPEATER_SUPPORT
   for( i = REP_DEVICE_OFFSET; i < (REP_DEVICE_OFFSET + NR_OF_REP_DEVICE); i++ ) {
      Set_Service_Change_State(i, SVC_IDLE);
   }
   #endif
}

EXPORT BIT
NTW_Connect_Pending( void )
{
	return ( KNL_STATE_ARRAY[CC][0] == F01 );
}

EXPORT BYTE
NTW_CC_State  ( BYTE po_no )
{
	BYTE cid = Get_Assigned_CID( po_no );
	if( cid != 0xFF)
		return ( KNL_STATE_ARRAY[CC][cid] == F01 );
	else
		return 0xFF;
}


#ifdef CATIQ_VE
/* =========================                                            */
/* Local function definition                                            */
/* =========================                                            */
LOCAL void
send_down_clss_message( BYTE msg )
{
	/* Frame there ?                    */
	if( G_PTR == NULL ) {
		return;
	}

	/* Frame too short ?                */
	if(((( struct HLI_Header * ) G_PTR ) -> length ) < 2 + sizeof( struct HLI_Header )) {
		Mmu_Free( G_PTR );
		return;
	}
	/* Overwrite 'dummy' & 'CID' Field  */
	/* of the received MNCC-Primitive ! */
	if(msg ==SS_FACILITY_CRSS){
		G_PTR[ sizeof( struct HLI_Header ) ] = PD_CC | TI_TV_CONNLESS | TI_FLAG_ORIG;
		msg = SS_FACILITY;
	} else {
		G_PTR[ sizeof( struct HLI_Header ) ] = PD_CISS | TI_TV_CONNLESS | TI_FLAG_ORIG;
	}
	G_PTR[ sizeof( struct HLI_Header ) + 1 ] = msg;
	KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, G_PTR, CurrentInc );
} // send_down_clss_message()
#endif



LOCAL void
send_down_message( BYTE msg )
{
	/* Frame there ?                    */
	if( G_PTR == NULL )
		return;
	/* Frame too short ?                */
	if(((( struct HLI_Header * ) G_PTR ) -> length ) < 2 + sizeof( struct HLI_Header ))
	{
		Mmu_Free( G_PTR );
		return;
	}
	/* Overwrite 'dummy' & 'CID' Field  */
	/* of the received MNCC-Primitive ! */
	G_PTR[ sizeof( struct HLI_Header )     ] = PD_CC | TI_Value_PD_CC[ CurrentInc ];
	G_PTR[ sizeof( struct HLI_Header ) + 1 ] = msg;
	KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, G_PTR, CurrentInc );
}

LOCAL void
send_up_message( BYTE msg )
{
	BYTE po_no;
	/* Frame there ?                    */
	if( G_PTR == NULL )
		return;

	/* Frame too short ?                */
	if(((( struct HLI_Header * ) G_PTR ) -> length ) < 2 + sizeof( struct HLI_Header ))
	{
		Mmu_Free( G_PTR );
		return;
	}

	po_no = Get_Assigned_Po_No( CurrentInc );
	/* Reasonable value for po_no ?     */
   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
	if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
   #endif
	{
		Mmu_Free( G_PTR );
		return;
	}
	/* Overwrite 'PD/Ti' & 'Message'    */
	/* Field of the received S-FORMAT   */
	/* Field !                          */
	G_PTR[ sizeof( struct HLI_Header )     ] = 0x00;
	G_PTR[ sizeof( struct HLI_Header ) + 1 ] = 0x00;
	Send_Message_To_APP(msg,
	                    G_PTR,
	                    CurrentInc,
	                    po_no,
	                    DUMMY_FILL,
	                    DUMMY_FILL,
	                    DUMMY_FILL);
}

LOCAL void
send_up_message_WP( BYTE msg, BYTE p2, BYTE p3, BYTE p4 )
{
	BYTE po_no;

	/* Frame there ?                    */
	if( G_PTR == NULL )
		return;
	/* Frame too short ?                */
	if(((( struct HLI_Header * ) G_PTR ) -> length ) < 2 + sizeof( struct HLI_Header ))
	{
		Mmu_Free( G_PTR );
		return;
	}

	po_no = Get_Assigned_Po_No( CurrentInc );
	/* Reasonable value for po_no ?     */
   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
	if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
   #endif
	{
		Mmu_Free( G_PTR );
		return;
	}
	/* Overwrite 'PD/Ti' & 'Message'    */
	/* Field of the received S-FORMAT   */
	/* Field !                          */
	G_PTR[ sizeof( struct HLI_Header )     ] = 0x00;
	G_PTR[ sizeof( struct HLI_Header ) + 1 ] = 0x00;
	Send_Message_To_APP( msg,
	G_PTR,
	CurrentInc,
	po_no,
	p2,
	p3,
	p4 );
}

LOCAL void
send_down_Release_Com( BYTE reason )
{
	FPTR temp;

	temp = Make_S_FORMAT_Message(PD_CC,
	                             TI_Value_PD_CC[ CurrentInc ],
                                CC_RELEASE_COM );
	if( reason != DUMMY_FILL )
		temp = Add_IE_2( temp, RELEASE_REASON, reason );
	KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_down_Release( BYTE reason )
{
	FPTR temp;

	temp = Make_S_FORMAT_Message(PD_CC,
										  TI_Value_PD_CC[ CurrentInc ],
										  CC_RELEASE);
	if( reason != DUMMY_FILL )
		temp = Add_IE_2( temp, RELEASE_REASON, reason );
	KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
}

LOCAL void
send_up_Release( void )
{
	BYTE po_no;

	po_no = Get_Assigned_Po_No( CurrentInc );
	/* Reasonable value for po_no ?     */
   #ifdef ULE_SUPPORT
      #ifdef KLOCWORK
   if (!VALID_PORTABLE_ALL(po_no, PORTABLE_ALL))
      #else
   if (!IsValidPortableNo(po_no, PORTABLE_ALL))
      #endif
   #else
	if(( po_no == 0 ) || ( po_no > MAX_PORTABLE ))
   #endif
		return;

	Send_Message_To_APP(FP_RELEASE_IN_CC,
	                    NULL,
	                    CurrentInc,
	                    po_no,
	                    DUMMY_FILL,
	                    DUMMY_FILL,
	                    DUMMY_FILL);
}

LOCAL void
send_dl_release_rq( BYTE release_mode )
{
	KNL_SENDTASK_WP_INC( LCE, LCE_DL_REL_RQ, release_mode, 0, 0, 0, CurrentInc );
}

#ifdef DECT_NG
LOCAL BYTE
evaluate_BASIC_SERVICE_IE( void )
{
	BYTE pos;

	pos = scan_IE( G_PTR, BASIC_SERVICE, 1, 1 );
	if( pos != 0 )
		return( G_PTR[ pos + 1 ] );
	else
		return( 0 );
}
#endif

#ifdef CONFIG_EARLY_ENCRYPTION
LOCAL BOOL
isRekeyingSupported(BYTE portableNo)
{
	/*
	 * Valid default cipher key index key index: 0x0001 ~ 0xFEFF (EN300175-3 V2.3.0, 7.2.5.7, Table 7.44b)
	 */

	WORD XDATA cipherKeyIndex;

   if (IFX_DECT_GetUserFeatures() & USER_FEATURES_EARLY_ENCRYPTION) { // Support of "Early encryption"
   	if (IFX_DECT_GetUserFeatures() & USER_FEATURES_REKEYING) { // Support of "Re-keying"
   		cipherKeyIndex = Subscription_GetDefaultCipherKeyIndex(portableNo);
   		if (cipherKeyIndex >= 0x0001 && cipherKeyIndex <= 0xFEFF) {
   			return YES;
   		}
   	}
	}

	return NO;
}
#endif

LOCAL void clearCCState(void)
{
	Stop_Pro_Timer(TIMER_CC_01, CurrentInc);
	Stop_Pro_Timer(TIMER_CC_02, CurrentInc);
	Stop_Pro_Timer(TIMER_CC_03, CurrentInc);
	#ifdef CONFIG_CC_ENCRYPTION
	Stop_Pro_Timer(TIMER_CC_SECURITY_WATCH, CurrentInc);
	#endif
	#ifdef CONFIG_EARLY_ENCRYPTION
	Stop_Pro_Timer(TIMER_CC_REKEYING, CurrentInc);
	#endif

   #if defined(CONFIG_CC_ENCRYPTION) || defined(CONFIG_CALL_SETUP_COLLISION)
	flags[CurrentInc] = 0;
	#endif
	#ifdef CONFIG_CALL_SETUP_COLLISION
	if (backupCCSetupReqDataPtr[CurrentInc]) {
	   Mmu_Free(backupCCSetupReqDataPtr[CurrentInc]);
	   backupCCSetupReqDataPtr[CurrentInc] = NULL;
	}
	#endif
	KNL_Transit(F00);
}

static void T0005( void )
{
	/* TRANSITION:      Q05                                                  */
	/* EVENT:           CC_MNCCS_ALERT_RQ_SWI received                       */
	/* STARTING STATE:  F01, F02, F03                                        */
	/* END STATE:       F04                                                  */
	/* ----------------------------------------------------------------------*/
	/* Stop Overlap Sending Timer       */
	/* -------------------------------- */
	Stop_Pro_Timer( TIMER_CC_01, CurrentInc );
	/* forward the << CC_ALERT >> msg.   */
	send_down_message( CC_ALERTING );
   #ifdef CONFIG_CALL_SETUP_COLLISION_DURING_F01
   if (CurrentState == F01) {
      #ifdef CONFIG_CC_ENCRYPTION
      #ifdef CONFIG_EARLY_ENCRYPTION
      KNL_SENDTASK_WP_INC(CC, CC_AUTHENTICATE_PT_RQ, YES, 0, 0, 0, CurrentInc);
      #else
      KNL_SENDTASK_INC(CC, CC_AUTHENTICATE_PT_RQ, CurrentInc);
      #endif
      #endif
   }
   #endif
	/* change to state CALL_DELIVERED   */
	KNL_Transit( F04 );
}

static void T0010( void )
{
	/* TRANSITION:      Q10                                                  */
	/* EVENT:           CC_MNCCS_CONNECT_RQ_SWI received                     */
	/* STARTING STATE:  F01, F02, F03, F04                                   */
	/* END STATE:       F10                                                  */
	/* ----------------------------------------------------------------------*/
	/* Stop Overlap Sending Timer       */
	/* -------------------------------- */
	Stop_Pro_Timer( TIMER_CC_01, CurrentInc );
	/* forward the << CC_CONNECT >> msg  */
	send_down_message( CC_CONNECT );
   #ifdef CONFIG_CALL_SETUP_COLLISION_DURING_F01
   if (CurrentState == F01) {
      #ifdef CONFIG_CC_ENCRYPTION
      #ifdef CONFIG_EARLY_ENCRYPTION
      KNL_SENDTASK_WP_INC(CC, CC_AUTHENTICATE_PT_RQ, YES, 0, 0, 0, CurrentInc);
      #else
      KNL_SENDTASK_INC(CC, CC_AUTHENTICATE_PT_RQ, CurrentInc);
      #endif
      #endif
   }
   #endif
	/* change to state ACTIVE            */
	KNL_Transit( F10 );
}

static void T0009( void )
{
	/* TRANSITION:      Q09                                                  */
	/* EVENT:           CC_MNCCS_CALL_PROC_RQ_SWI received                   */
	/* STARTING STATE:  F01 / F02                                            */
	/* END STATE:       F03                                                  */
	/* ----------------------------------------------------------------------*/
	/* Stop Overlap Sending Timer       */
	/* -------------------------------- */
	Stop_Pro_Timer( TIMER_CC_01, CurrentInc );
	/* forward the << CC_CALL_PROC >> msg*/
	send_down_message( CC_CALL_PROC );
   #ifdef CONFIG_CALL_SETUP_COLLISION_DURING_F01
   if (CurrentState == F01) {
      #ifdef CONFIG_CC_ENCRYPTION
      #ifdef CONFIG_EARLY_ENCRYPTION
      KNL_SENDTASK_WP_INC(CC, CC_AUTHENTICATE_PT_RQ, YES, 0, 0, 0, CurrentInc);
      #else
      KNL_SENDTASK_INC(CC, CC_AUTHENTICATE_PT_RQ, CurrentInc);
      #endif
      #endif
   }
   #endif
	/* change to state CALL_PROCEEDING   */
	KNL_Transit( F03 );
}

static void T0016( void )
{
	/* TRANSITION:      Q16                                                  */
	/* EVENT:           CC_MNCCS_REJECT_RQ_SWI received                      */
	/* STARTING STATE:  F01, F02                                             */
	/* END STATE:       F00                                                  */
	/* ----------------------------------------------------------------------*/
	/* forward the << CC_REJECT >> msg. */
	/* Note:                            */
	/* the << CC_REJECT >> msg is       */
	/* converted to << CC_RELEASE_COM >>*/
	send_down_message( CC_RELEASE_COM );
	send_dl_release_rq( NORMAL );
	clearCCState();
}

static void T0013( void )
{
	/* TRANSITION:      Q13                                                  */
	/* EVENT:           CC_MNCCS_RELEASE_RQ_SWI received                     */
	/* STARTING STATE:  F03, F04, F06, F07, F10                              */
	/* END STATE:       F19                                                  */
	/* ----------------------------------------------------------------------*/
	/* Release Timer                    */
	/* -------------------------------- */
	/* Timer:     <CC_release.02>       */
	/* Duration:  30 seconds            */
	Start_Pro_Timer( TIMER_CC_02, CurrentInc );
	/* forward the << CC_RELEASE >> msg.*/
	send_down_message( CC_RELEASE );
   #ifdef CONFIG_CALL_SETUP_COLLISION
   if (CurrentState == F06) {
      if (backupCCSetupReqDataPtr[CurrentInc]) {
         Mmu_Free(backupCCSetupReqDataPtr[CurrentInc]);
         backupCCSetupReqDataPtr[CurrentInc] = NULL;
      }
   }
   #endif
	/* change to state RELEASE_PENDING  */
	KNL_Transit( F19 );
}

static void T0020( void )
{
	/* TRANSITION:      Q20                                                  */
	/* EVENT:           CC_RELEASE_LCE received                              */
	/* STARTING STATE:  F01, F02, F03, F04, F07, F10                         */
	/* END STATE:       F00                                                  */
	/* ----------------------------------------------------------------------*/
	BYTE pos;

	/* report the << CC_RELEASE >> msg   */
	send_up_message( FP_RELEASE_IN_CC );
	/* The CC Process is responsible    */
	/* for sending the                  */
	/* << CC_RELEASE_COM >> message!    */
	/* Partial Release requested ?      */
	/* (according to GAP 300 444 / 8.9) */
	/* -------------------------------- */
	/* << RELEASE REASON >> IE          */
	/* included ?                       */
	pos = scan_IE( G_PTR, RELEASE_REASON, 0, 0 );
	/* Release Reason 'Partial' ?       */
	if(( pos != 0 ) && ( G_PTR[ pos + 1 ] == PARTIAL_RELEASE ))
	{
		send_down_Release_Com( PARTIAL_RELEASE );
		send_dl_release_rq( PARTIAL_RELEASE );
	}
	else
	{
		send_down_Release_Com( NORMAL );
		send_dl_release_rq( NORMAL );
	}
	clearCCState();
}

static void T0014( void )
{
	/* TRANSITION:      Q14                                                  */
	/* EVENT:           CC_RELEASE_COMPLETE_LCE received                     */
	/* STARTING STATE:  F01, F02, F03, F04, F07, F10                         */
	/* END STATE:       F00                                                  */
	/* ----------------------------------------------------------------------*/
	BYTE pos;
	/* report the << CC_RELEASE_COM >>  */
	/* msg                              */
	send_up_message( FP_RELEASE_IN_CC );
	/* Partial Release requested ?      */
	/* (according to GAP 300 444 / 8.9) */
	/* -------------------------------- */
	/* << RELEASE REASON >> IE          */
	/* included ?                       */
	pos = scan_IE( G_PTR, RELEASE_REASON, 0, 0 );
	/* Release Reason 'Partial' ?       */
	if(( pos != 0 ) && ( G_PTR[ pos + 1 ] == PARTIAL_RELEASE ))
	{
		send_dl_release_rq( PARTIAL_RELEASE );
	}
	else
	{
		send_dl_release_rq( NORMAL );
	}
	clearCCState();
}

static void T0050( void )
{
	/* TRANSITION:      Q50                                                  */
	/* EVENT:           Data Link Release                                    */
	/* STARTING STATE:  all                                                  */
	/* END STATE:       F00                                                  */
	/* ----------------------------------------------------------------------*/
	/* Unexpected Release of the link,  */
	/* the application layer is         */
	/* informed with a Release message. */
	send_up_Release( );
	clearCCState();
}

static void T0112( void )
{
	/* TRANSITION:      Q112                                                 */
	/* EVENT:           CC_MNCCS_INFO_RQ_SWI received                        */
	/* STARTING STATE:  F02, F03, F04, F06, F07, F10                         */
	/* END STATE:       current state maintained                             */
	/* ----------------------------------------------------------------------*/
	/* forward the << CC_INFO >> msg     */
	send_down_message( CC_INFO );
}

static void T0012( void )
{

	/* TRANSITION:      Q12                                                  */
	/* EVENT:           CC_INFO_LCE received                                 */
	/* STARTING STATE:  F03, F04, F07, F10                                   */
	/* END STATE:       current state maintained                             */
	/* ----------------------------------------------------------------------*/
	/* report the << CC_INFO >> msg     */
	send_up_message( FP_INFO_IN_CC );
}

static void T0030( void )
{
	/* TRANSITION:      Q30                                                  */
	/* EVENT:           CC_MNCCS_CONNECT_ACK_RQ_SWI received                 */
	/* STARTING STATE:  F06, F07                                             */
	/* END STATE:       F10                                                  */
	/* ----------------------------------------------------------------------*/
	/* forward the << CC_CONNECT_ACK >> */
	/* msg                              */
	send_down_message( CC_CONNECT_ACK );
   #ifdef CONFIG_CALL_SETUP_COLLISION
   if (CurrentState == F06) {
      if (backupCCSetupReqDataPtr[CurrentInc]) {
         Mmu_Free(backupCCSetupReqDataPtr[CurrentInc]);
         backupCCSetupReqDataPtr[CurrentInc] = NULL;
      }
   }
   #endif
	KNL_Transit( F10 );
}

static void T0007( void )
{
	/* TRANSITION:      Q07                                                  */
	/* EVENT:           CC_CONNECT_LCE received                              */
	/* STARTING STATE:  F06, F07                                             */
	/* END STATE:       Current State maintained                             */
	/* ----------------------------------------------------------------------*/
	/* report the << CC_CONNECT >> msg  */


	#ifdef  DECT_NG
	#ifdef ULE_SUPPORT
   send_up_message_WP(FP_CONNECT_IN_CC, DUMMY_FILL, Evaluate_CODEC_LIST_IE( ), Get_Actual_Slot_Type(Get_Assigned_Po_No( CurrentInc )));
	#else
   send_up_message_WP(FP_CONNECT_IN_CC, DUMMY_FILL, Evaluate_CODEC_LIST_IE( ), Actual_Slot_Type[Get_Assigned_Po_No( CurrentInc ) - 1]);
	#endif
	#else
	send_up_message( FP_CONNECT_IN_CC );
	#endif
	#ifdef CONFIG_CC_ENCRYPTION
	if (CurrentState == F06) {
		#ifdef CONFIG_EARLY_ENCRYPTION
		KNL_SENDTASK_WP_INC(CC, CC_AUTHENTICATE_PT_RQ, YES, 0, 0, 0, CurrentInc);
		#else
		KNL_SENDTASK_INC(CC, CC_AUTHENTICATE_PT_RQ, CurrentInc);
		#endif
	}
	#endif

   #ifdef CONFIG_CALL_SETUP_COLLISION
   if (CurrentState == F06) {
      if (backupCCSetupReqDataPtr[CurrentInc]) {
         Mmu_Free(backupCCSetupReqDataPtr[CurrentInc]);
         backupCCSetupReqDataPtr[CurrentInc] = NULL;
      }
   }
   #endif

	/* The CC process changes after the */
	/* receipt of the                   */
	/* CC_MNCCS_CONNECT_ACK_RQ_SWI      */
	/* message to state F10 (ACTIVE).   */
}

#ifdef CONFIG_CC_ENCRYPTION
static void T0561( void )
{
	// TRANSITION: 	  Q561
	// EVENT:			  CC_AUTHENTICATE_PT_RQ
	// STARTING STATE:  F
	// END STATE:		  F
	// ------------------------------------------------------------------------
	BYTE portableNo;

	portableNo = Get_Assigned_Po_No(CurrentInc);
	#ifdef CONFIG_EARLY_ENCRYPTION
	if (PARAMETER1 == YES) { // if first authentication of PT
		if (TST_BITS(flags[CurrentInc], FLAG_FIRST_AUTHENTICATION_DONE) == 0) { // if it is not done
			KNL_SENDTASK_WP_INC(MM, MM_MMS_AUTHENTICATE_PT_RQ, CC, CC_MNCCS_AUTHENTICATE_PT_CFM, CurrentInc, portableNo, CurrentInc);
			Start_Pro_Timer(TIMER_CC_SECURITY_WATCH, CurrentInc);
			SET_BITS(flags[CurrentInc], FLAG_FIRST_AUTHENTICATION_DONE);
			// DEBUG_PRINT(PRINTF("FirstAuthReq:%bu:%bu\n", CurrentInc, CurrentState));

			if (isRekeyingSupported(portableNo) == YES) {
				Start_Pro_Timer(TIMER_CC_REKEYING, CurrentInc); // <MM_re-keying.1>
				// DEBUG_PRINT(PRINTF("RunRekeyingTimer\n"));
			}
		}
	} else { // if the message is for rekeying
		KNL_SENDTASK_WP_INC(MM, MM_MMS_AUTHENTICATE_PT_RQ, CC, CC_MNCCS_AUTHENTICATE_PT_CFM, CurrentInc, portableNo, CurrentInc);
		Start_Pro_Timer(TIMER_CC_REKEYING, CurrentInc); // <MM_re-keying.1>
		SET_BITS(flags[CurrentInc], FLAG_REKEYING_RUNNING);
		// DEBUG_PRINT(PRINTF("NextAuthReq:%bu:%bu\n", CurrentInc, CurrentState));
	}
	#else
	if (TST_BITS(flags[CurrentInc], FLAG_FIRST_AUTHENTICATION_DONE) == 0) { // if it is not done
		KNL_SENDTASK_WP_INC(MM, MM_MMS_AUTHENTICATE_PT_RQ, CC, CC_MNCCS_AUTHENTICATE_PT_CFM, CurrentInc, portableNo, CurrentInc);
		Start_Pro_Timer(TIMER_CC_SECURITY_WATCH, CurrentInc);
		SET_BITS(flags[CurrentInc], FLAG_FIRST_AUTHENTICATION_DONE);
		// DEBUG_PRINT(PRINTF("FirstAuthReq:%bu:%bu\n", CurrentInc, CurrentState));
	}
	#endif
}

static void T0562( void )
{
	// TRANSITION: 	  Q562
	// EVENT:			  CC_MNCCS_AUTHENTICATE_PT_CFM
	// STARTING STATE:  F
	// END STATE:		  F
	// ------------------------------------------------------------------------
	#ifdef CONFIG_EARLY_ENCRYPTION
	BYTE releaseReason;
	#endif

	if (PARAMETER1 == TRUE) {
		// DEBUG_PRINT(PRINTF("AuthCfm:%bu:%bu\n", CurrentInc, CurrentState));
		if (IFX_DECT_GetUserFeatures() & USER_FEATURES_ENCRYPTION) {
			KNL_SENDTASK_INC(CC, CC_CIPHER_REQ_ON, CurrentInc);
		} else {
			Stop_Pro_Timer(TIMER_CC_SECURITY_WATCH, CurrentInc);
			// DEBUG_PRINT(PRINTF("StopWatchTimer\n"));
		}
	} else {
		#ifdef CONFIG_EARLY_ENCRYPTION
		if (TST_BITS(flags[CurrentInc], FLAG_REKEYING_RUNNING)) {
			releaseReason = REKEYING_FAILED;
		} else {
			releaseReason = AUTHENTICATION_FAILED;
		}
		#endif

		send_up_Release();
		#ifdef CONFIG_EARLY_ENCRYPTION
		// DEBUG_PRINT(PRINTF("AuthFail(%02bX):%bu:%bu\n", releaseReason, CurrentInc, CurrentState));
		send_down_Release_Com(releaseReason);
		#else
		// DEBUG_PRINT(PRINTF("AuthFail(09):%bu:%bu\n", CurrentInc, CurrentState));
		send_down_Release_Com(AUTHENTICATION_FAILED);
		#endif
		clearCCState();
	}
}

static void T0563( void )
{
	// TRANSITION: 	  Q563
	// EVENT:			  CC_CIPHER_REQ_ON
	// STARTING STATE:  F
	// END STATE:		  F
	// ------------------------------------------------------------------------
	KNL_SENDTASK_WP_INC(MM, MM_MMS_CIPHER_ON_RQ, CC, CC_MNCCS_CIPHER_CFM_ON, CurrentInc, Get_Assigned_Po_No(CurrentInc), CurrentInc);
	// DEBUG_PRINT(PRINTF("CipherReq:%bu:%bu\n", CurrentInc, CurrentState));
}

static void T0564( void )
{
	// TRANSITION: 	  Q564
	// EVENT:			  CC_MNCCS_CIPHER_CFM_ON
	// STARTING STATE:  F
	// END STATE:		  F
	// ------------------------------------------------------------------------
	if (PARAMETER1 == TRUE) {
		Stop_Pro_Timer(TIMER_CC_SECURITY_WATCH, CurrentInc);
		// DEBUG_PRINT(PRINTF("CipherCfm:%bu:%bu\n", CurrentInc, CurrentState));
	} else {
		// DEBUG_PRINT(PRINTF("CipherFail:%bu:%bu\n", CurrentInc, CurrentState));
		send_up_Release();
		send_down_Release_Com(ENCRYPTION_ACTIVATION_FAILED);
		clearCCState();
	}
}

static void T0565( void )
{
	// TRANSITION: 	  Q565
	// EVENT:			  CC_TIM_SECURITY_WATCH_EXPIRED
	// STARTING STATE:  F
	// END STATE:		  F
	// ------------------------------------------------------------------------
	// DEBUG_PRINT(PRINTF("WatchTimerOut\n"));
	send_up_Release();
	send_down_Release_Com(ENCRYPTION_ACTIVATION_FAILED);
	clearCCState();
}
#endif

#ifdef DECT_DEBUG_USER_CC_PRIMITIVE
LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
{
	BYTE i;

	for (i = 0; tablePtr[i].key != 0xFF; i++) {
		if (tablePtr[i].key == key) {
			break;
		}
	}
	return tablePtr[i].string;
}
#endif

void DECODE_CC(void)
{
	#ifdef DECT_DEBUG_USER_CC_PRIMITIVE
	DECT_DEBUG_USER_CC_PRIMITIVE("%s, %s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable), getDebugStringRef(CurrentState, stateStringTable), CurrentInc,
	                             PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
	#endif
	switch (CurrentState)
	{
		case F00:
			switch (CurrentMessage)
			{
				case CC_MNCCS_SETUP_RQ_SWI:  /*  IN LINE CODE T0001    */
				{
					/* TRANSITION:      Q01                                                  */
					/* EVENT:           CC_MNCCS_SETUP_RQ_SWI received                       */
					/* STARTING STATE:  F00                                                  */
					/* END STATE:       F06                                                  */
					/* ----------------------------------------------------------------------*/
					/* Check assigned po_no.            */
					if( Get_Assigned_Po_No( CurrentInc ) != PARAMETER4 )
					{
						Mmu_Free( G_PTR );
						return;
					}

               #ifdef CONFIG_CALL_SETUP_COLLISION
               // "if" is just for safety. It should be not happend.
               if (backupCCSetupReqDataPtr[CurrentInc]) {
                  Mmu_Free(backupCCSetupReqDataPtr[CurrentInc]);
               }
               backupCCSetupReqDataPtr[CurrentInc] = Mmu_Malloc(((struct HLI_Header *)G_PTR)->length);
               Mmu_Memcpy(backupCCSetupReqDataPtr[CurrentInc], G_PTR, ((struct HLI_Header *)G_PTR)->length);
               #endif

					/* Set Transaction Identitfier      */
					/* value.                           */
					/* -------------------------------- */
					/* TI-Value always << 0 >> !        */
					TI_Value_PD_CC[ CurrentInc ] = 0 << 4;
					/* Call Establishment Timer         */
					/* -------------------------------- */
					/* Timer:     <CC_setup.03>         */
					/* Duration:  20 seconds            */
					Start_Pro_Timer( TIMER_CC_03, CurrentInc );
					#ifdef DECT_NG
					#ifdef ULE_SUPPORT
					Set_Actual_Slot_Type(Get_Assigned_Po_No(CurrentInc), Required_Slot_Type_CID[CurrentInc]);
					#else
					Actual_Slot_Type[Get_Assigned_Po_No( CurrentInc ) - 1]  = Required_Slot_Type_CID[CurrentInc];
					#endif
					#endif
					/* forward the << CC_SETUP >> msg   */
					send_down_message( CC_SETUP );
					/* change to state CALL_PRESENT     */
					KNL_Transit( F06 );
				}
				return;

				case CC_SETUP_LCE:  /*  IN LINE CODE T0008    */
				{
					/* TRANSITION:      Q08                                                  */
					/* EVENT:           CC_SETUP_LCE received                                */
					/* STARTING STATE:  F00                                                  */
					/* END STATE:       F01                                                  */
					/* ----------------------------------------------------------------------*/
					BYTE pos, po_no;
					#ifdef DECT_NG
					BYTE temp_codec, temp_service;
					#endif
					/* Store the received transaction   */
					/* identifier.                      */
					/* -------------------------------- */
					/* The TI-value is inverted,        */
					/* because the variable always      */
					/* stores the value wich must be    */
					/* used for sending primitives !    */
					TI_Value_PD_CC[ CurrentInc ]  = G_PTR[ sizeof( struct HLI_Header ) ] & 0xF0;
					TI_Value_PD_CC[ CurrentInc ] ^= 0x80;
					/* Mandatory << PORTABLE IDENTITY >>*/
					/* included ?                       */
					/* -------------------------------- */
					pos = scan_IE( G_PTR, PORTABLE_IDENTITY, 7, 7 );
					if( pos == 0 )
					{
						Mmu_Free( G_PTR );
						send_down_Release_Com( MANDATORY_IE_MISSING );
						send_dl_release_rq( NORMAL );
						clearCCState();
						return;
					}
					/* Content of                       */
					/* << PORTABLE IDENTITY>> correct ? */
					/* -------------------------------- */
					/* The registration of the portable */
					/* is checked.                      */
					#ifdef MASTER_BS
					//Subscription_ForceToRegister( &G_PTR[ pos + 4 ], 0 );
					Subscription_ForceToRegister( &G_PTR[ pos + 4 ], 1 );
					#endif
					po_no = Subscription_GetPotableNoFromIPUI( &G_PTR[ pos + 4 ] );
					if( po_no == 0xFF )
					{
						Mmu_Free( G_PTR );
						send_down_Release_Com( INVALID_IDENTITY );
						send_dl_release_rq( NORMAL );
						clearCCState();
						return;
					}
					/* Mandatory << FIXED IDENTITY >>   */
					/* included ?                       */
					/* -------------------------------- */
					pos = scan_IE( G_PTR, FIXED_IDENTITY, 7, 7 );
					if( pos == 0 )
					{
						Mmu_Free( G_PTR );
						send_down_Release_Com( MANDATORY_IE_MISSING );
						send_dl_release_rq( NORMAL );
						clearCCState();
						return;
					}
					/* Content of                       */
					/* << FIXED IDENTITY>> correct ?    */
					/* -------------------------------- */
					if( ! Check_Received_PARK( &G_PTR[ pos + 4 ] ))
					{
						Mmu_Free( G_PTR );
						send_down_Release_Com( INVALID_IDENTITY );
						send_dl_release_rq( NORMAL );
						clearCCState();
						return;
					}
					/* Mandatory << BASIC SERVICE >>    */
					/* included ?                       */
					/* -------------------------------- */
					if( scan_IE( G_PTR, BASIC_SERVICE, 0, 0 ) == 0 )
					{
						Mmu_Free( G_PTR );
						send_down_Release_Com( MANDATORY_IE_MISSING );
						send_dl_release_rq( NORMAL );
						clearCCState();
						return;
					}

					#ifdef DECT_NG
					temp_service = evaluate_BASIC_SERVICE_IE( );

					if(temp_service == BS_DATA_CALL)
					{
						pos = scan_IE( G_PTR , IWU_ATTRIBUTES, 4, 10 );
                                                Set_FU10_Method (CurrentInc, pos);
                                                #if 0
						if(pos == 0)
						{
							Mmu_Free( G_PTR );
							send_down_Release_Com( MANDATORY_IE_MISSING );
							send_dl_release_rq( NORMAL );
							clearCCState();
							return;
						}
						CheckIWU_ATTRIBUTES ( CurrentInc, &G_PTR[ pos ] );
					        #endif
					}

					{
						temp_codec   = Evaluate_CODEC_LIST_IE( );
						#if 0
						//if( temp_service == WBS_EXTERNAL_CALL )
						if( (temp_service & 0x0F) == WIDEBAND_SPEEACH_BSERVICE )
						{
							temp_codec = CODEC_G722;
						}
						else
							temp_codec = CODEC_G726;
						#endif
						/* If no codec present than chose the preferred codec in locate request*/
						if(temp_codec == 0xFF){
                     #if defined(ULE_SUPPORT) || defined(CONFIG_REPEATER_SUPPORT)
							temp_codec = Get_First_Codec(po_no);
							#else
							temp_codec =  First_Codec[po_no - 1];
							#endif
							if(temp_codec == 0){
								if( (temp_service & 0x0F) == WIDEBAND_SPEEACH_BSERVICE )
								{
									temp_codec = CODEC_G722;
								}
							}
						}
					}
					#endif
					/* All mandatory IE are included in */
					/* the CC_SETUP frame. Forward the  */
					/* frame to the application layer ! */

					/* The assignment to the            */
					/* Application layer is set !       */
					Set_App_Layer_Assignment( CurrentInc, po_no );

					/* report the << CC_SETUP >> msg    */
					#ifdef DECT_NG
					#ifdef ULE_SUPPORT
					Set_Actual_Slot_Type(po_no, Required_Slot_Type_CID[CurrentInc]);
					send_up_message_WP( FP_SETUP_IN_CC, temp_service, temp_codec, Get_Actual_Slot_Type(po_no) );
					#else
					Actual_Slot_Type[ po_no - 1]  = Required_Slot_Type_CID[CurrentInc];
					send_up_message_WP( FP_SETUP_IN_CC, temp_service, temp_codec, Actual_Slot_Type[po_no - 1] );
					#endif
					#else
					send_up_message( FP_SETUP_IN_CC );
					#endif
					#ifndef CONFIG_CALL_SETUP_COLLISION_DURING_F01
					#ifdef CONFIG_CC_ENCRYPTION
					#ifdef CONFIG_EARLY_ENCRYPTION
					KNL_SENDTASK_WP_INC(CC, CC_AUTHENTICATE_PT_RQ, YES, 0, 0, 0, CurrentInc);
					#else
					KNL_SENDTASK_INC(CC, CC_AUTHENTICATE_PT_RQ, CurrentInc);
					#endif
					#endif
					#endif
					/* change to state CALL INITIATED   */
					KNL_Transit( F01 );
				}
				return;

				#ifdef CATIQ_VE
				case CC_CRSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY_CRSS);
					/* Release Timer                    */
					/* -------------------------------- */
					/* Timer:     <CC_release.02>       */
					/* Duration:  30 seconds            */
					Start_Pro_Timer( TIMER_CC_02, CurrentInc );

					/* change to state FAC SENT   */
					KNL_Transit( F99 );
          	return;

				case CC_CLSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY);
					/* Release Timer                    */
					/* -------------------------------- */
					/* Timer:     <CC_release.02>       */
					/* Duration:  30 seconds            */
					Start_Pro_Timer( TIMER_CC_02, CurrentInc );

					/* change to state FAC SENT   */
					KNL_Transit( F99 );
				return;

				case CC_CRSS_FACILITY_IN_LCE:
				case CC_CLSS_FACILITY_IN_LCE:
				{
					BYTE pmidBuf[4];
					BYTE po_no;

					// set connection id (CurrentInc) to buffer as parameter for request
					pmidBuf[0] = CurrentInc;

					get_pmid_from_hmac_ioctl(pmidBuf);
					po_no = Subscription_GetPortableNoFromPMID( &pmidBuf[1] );

					if( po_no == 0xFF )
					{
						Mmu_Free( G_PTR );
						send_down_Release_Com( INVALID_IDENTITY );
						send_dl_release_rq( NORMAL );
						clearCCState();
						return;
					}


					/* The assignment to the            */
					/* Application layer is set !       */
					Set_App_Layer_Assignment( CurrentInc, po_no );

					// send message to Application
					if (CurrentMessage == CC_CLSS_FACILITY_IN_LCE )
						send_up_message( FP_FACILITY_IN_CLSS );
					else if (CurrentMessage == CC_CRSS_FACILITY_IN_LCE )
						send_up_message( FP_FACILITY_IN_CRSS );

					// take care that connection will be dropped

					/* Release Timer                    */
					/* -------------------------------- */
					/* Timer:     <CC_release.02>       */
					/* Duration:  30 seconds            */
					Start_Pro_Timer( TIMER_CC_02, CurrentInc );

					/* change to state FAC SENT   */
					KNL_Transit( F99 );
				}
				return;

				#endif // CATIQ_VE
				default:
					 break;

			}										/* end of switch message				*/
 			break;

		case F01:
			switch (CurrentMessage)
			{
            #ifdef CONFIG_CALL_SETUP_COLLISION_DURING_F01
            case CC_MNCCS_SETUP_RQ_SWI:
            {
               FPTR temp;
               BYTE ti;
               
               /* Clear CC */
               ti = TI_Value_PD_CC[CurrentInc]; // Backup for rejection of the outgoing call
               clearCCState();

               /* Handle the incoming call request - Send CC-SETUP to make collision in the PP */
               
					if (Get_Assigned_Po_No(CurrentInc) != PARAMETER4) {
						Mmu_Free(G_PTR);
						return;
					}

               // "if" is just for safety. It should be not happend.
               if (backupCCSetupReqDataPtr[CurrentInc]) {
                  Mmu_Free(backupCCSetupReqDataPtr[CurrentInc]);
               }
               backupCCSetupReqDataPtr[CurrentInc] = Mmu_Malloc(((struct HLI_Header *)G_PTR)->length);
               Mmu_Memcpy(backupCCSetupReqDataPtr[CurrentInc], G_PTR, ((struct HLI_Header *)G_PTR)->length);

					TI_Value_PD_CC[ CurrentInc ] = 0 << 4; // Set TI
					Start_Pro_Timer( TIMER_CC_03, CurrentInc );
               #ifdef DECT_NG
               #ifdef ULE_SUPPORT
					Set_Actual_Slot_Type(Get_Assigned_Po_No(CurrentInc), Required_Slot_Type_CID[CurrentInc]);
               #else
					Actual_Slot_Type[Get_Assigned_Po_No(CurrentInc) - 1]  = Required_Slot_Type_CID[CurrentInc];
               #endif
               #endif
					send_down_message(CC_SETUP);
					KNL_Transit(F06);


               /* Call setup collision */
					
               SET_BITS(flags[CurrentInc], FLAG_CALL_SETUP_COLLISION);

               temp = Make_S_FORMAT_Message(PD_CC, ti, CC_RELEASE_COM);
               temp = Add_IE_2(temp, RELEASE_REASON, INSUFFICIENT_RESOURCES);
               KNL_SENDTASK_NP_INC(LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
               send_dl_release_rq(PARTIAL_RELEASE);
            }
            return;
            #endif
			
				case CC_MNCCS_SETUP_ACK_RQ_SWI:  /*  IN LINE CODE T0011    */
				{
					/* TRANSITION:      Q11                                                  */
					/* EVENT:           CC_MNCCS_SETUP_ACK_RQ_SWI received                   */
					/* STARTING STATE:  F01                                                  */
					/* END STATE:       F02                                                  */
					/* ----------------------------------------------------------------------*/
					/* Overlap Sending Timer            */
					/* -------------------------------- */
					/* Timer:     <CC_overlap.01>       */
					/* Duration:  20 seconds            */
					Start_Pro_Timer( TIMER_CC_01, CurrentInc );
					/* forward the << CC_SETUP_ACK >>   */
					send_down_message( CC_SETUP_ACK );
               #ifdef CONFIG_CALL_SETUP_COLLISION_DURING_F01
               #ifdef CONFIG_CC_ENCRYPTION
               #ifdef CONFIG_EARLY_ENCRYPTION
					KNL_SENDTASK_WP_INC(CC, CC_AUTHENTICATE_PT_RQ, YES, 0, 0, 0, CurrentInc);
               #else
					KNL_SENDTASK_INC(CC, CC_AUTHENTICATE_PT_RQ, CurrentInc);
               #endif
               #endif
               #endif
					/* change to state OVERLAP_SENDING  */
					KNL_Transit( F02 );
				}
				return;

				case CC_MNCCS_ALERT_RQ_SWI:
					T0005();
				return;

				case CC_MNCCS_CONNECT_RQ_SWI:
					T0010();
				return;

				case CC_MNCCS_CALL_PROC_RQ_SWI:
					T0009();
				return;

				case CC_MNCCS_REJECT_RQ_SWI:
					T0016();
				return;

				case CC_MNCCS_RELEASE_RQ_SWI:
					T0013();
				return;

				case CC_RELEASE_LCE:
					T0020();
				return;

				case CC_RELEASE_COM_LCE:
					T0014();
				return;

				case CC_DL_REL_IN_LCE:
					T0050();
				return;

				#ifdef CATIQ_VE
				// send message to active data link
				case CC_CLSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY);
				return;

				case CC_CLSS_FACILITY_IN_LCE:
					// send message to Application
					send_up_message( FP_FACILITY_IN_CLSS );
				return;
				#endif

            #ifndef CONFIG_CALL_SETUP_COLLISION_DURING_F01
				#ifdef CONFIG_CC_ENCRYPTION
				case CC_AUTHENTICATE_PT_RQ:
					T0561();
				return;

				case CC_MNCCS_AUTHENTICATE_PT_CFM:
					T0562();
				return;

				case CC_CIPHER_REQ_ON:
					T0563();
				return;

				case CC_MNCCS_CIPHER_CFM_ON:
					T0564();
				return;

				case CC_TIM_SECURITY_WATCH_EXPIRED:
					T0565();
				return;
				#endif
				#endif

				default:
					 break;

			}										/* end of switch message				*/
 			break;

		case F02:
			switch (CurrentMessage)
			{
				case CC_MNCCS_ALERT_RQ_SWI:
					T0005();
				return;

				case CC_MNCCS_CONNECT_RQ_SWI:
					T0010();
				return;

				case CC_MNCCS_CALL_PROC_RQ_SWI:
					T0009();
				return;

				case CC_MNCCS_REJECT_RQ_SWI:
					T0016();
				return;

				case CC_MNCCS_RELEASE_RQ_SWI:
					T0013();
				return;

				case CC_RELEASE_LCE:
					T0020();
				return;

				case CC_RELEASE_COM_LCE:
					T0014();
				return;

				case CC_DL_REL_IN_LCE:
					T0050();
				return;

				case CC_MNCCS_INFO_RQ_SWI:
					T0112();
				return;

				case CC_MNCCS_IWU_INFO_RQ_SWI:  /*  IN LINE CODE T0200    */
				{
					/* TRANSITION:      Q200                                                 */
					/* EVENT:           CC_IWU_INFO_RQ_SWI received                          */
					/* STARTING STATE:  F02                                                  */
					/* END STATE:       current state maintained                             */
					/* ----------------------------------------------------------------------*/
					/* forward the << CC_INFO >> msg     */
					send_down_message( IWU_INFO );
				}
				return;

				case CC_INFO_LCE:  /*  IN LINE CODE T0004    */
				{
					/* TRANSITION:      Q4                                                   */
					/* EVENT:           CC_INFO_LCE received                                 */
					/* STARTING STATE:  F02                                                  */
					/* END STATE:       current state maintained                             */
					/* ----------------------------------------------------------------------*/
					/* Restart Overlap Sending Timer    */
					/* -------------------------------- */
					Start_Pro_Timer( TIMER_CC_01, CurrentInc );
					/* report the << CC_INFO >> msg     */
					send_up_message( FP_INFO_IN_CC );
				}
				return;

				case CC_IWU_INFO_LCE:  /*  IN LINE CODE T0201    */
				{
					/* TRANSITION:      Q201                                                 */
					/* EVENT:           CC_IWU_INFO_LCE received                             */
					/* STARTING STATE:  F02                                                  */
					/* END STATE:       current state maintained                             */
					/* ----------------------------------------------------------------------*/
					/* report the << CC_INFO >> msg     */
					#ifdef DECT_NG
					BYTE po_no, temp_codec;

					po_no = Get_Assigned_Po_No( CurrentInc );
					temp_codec = Evaluate_CODEC_LIST_IE( );

               #ifdef ULE_SUPPORT
					if( Get_Service_Change_State(po_no) == SVC_IDLE )
					#else
					if( Service_Change_State[ po_no - 1 ] == SVC_IDLE )
					#endif
					{
					   send_up_message( FP_IWU_INFO_IN_CC );
					}
					else if( temp_codec != DUMMY_FILL )
					{
                  #ifdef ULE_SUPPORT
						Set_Service_Change_State(po_no, SVC_IDLE);
						#else
						Service_Change_State[ po_no - 1 ] = SVC_IDLE;
						#endif
						send_up_message_WP( FP_IWU_INFO_IN_CC, DUMMY_FILL, temp_codec, DUMMY_FILL );
					}
					else
					{
						send_up_message( FP_IWU_INFO_IN_CC );
					}
					#endif
				}
				return;

				case CC_TIM_01_EXPIRED:  /*  IN LINE CODE T0017    */
				{
					/* TRANSITION:      Q17                                                  */
					/* EVENT:           CC_TIM_01_EXPIRED                                    */
					/* DESCRIPTION:     Timer F-<CC.01> ( Overlap sending ) expired          */
					/* STARTING STATE:  F02                                                  */
					/* END STATE:       F19                                                  */
					/* ----------------------------------------------------------------------*/
					/* Overlap Sending Timer expired.   */

					/* Release Timer                    */
					/* -------------------------------- */
					/* Timer:     <CC_release.02>       */
					/* Duration:  30 seconds            */
					Start_Pro_Timer( TIMER_CC_02, CurrentInc );
					/* Clear the initiated call....     */
					send_down_Release( TIMER_EXPIRY );
					/* ... and report the clearing to   */
					/* the application layer.           */
					send_up_Release( );
					KNL_Transit( F19 );
				}
				return;

				#ifdef CATIQ_VE
					// send message to active data link
				case CC_CLSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY);
				return;

				case CC_CLSS_FACILITY_IN_LCE:
					// send message to Application
					send_up_message( FP_FACILITY_IN_CLSS );
				return;
				case CC_CRSS_FACILITY_RQ_SWI:
					send_down_message(SS_FACILITY);
				return;

				case CC_CRSS_FACILITY_IN_LCE:
					send_up_message( FP_FACILITY_IN_CRSS );
				return;
				#endif

				#ifdef CONFIG_CC_ENCRYPTION
				case CC_AUTHENTICATE_PT_RQ:
					T0561();
				return;

				case CC_MNCCS_AUTHENTICATE_PT_CFM:
					T0562();
				return;

				case CC_CIPHER_REQ_ON:
					T0563();
				return;

				case CC_MNCCS_CIPHER_CFM_ON:
					T0564();
				return;

				case CC_TIM_SECURITY_WATCH_EXPIRED:
					T0565();
				return;
				#endif

				default:
					 break;

			}										/* end of switch message				*/
 			break;

		case F03:
			switch (CurrentMessage)
			{
				case CC_MNCCS_ALERT_RQ_SWI:
					T0005();
				return;

				case CC_MNCCS_CONNECT_RQ_SWI:
					T0010();
				return;

				case CC_MNCCS_REJECT_RQ_SWI:
					T0016();
				return;

				case CC_MNCCS_RELEASE_RQ_SWI:
					T0013();
				return;

				case CC_RELEASE_LCE:
					T0020();
				return;

				case CC_RELEASE_COM_LCE:
					T0014();
				return;

				case CC_DL_REL_IN_LCE:
					T0050();
				return;

				case CC_MNCCS_INFO_RQ_SWI:
					T0112();
				return;

				case CC_INFO_LCE:
					T0012();
				return;

				#ifdef CATIQ_VE
				// send message to active data link
				case CC_CLSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY);
				return;

				case CC_CLSS_FACILITY_IN_LCE:
				// send message to Application
					send_up_message( FP_FACILITY_IN_CLSS );
				return;

				case CC_CRSS_FACILITY_RQ_SWI:
					send_down_message(SS_FACILITY);
				return;

				case CC_CRSS_FACILITY_IN_LCE:
					send_up_message( FP_FACILITY_IN_CRSS );
				return;
				#endif

				case CC_IWU_INFO_LCE:  /*  IN LINE CODE T0201    */
				{
					/* TRANSITION:      Q201                                                 */
					/* EVENT:           CC_IWU_INFO_LCE received                             */
					/* STARTING STATE:  F03                                                  */
					/* END STATE:       current state maintained                             */
					/* ----------------------------------------------------------------------*/
					/* report the << CC_INFO >> msg     */
					#ifdef DECT_NG
					BYTE temp_codec;

					temp_codec = Evaluate_CODEC_LIST_IE();
					if (temp_codec != DUMMY_FILL) {
                  #ifdef ULE_SUPPORT
						Set_Service_Change_State(Get_Assigned_Po_No(CurrentInc), SVC_IDLE);
						#else
						Service_Change_State[Get_Assigned_Po_No(CurrentInc) - 1] = SVC_IDLE;
						#endif
						send_up_message_WP( FP_IWU_INFO_IN_CC, DUMMY_FILL, temp_codec, DUMMY_FILL );
					} else {
						send_up_message(FP_IWU_INFO_IN_CC);
					}
					#endif
				}
				return;

				case CC_MNCCS_IWU_INFO_RQ_SWI:  /*  IN LINE CODE T0200    */
				{
					/* TRANSITION:      Q200                                                 */
					/* EVENT:           CC_IWU_INFO_RQ_SWI received                          */
					/* STARTING STATE:  F03                                                  */
					/* END STATE:       current state maintained                             */
					/* ----------------------------------------------------------------------*/
					/* forward the << CC_INFO >> msg     */
					send_down_message( IWU_INFO );
					#ifdef ULE_SUPPORT
                  #ifdef KLOCWORK
               if (VALID_PORTABLE_ULE(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #else
					if (IsValidPortableNo(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
					   #endif
						G_PTR[sizeof(struct HLI_Header)] = (G_PTR[sizeof(struct HLI_Header)] & ~0xF0) | 0x50; // TI = 5
					}
					#endif
				}
				return;

				#ifdef ULE_SUPPORT
				case CC_MNCCS_SERVICE_CHANGE_RQ_SWI:
				{
					// TRANSITION:
					// EVENT:           CC_MNCCS_SERVICE_CHANGE_RQ_SWI
					// STARTING STATE:  F03
					// END STATE:       F03
					// REMARK: ULE
					// ------------------------------------------------------------------------
                  #ifdef KLOCWORK
               if (VALID_PORTABLE_ULE(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #else
					if (IsValidPortableNo(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
					   #endif
						send_down_message(CC_SERVICE_CHANGE);
						G_PTR[sizeof(struct HLI_Header)] = (G_PTR[sizeof(struct HLI_Header)] & ~0xF0) | 0x50; // TI = 5
					} else {
						Mmu_Free( G_PTR );
					}
				}
				return;

				case CC_MNCCS_SERVICE_ACCEPT_RQ_SWI:
				{
					// TRANSITION:      Q61
					// EVENT:           CC_MNCCS_SERVICE_ACCEPT_RQ_SWI
					// STARTING STATE:  F03
					// END STATE:       F03
					// REMARK: ULE
					// ------------------------------------------------------------------------
                  #ifdef KLOCWORK
               if (VALID_PORTABLE_ULE(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #else
               if (IsValidPortableNo(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #endif
						send_down_message(CC_SERVICE_ACCEPT);
					   G_PTR[sizeof(struct HLI_Header)] = (G_PTR[sizeof(struct HLI_Header)] & ~0xF0) | 0x50; // TI = 5
					} else {
						Mmu_Free(G_PTR);
					}
				}
				return;

				case CC_MNCCS_SERVICE_REJECT_RQ_SWI:
				{
					// TRANSITION:      Q62
					// EVENT:           CC_MNCCS_SERVICE_REJECT_RQ_SWI
					// STARTING STATE:  F03
					// END STATE:       F03
					// REMARK: ULE
					// ------------------------------------------------------------------------
                  #ifdef KLOCWORK
               if (VALID_PORTABLE_ULE(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #else
               if (IsValidPortableNo(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #endif
						send_down_message(CC_SERVICE_REJECT);
					   G_PTR[sizeof(struct HLI_Header)] = (G_PTR[sizeof(struct HLI_Header)] & ~0xF0) | 0x50; // TI = 5
					} else {
						Mmu_Free(G_PTR);
					}
				}
				return;

				case CC_SERVICE_CHANGE_LCE:
				{
					// TRANSITION:      Q70
					// EVENT:           CC_SERVICE_CHANGE_LCE
					// STARTING STATE:  F03
					// END STATE:       F03
					// REMARK: ULE
					// ------------------------------------------------------------------------
                  #ifdef KLOCWORK
               if (VALID_PORTABLE_ULE(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #else
               if (IsValidPortableNo(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #endif
						send_up_message(FP_SERVICE_CHANGE_IN_CC);
					} else {
						Mmu_Free(G_PTR);
					}
				}
				return;

				case CC_SERVICE_ACCEPT_LCE:
				{
					// TRANSITION:      Q71
					// EVENT:           CC_SERVICE_ACCEPT_LCE
					// STARTING STATE:  F03
					// END STATE:       F03
					// REMARK: ULE
					// ------------------------------------------------------------------------
                  #ifdef KLOCWORK
               if (VALID_PORTABLE_ULE(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #else
               if (IsValidPortableNo(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #endif
						send_up_message(FP_SERVICE_ACCEPT_IN_CC);
					} else {
						Mmu_Free(G_PTR);
					}
 				}
				return;

				case CC_SERVICE_REJECT_LCE:
				{
					// TRANSITION:      Q72
					// EVENT:           CC_SERVICE_REJECT_LCE
					// STARTING STATE:  F03
					// END STATE:       F03
					// REMARK: ULE
					// ------------------------------------------------------------------------
                  #ifdef KLOCWORK
               if (VALID_PORTABLE_ULE(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #else
               if (IsValidPortableNo(Get_Assigned_Po_No(CurrentInc), PORTABLE_ULE)) {
                  #endif
						send_up_message(FP_SERVICE_REJECT_IN_CC);
					} else {
						Mmu_Free(G_PTR);
					}
				}
				return;
				#endif

				#ifdef CONFIG_CC_ENCRYPTION
				case CC_AUTHENTICATE_PT_RQ:
					T0561();
				return;

				case CC_MNCCS_AUTHENTICATE_PT_CFM:
					T0562();
				return;

				case CC_CIPHER_REQ_ON:
					T0563();
				return;

				case CC_MNCCS_CIPHER_CFM_ON:
					T0564();
				return;

				case CC_TIM_SECURITY_WATCH_EXPIRED:
					T0565();
				return;
				#endif

				default:
					 break;

			}										/* end of switch message				*/
 			break;

		case F04:
			switch (CurrentMessage)
			{
				case CC_MNCCS_CONNECT_RQ_SWI:
					T0010();
				return;

				case CC_MNCCS_REJECT_RQ_SWI:
					T0016();
				return;

				case CC_MNCCS_RELEASE_RQ_SWI:
					T0013();
				return;

				case CC_RELEASE_LCE:
					T0020();
				return;

				case CC_RELEASE_COM_LCE:
					T0014();
				return;

				case CC_DL_REL_IN_LCE:
					T0050();
				return;

				case CC_MNCCS_INFO_RQ_SWI:
					T0112();
				return;

				case CC_INFO_LCE:
					T0012();
				return;

				#ifdef CATIQ_VE
				// send message to active data link
				case CC_CLSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY);
				return;

				case CC_CLSS_FACILITY_IN_LCE:
				// send message to Application
					send_up_message( FP_FACILITY_IN_CLSS );
				return;

				case CC_CRSS_FACILITY_RQ_SWI:
					send_down_message(SS_FACILITY);
				return;

				case CC_CRSS_FACILITY_IN_LCE:
					send_up_message( FP_FACILITY_IN_CRSS );
				return;
				#endif

				#ifdef CONFIG_CC_ENCRYPTION
				case CC_AUTHENTICATE_PT_RQ:
					T0561();
				return;

				case CC_MNCCS_AUTHENTICATE_PT_CFM:
					T0562();
				return;

				case CC_CIPHER_REQ_ON:
					T0563();
				return;

				case CC_MNCCS_CIPHER_CFM_ON:
					T0564();
				return;

				case CC_TIM_SECURITY_WATCH_EXPIRED:
					T0565();
				return;
				#endif

				default:
					 break;

			}										/* end of switch message				*/
 			break;

		case F06:
			switch (CurrentMessage)
			{
			   #ifdef CONFIG_CALL_SETUP_COLLISION
			   case CC_SETUP_LCE:
            {
               // Call setup collision
               
               FPTR temp;
               BYTE ti;

               SET_BITS(flags[CurrentInc], FLAG_CALL_SETUP_COLLISION);

               ti = (G_PTR[sizeof(struct HLI_Header)] & 0xF0) ^ 0x80;
               Mmu_Free(G_PTR);
               
               temp = Make_S_FORMAT_Message(PD_CC, ti, CC_RELEASE_COM);
               temp = Add_IE_2(temp, RELEASE_REASON, INSUFFICIENT_RESOURCES);
               KNL_SENDTASK_NP_INC(LCE, LCE_DL_DATA_RQ, temp, CurrentInc );
               send_dl_release_rq(PARTIAL_RELEASE);
            }
		      return;
			   #endif
			   
				case CC_MNCCS_REJECT_RQ_SWI:
					T0016();
				return;
				case CC_MNCCS_RELEASE_RQ_SWI:
					T0013();
				return;

				case CC_RELEASE_COM_LCE:
				{
				   #ifdef CONFIG_CALL_SETUP_COLLISION
               BYTE pos;

               if ((pos = scan_IE(G_PTR, RELEASE_REASON, 0, 0)) != 0) {
                  switch (G_PTR[pos + 1]) {
                     case INSUFFICIENT_RESOURCES:
                        // The check of backupCCSetupReqDataPtr[CurrentInc] is for sefety
                        if (TST_BITS(flags[CurrentInc], FLAG_CALL_SETUP_COLLISION) && backupCCSetupReqDataPtr[CurrentInc]) {
                           // Incoming call is represented again.

                           FPTR dataPtr;

                           // Copy. The backup data is kept for the repetitive collision case with the old PP - The exception case
                           dataPtr = Mmu_Malloc(((struct HLI_Header *)backupCCSetupReqDataPtr[CurrentInc])->length);
                           #ifdef KLOCWORK
						   if(dataPtr != NULL)
						   #endif
						   {
						      Mmu_Memcpy(dataPtr, backupCCSetupReqDataPtr[CurrentInc], ((struct HLI_Header *)backupCCSetupReqDataPtr[CurrentInc])->length);
                           
                              TI_Value_PD_CC[CurrentInc] = 0 << 4;
                              Start_Pro_Timer(TIMER_CC_03, CurrentInc);
                              #ifdef DECT_NG
                              #ifdef ULE_SUPPORT
                              Set_Actual_Slot_Type(Get_Assigned_Po_No(CurrentInc), Required_Slot_Type_CID[CurrentInc]);
                              #else
                              Actual_Slot_Type[Get_Assigned_Po_No(CurrentInc) - 1]  = Required_Slot_Type_CID[CurrentInc];
                              #endif
                              #endif
                           
                              dataPtr[sizeof(struct HLI_Header)] = PD_CC | TI_Value_PD_CC[CurrentInc];
                              dataPtr[sizeof(struct HLI_Header) + 1] = CC_SETUP;
                              KNL_SENDTASK_NP_INC(LCE, LCE_DL_DATA_RQ, dataPtr, CurrentInc);
                              CLR_BITS(flags[CurrentInc], FLAG_CALL_SETUP_COLLISION); // The collision has been handled.
                              // KNL_Transit(F06);
						   }
                        } else {
                           send_up_message(FP_RELEASE_IN_CC);
                           send_dl_release_rq(NORMAL);
                           clearCCState();
                        }
                        break;
                        
                     case PARTIAL_RELEASE:
                        send_up_message(FP_RELEASE_IN_CC);
                        send_dl_release_rq(PARTIAL_RELEASE);
                        clearCCState();
                        break;

                     default:
                        send_up_message(FP_RELEASE_IN_CC);
                        send_dl_release_rq( NORMAL );
                        clearCCState();
                        break;
                  }
               }
				   #else
					T0014();
					#endif
			   }
				return;

				case CC_DL_REL_IN_LCE:
					T0050();
				return;

				case CC_MNCCS_INFO_RQ_SWI:
					T0112();
				return;

				case CC_MNCCS_CONNECT_ACK_RQ_SWI:
					T0030();
				return;

				case CC_ALERTING_LCE:  /*  IN LINE CODE T0006    */
				{
					/* TRANSITION:      Q06                                                  */
					/* EVENT:           CC_ALERTING_LCE received                             */
					/* STARTING STATE:  F06                                                  */
					/* END STATE:       F07                                                  */
					/* ----------------------------------------------------------------------*/
					/* Stop Call Establishment Timer.   */
					Stop_Pro_Timer( TIMER_CC_03, CurrentInc );
					/* report the << CC_ALERT >> msg    */
					#ifdef DECT_NG
               #ifdef ULE_SUPPORT
               send_up_message_WP( FP_ALERT_IN_CC, DUMMY_FILL, Evaluate_CODEC_LIST_IE(), Get_Actual_Slot_Type(Get_Assigned_Po_No(CurrentInc)));
               #else
               send_up_message_WP( FP_ALERT_IN_CC, DUMMY_FILL, Evaluate_CODEC_LIST_IE(), Actual_Slot_Type[Get_Assigned_Po_No(CurrentInc) - 1]);
               #endif
					#else
					send_up_message( FP_ALERT_IN_CC );
					#endif
					#ifdef CONFIG_CC_ENCRYPTION
					#ifdef CONFIG_EARLY_ENCRYPTION
					KNL_SENDTASK_WP_INC(CC, CC_AUTHENTICATE_PT_RQ, YES, 0, 0, 0, CurrentInc);
					#else
					KNL_SENDTASK_INC(CC, CC_AUTHENTICATE_PT_RQ, CurrentInc);
					#endif
					#endif
               #ifdef CONFIG_CALL_SETUP_COLLISION
               if (backupCCSetupReqDataPtr[CurrentInc]) {
                  Mmu_Free(backupCCSetupReqDataPtr[CurrentInc]);
                  backupCCSetupReqDataPtr[CurrentInc] = NULL;
               }
               #endif
					/* change to state CALL_RECEIVED    */
					KNL_Transit( F07 );
				}
				return;

				case CC_CONNECT_LCE:
					T0007();
				return;

				case CC_TIM_03_EXPIRED:  /*  IN LINE CODE T0027    */
				{
					/* TRANSITION:      Q27                                                  */
					/* EVENT:           CC_TIM_02_EXPIRED ( SETUP Timeout )                  */
					/* DESCRIPTION:     Timer F-<CC.02> expired                              */
					/* STARTING STATE:  F06                                                  */
					/* END STATE:       F00                                                  */
					/* ----------------------------------------------------------------------*/
					/* Clear the initiated call....     */
					send_down_Release_Com( NORMAL );
					/* ... and report the clearing to   */
					/* the application layer.           */
					send_up_Release( );
					send_dl_release_rq( NORMAL );
					clearCCState();
				}
				return;

				#ifdef CATIQ_VE
				// send message to active data link
				case CC_CLSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY);
				return;

				case CC_CLSS_FACILITY_IN_LCE:
					// send message to Application
					send_up_message( FP_FACILITY_IN_CLSS );
				return;

				case CC_CRSS_FACILITY_RQ_SWI:
					send_down_message(SS_FACILITY);
				return;

				case CC_CRSS_FACILITY_IN_LCE:
					send_up_message( FP_FACILITY_IN_CRSS );
				return;
				#endif

				#ifdef CONFIG_CC_ENCRYPTION
				case CC_AUTHENTICATE_PT_RQ:
					T0561();
				return;

				case CC_MNCCS_AUTHENTICATE_PT_CFM:
					T0562();
				return;

				case CC_CIPHER_REQ_ON:
					T0563();
				return;

				case CC_MNCCS_CIPHER_CFM_ON:
					T0564();
				return;

				case CC_TIM_SECURITY_WATCH_EXPIRED:
					T0565();
				return;
				#endif

				default:
					 break;

			}										/* end of switch message				*/
 			break;

		case F07:
			switch (CurrentMessage)
			{
				case CC_MNCCS_REJECT_RQ_SWI:
					T0016();
				return;
				case CC_MNCCS_RELEASE_RQ_SWI:
					T0013();
				return;

				case CC_RELEASE_LCE:
					T0020();
				return;

				case CC_RELEASE_COM_LCE:
					T0014();
				return;

				case CC_DL_REL_IN_LCE:
					T0050();
				return;

				case CC_MNCCS_INFO_RQ_SWI:
					T0112();
				return;

				case CC_INFO_LCE:
					T0012();
				return;

				case CC_MNCCS_CONNECT_ACK_RQ_SWI:
					T0030();
				return;

				case CC_CONNECT_LCE:
					T0007();
				return;

				#ifdef CATIQ_VE
				// send message to active data link
				case CC_CLSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY);
				return;

				case CC_CLSS_FACILITY_IN_LCE:
					// send message to Application
					send_up_message( FP_FACILITY_IN_CLSS );
				return;

				case CC_CRSS_FACILITY_RQ_SWI:
					send_down_message(SS_FACILITY);
				return;

				case CC_CRSS_FACILITY_IN_LCE:
					send_up_message( FP_FACILITY_IN_CRSS );
				return;
				#endif

				#ifdef CONFIG_CC_ENCRYPTION
				case CC_AUTHENTICATE_PT_RQ:
					T0561();
				return;

				case CC_MNCCS_AUTHENTICATE_PT_CFM:
					T0562();
				return;

				case CC_CIPHER_REQ_ON:
					T0563();
				return;

				case CC_MNCCS_CIPHER_CFM_ON:
					T0564();
				return;

				case CC_TIM_SECURITY_WATCH_EXPIRED:
					T0565();
				return;
				#endif

				default:
					 break;

			}										/* end of switch message				*/
 			break;

		case F10:
			switch (CurrentMessage)
			{
				case CC_MNCCS_REJECT_RQ_SWI:
					T0016();
				return;
				case CC_MNCCS_RELEASE_RQ_SWI:
					T0013();
				return;

				case CC_RELEASE_LCE:
					T0020();
				return;

				case CC_RELEASE_COM_LCE:
					T0014();
				return;

				case CC_DL_REL_IN_LCE:
					T0050();
				return;

				case CC_MNCCS_INFO_RQ_SWI:
					T0112();
				return;

				case CC_INFO_LCE:
					T0012();
				return;

				case CC_MNCCS_IWU_INFO_RQ_SWI:  /*  IN LINE CODE T0200    */
				{
					/* TRANSITION:      Q200                                                 */
					/* EVENT:           CC_IWU_INFO_RQ_SWI received                          */
					/* STARTING STATE:  F10                                                  */
					/* END STATE:       current state maintained                             */
					/* ----------------------------------------------------------------------*/
					/* forward the << CC_INFO >> msg     */
					send_down_message( IWU_INFO );
				}
				return;

				case CC_IWU_INFO_LCE:  /*  IN LINE CODE T0201    */
				{
					/* TRANSITION:      Q201                                                 */
					/* EVENT:           CC_IWU_INFO_LCE received                             */
					/* STARTING STATE:  F10                                                  */
					/* END STATE:       current state maintained                             */
					/* ----------------------------------------------------------------------*/
					/* report the << CC_INFO >> msg     */
					#ifdef DECT_NG
					BYTE temp_codec;

					temp_codec = Evaluate_CODEC_LIST_IE();
					if( temp_codec != DUMMY_FILL )
					{
                  #ifdef ULE_SUPPORT
						Set_Service_Change_State(Get_Assigned_Po_No(CurrentInc), SVC_IDLE);
						#else
						Service_Change_State[Get_Assigned_Po_No(CurrentInc) - 1] = SVC_IDLE;
						#endif
						send_up_message_WP( FP_IWU_INFO_IN_CC, DUMMY_FILL, temp_codec, DUMMY_FILL );
					}
					else
					{
						send_up_message( FP_IWU_INFO_IN_CC );
					}
					#endif
				}
				return;

				case CC_MNCCS_SERVICE_CHANGE_RQ_SWI:  /*  IN LINE CODE T0060    */
				{
					/* TRANSITION:      Q60                                                  */
					/* EVENT:           CC_MNCCS_SERVICE_CHANGE_RQ_SWI received                 */
					/* STARTING STATE:  F10                                             */
					/* END STATE:       F10                                                  */
					/* ----------------------------------------------------------------------*/
					#ifdef DECT_NG
					/* forward the << CC_SERVICE_CHANGE >> */
					/* msg                              */
					send_down_message(CC_SERVICE_CHANGE);
               #ifdef ULE_SUPPORT
					Set_Service_Change_State(Get_Assigned_Po_No(CurrentInc), SVC_ACTIVE_FROM_BASE);
					#else
					Service_Change_State[Get_Assigned_Po_No(CurrentInc) - 1] = SVC_ACTIVE_FROM_BASE;
					#endif
					#endif
				}
				return;

				case CC_MNCCS_SERVICE_ACCEPT_RQ_SWI:  /*  IN LINE CODE T0061    */
				{
					/* TRANSITION:      Q61                                                  */
					/* EVENT:           CC_MNCCS_SERVICE_ACCEPT_RQ_SWI received                 */
					/* STARTING STATE:  F10                                             */
					/* END STATE:       F10                                                  */
					/* ----------------------------------------------------------------------*/
					#ifdef DECT_NG
					/* forward the << CC_SERVICE_CHANGE >> */
					/* msg                              */
               #ifdef ULE_SUPPORT
					if( Get_Service_Change_State(Get_Assigned_Po_No(CurrentInc)) == SVC_ACTIVE_FROM_HAND )
					#else
					if( Service_Change_State[Get_Assigned_Po_No(CurrentInc) - 1] == SVC_ACTIVE_FROM_HAND )
					#endif
					{
						send_down_message( CC_SERVICE_ACCEPT );
					}
					#endif
				}
				return;

				case CC_MNCCS_SERVICE_REJECT_RQ_SWI:  /*  IN LINE CODE T0062    */
				{
					/* TRANSITION:      Q62                                                  */
					/* EVENT:           CC_MNCCS_SERVICE_REJECT_RQ_SWI received                 */
					/* STARTING STATE:  F10                                             */
					/* END STATE:       F10                                                  */
					/* ----------------------------------------------------------------------*/
					#ifdef DECT_NG
					BYTE po_no;

					/* forward the << CC_SERVICE_CHANGE >> */
					/* msg                              */
					po_no = Get_Assigned_Po_No( CurrentInc );
               #ifdef ULE_SUPPORT
					if( Get_Service_Change_State(po_no) == SVC_ACTIVE_FROM_HAND )
					#else
					if( Service_Change_State[po_no - 1] == SVC_ACTIVE_FROM_HAND )
					#endif
					{
						send_down_message( CC_SERVICE_REJECT );
					}
					#ifdef ULE_SUPPORT
					Set_Service_Change_State(po_no, SVC_IDLE);
					#else
					Service_Change_State[po_no - 1] = SVC_IDLE;
					#endif
					#endif
				}
				return;

				case CC_SERVICE_CHANGE_LCE:  /*  IN LINE CODE T0070    */
				{
					/* TRANSITION:      Q70                                                  */
					/* EVENT:           CC_SERVICE_CHANGE_LCE received                 */
					/* STARTING STATE:  F10                                             */
					/* END STATE:       F10                                                  */
					/* ----------------------------------------------------------------------*/
					#ifdef DECT_NG
					send_up_message_WP(FP_SERVICE_CHANGE_IN_CC, DUMMY_FILL, Evaluate_CODEC_LIST_IE(), 0);
					#ifdef ULE_SUPPORT
					Set_Service_Change_State(Get_Assigned_Po_No(CurrentInc), SVC_ACTIVE_FROM_HAND);
					#else
					Service_Change_State[Get_Assigned_Po_No(CurrentInc) - 1] = SVC_ACTIVE_FROM_HAND;
					#endif
					#endif

				}
				return;

				case CC_SERVICE_ACCEPT_LCE:  /*  IN LINE CODE T0071    */
				{
					/* TRANSITION:      Q71                                                  */
					/* EVENT:           CC_SERVICE_ACCEPT_LCE received                 */
					/* STARTING STATE:  F10                                             */
					/* END STATE:       F10                                                  */
					/* ----------------------------------------------------------------------*/
					#ifdef DECT_NG
               #ifdef ULE_SUPPORT
					if( Get_Service_Change_State(Get_Assigned_Po_No(CurrentInc)) == SVC_ACTIVE_FROM_BASE )
					#else
					if( Service_Change_State[Get_Assigned_Po_No(CurrentInc) - 1] == SVC_ACTIVE_FROM_BASE )
					#endif
               {
						send_up_message( FP_SERVICE_ACCEPT_IN_CC);
					}
					#endif

					#if 0
					//////////////////////////////////////////////////////////////////////////
					// GPTR			 = n.u
					// PARAMETER1 = Po_no(currentInc + 1)
					// PARAMETER2 = SLOT_TYPE( 1:LONG_SLOT, 0:FULL_SLOT )
					// PARAMETER3 = n.u
					// PARAMETER4 = n.u
					//////////////////////////////////////////////////////////////////////////
					mcei_1 = Get_Assigned_CID( PARAMETER1 );
					/*
					KNL_SENDTASK_WP(HMAC,
					                MAC_SLOTTYPE_MOD_RQ_SWI,
					                mcei_1, //P1
					                0,
					                0,
					                PARAMETER2);
					*/
					write_to_hmac_ioctl(HMAC, MAC_SLOTTYPE_MOD_RQ_SWI,
					                    mcei_1, 0, 0, PARAMETER2,
					                    0, 0, 0, 0);
					#endif
					/* FP_SLOTTYPE_MOD_IN_MAC send LMAC */
				}
				return;

				case CC_SERVICE_REJECT_LCE:  /*  IN LINE CODE T0072    */
				{
					/* TRANSITION:      Q72                                                  */
					/* EVENT:           CC_SERVICE_REJECT_LCE received                 */
					/* STARTING STATE:  F10                                             */
					/* END STATE:       F10                                                  */
					/* ----------------------------------------------------------------------*/
					#ifdef DECT_NG
               BYTE  po_no;

					po_no = Get_Assigned_Po_No( CurrentInc );
               #ifdef ULE_SUPPORT
					if( Get_Service_Change_State(po_no) == SVC_ACTIVE_FROM_BASE )
					#else
					if( Service_Change_State[ po_no - 1 ] == SVC_ACTIVE_FROM_BASE )
					#endif
               {
						send_up_message(FP_SERVICE_REJECT_IN_CC);
					}
					#ifdef ULE_SUPPORT
					Set_Service_Change_State(po_no, SVC_IDLE);
					#else
					Service_Change_State[ po_no - 1 ] = SVC_IDLE;
					#endif
					#endif
				}
				return;

				#ifdef CATIQ_VE
				// send message to active data link
				case CC_CLSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY);
				return;

				case CC_CLSS_FACILITY_IN_LCE:
					// send message to Application
					send_up_message( FP_FACILITY_IN_CLSS );
				return;

				case CC_CRSS_FACILITY_RQ_SWI:
					send_down_message(SS_FACILITY);
				return;

				case CC_CRSS_FACILITY_IN_LCE:
					send_up_message( FP_FACILITY_IN_CRSS );
				return;
				#endif

				#ifdef CONFIG_CC_ENCRYPTION
				case CC_AUTHENTICATE_PT_RQ:
					T0561();
				return;

				case CC_MNCCS_AUTHENTICATE_PT_CFM:
					T0562();
				return;

				case CC_CIPHER_REQ_ON:
					T0563();
				return;

				case CC_MNCCS_CIPHER_CFM_ON:
					T0564();
				return;

				case CC_TIM_SECURITY_WATCH_EXPIRED:
					T0565();
				return;
				#endif

				default:
					 break;

			}										/* end of switch message				*/
 			break;

		case F19:
			switch (CurrentMessage)
			{
				case CC_MNCCS_SETUP_RQ_SWI:  /*  IN LINE CODE T0111    */
				{
					/* TRANSITION:                                                           */
					/* EVENT:           CC_MNCCS_SETUP_RQ_SWI received                       */
					/* STARTING STATE:  F19                                                  */
					/* END STATE:       F19                                                  */
					/* ----------------------------------------------------------------------*/
					/* Check assigned po_no.            */
					if( Get_Assigned_Po_No( CurrentInc ) != PARAMETER4 )
					{
						Mmu_Free( G_PTR );
						return;
					}
					/* Last call not yet released       */
					/* completly, reject new call       */
					/* establishment.                   */
					send_up_Release( );
					Mmu_Free( G_PTR );
				}
				return;

				case CC_RELEASE_LCE:
				case CC_RELEASE_COM_LCE:  /*  IN LINE CODE T0022    */
				{
					/* TRANSITION:      Q22                                                  */
					/* EVENT:           CC_RELEASE_LCE / CC_RELEASE_COMPLETE_LCE received    */
					/* STARTING STATE:  F19                                                  */
					/* END STATE:       F00                                                  */
					/* ----------------------------------------------------------------------*/
					BYTE pos;
					/* Partial Release requested ?      */
					/* (according to GAP 300 444 / 8.9) */
					/* -------------------------------- */
					/* << RELEASE REASON >> IE          */
					/* included ?                       */
					pos = scan_IE( G_PTR, RELEASE_REASON, 0, 0 );
					/* Release Reason 'Partial' ?       */
					if(( pos != 0 ) && ( G_PTR[ pos + 1 ] == PARTIAL_RELEASE ))
					{
						send_dl_release_rq( PARTIAL_RELEASE );
					}
					else
					{
						send_dl_release_rq( NORMAL );
					}
					Mmu_Free( G_PTR );
					clearCCState();
				}
				return;

				case CC_DL_REL_IN_LCE:
					T0050();
				return;

				case CC_INFO_LCE:
					T0012();
				return;

				case CC_TIM_02_EXPIRED:  /*  IN LINE CODE T0015    */
				{
					/* TRANSITION:      Q15                                                  */
					/* EVENT:           CC_TIM_02_EXPIRED ( RELEASE Timeout )                */
					/* DESCRIPTION:     Timer F-<CC.02> ( Release Timer ) expired            */
					/* STARTING STATE:  F19                                                  */
					/* END STATE:       F00                                                  */
					/* ----------------------------------------------------------------------*/
					send_down_Release_Com( NORMAL );
					send_dl_release_rq( NORMAL );
					clearCCState();
				}
				return;

				#ifdef CATIQ_VE
				// send message to active data link
				case CC_CLSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY);
				return;

				case CC_CLSS_FACILITY_IN_LCE:
					// send message to Application
					send_up_message( FP_FACILITY_IN_CLSS );
				return;

				case CC_CRSS_FACILITY_RQ_SWI:
					send_down_message(SS_FACILITY);
				return;

				case CC_CRSS_FACILITY_IN_LCE:
					send_up_message( FP_FACILITY_IN_CRSS );
				return;
				#endif

				default:
					 break;


			}										/* end of switch message				*/
 			break;

		#ifdef CATIQ_VE
		case F99:
			switch (CurrentMessage)
			{

				case CC_DL_REL_IN_LCE:
					clearCCState();
				return;


				case CC_TIM_02_EXPIRED:
					// timer expired => release connection
					send_dl_release_rq( NORMAL );
					clearCCState();
				return;


				case CC_MNCCS_SETUP_RQ_SWI:  /*  IN LINE CODE T0001    */
				{

					/* TRANSITION:      Q01                                                  */
					/* EVENT:           CC_MNCCS_SETUP_RQ_SWI received                       */
					/* STARTING STATE:  F99                                                  */
					/* END STATE:       F06                                                  */
					/* ----------------------------------------------------------------------*/
					/* Check assigned po_no.            */
					if( Get_Assigned_Po_No( CurrentInc ) != PARAMETER4 )
					{
						Mmu_Free( G_PTR );
						return;
					}
					
               #ifdef CONFIG_CALL_SETUP_COLLISION
               {
                  // "if" is just for safety. It should be not happend.
                  if (backupCCSetupReqDataPtr[CurrentInc]) {
                     Mmu_Free(backupCCSetupReqDataPtr[CurrentInc]);
                  }
                  backupCCSetupReqDataPtr[CurrentInc] = Mmu_Malloc(((struct HLI_Header *)G_PTR)->length);
                  Mmu_Memcpy(backupCCSetupReqDataPtr[CurrentInc], G_PTR, ((struct HLI_Header *)G_PTR)->length);
               }
               #endif

					/* Set Transaction Identitfier      */
					/* value.                           */
					/* -------------------------------- */
					/* TI-Value always << 0 >> !        */
					TI_Value_PD_CC[ CurrentInc ] = 0 << 4;
					/* Call Establishment Timer         */
					/* -------------------------------- */
					/* Timer:     <CC_setup.03>         */
					/* Duration:  20 seconds            */
					Stop_Pro_Timer( TIMER_CC_02, CurrentInc );
					Start_Pro_Timer( TIMER_CC_03, CurrentInc );

					#ifdef DECT_NG
               #ifdef ULE_SUPPORT
               Set_Actual_Slot_Type(Get_Assigned_Po_No( CurrentInc ), Required_Slot_Type_CID[CurrentInc]);
               #else
               Actual_Slot_Type[ Get_Assigned_Po_No( CurrentInc ) - 1]  = Required_Slot_Type_CID[CurrentInc];
               #endif
					#endif
					/* forward the << CC_SETUP >> msg   */
					send_down_message( CC_SETUP );
					/* change to state CALL_PRESENT     */
					KNL_Transit( F06 );
				}
				return;

				case CC_SETUP_LCE:  /*  IN LINE CODE T0508    */
				{
					/* TRANSITION:      Q508                                                 */
					/* EVENT:           CC_SETUP_LCE received                                */
					/* STARTING STATE:  F99                                                  */
					/* END STATE:       F01                                                  */
					/* ----------------------------------------------------------------------*/
					BYTE pos, po_no;
					#ifdef DECT_NG
					BYTE temp_codec, temp_service;
					#endif
					/* Store the received transaction   */
					/* identifier.                      */
					/* -------------------------------- */
					/* The TI-value is inverted,        */
					/* because the variable always      */
					/* stores the value wich must be    */
					/* used for sending primitives !    */
					TI_Value_PD_CC[ CurrentInc ]  = G_PTR[ sizeof( struct HLI_Header ) ] & 0xF0;
					TI_Value_PD_CC[ CurrentInc ] ^= 0x80;
					/* Mandatory << PORTABLE IDENTITY >>*/
					/* included ?                       */
					/* -------------------------------- */
					pos = scan_IE( G_PTR, PORTABLE_IDENTITY, 7, 7 );
					if( pos == 0 )
					{
						Mmu_Free( G_PTR );
						send_down_Release_Com( MANDATORY_IE_MISSING );
						send_dl_release_rq( NORMAL );
				 		clearCCState();
						return;
					}
					/* Content of                       */
					/* << PORTABLE IDENTITY>> correct ? */
					/* -------------------------------- */
					/* The registration of the portable */
					/* is checked.                      */
					#ifdef MASTER_BS
					//Subscription_ForceToRegister( &G_PTR[ pos + 4 ], 0 );
					Subscription_ForceToRegister( &G_PTR[ pos + 4 ], 1 );
					#endif

					// determine portable with sent id, has to be the same than existing assignment
					po_no = Subscription_GetPotableNoFromIPUI( &G_PTR[ pos + 4 ] );
					//if(po_no == 0xFF ) was in orginal:radva
					if( ( po_no == 0xFF ) || ( po_no != Get_Assigned_Po_No(CurrentInc) ) )
					{
						Mmu_Free( G_PTR );
						send_down_Release_Com( INVALID_IDENTITY );
						send_dl_release_rq( NORMAL );
				 		clearCCState();
						return;
					}
					/* Mandatory << FIXED IDENTITY >>   */
					/* included ?                       */
					/* -------------------------------- */
					pos = scan_IE( G_PTR, FIXED_IDENTITY, 7, 7 );
					if( pos == 0 )
					{
						Mmu_Free( G_PTR );
						send_down_Release_Com( MANDATORY_IE_MISSING );
						send_dl_release_rq( NORMAL );
				 		clearCCState();
						return;
					}
					/* Content of                       */
					/* << FIXED IDENTITY>> correct ?    */
					/* -------------------------------- */
					if( ! Check_Received_PARK( &G_PTR[ pos + 4 ] ))
					{
						Mmu_Free( G_PTR );
						send_down_Release_Com( INVALID_IDENTITY );
						send_dl_release_rq( NORMAL );
				 		clearCCState();
						return;
					}
					/* Mandatory << BASIC SERVICE >>    */
					/* included ?                       */
					/* -------------------------------- */
					if( scan_IE( G_PTR, BASIC_SERVICE, 0, 0 ) == 0 )
					{
						Mmu_Free( G_PTR );
						send_down_Release_Com( MANDATORY_IE_MISSING );
						send_dl_release_rq( NORMAL );
				 		clearCCState();
						return;
					}

					#ifdef DECT_NG
					temp_service = evaluate_BASIC_SERVICE_IE( );

					if(temp_service == BS_DATA_CALL)
					{
						pos = scan_IE( G_PTR , IWU_ATTRIBUTES, 4, 10 );
                                                Set_FU10_Method (CurrentInc, pos);
                                        #if 0
						if(pos == 0)
						{
							Mmu_Free( G_PTR );
							send_down_Release_Com( MANDATORY_IE_MISSING );
							send_dl_release_rq( NORMAL );
							clearCCState();
							return;
						}
						CheckIWU_ATTRIBUTES ( CurrentInc, &G_PTR[ pos ] );
                                        #endif
					}

          		{
						temp_codec   = Evaluate_CODEC_LIST_IE( );
						if( (temp_service & 0x0F) == WIDEBAND_SPEEACH_BSERVICE )
							temp_codec = CODEC_G722;
						else
							temp_codec = CODEC_G726;
					}
					#endif
					/* All mandatory IE are included in */
					/* the CC_SETUP frame. Forward the  */
					/* frame to the application layer ! */
					#if 0 //radva was not in CLMS stack
					/* The assignment to the            */
					/* Application layer is set !       */
					Set_App_Layer_Assignment( CurrentInc, po_no );
					#endif
					/* report the << CC_SETUP >> msg    */
					#ifdef DECT_NG
               #ifdef ULE_SUPPORT
               Set_Actual_Slot_Type(po_no, Required_Slot_Type_CID[CurrentInc]);
					send_up_message_WP( FP_SETUP_IN_CC, temp_service, temp_codec, Get_Actual_Slot_Type(po_no) );
               #else
               Actual_Slot_Type[ po_no - 1]  = Required_Slot_Type_CID[CurrentInc];
					send_up_message_WP( FP_SETUP_IN_CC, temp_service, temp_codec, Actual_Slot_Type[po_no - 1] );
               #endif
					#else
					send_up_message( FP_SETUP_IN_CC );
					#endif
               #ifndef CONFIG_CALL_SETUP_COLLISION_DURING_F01
					#ifdef CONFIG_CC_ENCRYPTION
					#ifdef CONFIG_EARLY_ENCRYPTION
					KNL_SENDTASK_WP_INC(CC, CC_AUTHENTICATE_PT_RQ, YES, 0, 0, 0, CurrentInc);
					#else
					KNL_SENDTASK_INC(CC, CC_AUTHENTICATE_PT_RQ, CurrentInc);
					#endif
					#endif
					#endif
					/* change to state CALL INITIATED   */
					Stop_Pro_Timer( TIMER_CC_02, CurrentInc );
					KNL_Transit( F01 );
				}
				return;

				case CC_CRSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY_CRSS);
					Start_Pro_Timer( TIMER_CC_02, CurrentInc );
				return;

				case CC_CLSS_FACILITY_RQ_SWI:
					send_down_clss_message(SS_FACILITY);
					Start_Pro_Timer( TIMER_CC_02, CurrentInc );
				return;

				case CC_CRSS_FACILITY_IN_LCE:
				case CC_CLSS_FACILITY_IN_LCE:
					// send message to Application
					if (CurrentMessage == CC_CLSS_FACILITY_IN_LCE) {
						send_up_message(FP_FACILITY_IN_CLSS);
					} else if (CurrentMessage == CC_CRSS_FACILITY_IN_LCE) {
						send_up_message(FP_FACILITY_IN_CRSS);
					}
					Start_Pro_Timer( TIMER_CC_02, CurrentInc );
				return;

				default:
					 break;

			}										/* end of switch message				*/
 			break;
		#endif

	}												/* end of switch state					*/
	KNL_T0000();

}													/* end of DECODE_CC()					*/
