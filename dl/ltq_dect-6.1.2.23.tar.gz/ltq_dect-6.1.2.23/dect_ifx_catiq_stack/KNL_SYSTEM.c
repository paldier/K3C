/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
*                   (c) 2005 IFX / INTNIX. All rights reserved.               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  SYSTEM.C                                                *
*     Date       :  18 Nov, 2005                                       *
*     Contents   :  Contents : PRODECT System Calls                         *
*     Hardware   :  IFX 87xx                                               *
*                                                                           *
*****************************************************************************
*/
   /* ========                                                             */
   /* Includes                                                             */
   /* ========                                                             */

#include <stdio.h>
#include <fcntl.h>
#ifdef LINUX
#include <sys/ioctl.h>
#endif
#include <string.h>

#include "DEFINE.H"                    /* Compiler switchs                 */

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "TYPEDEF_CP.H"
#include "CONF_DEF.H"
#include "DECT.H"
#include "ERROR.H"
#ifdef FT
#include "FGLOBAL.H"
#endif
#include "FDEF.H"
#include "MMU.H"
#include "SYSINIT.H"

#ifdef FT
#include "FBMC_DEF.H"
//#include "FMAC_LIB.H"
//#include "FLLME.H"
#include "FMAC_DEF.H"
#endif

#include    "KNL_SYSTEM.H"
#include    "KNL_TASK.H"

#include "ENI_LIB.H"

#include "MESSAGE_DEF.H"
#include "CP_SERVER.H"

#ifdef CATIQ_UPLANE
#include "CAT_UP.H"
#include "DECT_UP.H"
#endif

#include "IFX_DECT_MsgRouter.h"

   /* ==========================                                           */
   /* Global Variable Definition                                           */
   /* ==========================                                           */

#ifdef FT
                                       /* Array for storing the TI values  */
                                       /* of the CC process.               */
                                       /*       CC.PSL / LCE_LIB.C         */
                                       /* ===============================  */
GLOBAL XDATA BYTE TI_Value_PD_CC[ MAX_LINK ];

                                       /* Feature code for Stack        */
                                       /* -------------------------------- */
GLOBAL XDATA BYTE    Feature_Code_CP=0;
                                       /* ATE version information(System_Parameters)    */
                                       /* ------------------------------------------------------- */
GLOBAL XDATA WORD    System_ATE_Ver;
                                       /* System Config idenifier      */
                                       /* -------------------------------- */
GLOBAL XDATA BYTE   System_Config;
                                       /* Delay Tick(100mS) for delay test */
                                       /* -------------------------------- */
#ifdef ST8_EVA
GLOBAL XDATA BYTE    Tick_100mS;
#endif

IMPORT CODE WORD     Library_ver[ ];

#endif //FT
   /* ==========================                                           */
   /* Local Macros & Definitions                                           */
   /* ==========================                                           */

#define  KNL_MAXTASK    (20 * MAX_LINK)
#define  KNL_MAX_TASK_LOAD  (15 * MAX_LINK)
  /* ==============                                                       */
   /* Local typedefs                                                       */
   /* ==============                                                       */
                                       /* TASK QUEUE definition            */
                                       /* ================================ */
typedef struct QUEUES_KNL
{
   BYTE PROCID;
   BYTE MSG;
   BYTE Parameter1;
   BYTE Parameter2;
   BYTE Parameter3;
   BYTE Parameter4;
   FPTR G_PTR;

   BYTE CurrentInc;
}QUEUES_KNL;


   /* ===============                                                      */
   /* Local functions                                                      */
   /* ===============                                                      */
#ifdef ULE_SUPPORT
IMPORT void DECODE_ULE_DLC(HMAC_QUEUES * messagePtr);
#endif

   /* ===============                                                      */
   /* Local variables                                                      */
   /* ===============                                                      */
                                       /* Task Queue                       */
#ifndef COSIC_TQ
LOCAL XDATA struct QUEUES_KNL     TASK_QUEUE_KNL[ KNL_MAXTASK ];
LOCAL XDATA BYTE              TQ_wrt_index;
LOCAL XDATA BYTE              TQ_rd_index;
                                       /* Current Load variables           */
LOCAL XDATA BYTE              Task_Queue_Load;
LOCAL XDATA BYTE              Task_Queue_Peak = 0;
#endif
//LOCAL XDATA BYTE              Stack_Load;
                                       /* Peak variables                   */
//LOCAL XDATA BYTE              Stack_Peak      = 0;
                                       /* Stack variables                  */
//LOCAL XDATA BYTE              Stack_Bottom;

                                       /* Process List Headers             */
#ifdef FT
LOCAL PDATA FPTR              LAP_Head[ MAX_LINK ];
LOCAL PDATA FPTR              LAP_End [ MAX_LINK ];
LOCAL PDATA FPTR              LC_Head [ MAX_LINK ];
LOCAL PDATA FPTR              LC_End  [ MAX_LINK ];
#ifdef CONFIG_REPEATER_SUPPORT
LOCAL PDATA FPTR              LAPR_Head[ MAX_LINK ];
LOCAL PDATA FPTR              LAPR_End [ MAX_LINK ];
LOCAL PDATA FPTR              LCR_Head [ MAX_LINK ];
LOCAL PDATA FPTR              LCR_End  [ MAX_LINK ];
#endif
#endif

   /* ===========================                                          */
   /* Global function definitions                                          */
   /* ===========================                                          */

extern void write_to_hmac_ioctl(BYTE procid, BYTE msgnr
                  ,BYTE param1, BYTE param2, BYTE param3, BYTE param4
                  ,BYTE param5, BYTE param6, FPTR pdata, BYTE inc);
extern BYTE
Get_Assigned_Po_No( BYTE cid );
extern void set_knl_state_to_hmac_ioctl(BYTE * data);
/*
*****************************************************************************
*                                                                           *
*   Function   :  KNL_INIT_TASK_QUEUE                                           *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Initializes the task queue pointers and the variables     *
*                 controlling the main loop.                                *
*   Parms      :  None                                                      *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT void
KNL_INIT_TASK_QUEUE( void )
{
   TQ_wrt_index = TQ_rd_index = Task_Queue_Load = 0;
   PARAMETER1 = PARAMETER2 = PARAMETER3 = PARAMETER4 = PARAMETER5 = PARAMETER6 = 0;
   G_PTR = NULL;
   Mmu_Memset((FPTR) TASK_QUEUE_KNL, 0, sizeof( struct QUEUES_KNL ) * KNL_MAXTASK );
}
#endif


#ifndef COSIC_TQ
EXPORT void
RESET_KNL_INIT_TASK_QUEUE( void )
{
   unsigned char index;

   for(index = 0; index < KNL_MAXTASK; index++)
   {
      if(TASK_QUEUE_KNL[index].G_PTR != NULL)
         Mmu_Free(TASK_QUEUE_KNL[index].G_PTR);
   }



   TQ_wrt_index = TQ_rd_index = Task_Queue_Load = 0;
   PARAMETER1 = PARAMETER2 = PARAMETER3 = PARAMETER4 = PARAMETER5 = PARAMETER6 = 0;
   G_PTR = NULL;

   /* malloc pointer clear by ralph_150508 */

   Mmu_Memset((FPTR) TASK_QUEUE_KNL, 0, sizeof( struct QUEUES_KNL ) * KNL_MAXTASK );
}
#endif




/*
*****************************************************************************
*                                                                           *
*   Function   :  SENDTASK                                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Writes a task to the tail of the task queue with the      *
*                 process identification PROCID and the message MSGNR.      *
*                 The data pointer is set to NULL.                          *
*   Parms      :  PROCID    process identification                          *
*                 MSGNR     message                                         *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT void
KNL_SENDTASK( BYTE PROCID, BYTE MSGNR )
{
   /* Set Task Queue Entry !           */
   TASK_QUEUE_KNL[ TQ_wrt_index ].PROCID = PROCID;
   TASK_QUEUE_KNL[ TQ_wrt_index ].MSG    = MSGNR;
                                       /* to prevent wrong parameter check */
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter1 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter2 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter3 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter4 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].CurrentInc  = 0;
                                       /* Increment Task Queue wrt index ! */
   if( TQ_wrt_index == ( KNL_MAXTASK - 1))
       TQ_wrt_index = 0;
   else
       TQ_wrt_index++;
                                       /* Increment Task Queue load        */
                                       /* variable !                       */
   Task_Queue_Load++;
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  SENDTASK_INC                                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Writes a task to the tail of the task queue with the      *
*                 process identification PROCID and the message MSGNR.      *
*                 The data pointer is set to NULL.                          *
*                 An incarnation number is accepted as part of this message.*
*   Parms      :  PROCID    process identification                          *
*                 MSGNR     message                                         *
*                 IncNumber incarnation number                              *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT void
KNL_SENDTASK_INC( BYTE PROCID, BYTE MSGNR, BYTE IncNumber )
{
                                       /* Set Task Queue Entry !           */
   TASK_QUEUE_KNL[ TQ_wrt_index ].PROCID     = PROCID;
   TASK_QUEUE_KNL[ TQ_wrt_index ].MSG        = MSGNR;
                                       /* to prevent wrong parameter check */
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter1 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter2 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter3 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter4 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].CurrentInc = IncNumber;
                                       /* Increment Task Queue wrt index ! */
   if( TQ_wrt_index == ( KNL_MAXTASK - 1))
       TQ_wrt_index = 0;
   else
       TQ_wrt_index++;
                                       /* Increment Task Queue load        */
                                       /* variable !                       */
   Task_Queue_Load++;

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  SENDTASK_WP                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Writes a task to the tail of  the task queue  with the    *
*                 process identification PROCID and the message MSGNR.      *
*                 The data pointer is set to NULL.                          *
*                 The parameters are set to the desired value.              *
*   Parms      :  PROCID      process identification                        *
*                 MSGNR       message                                       *
*                 Parameter1  parameters sent                               *
*                 Parameter2                                                *
*                 Parameter3                                                *
*                 Parameter4                                                *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT void
KNL_SENDTASK_WP( BYTE PROCID, BYTE MSGNR, BYTE P1, BYTE P2, BYTE P3, BYTE P4 )
{
                                       /* Set Task Queue Entry !           */
   TASK_QUEUE_KNL[ TQ_wrt_index ].PROCID     = PROCID;
   TASK_QUEUE_KNL[ TQ_wrt_index ].MSG        = MSGNR;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter1 = P1;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter2 = P2;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter3 = P3;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter4 = P4;
   TASK_QUEUE_KNL[ TQ_wrt_index ].CurrentInc  = 0;
                                       /* Increment Task Queue wrt index ! */
   if( TQ_wrt_index == ( KNL_MAXTASK - 1))
       TQ_wrt_index = 0;
   else
       TQ_wrt_index++;
                                       /* Increment Task Queue load        */
                                       /* variable !                       */
   Task_Queue_Load++;

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  SENDTASK_WP_INC                                           *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Writes a task to the tail of  the task queue  with the    *
*                 process identification PROCID and the message MSGNR.      *
*                 The data pointer is set to NULL.                          *
*                 The parameters and the incarnation number are set to th   *
*                 desired value.                                            *
*   Parms      :  PROCID      process identification                        *
*                 MSGNR       message                                       *
*                 Parameter1  parameters sent                               *
*                 Parameter2                                                *
*                 Parameter3                                                *
*                 Parameter4                                                *
*                 IncNumber   incarnation number                            *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT void
KNL_SENDTASK_WP_INC( BYTE PROCID, BYTE MSGNR, BYTE P1, BYTE P2, BYTE P3, BYTE P4, BYTE IncNumber )
{
   /* Set Task Queue Entry !           */
   TASK_QUEUE_KNL[ TQ_wrt_index ].PROCID     = PROCID;
   TASK_QUEUE_KNL[ TQ_wrt_index ].MSG        = MSGNR;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter1 = P1;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter2 = P2;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter3 = P3;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter4 = P4;
   TASK_QUEUE_KNL[ TQ_wrt_index ].CurrentInc = IncNumber;
                                       /* Increment Task Queue wrt index ! */
   if( TQ_wrt_index == ( KNL_MAXTASK - 1))
       TQ_wrt_index = 0;
   else
       TQ_wrt_index++;
                                       /* Increment Task Queue load        */
                                       /* variable !                       */
   Task_Queue_Load++;

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  SENDTASK_NP_WP                                            *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Writes a task to the tail of the task queue with the      *
*                 process identification PROCID and the message MSGNR.      *
*                 The data pointer is set to P.                             *
*                 The parameters are set to the desired value.              *
*   Parms      :  PROCID      process identification                        *
*                 MSGNR       message                                       *
*                 P           pointer to frame                              *
*                 Parameter1  parameters sent                               *
*                 Parameter2                                                *
*                 Parameter3                                                *
*                 Parameter4                                                *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT void
KNL_SENDTASK_NP_WP( BYTE PROCID, BYTE MSGNR, FPTR P, BYTE P1, BYTE P2, BYTE P3, BYTE P4 )
{

                                      /* Set Task Queue Entry !           */
   TASK_QUEUE_KNL[ TQ_wrt_index ].PROCID     = PROCID;
   TASK_QUEUE_KNL[ TQ_wrt_index ].MSG        = MSGNR;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter1 = P1;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter2 = P2;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter3 = P3;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter4 = P4;
   TASK_QUEUE_KNL[ TQ_wrt_index ].G_PTR  = P;
   TASK_QUEUE_KNL[ TQ_wrt_index ].CurrentInc  = 0;
                                       /* Increment Task Queue wrt index ! */

   if( TQ_wrt_index == ( KNL_MAXTASK - 1))
       TQ_wrt_index = 0;
   else
       TQ_wrt_index++;
                                       /* Increment Task Queue load        */
                                       /* variable !                       */
   Task_Queue_Load++;

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  SENDTASK_NP_WP_INC                                        *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Writes a task to the tail of the task queue with the      *
*                 process identification PROCID and the message MSGNR.      *
*                 The data pointer is set to P.                             *
*                 The parameters and the incarnation number are set to th   *
*                 desired value.                                            *
*   Parms      :  PROCID      process identification                        *
*                 MSGNR       message                                       *
*                 P           pointer to frame                              *
*                 Parameter1  parameters sent                               *
*                 Parameter2                                                *
*                 Parameter3                                                *
*                 Parameter4                                                *
*                 IncNumber   incarnation number                            *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT void
KNL_SENDTASK_NP_WP_INC( BYTE PROCID, BYTE MSGNR, FPTR P, BYTE P1, BYTE P2, BYTE P3, BYTE P4, BYTE Inc )
{
                                       /* Set Task Queue Entry !           */
   TASK_QUEUE_KNL[ TQ_wrt_index ].PROCID     = PROCID;
   TASK_QUEUE_KNL[ TQ_wrt_index ].MSG        = MSGNR;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter1 = P1;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter2 = P2;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter3 = P3;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter4 = P4;
   TASK_QUEUE_KNL[ TQ_wrt_index ].G_PTR  = P;
   TASK_QUEUE_KNL[ TQ_wrt_index ].CurrentInc = Inc;
                                       /* Increment Task Queue wrt index ! */
   if( TQ_wrt_index == ( KNL_MAXTASK - 1))
       TQ_wrt_index = 0;
   else
       TQ_wrt_index++;
                                       /* Increment Task Queue load        */
                                       /* variable !                       */
   Task_Queue_Load++;

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  SENDTASK_NP_INC                                           *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Writes a task to the tail of the task queue with the      *
*                 process identification PROCID and the message MSGNR.      *
*                 The data pointer is set to P.                             *
*                 An incarnation number is accepted.                        *
*   Parms      :  PROCID      process identification                        *
*                 MSGNR       message                                       *
*                 P           pointer to frame                              *
*                 IncNumber   incarnation number                            *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT void
KNL_SENDTASK_NP_INC( BYTE PROCID, BYTE MSGNR, FPTR P, BYTE Inc )
{
                                       /* Set Task Queue Entry !           */
   TASK_QUEUE_KNL[ TQ_wrt_index ].PROCID     = PROCID;
   TASK_QUEUE_KNL[ TQ_wrt_index ].MSG        = MSGNR;
                                       /* to prevent wrong parameter check */
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter1 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter2 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter3 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter4 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].G_PTR  = P;
   TASK_QUEUE_KNL[ TQ_wrt_index ].CurrentInc = Inc;
                                       /* Increment Task Queue wrt index ! */
   if( TQ_wrt_index == ( KNL_MAXTASK - 1))
       TQ_wrt_index = 0;
   else
       TQ_wrt_index++;
                                       /* Increment Task Queue load        */
                                       /* variable !                       */
   Task_Queue_Load++;

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  SENDTASK_NP                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Writes a task to the tail of the task queue with the      *
*                 process identification PROCID and the message MSGNR.      *
*                 The data pointer is set P.                                *
*   Parms      :  PROCID      process identification                        *
*                 MSGNR       message                                       *
*                 P           pointer to frame                              *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT void
KNL_SENDTASK_NP( BYTE PROCID, BYTE MSGNR, FPTR P )
{
                                       /* Set Task Queue Entry !           */
   TASK_QUEUE_KNL[ TQ_wrt_index ].PROCID      = PROCID;
   TASK_QUEUE_KNL[ TQ_wrt_index ].MSG         = MSGNR;
                                       /* to prevent wrong parameter check */
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter1 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter2 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter3 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter4 = 0;
   TASK_QUEUE_KNL[ TQ_wrt_index ].G_PTR  = P;
   TASK_QUEUE_KNL[ TQ_wrt_index ].CurrentInc  = 0;
                                       /* Increment Task Queue wrt index ! */
   if( TQ_wrt_index == ( KNL_MAXTASK - 1))
       TQ_wrt_index = 0;
   else
       TQ_wrt_index++;
                                       /* Increment Task Queue load        */
                                       /* variable !                       */
   Task_Queue_Load++;

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  KNL_SENDTASK_FROM_HMAC                                    *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Route the event from the HMAC queue to COSIC(LMAC) or Stack       *
*                 The data pointer is set *data.                            *
*   Parms      :  *data   pointer to HMAC_QUEUES frame                      *
*                                                                           *
*                                                                           *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
KNL_SENDTASK_FROM_HMAC(HMAC_QUEUES* data)
{
   FPTR temp_ptr;

   memset(&TASK_QUEUE_KNL[ TQ_wrt_index ],0,sizeof(struct QUEUES_KNL));

   /* from LMAC initial command */
   if (data->PROCID == PROCMAX && data->MSG == STACK_INITAL_CMD) {
      RESET_init_proc_table();

      // Send Boot Indicator to DECT Agent
      // G_PTR buffer = COSIC Modem Compilation time (10 Bytes)
      // Parameter1 & Parameter2 = COSIC Modem Version
      // Parameter3 & Parameter4 = DECT Stack Version
      // Send_Message_To_APP( FP_MODEM_BOOT_IND, NULL, 0, 0, 0, 0, 0 );
      Send_Message_To_APP(FP_MODEM_BOOT_IND,
                          data->G_PTR_buf,
                          0,
                          ((data->Parameter1 & 0x0F)<< 4) | (data->Parameter2 & 0x0F),
                          data->Parameter3,
                          (BYTE)((Library_ver[0] >> 8) & 0x00FF),
                          (BYTE)(Library_ver[0] & 0x00FF));

      /* set hmac status init */
      write_to_hmac_ioctl(HMAC, MAC_INIT_CMD ,0, 0, 0, 0 ,0, 0, 0, 0);
      return;
   } /* HMAC send to APP send command Wide Band Slottype   hiryu_20071220 insert */
   #ifdef DECT_NG
   else if (data->PROCID == PROCMAX && data->MSG == FP_SLOTTYPE_MOD_IN_MAC_TO_APP) {
      #if 1  // SLOTTYPE_MOD_FIX
      Send_Message_To_APP( FP_SLOTTYPE_MOD_IN_MAC, NULL, data->CurrentInc,
      Get_Assigned_Po_No(data->CurrentInc), 0,data->Parameter3,data->Parameter4);
      #else
      Send_Message_To_APP( FP_SLOTTYPE_MOD_IN_MAC, NULL, data->CurrentInc, Get_Assigned_Po_No(data->CurrentInc), 0,data->Parameter3,0);
      #endif
      #if 0  //Radvajesh:Enable voice is done from FT app, so not required to enable voice at stack
      write_to_hmac_ioctl(HMAC, MAC_ENABLE_VOICE_EXTERNAL_SWI, data->Parameter1, Current_Tapi_Ch1[ data->Parameter1 ], 0, 0, 0, 0, 0, 0);
      /* data->Parameter3        slot type */
      /* data->Parameter4        success /fail  */
      #endif
      return;
   }
   #endif
   else if(data->PROCID == PROCMAX && data->MSG == FP_DEBUG_MSG_IN_MAC_TO_APP) {
      Send_Message_To_APP( FP_DEBUG_MESSAGE_IND, NULL, data->CurrentInc,
      data->Parameter1, data->Parameter2,data->Parameter3,data->Parameter4);
      return;
   }
   #ifdef CATIQ_UPLANE
   else if (/*(data->PROCID == HMAC) && */(data->MSG == MAC_FU10_DATA_IN)) {
      /* LMAC send to HMAC FU10_DATA_IN */
      FPTR fptr=0;
      int len;
      #if 0
      for(i=0;i<32;i++)
      {
         if(data->G_PTR_buf[i])
         {



            DECT_DEBUG_UPLANE("MAC_FU10_DATA_IN inc=%d,p[1..4]:%02x %02x %02x %02x Data: %02x %02x %02x %02x %02x %02x %02x %02x...\xd\xa",
                              data->CurrentInc,
                              data->Parameter1,
                              data->Parameter2,
                              data->Parameter3,
                              data->Parameter4,
                              data->G_PTR_buf[0],data->G_PTR_buf[1],data->G_PTR_buf[2],data->G_PTR_buf[3],
                              data->G_PTR_buf[4],data->G_PTR_buf[5],data->G_PTR_buf[6],data->G_PTR_buf[7]);
            break;
         }
      }
      #endif

      if ((data->G_PTR_buf[0] != 0) || (data->G_PTR_buf[1] != 0)) {
         DECT_DEBUG_UPLANE("URX :%02x%02x%02x%02x %02x%02x%02x%02x %02x\r\n", 
      data->G_PTR_buf[0],data->G_PTR_buf[1],data->G_PTR_buf[ 2],data->G_PTR_buf[ 3],
         data->G_PTR_buf[4],data->G_PTR_buf[5],data->G_PTR_buf[ 6],data->G_PTR_buf[ 7], data->G_PTR_buf[ 8]);
         //data->G_PTR_buf[4],data->Parameter3, data->Parameter4 );
         //DECT_DEBUG_UPLANE("URX :%02x%02x%02x%02x %02x%02x%02x%02x %02x%02x%02x%02x[%02x%02x]\r\n", 
         //data->G_PTR_buf[0],data->G_PTR_buf[1],data->G_PTR_buf[ 2],data->G_PTR_buf[ 3],
         //data->G_PTR_buf[4],data->G_PTR_buf[5],data->G_PTR_buf[ 6],data->G_PTR_buf[ 7],
         //data->G_PTR_buf[8],data->G_PTR_buf[9],data->G_PTR_buf[10],data->G_PTR_buf[11],
         //data->Parameter3, data->Parameter4 );
      //DECT_DEBUG_UPLANE("FU10PDURx ok\xd\xa");
      }
      FU10PduRx(data->CurrentInc,data->G_PTR_buf,data->Parameter3,data->Parameter4&0x0F);


      #if UPLANE_LOOP & UPLANE_FTLOOP2
      if(data->Parameter3 & IPALL_OK) {
         len=G_PTR_MAX_COUNT;

         if((PduSSN & 0x7f)==0)  // Only send each 128. packet...
         write_to_hmac_ioctl(HMAC,MAC_FU10_DATA_RQ,           // PROC, msgId
                             (len>>8),(unsigned char)len,0,0, // p1..4
                             0,len,                           // hli flag, len of data
                             data->G_PTR_buf,                            // data

                             data->CurrentInc);                // lln

      }
      #endif
      // return;



         // Check if we shall send something
         //if((data->Parameter4>>4) <= 1)
      { // Modem Buffer are free
         len= FU10PduTx(data->CurrentInc,&fptr,data->Parameter4&0x0F);
         if((len>0) && fptr)
         {
            if ((fptr[0] != 0x00) && (fptr[1] != 0x00) && (fptr[2] != 0xF0) && (fptr[3] != 0xF0))
               DECT_DEBUG_UPLANE("UTX:%02x%02x%02x%02x\r\n", fptr[0],fptr[1],fptr[ 2],fptr[ 3]);
               //DECT_DEBUG_UPLANE("UTX1:%02x%02x%02x%02x%02x\r\n", fptr[0],fptr[1],fptr[ 2],fptr[ 3], fptr[4]);

            // Yes, then send it
            // set len to MAX SPI len.
            len=G_PTR_MAX_COUNT;
            write_to_hmac_ioctl(HMAC,MAC_FU10_DATA_RQ,           // PROC, msgId
                               (len>>8),(unsigned char)len,0,0, // p1..4
                               0,len,                           // hli flag, len of data
                               fptr,                            // data
                               data->CurrentInc);                // lln
            // DECT_DEBUG_UPLANE("Send FU10 PDU to hmac OK\xd\xa");
         }
         else if( fptr )
         {
            // Send Dummy DPU Packet
            DECT_DEBUG_UPLANE("UTX2:%02x%02x%02x%02x\r\n",
            fptr[0],fptr[1],fptr[ 2],fptr[ 3] );
            len = G_PTR_MAX_COUNT;
            write_to_hmac_ioctl( HMAC,MAC_FU10_DATA_RQ,           // PROC, msgId
                                 (len>>8),(unsigned char)len,1,0, // p1..4
                                 0, len,                          // hli flag, len of data
                                 fptr,                            // data
                                 data->CurrentInc );              // lln
            // DECT_DEBUG_UPLANE("Send FU10 PDU to hmac OK\xd\xa");
         }
      }
      return;
   }
   #endif
   #ifdef ULE_SUPPORT
   else if ((data->PROCID == HMAC) && ((data->MSG >= HMAC_ULE_FU10_ACC_IND) && (data->MSG <= HMAC_ULE_FU10_OTHER_IND))) {
      DECODE_ULE_DLC(data);
      return;
   }
   #endif

   /* Set Task Queue Entry !           */
   TASK_QUEUE_KNL[ TQ_wrt_index ].PROCID      = data->PROCID;
   TASK_QUEUE_KNL[ TQ_wrt_index ].MSG         = data->MSG;

   /* to prevent wrong parameter check */
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter1 = data->Parameter1;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter2 = data->Parameter2;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter3 = data->Parameter3;
   TASK_QUEUE_KNL[ TQ_wrt_index ].Parameter4 = data->Parameter4;

   #ifdef CONFIG_REPEATER_SUPPORT
   if (((data->PROCID== LC) || (data->PROCID== LC_REP)) && data->MSG == LC_CO_DATA_IN_MAC) {
   #else
   if (data->PROCID== LC && data->MSG == LC_CO_DATA_IN_MAC) {
   #endif
      temp_ptr = Mmu_Malloc(5 + sizeof( struct HLI_Header ));
      #ifdef KLOCWORK
      if(temp_ptr != NULL)
      #endif
      {
         memcpy(&temp_ptr[sizeof( struct HLI_Header )], data->G_PTR_buf, 5);
         ((struct HLI_Header *)temp_ptr)->length = 5 + sizeof( struct HLI_Header );
         ((struct HLI_Header *)temp_ptr)->next = NULL;
         TASK_QUEUE_KNL[ TQ_wrt_index ].G_PTR  = temp_ptr;
      }
   } else {
      TASK_QUEUE_KNL[ TQ_wrt_index ].G_PTR   = NULL;
   }

   TASK_QUEUE_KNL[ TQ_wrt_index ].CurrentInc  = data->CurrentInc;
                                     /* Increment Task Queue wrt index ! */
   if( TQ_wrt_index == ( KNL_MAXTASK - 1))
      TQ_wrt_index = 0;
   else
      TQ_wrt_index++;
                                     /* Increment Task Queue load        */
                                     /* variable !                       */
   Task_Queue_Load++;
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  KNL_T0000                                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The subroutine KNL_T0000 (UNEXPECTED) is called from the      *
*                 system if the message received from a specific process in *
*                 a particular state is to be ignored (transitions which are*
*                 not specified in a specific state).                       *
*   Parms      :  none                                                      *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
KNL_T0000( void )
{
                                       /* Free Memory !                    */
   if( G_PTR != NULL )
      Mmu_Free( G_PTR );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  KNL_Check_Overload_Condition                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The functions checks the current load of the TASK-Queue,  *
*                 MMU Pool and Stack.                                       *
*   Parms      :  None                                                      *
*   Returns    :  TRUE / FALSE                                              *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifdef FT
EXPORT BIT
KNL_Check_Overload_Condition( void )
{
   return( KNL_Get_TQ_Load() > KNL_MAX_TASK_LOAD);

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  KNL_Store_TQ_Peak                                             *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Updates the Task Queue Load Peak value.                   *
*   Parms      :  none                                                      *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remark     :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT void
KNL_Store_TQ_Peak( void )
{

   if( Task_Queue_Load > Task_Queue_Peak )
   {
       Task_Queue_Peak = Task_Queue_Load;
   }

}
#endif

#if 0
/*
*****************************************************************************
*                                                                           *
*   Function   :  Determine_Stack_Bottom                                    *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Determines the Stack Bottom (after system reset).         *
*   Parms      :  none                                                      *
*   Return     :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remark     :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
KNL_Determine_Stack_Bottom( void )
{
   Stack_Bottom = SP;
   Stack_Load   = SP;
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Store_Stack_Peak                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Stores the Stack peak value.                              *
*   Parms      :  none                                                      *
*   Return     :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remark     :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
KNL_Store_Stack_Peak( void )
{

   if( Stack_Load > Stack_Peak )
   {
      Stack_Peak = Stack_Load;
   }

   Stack_Load = SP;

   if( Stack_Peak > 0xF0 )
       FATAL_ERROR( STACK_OVF );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  KNL_BMC_Store_Stack_Value                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  The function stores the maximum stack load during a BMC-  *
*                 interrupt.                                                *
*   Parms      :  none                                                      *
*   Return     :  none                                                      *
*   Call Level :  ISR Level - BMC                                           *
*   Remark     :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
KNL_BMC_Store_Stack_Value( void )
{
   if( SP > Stack_Load )
      Stack_Load = SP;
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Get_Stack_Load                                            *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Returns the Stack Load.                                   *
*   Parms      :  none                                                      *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remark     :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT BYTE
KNL_Get_Stack_Load( void )
{
   BYTE cur_val;

   cur_val = SP;

   return( cur_val );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  KNL_Get_TQ_Load                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Returns the current Task Queue Load.                      *
*   Parms      :  none                                                      *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remark     :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT BYTE
KNL_Get_TQ_Load( void )
{
   BYTE cur_val;
   cur_val = Task_Queue_Load;

   return( cur_val );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Serve_Task_Queue                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Main Decoding function.                                   *
*                 The main loop (main.c) calls periodically this function.  *
*                 The function sets the global variables when a task is     *
*                 found in the TASK QUEUE. The Task is executed by a call to*
*                 the function DECODE (generated from PCT's).               *
*   Parms      :  None                                                      *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
#ifndef COSIC_TQ
EXPORT void
KNL_Serve_Task_Queue( void )
{
   BYTE cur_val;


#if 1
   unsigned char cid;
   unsigned char data[ 2 ];
   unsigned char changed_flag[ MAX_LINK ];

   for( cid = 0; cid < MAX_LINK; cid++ )
   {
      changed_flag[ cid ] = 0;
      if( (KNL_STATE_ARRAY[ LC  ][ cid ] == CLOSED) &&
          (KNL_STATE_ARRAY[ LAP ][ cid ] == ULI_RELEASED) &&
          (KNL_STATE_ARRAY[ LCE ][ cid ] == LINK_RELEASED) &&
          (KNL_STATE_ARRAY[ CC  ][ cid ] == F00) &&
          (KNL_STATE_ARRAY[ MM  ][ cid ] == MM_OPEN) )
      {
         if( (KNL_STATE_FOR_HMAC[ cid ] & 0x0F) == 0x00 )
         {
            KNL_STATE_FOR_HMAC[ cid ] = (KNL_STATE_FOR_HMAC[ cid] & 0xF0) | 0x01;
            changed_flag[ cid ] = 1;
         }
      }
      else
      {
         if( (KNL_STATE_FOR_HMAC[ cid ] & 0x0F) == 0x01 )
         {
             KNL_STATE_FOR_HMAC[ cid ] = (KNL_STATE_FOR_HMAC[ cid] & 0xF0) | 0x00;
             changed_flag[ cid ] = 1;
         }
      }

      if( KNL_STATE_ARRAY[ CC  ][ cid ] == F10 )
      {
         if( (KNL_STATE_FOR_HMAC[ cid ] & 0xF0) == 0x00 )
         {
            KNL_STATE_FOR_HMAC[ cid ] = (KNL_STATE_FOR_HMAC[ cid] & 0x0F) | 0x10;
            changed_flag[ cid ] = 1;
         }
      }
      else
      {
         if( (KNL_STATE_FOR_HMAC[ cid ] & 0xF0) == 0x10 )
         {
             KNL_STATE_FOR_HMAC[ cid ] = (KNL_STATE_FOR_HMAC[ cid] & 0x0F) | 0x00;
             changed_flag[ cid ] = 1;
         }
      }
   }

   for( cid = 0;  cid < MAX_LINK;  cid++ )
   {
      if( changed_flag[ cid ] == 1 )
      {
         data[ 0 ] = cid;
         data[ 1 ] = KNL_STATE_FOR_HMAC[ cid ];
         set_knl_state_to_hmac_ioctl( data );
      }
   }
#else
   {
      unsigned char cid;
      unsigned char data[2];

      for( cid = 0; cid < MAX_LINK; cid++ )
      {
       if ((KNL_STATE_ARRAY[ LC  ][ cid ] == CLOSED)
         && (KNL_STATE_ARRAY[ LAP ][ cid ] == ULI_RELEASED)
         && (KNL_STATE_ARRAY[ LCE ][ cid ] == LINK_RELEASED)
         && (KNL_STATE_ARRAY[ CC ][ cid ] == F00)
         && (KNL_STATE_ARRAY[ MM ][ cid ] == MM_OPEN))
       {
         if (KNL_STATE_FOR_HMAC[cid] == FALSE)
         {
          KNL_STATE_FOR_HMAC[cid] = TRUE;
          data[0] = cid;
          data[1] = KNL_STATE_FOR_HMAC[cid];
          set_knl_state_to_hmac_ioctl(data);
         }
       }
       else
       {
         if (KNL_STATE_FOR_HMAC[cid] == TRUE)
         {
          KNL_STATE_FOR_HMAC[cid] = FALSE;
          data[0] = cid;
          data[1] = KNL_STATE_FOR_HMAC[cid];
          set_knl_state_to_hmac_ioctl(data);
         }
       }

      }
    }
#endif
                                       /* Get current Task Queue load.     */
   cur_val = Task_Queue_Load;
                                       /* Task Queue empty ?               */
   if( cur_val == 0 )
      return;
                                       /* Overload Condition ?             */
   if( cur_val >= KNL_MAXTASK )
   {
      FATAL_ERROR( TQ_OVF );
     printf("\nSBB: DECT Stack Overflow\n");
   }

/* Update Task Queue Peak value !   */
   KNL_Store_TQ_Peak();



                                       /* Copy Task Queue entry to global  */
                                       /* variables !                      */
   ProcId         = TASK_QUEUE_KNL[ TQ_rd_index ].PROCID;
   CurrentMessage = TASK_QUEUE_KNL[ TQ_rd_index ].MSG;
   PARAMETER1     = TASK_QUEUE_KNL[ TQ_rd_index ].Parameter1;
   PARAMETER2     = TASK_QUEUE_KNL[ TQ_rd_index ].Parameter2;
   PARAMETER3     = TASK_QUEUE_KNL[ TQ_rd_index ].Parameter3;
   PARAMETER4     = TASK_QUEUE_KNL[ TQ_rd_index ].Parameter4;
//   PARAMETER5     = TASK_QUEUE_KNL[ TQ_rd_index ].uni.add_p.Parameter5;
//   PARAMETER6     = TASK_QUEUE_KNL[ TQ_rd_index ].uni.add_p.Parameter6;



   if(TASK_QUEUE_KNL[ TQ_rd_index ].G_PTR != NULL)
   {
      G_PTR          = TASK_QUEUE_KNL[ TQ_rd_index ].G_PTR;
   }

   else
   {
      G_PTR = NULL;
   }


   CurrentInc         = TASK_QUEUE_KNL[ TQ_rd_index ].CurrentInc;
                                       /* Delete entry from Task Queue !   */
   Mmu_Memset((FPTR) &TASK_QUEUE_KNL[ TQ_rd_index ], 0, sizeof( struct QUEUES_KNL ));
                                       /* Increment Task-Queue read index   */

   if( TQ_rd_index == ( KNL_MAXTASK - 1))
       TQ_rd_index = 0;
   else
       TQ_rd_index++;
                                       /* Decrement Task-Queue load variable*/
   Task_Queue_Load--;
                                       /* Check for miscellaneous values !  */
   if( ProcId >= PROCMAX )
      return;
   if( CurrentInc >= INCMAX )
      return;
   if( CurrentMessage == 0xFF )
      return;
                                       /* Set current process state !      */
   CurrentState = KNL_STATE_ARRAY[ ProcId ][ CurrentInc ];

   KNL_DECODE();

}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Transit                                                   *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Used for changing the state of the process identified by  *
*                 the global ProcId and Current_Inc.                        *
*                 The subroutine relies on valid process number.            *
*                 Maps to the predefined macro CST on protocol level.       *
*   Parms      :  NewState                                                  *
*   Returns    :  None                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
KNL_Transit( BYTE NewState )
{
   KNL_STATE_ARRAY[ ProcId ][ CurrentInc ] = NewState;
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Get_KNL_State_Info                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Return the STATE_ARRAY info.                        *
*   Parms      :  proc, inc                                                      *
*   Returns    :  STATE                                                *                                                       *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT BYTE
Get_KNL_State_Info( BYTE proc, BYTE inc )
{
   return KNL_STATE_ARRAY[ proc ][ inc ];
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Put_in_Queue                                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Stores a frame in the given process queue.                *
*   Parms      :  process    : process queue identifier                     *
*                 ptr        : pointer to the frame                         *
*   Returns    :                                                            *                                                       *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Put_in_Queue( BYTE process, BYTE cid, FPTR pNew )
{
   FPTR * ppHead;
   FPTR * ppEnd;

                                       /* Get the Queue pointers !         */
                                       /* ========================         */
   switch( process )
   {
      case LAP :
            ppHead = &LAP_Head[ cid ];
            ppEnd  = &LAP_End [ cid ];
            break;

      case LC :
            ppHead = &LC_Head[ cid ];
            ppEnd  = &LC_End [ cid ];
            break;

      #ifdef CONFIG_REPEATER_SUPPORT
      case LAP_REP :
            ppHead = &LAPR_Head[ cid ];
            ppEnd  = &LAPR_End [ cid ];
            break;

      case LC_REP :
            ppHead = &LCR_Head[ cid ];
            ppEnd  = &LCR_End [ cid ];
            break;
      #endif

      default :
            return;
   }
                                       /* Insert frame in Queue !          */
                                       /* =======================          */
   #ifdef KLOCWORK
   if( pNew == NULL )   return;
   #endif

                                       /* Mark the end of the list !       */
   ((struct HLI_Header * ) pNew ) -> next = NULL;

   if( *ppHead == NULL )
   {
                                       /* The Queue is empty !             */
      *ppHead = pNew;
      *ppEnd  = pNew;
   }
   else
   {
                                       /* The Queue is not empty, insert   */
                                       /* the frame at the end !           */
      ((struct HLI_Header * ) *ppEnd ) -> next = pNew;
      *ppEnd = pNew;
   }
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Get_Next_Queue_Entry                                      *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Returns the next frame of the given process queue.        *
*   Parms      :  process    : process queue identifier                     *
*   Returns    :  pointe to the frame                                       *                                                       *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Get_Next_Queue_Entry( BYTE process, BYTE cid )
{
   FPTR * ppHead;
   FPTR * ppEnd;
   FPTR   pTemp;

                                       /* Get the Queue pointers !         */
                                       /* ========================         */
   switch( process )
   {
      case LAP :
            ppHead = &LAP_Head[ cid ];
            ppEnd  = &LAP_End [ cid ];
            break;

      case LC :
            ppHead = &LC_Head[ cid ];
            ppEnd  = &LC_End [ cid ];
            break;

      #ifdef CONFIG_REPEATER_SUPPORT
      case LAP_REP :
            ppHead = &LAPR_Head[ cid ];
            ppEnd  = &LAPR_End [ cid ];
            break;

      case LC_REP :
            ppHead = &LCR_Head[ cid ];
            ppEnd  = &LCR_End [ cid ];
            break;
      #endif

      default :
            return( NULL );
   }
                                       /* Get next frame from Queue !      */
                                       /* ===========================      */
   if( *ppHead == NULL )
   {
                                       /* The Queue is empty !             */
      return( NULL );
   }
   else
   {
      if( *ppHead == *ppEnd )
      {
                                       /* The last frame is returned !     */
         pTemp   = *ppHead;
         *ppHead = NULL;
         *ppEnd  = NULL;
         ((struct HLI_Header * ) pTemp ) -> next = NULL;
         return( pTemp );
      }
      else
      {
         pTemp   = *ppHead;
         *ppHead = ((struct HLI_Header * ) *ppHead ) -> next;
         ((struct HLI_Header * ) pTemp ) -> next = NULL;
         return( pTemp );
      }
   }
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Get_Next_Queue_Entry_Copy                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Returns a copy of the next frame of the given process     *
*                 queue.                                                    *
*   Parms      :  process    : process queue identifier                     *
*   Returns    :  pointe to the frame                                       *                                                       *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Get_Next_Queue_Entry_Copy( BYTE process, BYTE cid )
{
   FPTR * ppHead;
   FPTR   pTemp;

                                       /* Get the Queue pointers !         */
                                       /* ========================         */
   switch( process )
   {
      case LAP :
            ppHead = &LAP_Head[ cid ];
            break;

      case LC :
            ppHead = &LC_Head[ cid ];
            break;

      #ifdef CONFIG_REPEATER_SUPPORT
      case LAP_REP :
            ppHead = &LAPR_Head[ cid ];
            break;

      case LC_REP :
            ppHead = &LCR_Head[ cid ];
            break;
      #endif

      default :
            return( NULL );
   }
                                       /* Get next frame from Queue !      */
                                       /* ===========================      */
   if( *ppHead == NULL )
   {
                                       /* The Queue is empty !             */
      return( NULL );
   }
   else
   {
                                       /* Copy the frame and return the    */
                                       /* 'frame copy'. The queue list is  */
                                       /* not modified.                    */
      pTemp = Mmu_Malloc( (( struct HLI_Header * ) *ppHead ) -> length );
      #ifdef KLOCWORK
      if(pTemp != NULL)
      #endif
      {
         Mmu_Memcpy( pTemp,
                     *ppHead,
                     (( struct HLI_Header * ) *ppHead ) -> length );
         (( struct HLI_Header * ) pTemp ) -> next = NULL;
      }
      return( pTemp );
   }
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Discard_Queue                                             *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Discards the given process queue.                         *
*   Parms      :  process    : process queue identifier                     *
*   Returns    :                                                            *                                                       *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Discard_Queue( BYTE process, BYTE cid )
{
   FPTR * ppHead;
   FPTR * ppEnd;
   FPTR   pTemp;

                                       /* Get the Queue pointers !         */
                                       /* ========================         */
   switch( process )
   {
      case LAP :
            ppHead = &LAP_Head[ cid ];
            ppEnd  = &LAP_End [ cid ];
            break;

      case LC :
            ppHead = &LC_Head[ cid ];
            ppEnd  = &LC_End [ cid ];
            break;

      #ifdef CONFIG_REPEATER_SUPPORT
      case LAP_REP :
            ppHead = &LAPR_Head[ cid ];
            ppEnd  = &LAPR_End [ cid ];
            break;

      case LC_REP :
            ppHead = &LCR_Head[ cid ];
            ppEnd  = &LCR_End [ cid ];
            break;
      #endif

      default :
            return;
   }

   while( *ppHead != NULL )
   {
      pTemp   = *ppHead;
      *ppHead = (( struct HLI_Header * ) *ppHead ) -> next;
         Mmu_Free( pTemp );
   }

   *ppHead = NULL;
   *ppEnd  = NULL;
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Empty_Queue                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Checks if the given process queue is empty or not.        *
*   Parms      :  process    : process queue identifier                     *
*   Returns    :                                                            *                                                       *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT BIT
Empty_Queue( BYTE process, BYTE cid )
{

   switch( process )
   {
      case LAP :
            return( LAP_Head[ cid ] == NULL );

      case LC :
            return( LC_Head[ cid ] == NULL );

      #ifdef CONFIG_REPEATER_SUPPORT
      case LAP_REP :
            return( LAPR_Head[ cid ] == NULL );

      case LC_REP :
            return( LCR_Head[ cid ] == NULL );
            break;
      #endif

      default :
            return( FALSE );
   }
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Init_Queue                                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Inits the given process queue elements.                   *
*   Parms      :  process    : process queue identifier                     *
*   Returns    :                                                            *                                                       *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT void
Init_Queue( BYTE process )
{
   BYTE i;

   switch( process )
   {
      case LAP :
            for( i = 0; i < MAX_LINK; i++ )
            {
               LAP_Head[ i ] = NULL;
               LAP_End [ i ] = NULL;
            }
            return;

      case LC :
            for( i = 0; i < MAX_LINK; i++ )
            {
               LC_Head[ i ] = NULL;
               LC_End [ i ] = NULL;
            }
            return;

      #ifdef CONFIG_REPEATER_SUPPORT
      case LAP_REP :
            for( i = 0; i < MAX_LINK; i++ )
            {
               LAPR_Head[ i ] = NULL;
               LAPR_End [ i ] = NULL;
            }
            return;

      case LC_REP :
            for( i = 0; i < MAX_LINK; i++ )
            {
               LCR_Head[ i ] = NULL;
               LCR_End [ i ] = NULL;
            }
            return;
      #endif

      default :
            return;
   }
}


