#include "SYSDEF.H"
#include "API.H"
#include "FDEF.H"
#include "MESSAGE_DEF.H"
#include "PCT_DEF.H"

#ifndef COSIC_TQ
extern void
KNL_SENDTASK( BYTE PROCID, BYTE MSGNR );
#endif

extern BIT
Send_Message_To_APP( BYTE msg, FPTR ptr, BYTE inc
                            , BYTE parameter1,  BYTE parameter2,  BYTE parameter3,  BYTE parameter4 );

LOCAL BYTE A44_Mode = 0;

BIT Check_Reg_Mode( void )
{

   return( A44_Mode == 1 );
}

void   Set_Reg_Flag( void )
{
   A44_Mode = 1;
}

void   Clear_Reg_Flag( void )
{
   A44_Mode = 0;
}

void   Clear_Reg_Mode(BYTE curinc, BYTE state )
{
   A44_Mode = 0;
	KNL_SENDTASK( ME, ME_A44_CLEAR_RQ_DIS );
	Send_Message_To_APP(FP_PORTABLE_REGISTER_FAIL_IN_MM,
	NULL,
	curinc,
	DUMMY_FILL,
	DUMMY_FILL,
	DUMMY_FILL,
	state );
}

