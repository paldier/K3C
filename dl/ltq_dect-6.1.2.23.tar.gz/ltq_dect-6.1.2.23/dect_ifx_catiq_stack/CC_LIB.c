/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
*                   (c) 2005 IFX / INTNIX. All rights reserved.               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  CC_LIB.C                                                *
*     Date       :  18 Nov, 2005                                       *
*     Contents   :  Contents : Library for Process 'CALL CONTROL ( CC )'    *
*     Hardware   :  IFX 87xx                                               *
*                                                                           *
*****************************************************************************
*/
   /* ========                                                             */
   /* Includes                                                             */
   /* ========                                                             */
#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#include "KNL_SYSTEM.H"
#include "MMU.H"
#include "PCT_DEF.H"
#include "FGLOBAL.H"

#include "CC_DEF.H"
#include "CC_LIB.H"
#include "ifx_common_defs.h"
#define e_IFX_Return int
#include "IFX_DECT_IEParser.h"

   /* ==========================                                           */
   /* Global function definition                                           */
   /* ==========================                                           */
#if defined(CAT_IQ2_1) || defined(ULE_SUPPORT)
EXPORT FPTR
Add_TRANSPARENT( FPTR frame_ptr, FPTR source_ptr )
{
   BYTE current_pos, length;
   #ifdef KLOCWORK
   FPTR temp_ptr;
   #endif

   if ( frame_ptr == NULL || source_ptr == NULL ||
        ((DATA_FRAME *) source_ptr)->length <= 1 )
      return( frame_ptr );

   current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
   length      = (( DATA_FRAME * ) source_ptr ) -> length;

   #ifdef KLOCWORK
   temp_ptr   = Mmu_Realloc( frame_ptr, current_pos + length );
   if( temp_ptr == NULL ) {
      return( frame_ptr );
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + length );
   #endif
   Mmu_Memcpy( &frame_ptr[ current_pos ], (( DATA_FRAME * ) source_ptr ) -> dat, length );
                                       /* Update of HLI_Header.            */
   ( ( struct HLI_Header * ) frame_ptr ) -> length = current_pos + length;

   return( frame_ptr );
} // Add_TRANSPARENT()
#endif

EXPORT FPTR
Add_PROPRIETARY( FPTR frame_ptr, FPTR source_ptr )
{
   BYTE current_pos, length;
   #ifdef KLOCWORK
   FPTR temp_ptr;
   #endif

   if ( frame_ptr == NULL || source_ptr == NULL ||
        ((DATA_FRAME *) source_ptr)->length <= 3 )
      return( frame_ptr );

   current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
   length      = (( DATA_FRAME * ) source_ptr ) -> length;

   #ifdef KLOCWORK
   temp_ptr   = Mmu_Realloc( frame_ptr, current_pos + length );
   if( temp_ptr == NULL ) {
      return( frame_ptr );
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + length );
   #endif
   Mmu_Memcpy( &frame_ptr[ current_pos ], (( DATA_FRAME * ) source_ptr ) -> dat, length );
                                       /* Update of HLI_Header.            */
   ( ( struct HLI_Header * ) frame_ptr ) -> length = current_pos + length;

   return( frame_ptr );
}

EXPORT FPTR
Add_IWU_PROPRIETARY( FPTR frame_ptr, FPTR source_ptr )
{
   if ( frame_ptr != NULL && source_ptr != NULL &&
        ((DATA_FRAME *) source_ptr)->length > 3 )
   {
      frame_ptr = Append_IE( frame_ptr,
                             IWU_TO_IWU,
                             ((DATA_FRAME *) source_ptr)->length,
                             ((DATA_FRAME *) source_ptr)->dat );
   }

   return( frame_ptr );
}

#ifdef DECT_NG
EXPORT FPTR
Add_CODEC_LIST( FPTR frame_ptr, FPTR source_ptr )
{

   if ( frame_ptr != NULL && source_ptr != NULL &&  ((DATA_FRAME *) source_ptr)->length > 3 )
   {
      frame_ptr = Append_IE( frame_ptr,
                                CODEC_LIST,
                                ((DATA_FRAME *) source_ptr)->length,
                                ((DATA_FRAME *) source_ptr)->dat );
   }
   return( frame_ptr );
}
EXPORT FPTR
Add_CODEC_LIST1( FPTR frame_ptr, FPTR source_ptr )
{

   if ( frame_ptr != NULL && source_ptr != NULL &&  ((DATA_FRAME *) source_ptr)->length > 3 )
   {
     IFX_DECT_IE_IEAdd(((uint32)((DATA_FRAME *) frame_ptr)->dat),IFX_DECT_IE_CODECLIST,source_ptr);

   }
   return( frame_ptr );
}
#endif

#ifdef DECT_NG
EXPORT FPTR
Add_PROGRESS_INDICATOR( FPTR frame_ptr, FPTR source_ptr )
{

   if ( frame_ptr != NULL && source_ptr != NULL &&  ((DATA_FRAME *) source_ptr)->length > 0 )
   {
      frame_ptr = Append_IE( frame_ptr,
                                PROGRESS_INDICATOR,
                                ((DATA_FRAME *) source_ptr)->length,
                                ((DATA_FRAME *) source_ptr)->dat );
   }
   return( frame_ptr );
}
#endif

/*
*****************************************************************************
*                                                                           *
*   Function   :  Make_S_FORMAT_Message                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Constructs the Header of a S-FORMAT Message as specified  *
*                 in ETS 300 175-5 / 7.1                                    *
*   Parms      :  pd              : Protocol Discriminator                  *
*                 ti              : Transaction Identifier                  *
*                 msg_type        : Type of Layer 3 Message                 *
*   Returns    :  Pointer to the constructed S-FORMAT Message               *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Make_S_FORMAT_Message( BYTE pd, BYTE ti, BYTE msg_type )
{
   FPTR  temp_ptr;
                                       /* ------------------------------  */
                                       /*|            TI        |          PD           |  */
                                       /* ------------------------------  */
                                       /*|                   msg_type                 |  */
                                       /* ------------------------------  */
   temp_ptr = Mmu_Malloc( 2 + sizeof( struct HLI_Header ) );

   #ifdef KLOCWORK
   if( temp_ptr != NULL )
   #endif
   {
      ( ( struct HLI_Header * ) temp_ptr ) -> length =
          2 + sizeof( struct HLI_Header );
                                       /* Set the Transaction Identifier   */
                                       /* and the Protocol discriminator   */
                                       /* element.                         */
      temp_ptr[ sizeof( struct HLI_Header ) ]        =
          ti | pd;
                                       /* Set the Message type element     */
      temp_ptr[ 1 + sizeof( struct HLI_Header ) ]    =
          msg_type;
   }
   return( temp_ptr );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Construct_MNCC_Primitive                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Constructs the Header of a MNCC-Primitve as specified     *
*                 in ETS 300 175-5 / 16.3.2                                 *
*   Parms      :  none                                                      *
*   Return     :  Pointer to the constructed MNCC-Primitive                 *
*   Call Level :  Process Level                                             *
*   Remarks    :  A dummy value is inserted, in order to allow the usage of *
*                 the same scan-Routine for MNCC-Primitives and FORMAT-S    *
*                 Messages.                                                 *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Construct_MNCC_Primitive( void )
{
   FPTR  temp_ptr;
                                       /* ����������������������������Ŀ   */
                                       /* ?HLI_Header ?dummy ?dummy ?  */
                                       /* ������������������������������   */
   temp_ptr = Mmu_Malloc( 2 + sizeof( struct HLI_Header ) );
   #ifdef KLOCWORK
   if( temp_ptr != NULL )
   #endif
   {
      ( ( struct HLI_Header * ) temp_ptr ) -> length =
          2 + sizeof( struct HLI_Header );

                                          /* Set the dummy value.             */
      temp_ptr[ sizeof( struct HLI_Header ) ]        =
          0x00;
      temp_ptr[ 1 + sizeof( struct HLI_Header ) ]    =
          0x00;
   }
   return( temp_ptr );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Add_IE_1                                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Appends an information element to frame pointed by Ptr.   *
*                 The information element is given bytewise as calling      *
*                 parameters.                                               *
*   Parms      :  frame_ptr       : Pointer to the frame, to which the IE   *
*                                   shall be added.                         *
*                 ie_byte_1       : Information element to be added.        *
*   Returns    :  frame_ptr       : Pointer to the frame.                   *
*   Call Level :  Process Level                                             *
*   Remarks    :  frame_ptr must be returned, cause of the Mmu_Realloc-Fkt. *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Add_IE_1( FPTR frame_ptr, BYTE ie_byte_1 )
{
   BYTE current_pos;
   #ifdef KLOCWORK
   FPTR temp_ptr;
   #endif

   if( frame_ptr == NULL )
      return( frame_ptr );
                                       /* Get current frame length.        */
   current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
                                       /* Get memory for the IE.           */
   #ifdef KLOCWORK
   temp_ptr   = Mmu_Realloc( frame_ptr, current_pos + 1 );
   if( temp_ptr == NULL ) {
      return( frame_ptr );
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + 1 );
   #endif
                                       /* Append the IE.                   */
   frame_ptr[ current_pos++ ] = ie_byte_1;
                                       /* Update of HLI_Header.            */
   (( struct HLI_Header * ) frame_ptr ) -> length = current_pos;
   return( frame_ptr );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Add_IE_2                                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Appends an information element to frame pointed by Ptr.   *
*                 The information element is given bytewise as calling      *
*                 parameters.                                               *
*   Parms      :  frame_ptr       : Pointer to the frame, to which the IE   *
*                                   shall be added.                         *
*                 ie_byte_1       : Information element to be added.        *
*                 .                                                         *
*                 .                                                         *
*   Returns    :  frame_ptr       : Pointer to the frame.                   *
*   Call Level :  Process Level                                             *
*   Remarks    :  frame_ptr must be returned, cause of the Mmu_Realloc-Fkt. *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Add_IE_2( FPTR frame_ptr, BYTE ie_byte_1, BYTE ie_byte_2 )
{
   BYTE current_pos;
   #ifdef KLOCWORK
   FPTR temp_ptr;
   #endif

   if( frame_ptr == NULL )
      return( frame_ptr );
                                       /* Get current frame length.        */
   current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
                                       /* Get memory for the IE.           */
   #ifdef KLOCWORK
   temp_ptr   = Mmu_Realloc( frame_ptr, current_pos + 2 );
   if( temp_ptr == NULL ) {
      return( frame_ptr );
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + 2 );
   #endif
                                       /* Append the IE.                   */
   frame_ptr[ current_pos++ ] = ie_byte_1;
   frame_ptr[ current_pos++ ] = ie_byte_2;
                                       /* Update of HLI_Header.            */
   (( struct HLI_Header * ) frame_ptr ) -> length = current_pos;
   return( frame_ptr );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Add_IE_3                                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Appends an information element to frame pointed by Ptr.   *
*                 The information element is given bytewise as calling      *
*                 parameters.                                               *
*   Parms      :  frame_ptr       : Pointer to the frame, to which the IE   *
*                                   shall be added.                         *
*                 ie_byte_1       : Information element to be added.        *
*                 .                                                         *
*                 .                                                         *
*   Returns    :  frame_ptr       : Pointer to the frame.                   *
*   Call Level :  Process Level                                             *
*   Remarks    :  frame_ptr must be returned, cause of the Mmu_Realloc-Fkt. *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Add_IE_3( FPTR frame_ptr, BYTE ie_byte_1, BYTE ie_byte_2, BYTE ie_byte_3 )
{
   BYTE current_pos;
   #ifdef KLOCWORK
   FPTR temp_ptr;
   #endif

   if( frame_ptr == NULL )
      return( frame_ptr );
                                       /* Get current frame length.        */
   current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
                                       /* Get memory for the IE.           */
   #ifdef KLOCWORK
   temp_ptr   = Mmu_Realloc( frame_ptr, current_pos + 3 );
   if( temp_ptr == NULL ) {
      return( frame_ptr );
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + 3 );
   #endif
                                       /* Append the IE.                   */
   frame_ptr[ current_pos++ ] = ie_byte_1;
   frame_ptr[ current_pos++ ] = ie_byte_2;
   frame_ptr[ current_pos++ ] = ie_byte_3;
                                       /* Update of HLI_Header.            */
   (( struct HLI_Header * ) frame_ptr ) -> length = current_pos;
   return( frame_ptr );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Add_IE_4                                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Appends an information element to frame pointed by Ptr.   *
*                 The information element is given bytewise as calling      *
*                 parameters.                                               *
*   Parms      :  frame_ptr       : Pointer to the frame, to which the IE   *
*                                   shall be added.                         *
*                 ie_byte_1       : Information element to be added.        *
*                 .                                                         *
*                 .                                                         *
*   Returns    :  frame_ptr       : Pointer to the frame.                   *
*   Call Level :  Process Level                                             *
*   Remarks    :  frame_ptr must be returned, cause of the Mmu_Realloc-Fkt. *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Add_IE_4( FPTR frame_ptr, BYTE ie_byte_1, BYTE ie_byte_2, BYTE ie_byte_3, BYTE ie_byte_4 )
{
   BYTE current_pos;
   #ifdef KLOCWORK
   FPTR temp_ptr;
   #endif

   if( frame_ptr == NULL )
      return( frame_ptr );
                                       /* Get current frame length.        */
   current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
                                       /* Get memory for the IE.           */
   #ifdef KLOCWORK
   temp_ptr   = Mmu_Realloc( frame_ptr, current_pos + 4 );
   if( temp_ptr == NULL ) {
      return( frame_ptr );
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + 4 );
   #endif
                                       /* Append the IE.                   */
   frame_ptr[ current_pos++ ] = ie_byte_1;
   frame_ptr[ current_pos++ ] = ie_byte_2;
   frame_ptr[ current_pos++ ] = ie_byte_3;
   frame_ptr[ current_pos++ ] = ie_byte_4;

                                       /* Update of HLI_Header.            */
   (( struct HLI_Header * ) frame_ptr ) -> length = current_pos;
   return( frame_ptr );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Add_IE_5                                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Appends an information element to frame pointed by Ptr.   *
*                 The information element is given bytewise as calling      *
*                 parameters.                                               *
*   Parms      :  frame_ptr       : Pointer to the frame, to which the IE   *
*                                   shall be added.                         *
*                 ie_byte_1       : Information element to be added.        *
*                 .                                                         *
*                 .                                                         *
*   Returns    :  frame_ptr       : Pointer to the frame.                   *
*   Call Level :  Process Level                                             *
*   Remarks    :  frame_ptr must be returned, cause of the Mmu_Realloc-Fkt. *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Add_IE_5( FPTR frame_ptr, BYTE ie_byte_1, BYTE ie_byte_2, BYTE ie_byte_3, BYTE ie_byte_4, BYTE ie_byte_5 )
{
   BYTE current_pos;
   #ifdef KLOCWORK
   FPTR temp_ptr;
   #endif

   if( frame_ptr == NULL )
      return( frame_ptr );
                                       /* Get current frame length.        */
   current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
                                       /* Get memory for the IE.           */
   #ifdef KLOCWORK
   temp_ptr   = Mmu_Realloc( frame_ptr, current_pos + 5 );
   if( temp_ptr == NULL ) {
      return( frame_ptr );
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + 5 );
   #endif
                                       /* Append the IE.                   */
   frame_ptr[ current_pos++ ] = ie_byte_1;
   frame_ptr[ current_pos++ ] = ie_byte_2;
   frame_ptr[ current_pos++ ] = ie_byte_3;
   frame_ptr[ current_pos++ ] = ie_byte_4;
   frame_ptr[ current_pos++ ] = ie_byte_5;
                                       /* Update of HLI_Header.            */
   (( struct HLI_Header * ) frame_ptr ) -> length = current_pos;
   return( frame_ptr );
}
/*
*****************************************************************************
*                                                                           *
*   Function   :  Add_IE_6                                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Appends an information element to frame pointed by Ptr.   *
*                 The information element is given bytewise as calling      *
*                 parameters.                                               *
*   Parms      :  frame_ptr       : Pointer to the frame, to which the IE   *
*                                   shall be added.                         *
*                 ie_byte_1       : Information element to be added.        *
*                 .                                                         *
*                 .                                                         *
*   Returns    :  frame_ptr       : Pointer to the frame.                   *
*   Call Level :  Process Level                                             *
*   Remarks    :  frame_ptr must be returned, cause of the Mmu_Realloc-Fkt. *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Add_IE_6( FPTR frame_ptr, BYTE ie_byte_1, BYTE ie_byte_2, BYTE ie_byte_3, BYTE ie_byte_4, BYTE ie_byte_5, BYTE ie_byte_6 )
{
   BYTE current_pos;
   #ifdef KLOCWORK
   FPTR temp_ptr;
   #endif

   if( frame_ptr == NULL )
      return( frame_ptr );
                                       /* Get current frame length.        */
   current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
                                       /* Get memory for the IE.           */
   #ifdef KLOCWORK
   temp_ptr   = Mmu_Realloc( frame_ptr, current_pos + 6 );
   if( temp_ptr == NULL ) {
      return( frame_ptr );
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + 6 );
   #endif
                                       /* Append the IE.                   */
   frame_ptr[ current_pos++ ] = ie_byte_1;
   frame_ptr[ current_pos++ ] = ie_byte_2;
   frame_ptr[ current_pos++ ] = ie_byte_3;
   frame_ptr[ current_pos++ ] = ie_byte_4;
   frame_ptr[ current_pos++ ] = ie_byte_5;
   frame_ptr[ current_pos++ ] = ie_byte_6;
                                       /* Update of HLI_Header.            */
   (( struct HLI_Header * ) frame_ptr ) -> length = current_pos;
   return( frame_ptr );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  Append_IE                                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Appends an information element to frame pointed by Ptr.   *
*                 Source points to the IE content to be added.              *
*   Parms      :  frame_ptr       : Pointer to the frame, to which the IE   *
*                                   shall be added.                         *
*                 ie_identifier   : The information element identifier      *
*                 ie_length       : Size of the Information element to be   *
*                                   added.                                  *
*                 source_ptr      : Pointer to the Information element      *
*                                   content                                 *
*   Returns    :  frame_ptr       : Pointer to the frame.                   *
*   Call Level :  Process Level                                             *
*   Remarks    :  frame_ptr must be returned, cause of the Mmu_Realloc-Fkt. *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
Append_IE( FPTR frame_ptr, BYTE ie_identifier, BYTE ie_length, FPTR source_ptr )
{
   BYTE current_pos;
   #ifdef KLOCWORK
   FPTR temp_ptr;
   #endif

   if( frame_ptr == NULL )
      return( frame_ptr );
                                       /* Get current frame length.        */
   current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
                                       /* Get memory for the IE.           */
   #ifdef KLOCWORK
   temp_ptr   = Mmu_Realloc( frame_ptr, current_pos + 2 + ie_length );
   if( temp_ptr == NULL ) {
      return( frame_ptr );
   } else {
      frame_ptr = temp_ptr;
   }
   #else
   frame_ptr   = Mmu_Realloc( frame_ptr, current_pos + 2 + ie_length );
   #endif
                                       /* Append the IE.                   */
   frame_ptr[ current_pos++ ] = ie_identifier;
   frame_ptr[ current_pos++ ] = ie_length;
   Mmu_Memcpy( &frame_ptr[ current_pos ], source_ptr, ie_length );
                                       /* Update of HLI_Header.            */
   ( ( struct HLI_Header * ) frame_ptr ) -> length = current_pos + ie_length;
   return( frame_ptr );
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  scan_IE                                                   *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  Scans for the specified Information element in a          *
*                 S-FORMAT Message or in a MNCC-Primitive.                  *
*   Parms      :  frame_ptr       : Pointer to the frame, which shall be    *
*                                   searched through.                       *
*                 info_element_id : The searched information element        *
*                                   identifier.                             *
*                 minimal_lenght  : Minimum required size of the            *
*                                   Information element.                    *
*   Return     :  0 if the requested IE element was not found, otherwise    *
*                 the index to the IE element.                              *
*   Call Level :  Process Level                                             *
*   Remarks    :  The Length is only checked, when scanning for a Varibale  *
*                 Length IE is performed.                                   *
*                                                                           *
*****************************************************************************
*/
EXPORT BYTE
scan_IE( FPTR frame_ptr, BYTE info_element_id, BYTE min_length, BYTE max_length )
{
   BYTE index;
   FPTR current_p;
   BYTE IE_type;
                                       /* Begin at first possible IE to    */
                                       /* search !                         */

                                       /* FORMAT-S Message:                */
                                       /* ����������������?               */
                                       /* ��������������������������...?  */
                                       /* ?HLI_H ?TI&PD ?MSG  ?IE's?  */
                                       /* ��������������������������...?  */

                                       /* MNCC-Primitive:                  */
                                       /* ��������������?                 */
                                       /* ��������������������������...?  */
                                       /* ?HLI_H ?dummy ?CID  ?IE's?  */
                                       /* ��������������������������...?  */

                                       /* Frame there ?                    */
   if( frame_ptr == NULL )
      return( 0 );
#if 0
// TODO: ???? jerom code merge    hiryu_20080830
   if(((struct HLI_Header *) frame_ptr )->length == 0)
   	return( 0);
// TODO: ???? jerom code merge    hiryu_20080830
#endif
   index     = sizeof( struct HLI_Header ) + 2;
   current_p = frame_ptr + index;
                                       /* Loop until end-of-frame.         */
   for ( ; index < ((struct HLI_Header *) frame_ptr ) -> length; )
   {
                                       /* Determine IE-Typ                 */
                                       /* ================================ */
         if( *current_p & 0x80 )
         {
                                       /* If MSB is set we talk about a    */
                                       /* FIXED LENGTH IE.                 */

                                       /* DOUBLE OCTET IE ?                */
             if(( *current_p & 0xF0 ) == 0xE0 )
                 IE_type = DOUBLE_OCTET_IE;
             else
                 IE_type = SINGLE_OCTET_IE;
         }
         else
         {
                                       /* MSB is cleared, we got a         */
                                       /* VARIABLE LENGTH IE.              */
                 IE_type = VARIABLE_LENGTH_IE;
         }
                                       /* Switch over IE-Typ               */
                                       /* ================================ */
         switch ( IE_type )
         {
            case SINGLE_OCTET_IE:
                                       if( *current_p == info_element_id )
                                          return( index );
                                       else
                                          index += 1;
                                       break;
            case DOUBLE_OCTET_IE:
                                       if( *current_p == info_element_id )
                                          return( index );
                                       else
                                          index += 2;
                                       break;
            case VARIABLE_LENGTH_IE:
                                       /* Additional the required          */
                                       /* Length is checked.               */

                                       if(( *current_p == info_element_id  ) &&
                                          ( *(current_p + 1) >= min_length ) &&
                                          ( *(current_p + 1) <= max_length ))
                                          return( index );
                                       else
                                          index += ( *(current_p + 1)) + 2;
                                       break;
            default:
                                       return( 0 );
         }
                                       /* Scan ahead !                     */
                                       /* ================================ */
         current_p = frame_ptr + index;
   }                                   /* end of for loop                  */
   return( 0 );                        /* Message length exceeded.         */
}



