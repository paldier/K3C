#ifdef CATIQ_UPLANE    
/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V9.0       *
*                   (c) 2008 IFX / Peucon. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  LU10RX.C                                                *
*     Date       :  7. August, 2008                                         *
*     Contents   :  U-Plane DLC Layer SDU transmit Functions.               *
*     Hardware   :  IFX 97xx                                                *
*                                                                           *
*---------------------------------------------------------------------------*
* Change History:                                                           *
*                                                                           *
* Date         Author Description                                           *
* 10-Jul-2008  U.P.   Initial version                                       *
* 05-Aug-2008  C.S.   Additional comments,                                  *
*                     Function name InitFU10SduRx corrected to InitLU10SduRx* 
*                     Function name FU10SduRx corrected to LU10SduRx        * 
* 07-Aug-2008  C.S.   Comments corrected                                    *
*****************************************************************************
*/
/** \file
 *  \brief LU10 SDU RX handling
 */ 
#include "ifx_common_defs.h"
#include "DEFINE.H"                    /* Compiler switchs                 */
#include "SYSDEF.H"

#include "DECT_UP.H"
#include "LUFU10AC.H"
#include "MMU.H"
#include "CAT_UP.H"
#include "PCT_DEF.H"
#ifdef FT
#include "CONF_CP.H"
#include "uplane_if.h"
#endif
#include "CP_SERVER.H"
#include "MESSAGE_DEF.H"

#include <stdio.h>

   /* ===============                                                      */
   /* Global variables                                                     */
   /* ===============                                                      */

   /* ===============                                                      */
   /* Local variables                                                      */
   /* ===============                                                      */

// Number of SDU Buffers per logical links (LLN)
LOCAL SDU_BUFFER_STRUCT XDATA SduRxBuf[DLC_U_LLN_MAX];

// SDU data arrays for each SDU buffer (SDU_BUFF_MAX) of SDU length (SDU_LEN_MAX)
LOCAL uint8             XDATA SduRxMem[DLC_U_LLN_MAX][SDU_BUFF_MAX][SDU_LEN_MAX];
   
   /* ===========================                                          */
   /* Local function declarations                                          */
   /* ===========================                                          */

   /* ===================                                                  */
   /* Function Definition                                                  */
   /* ===================                                                  */

/*
*****************************************************************************
*                                                                           *
*     Function :  InitLU10SduRx                                             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Initialisation of the SDU RX buffer number 0              *
*     Parms    :  Locigal link number, Lln                                  *
*                 Local(static): SduRxBuf[0]                                *
*     Returns  :  Local(static): SduRxBuf[0]                                *
*     Remarks  :  For SDU_BUFF_MAX = 0x02 and after initialisation          *
*                 We have 1 SDU RX Buffer ([0]) buffering 2 SDUs ([0] and   *
*                 [1]). The 2 SDUs are SduRxMem 0 and 1.                    *
*                                                                           *
*                 SDU RX Buffer (struct) is composed of                     *
*                 MaximumSduSize: protocol max SDU size                     *
*                 FreeByte:       number of free byte for sending           *
*                 Write:          Buffer write counter (number of bytes     *
*                                 written into buffer)                      *
*                 Read:           Buffer read counter  (number of bytes     *
                                  read out of buffer)                       *
*                 Sdu[]:          SDU data array                            *
*                                                                           *
*                 SDU array (struct) is composed of                         *
*                 Length:         Length of the SDU data                    *
*                 ReadByte:       Number read bytes                         *
*                 DataP:          Pointer to the SDU data (here SduRxMem[]) *
*     Called by:  LU10INI.C/InitUPlane()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT void
InitLU10SduRx ( uint8 Lln )
{
uint8 XDATA BuffCount;

  Mmu_Memset((FPTR)&SduRxBuf[Lln],0x00,sizeof(SDU_BUFFER_STRUCT)); // Sets struct SduRxBuf to 0x00

  Mmu_Memset((FPTR)&SduRxMem[Lln],0x00,SDU_BUFF_MAX*SDU_LEN_MAX); // Sets data array SduRxMem to 0x00

  SduRxBuf[Lln].MaxSduSize    = SDU_LEN_MAX;
  SduRxBuf[Lln].FreeSduBuffer = SDU_BUFF_MAX;

  for(BuffCount = 0;BuffCount<SDU_BUFF_MAX ;BuffCount++ )
  {
    SduRxBuf[Lln].Sdu[BuffCount].DataP = SduRxMem[Lln][BuffCount]; // Sets SDU data part to SduRxMem buffer pointers 
  }

  SduRxBuf[Lln].State = UPCON_ACTIV;

}

/*
*****************************************************************************
*                                                                           *
*     Function :  DeInitLU10PduRx                                           *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Deinitialisation of the SDU RX buffer number 0            *
*     Parms    :  Locigal link number, Lln                                  *
*              :  Set Connectuin  state                                     *
*     Returns  :  Local(static):                                            *
*                                                                           *
*     Remarks  :                                                            *
*     Called by:  LU10INI.C/InitUPlane()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT void
DeInitLU10SduRx ( uint8 Lln )
{
  SduRxBuf[Lln].State = UPCON_IDLE;
}

#ifdef LU10_SDURX_POLLMODE
/*
*****************************************************************************
*                                                                           *
*     Function :  LU10SduRx                                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Fills receive SDU data buffer                             *
*     Parms    :  Locigal link number, Lln                                  *
*                 Pointer to received SDU data, SduDataP                    *
*     Returns  :  Length of received SDU data, Retval                       *
*                 By reference: Pointer to SDU data buffer, SduDataP        *
*     Remarks  :  Lln is only used for FT.                                  *
*                                                                           *
*                 Index of RX SDU data is derived from Read counter using   *
*                 max number of buffers - 1 (SDU_BUFF_MOD) as modulo,       *
*                 further called read index.                                *
*                                                                           *
*                 It checks whether write counter and read counter of SDU RX*
*                 buffer are not equal. In this case the buffer holds a     *
*                 received SDU in SDU data buffer.                          *
*                 It sets the passed over pointer (SduDataP)to the SDU data *
*                 buffer concerning current read index.                     *
*                 Then it set the return value and increments read counter  *
*                 by 1.
*     Called by:  LU10INI.C/InitUPlane()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT int16
LU10SduRx (uint8 Lln, FPTR *SduDataP )
{
int16 XDATA SduLength = 0;
SDU_DATA_STRUCT XDATA *SduBufPtr;
                                       
#ifdef FT // Fixed part terminal
  if(Lln >= DLC_U_LLN_MAX)
  {
    return(-1);
  }
#else // Portable part terminal
  SET_PORT_DEBUG(LU10RX_ACTIVE);
  Lln = 0;
#endif 

  if(SduRxBuf[Lln].Write != SduRxBuf[Lln].Read)  /* data avalable                    */                    
  {
    SduBufPtr = & SduRxBuf[Lln].Sdu[SduRxBuf[Lln].Read & SDU_BUFF_MOD];
    *SduDataP = SduBufPtr->DataP;
    SduLength = SduBufPtr->Length;
    SduBufPtr->Length = 0;
    SduRxBuf[Lln].Read++;
    DECT_DEBUG_LU10RX("%1d %4d",Lln,Retval,0,0);
  }
  SET_PORT_DEBUG(UPLANE_NOACTIVE);
  return(SduLength);                      
}
#endif // LU10_SDURX_POLLMODE

/*
*****************************************************************************
*                                                                           *
*     Function :  CopyPdu2Sdu                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Copies received PDU data into SDU buffer                  *
*     Parms    :  Locigal link number, Lln                                  *
*                 Pointer to received PDU data, PduPtr                      *
*     Returns  :  none                                                      *
*     Remarks  :  Index of RX SDU data is derived from Read and Write       *
*                 counter using max number of buffers (SDU_BUFF_MOD) as     *
*                 modulo, further called read and write index.              *
*                                                                           *
*                 The buffer holds to SDU data buffers at index 0 and 1     *
*                 These are used alternating indentified by read and write  *
*                 index. When PDUs are copied into the SDU data buffer      *
*                 the write index is used e.g. index 0. When the SDU is     *
*                 completed write index is incremented to 1 and now index 0 *
*                 becomes the read index. When SDU has been read and sent   *
*                 also read index is incremented by one. In this case both  *
*                 indexes are equal and no SDU is ready to be read.
*                                                                           *
*                 It sets the local SDU data pointer to the current SDU data*
*                 pointer of the SDU RX buffer using write index.           *
*                 After this it copies the PDU data into the SDU data       *
*                 buffer starting at position defined by SduDataP->Length   *
*                 in order to continue assembling a SDU.                    *
*                 Then it increments SduDataP->Length by length of copied   *
*                 PDU.                                                      *
*                 Now it check whether this is last PDU of the SDU using    *
*                 more bit value.                                           *
*                 If it is the case it increments write index to be prepared*
*                 for next SDU.                                             *
*                 It checks whether write counter and read counter of SDU RX*
*                 buffer are not equal. This is the case when SDU was       *
*                 complete and write index has been incremented before.     *
*                 In this case it sets the local SDU data pointer to the    *
*                 current SDU data pointer of the SDU RX buffer using       *
*                 read index.                                               *
*                 Next is that completed SDU is sent to U-Plane via SPI. If *
*                 this is successful, read index is incremented.            *
*                                                                           *
*     Called by:  FU10ACRX.C/FU10PduRx()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT uint8
CopyPdu2Sdu (uint8 Lln, uint8 *PduPtr, uint8 PduLength, uint8 Sdu_MORE_BIT )
{
SDU_DATA_STRUCT XDATA *SduBufPtr;
  // Set SduDataP to current RX SDU data buffer at write index
#ifndef REMOTE_APPL      
//XDATA FPTR  pData2App;
#endif

#ifdef FT // Fixed part terminal
  SduBufPtr = &SduRxBuf[Lln].Sdu[SduRxBuf[Lln].Write & SDU_BUFF_MOD];
#else     // Portable part terminal
  SduBufPtr = &SduRxBuf[0].Sdu[SduRxBuf[0].Write & SDU_BUFF_MOD];
#endif 


  if((SduBufPtr->Length+PduLength)> SduRxBuf[Lln].MaxSduSize)
  {
    SduBufPtr->Length = 0; // delete
    return(0);
  }
   
   // ACK PDU
   if (PduLength == 0) {
      return( 0 );
   }

  // Copy PDU at position where last received PDU has ended.
  Mmu_Memcpy( &SduBufPtr->DataP[SduBufPtr->Length], PduPtr, PduLength);
  SduBufPtr->Length+= PduLength;
  if( Sdu_MORE_BIT != FU10_MORE_BIT )
  { // SDU complead
    //SDU header TODO
    SduRxBuf[Lln].Write++; // New write buffer
  }

#ifndef SDURX_POLLMODE
  if(SduRxBuf[Lln].Write != SduRxBuf[Lln].Read)  /* data avalable     */                    
  {
#ifdef FT // Fixed part terminal
    SduBufPtr = &SduRxBuf[Lln].Sdu[SduRxBuf[Lln].Read & SDU_BUFF_MOD];
    //if(0==Send_UPMessage_To_AppX(Lln,PduPtr->Length,SduDataP->DataP) )

      #if 0
      {
         BYTE i;
         printf("RX-SDU:");
         for (i=0;  i<SduBufPtr->Length;  i++) {
            printf("%02x", SduBufPtr->DataP[i]);
         }
         printf("[%04x]\n", SduBufPtr->Length);
      }
      #endif

    if(Send_UPMessage_To_APP(  FP_MEDIA_SDU_RCV_IN, SduBufPtr->DataP, Lln,
                           (uint8) (SduBufPtr->Length>>8),  (uint8) SduBufPtr->Length, 0 ,0 ))
    {
      DECT_DEBUG_LU10RX( "SDU to APP %1d %4d \r\n", Lln, SduBufPtr->Length, 0, 0 );
      SduBufPtr->Length = 0;
      SduRxBuf[Lln].Read++;
    }
#else // PT Portable part terminal
    SduBufPtr = &SduRxBuf[0].Sdu[SduRxBuf[0].Read & SDU_BUFF_MOD];
  #ifdef REMOTE_APPL      
    if(Send_Message_To_APP(  PP_MEDIA_SDU_RCV_IN, SduBufPtr->DataP, Lln,
                           (uint8) (SduBufPtr->Length>>8),  (uint8) SduBufPtr->Length, DUMMY_FILL ,DUMMY_FILL ))
    {
      SduBufPtr->Length = 0;
      SduRxBuf[Lln].Read++;
    }

  #else // no REMOTE_APPL
    #if  (UPLANE_LOOP == UPLANE_PTLOOP3)
    if(LU10SduTxGetPtr (0, &pData2App) >= 0)
    { 
      Mmu_Memcpy( pData2App, SduBufPtr->DataP, SduBufPtr->Length);
      LU10SduTx (0 , SduBufPtr->Length, &pData2App );
      SduBufPtr->Length = 0;
      SduRxBuf[Lln].Read++;
    }
    #else
    pData2App = Mmu_Malloc(SduBufPtr->Length);
    if ( pData2App == NULL )
    {
      return(0);
    }
    Mmu_Memcpy( pData2App, SduBufPtr->DataP, SduBufPtr->Length);
    if(Send_Message_To_APP(  PP_MEDIA_SDU_RCV_IN, pData2App, Lln,
                           (uint8) (SduBufPtr->Length>>8),  (uint8) SduBufPtr->Length, DUMMY_FILL ,DUMMY_FILL ))
    {
      DECT_DEBUG_LU10RX( "SDU to APP %1d %4d\r\n", Lln, SduBufPtr->Length, 0, 0 );
      SduBufPtr->Length = 0;
      SduRxBuf[Lln].Read++;
    }
    #endif
  #endif // REMOTE_APPL
#endif   // FT
  }
#endif

  return(PduLength);

}
#endif // CATIQ_UPLANE    

