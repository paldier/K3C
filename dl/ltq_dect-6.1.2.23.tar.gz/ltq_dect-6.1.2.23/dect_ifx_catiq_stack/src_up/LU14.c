/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0       *
*                   (c) 2005 IFX / INTNIX. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  LU14.c                                                  *
*     Date       :  06 May, 2013                                            *
*     Contents   :  Contents : Library for U-Plane DLC Layer SDU transmit/receive Functions.  *                                                                                                                                                                                                                                                               *
*     Hardware   :  IFX 97xx                                                *
*                                                                           *
*****************************************************************************
*/
   /* ========                                                             */
   /* Includes                                                             */
   /* ========                                                             */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "ifx_common_defs.h"
#include "DEFINE.H"                    /* Compiler switchs                 */
#include "SYSDEF.H"
#include "DECT_UP.H"
#include "DECT.H"
#include "LUFU10AC.H"
#include "MMU.H"
#include "CAT_UP.H"
#include "CONF_CP.H"
#include "uplane_if.h"
#include "MESSAGE_DEF.H"
#include "CP_SERVER.H"
#ifdef ULE_SUPPORT
#include "DSAA2.h"
#endif

#ifdef ULE_SUPPORT
   /* ==============                                                       */
   /* Local typedefs                                                       */
   /* ==============                                                       */
#define CCM_PACKET_NUMBER_SIZE 6
#define CCM_NONECE_LENGTH  13
#define CCM_MIC_LENGTH     4

   /* ===============                                                      */
   /* Local variables                                                      */
   /* ===============                                                      */

   /* ==========================                                           */
   /* Local function declaration                                           */
   /* ==========================                                           */

   /* ===========================                                          */
   /* Global function definitions                                          */
   /* ===========================                                          */

/*
*****************************************************************************
*                                                                           *
*   Function   :  CCM_Process                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  data encryption/decryption                                *
*   Parms      :  pNonce    : pointer to Nonce                              *
*                 nonceLen  : length of Nonce                               *
*                 pInData   : pointer to input data                         *
*                 pOutData  : pointer to output data                        *
*                 dataLen   : length of data                                *
*                 pHdr      : pointer to header data                        *
*                 hdrLen    : length of header                              *
*                 pMic      : pointer to Mic                                *
*                 micLen    : length of Mic                                 *
*                 micLen    : length of Mic                                 *
*                 isEncryption : is encryption or decryption                *
*                 ctx       : expanded chiper key                           *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
LOCAL BYTE
CCM_Process(FPTR pNonce,
                   BYTE nonceLen,
                   FPTR pInData,
                   FPTR pOutData,
                   WORD dataLen,
                   FPTR pHdr,
                   WORD hdrLen,
                   FPTR pMic,
                   BYTE micLen,
                   BYTE isEncryption,
                   aes_context ctx[1])
{
   BYTE iv[16], pad[16], ctr[16], ctr_pad[16], b;
   WORD x, y, z, ctr_len;
   BYTE val;

   /* calculate IV   */
   // message length octets = 2
   val = 2;

   nonceLen = ( nonceLen > 13 ) ? 13 : nonceLen;
   if( (15 - nonceLen) > val )
       val = 15 - nonceLen;
   if( (nonceLen + val) > 15 )
       nonceLen = 15 - val;

   x = 0;
   // IV first byte
   iv[x++] = ( (hdrLen > 0) ? (1 << 6) : 0 ) | ( ((micLen - 2) >> 1) << 3 ) | ( val - 1 );
   // IV nonce bytes
   for( y = 0; y < (16 - (val + 1)); y++ )
      iv[x++] = pNonce[y];

   // IV SDU length
   iv[x++] = ( dataLen >> 8 ) & 0xFF;
   iv[x++] = dataLen & 0xFF;

   // calculate X1
   if( !aes_encrypt(iv, pad, ctx) )
      return 0;

   /* additional info - calculate X2  */
   if( hdrLen > 0 ) {
      x = 0;
      pad[x++] ^= ( hdrLen >> 8 ) & 255;
      pad[x++] ^= hdrLen & 255;
      for( y = 0; y < hdrLen; y++ ) {
#ifdef KLOCWORK
         if( x >= 16 ) {
#else
         if( x == 16 ) {
#endif
            if( !aes_encrypt(pad, pad, ctx) )
               return 0;
            x = 0;
         }
#ifdef KLOCWORK
         //Nothing ToDo, (x<16)
#endif
         pad[x++] ^= pHdr[y];
      }
      if( x != 0 ) {
         if( !aes_encrypt(pad, pad, ctx) )
            return 0;
      }
   }

   /* calculate CTR   */
   x = 0;
   ctr[x++] = val - 1;
   for( y = 0; y < (16 - (val + 1)); ++y )
       ctr[x++] = pNonce[y];

   while( x < 16 )
       ctr[x++] = 0;

   /* Message authentication(X2orX3 ~ Xn) and encryption(S)  */
   x = 0;
   ctr_len = 16;
   if( dataLen > 0 ) {
      y = 0;
      for( ; y < dataLen; y++ ) {
#ifdef KLOCWORK
         if( ctr_len >= 16 ) {
#else
         if( ctr_len == 16 ) {
#endif
            for( z = 15; z > (15 - val); z-- ) {
               ctr[z] = ( ctr[z] + 1 ) & 255;
               if( ctr[z] )
                  break;
            }
            if( !aes_encrypt(ctr, ctr_pad, ctx) )
               return 0;
            ctr_len = 0;
         }
#ifdef KLOCWORK
           //Nothing ToDo, (ctr_len<16)
#endif
         if( isEncryption ) {
            b = pInData[y];
            pOutData[y] = b ^ ctr_pad[ctr_len++];
         } else {
            b = pInData[y] ^ ctr_pad[ctr_len++];
            pOutData[y] = b;
         }
#ifdef KLOCWORK
         if( x >= 16 ) {
#else
         if( x == 16 ) {
#endif
            if( !aes_encrypt(pad, pad, ctx) )
               return 0;
            x = 0;
         }
#ifdef KLOCWORK
          //Nothing ToDo, (x<16)
#endif
         pad[x++] ^= b;
      }
      if( x != 0 )
         if( !aes_encrypt(pad, pad, ctx) )
            return 0;
   }
   for( y = 15; y > (15 - val); y-- )
      ctr[y] = 0;

   if( !aes_encrypt(ctr, ctr_pad, ctx) )
      return 0;

   if( isEncryption ) {
      for( x = 0; x < micLen; x++ )
         pMic[x] = pad[x] ^ ctr_pad[x];
   } else {
      for( x = 0; x < micLen; x++ )
         pad[x] ^= ctr_pad[x];
      if ( !Mmu_Memcmp(pad, pMic, micLen) )
         return 0;
   }
   return 1;
}

LOCAL void
Construct_CCM_Nonce(BYTE * noncePtr, BYTE * pmidPtr, BYTE * rfpiPtr, BYTE * snPtr, BYTE direction)
{
   BYTE pos=0;

   /* reserved byte    */
   noncePtr[pos++] = 0x00;
   /* PAcket number : DLC SN of PDUs  */
   Mmu_Memcpy(&noncePtr[pos], snPtr, CCM_PACKET_NUMBER_SIZE);
   pos += CCM_PACKET_NUMBER_SIZE;
   /* PARI : lease significant 12bits, PMID : 20bits   */
   noncePtr[pos++] = ((rfpiPtr[3] & 0x7F) << 1) | ((rfpiPtr[4] & 0x80) >> 7);
   noncePtr[pos++] = ((rfpiPtr[4] & 0x78) << 1) | (pmidPtr[0] & 0x0F);
   noncePtr[pos++] = pmidPtr[1];
   noncePtr[pos++] = pmidPtr[2];
   /* ECN: ULE=0x07 NORMAL=0x05, FP->PP:0 PP->FP:1   */
   noncePtr[pos++] = ((direction & 0x01) << 7) | 0x07;
   /* fixed byte    */
   noncePtr[pos++] = 0x00;
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  LU14SduEncrytion                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  SDU data encryption                                       *
*   Parms      :  po_no   : Portable number                                 *
*                 DataLen : Length of input data                            *
*                 InP     : Pointer to input data                           *
*                 OutP    : Pointer to output data                          *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT BYTE 
ULE_Lu14SduEncryption(BYTE * keyPtr , BYTE * pmidPtr, BYTE * rfpiPtr, BYTE * snPtr, WORD dataLength, FPTR inPtr, FPTR outPtr)
{
   aes_context ctx[1];
   BYTE XDATA nonce[13];

   if (dataLength == 0) {
      return 0;
   }

   /* expand key  */
   aes_set_key(keyPtr, 16, ctx);

   /* construct CCM nonce   */
   Construct_CCM_Nonce(nonce, pmidPtr, rfpiPtr, snPtr, 0);
   if ( !CCM_Process(nonce,
                     CCM_NONECE_LENGTH,
                     inPtr,
                     outPtr,
                     dataLength,
                     NULL,
                     0,
                     &outPtr[dataLength],
                     CCM_MIC_LENGTH,
                     TRUE,
                     ctx)) {
      return 0;
   }          
   return 1;
}

/*
*****************************************************************************
*                                                                           *
*   Function   :  LU14SduDecrytion                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*   Purpose    :  SDU data Decryption                                       *
*   Parms      :  po_no   : Portable number                                 *
*                 DataLen : Length of input data                            *
*                 InP     : Pointer to input data                           *
*                 OutP    : Pointer to output data                          *
*   Returns    :  none                                                      *
*   Call Level :  Process Level                                             *
*   Remarks    :                                                            *
*                                                                           *
*****************************************************************************
*/
EXPORT BYTE 
ULE_Lu14SduDecryption(BYTE * keyPtr , BYTE * pmidPtr, BYTE * rfpiPtr, BYTE * snPtr, WORD dataLength, FPTR inPtr, FPTR outPtr)
{
   aes_context ctx[1];
   BYTE XDATA nonce[13];

   if (dataLength <= CCM_MIC_LENGTH) {
      return 0;
   }

   aes_set_key(keyPtr, 16, ctx);

   /* construct CCM nonce   */
   Construct_CCM_Nonce(nonce, pmidPtr, rfpiPtr, snPtr, 1);
   if ( !CCM_Process(nonce,
                     CCM_NONECE_LENGTH,
                     inPtr,
                     outPtr,
                     dataLength-CCM_MIC_LENGTH,
                     NULL,
                     0,
                     &inPtr[dataLength-CCM_MIC_LENGTH],
                     CCM_MIC_LENGTH,
                     FALSE,
                     ctx)) {
      return 0;
   }          
   return 1;
}
#endif
