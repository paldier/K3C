#ifdef CATIQ_UPLANE
/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V9.0       *
*                   (c) 2008 IFX / Peucon. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  LU10INI.C                                               *
*     Date       :  5 August, 2008                                          *
*     Contents   :  U-Plane init funktion .                                 *
*     Hardware   :  IFX 97xx                                                *
*                                                                           *
*---------------------------------------------------------------------------*
* Change History:                                                           *
*                                                                           *
* Date         Author Description                                           *
* 10-Jul-2008  U.P.   Initial version                                       *
* 05-Aug-2008  C.S.   Coding for IWU Attributes and Call Attributes added   *
*****************************************************************************
*/
/** \file
 *   \brief Init functions for UPlane and call attribute handling
 */
 #include "ifx_common_defs.h"
#include "DEFINE.H"                    /* Compiler switchs                 */
#include "SYSDEF.H"
#include "CC_DEF.H"
#include "DECT_UP.H"
#include "DECT.H"
#include "CAT_UP.H"
#ifdef FT
#include "CONF_CP.H"
#include "uplane_if.h"
#else
#include "TYPEDEF.H"
#include "MMU.H"
#include "TYPEDEF_CP.H"
#include "PMAC_LIB.H"
#endif

#include "DEBUG_UP.H"


extern FPTR
Mmu_Realloc( FPTR realloc_ptr, WORD word_size );

   /* ===============                                                      */
   /* Global variables                                                     */
   /* ===============                                                      */


   /* ===============                                                      */
   /* Local variables                                                      */
   /* ===============                                                      */

EXPORT XDATA BYTE StateUPlane[DLC_U_LLN_MAX];  //!< Array with current link states
EXPORT XDATA BYTE FU10Method[DLC_U_LLN_MAX];    //!< Algorithm of FU10 Protocol

   /* ===========================                                          */
   /* Local function declarations                                          */
   /* ===========================                                          */

   /* ===================                                                  */
   /* Function Definition                                                  */
   /* ===================                                                  */
#define EXTB  0x80  //!< Extension bit

/*
*****************************************************************************
*                                                                           *
*     Function :  InitUPlane                                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  General initialization of LU10 U-Plane                    *
*     Parms    :  none                                                      *
*     Returns  :  none                                                      *
*     Remarks  :  Is part of application library                            *
*     Called by: <TODO>                                                     *
*                                                                           *
*****************************************************************************
*/
EXPORT void
InitUPlane ( void )
{
  BYTE XDATA LlnCount;

  for(LlnCount= 0; LlnCount < DLC_U_LLN_MAX; LlnCount++)
  {
    StateUPlane[LlnCount] = UPCON_IDLE;
#ifdef CATIQ_UPLANE_NOT_JET
    InitFU10PduTx( LlnCount ); // Init FU10 Frame PDU TX Buffer
    InitFU10PduRx( LlnCount ); // Init FU10 Frame PDU RX Buffer
    InitLU10SduTx( LlnCount ); // Init LU10 SDU TX Buffer
    InitLU10SduRx( LlnCount ); // Init LU10 SDU TX Buffer
#endif
  }

  INIT_PORT_DEBUG
  DECT_DEBUG_LU10TX(" and RX Init Mem",0,0,0,0);

}
/*
*****************************************************************************
*                                                                           *
*     Function :  InitLlnUPlane                                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  General initialization of LU10 U-Plane                    *
*     Parms    :  none                                                      *
*     Returns  :  none                                                      *
*     Remarks  :  Is part of application library                            *
*     Called by: <TODO>                                                     *
*                                                                           *
*****************************************************************************
*/
EXPORT void
InitLlnUPlane (  uint8 Lln  )
{

  if(Lln >= DLC_U_LLN_MAX)
  {
    return;
  }
#ifdef PT
  if(( System_Info.Rx_QC_Long_Slot == 0)||( System_Info.Rx_Q4_DPRS == 0))
  { // QT no a12:long slot(j=640), Extended Physical and MAC layer capabilities
    DECT_DEBUG_LU10TX(" and RX No DPRS FP ",0,0,0,0);
    return;
  }
#endif

  DECT_DEBUG_LU10TX(" and RX Lln Init %1",Lln,0,0,0);

  InitFU10PduRx( Lln ); // Init FU10 Frame PDU RX Buffer
  InitFU10PduTx( Lln ); // Init FU10 Frame PDU TX Buffer
  InitLU10SduRx( Lln ); // Init LU10 SDU TX Buffer
  InitLU10SduTx( Lln ); // Init LU10 SDU TX Buffer
  StateUPlane[Lln] = UPCON_ACTIV;

}

/*
*****************************************************************************
*                                                                           *
*     Function :  DeInitLlnUPlane                                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  General initialization of LU10 U-Plane                    *
*     Parms    :  none                                                      *
*     Returns  :  none                                                      *
*     Remarks  :  Is part of application library                            *
*     Called by: <TODO>                                                     *
*                                                                           *
*****************************************************************************
*/
EXPORT void
DeInitLlnUPlane (  uint8 Lln  )
{

  if(Lln >= DLC_U_LLN_MAX)
  {
    return;
  }

  if(StateUPlane[Lln] == UPCON_IDLE)
  {
    DECT_DEBUG_LU10TX(" and RX Lln not init %1",Lln,0,0,0);
    return;
  }

  DECT_DEBUG_LU10TX(" and RX Lln DeInit %1",Lln,0,0,0);

  StateUPlane[Lln] = UPCON_IDLE;
  DeInitFU10PduTx( Lln ); // Init FU10 Frame PDU TX Buffer
  DeInitFU10PduRx( Lln ); // Init FU10 Frame PDU RX Buffer
  DeInitLU10SduTx( Lln ); // Init LU10 SDU TX Buffer
  DeInitLU10SduRx( Lln ); // Init LU10 SDU TX Buffer

}
/*
*****************************************************************************
*                                                                           *
*     Function :  GetStateUPlane                                            *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  get State of connection  LU10 U-Plane                     *
*     Parms    :  Lln                                                       *
*     Returns  :  State                                                     *
*     Remarks  :  Is part of application library                            *
*     Called by: <TODO>                                                     *
*                                                                           *
*****************************************************************************
*/
EXPORT uint8
GetStateUPlane (  uint8 Lln  )
{

  if(Lln >= DLC_U_LLN_MAX)
  {
    return(0);
  }
  return(StateUPlane[Lln]);

  DECT_DEBUG_LU10TX(" and RX Lln %1 State %1 ",Lln,StateUPlane[Lln],0,0);
}

EXPORT void
Set_FU10_Method (uint8 Lln, uint8 Method)
{

   if(Lln >= DLC_U_LLN_MAX) {
      return;
   }

   if (Method == 0) {
      FU10Method[ Lln ] = SUOTA_V1_1_1;
      DECT_DEBUG_UPLANE("SUOTA Version 1.1.1 is supported.\n");
   } else {
      FU10Method[ Lln ] = SUOTA_V1_3_1;
      DECT_DEBUG_UPLANE("SUOTA Version 1.3.1 is supported.\n");
   }
}

/*
*****************************************************************************
*                                                                           *
*     Function :  GetIWU_ATTRIBUTES                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Retrieves predefined values for IWU attributes IE         *
*                 (EN 300 175-5 7.7.21 InterWorking Unit (IWU) attributes)  *
*                 and fills IE array specified by input parameter InfoPtr   *
*     Parms    :  Input: Pointer of the IWU Attributes IE array             *
*     Returns  :  none                                                      *
*     Remarks  :  The coding values refer to document Ref [2]               *
*                 "Proposal for software upgrade over the air (SUOTA),      *
*                 Default setup attributes for light data service, Table E3 *
*                 and EN 301 349, table 81
*                 Is part of application library                            *
*     Called by: <TODO>                                                     *
*                                                                           *
*****************************************************************************
*/
EXPORT FPTR
GetIWU_ATTRIBUTES ( FPTR frame_ptr )
{   // Octet Information element field Field			Value
  BYTE current_pos;
  #ifdef KLOCWORK
  FPTR temp_ptr;
  #endif
  current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
  #ifdef KLOCWORK
  temp_ptr   = (FPTR)Mmu_Realloc( frame_ptr, current_pos + 7 );
  if( temp_ptr == NULL ) {
   return(frame_ptr);
  } else {
   frame_ptr = temp_ptr;
  }
  #else
  frame_ptr   = (FPTR)Mmu_Realloc( frame_ptr, current_pos + 7 );
  #endif
//-------------------------------------------------------------------------------------------------------------
  frame_ptr[current_pos++] = IWU_ATTRIBUTES;	// 1     Element ID, EN 300 175-5 Table 76			0x12
  frame_ptr[current_pos++] = 5;         // 2     Length     0x05 bytes
  frame_ptr[current_pos++] = 0xA0;      // 3     Coding standard, bits 1					1 = Fixed value
                          // 3     Coding standard, bits 7, 6					01 = Profile defined code
                          // 3     Profile, bits 5 - 1                    	00000 = DPRS: Frame Relay services
  frame_ptr[current_pos++] = 0x88;      // 4     Coding standard, bits 1					1 = Fixed value
                          // 4   Negotiation indicator, bits 7 -5			000 = Not Possible
                          // 4     Profile Subtype, bits 4 - 1			    1000 = DECT Generic Media Encapsulation
  frame_ptr[current_pos++] = (((uint8)(SDU_LEN_MAX>>7))&0x7F)|0x80;
                          // 5     Maximum SDU size (Most significant 7 bits)   = bit 8 = 1, bits 7 - 1 = bits 14 - 8 of SDU_LEN_MAX
  frame_ptr[current_pos++] = (((uint8)(SDU_LEN_MAX>>0))&0x7F)|0x80;
                          // 5a    Maximum SDU size (Least significant 7 bits)  = bit 8 = 1, bits 7 - 1 = bits 7 - 1 of SDU_LEN_MAX
  frame_ptr[current_pos++] = 0x80;      // 6     Profile subtype attributes, bitmap 	xxxxxx1 = HTTP supported (as specified in DPRS clause B.8.3.1)


  (( struct HLI_Header * ) frame_ptr ) -> length = current_pos;
  return(frame_ptr);

}


#ifdef CATIQ_UPLANE_NO_JET
/*
*****************************************************************************
*                                                                           *
*     Function :  SetIWU_ATTRIBUTES                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Sets the local variable max SDU size concerning           *
*                 IWU-Atrributes IE octet 5 and 5a, specified by input      *
*                 parameter InfoPtr.                                        *
*                 Validates max SDU size against possible PDU length for    *
*                 B_FIELD_PLONG_SLOT multiplied with possible number of PDU *
*                 in SDU.                                                   *
*     Parms    :  Locigal link number, Lln                                  *
*              :  Input: Pointer of the IWU Attributes IE array             *
*     Returns  :  0 if max SDU size is larger then possible values.         *                                                     *
*     Remarks  :  The coding values refer to document Ref [2]               *
*                 "Proposal for software upgrade over the air (SUOTA),      *
*                 Default setup attributes for light data service, Table E3 *
*                 Is part of application library                            *
*     Called by: <TODO>                                                     *
*                                                                           *
*****************************************************************************
*/
EXPORT uint8
CheckIWU_ATTRIBUTES ( uint8 Lln, FPTR InfoPtr )
{
  if( InfoPtr == NULL )
      return( 0xFF );

  uint16 XDATA SduSize; // Maximum SDU size is 14 bits long

  SduSize = (InfoPtr[4]&0x3F); // Retrieving Maximum SDU size (Most significant 7 bits)
                               // mask is 0011 1111
  SduSize = (SduSize<<7)|(InfoPtr[5]&0x3F); // Adding Maximum SDU size (Least significant 7 bits)

  if(SduSize > SDU_LEN_MAX)
  { // Size to long
    return(0);
  }

  return(1);

}
#endif

/*
*****************************************************************************
*                                                                           *
*     Function :  GetCALL_ATTRIBUTES                                        *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Retrieves predefined values for Call attributes IE        *
*                 (EN 300 175-5 7.7.5 Call Attributes)                      *
*                 and fills IE array specified by input parameter InfoPtr   *
*                                                                           *
*     Parms    :  Input: Pointer of the Call Attributes IE array            *
*     Returns  :  none                                                      *
*     Remarks  :  The coding values refer to document Ref [2]               *
*                 "Proposal for software upgrade over the air (SUOTA),      *
*                 Default setup attributes for light data service, Table E4 *
*                 Octets 5a and 6a are not present because U-plane symmetry *
*                 is set to symmetric - same number of bearer in up- and    *
*                 downlink.                                                 *
*                 Is part of application library                            *
*     Called by: <TODO>                                                     *
*****************************************************************************
*/
EXPORT FPTR
GetCALL_ATTRIBUTES ( FPTR frame_ptr )
{                               // Octet Information element field Field			Value
  BYTE current_pos;
  #ifdef KLOCWORK
  FPTR temp_ptr;
  #endif
  current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
  #ifdef KLOCWORK
  temp_ptr   = (FPTR)Mmu_Realloc( frame_ptr, current_pos + 6 );
  if( temp_ptr == NULL ) {
   return(frame_ptr);
  } else {
   frame_ptr = temp_ptr;
  }
  #else
  frame_ptr   = (FPTR)Mmu_Realloc( frame_ptr, current_pos + 6 );
  #endif
//-------------------------------------------------------------------------------------------------------------
  frame_ptr[current_pos++] = CALL_ATTRIBUTES; // 1     Element ID, EN 300 175-5 Table 76			0x13
  frame_ptr[current_pos++] = 4;               // 2     Length                                     0x04 Bytes
  frame_ptr[current_pos++] = 0x82;            // 3     Bit 8										1 = Fixed value
                                // 3     Coding standard, bits 7, 6 				00 = DECT standard
                                // 3     Network layer attributes bits 5 - 1        00010 = DPRS
  frame_ptr[current_pos++] = 0xA0;            // 4     Bit 8										1 = Fixed value
                                // 4     C-plane class, bits 7 - 5					010 = Class A Link; shared
                                // 4     C-plane routing, bits 4 - 1                0000 = Cs only
  frame_ptr[current_pos++] = 0x8A;            // 5     Bit 8										Don't care, here set to 1
                                // 5     U-plane symmetry, bits 7, 6                00 = Symmetric
                                // 5     LU identification, bits 5 - 1              01010 = LU10
  frame_ptr[current_pos++] = 0xCA;            // 6     Bit 8										Don't care, here set to 1
                                // 6     U-plane class, bits 7 - 5                  100 = Class 2; Go_Back_N
                                // 6     U-plane frame type, bits 4 - 1             1010 = FU10a/c
  (( struct HLI_Header * ) frame_ptr ) -> length = current_pos;

  return(frame_ptr);
}

#ifdef CATIQ_UPLANE_NO_JET
/*
*****************************************************************************
*                                                                           *
*     Function :  SetCALL_ATTRIBUTES                                        *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Checks the length of Call Attributes (Octet 2) specified  *
*                 by input parameter InfoPtr.                               *
*     Parms    :  Locigal link number, Lln                                  *
*              :  Input: Pointer of the IWU Attributes IE array             *
*     Returns  :  0 if IE length not equal to 4 bytes                       *
*     Remarks  :  none                                                      *
*     Called by: <TODO>                                                     *
*                                                                           *
*****************************************************************************
*/
EXPORT uint8
CheckCALL_ATTRIBUTES (  uint8 Lln, FPTR InfoPtr )
{
  if( InfoPtr == NULL )
      return( 0xFF );

  if(InfoPtr[1] != 4)
  {
    return(0);
  }
  return(1);
}
#endif

/*
*****************************************************************************
*                                                                           *
*     Function :  GetCONNECTION_ATTRIBUTES                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Retrieves predefined values for Connection attributes IE  *
*                 (EN 300 175-5 7.7.5 Call Attributes)                      *
*                 and fills IE array specified by input parameter InfoPtr   *
*                                                                           *
*     Parms    :  Input: Pointer of the Call Attributes IE array            *
*     Returns  :  none                                                      *
*     Remarks  :  The coding values refer to document Ref [2]               *
*                 "Proposal for software upgrade over the air (SUOTA),      *
*                 Default setup attributes for light data service, Table E4 *
*                 Octets 5a and 6a are not present because U-plane symmetry *
*                 is set to symmetric - same number of bearer in up- and    *
*                 downlink.                                                 *
*                 Is part of application library                            *
*     Called by: <TODO>                                                     *
*****************************************************************************
*/
EXPORT FPTR
GetCONNECTION_ATTRIBUTES ( FPTR frame_ptr )
{                               // Octet Information element field Field			Value
  BYTE current_pos;
  #ifdef KLOCWORK
  FPTR temp_ptr;
  #endif
  current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
  #ifdef KLOCWORK
  temp_ptr   = (FPTR)Mmu_Realloc( frame_ptr, current_pos + 12 );
  if( temp_ptr == NULL ) {
   return(frame_ptr);
  } else {
   frame_ptr = temp_ptr;
  }
  #else
  frame_ptr   = (FPTR)Mmu_Realloc( frame_ptr, current_pos + 12 );
  #endif
//-------------------------------------------------------------------------------------------------------------
  frame_ptr[current_pos++] = CONNECTION_ATTRIBUTES; // 1     Element ID, EN 300 175-5 Table 76			0x17
  frame_ptr[current_pos++] = 0x0a;                  // 2     Length                                     0x04 Bytes

  frame_ptr[current_pos++] = 0x90; // 3 < Symmetry > Symmetric only connection < Connection identity >Unknown
  frame_ptr[current_pos++] = 0x01; // 4 < Maximum bearers P=>F direction > 1
  frame_ptr[current_pos++] = 0x21; // 4a< Minimum bearers P=>F direction > 1
  frame_ptr[current_pos++] = 0x41; // 4b< Maximum bearers F=>P direction > 1
  frame_ptr[current_pos++] = 0xE1; // 4c< Minimum bearers F=>P direction > 1
  frame_ptr[current_pos++] = 0x12; // 5 < Slot type> Long slot; j = 640 < MAC service P => F >IPM; (IP error detect, multisubfield)
  frame_ptr[current_pos++] = 0x92; // 5a< MAC service F => P >IPM; (IP error detect, multisubfield)
  frame_ptr[current_pos++] = 0x00; // 6 < CF-channel attributes P => F > CF never (CS only) < MAC packet life time P => F >Not applicable
  frame_ptr[current_pos++] = 0x80; // 6a< CF-channel attributes F => P> CF never (CS only) < MAC packet life time F => P> Not applicable
  frame_ptr[current_pos++] = 0x80; // 7 < A attributes > 2-level < B attributes >2-level

  (( struct HLI_Header * ) frame_ptr ) -> length = current_pos;

  return(frame_ptr);
}

#ifdef CATIQ_UPLANE_NO_JET
/*
*****************************************************************************
*                                                                           *
*     Function :  SetCONNECTION_ATTRIBUTES                                        *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Checks the length of Call Attributes (Octet 2) specified  *
*                 by input parameter InfoPtr.                               *
*     Parms    :  Locigal link number, Lln                                  *
*              :  Input: Pointer of the IWU Attributes IE array             *
*     Returns  :  0 if IE length not equal to 4 bytes                       *
*     Remarks  :  none                                                      *
*     Called by: <TODO>                                                     *
*                                                                           *
*****************************************************************************
*/
EXPORT uint8
CheckCONNECTION_ATTRIBUTES (  uint8 Lln,FPTR InfoPtr )
{
  if( InfoPtr == NULL )
      return( 0xFF );

  if(InfoPtr[1] != 4)
  {
    return(0);
  }
  return(1);
}
#endif
/*
*****************************************************************************
*                                                                           *
*     Function :  GetTRANSIT_DELAY                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Retrieves predefined values for Connection attributes IE  *
*                 (EN 300 175-5 7.7.42 ransit delay)                        *
*                 and fills IE array specified by input parameter InfoPtr   *
*                                                                           *
*     Parms    :  Input: Pointer of the Transit delay IE array              *
*     Returns  :  none                                                      *
*     Remarks  :  The coding values refer to document Ref [2]               *
*                 Is part of application library                            *
*     Called by: <TODO>                                                     *
*****************************************************************************
*/
EXPORT FPTR
GetTRANSIT_DELAY ( FPTR frame_ptr )
{                               // Octet Information element field Field			Value
  BYTE current_pos;
  #ifdef KLOCWORK
  FPTR temp_ptr;
  #endif
  current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
  #ifdef KLOCWORK
  temp_ptr   = (FPTR)Mmu_Realloc( frame_ptr, current_pos + 4 );
  if( temp_ptr == NULL ) {
   return(frame_ptr);
  } else {
   frame_ptr = temp_ptr;
  }
  #else
  frame_ptr   = (FPTR)Mmu_Realloc( frame_ptr, current_pos + 4 );
  #endif
//-------------------------------------------------------------------------------------------------------------
  frame_ptr[current_pos++] = TRANSIT_DELAY; // 1     Element ID, EN 300 175-5 Table 76			0x66
  frame_ptr[current_pos++] = 0x02;          // 2     Length                                     0x04 Bytes

  frame_ptr[current_pos++] = 0x80; // 3 Forward Delay
  frame_ptr[current_pos++] = 0x80; // 4 Backward Delay

  (( struct HLI_Header * ) frame_ptr ) -> length = current_pos;

  return(frame_ptr);
}

#ifdef CATIQ_UPLANE_NO_JET
/*
*****************************************************************************
*                                                                           *
*     Function :  SetTRANSIT_DELAY                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Checks the length of Call Attributes (Octet 2) specified  *
*                 by input parameter InfoPtr.                               *
*     Parms    :  Locigal link number, Lln                                  *
*              :  Input: Pointer of the IWU Attributes IE array             *
*     Returns  :  0 if IE length not equal to 4 bytes                       *
*     Remarks  :  none                                                      *
*     Called by: <TODO>                                                     *
*                                                                           *
*****************************************************************************
*/
EXPORT uint8
CheckTRANSIT_DELAY (  uint8 Lln,FPTR InfoPtr )
{
  if( InfoPtr == NULL )
      return( 0xFF );

  if(InfoPtr[1] != 4)
  {
    return(0);
  }
  return(1);
}
#endif
/*
*****************************************************************************
*                                                                           *
*     Function :  GetWINDOW_SIZE                                            *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Retrieves predefined values for Connection attributes IE  *
*                 (EN 300 175-5 7.7.43 Window size)                         *
*                 and fills IE array specified by input parameter InfoPtr   *
*                                                                           *
*     Parms    :  Input: Pointer of the Window size IE array                *
*     Returns  :  none                                                      *
*     Remarks  :  The coding values refer to document Ref [2]               *
*                 Is part of application library                            *
*     Called by: <TODO>                                                     *
*****************************************************************************
*/
EXPORT FPTR
GetWINDOW_SIZE ( FPTR frame_ptr )
{                               // Octet Information element field Field			Value
  BYTE current_pos;
  #ifdef KLOCWORK
  FPTR temp_ptr;
  #endif
  current_pos = (( struct HLI_Header * ) frame_ptr ) -> length;
  #ifdef KLOCWORK
  temp_ptr   = (FPTR)Mmu_Realloc( frame_ptr, current_pos + 8 );
  if( temp_ptr == NULL ) {
   return(frame_ptr);
  } else {
   frame_ptr = temp_ptr;
  }
  #else
  frame_ptr   = (FPTR)Mmu_Realloc( frame_ptr, current_pos + 8 );
  #endif
//-------------------------------------------------------------------------------------------------------------
  frame_ptr[current_pos++] = WINDOW_SIZE; // 1     Element ID, EN 300 175-5 Table 76 0x67
  frame_ptr[current_pos++] = 0x06;        // 2     Length                                     0x04 Bytes

  frame_ptr[current_pos++] = EXTB|FU10_WINDOW_SIZE; // 0 Window size value (forward) 3
                                                    // 0/1 ext Window size value continue 3a
  frame_ptr[current_pos++] = EXTB|PDU_LEN;          // 0/1 ext Maximum PDU length (forward) 3b
  frame_ptr[current_pos++] = EXTB|SDU_LIFE_TIME;    // 1 SDU LAPU timer (forward) 3c

  frame_ptr[current_pos++] = EXTB|FU10_WINDOW_SIZE; // 0 Window size value (backward) 4
                                                    // 0/1 ext Window size value (continue) 4a
  frame_ptr[current_pos++] = EXTB|PDU_LEN;          // 0/1 ext Maximum PDU length (backward) 4b
  frame_ptr[current_pos++] = EXTB|SDU_LIFE_TIME;    // 1 SDU LAPU timer (backward) 4c

  (( struct HLI_Header * ) frame_ptr ) -> length = current_pos;

  return(frame_ptr);
}

#ifdef CATIQ_UPLANE_NO_JET
/*
*****************************************************************************
*                                                                           *
*     Function :  SetWINDOW_SIZE                                            *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Checks the length of Window size specified                *
*                 by input parameter InfoPtr.                               *
*     Parms    :  Locigal link number, Lln                                  *
*              :  Input: Pointer of the IWU Window size array               *
*     Returns  :  0 if IE length not equal to 4 bytes                       *
*     Remarks  :  none                                                      *
*     Called by: <TODO>                                                     *
*                                                                           *
*****************************************************************************
*/
EXPORT uint8
CheckWINDOW_SIZE (  uint8 Lln,FPTR InfoPtr )
{
  if( InfoPtr == NULL )
      return( 0xFF );

  if(InfoPtr[1] != 4)
  {
    return(0);
  }
  return(1);
}
#endif

#ifdef PT
/*
*****************************************************************************
*                                                                           *
*     Function :  GetMacDataATTRIBUTES                                      *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :                                                            *
*                                                                           *
*     Parms    :                                                            *
*              :                                                            *
*     Returns  :                                                            *
*     Remarks  :  none                                                      *
*     Called by: <TODO>                                                     *
*                                                                           *
*****************************************************************************
*/
EXPORT uint8
GetMacDataATTRIBUTES ( FPTR MtInfoPtr )
{
  if( MtInfoPtr == NULL )
  {
    return( 0 );
  }
                                         /* ECN(a16..a19): 0000           */
                                         /* LBN (a20..a23): 1111          */
  MtInfoPtr[2] = 0x0F;

                                          /* up/down/sm/ss(a24..a25): Symetric single(11)       */
                                          /* max life (a29..a31):no life time(000)              */
  if(( System_Info.Rx_QC_Long_Slot == 0)||( System_Info.Rx_Q4_DPRS == 0))
  {
                                          /* Ser type(a26..a28):IN voice(000)                   */
    MtInfoPtr[3] = MT_ATTRIBUTES_SYM_SING_CONNECTION|MT_ATTRIBUTES_INA_DELAY_TYPE;
  }
  else
  {
                                          /* Ser type(a26..a28):IPM                             */
    MtInfoPtr[3] = MT_ATTRIBUTES_SYM_SING_CONNECTION|MT_ATTRIBUTES_IPM_PROTECT_TYPE;
  }

                                          /* Slot type(a32..a35):full slot;(0000)               */
                                          /* Cf support(a36):not support CF(0)                  */
                                          /* Spare(a37..a39):rsv(111)   */
  if( System_Info.Rx_QC_Long_Slot == 0)
  {
    MtInfoPtr[4] = (MT_ATTRIBUTES_SLOT_TYPE_FULL<<4)|0x07;
  }
  else
  {
                                          /* long slot;j=640(0011)       */
    MtInfoPtr[4] = (MT_ATTRIBUTES_SLOT_TYPE_LONG<<4)|0x07;
  }
                                          /* Adpative code rate/Spare(a40..a43):no coding(0000) */
                                          /* Afield modulation type(a44..a45): 2-level(11)      */
                                          /* (B+Z)field modulation type(a46..a47): 2-level(11)  */
  MtInfoPtr[5] = 0x0F;

  return( 1 );
}
#endif
#endif // #ifdef CATIQ

