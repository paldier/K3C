#ifdef CATIQ_UPLANE    
/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V9.0       *
*                   (c) 2008 IFX / Peucon. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  FU10ACTX.C                                              *
*     Date       :  8 August, 2008                                          *
*     Contents   :  U-Plane DLC Layer PDU transmit Functions.               *
*     Hardware   :  IFX 97xx                                                *
*                                                                           *
*---------------------------------------------------------------------------*
* Change History:                                                           *
*                                                                           *
* Date         Author Description                                           *
* 10-Jul-2008  U.P.   Initial version                                       *
* 06-Aug-2008  C.S.   Additional comments                                   *
* 08-Aug-2008  C.S.   Variable RelatedSDU added to CopySdu2Pdu for handling *
*                     of SDU life time                                      *
*                     InitFU10PduTx extended with PDU life time             *
*****************************************************************************
*/
/** \file
 *  \brief LU10 PDU TX handling
 */ 
#include "ifx_common_defs.h"
#include "DEFINE.H"                    /* Compiler switchs                 */
#include "SYSDEF.H"
#ifdef FT
#include "CONF_CP.H"
#include "uplane_if.h"
#else
//#include "PMBC.H"
#endif
#include "DECT_UP.H"
#include "DECT.H"
#include "CAT_UP.H"
#include "LUFU10AC.H"
#include "MMU.H"


   /* ===============                                                      */
   /* Global variables                                                     */
   /* ===============                                                      */
IMPORT XDATA BYTE FU10Method[DLC_U_LLN_MAX];    //!< Algorithm of FU10 Protocol

IMPORT int8         CopySdu2Pdu (uint8 Lln, FPTR PduDataPtr, uint8 AvailableSpace,uint8 *Sdu_MOER_BIT);
IMPORT int8         CheckSdu2Pdu   (uint8 Lln);
IMPORT uint8        FU10PduRxAck    (uint8 Lln, FPTR PduDataPtr , uint8 UpDate );
IMPORT uint8        FU10PduRxAckV131    (uint8 Lln, FPTR PduDataPtr , uint8 UpDate );
IMPORT uint8        FU10PduRxAck2   (uint8 Lln, FPTR PduDataPtr );
IMPORT void         FU10UpdateLifeTimeRxBuffer (uint8 Decrement);
IMPORT void         FU10UpdateRxBufferSSN (uint8 Lln, uint8 SSN);

   /* ===============                                                      */
   /* Local variables                                                      */
   /* ===============                                                      */
// Number of PDU TX Buffers per logical links (LLN)
LOCAL PDU_BUFFER_STRUCT XDATA PduTxBuf[DLC_U_LLN_MAX];
// PDU data arrays for each PDU TX buffer (PDU_BUFF_MAX) of PDU length (PDU_LEN)
LOCAL uint8             XDATA PduTxMem[DLC_U_LLN_MAX][PDU_BUFF_MAX][PDU_LEN];
// Ack PDU data arrays
LOCAL uint8             XDATA PduTxAckMem[DLC_U_LLN_MAX][PDU_LEN];

LOCAL uint8             XDATA NULLPdu[ PDU_LEN ];
// Sync PDU data arrays
//LOCAL uint8             XDATA PduTxSyncMem[PDU_BUFF_MAX][PDU_LEN];
   
   /* ===========================                                          */
   /* Local function declarations                                          */
   /* ===========================                                          */

   /* ===================                                                  */
   /* Function Definition                                                  */
   /* ===================                                                  */

/*
*****************************************************************************
*                                                                           *
*     Function :  InitFU10PduTx                                             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Initialisation of the PDU TX buffer number 0              *
*     Parms    :  Locigal link number, Lln                                  *
*                 Local(static): PduTxBuf[0]                                *
*                 Local(static): PduTxMem[0] and PduTxMem[1]                *
*     Returns  :  Local(static): PduTxBuf[0]                                *
*                 Local(static): PduTxMem[0] and PduTxMem[1]                *
*     Remarks  :  For PDU_WIN_SIZE = 0x10 and after initialisation          *
*                 We have 1 PDU TX Buffer ([0]) buffering 16 PDUs ([0]-[15] *
*                 The 16 PDUs are PduTxMem 0 - 15                           *
*                                                                           *
*                 FU10 PDU TX Buffer (struct) is composed of                *
*                 Window:            PDU Window Counter                     *
*                 SSN:               Send sequence Number N(S)              *
*                 RSN:               Read = Receive sequence Number N(R)    *
*                 NAckCount:         Number of negative acknowledged PDUs   *
*                 AckReqCount:       Number of PDUs requested to be         *
*                                    acknowledged                           *
*                 EndOfLifeCount:    Number of PDUs at end of life time     *
*                 AckNackPduP:       AckNack message PDU, pointer           *
* TODO            SycPduP:           Sync message PDU, pointer              * 
*                 Pdu[]:             PDU Buffer data pointer array          *
*                                                                           *
*                 FU10 PDU Data Buffer (struct) is composed of              *
*                 RelatedSDU;        SDU Buffer write counter in number of  *
*                                    SDUs, shows to which SDU it belongs    *
*                 AckState:          Status of achknowledgement             *
*                 LifeTime:          Lifetime of PDU in number of TDMA frames*
*                 Length:            Length of PDU in bytes                 *
*                 MBit:              More bit indication                    *
*                 DataP:             Pointer to the SDU data (here PduTxMem[])*
*     Called by:  LU10INI.C/InitUPlane()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT void
InitFU10PduTx ( uint8 Lln )
{
    uint8 XDATA BuffCount;

    Mmu_Memset((FPTR)&PduTxBuf[Lln],0x00,sizeof(PDU_BUFFER_STRUCT)); // Sets struct PduTxBuf to 0x00
    Mmu_Memset((FPTR)&PduTxMem[Lln],0x00,PDU_BUFF_MAX*PDU_LEN); // Sets data array PduTxMem to 0x00
    for( BuffCount = 0;  BuffCount < PDU_WIN_SIZE;  BuffCount++ )
    {
        PduTxBuf[Lln].Pdu[BuffCount].DataP    = PduTxMem[Lln][BuffCount];// Sets PDU data part to PduTxMem buffer pointers
        PduTxBuf[Lln].Pdu[BuffCount].AckState = FU10_IDLE;
    }
    PduTxBuf[Lln].AckNackPduP = PduTxAckMem[Lln];

#ifdef PT
//    Send_Fu_Fragment_MBC (Lln, PduTxBuf[Lln].Pdu[0].DataP);
#endif
    PduTxBuf[Lln].LastPduP = PduTxBuf[Lln].Pdu[0].DataP;
    PduTxBuf[Lln].SSN      = 0;                                       // SN for new PDU
    PduTxBuf[Lln].RSN      = (PduTxBuf[Lln].SSN - 1) & FU10A_SSN_MOD; // Latest SN of ACK message
   PduTxBuf[Lln].RSNIndex = PduTxBuf[Lln].RSN;
    PduTxBuf[Lln].FrmCnt   = 0xFF;
    PduTxBuf[Lln].State    = UPCON_ACTIV;
  
    NULLPdu[ 0 ] = 0x00;
    NULLPdu[ 1 ] = FU10_LI_NO;
    for( BuffCount = 2;  BuffCount < PDU_LEN;  BuffCount++ )
       NULLPdu[ BuffCount ] = FU10_FILL_VALUE;

    Mmu_Memcpy( PduTxBuf[ Lln ].AckNackPduP, NULLPdu, PDU_LEN );
}

/*
*****************************************************************************
*                                                                           *
*     Function :  DeInitFU10PduTx                                           *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Deinitialisation of the SDU TX buffer number 0            *
*     Parms    :  Locigal link number, Lln                                  *
*              :  Set Connectuin  state                                     *
*     Returns  :  Local(static):                                            *
*                                                                           *
*     Remarks  :                                                            *
*     Called by:  LU10INI.C/InitUPlane()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT void
DeInitFU10PduTx ( uint8 Lln )
{
  PduTxBuf[Lln].State          = UPCON_IDLE;/* State of connection                  */ 
}


#ifdef CATIQ_UPLANE_FU10
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduTx                                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  : Fills the PDU data Buffer with PDU data ready for sending  *
*     Parms    : Locigal link number, Lln                                   *
*                Pointer to PDU data ready for sending, PduDataPtr          *
*     Returns  : = number of PDU data bytes in PDU to be sent               *
*     Remarks  : Lln is only used for FT.                                   *
*                                                                           *
*                Index of TX PDU data buffers is derived from SSN and RSN   *
*                counter using max number of buffers - 1 (SDU_BUFF_MOD) as  *
*                modulo, further called write and read index.               *
*                                                                           *
*                It checks whether PDU buffer contains a NACK requests. In  *
*                this case it searches for the first PDU data with status   *
*                FU10_TX_PDU_NACK. The search starts from last receive      *
*                sequence number(PduBufPtr->RSN) and ends at last send      *
*                sequence number(PduBufPtr->SSN).                           *
*                                                                           *
*                If it finds PDU data with this ack status, then PDU data   *
*                pointer ready for sending (PduDataPtr) is set to this PDU  *
*                data. This means thst this PDU will be retransmitted.      *
*                After this it returns with initial value of Retval (0x00). *
*                                                                           *
*                If it doesn't find PDU data with this ack status, then the *
*                number of requestet SSN (PduBufPtr->NAckCount) is reset    *
*                to 0x00 because no PDU is in status FU10_ACK_NACK. This    *
*                means none of the PDU has to be retransmitted.             *
*                                                                           *
*                Then it builds a synch frame as defined in EN 300 175-4    *
*                Figure 14.3.4.1.1.1. The first byte of synch frame is 8 LSB*
*                of the last SSN. The 2nd byte is bit 9 of last SSN         *
*                as MSB. Bits 7 - 2 and M bit set are not set because coding*
*                concerning FU10a or FU10c frame will be done by            *
*                PduRxAck().                                                *
*                                                                           *
*                If PduRxAck returns value bigger than 0 (e.g. 1 or 2) means*
*                that synch frame or ACK/NACK frame has to be sent.         *
*                                                                           *
*                If value is 2 a ACK/NACK frame has to be sent. A ACK/NACK  *
*                LU10c is always included in a FU10a frame and has been     *
*                composed by PduRxAck using RX buffer. This includes also   *
*                SSN of FU10a frame. Therefore SSN of TX buffer has to be   *
*                set. After this, Pointer to PDU data ready for sending,    *
*                PduDataPtr is set to this ACK/NACK frame. 0 is returned    *
*                                                                           *
*                If value is 1 a FU10a synch frame has to be sent it        *
*                contains SSN of RX buffer. After this Pointer to PDU data  *
*                ready for sending, PduDataPtr is set to this synch frame.  *
*                0 is returned.                                             *
*                                                                           *
*                If PduRxAck returns 0, this means that no synch and no     *
*                ACK/NACK frame has to be sent.                             *
*                                                                           *
*                It checks whether the window counter of the TX buffer is   *
*                larger than the Window size, which means no new PDUs can be*
*                sent. If this is the case it sets Pointer to PDU data ready*
*                for sending, PduDataPtr to current PDU data. It returns    *
*                Retval.                                                    *
*                                                                           *
*                Because window counter of the TX buffer is smaller than the*
*                Window size a new PDU can be sent. Therefore a new PDU TX  *
*                buffer is used. CopySdu2Pdu is called with the new PDU TX  *
*                pointer.                                                   *
*                If CopySdu2Pdu returns 0 no PDU (or better SDU) has to be  *
*                sent. It returns Retval.                                   *
*                                                                           *
*                If CopySdu2Pdu return value higher than 0 this measn that a*
*                PDU (or better SDU) has to be sent and the new PDU TX      *
*                pointer contains the new PDU data (starting after the FU10a*
*                header). Then  Pointer to PDU data ready for sending,      *
*                PduDataPtrNow is set to this new PDU data. Also the SSN    *
*                (write) of the new PDU TX buffer is incremented. FU10a     *
*                header is set using SSN (write) of new TX PDU buffer. In   *
*                addition window counter is incremented because of the new  *
*                PDU to be sent. It returns Retval.                         *
*     Called by:  <TODO>                                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT int8 
FU10PduTx (uint8 Lln, FPTR *PduDataPtr )        // Not Used
{
int8    XDATA AckLength  = 0;
uint8   XDATA RelatedSdu = 0;
uint16  XDATA PduLen  = 0;
int8    XDATA CopiedPduLength = 0;
FPTR    XDATA PduDataTempP = NULL;
uint16  XDATA SSNCount = 0;
uint8   XDATA PduBytesSent = 0;
#ifdef _UPSIM
  uint8 XDATA TestArray[100];
#endif
PDU_BUFFER_STRUCT XDATA *PduTxBufPtr;

#ifdef FT // Fixed part terminal
  if(Lln >= DLC_U_LLN_MAX)
  {
    return(-1);
  }
  PduTxBufPtr = &PduTxBuf[Lln];
#else // Portable part terminal
  SET_PORT_DEBUG(FU10TX_ACTIVE);
  PduTxBufPtr = &PduTxBuf[0];
#endif 

  if( PduTxBufPtr->uni.EndOfLifeCount > 0 )//Any PDUs at end of life time?
  {
    for(SSNCount = PduTxBufPtr->RSN ; SSNCount < PduTxBufPtr->SSN ; SSNCount++)
    { // start search from last received acknowledged PDU to last sent PDU
      if(PduTxBufPtr->Pdu[SSNCount & PDU_BUFF_MOD].LifeTime == 0)
      {  // life time has ended and synch frame has to be sent
         // Re-use PDU buffer of died PDU
        PduDataTempP  = PduTxBufPtr->Pdu[SSNCount & PDU_BUFF_MOD].DataP; // set temp data pointer to data buffer
       *PduDataTempP = (uint8) SSNCount; // Set 8 LSB of SSN into 1st byte
        PduDataTempP++; // next byte
       *PduDataTempP |= (uint8) SSNCount & FU10_ES9_BIT;// Set bit 9 of SSN
       *PduDataTempP |= FU10_SYNC_MESS; // set synch indication
       *PduDataTempP &= FU10_CLEAR_MORE_BIT; // set more bit to 0
         // PDU has to be cleared / initialized
         PduTxBufPtr->Pdu[SSNCount & PDU_BUFF_MOD].Length = PDU_HEADER_LEN; // only FU10a header
        PduTxBufPtr->Pdu[SSNCount & PDU_BUFF_MOD].LifeTime = PDU_TX_LIFE_TIME;
        PduTxBufPtr->Pdu[SSNCount & PDU_BUFF_MOD].AckState = FU10_TX_PDU;
        PduTxBufPtr->Window++; // increment window because new SDU segment has been sent
        *PduDataPtr = PduDataTempP; // set data to be sent pointer to synch frame
        DECT_DEBUG_FU10TX("PDUs at end of life time Tx %1d %4d",Lln,PduTxBufPtr->Pdu[SSNCount & PDU_BUFF_MOD].Length,0,0);
        SET_PORT_DEBUG(UPLANE_NOACTIVE);
        return(PduTxBufPtr->Pdu[SSNCount & PDU_BUFF_MOD].Length); // number of bytes to be sent
      }
      else
      {
        PduTxBufPtr->uni.EndOfLifeCount = 0; // Error in counter is corrected
      }
    }//end for loop
  }// end uni.EndOfLifeCount > 0
  else if ( PduTxBufPtr->NAckCount > 0 ) // Any NACK's received? 
  { 
    for(SSNCount = PduTxBufPtr->RSN ; SSNCount < PduTxBuf->SSN ; SSNCount++)
    {// start search from last received PDU to last sent PDU
      if(PduTxBufPtr->Pdu[SSNCount & PDU_BUFF_MOD].AckState == FU10_TX_PDU_NACK)
      {// negative acknowledge/s has/have been received for SSN, re-transmission needed
        *PduDataPtr = PduTxBufPtr->Pdu[SSNCount & PDU_BUFF_MOD].DataP;
        DECT_DEBUG_FU10TX("Any NACK's received %1d %4d",Lln,PduTxBufPtr->Pdu[SSNCount & PDU_BUFF_MOD].Length,0,0);
        SET_PORT_DEBUG(UPLANE_NOACTIVE);
        return(PduTxBufPtr->Pdu[SSNCount & PDU_BUFF_MOD].Length); // number of bytes to be sent;
      }
      else
      {
        PduTxBufPtr->NAckCount = 0;  /* Error no entry found */
      }
    }//end for
  }
  
  // Any acknowledgement to be sent
  AckLength = FU10PduRxAck (Lln, &PduTxBufPtr->AckNackPduP, 0); // return is number of bytes for LU10c ack frame or 0 

  if(AckLength == -3)
  { 
    // Acknowledgement is not needed but window size has been exceeded
    // Actually this point should never be reached
    DECT_DEBUG_FU10TX("window size has been exceeded %1d %5d",Lln,-3,0,0);
    SET_PORT_DEBUG(UPLANE_NOACTIVE);
    return (-3);
  }

  // New PDU could be sent 
  if(AckLength > 0) // with ack
  {
    // get new PDU buffer. Data buffer starting after ack + PDU header length (FU10a) and space of 2nd length
    // indication byte of FU10a frame
    PduDataTempP = PduTxBufPtr->Pdu[(PduTxBufPtr->SSN) & PDU_BUFF_MOD].DataP + AckLength + PDU_HEADER_LEN + 1; 
    // +1 is for space of 2nd length indication byte of FU10a frame
    CopiedPduLength = CopySdu2Pdu (Lln, PduDataTempP, (uint8)(PDU_DATA_LEN - AckLength),&PduDataTempP[1]); // -1 for 2nd length indication byte 

  }
  else if (AckLength == 0) // without ack
  {
    // get PDU buffer. Data buffer starting after PDU header length (FU10a)
    PduDataTempP = PduTxBufPtr->Pdu[(PduTxBufPtr->SSN) & PDU_BUFF_MOD].DataP; 
    //PduDataTempP = PduTxBufPtr->Pdu[(PduTxBufPtr->SSN) & PDU_BUFF_MOD].DataP + PDU_HEADER_LEN; 
    CopiedPduLength = CopySdu2Pdu (Lln, &PduDataTempP[PDU_HEADER_LEN], PDU_DATA_LEN,&PduDataTempP[1]); //  
  }

  if(CopiedPduLength > 0)
  { // SDU segment is available from the current SDU  */
//UWE    PduTxBufPtr->Pdu[(PduTxBufPtr->SSN) & PDU_BUFF_MOD].RelatedSDU = RelatedSdu; // set current (related) SDU number
 
    if(AckLength > 0) //shall ack be sent?
    {   // ack shall be sent with this FU10a frame
      // Copy ack frame after FU10a header of new PDU data buffer
      Mmu_Memcpy( PduDataTempP + 2, PduTxBufPtr->AckNackPduP, AckLength);
      // fill FU10a header
      *PduDataTempP = (uint8) PduTxBufPtr->SSN;// Set 8 LSB of last SSN into 1st byte
      //next byte
      *(PduDataTempP + 1) |= ((uint8)(PduTxBufPtr->SSN >> 1) & FU10_ES9_BIT);// Set bit 9 of last SSN
      *(PduDataTempP + 1) |= FU10_ACK_MESS; // set ack indication, M-Bit and length = fixed
      // set length concerning copied SDU data at position of 2nd length byte
          *(PduDataTempP + (AckLength + PDU_HEADER_LEN + 1) ) = (CopiedPduLength >> 1); // bit 8 = don't care
      // set return value
      PduBytesSent = (2 + AckLength + 1 + CopiedPduLength); //header + FU10c + 2nd length + part of SDU data
    }// end ack with SDU segment
    else if (AckLength == 0)
    {  // Only SDU segment shall be sent, no ack included
       // fill FU10a header
       *PduDataTempP = (uint8) PduTxBufPtr->SSN;// Set 8 LSB of last SSN into 1st byte
        //next byte
        *(PduDataTempP + 1) |= ((uint8)(PduTxBufPtr->SSN >> 1) & FU10_ES9_BIT)|(CopiedPduLength<<1);// Set bit 9 of last SSN
        //  bit 8 = don't care, M-Bit and length ind have been handled in CopySdu2Pdu
        PduBytesSent = (2 + CopiedPduLength); //header + part of SDU data
    } // end only SDU segment
  }
  else if (CopiedPduLength == 0)
  { // no SDU segment, shall ack be sent?
    if(AckLength > 0)
    { // ack shall be sent with this FU10a frame
      PduDataTempP = PduTxBufPtr->Pdu[PduTxBufPtr->SSN & PDU_BUFF_MOD].DataP;
      // Copy ack frame after FU10a header of new PDU data buffer
      Mmu_Memcpy( PduDataTempP + 2, PduTxBufPtr->AckNackPduP, AckLength);
      // fill FU10a header
      *PduDataTempP = (uint8) PduTxBufPtr->SSN;// Set 8 LSB of last SSN into 1st byte
      //next byte
      *(PduDataTempP + 1) |= ((uint8)( (PduTxBufPtr->SSN >> 1) & FU10_LENGTH_FIELD) & FU10_ES9_BIT);// Set bit 9 of last SSN
      *(PduDataTempP + 1) |= FU10_ACK_MESS; // ack indication
      PduBytesSent = AckLength + PDU_HEADER_LEN;
    }// end only ack
    else
    {  // no SDU and no ack
//      DECT_DEBUG_FU10TX("no SDU segment, shall ack be sent %1d",Lln,0,0,0);
        SET_PORT_DEBUG(UPLANE_NOACTIVE);
      return(0);
    }
  }// end no SDU segment
  else
  { // no more PDU to send, SDU has been completly read
    DECT_DEBUG_FU10TX("SDU has been completly read %1d",Lln,0,0,0);
    SET_PORT_DEBUG(UPLANE_NOACTIVE);
    return(0);
  }
  // Init new PDU
  PduTxBufPtr->Pdu[(PduTxBufPtr->SSN) & PDU_BUFF_MOD].Length = PduBytesSent;
  PduTxBufPtr->Pdu[(PduTxBufPtr->SSN) & PDU_BUFF_MOD].LifeTime = PDU_TX_LIFE_TIME;
  PduTxBufPtr->Pdu[(PduTxBufPtr->SSN) & PDU_BUFF_MOD].AckState = FU10_TX_PDU;
  PduTxBufPtr->Pdu[(PduTxBufPtr->SSN) & PDU_BUFF_MOD].MBit = *(PduDataTempP + 1) & FU10_MORE_BIT;
  
  if (CopiedPduLength != 0)
  { // only if SDU data have been included
    PduTxBufPtr->Window++; // increment window because new SDU segment has been sent
  }

  if(AckLength > 0) // ack has been sent
  {
    // Update RX buffer with SSN
    FU10UpdateRxBufferSSN (Lln, (uint8)PduTxBufPtr->SSN);
  }
  PduTxBufPtr->SSN++; // increment SSN (for next PDU)
  *PduDataPtr = PduDataTempP;

  DECT_DEBUG_FU10TX("%1d %4d",Lln,PduBytesSent,0,0);
  SET_PORT_DEBUG(UPLANE_NOACTIVE);
  return(PduBytesSent);
}

/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduTxAck                                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Update the status of TX PDU concerning received ack or    *
*                 synch or synch ack                                        *
*     Parms    :  Pointer to received PDU data, PduDataP                    *
*                 Locigal link number, Lln                                  *
*     Returns  :  = 0 if no ack, synch or synch ack was received            *
*                 = 1 if ack, synch or synch ack was received               *
*     Remarks  :                                                            *
*     Called by:  FU10ACRX.C/FU10PduRx()                                    *
*****************************************************************************
*/
EXPORT uint8 
FU10PduTxAckSync (uint8 Lln, FPTR PduDataP )    // Not Used
{
uint16  XDATA RecRSN = 0;
uint8   XDATA NA1NA2 = 0;
uint8   XDATA RSNCount = 0;
uint8   XDATA SecondLengthInd = 0;
uint16  XDATA TempSSN = 0;
uint16  XDATA Count;
FPTR    XDATA PduDataTempP;

PDU_BUFFER_STRUCT XDATA *PduTxBufPtr;

#ifdef FT
  PduTxBufPtr = &PduTxBuf[Lln];
#else
  PduTxBufPtr = &PduTxBuf[0];
#endif 

  PduDataTempP =  PduDataP; // set temp pointer to received PDU
  RecRSN = *PduDataTempP; // copy 8 LSB of RSN
  PduDataTempP++;         // next byte ER9, length and more bit
  RecRSN    |= ((uint16)(*PduDataTempP & FU10_ES9_BIT))<<1; //copy bit 9 of RSN

  if( (*PduDataTempP >> 1) == FU10_SYNC_MESS )// Is it synch frame PDU?
  { // synch PDU received, indication of which PDU has reached end of life time at peer side
    // As soon as a synchronization message has been received, the RSN shall be set to one higher 
    // than the value of the SN contained in the synchronization message and all the buffered PDUs 
    // with an SSN lower than or equal to the received one should be discarded.
    for (Count = 0 ; Count <= PDU_BUFF_MAX; Count++ )
    {  //have to go to all buffer because of modulo operation with PDU_BUFF_MOD to determine SSN
      TempSSN = *PduTxBufPtr->Pdu[Count & PDU_BUFF_MOD].DataP; // copy 8 LSB of RSN
      PduTxBufPtr->Pdu[Count & PDU_BUFF_MOD].DataP++; // next byte ER9, length and more bit
      TempSSN |= ((uint16)(*PduTxBufPtr->Pdu[Count & PDU_BUFF_MOD].DataP & FU10_ES9_BIT))<<1; //copy bit 9 of RSN
      if( (TempSSN <= RecRSN) && (PduTxBufPtr->Pdu[Count & PDU_BUFF_MOD].AckState != FU10_IDLE ) )
      {  // to be discarded
        PduTxBufPtr->Pdu[Count & PDU_BUFF_MOD].AckState = FU10_IDLE;
        PduTxBufPtr->Pdu[Count & PDU_BUFF_MOD].Length = 0;
        PduTxBufPtr->Pdu[Count & PDU_BUFF_MOD].LifeTime = PDU_TX_LIFE_TIME;
        if(PduTxBufPtr->Window > 0)
        {
          PduTxBufPtr->Window--; // decrement window because PDU has been freed
        }
      }
    }//end for loop
    PduTxBufPtr->Pdu[RecRSN & PDU_BUFF_MOD].AckState = FU10_RX_PDU_SYNC_ACK;// synch ack requested
    return(2); 
  }// end synch frame PDU
  else if ( (*PduDataTempP >> 1) == FU10_ACK_MESS ) // Is it ack pdu contains FU10c frame
  { // ack PDU received
    NA1NA2  =  PduDataTempP[FU10A_HEADER_LEN + FU10C_RSN_ANZ] & FU10C_NA_M;
    // check whether it is synch ack or normal ack.
    switch(NA1NA2)
    {
      case FU10C_NA_SYNC:     // 00 This frame contains an Ack of a synchronization message in RSN#1, no NACKs
      // ack that peer has synchronized, search for related synch PDU
        for(Count = PduTxBufPtr->SSN ; Count < RecRSN ; Count++)//
        {
          if(PduTxBufPtr->Pdu[Count & PDU_BUFF_MOD].AckState != FU10_IDLE) 
          {
            if(PduTxBufPtr->Pdu[Count & PDU_BUFF_MOD].AckState == FU10_TX_PDU_NACK) 
            {
              PduTxBufPtr->NAckCount--;
            }
            PduTxBufPtr->Pdu[Count & PDU_BUFF_MOD].AckState = FU10_TX_PDU_ACK;
          }
        }
        break;
      case FU10C_NA_ACK:      // 01 This frame contains only one ACK message in RSN#1, no NACKs
        if(PduTxBufPtr->Pdu[RecRSN & PDU_BUFF_MOD].AckState != FU10_IDLE) 
        {
          if(PduTxBufPtr->Pdu[RecRSN & PDU_BUFF_MOD].AckState == FU10_TX_PDU_NACK) 
          {
            PduTxBufPtr->NAckCount--;
          }
          PduTxBufPtr->Pdu[RecRSN & PDU_BUFF_MOD].AckState = FU10_TX_PDU_ACK;
        }
        break;
      case FU10C_NA_ACK_5NACK:// 10 This frame contains one ACK message in RSN#1plus five NACK messages in RSN#2-RSN#6
          if(PduTxBufPtr->Pdu[RecRSN & PDU_BUFF_MOD].AckState != FU10_IDLE) 
          {
            if(PduTxBufPtr->Pdu[RecRSN & PDU_BUFF_MOD].AckState == FU10_TX_PDU_NACK) 
            {
              PduTxBufPtr->NAckCount--;
            }
            PduTxBufPtr->Pdu[RecRSN & PDU_BUFF_MOD].AckState = FU10_TX_PDU_ACK;
          }
      
        RSNCount++;
      // break; use the next case 
      case FU10C_NA_6NACK:    // 11 This frame contains six NACK messages
        for(    ;RSNCount < FU10C_RSN_ANZ; RSNCount++)
        {
          RecRSN = PduDataTempP[RSNCount] | ((PduDataTempP[RSNCount]&(0x01<<RSNCount))<<(8-RSNCount));

          if(   (PduTxBufPtr->Pdu[RecRSN & PDU_BUFF_MOD].AckState != FU10_TX_PDU_NACK)
              &&(PduTxBufPtr->Pdu[RecRSN & PDU_BUFF_MOD].AckState != FU10_IDLE)  )
          {
            PduTxBufPtr->Pdu[RecRSN & PDU_BUFF_MOD].AckState = FU10_TX_PDU_NACK;
            PduTxBufPtr->NAckCount++;
          }

        }
      break;
    default:
      break;
    }// end switch NA1NA2
    // check whether SDU segment follows after ack
    SecondLengthInd = (PduDataTempP[FU10A_HEADER_LEN + FU10C_RSN_ANZ + 1] >> 1) & 0x3F; //follows after NA1, NA2 byte
    if(SecondLengthInd != 0)
    {  // data PDU follow
       // include 2nd length indication into FU10a header, 2nd byte, bit 8 remains = ES9, M-bit is overwritten
       PduDataTempP++;
       *PduDataTempP |= (PduDataTempP[FU10A_HEADER_LEN + FU10C_RSN_ANZ + 1]) & 0x7E;
       PduDataTempP++;
       // exclude ack by copy data PDU at at PDU header
       Mmu_Memcpy( PduDataTempP, PduDataTempP + (FU10A_HEADER_LEN + FU10C_RSN_ANZ + 2), SecondLengthInd);
    }
    return(1);
  }// end ack PDU
  else
  { // no ack and no sync
    return(0);
  }
}
#endif
#ifdef CATIQ_UPLANE_NO_JET
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10ClearRelatedPdu                                       *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Clears all PDUs belonging to a SDU which has reach end of *
*                 life time.
*     Parms    :  Number of the SDU                                         *
*     Returns  :  none                                                      *
*     Remarks  :                                                            *
*     Called by:  LU10TX.C/CopySdu2Pdu()                                    *
*****************************************************************************
*/
EXPORT void 
FU10ClearRelatedPdu (uint8 RelatedSdu )         // Not Used
{
  return;
}
#endif
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10UpdateLifeTimeTxBuffer                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Decrements life time counter of all PDUs in Tx buffer     *
*     Parms    :  Decrements value                                          *
*     Returns  :  none                                                      *
*     Remarks  :  The PDU life time is counted in TDMA frames. The decrement*
*                 determines the number of TDMA frames which have passed    *
*                 since last call of this function.
*                                                                           *
*     Called by:  TODO                                                      *
*                                                                           *
*****************************************************************************
*/
#ifdef CATIQ_UPLANE_NO_JET
EXPORT void
FU10UpdateLifeTimeTxBuffer (uint8 Decrement)    // Not Used
{
  uint8 XDATA Count = 0;

  for (Count = 0 ; Count <= PDU_BUFF_MAX; Count++ )
  {  //have to go to all buffers
    if( (PduTxBuf->Pdu[Count & PDU_BUFF_MOD].AckState != FU10_IDLE ) )
    {  // to be decremented
    if (PduTxBuf->Pdu[Count & PDU_BUFF_MOD].LifeTime >= Decrement)
      {
      PduTxBuf->Pdu[Count & PDU_BUFF_MOD].LifeTime -= Decrement;
      }
    else if (PduTxBuf->Pdu[Count & PDU_BUFF_MOD].LifeTime < Decrement)
      {
      PduTxBuf->Pdu[Count & PDU_BUFF_MOD].LifeTime = 0;
      }
    }
  }//end for loop

  return;
}
#endif
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10UpdateTxBufferRSN                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Updates RSN of TX buffer concerning RSN of RX buffer      *
*     Parms    :  RSN of RX Buffer                                          *
*                 Locigal link number, Lln                                  *
*     Returns  :  none                                                      *
*     Remarks  :                                                            *
*                                                                           *
*     Called by:  TODO                                                      *
*                                                                           *
*****************************************************************************
*/
#ifdef CATIQ_UPLANE_NO_JET
EXPORT void
FU10UpdateTxBufferRSN (uint8 Lln, uint8 RSN)    // Not Used
{
  PDU_BUFFER_STRUCT *PduTxBufPtr;

#ifdef FT
  PduTxBufPtr = &PduTxBuf[Lln];
#else
  PduTxBufPtr = &PduTxBuf[0];
#endif 

 PduTxBufPtr->RSN = RSN;

 return;
}
#endif

#ifdef CATIQ_UPLANE_FUXX
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduTx                                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  : Fills the PDU data Buffer with PDU data ready for sending  *
*     Parms    : Locigal link number, Lln                                   *
*                Pointer to PDU data ready for sending, PduDataPtr          *
*     Returns  : = number of PDU data bytes in PDU to be sent               *
*     Remarks  : Lln is only used for FT.                                   *
*                                                                           *
*     Called by:  <TODO>                                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT int8 
FU10PduTx (uint8 Lln, FPTR *PduDataPtr, uint8  FrmCnt )     // Old Algorithm
{
   uint8    XDATA PduLength     = 0;    // length of FU10A PDU
   uint8    XDATA Sdu_MORE_BIT  = 0;    // End of SDU?
   uint8    XDATA PduBytesSent  = 0;
   uint16   XDATA RSN;

   PDU_BUFFER_STRUCT XDATA *PduTxBufPtr;
   PDU_DATA_STRUCT   XDATA *PduTxPtr;

    // Check LLN(Logical Link Number)
   if( Lln >= DLC_U_LLN_MAX )
   {  // No data sending to MAC.
      return( 0 );
   }

   // Check FU10 Protocol Method and process related function call.
   if (FU10Method[ Lln ] != SUOTA_V1_1_1) {
      return (FU10PduTxV131 (Lln, PduDataPtr, FrmCnt));
   }

   PduTxBufPtr = &PduTxBuf[ Lln ];

   // Dupulicated Frame within one frame ?
   if( PduTxBufPtr->FrmCnt == FrmCnt )
   {  // Duplicated frame, no data sending    
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( 0 );
   }

   PduTxBufPtr->FrmCnt = FrmCnt;
   // UPlane Connection is not activated, we will send NULL PDU and set B-Field type to U_TYPE_0
   if( PduTxBufPtr->State != UPCON_ACTIV )
   {
      if( PduTxBufPtr->SSN )
         PduTxBufPtr->SSN = 0;

      // Null Data sending to MAC.
      *PduDataPtr  = NULLPdu;
      NULLPdu[ 0 ]  = (uint8)PduTxBufPtr->SSN;
      NULLPdu[ 1 ] |= (((uint8)(PduTxBufPtr->SSN >> 1)) & FU10_ES9_BIT);
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( 0 );         // For changing B-Field type to U_TYPE_0
   }

   // Should be checked whether ACK/NACK messages are required or not.
   // TODO : Should be checked for Bi-direction. Now, only think uni-direction.
   // Check whether ACK or NACK messages are required.
   PduLength = FU10PduRxAck( Lln, PduTxBufPtr->AckNackPduP, 0 );
   if( PduLength > 0 )
   {   // New SDU fetching will be happened when no NACK/ACK messages and no retransmission are required.

      *PduDataPtr = PduTxBufPtr->AckNackPduP;
      PduTxBufPtr->AckNackPduP[0]  =   (uint8)PduTxBufPtr->SSN;
      PduTxBufPtr->AckNackPduP[1] |= (((uint8)(PduTxBufPtr->SSN>>1))&FU10_ES9_BIT);

      // No further PDU.
      PduTxBufPtr->AckNackPduP[ PduLength + 1 ]  = 0x00;
      //DECT_DEBUG_UPLANE("UTX ACK:%02x%02x%02x%02x %02x%02x%02x%02x %02x%02x%02x%02x\r\n", 
      //PduTxBufPtr->AckNackPduP[0], PduTxBufPtr->AckNackPduP[1], PduTxBufPtr->AckNackPduP[ 2], PduTxBufPtr->AckNackPduP[ 3],
      //PduTxBufPtr->AckNackPduP[4], PduTxBufPtr->AckNackPduP[5], PduTxBufPtr->AckNackPduP[ 6], PduTxBufPtr->AckNackPduP[ 7],
      //PduTxBufPtr->AckNackPduP[8], PduTxBufPtr->AckNackPduP[9], PduTxBufPtr->AckNackPduP[10], PduTxBufPtr->AckNackPduP[11] );
      return( PDU_LEN );
      //return( 0 );
   }

   // NACKed PDU first.
   // When any NACK Messages are received, so we have to resend past NACKed PDUs first.
   if( PduTxBufPtr->NAckCount > 0 )
   {
      RSN = (PduTxBufPtr->RSN + 1) & FU10A_SSN_MOD;
      //RSN = ((uint8)(PduTxBufPtr->RSN+1)) & FU10A_SSN_MOD;
      for( PduLength = 0;  PduLength < PDU_BUFF_MAX;  PduLength++ )
      {
         if( PduTxBufPtr->Pdu[ RSN & PDU_BUFF_MOD ].AckState == FU10_TX_PDU_NACK )
         {
            *PduDataPtr = PduTxBufPtr->Pdu[ RSN & PDU_BUFF_MOD ].DataP;
            PduTxBufPtr->Pdu[ RSN & PDU_BUFF_MOD ].AckState = FU10_TX_PDU;
            PduTxBufPtr->NAckCount--;
            PduTxBufPtr->AckReqCount++;
            PduTxBufPtr->Window++;
            SET_PORT_DEBUG( UPLANE_NOACTIVE );

            PduTxBufPtr->LastPduP = *PduDataPtr;
            DECT_DEBUG_UPLANE("TX NACKed Msg:%2x %2x %02x - %04x\r\n", PduTxBufPtr->AckReqCount,
                              PduTxBufPtr->NAckCount, PduTxBufPtr->Window, RSN );
            return ( PDU_LEN );
         }
         RSN = (RSN + 1) & FU10A_SSN_MOD;
      }
      PduTxBufPtr->NAckCount = 0;
   }

   // in order to check More-Bit of previous PDU packet for deciding whether previous PDU is last
   // PDU of one SDU packet or not.
   RSN = (PduTxBufPtr->SSN - 1) & FU10A_SSN_MOD;

   PduTxPtr = &PduTxBufPtr->Pdu[ PduTxBufPtr->SSN & PDU_BUFF_MOD ];
   // Window is full. So, send last PDU one time and go back PDU resending from last unACKed PDU.
   if( (PduTxBufPtr->AckReqCount >= FU10_WINDOW_SIZE) || (PduTxPtr->AckState != FU10_IDLE) ||
      ((PduTxBufPtr->Pdu[ RSN & PDU_BUFF_MOD ].MBit != FU10_MORE_BIT) && (PduTxBufPtr->AckReqCount > 0)) )
   {  // Resend last PDU.
      DECT_DEBUG_UPLANE("ReTX Un-ACKed PDU1:%02x%02x%02x - %02x %04x%04x\r\n", PduTxBufPtr->AckReqCount, PduTxBufPtr->NAckCount, 
                        PduTxBufPtr->Window, PduTxPtr->AckState, PduTxBufPtr->RSN, PduTxBufPtr->SSN );
      *PduDataPtr = PduTxBufPtr->LastPduP;

      // Set all un-ACKed PDUs to NACK PDUs for resending.
      RSN = (PduTxBufPtr->RSN + 1) & FU10A_SSN_MOD;
      //RSN = PduTxBufPtr->RSN;
      //RSN = ((uint8)(PduTxBufPtr->RSN + 1)) & FU10A_SSN_MOD;
      for( PduLength = 0;  (PduLength < PDU_BUFF_MAX) && (RSN != ((PduTxBufPtr->SSN + 1) & FU10A_SSN_MOD));
           PduLength++ )
      {
         if( PduTxBufPtr->Pdu[ RSN & PDU_BUFF_MOD ].AckState == FU10_TX_PDU )
         {
            PduTxBufPtr->Pdu[ RSN & PDU_BUFF_MOD ].AckState = FU10_TX_PDU_NACK;
            PduTxBufPtr->NAckCount++;
            PduTxBufPtr->AckReqCount--;
            PduTxBufPtr->Window--;
            SET_PORT_DEBUG( UPLANE_NOACTIVE );
         }
         RSN = (RSN + 1) & FU10A_SSN_MOD;
      }

      DECT_DEBUG_UPLANE("ReTX Un-ACKed PDU2:%02x%02x%02x - %04x%04x\r\n", PduTxBufPtr->AckReqCount, PduTxBufPtr->NAckCount, 
                        PduTxBufPtr->Window, PduTxBufPtr->RSN, PduTxBufPtr->SSN );
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( PDU_LEN );
   }

   *PduDataPtr = PduTxPtr->DataP;
   // Check whether there is new PDU for sending or not.
   PduLength = CopySdu2Pdu ( Lln, (FPTR) &PduTxPtr->DataP[ PDU_HEADER_LEN ], PDU_DATA_LEN, &Sdu_MORE_BIT );
   if( PduLength )
   {
      PduTxPtr->DataP[0]  = (uint8)PduTxBufPtr->SSN;
#ifdef SDUSIZE
      PduTxPtr->DataP[1]  = (((uint8)(PduTxBufPtr->SSN>>1))&FU10_ES9_BIT) |
                             (PduLength << 1);
      if( (Sdu_MORE_BIT & 0x80) != 0x80 ) {
         PduTxPtr->DataP[1] |= FU10_MORE_BIT;
         PduTxPtr->MBit      = FU10_MORE_BIT;
      } else {
         PduTxPtr->MBit      = FU10_NOMORE_BIT;
      }
#else
      PduTxPtr->DataP[1]  = (((uint8)(PduTxBufPtr->SSN>>1))&FU10_ES9_BIT) |
                             (PduLength << 1) | Sdu_MORE_BIT;
      PduTxPtr->MBit     = Sdu_MORE_BIT;
#endif
      PduBytesSent = PDU_HEADER_LEN + PduLength;
      PduTxPtr->AckState = FU10_TX_PDU;

      PduTxBufPtr->Window++;
      PduTxBufPtr->AckReqCount++;
      // next PDU
      DECT_DEBUG_UPLANE("TX New Data:%2x %2x %02x - %04x\r\n", PduTxBufPtr->AckReqCount, PduTxBufPtr->NAckCount, 
                        PduTxBufPtr->Window, PduTxBufPtr->SSN );
      //DECT_DEBUG_FU10TX("%02d %04x", PduBytesSent, PduTxBufPtr->SSN, 0, 0 );
      PduTxBufPtr->SSN = (PduTxBufPtr->SSN + 1) & FU10A_SSN_MOD;;

      if( PduBytesSent < PDU_LEN )
      {
         (*PduDataPtr)[ PduBytesSent++ ] = FU10_LI_NO;
         for( ; PduBytesSent < PDU_LEN;  PduBytesSent++ )
         {    
            PduTxPtr->DataP[PduBytesSent] = FU10_FILL_VALUE;
         }
      }
      PduTxBufPtr->LastPduP = *PduDataPtr;
   }
   else
   {   // No need any ACK/NACK or SDU data, so we send NULL frame packet.
      *PduDataPtr  = NULLPdu;
      NULLPdu[0]  = (uint8)PduTxBufPtr->SSN;
      NULLPdu[1] |= (((uint8)(PduTxBufPtr->SSN >> 1)) & FU10_ES9_BIT);
      PduBytesSent = 0;    // For changing B-Field type to U_TYPE_0
   }

    SET_PORT_DEBUG( UPLANE_NOACTIVE );
    return( PduBytesSent );
}
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduTxAck                                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Update the status of TX PDU concerning received ack or    *
*                 synch or synch ack                                        *
*     Parms    :  Pointer to received PDU data, PduDataP                    *
*                 Locigal link number, Lln                                  *
*     Returns  :  = 0 if no ack, synch or synch ack was received            *
*                 = 1 if ack, synch or synch ack was received               *
*     Remarks  :                                                            *
*     Called by:  FU10ACRX.C/FU10PduRx()                                    *
*****************************************************************************
*/

EXPORT uint8 
FU10PduTxAckSync (uint8 Lln, FPTR PduDataP )
{
   uint16 XDATA   RSN;
   uint8  XDATA   RSNmod, WinSize;
   uint8  XDATA   index;

   PDU_BUFFER_STRUCT XDATA *PduTxBufPtr;

   PduTxBufPtr = &PduTxBuf[ Lln ];
  
   index = 1;
   WinSize = PDU_WIN_SIZE;

   // For processing multi-ACK/NACK messages, we have to check ACK/NACK messages
   // until there is no ACK/NACK message.
   while( (PduDataP[ index ] & FU10_MESS_M) == FU10_ACK_MESS )
   {
      /* Indication of FU10a Synch Frame without M-Bit set  */
      /* Indication of FU10c ACK Frame in FU10a with M-Bit set  */
      // FU10c NA1, NA2 defines
      switch( PduDataP[ index + 7 ] & FU10C_NA_M )
      {
         // 01 This frame contains only one ACK message in RSN#1, no NACKs
         case FU10C_NA_ACK:
            RSN = (PduDataP[ FU10C_RSN_ER9 ] & FU10C_RSN1_ER9_M);
            RSN = (RSN << (8-FU10C_RSN1_ER9)) | PduDataP[ FU10C_RSN1 ];
#if 1  // FIXED_SSN
            RSN = (RSN - 1) & FU10A_SSN_MOD;
#endif

            if( (PduTxBufPtr->SSN & FU10A_SSN_MOD) < WinSize )
            {
               if( RSN > WinSize ) {
                  if( RSN < ((PduTxBufPtr->SSN - WinSize) & FU10A_SSN_MOD) ) {
                     DECT_DEBUG_UPLANE("OOR_ACK1:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                     break;
                  }
               } else {
                  if( PduTxBufPtr->SSN <= RSN ) {
                     DECT_DEBUG_UPLANE("OOR_ACK2:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                     break;
                  }
               }
            } else {
               if( (PduTxBufPtr->SSN <= RSN) ||
                   (RSN < ((PduTxBufPtr->SSN - WinSize) & FU10A_SSN_MOD)) ) 
               {
                     DECT_DEBUG_UPLANE("OOR_ACK3:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                  break;
               }
            }

            if ((RSN & FU10C_SSN_MOD) < WinSize) {
               if (PduTxBufPtr->RSN > WinSize) {
                  if (PduTxBufPtr->RSN < ((RSN - WinSize) & FU10C_SSN_MOD)) {
                     DECT_DEBUG_UPLANE("OOR_ACK4:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                     break;
                  }
               } else {
                  if (RSN <= PduTxBufPtr->RSN) {
                     DECT_DEBUG_UPLANE("OOR_ACK5:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                     break;
                  }
               }
            } else {
               if ((RSN <= PduTxBufPtr->RSN) ||
                   (PduTxBufPtr->RSN < ((RSN - WinSize) & FU10C_SSN_MOD))) {
                  DECT_DEBUG_UPLANE("OOR_ACK6:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                  break;
               }
            }
            DECT_DEBUG_UPLANE("TX 1-ACK:%2x %02x %2x - %4x %4x\r\n", PduTxBufPtr->AckReqCount,
                              PduTxBufPtr->NAckCount, PduTxBufPtr->Window, PduTxBufPtr->RSN, RSN );
            // Synchronization for TX PDU window
            if( RSN != PduTxBufPtr->RSN )
            {
               PduTxBufPtr->uni.EndOfLifeCount = 0;
               for( RSNmod = 0;  (RSNmod < PDU_BUFF_MAX) && (RSN != PduTxBufPtr->RSN);  RSNmod++ )
               {
                  PduTxBufPtr->RSN = (PduTxBufPtr->RSN + 1) & FU10A_SSN_MOD;
                  if( PduTxBufPtr->Pdu[ PduTxBufPtr->RSN & PDU_BUFF_MOD ].AckState == FU10_TX_PDU )
                  {
                     PduTxBufPtr->AckReqCount--;
                     PduTxBufPtr->Window--;
                  }
                  else if( PduTxBufPtr->Pdu[ PduTxBufPtr->RSN & PDU_BUFF_MOD ].AckState == FU10_TX_PDU_NACK )
                  {
                     PduTxBufPtr->NAckCount--;
                  }
                  PduTxBufPtr->Pdu[PduTxBufPtr->RSN & PDU_BUFF_MOD].AckState = FU10_IDLE;
               }
            }
#if 0
            else
            {
               if( PduTxBufPtr->Pdu[ PduTxBufPtr->RSN & PDU_BUFF_MOD ].AckState == FU10_TX_PDU )
               {
                  PduTxBufPtr->AckReqCount--;
                  PduTxBufPtr->Window--;
               }
               else if( PduTxBufPtr->Pdu[ PduTxBufPtr->RSN & PDU_BUFF_MOD ].AckState == FU10_TX_PDU_NACK )
               {
                  PduTxBufPtr->NAckCount--;
               }
               PduTxBufPtr->Pdu[PduTxBufPtr->RSN & PDU_BUFF_MOD].AckState = FU10_IDLE;
            }
#endif
            break;

         // 10 This frame contains one ACK message in RSN#1 plus five NACK messages in RSN#2-RSN#6
         case FU10C_NA_ACK_5NACK:    
            RSN = (PduDataP[ FU10C_RSN_ER9 ] & FU10C_RSN1_ER9_M);
            RSN = (RSN << (8 - FU10C_RSN1_ER9)) | PduDataP[ FU10C_RSN1 ];

#if 1  // FIXED_SSN
            RSN = (RSN - 1) & FU10A_SSN_MOD;
#endif
            DECT_DEBUG_UPLANE("TX 1+5-ACK:%2x %02x %2x -  %4x %4x\r\n", PduTxBufPtr->AckReqCount,
                              PduTxBufPtr->NAckCount, PduTxBufPtr->Window, PduTxBufPtr->RSN, RSN );
            // Synchronization for TX PDU window
            for( RSNmod = 0;  (RSNmod < PDU_BUFF_MAX) && (RSN != PduTxBufPtr->RSN);  RSNmod++ )
            {
               PduTxBufPtr->RSN = (PduTxBufPtr->RSN + 1) & FU10A_SSN_MOD;
               if(PduTxBufPtr->Pdu[ PduTxBufPtr->RSN & PDU_BUFF_MOD ].AckState == FU10_TX_PDU )
               {
                  PduTxBufPtr->AckReqCount--;
                  PduTxBufPtr->Window--;
               }
               PduTxBufPtr->Pdu[ PduTxBufPtr->RSN & PDU_BUFF_MOD ].AckState = FU10_IDLE;
            } 
            // Go Back 2 NACK
            for( RSN = ((RSN + 1) & FU10A_SSN_MOD);  RSN != ((PduTxBufPtr->SSN + 1) & FU10A_SSN_MOD);
                 RSN = ((RSN + 1) & FU10A_SSN_MOD) )
            {
               if( PduTxBufPtr->Pdu[RSN & PDU_BUFF_MOD].AckState == FU10_TX_PDU )
               {
                  PduTxBufPtr->Pdu[ RSN & PDU_BUFF_MOD ].AckState = FU10_TX_PDU_NACK;
                  PduTxBufPtr->NAckCount++;
                  PduTxBufPtr->AckReqCount--;
                  PduTxBufPtr->Window--;
               }
            }
            break;
         
         // 00 This frame contains an ACK of a synchronization message in RSN#1, no NACKs
         case FU10C_NA_SYNC:
         // 11 This frame contains 6 NACK messages
         case FU10C_NA_6NACK:
         default:
            break;
         
      }
      index += (PDU_FU10C_HEADER_LEN + PDU_FU10AC_OFFSET);
   }

   return( index - 1 );
}
#endif //#ifdef CATIQ_UPLANE_FUXX
#ifdef CATIQ_UPLANE_FU01
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduTx   FU01                                          *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  : Fills the PDU data Buffer with PDU data ready for sending  *
*     Parms    : Locigal link number, Lln                                   *
*                Pointer to PDU data ready for sending, PduDataPtr          *
*     Returns  : = number of PDU data bytes in PDU to be sent               *
*     Remarks  : Lln is only used for FT.                                   *
*                                                                           *
*     Called by:  <TODO>                                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT int8 
FU10PduTx (uint8 Lln, FPTR *PduDataPtr )        // Not Used
{
  uint8 XDATA Sdu_MORE_BIT  = 0;    // End of SDU?
  PDU_BUFFER_STRUCT XDATA *PduTxBufPtr;
  PDU_DATA_STRUCT   XDATA *PduTxPtr;
#ifdef FT // Fixed part terminal
  if(Lln >= DLC_U_LLN_MAX)
  {
    return(0);
  }
  PduTxBufPtr = &PduTxBuf[Lln];
#else // Portable part terminal
  SET_PORT_DEBUG(FU10TX_ACTIVE);
  PduTxBufPtr = &PduTxBuf[0];
#endif 

  PduTxPtr  = &PduTxBuf[Lln].Pdu[PduTxBufPtr->SSN&PDU_BUFF_MOD];
  Mmu_Memset( (FPTR) PduTxPtr->DataP, 0 , PDU_LEN );
  if(CopySdu2Pdu ( Lln, PduTxPtr->DataP,PDU_LEN ,&Sdu_MORE_BIT))
  {
    PduTxBufPtr->SSN++;
  }
  *PduDataPtr  = PduTxPtr->DataP;
  SET_PORT_DEBUG(UPLANE_NOACTIVE);
  return(PDU_LEN); 

}
#endif //#ifdef CATIQ_UPLANE_FU01

#ifdef CATIQ_UPLANE_FU10_NEW_STD
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduTx                                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  : Fills the PDU data Buffer with PDU data ready for sending  *
*     Parms    : Locigal link number, Lln                                   *
*                Pointer to PDU data ready for sending, PduDataPtr          *
*     Returns  : = number of PDU data bytes in PDU to be sent               *
*     Remarks  : Lln is only used for FT.                                   *
*                                                                           *
*     Called by:  <TODO>                                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT int8 
FU10PduTxV131 (uint8 Lln, FPTR *PduDataPtr, uint8  FrmCnt )     // New Algorithm
{
   uint8    XDATA i, PduLength = 0;    // length of FU10A PDU
   uint8    XDATA Sdu_MORE_BIT = 0;    // End of SDU?
   uint8    XDATA PduBytesSent = 0;
   uint8    XDATA RXAckLength = 0;
   uint16   XDATA TempSN;

   PDU_BUFFER_STRUCT XDATA *PduTxBufPtr;
   PDU_DATA_STRUCT   XDATA *PduTxPtr;

   #if 0
   // Check LLN(Logical Link Number)
   if (Lln >= DLC_U_LLN_MAX) {
      // No data sending to MAC.
      return( 0 );
   }
   #endif

   PduTxBufPtr = &PduTxBuf[ Lln ];

   // Dupulicated Frame within one frame ?
   if (PduTxBufPtr->FrmCnt == FrmCnt) {
      // Duplicated frame, no data sending    
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( 0 );
   }

   PduTxBufPtr->FrmCnt = FrmCnt;
   if (PduTxBufPtr->State != UPCON_ACTIV) {
      // UPlane Connection is not activated, we will send NULL PDU and set B-Field type to U_TYPE_0
      if (PduTxBufPtr->SSN) {
         PduTxBufPtr->SSN = 0;
      }

      *PduDataPtr  = NULLPdu;             // Null Data sending to MAC.
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( PDU_LEN );
   }

   PduTxBufPtr->RSN &= FU10C_SSN_MOD;
   //DECT_DEBUG_UPLANE("TX:%02x %02x\r\n", PduTxBufPtr->RSN, PduTxBufPtr->SSN);

   // Check whether ACK/NACK messages are required or not.
   // ACK/NACK message is also PDU and store in TX Buffer.
   RXAckLength = FU10PduRxAckV131( Lln, PduTxBufPtr->AckNackPduP, 0 );

   // Check resend timer of each PDU in TX TX Buffer and resend TX PDU when resend timer is expired.
   //TempSN = (PduTxBufPtr->RSN + 1) & FU10C_SSN_MOD;
   TempSN = (PduTxBufPtr->RSNIndex + 1) & FU10C_SSN_MOD;
   PduTxBufPtr->Window = 0;
   Sdu_MORE_BIT = 0;
   for( i = 0;  (i < PDU_BUFF_MAX) && (TempSN != ((PduTxBufPtr->SSN + 1) & FU10C_SSN_MOD));  i++ )
   {
      PduLength = TempSN & PDU_BUFF_MOD;
      if (PduTxBufPtr->Pdu[ PduLength ].AckState == FU10_TX_PDU) {
         if (PduTxBufPtr->Pdu[ PduLength ].ReSendTimer > 0) {
            PduTxBufPtr->Pdu[ PduLength ].ReSendTimer--;
         }

         if ((PduTxBufPtr->Pdu[ PduLength ].ReSendTimer == 0) && (Sdu_MORE_BIT == 0) && (RXAckLength == 0)) {
               DECT_DEBUG_UPLANE("Re:%02x\r\n", TempSN);
               *PduDataPtr = PduTxBufPtr->Pdu[ PduLength ].DataP;
               PduTxBufPtr->Pdu[ PduLength ].AckState = FU10_TX_PDU;
               PduTxBufPtr->Pdu[ PduLength ].ReSendTimer = PDU_RESEND_TIME;
               PduTxBufPtr->LastPduP = *PduDataPtr;
               Sdu_MORE_BIT = 1;
               //return ( PDU_LEN );
         }
         PduTxBufPtr->Window++;
      }
      TempSN = (TempSN + 1) & FU10C_SSN_MOD;
   }

   if (Sdu_MORE_BIT == 1) {
      return( PDU_LEN );
   }
   if (PduTxBufPtr->Window >= PDU_BUFF_MAX)
   {
      return( 0 );
   }

   // Check whether ACK/NACK messages are required or not.
   // ACK/NACK message is also PDU and store in TX Buffer.
   //PduLength = FU10PduRxAckV131( Lln, PduTxBufPtr->AckNackPduP, 0 );
   if (RXAckLength > 0) {
      // New SDU fetching will be happened when no NACK/ACK messages and no retransmission are required.
      PduTxBufPtr->AckNackPduP[0]  =   (uint8)PduTxBufPtr->SSN;
      PduTxBufPtr->AckNackPduP[1] |= (((uint8)(PduTxBufPtr->SSN>>1)) & FU10_ES9_BIT);

      TempSN = PduTxBufPtr->SSN & PDU_BUFF_MOD;
      PduTxPtr = &PduTxBufPtr->Pdu[ TempSN ];
      *PduDataPtr = PduTxBufPtr->Pdu[ TempSN ].DataP;
      PduBytesSent = RXAckLength + 1;

      Mmu_Memcpy((*PduDataPtr), PduTxBufPtr->AckNackPduP, PduBytesSent);
      PduTxBufPtr->Pdu[ TempSN ].AckState = FU10_TX_PDU;
      PduTxBufPtr->Pdu[ TempSN ].ReSendTimer = PDU_RESEND_TIME;

      PduTxBufPtr->LastPduP = *PduDataPtr;
      PduTxBufPtr->SSN = (PduTxBufPtr->SSN + 1) & FU10C_SSN_MOD;

      // Fill FILL_BYTEs
      if (PduBytesSent < PDU_LEN) {
         (*PduDataPtr)[ PduBytesSent++ ] = FU10_LI_NO;
         for ( ; PduBytesSent < PDU_LEN;  PduBytesSent++ ) {
            PduTxPtr->DataP[PduBytesSent] = FU10_FILL_VALUE;
         }
      }
      //DECT_DEBUG_UPLANE("UTX ACK:%02x%02x%02x%02x %02x%02x%02x%02x\r\n", 
      //(*PduDataPtr)[0], (*PduDataPtr)[1], (*PduDataPtr)[2], (*PduDataPtr)[3],
      //(*PduDataPtr)[4], (*PduDataPtr)[5], (*PduDataPtr)[6], (*PduDataPtr)[7] );
      #if 0
      TempSN = (PduTxBufPtr->RSN + 1) & FU10C_SSN_MOD;
      for( i = 0;  (i < PDU_BUFF_MAX) && (TempSN != ((PduTxBufPtr->SSN + 1) & FU10C_SSN_MOD));  i++ )
      {
         PduLength = TempSN & PDU_BUFF_MOD;
         if (PduTxBufPtr->Pdu[ PduLength ].AckState == FU10_TX_PDU) {
            PduTxBufPtr->Pdu[ PduLength ].ReSendTimer = 0;
         }
         TempSN = (TempSN + 1) & FU10C_SSN_MOD;
      }
      #endif
      return( PDU_LEN );
   }


   TempSN = (PduTxBufPtr->SSN - 1) & FU10C_SSN_MOD;
   PduTxPtr = &PduTxBufPtr->Pdu[ PduTxBufPtr->SSN & PDU_BUFF_MOD ];

   *PduDataPtr = PduTxPtr->DataP;
   // Check whether there is new PDU for sending or not.
   PduLength = CopySdu2Pdu (Lln, (FPTR) &PduTxPtr->DataP[ PDU_HEADER_LEN ], PDU_DATA_LEN, &Sdu_MORE_BIT);
   if (PduLength) {
      PduTxPtr->DataP[0] = (uint8)PduTxBufPtr->SSN;
   #ifdef SDUSIZE
      PduTxPtr->DataP[1] = (((uint8)(PduTxBufPtr->SSN>>1))&FU10_ES9_BIT) | (PduLength << 1);
      if( (Sdu_MORE_BIT & 0x80) != 0x80 ) {
         PduTxPtr->DataP[1] |= FU10_MORE_BIT;
         PduTxPtr->MBit      = FU10_MORE_BIT;
      } else {
         PduTxPtr->MBit      = FU10_NOMORE_BIT;
      }
   #else
      PduTxPtr->DataP[1] = (((uint8)(PduTxBufPtr->SSN>>1))&FU10_ES9_BIT) | (PduLength << 1) | Sdu_MORE_BIT;
      PduTxPtr->MBit     = Sdu_MORE_BIT;
   #endif
      PduBytesSent = PDU_HEADER_LEN + PduLength;
      PduTxPtr->AckState = FU10_TX_PDU;
      PduTxPtr->ReSendTimer = PDU_RESEND_TIME;

      PduTxBufPtr->Window++;

      // next PDU
      DECT_DEBUG_UPLANE("New:%02x%02x%02x - %02x\r\n", PduTxBufPtr->AckReqCount, PduTxBufPtr->NAckCount, 
                        PduTxBufPtr->Window, PduTxBufPtr->SSN );
      //DECT_DEBUG_FU10TX("%02d %04x", PduBytesSent, PduTxBufPtr->SSN, 0, 0 );
      PduTxBufPtr->SSN = (PduTxBufPtr->SSN + 1) & FU10C_SSN_MOD;
      PduTxBufPtr->LastPduP = *PduDataPtr;

      // Fill FILL_BYTEs
      if (PduBytesSent < PDU_LEN) {
         (*PduDataPtr)[ PduBytesSent++ ] = FU10_LI_NO;
         for ( ; PduBytesSent < PDU_LEN;  PduBytesSent++ ) {
            PduTxPtr->DataP[PduBytesSent] = FU10_FILL_VALUE;
         }
      }
   } else {
      // No need any ACK/NACK or SDU data, so we send NULL frame packet.
      *PduDataPtr  = NULLPdu;
      PduBytesSent = PDU_LEN;
   }

   SET_PORT_DEBUG( UPLANE_NOACTIVE );
   return( PduBytesSent );
}
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduTxAck                                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Update the status of TX PDU concerning received ack or    *
*                 synch or synch ack                                        *
*     Parms    :  Pointer to received PDU data, PduDataP                    *
*                 Locigal link number, Lln                                  *
*     Returns  :  = 0 if no ack, synch or synch ack was received            *
*                 = 1 if ack, synch or synch ack was received               *
*     Remarks  :                                                            *
*     Called by:  FU10ACRX.C/FU10PduRx()                                    *
*****************************************************************************
*/

EXPORT uint8 
FU10PduTxAckSyncV131 (uint8 Lln, FPTR PduDataP )
{
   uint16 XDATA   RSN;
   uint8  XDATA   RSNmod, WinSize;
   uint8  XDATA   index;

   PDU_BUFFER_STRUCT XDATA *PduTxBufPtr;

   PduTxBufPtr = &PduTxBuf[ Lln ];
  
   index = 1;
   WinSize = PDU_WIN_SIZE;

   //DECT_DEBUG_UPLANE("TXACK:%04x%04x %02x%02x\r\n", PduTxBufPtr->SSN, PduTxBufPtr->RSN, PduDataP[ index ], PduDataP[ index+7 ] );
   // For processing multi-ACK/NACK messages, we have to check ACK/NACK messages
   // until there is no ACK/NACK message.
   while ((PduDataP[ index ] & FU10_MESS_M) == FU10_ACK_MESS) {
      /* Indication of FU10a Synch Frame without M-Bit set      */
      /* Indication of FU10c ACK Frame in FU10a with M-Bit set  */
      // FU10c NA1, NA2 defines
      switch (PduDataP[index+7] & FU10C_NA_M) {
         // 01 This frame contains only one ACK message in RSN#1, no NACKs
         case FU10C_NA_ACK:
         // 10 This frame contains one ACK message in RSN#1 plus five NACK messages in RSN#2-RSN#6
         case FU10C_NA_ACK_5NACK:
            RSN = (PduDataP[ FU10C_RSN_ER9 ] & FU10C_RSN1_ER9_M);
            RSN = (RSN << (8-FU10C_RSN1_ER9)) | PduDataP[ FU10C_RSN1 ];
            RSN = (RSN - 1) & FU10C_SSN_MOD;

            if ((PduTxBufPtr->SSN & FU10C_SSN_MOD) < WinSize) {
               if (RSN > WinSize) {
                  if ( RSN < ((PduTxBufPtr->SSN - WinSize) & FU10C_SSN_MOD)) {
                     DECT_DEBUG_UPLANE("OOR_ACK1:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                     break;
                  }
               } else {
                  if (PduTxBufPtr->SSN <= RSN) {
                     DECT_DEBUG_UPLANE("OOR_ACK2:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                     break;
                  }
               }
            } else {
               if ((PduTxBufPtr->SSN <= RSN) ||
                   (RSN < ((PduTxBufPtr->SSN - WinSize) & FU10C_SSN_MOD))) {
                     DECT_DEBUG_UPLANE("OOR_ACK3:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                  break;
               }
            }

            if ((RSN & FU10C_SSN_MOD) < WinSize) {
               if (PduTxBufPtr->RSN > WinSize) {
                  if (PduTxBufPtr->RSN < ((RSN - WinSize) & FU10C_SSN_MOD)) {
                     DECT_DEBUG_UPLANE("OOR_ACK4:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                     break;
                  }
               } else {
                  if (RSN <= PduTxBufPtr->RSN) {
                     DECT_DEBUG_UPLANE("OOR_ACK5:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                     break;
                  }
               }
            } else {
               if ((RSN <= PduTxBufPtr->RSN) ||
                   (PduTxBufPtr->RSN < ((RSN - WinSize) & FU10C_SSN_MOD))) {
                  DECT_DEBUG_UPLANE("OOR_ACK6:%02x%02x %04x\r\n", PduTxBufPtr->RSN, RSN, PduTxBufPtr->SSN );
                  break;
               }
            }
            
            DECT_DEBUG_UPLANE("TX-ACK:%02x %02x\r\n", PduTxBufPtr->RSN, RSN );
            // Synchronization for TX PDU window
            if (RSN != PduTxBufPtr->RSN) {
               for (RSNmod = 0;  (RSNmod < PDU_BUFF_MAX) && (RSN != PduTxBufPtr->RSN);  RSNmod++)
               {
                  PduTxBufPtr->RSN = (PduTxBufPtr->RSN + 1) & FU10C_SSN_MOD;
                  if (PduTxBufPtr->Pdu[ PduTxBufPtr->RSN & PDU_BUFF_MOD ].AckState == FU10_TX_PDU) {
                     PduTxBufPtr->Pdu[PduTxBufPtr->RSN & PDU_BUFF_MOD].AckState = FU10_IDLE;
                     PduTxBufPtr->Pdu[PduTxBufPtr->RSN & PDU_BUFF_MOD].ReSendTimer = 0;
                  }
               }
               PduTxBufPtr->RSNIndex = PduTxBufPtr->RSN;
            }
            break;

         // 00 This frame contains an ACK of a synchronization message in RSN#1, no NACKs
         case FU10C_NA_SYNC:
         // 11 This frame contains 6 NACK messages
         case FU10C_NA_6NACK:
         default:
            break;
         
      }
      index += (PDU_FU10C_HEADER_LEN + PDU_FU10AC_OFFSET);
   }

   return( index - 1 );
}
#endif //#ifdef CATIQ_UPLANE_FU10_NEW_STD

#endif // #ifdef CATIQ   
