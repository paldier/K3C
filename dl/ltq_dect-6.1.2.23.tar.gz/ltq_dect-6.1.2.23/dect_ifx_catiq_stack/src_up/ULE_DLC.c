/* =======================================================================
 * Copyright (C) 2013 LANTIQ. All rights reserved.
 * Copyright (C) 2013 INTNIX. All rights reserved.
 * ======================================================================= */

/* =======================================================================
 * File:                   ULE_DLC.c
 *
 * Programmer:
 * Created:                2013-06-03
 *
 * Description:
 * Module:
 * Controlling Document:
 * System Dependencies:
 *
 * Remarks:
 * ======================================================================= */

/* =======================================================================
 * Include Files
 * ======================================================================= */
#include <stdio.h>

#include "DEFINE.H"                    /* Compiler switchs                 */
#include "SYSDEF.H"
#include "DECT_UP.H"
#include "DECT.H"
#include "MMU.H"
#include "CAT_UP.H"
#include "CONF_CP.H"
#include "uplane_if.h"
#include "MESSAGE_DEF.H"
#include "CP_SERVER.H"
#include "FDEF.H"
#include "KNL_SYSTEM.H"
#include "MM_LIB.H"
#ifdef ULE_SUPPORT
#include "ULE_DLC.h"

/* =======================================================================
 * External Reference
 * ======================================================================= */
IMPORT FPTR Subscription_GetTPUIRef(BYTE);
IMPORT FPTR Get_Rfpi_Ptr(void);
IMPORT BYTE Subscription_GetPortableNoFromPMID(FPTR pmid_ptr);
IMPORT BYTE ULE_Lu14SduEncryption(BYTE * key , BYTE * pmidPtr, BYTE * rfpiPtr, BYTE * sn, WORD dataLength, FPTR inPtr, FPTR outPtr);
IMPORT BYTE ULE_Lu14SduDecryption(BYTE * key , BYTE * pmidPtr, BYTE * rfpiPtr, BYTE * sn, WORD dataLength, FPTR inPtr, FPTR outPtr);
IMPORT void write_to_hmac_ioctl(BYTE procid,
                                BYTE msgnr,
                                BYTE param1, BYTE param2, BYTE param3, BYTE param4,
                                BYTE param5, BYTE param6, FPTR pdata,
                                BYTE inc);

/* =======================================================================
 * Definitions
 * ======================================================================= */
#define CONFIG_UPDATE_OTHER_HANDLING

#define ULE_SDU_MIC_SIZE               4

#define MAX_ULE_SDU_SIZE               500
#define MAX_ULE_ENCRYPT_SDU_SIZE       (MAX_ULE_SDU_SIZE + ULE_SDU_MIC_SIZE)
#define MAX_ULE_PDU_SIZE               38

#define ULE_PDU_HEADER_SIZE            2
#define ULE_PDU_DATA_SIZE              36

#ifdef SMART_HOME_DEMO
uint32 SBBflg=0;
#define HAN_FUN_REG_REQUEST_LENGTH 29
#define HAN_FUN_REG_RESPONSE_LENGTH 18
#endif

#ifdef CONFIG_TEST_DIALOG_LIMITED_TPUI
#define GET_BIT_OFFSET(p) (p - ULE_DEVICE_OFFSET + 1) // 1 ~ n
#else
#define GET_BIT_OFFSET(p) Subscription_GetBitOffset(p)
#endif

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */
// ULE DLC Link Status Flags
enum {
   ULE_DLC_LINK_STATUS_OPEN_FLAG = BIT0,
   ULE_DLC_LINK_STATUS_PP_READY_FOR_RELEASE_FLAG = BIT1,
   ULE_DLC_LINK_STATUS_WAIT_FOR_ACK_FLAG = BIT2,
   ULE_DLC_LINK_STATUS_RX_RESPONSE_FLAG = BIT3,
   ULE_DLC_LINK_STATUS_WAIT_FOR_RELEASE_FLAG = BIT4,
   #ifdef CONFIG_UPDATE_OTHER_HANDLING
   ULE_DLC_LINK_STATUS_OTHER_RECEIVED_FLAG = BIT5, // MAC connection indication flag
   #endif
};
typedef BYTE ULEDLCLinkStatusFlags_e;

// ULE DLC Open Error
enum {
   ULE_DLC_OPEN_ERROR_NONE = 0,
   ULE_DLC_OPEN_ERROR_WRONG_PMID
};
typedef BYTE ULEDLCOpenError_e;

// ULE DLC Error
enum {
   ULE_DLC_ERROR_NONE = 0,
   ULE_DLC_ERROR_OUT_OF_RANGE,
   ULE_DLC_ERROR_WRONG_RECEIVED_DATA,
   ULE_DLC_ERROR_NO_SUCH_CONNECTION,
   ULE_DLC_ERROR_DATA_NOT_PROCESSED // Exception case to protect call is hung on
};
typedef BYTE ULEDLCError_e;

// ULE DLC Data Status Flags
enum {
   ULE_DLC_DATA_STATUS_FIRST_RSN_RECEIVED_FLAG = BIT0, // RX instance receives the first PDU of the SDU.
   ULE_DLC_DATA_STATUS_TX_USED_FLAG = BIT1, // TX instance is used.
   ULE_DLC_DATA_STATUS_TX_LAST_PDU_FLAG = BIT2, // The last PDU of the SDU is sent.
   ULE_DLC_DATA_STATUS_TX_STOP_REQUIRED_FLAG = BIT3 // TX instance receives transmission stop request message.
};
typedef BYTE ULEDLCDataStatusFlags_e;

typedef struct {
   WORD dataLength;
   BYTE dataBuffer[MAX_ULE_ENCRYPT_SDU_SIZE];
} ULEDLCBufferData_t;

typedef struct {
   ULEDLCBufferData_t txBuffer;
   BOOL ccmNotRequired; 
} ULEDLCDeviceData_t;

typedef struct {
   BYTE SSN[ULE_DLC_SN_SIZE];
   WORD sentDataLength;
   WORD dataLength;
   FPTR dataPtr;
   FPTR tempDataPtr;
} ULEDLCDeviceTXInstanceData_t;

typedef struct {
   BYTE firstRSN[ULE_DLC_SN_SIZE]; // SN of first PDU
   BYTE RSN[ULE_DLC_SN_SIZE];
   BYTE releaseReason;
   BYTE releaseInfo;
   WORD dataLength;
   FPTR dataPtr;
} ULEDLCDeviceRXInstanceData_t;

typedef struct {
   BYTE slotNo;
   BYTE PMID[3];
   ULEDLCOpenError_e openError;
   ULEDLCError_e error;
   BYTE windowSize;
   ULEDLCDataStatusFlags_e dataStatusFlags;

   // for the transmitting part
   ULEDLCDeviceTXInstanceData_t txInstance;
   // for the receiving part
   ULEDLCDeviceRXInstanceData_t rxInstance;
} ULEDLCDeviceInstanceData_t;

#ifdef DECT_DEBUG_USER_DLC_ULE_PRIMITIVE
typedef struct {
	BYTE key;
	char *string;
} DebugStringTable_t;
#endif

/* =======================================================================
 * Local Variables
 * ======================================================================= */
/* -----------------------------------------------------------------------
 * Name: LocalVar
 * Description:
 * ----------------------------------------------------------------------- */
LOCAL ULEDLCDeviceData_t XDATA device[NR_OF_ULE_DEVICE];
LOCAL ULEDLCDeviceInstanceData_t XDATA deviceInstance[MAX_LINK];
LOCAL ULEDLCLinkStatusFlags_e ULEDLCLinkStatusFlags[6];

#ifdef DECT_DEBUG_USER_DLC_ULE_PRIMITIVE
LOCAL DebugStringTable_t messageStringTable[] = {
   {HMAC_ULE_FU10_ACC_IND, "HMAC_ULE_FU10_ACC_IND"},
   {HMAC_ULE_FU10_ACC_RDY_REL_IND, "HMAC_ULE_FU10_ACC_RDY_REL_IND"},
   {HMAC_ULE_FU10_RDY_REL_IND, "HMAC_ULE_FU10_RDY_REL_IND"},
   {HMAC_ULE_FU10_DATA_IND, "HMAC_ULE_FU10_DATA_IND"},
   {HMAC_ULE_FU10_GFA_IND, "HMAC_ULE_FU10_GFA_IND"},
   {HMAC_ULE_FU10_REL_IND, "HMAC_ULE_FU10_REL_IND"},
   {HMAC_ULE_FU10_DTR_IND, "HMAC_ULE_FU10_DTR_IND"},
   {HMAC_ULE_FU10_LINK_REL_IND, "HMAC_ULE_FU10_LINK_REL_IND"},
   {HMAC_ULE_FU10_OTHER_IND, "HMAC_ULE_FU10_OTHER_IND"},
	{0xFF, "Unknown Message"}
};
#endif

#ifdef CONFIG_TEST_TX_PACKET_SENDING_DURING_ULE_OPEN
#if 1
LOCAL BYTE ULETestDataPacket[32] = {
   0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
   0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x00
};
#else
LOCAL BYTE ULETestDataPacket[68] = {
   0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
   0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f,
   0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f,
   0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f,
   0x40, 0x41, 0x42, 0x00,
};
#endif
#endif

/* =======================================================================
 * Global Variables
 * ======================================================================= */

/* =======================================================================
 * Local Function Prototypes
 * ======================================================================= */
/* -----------------------------------------------------------------------
 * Function    :
 * Descriptions: Open DLC for data transmit/receive
 * Parameters  : aMCEI - MCEI
 *               aPMIDPtr - Pointer to PMID
 * Return Value: YES / NO
 * Remarks     :
 * Requirments :
 * Call Level  :
 * ----------------------------------------------------------------------- */
LOCAL BOOL openDLC(BYTE aMCEI, BYTE *aPMIDPtr);
/* -----------------------------------------------------------------------
 * Function    :
 * Descriptions: Close DLC for data transmit/receive
 * Parameters  : aMCEI - MCEI
 *               normalRelease - Indicate if the release message is received or not
 * Return Value: None
 * Remarks     :
 * Requirments :
 * Call Level  :
 * ----------------------------------------------------------------------- */
#ifdef CONFIG_UPDATE_OTHER_HANDLING
LOCAL void closeDLC(BYTE aMCEI, BOOL normalRelease);
#else
LOCAL void closeDLC(BYTE aMCEI);
#endif
/* -----------------------------------------------------------------------
 * Function    :
 * Descriptions: Get PDU transmitted
 * Parameters  : aMCEI - MCEI
 *               dataPtr - Pointer to TX buffer
 *               lastPDUPtr - Upon return, the returned value is YES if the PDU is the last
 *
 * Return Value: YES / NO
 *               YES - PDU is existed.
 *               NO - PDU is not exised.
 * Remarks     :
 * Requirments :
 * Call Level  :
 * ----------------------------------------------------------------------- */
LOCAL BOOL getFU10TXPDU(BYTE aMCEI, BYTE * dataPtr, BOOL * lastPDUPtr);
/* -----------------------------------------------------------------------
 * Function    :
 * Descriptions: Notified FU10 TX data is acknowledged.
 * Parameters  : aMCEI - MCEI
 * Return Value: None
 * Remarks     :
 * Requirments :
 * Call Level  :
 * ----------------------------------------------------------------------- */
LOCAL void aFU10TXPDUAcknowledged(BYTE aMCEI);
/* -----------------------------------------------------------------------
 * Function    :
 * Descriptions: Get current RSN (Receive Sequence Number).
 * Parameters  : aMCEI - MCEI
 * Return Value: RSN
 * Remarks     :
 * Requirments :
 * Call Level  :
 * ----------------------------------------------------------------------- */
LOCAL BYTE getFU10RSN(BYTE aMCEI);
/* -----------------------------------------------------------------------
 * Function    :
 * Descriptions: Notified FU10 PDU data is recieved. PDU data is processed.
 * Parameters  : aMCEI - MCEI
 *               dataPtr - Pointer to data buffer received.
 *               firstData - Indicate data is first after link is opened.
 * Return Value: RSN (Receive Sequence Number)
 * Remarks     :
 * Requirments :
 * Call Level  :
 * ----------------------------------------------------------------------- */
LOCAL BYTE aFU10PDUReceived(BYTE aMCEI, BYTE * dataPtr);
LOCAL void increaseSN(BYTE * aSNPtr, BOOL excludesLSB);

/* =======================================================================
 * Local Function Definitions
 * ======================================================================= */
LOCAL BOOL openDLC(BYTE aMCEI, BYTE *aPMIDPtr)
{
   BYTE portableNo;
   BYTE slotNo;
   ULEDLCDeviceInstanceData_t XDATA * deviceInstancePtr;

   deviceInstancePtr = &deviceInstance[aMCEI];

   deviceInstancePtr->error = ULE_DLC_ERROR_NONE;
   deviceInstancePtr->openError = ULE_DLC_OPEN_ERROR_NONE;

   if (aPMIDPtr[0] == 0x0E) {
      deviceInstancePtr->openError = ULE_DLC_OPEN_ERROR_WRONG_PMID;
      return FALSE;
   }

   portableNo = Subscription_GetPortableNoFromPMID(aPMIDPtr);
   #ifdef KLOCWORK
   if (!VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (!IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      deviceInstancePtr->openError = ULE_DLC_OPEN_ERROR_WRONG_PMID;
      return FALSE;
   }

   if (!Subscription_ResumesULENWK(portableNo)) {
      deviceInstancePtr->error = ULE_DLC_ERROR_NO_SUCH_CONNECTION;
   }

   slotNo = portableNo - ULE_DEVICE_OFFSET;

   deviceInstancePtr->slotNo = slotNo;
   Mmu_Memcpy(deviceInstancePtr->PMID, aPMIDPtr, 3);
   deviceInstancePtr->windowSize = Subscription_GetWindowSize(portableNo);
   deviceInstancePtr->dataStatusFlags = 0;

   #ifdef KLOCWORK
   {  BYTE XDATA * ptr;
      ptr = Subscription_GetRSNRef(portableNo);
      if(ptr != NULL)
      Mmu_Memcpy(deviceInstancePtr->rxInstance.RSN, ptr, ULE_DLC_SN_SIZE);
   }
   #else
   Mmu_Memcpy(deviceInstancePtr->rxInstance.RSN, Subscription_GetRSNRef(portableNo), ULE_DLC_SN_SIZE);
   #endif
   deviceInstancePtr->rxInstance.releaseReason = ADV2_REL_REASON_NORMAL_REL;
   deviceInstancePtr->rxInstance.releaseInfo = 0;
   deviceInstancePtr->rxInstance.dataLength = 0;
   deviceInstancePtr->rxInstance.dataPtr = Mmu_Malloc(MAX_ULE_ENCRYPT_SDU_SIZE);

   #ifdef KLOCWORK
   {  BYTE XDATA * ptr;
      ptr = Subscription_GetSSNRef(portableNo);
      if(ptr != NULL)
      Mmu_Memcpy(deviceInstancePtr->txInstance.SSN, ptr, ULE_DLC_SN_SIZE);
   }
   #else
   Mmu_Memcpy(deviceInstancePtr->txInstance.SSN, Subscription_GetSSNRef(portableNo), ULE_DLC_SN_SIZE);
   #endif
   deviceInstancePtr->txInstance.sentDataLength = 0;
   deviceInstancePtr->txInstance.dataLength = 0;
   if (device[slotNo].txBuffer.dataLength) {
      if (device[slotNo].ccmNotRequired) {
         deviceInstancePtr->dataStatusFlags |= ULE_DLC_DATA_STATUS_TX_USED_FLAG;
         deviceInstancePtr->txInstance.dataLength = device[slotNo].txBuffer.dataLength;
         deviceInstancePtr->txInstance.dataPtr = Mmu_Malloc(deviceInstancePtr->txInstance.dataLength);
   #ifdef KLOCWORK
         if(deviceInstancePtr->txInstance.dataPtr != NULL)
   #endif
         {
            Mmu_Memcpy(deviceInstancePtr->txInstance.dataPtr, device[slotNo].txBuffer.dataBuffer, deviceInstancePtr->txInstance.dataLength);
         }
      } else {
         deviceInstancePtr->txInstance.dataPtr = Mmu_Malloc(device[slotNo].txBuffer.dataLength + ULE_SDU_MIC_SIZE);
         if (ULE_Lu14SduEncryption(Subscription_GetDCKCCMRef(portableNo),
                                   Subscription_GetTPUIRef(portableNo),
                                   Get_Rfpi_Ptr(),
                                   Subscription_GetSSNRef(portableNo),
                                   device[slotNo].txBuffer.dataLength,
                                   device[slotNo].txBuffer.dataBuffer,
                                   deviceInstancePtr->txInstance.dataPtr)) {
            deviceInstancePtr->dataStatusFlags |= ULE_DLC_DATA_STATUS_TX_USED_FLAG;
            deviceInstancePtr->txInstance.dataLength = device[slotNo].txBuffer.dataLength + ULE_SDU_MIC_SIZE;
         } else {
            Mmu_Free(deviceInstancePtr->txInstance.dataPtr);
            deviceInstancePtr->txInstance.dataPtr = NULL;
         }
      }
   }

   // clear device buffer
   device[slotNo].txBuffer.dataLength = 0;
   device[slotNo].ccmNotRequired = NO;

   return TRUE;
}

#ifdef CONFIG_UPDATE_OTHER_HANDLING
LOCAL void closeDLC(BYTE aMCEI, BOOL normalRelease)
#else
LOCAL void closeDLC(BYTE aMCEI)
#endif
{
   ULEDLCDeviceInstanceData_t XDATA * deviceInstancePtr;

   deviceInstancePtr = &deviceInstance[aMCEI];

   // Update SN:
   // - If normal call release, SN will be updated without checking MAC connection
   // - If abnormal call release, SN will be updated if MAC connection is confirmed.
   //   . This is actually for RSN. It is also OK for SSN.
   #ifdef CONFIG_UPDATE_OTHER_HANDLING
   if (normalRelease || (ULEDLCLinkStatusFlags[aMCEI] & ULE_DLC_LINK_STATUS_OTHER_RECEIVED_FLAG))
   #endif
   {
      Subscription_SetSN(deviceInstancePtr->txInstance.SSN, deviceInstancePtr->rxInstance.RSN, deviceInstancePtr->slotNo + ULE_DEVICE_OFFSET);
   }

   // Free memory allocation
   Mmu_Free(deviceInstancePtr->rxInstance.dataPtr);
   if (deviceInstancePtr->txInstance.dataPtr != NULL) {
      Mmu_Free(deviceInstancePtr->txInstance.dataPtr);
   }
   if (deviceInstancePtr->txInstance.tempDataPtr != NULL) {
      Mmu_Free(deviceInstancePtr->txInstance.tempDataPtr);
   }

   // Reset instance
   Mmu_Memset((FPTR)deviceInstancePtr, 0, sizeof(ULEDLCDeviceInstanceData_t));
}

LOCAL BOOL getFU10TXPDU(BYTE aMCEI, BYTE * dataPtr, BOOL * lastPDUPtr)
{
   WORD dataSize;
   ULEDLCDeviceInstanceData_t XDATA * deviceInstancePtr;

   deviceInstancePtr = &deviceInstance[aMCEI];

   // if nothing to send data
   if (deviceInstancePtr->txInstance.sentDataLength == deviceInstancePtr->txInstance.dataLength) {
      return FALSE;
   }

   // compare data size with 1 PDU size
   dataSize = deviceInstancePtr->txInstance.dataLength - deviceInstancePtr->txInstance.sentDataLength;
   if (dataSize > ULE_PDU_DATA_SIZE) {
      dataSize = ULE_PDU_DATA_SIZE;
      *lastPDUPtr = NO;
   } else {
      *lastPDUPtr = YES;
   }

   // FU10 Header
   // SN low byte
   dataPtr[0] =  deviceInstancePtr->txInstance.SSN[5];
   // SN hi 1bit | pdu length | more bit
   dataPtr[1] =  ((deviceInstancePtr->txInstance.SSN[4] & 0x01) << 7) | (dataSize << 1) | (*lastPDUPtr ^ YES);
   // FU10 Data
   Mmu_Memcpy(&dataPtr[ULE_PDU_HEADER_SIZE], &deviceInstancePtr->txInstance.dataPtr[deviceInstancePtr->txInstance.sentDataLength], dataSize);
   // fill null char
   if (dataSize < ULE_PDU_DATA_SIZE) {
      Mmu_Memset(&dataPtr[ULE_PDU_HEADER_SIZE + dataSize], 0xF0, ULE_PDU_DATA_SIZE - dataSize);
   }

   // Update the variables for TX instance
   if (*lastPDUPtr) {
      deviceInstancePtr->dataStatusFlags |= ULE_DLC_DATA_STATUS_TX_LAST_PDU_FLAG;
   }
   deviceInstancePtr->txInstance.sentDataLength += dataSize;

   increaseSN(deviceInstancePtr->txInstance.SSN, NO);

   return TRUE;
}

LOCAL void increaseSN(BYTE * aSNPtr, BOOL excludesLSB)
{
   BOOL overflows;

   overflows = NO;
   if (excludesLSB == NO) {
      if ((++aSNPtr[5]) == 0) {
         overflows = YES;
      }
   }

   if (overflows || excludesLSB) {
      if ((++aSNPtr[4]) == 0) {
         if ((++aSNPtr[3]) == 0) {
            if ((++aSNPtr[2]) == 0) {
               if ((++aSNPtr[1]) == 0) {
                  ++aSNPtr[0];
               }
            }
         }
      }
   }
}

LOCAL void sendUpTXResult(BYTE aMCEI, BYTE aRSN, BOOL normalRelease)
{
   BYTE portableNo;
   BYTE result = FALSE;
   ULEDLCDeviceInstanceData_t XDATA * deviceInstancePtr;

   deviceInstancePtr = &deviceInstance[aMCEI];

   if (!(deviceInstancePtr->dataStatusFlags & ULE_DLC_DATA_STATUS_TX_USED_FLAG)) {
      return;
   }

   if (normalRelease && (deviceInstancePtr->txInstance.SSN[5] == aRSN)) {
      result = TRUE;
   }

   portableNo = deviceInstancePtr->slotNo + ULE_DEVICE_OFFSET;
   DECT_DEBUG_USER_DLC_ULE_RX_TX_DATA(IFX_DBG_Printf("[ULE] SDU TX Result Sent: %02x %02x\n", portableNo, result));
   Send_UPMessage_To_APP(FP_ULE_MEDIA_SDU_FLOW_IN, NULL, 0,
                         result, 0, 0, portableNo);

   if (deviceInstancePtr->dataStatusFlags & ULE_DLC_DATA_STATUS_TX_STOP_REQUIRED_FLAG) {
      Send_UPMessage_To_APP(FP_ULE_MEDIA_SDU_STOP_CFM, NULL, 0,
                            0, 0, 0, portableNo);
   }
}

LOCAL void sendUpRXIndication(BYTE aMCEI, BYTE * dataPtr, WORD dataLength)
{
   BYTE portableNo;
   ULEDLCDeviceInstanceData_t XDATA * deviceInstancePtr;

   deviceInstancePtr = &deviceInstance[aMCEI];

   if (deviceInstancePtr->error != ULE_DLC_ERROR_NONE) {
      return;
   }

   portableNo = deviceInstancePtr->slotNo + ULE_DEVICE_OFFSET;
   Send_UPMessage_To_APP(FP_ULE_MEDIA_SDU_RCV_IN, dataPtr, aMCEI,
                         (BYTE)(dataLength>>8),  (BYTE)dataLength, 0 ,portableNo);
}

LOCAL void aFU10TXPDUAcknowledged(BYTE aMCEI)
{
   aMCEI = aMCEI;
}

LOCAL BYTE getFU10RSN(BYTE aMCEI)
{
   return (deviceInstance[aMCEI].rxInstance.RSN[5]);
}

LOCAL BYTE aFU10PDUReceived(BYTE aMCEI, BYTE * dataPtr)
{
   BYTE XDATA * keyPtr;
   BYTE XDATA * rfpiPtr;
   BYTE XDATA * decDataPtr;
   #ifdef SMART_HOME_DEMO
   BYTE XDATA * aPMIDPtr;
   #endif
   WORD decDataLength;
   BYTE portableNo;
   BYTE aRSN; // SN of the last recevied PDU
   BYTE receivedRSN; // SN of the current received PDU
   BOOL morePDU;
   BYTE dataLength;
   BYTE windowSize;
   WORD range;
   BYTE error = FALSE;
   ULEDLCDeviceInstanceData_t XDATA * deviceInstancePtr;

   deviceInstancePtr = &deviceInstance[aMCEI];

   // if ULE is suspend mode
   if (deviceInstancePtr->error == ULE_DLC_ERROR_NO_SUCH_CONNECTION) {
      DECT_DEBUG_USER_DLC_ULE_RX_TX_DATA(IFX_DBG_Printf("[ULE] ULE_DLC_ERROR_NO_SUCH_CONNECTION %02x\n",deviceInstancePtr->rxInstance.firstRSN[5]));
      return (deviceInstancePtr->rxInstance.RSN[5]);
   }

   receivedRSN = dataPtr[0];
   morePDU = dataPtr[1] & BIT0;
   dataLength = (dataPtr[1] & 0x7E) >> 1;
   // Even the wrong data size, the data is processed to notify ULE device about error.
   if (dataLength > ULE_PDU_DATA_SIZE) {
      dataLength = ULE_PDU_DATA_SIZE;
   }

   aRSN = deviceInstancePtr->rxInstance.RSN[5];
   if (deviceInstancePtr->windowSize > 0) {
      windowSize = deviceInstancePtr->windowSize-1;
   } else {
      windowSize = 0;
   }
   range = ((WORD)aRSN + windowSize);

   // Check if RSN is out of range
   if (range > 0xFF) {
      if (receivedRSN < windowSize) {
         if (receivedRSN > (range & 0xFF)) {
            error = TRUE;
         }
      } else {
         if (receivedRSN < aRSN) {
            error = TRUE;
         }
      }
   } else {
      if ((receivedRSN < aRSN) || (receivedRSN > range)) {
         error = TRUE;
      }
   }

   if (error) {
      deviceInstancePtr->error = ULE_DLC_ERROR_OUT_OF_RANGE;
      DECT_DEBUG_USER_DLC_ULE_RX_TX_DATA(IFX_DBG_Printf("[ULE] ULE_DLC_ERROR_OUT_OF_RANGE %02x\n",deviceInstancePtr->rxInstance.firstRSN[5]));
      return (deviceInstancePtr->rxInstance.RSN[5]);
   }

   // If the received RSN is not same, FP's RSN is updated with the received RSN.
   // Even same, FP's RSN will be updated just to save code.
   if (aRSN > receivedRSN) {  // if the received SN is overflow
      increaseSN(deviceInstancePtr->rxInstance.RSN, YES);
   }
   aRSN = deviceInstancePtr->rxInstance.RSN[5] = receivedRSN;

   if (!(deviceInstancePtr->dataStatusFlags & ULE_DLC_DATA_STATUS_FIRST_RSN_RECEIVED_FLAG)) {
      deviceInstancePtr->dataStatusFlags |= ULE_DLC_DATA_STATUS_FIRST_RSN_RECEIVED_FLAG;
      Mmu_Memcpy(deviceInstancePtr->rxInstance.firstRSN, deviceInstancePtr->rxInstance.RSN, ULE_DLC_SN_SIZE);
   }

   Mmu_Memcpy(&deviceInstancePtr->rxInstance.dataPtr[deviceInstancePtr->rxInstance.dataLength], &dataPtr[ULE_PDU_HEADER_SIZE], dataLength);
   deviceInstancePtr->rxInstance.dataLength += dataLength;

   if (!morePDU) {  // last data received
      portableNo = deviceInstancePtr->slotNo + ULE_DEVICE_OFFSET;
      keyPtr = Subscription_GetDCKCCMRef(portableNo);
      rfpiPtr = Get_Rfpi_Ptr();
      decDataPtr = Mmu_Malloc(deviceInstancePtr->rxInstance.dataLength);
	   #ifdef KLOCWORK
	   if (decDataPtr != NULL)
	  	{
	   #endif
         // Decryption data(CCM)
      #ifdef CONFIG_TEST_ULE_NO_CCM
      if (1)
      #else
         if (ULE_Lu14SduDecryption(keyPtr,
                                   deviceInstancePtr->PMID,
                                   rfpiPtr,
                                   deviceInstancePtr->rxInstance.firstRSN,
                                   deviceInstancePtr->rxInstance.dataLength,
                                   deviceInstancePtr->rxInstance.dataPtr, decDataPtr))
      #endif
      {
         #ifdef CONFIG_TEST_ULE_NO_CCM
         Mmu_Memcpy(decDataPtr, deviceInstancePtr->rxInstance.dataPtr, deviceInstancePtr->rxInstance.dataLength);
         decDataLength = deviceInstancePtr->rxInstance.dataLength;
         #else
         decDataLength = deviceInstancePtr->rxInstance.dataLength - ULE_SDU_MIC_SIZE;
         #endif

            DECT_DEBUG_USER_DLC_ULE_RX_TX_DATA({
               WORD i;
               IFX_DBG_Printf("[ULE] RX Data: %02x %04x\n", deviceInstancePtr->rxInstance.firstRSN[5], decDataLength);
               for (i = 0; i < decDataLength; i++) {
                  if (i != 0 && (i % 32) == 0) {
                     IFX_DBG_Printf("\n");
                  }
                  IFX_DBG_Printf(" %02x", decDataPtr[i]);
               }
               IFX_DBG_Printf("\n");
            });

            #ifdef SMART_HOME_DEMO
            {
               int32 IFX_DECT_ULE_Check_HAN_FUN_Reg(IN uchar8 ucInstanceId, IN uchar8 *pucRegMsg, OUT uchar8 *pucRegRsp);
               BYTE regData[HAN_FUN_REG_RESPONSE_LENGTH];

               if ((decDataLength == HAN_FUN_REG_REQUEST_LENGTH) &&
                   (IFX_DECT_ULE_Check_HAN_FUN_Reg(portableNo, decDataPtr, regData) == 0)) {
                  SBBflg=1;
                  // Get PMID
                  aPMIDPtr = Subscription_GetTPUIRef(portableNo);
                  if (deviceInstancePtr->txInstance.dataPtr != NULL) {
                     Mmu_Free(deviceInstancePtr->txInstance.dataPtr);
                  }
                  deviceInstancePtr->txInstance.dataLength = HAN_FUN_REG_RESPONSE_LENGTH + ULE_SDU_MIC_SIZE;
                  deviceInstancePtr->txInstance.dataPtr = Mmu_Malloc(deviceInstancePtr->txInstance.dataLength);
                  ULE_Lu14SduEncryption(keyPtr,
                                        aPMIDPtr,
                                        rfpiPtr,
                                        Subscription_GetSSNRef(portableNo),
                                        HAN_FUN_REG_RESPONSE_LENGTH,
                                        regData,
                                        deviceInstancePtr->txInstance.dataPtr);
                  deviceInstancePtr->rxInstance.releaseReason = ADV2_REL_REASON_NORMAL_REL;
                  deviceInstancePtr->rxInstance.releaseInfo = 0;
                  ULEDLCLinkStatusFlags[aMCEI] |= ULE_DLC_LINK_STATUS_RX_RESPONSE_FLAG;
                  DECT_DEBUG_USER_DLC_ULE_RX_TX_DATA(IFX_DBG_Printf("[ULE] RX Data: HAN-FUN-REG Req\n"));
               } else {
                  // send data to High layer
                  sendUpRXIndication(aMCEI, decDataPtr, decDataLength);
               }
            }
            #else
            // send data to High layer
            sendUpRXIndication(aMCEI, decDataPtr, decDataLength);
            #endif
         } else {
            if (deviceInstancePtr->error == ULE_DLC_ERROR_NONE) {
               deviceInstancePtr->error = ULE_DLC_ERROR_WRONG_RECEIVED_DATA;
            }
            DECT_DEBUG_USER_DLC_ULE_RX_TX_DATA(IFX_DBG_Printf("[ULE] RX Data: %02x %04x, Fail\n", deviceInstancePtr->rxInstance.firstRSN[5], deviceInstancePtr->rxInstance.dataLength));
         }
         deviceInstancePtr->dataStatusFlags &= ~ULE_DLC_DATA_STATUS_FIRST_RSN_RECEIVED_FLAG;
         deviceInstancePtr->rxInstance.dataLength = 0;
         Mmu_Free(decDataPtr);
      #ifdef KLOCWORK
      }
      #endif
   }

   increaseSN(deviceInstancePtr->rxInstance.RSN, NO);
   return (deviceInstancePtr->rxInstance.RSN[5]);
}

LOCAL BOOL isErrorHappened(BYTE aMCEI)
{
   if (deviceInstance[aMCEI].error != ULE_DLC_ERROR_NONE)
      return TRUE;
   return FALSE;
}

LOCAL void storeFU10LastTXPDU(BYTE aMCEI, FPTR dataPtr)
{
   ULEDLCDeviceInstanceData_t XDATA * deviceInstancePtr;

   deviceInstancePtr = &deviceInstance[aMCEI];

   deviceInstancePtr->txInstance.tempDataPtr = Mmu_Malloc(MAX_ULE_PDU_SIZE);
   #ifdef KLOCWORK
   if(deviceInstancePtr->txInstance.tempDataPtr != NULL )
   #endif
   {
      Mmu_Memcpy(deviceInstancePtr->txInstance.tempDataPtr, dataPtr, MAX_ULE_PDU_SIZE);
   }
}

LOCAL void sendFU10ReadyRelease(BYTE aMCEI, BYTE *dataPtr)
{
   BYTE portableNo;
   BOOL indicatesDLCError;
   ULEDLCDeviceInstanceData_t XDATA * deviceInstancePtr;

   deviceInstancePtr = &deviceInstance[aMCEI];

   indicatesDLCError = NO;
   if ((deviceInstancePtr->error == ULE_DLC_ERROR_OUT_OF_RANGE) ||
       (deviceInstancePtr->error == ULE_DLC_ERROR_WRONG_RECEIVED_DATA)) {
      deviceInstancePtr->rxInstance.releaseReason = ADV2_REL_REASON_SWITCH_CRKT_MODE;
      deviceInstancePtr->rxInstance.releaseInfo = 0x01;
      indicatesDLCError = YES;
   } else if (deviceInstancePtr->error == ULE_DLC_ERROR_NO_SUCH_CONNECTION) {
      deviceInstancePtr->rxInstance.releaseReason = ADV2_REL_REASON_VIRTUAL_CRKT;
      indicatesDLCError = YES;
   } else if (deviceInstancePtr->error == ULE_DLC_ERROR_DATA_NOT_PROCESSED) {
   	// For this case, nothing to do. Just ULE device is wrong.
      deviceInstancePtr->rxInstance.releaseReason = ADV2_REL_REASON_NORMAL_REL;
   }

   if (indicatesDLCError) {
      portableNo = deviceInstancePtr->slotNo + ULE_DEVICE_OFFSET;
      /* send up DLC error indication  */
      Send_UPMessage_To_APP(FP_ULE_MEDIA_DLC_ERROR_IN, NULL, 0,
                            deviceInstancePtr->rxInstance.releaseReason,
                            deviceInstancePtr->rxInstance.releaseInfo,
                            0,
                            portableNo);
   }

   write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_RDY_REL_REQ,
                       deviceInstancePtr->rxInstance.releaseReason,
                       deviceInstancePtr->rxInstance.releaseInfo,
                       getFU10RSN(aMCEI),  // RSN
                       0, // -
                       0, dataPtr[0]+1, dataPtr,
                       aMCEI);
}

LOCAL void sendFU10OpenError(BYTE aMCEI)
{
   BYTE aRn = 0;
   BYTE reason = ADV2_REL_REASON_NORMAL_REL;

   if (deviceInstance[aMCEI].openError == ULE_DLC_OPEN_ERROR_WRONG_PMID) {
      reason = ADV2_REL_REASON_WRONG_PMID;
   }

   write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_REL_REQ,
                       reason, // Reason
                       0, // Info
                       aRn, // RSN
                       0, // -
                       0, 0, NULL,
                       aMCEI);
}

#ifdef DECT_DEBUG_USER_DLC_ULE_PRIMITIVE
LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
{
	BYTE i;

	for (i = 0; tablePtr[i].key != 0xFF; i++) {
		if (tablePtr[i].key == key) {
			break;
		}
	}
	return tablePtr[i].string;
}
#endif

/* =======================================================================
 * Global Function Definitions
 * ======================================================================= */
EXPORT void
ULEDLC_Init(void)
{
   BYTE i;

   for (i=0; i<NR_OF_ULE_DEVICE; i++)
   {
      Mmu_Memset((FPTR)&device[i], 0, sizeof(ULEDLCDeviceData_t));
   }

   for (i=0; i<MAX_LINK; i++) {
      Mmu_Memset((FPTR)&deviceInstance[i], 0, sizeof(ULEDLCDeviceInstanceData_t));
   }
}

/* -----------------------------------------------------------------------
 * Function    :
 * Descriptions: Sending SDU data
 * Parameters  : po_no : Portable Number
 *               dataLength : length of data
 *               dataPtr : pointer to Tx data
 * Return Value: YES / NO
 * Remarks     :
 * Requirments :
 * Call Level  :
 * ----------------------------------------------------------------------- */
EXPORT BYTE ULE_LU10SduTx(BYTE po_no, WORD dataLength, BYTE *dataPtr, BOOL encrypt)
{
   BYTE XDATA * keyPtr;
   BYTE XDATA * rfpiPtr;
   BYTE XDATA * aPMIDPtr;
   BYTE slotNo;
   #ifdef CONFIG_TX_PACKET_SENDING_DURING_ULE_OPEN
   BOOL lastPDU;
   BYTE aMCEI;
   FPTR buffer;
   ULEDLCLinkStatusFlags_e * linkStatusFlagsPtr;
   ULEDLCDeviceInstanceData_t XDATA * deviceInstancePtr;
   #endif

   // check portable numbber!
   #ifdef KLOCWORK
   if (!VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
   #else
   if (!IsValidPortableNo(po_no, PORTABLE_ULE)) {
   #endif
      return FALSE;
   }

   // Ule buffer position
   slotNo = po_no - ULE_DEVICE_OFFSET;

   // check if buffer is empty!
   if (device[slotNo].txBuffer.dataLength > 0) {
      return FALSE;
   }

   if (dataLength == 0) {
      return NO;
   }

   // Get DCK
   keyPtr = Subscription_GetDCKCCMRef(po_no);
   // Get PMID
   aPMIDPtr = Subscription_GetTPUIRef(po_no);
   // Get RFPI
   rfpiPtr = Get_Rfpi_Ptr();

//#if 0
   DECT_DEBUG_USER_DLC_ULE_RX_TX_DATA({
      WORD i;
      IFX_DBG_Printf("[ULE] TX Data: %02x %02x %04x\n", (Subscription_GetSSNRef(po_no))[4], (Subscription_GetSSNRef(po_no))[5], dataLength);
      for (i = 0; i < dataLength; i++) {
         if (i != 0 && (i % 32) == 0) {
            IFX_DBG_Printf("\n");
         }
         IFX_DBG_Printf(" %02x", dataPtr[i]);
      }
      IFX_DBG_Printf("\n");
   });
//#endif

   Mmu_Memcpy(device[slotNo].txBuffer.dataBuffer, dataPtr, dataLength);
   device[slotNo].txBuffer.dataLength = dataLength;
   #ifdef CONFIG_TEST_ULE_NO_CCM
   encrypt = encrypt;
   device[slotNo].ccmNotRequired = YES;
   #else
   if (!encrypt) {
      device[slotNo].ccmNotRequired = YES;
      } else {
      device[slotNo].ccmNotRequired = NO;
   }
   #endif

   #ifdef CONFIG_TX_PACKET_SENDING_DURING_ULE_OPEN
   /*
      Check points
      ------------
      1. check if DLC is open
      2. check if "wait for release" flag is not set
      3. check if "rx response" flag is not set
      4. check if the current TX data pointer is empty
    */

   linkStatusFlagsPtr = &ULEDLCLinkStatusFlags[0];
   deviceInstancePtr = &deviceInstance[0];
   for (aMCEI = 0; aMCEI < MAX_LINK; aMCEI++) {
      if ((*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_OPEN_FLAG) && (deviceInstancePtr->slotNo == slotNo)) {
         break;
      }
      linkStatusFlagsPtr++;
      deviceInstancePtr++;
   }

   if (aMCEI < MAX_LINK) {
      if (!(*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_WAIT_FOR_RELEASE_FLAG) &&
          !(*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_RX_RESPONSE_FLAG) &&
          !(deviceInstancePtr->dataStatusFlags & ULE_DLC_DATA_STATUS_TX_USED_FLAG)) {
         if (device[slotNo].ccmNotRequired) {
         deviceInstancePtr->dataStatusFlags |= ULE_DLC_DATA_STATUS_TX_USED_FLAG;
         deviceInstancePtr->txInstance.dataLength = device[slotNo].txBuffer.dataLength;
         deviceInstancePtr->txInstance.dataPtr = Mmu_Malloc(deviceInstancePtr->txInstance.dataLength);
         Mmu_Memcpy(deviceInstancePtr->txInstance.dataPtr, device[slotNo].txBuffer.dataBuffer, deviceInstancePtr->txInstance.dataLength);
         } else {
            deviceInstancePtr->txInstance.dataPtr = Mmu_Malloc(device[slotNo].txBuffer.dataLength + ULE_SDU_MIC_SIZE);
            #ifdef KLOCWORK
            if(aPMIDPtr == NULL || keyPtr == NULL) {
               return NO;
            }
            #endif
            if (ULE_Lu14SduEncryption(keyPtr,
                                      aPMIDPtr,
                                      rfpiPtr,
                                      Subscription_GetSSNRef(po_no),
                                      device[slotNo].txBuffer.dataLength,
                                      device[slotNo].txBuffer.dataBuffer,
                                      deviceInstancePtr->txInstance.dataPtr)) {
               deviceInstancePtr->dataStatusFlags |= ULE_DLC_DATA_STATUS_TX_USED_FLAG;
               deviceInstancePtr->txInstance.dataLength = device[slotNo].txBuffer.dataLength + ULE_SDU_MIC_SIZE;
            } else {
               Mmu_Free(deviceInstancePtr->txInstance.dataPtr);
               deviceInstancePtr->txInstance.dataPtr = NULL;

               // clear device buffer
               device[slotNo].txBuffer.dataLength = 0;
               device[slotNo].ccmNotRequired = NO;
               
               return NO;
            }
         }

         // clear device buffer
         device[slotNo].txBuffer.dataLength = 0;
         device[slotNo].ccmNotRequired = NO;

         // send PDU
         buffer = Mmu_Malloc(MAX_ULE_PDU_SIZE+1);
         #ifdef KLOCWORK
         if(buffer != NULL)
         #endif
         {
            getFU10TXPDU(aMCEI, &buffer[1], &lastPDU);
            *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_WAIT_FOR_ACK_FLAG;
            buffer[0] = MAX_ULE_PDU_SIZE;
            if (!lastPDU) { // middle packet
               write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_DATA_REQ,
                                   0, // -
                                   0, // -
                                   0, // -
                                   0, // -
                                   0, MAX_ULE_PDU_SIZE+1, buffer,
                                   aMCEI);
            } else { // last packet
               if (*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_PP_READY_FOR_RELEASE_FLAG) {
                  // Both are readied to release link. Wait for RX response message.
                  #if 1
                  storeFU10LastTXPDU(aMCEI, &buffer[1]);
                  Mmu_Free(buffer);
                  #else
                  write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_DATA_REQ,
                                      0, // -
                                      0, // -
                                      0, // -
                                      0, // -
                                      0, MAX_ULE_PDU_SIZE+1, buffer,
                                      aMCEI);
                  #endif
               } else {
                  write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_DATA_REQ,
                                      0, // -
                                      0, // -
                                      0, // -
                                      0, // -
                                      0, MAX_ULE_PDU_SIZE+1, buffer,
                                      aMCEI);
               }
            }
         }
      }
   }
   #endif

   return YES;
}

EXPORT void ULE_LU10SduTxStop(BYTE po_no)
{
   BYTE slotNo, aMCEI;
   ULEDLCLinkStatusFlags_e * linkStatusFlagsPtr;
   ULEDLCDeviceInstanceData_t XDATA * deviceInstancePtr;

   // check portable numbber!
   #ifdef KLOCWORK
   if (!VALID_PORTABLE_ULE(po_no, PORTABLE_ULE)) {
   #else
   if (!IsValidPortableNo(po_no, PORTABLE_ULE)) {
   #endif
      return;
   }

   slotNo = po_no - ULE_DEVICE_OFFSET;

   linkStatusFlagsPtr = &ULEDLCLinkStatusFlags[0];
   deviceInstancePtr = &deviceInstance[0];
   for (aMCEI = 0; aMCEI < MAX_LINK; aMCEI++) {
      if ((*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_OPEN_FLAG) && (deviceInstancePtr->slotNo == slotNo)) {
         break;
      }
      linkStatusFlagsPtr++;
      deviceInstancePtr++;
   }

   // Clear SDU TX
   device[slotNo].txBuffer.dataLength = 0;
   device[slotNo].ccmNotRequired = NO;
   
   if ((aMCEI < MAX_LINK) && (deviceInstancePtr->dataStatusFlags & ULE_DLC_DATA_STATUS_TX_USED_FLAG)) { // if DLC is activated
      deviceInstancePtr->dataStatusFlags |= ULE_DLC_DATA_STATUS_TX_STOP_REQUIRED_FLAG;
   } else {
      Send_UPMessage_To_APP(FP_ULE_MEDIA_SDU_STOP_CFM, NULL, 0,
                            0, 0, 0, po_no);
   }
}

EXPORT void ULE_LU10SduRXResponse(BYTE portableNo, BYTE releaseReason, BYTE releaseInfo)
{
   FPTR buffer;
   BYTE slotNo;
   BYTE aMCEI;
   ULEDLCLinkStatusFlags_e * linkStatusFlagsPtr;
   ULEDLCDeviceInstanceData_t XDATA * deviceInstancePtr;

   #ifdef KLOCWORK
   if (!VALID_PORTABLE_ULE(portableNo, PORTABLE_ULE)) {
   #else
   if (!IsValidPortableNo(portableNo, PORTABLE_ULE)) {
   #endif
      return;
   }

   #ifdef CONFIG_TEST_TX_PACKET_SENDING_DURING_ULE_OPEN
   ULE_LU10SduTx(portableNo, sizeof(ULETestDataPacket), ULETestDataPacket, 1);
   ULETestDataPacket[sizeof(ULETestDataPacket) - 1]++;
   #endif

   slotNo = portableNo - ULE_DEVICE_OFFSET;

   linkStatusFlagsPtr = &ULEDLCLinkStatusFlags[0];
   deviceInstancePtr = &deviceInstance[0];
   for (aMCEI = 0; aMCEI < MAX_LINK; aMCEI++) {
      if ((*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_OPEN_FLAG) && (deviceInstancePtr->slotNo == slotNo)) {
         break;
      }
      linkStatusFlagsPtr++;
      deviceInstancePtr++;
   }

   if (aMCEI < MAX_LINK) {
      deviceInstancePtr->rxInstance.releaseReason = releaseReason;
      deviceInstancePtr->rxInstance.releaseInfo = releaseInfo;
      if ((*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_PP_READY_FOR_RELEASE_FLAG) &&
          (deviceInstancePtr->txInstance.sentDataLength == deviceInstancePtr->txInstance.dataLength)) {
         *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_WAIT_FOR_RELEASE_FLAG;
         buffer = Mmu_Malloc(MAX_ULE_PDU_SIZE + 1);
         #ifdef KLOCWORK
         if(buffer != NULL)
         #endif
         {
            if (deviceInstancePtr->txInstance.tempDataPtr != NULL) {
               buffer[0] = MAX_ULE_PDU_SIZE;
               Mmu_Memcpy(&buffer[1], deviceInstancePtr->txInstance.tempDataPtr, MAX_ULE_PDU_SIZE);
               Mmu_Free(deviceInstancePtr->txInstance.tempDataPtr);
               deviceInstancePtr->txInstance.tempDataPtr = NULL;
            } else {
               buffer[0] = 0; // Length
            }
            write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_RDY_REL_REQ,
                                releaseReason, // Reason
                                releaseInfo, // Info
                                getFU10RSN(aMCEI),  // RSN
                                0, // -
                                0, buffer[0]+1, buffer,
                                aMCEI);
         }
      } else {
         *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_RX_RESPONSE_FLAG;
      }
   }
}

EXPORT BYTE ULE_PageStart(BYTE portableNo, BYTE pagingType)
{
   FPTR buffer;
   BYTE active;

   // If non-pageable device, return; This is just for safety
   if ((active = PageDescription_GetChannelActiveMask(portableNo)) == 0xFF) {
      return 0;
   }

   buffer = Mmu_Malloc(3);
   #ifdef KLOCWORK
   if(buffer != NULL)
   #endif
   {
      buffer[0] = 0;
      buffer[1] = GET_BIT_OFFSET(portableNo);
      buffer[2] = pagingType;
      write_to_hmac_ioctl(HMAC, MAC_ULE_PAGE_LB,
                          active, // Channel Active
                          PageDescription_GetChannelPeriodicity(portableNo), // Channel Periodicity
                          (BYTE)(PageDescription_GetStartMultiframeNumber(portableNo) >> 4), // Start MFM4
                          ((BYTE)(PageDescription_GetStartMultiframeNumber(portableNo) << 4)) | PageDescription_GetStartFrameNumber(portableNo), // Start MFM + Start FCNT
                          0, 3, buffer,
                          0);
   }
   return 1;
}

EXPORT BYTE ULE_PageStop(BYTE portableNo, BYTE pagingType)
{
   FPTR buffer;
   BYTE active;

   // If non-pageable device, return; This is just for safety
   if ((active = PageDescription_GetChannelActiveMask(portableNo)) == 0xFF) {
      return 0;
   }

   buffer = Mmu_Malloc(3);
   #ifdef KLOCWORK
   if(buffer != NULL)
   #endif
   {
      buffer[0] = 0;
      buffer[1] = GET_BIT_OFFSET(portableNo);
      buffer[2] = pagingType;
   	write_to_hmac_ioctl(HMAC, MAC_ULE_PAGE_STOP_LB,
                          active, // Channel Active
   							  0,
   							  0,
   							  0,
                          0, 3, buffer,
   							  0);
   }
   return 1;
}

EXPORT void DECODE_ULE_DLC(HMAC_QUEUES * messagePtr)
{
   BOOL lastPDU;
   FPTR buffer;
   ULEDLCLinkStatusFlags_e * linkStatusFlagsPtr;

   #ifdef DECT_DEBUG_USER_DLC_ULE_PRIMITIVE
   DECT_DEBUG_USER_DLC_ULE_PRIMITIVE("%s, %02x, %02x %02x %02x, %02x %02x\n", getDebugStringRef(messagePtr->MSG, messageStringTable), messagePtr->CurrentInc, messagePtr->Parameter1, messagePtr->Parameter2, messagePtr->Parameter3, messagePtr->G_PTR_buf[0], messagePtr->G_PTR_buf[1]);
   #endif

   linkStatusFlagsPtr = &ULEDLCLinkStatusFlags[messagePtr->CurrentInc];

   switch (messagePtr->MSG) {
      case HMAC_ULE_FU10_ACC_IND:
         #if 0
         if (messagePtr->G_PTR_buf[0] == 0) {
            printf("> Data:No Data!\n");
         } else {
            BYTE i;

            printf("> Data:\n");
            for (i = 0; i < messagePtr->G_PTR_buf[0]; i++) {
               if (i != 0 && ((i % 16) == 0)) {
                  printf("\n");
               }
               printf("%02x ", messagePtr->G_PTR_buf[1 + i]);
            }
            printf("\n");
         }
         #endif


   #ifdef KLOCWORK
         if (openDLC(messagePtr->CurrentInc, (uchar8 *)messagePtr+2)) {
   #else
         if (openDLC(messagePtr->CurrentInc, &messagePtr->Parameter1)) {
   #endif
            *linkStatusFlagsPtr = ULE_DLC_LINK_STATUS_OPEN_FLAG;

            if (messagePtr->G_PTR_buf[0]) {
               aFU10PDUReceived(messagePtr->CurrentInc, &messagePtr->G_PTR_buf[1]);
            }

            buffer = Mmu_Malloc(MAX_ULE_PDU_SIZE+1);
   #ifdef KLOCWORK
            if( buffer != NULL )
   #endif
            {
               if (getFU10TXPDU(messagePtr->CurrentInc, &buffer[1], &lastPDU)) {
                  // Do not check "lastPDU" value for ready_for_release of FP
                  *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_WAIT_FOR_ACK_FLAG;
                  buffer[0] = MAX_ULE_PDU_SIZE;
                  write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_DATA_REQ,
                                      0, // -
                                      0, // -
                                      0, // -
                                      0, // -
                                      0, MAX_ULE_PDU_SIZE+1, buffer,
                                      messagePtr->CurrentInc);
               } else {
                  // Send null data to transfer MCEI to LMAC
                  buffer[0] = 0; // Length
                  write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_DATA_REQ,
                                      0, // -
                                      0, // -
                                      0, // -
                                      0, // -
                                      0, 1, buffer,
                                      messagePtr->CurrentInc);
               }
            }
         } else {
            sendFU10OpenError(messagePtr->CurrentInc);
         }
         break;

      case HMAC_ULE_FU10_ACC_RDY_REL_IND:
         #if 0
         if (messagePtr->G_PTR_buf[0] == 0) {
            printf("> Data:No Data!\n");
         } else {
            BYTE i;

            printf("> Data:\n");
            for (i = 0; i < messagePtr->G_PTR_buf[0]; i++) {
               if (i != 0 && ((i % 16) == 0)) {
                  printf("\n");
               }
               printf("%02x ", messagePtr->G_PTR_buf[1 + i]);
            }
            printf("\n");
         }
         #endif

   #ifdef KLOCWORK
         if (openDLC(messagePtr->CurrentInc, (uchar8 *)messagePtr+2)) {
   #else
         if (openDLC(messagePtr->CurrentInc, &messagePtr->Parameter1)) {
   #endif
            *linkStatusFlagsPtr = ULE_DLC_LINK_STATUS_OPEN_FLAG;
            *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_PP_READY_FOR_RELEASE_FLAG;

            if (messagePtr->G_PTR_buf[0]) {
               aFU10PDUReceived(messagePtr->CurrentInc, &messagePtr->G_PTR_buf[1]);
            } else {
               // send rx indication to High layer
               sendUpRXIndication(messagePtr->CurrentInc, NULL, 0);
            }

            // READY_FOR_RELEASE has been received, but If the received data is not processed then the data is wrong.
            // - Error case: The more bit of the last recieved PDU is still set to 1.
            // - This error case can never be happened, but just for protection. If happened, the call is hung on.
            if (deviceInstance[messagePtr->CurrentInc].dataStatusFlags & ULE_DLC_DATA_STATUS_FIRST_RSN_RECEIVED_FLAG) {
               if (deviceInstance[messagePtr->CurrentInc].error == ULE_DLC_ERROR_NONE) {
                  deviceInstance[messagePtr->CurrentInc].error = ULE_DLC_ERROR_DATA_NOT_PROCESSED;
               }
            }

            buffer = Mmu_Malloc(MAX_ULE_PDU_SIZE+1);
            #ifdef KLOCWORK
				if (buffer == NULL)
				   return;
			   #endif
            if (getFU10TXPDU(messagePtr->CurrentInc, &buffer[1], &lastPDU)) {
               *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_WAIT_FOR_ACK_FLAG;
               buffer[0] = MAX_ULE_PDU_SIZE;
               if (!lastPDU) { // multiple packet
                  write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_DATA_REQ,
                                      0, // -
                                      0, // -
                                      0, // -
                                      0, // -
                                      0, MAX_ULE_PDU_SIZE+1, buffer,
                                      messagePtr->CurrentInc);
               } else { // single packet
                  if ((*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_RX_RESPONSE_FLAG) ||
                     isErrorHappened(messagePtr->CurrentInc)) {
                     // Both are readied to release link. PP will send release message first.
                     *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_WAIT_FOR_RELEASE_FLAG;
                     sendFU10ReadyRelease(messagePtr->CurrentInc, buffer);
                  } else {
                     #if 1
                     storeFU10LastTXPDU(messagePtr->CurrentInc, &buffer[1]);
                     Mmu_Free(buffer);
                     #else
                     write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_DATA_REQ,
                                         0, // -
                                         0, // -
                                         0, // -
                                         0, // -
                                         0, MAX_ULE_PDU_SIZE+1, buffer,
                                         messagePtr->CurrentInc);
                     #endif
                  }
               }
            } else {
               // Both are readied to release link. PP will send release message first.
               // Remark: Our system can not send release message due to timming issue.
               if ((*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_RX_RESPONSE_FLAG) ||
                  isErrorHappened(messagePtr->CurrentInc)) {
                  *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_WAIT_FOR_RELEASE_FLAG;
                  buffer[0] = 0; // Length
                  sendFU10ReadyRelease(messagePtr->CurrentInc, buffer);
               } else {
                  Mmu_Free(buffer);
               }
            }
         } else {
            sendFU10OpenError(messagePtr->CurrentInc);
         }
         break;

      case HMAC_ULE_FU10_RDY_REL_IND:
         #if 0
         if (messagePtr->G_PTR_buf[0] == 0) {
            printf("> Data:No Data!\n");
         } else {
            BYTE i;

            printf("> Data:\n");
            for (i = 0; i < messagePtr->G_PTR_buf[0]; i++) {
               if (i != 0 && ((i % 16) == 0)) {
                  printf("\n");
               }
               printf("%02x ", messagePtr->G_PTR_buf[1 + i]);
            }
            printf("\n");
         }
         #endif

         if (*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_OPEN_FLAG) {
            // "if" statement is for exception case;
            // This case supposes the message is sent from ULE device with wrong IP number.
            // LMAC sends up the message even if IP number is wrong to release the link.
            if (!(*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_PP_READY_FOR_RELEASE_FLAG)) {
               *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_PP_READY_FOR_RELEASE_FLAG;

               if (messagePtr->G_PTR_buf[0]) {
                  aFU10PDUReceived(messagePtr->CurrentInc, &messagePtr->G_PTR_buf[1]);
               }

               // READY_FOR_RELEASE has been received, but If the received data is not processed then the data is wrong.
               // - Error case: The more bit of the last recieved PDU is still set to 1.
               // - This error case can never be happened, but just for protection. If happened, the call is hung on.
               if (deviceInstance[messagePtr->CurrentInc].dataStatusFlags & ULE_DLC_DATA_STATUS_FIRST_RSN_RECEIVED_FLAG) {
                  if (deviceInstance[messagePtr->CurrentInc].error == ULE_DLC_ERROR_NONE) {
                     deviceInstance[messagePtr->CurrentInc].error = ULE_DLC_ERROR_DATA_NOT_PROCESSED;
                  }
               }

               if (!(*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_WAIT_FOR_ACK_FLAG)) { // FP is not sending data.
                  // Both are readied to release link. PP will send release message first.
                  if ((*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_RX_RESPONSE_FLAG) ||
                     isErrorHappened(messagePtr->CurrentInc)) {
                     *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_WAIT_FOR_RELEASE_FLAG;
                     buffer = Mmu_Malloc(1);
                     #ifdef KLOCWORK
         				if (buffer != NULL)
         			   #endif
         			   {
                        buffer[0] = 0; // Length
                        sendFU10ReadyRelease(messagePtr->CurrentInc, buffer);
                     }
                  }
               }
            }
         }
         break;

      case HMAC_ULE_FU10_DATA_IND:
         #if 0
         if (messagePtr->G_PTR_buf[0] == 0) {
            printf("> Data:No Data!\n");
         } else {
            BYTE i;

            printf("> Data:\n");
            for (i = 0; i < messagePtr->G_PTR_buf[0]; i++) {
               if (i != 0 && ((i % 16) == 0)) {
                  printf("\n");
               }
               printf("%02x ", messagePtr->G_PTR_buf[1 + i]);
            }
            printf("\n");
         }
         #endif

         if (*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_OPEN_FLAG) {
            if (messagePtr->G_PTR_buf[0]) {
               aFU10PDUReceived(messagePtr->CurrentInc, &messagePtr->G_PTR_buf[1]);
            }
         }
         break;

      #if 0
      // For now, nothing to do.
      case HMAC_ULE_FU10_GFA_IND:
         if (*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_OPEN_FLAG) {
         }
         break;
      #endif

      case HMAC_ULE_FU10_REL_IND:
         if (*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_OPEN_FLAG) {
            sendUpTXResult(messagePtr->CurrentInc, messagePtr->Parameter3, TRUE);
            #ifdef CONFIG_UPDATE_OTHER_HANDLING
            closeDLC(messagePtr->CurrentInc, YES);
            #else
            closeDLC(messagePtr->CurrentInc);
            #endif
            *linkStatusFlagsPtr = 0;
         }
         break;

      case HMAC_ULE_FU10_DTR_IND:
         if (*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_OPEN_FLAG) {
            *linkStatusFlagsPtr &= ~ULE_DLC_LINK_STATUS_WAIT_FOR_ACK_FLAG;

            aFU10TXPDUAcknowledged(messagePtr->CurrentInc); // indicate acknowledgment.

            if (!(*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_WAIT_FOR_RELEASE_FLAG)) {
               buffer = Mmu_Malloc(MAX_ULE_PDU_SIZE+1);

   			   #ifdef KLOCWORK
   			   if(buffer != NULL)
   			   {
   			   #endif
                  if (getFU10TXPDU(messagePtr->CurrentInc, &buffer[1], &lastPDU)) {
                     *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_WAIT_FOR_ACK_FLAG;
                     buffer[0] = MAX_ULE_PDU_SIZE;
                     if (!lastPDU) { // middle packet
                        write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_DATA_REQ,
                                            0, // -
                                            0, // -
                                            0, // -
                                            0, // -
                                            0, MAX_ULE_PDU_SIZE+1, buffer,
                                            messagePtr->CurrentInc);
                     } else { // last packet
                        if (*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_PP_READY_FOR_RELEASE_FLAG) {
                           // Both are readied to release link. PP will send release message first.
                           if ((*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_RX_RESPONSE_FLAG) ||
                              isErrorHappened(messagePtr->CurrentInc)) {
                              *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_WAIT_FOR_RELEASE_FLAG;
                              sendFU10ReadyRelease(messagePtr->CurrentInc, buffer);
                           } else {
                              #if 1
                              storeFU10LastTXPDU(messagePtr->CurrentInc, &buffer[1]);
                              Mmu_Free(buffer);
                              #else
                              write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_DATA_REQ,
                                                  0, // -
                                                  0, // -
                                                  0, // -
                                                  0, // -
                                                  0, MAX_ULE_PDU_SIZE+1, buffer,
                                                  messagePtr->CurrentInc);
                              #endif
                           }
                        } else {
                           write_to_hmac_ioctl(HMAC, HMAC_ULE_FU10_DATA_REQ,
                                               0, // -
                                               0, // -
                                               0, // -
                                               0, // -
                                               0, MAX_ULE_PDU_SIZE+1, buffer,
                                               messagePtr->CurrentInc);
                        }
                     }
                  } else {
                     if (*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_PP_READY_FOR_RELEASE_FLAG) {
                        // Both are readied to release link. PP will send release message first.
                        if ((*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_RX_RESPONSE_FLAG) ||
                           isErrorHappened(messagePtr->CurrentInc)) {
                           *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_WAIT_FOR_RELEASE_FLAG;
                           buffer[0] = 0;
                           sendFU10ReadyRelease(messagePtr->CurrentInc, buffer);
                        } else {
                           Mmu_Free(buffer);
                        }
                     } else {
                        Mmu_Free(buffer);
                     }
                  }
   			   #ifdef KLOCWORK
   		      }
   			   #endif
            }
         }
         break;

      case HMAC_ULE_FU10_LINK_REL_IND:
         if (*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_OPEN_FLAG) {
            sendUpTXResult(messagePtr->CurrentInc, 0, FALSE);
            #ifdef CONFIG_UPDATE_OTHER_HANDLING
            closeDLC(messagePtr->CurrentInc, NO);
            #else
            closeDLC(messagePtr->CurrentInc);
            #endif
            *linkStatusFlagsPtr = 0;
         }
         break;

      case HMAC_ULE_FU10_OTHER_IND:
         #ifdef CONFIG_UPDATE_OTHER_HANDLING
         if (*linkStatusFlagsPtr & ULE_DLC_LINK_STATUS_OPEN_FLAG) {
            *linkStatusFlagsPtr |= ULE_DLC_LINK_STATUS_OTHER_RECEIVED_FLAG;
         }
         #endif
         break;

   }
}

#endif  //ULE_SUPPORT
