#ifdef CATIQ_UPLANE    
/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V9.0       *
*                   (c) 2008 IFX / Peucon. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  LU10TX.C                                                *
*     Date       :  7. August, 2008                                         *
*     Contents   :  U-Plane DLC Layer SDU transmit Functions.               *
*     Hardware   :  IFX 97xx                                                *
*---------------------------------------------------------------------------*
* Change History:                                                           *
*                                                                           *
* Date         Author Description                                           *
* 10-Jul-2008  U.P.   Initial version                                       *
* 06-Aug-2008  C.S.   Additional comments,                                  *
*                     In function InitLU10SduTxSduTxBuf[0]                  *
*                     variable MaximumSduSize set to SDU_LEN_MAX            *
*                     variable FreeByte set to SDU_LEN_MAX                  *
* 07-Aug-2008  C.S.   Comments corrected                                    *
*****************************************************************************
*/
/** \file
 *  \brief SDU transmit function 
 */
#include <stdio.h>
 #include "ifx_common_defs.h"
#include "DEFINE.H"                    /* Compiler switchs                 */
#include "SYSDEF.H"
#include "DECT_UP.H"
#include "DECT.H"
#include "LUFU10AC.H"
#include "MMU.H"
#include "CAT_UP.H"
#ifdef FT
#include "CONF_CP.H"
#include "uplane_if.h"
#else
//TODO#include "PGLOBAL.C"
#endif
#include "MESSAGE_DEF.H"
#include "CP_SERVER.H"



   /* ===============                                                      */
   /* Global variables                                                     */
   /* ===============                                                      */
IMPORT void FU10ClearRelatedPdu (uint8 RelatedSdu);
   /* Local variables                                                      */
   /* ===============                                                      */
// Number of SDU TX Buffers per logical links (LLN)
LOCAL SDU_BUFFER_STRUCT XDATA SduTxBuf[DLC_U_LLN_MAX];

// SDU data arrays for each SDU TX buffer (SDU_BUFF_MAX) of SDU length (SDU_LEN_MAX)
LOCAL uint8             XDATA SduTxMem[DLC_U_LLN_MAX][SDU_BUFF_MAX+1][SDU_LEN_MAX]; 
   
   /* ===========================                                          */
   /* Local function declarations                                          */
   /* ===========================                                          */

   /* ===================                                                  */
   /* Function Definition                                                  */
   /* ===================                                                  */

/*
*****************************************************************************
*                                                                           *
*     Function :  InitLU10SduTx                                             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Initialisation of the SDU TX buffer number 0              *
*     Parms    :  Locigal link number, Lln                                  *
*              :  Local(static): SduTxBuf[0]                                *
*                 Local(static): SduTxMem[0] and SduTxMem[1]                *
*     Returns  :  Local(static): SduTxBuf[0]                                *
*                 Local(static): SduTxMem[0] and SduTxMem[1]                *
*     Remarks  :  For SDU_BUFF_MAX = 0x02 and after initialisation          *
*                 We have 1 SDU TX Buffer ([0]) buffering 2 SDUs ([0] and   *
*                 [1]). The 2 SDUs are SduTxMem 0 and 1.                    *
*                                                                           *
*                 SDU TX Buffer (struct) is composed of                     *
*                 MaxSduSize:     Max number of bytes for a SDU in bytes    *
*                 FreeBufferSize: Number of free bytes for SDU transfer     *
*                 Write:          Buffer write counter in number of SDUs    *
*                 Read:           Buffer read counter in number of SDUs     *
*                 Sdu[]:          SDU data array                            *
*                                                                           *
*                 SDU array (struct) is composed of                         *
*                 LifeTime:       Lifetime of SDU in number of TDMA frames  *
*                 Length:         Length of the SDU                         *
*                 ReadByte:       Number of read bytes                      *
*                 DataP:          Pointer to the SDU      (here SduTxMem[]) *
*     Called by:  LU10INI.C/InitUPlane()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT void
InitLU10SduTx ( uint8 Lln )
{
uint8 XDATA BuffCount;

  Mmu_Memset((FPTR)&SduTxBuf[Lln],0x00,sizeof(SDU_BUFFER_STRUCT)); // Sets struct SduTxBuf to 0x00

  
  SduTxBuf[Lln].FreeBufferSize = SDU_LEN_MAX * SDU_BUFF_MAX;

  Mmu_Memset((FPTR)&SduTxMem[Lln],0x00,SduTxBuf[Lln].FreeBufferSize); // Sets data array SduTxMem to 0x00

  SduTxBuf[Lln].MaxSduSize    = SDU_LEN_MAX;
  SduTxBuf[Lln].FreeSduBuffer = SDU_BUFF_MAX;

  for(BuffCount = 0;BuffCount<SDU_BUFF_MAX ;BuffCount++ )
  {
    SduTxBuf[Lln].Sdu[BuffCount].DataP    = SduTxMem[Lln][BuffCount]; // Sets SDU data part to SduTxMem buffer pointers
    SduTxBuf[Lln].Sdu[BuffCount].LifeTime = SDU_LIFE_TIME;    // Life time of SDU
  }

#ifdef FT // Fixed part terminal
  Send_UPMessage_To_APP(  FP_MEDIA_SDU_FLOW_IN, NULL, Lln,SduTxBuf[Lln].FreeSduBuffer,  
          (uint8) (SduTxBuf[Lln].MaxSduSize>>8), (uint8)SduTxBuf[Lln].MaxSduSize ,TXFLOWSTATE_ACRIV );
#else     // Portable part terminal
  #ifdef REMOTE_APPL  
  Send_Message_To_APP(  PP_MEDIA_SDU_FLOW_IN, NULL, Lln ,SduTxBuf[Lln].FreeSduBuffer,  
          (uint8) (SduTxBuf[Lln].MaxSduSize>>8), (uint8) SduTxBuf[Lln].MaxSduSize ,TXFLOWSTATE_ACRIV );
  #endif
#endif 
  SduTxBuf[Lln].State = UPCON_ACTIV;

}
/*
*****************************************************************************
*                                                                           *
*     Function :  DeInitLU10SduTx                                           *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Deinitialisation of the SDU TX buffer number 0            *
*     Parms    :  Locigal link number, Lln                                  *
*              :  Set Connectuin  state                                     *
*     Returns  :  Local(static):                                            *
*                                                                           *
*     Remarks  :                                                            *
*     Called by:  LU10INI.C/InitUPlane()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT void
DeInitLU10SduTx ( uint8 Lln )
{
  SduTxBuf[Lln].State          = UPCON_IDLE;/* State of connection                     */ 
  SduTxBuf[Lln].Write          = 0;         /* Buffer write counter in number of SDUs  */
  SduTxBuf[Lln].MaxSduSize     = 0;         /* Max number of bytes for a SDU in bytes  */
  SduTxBuf[Lln].FreeBufferSize = 0;         /* Number of free bytes for SDU transfer   */
  SduTxBuf[Lln].FreeSduBuffer  = 0;         /* Number of free buffer of SDUs           */
  SduTxBuf[Lln].Read           = 0;         /* Buffer read counter in number of SDUs   */
#ifdef FT // Fixed part terminal
  Send_UPMessage_To_APP(  FP_MEDIA_SDU_FLOW_IN, NULL, Lln,SduTxBuf[Lln].FreeSduBuffer,  
          (uint8) (SduTxBuf[Lln].MaxSduSize>>8), (uint8)SduTxBuf[Lln].MaxSduSize ,TXFLOWSTATE_IDLE );
#else     // Portable part terminal
  #ifdef REMOTE_APPL  
  Send_Message_To_APP(  PP_MEDIA_SDU_FLOW_IN, NULL, Lln ,SduTxBuf[Lln].FreeSduBuffer,  
          (uint8) (SduTxBuf[Lln].MaxSduSize>>8), (uint8) SduTxBuf[Lln].MaxSduSize ,TXFLOWSTATE_IDLE );
  #endif
#endif 


}
/*
*****************************************************************************
*                                                                           *
*     Function : LU10SduTx                                                  *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Fills SDU Buffer and retrieves pointer to next SDU data   *
*                 buffer. When called with Bytes2Send = 0 pointer is provide*
*                 and called with Bytes2Send larger 0 data has been filled  *
*                 already by calling function.                              *
*     Parms    :  Locigal link number, Lln                                  *
*                 Number of bytes to be sent incl. SDU header, Bytes2Send   *
*                 Pointer to next SDU data to be sent, *NextSduDataP        *
*     Returns  :  = -1 if bytes to sent + SDU header is longer than max     *
*                   SDU size.                                               *
*                 = number free bytes in SDU buffer                         *
*                 = -3 if bytes to sent + SDU header is longer than free    *
*                   bytes in SDU buffer.                                    *
*                 = -4 if no buffer is available                            *
*                 by reference: Pointer to next SDU data to be sent,        *
*                 NextSduDataP                                              *
*     Remarks  :  Lln is only used for FT.                                  *
*                                                                           *
*                 Index of TX SDU data is derived from Write counter using  *
*                 max number of buffers (SDU_BUFF_MOD) as modulo, further   *
*                 called write index.                                       *
*                                                                           *
*                 Both write buffers are used alternately this means when   *
*                 buffer at write index 0 has been filled index is          *
*                 incrementd by one for getting next SDU.                   *
*                                                                           *
*                 If no bytes to be sent:                                   *
*                 Sets pointer of next SDU data to value of next SDU data   *
*                 in SDU buffer concerning Write index.                     *
*                 Then it returns FreeBufferSize.                           *
*                                                                           *
*                 If bytes to be sent:                                      *
*                 Checks if bytes to be sent exceeds max SDU size or number *
*                 of free bytes in buffer. In this case the result          *
*                 is -1 or -3 and pointer to next SDU data is set to NULL.  *
*                                                                           *
*                 In the other case it does the following:                  *
*                 SDU data length is set to number of bytes to be sent,     *
*                 read bytes of SDU data is set to 0                        *
*                 free bytes of SDU buffer is calculated by subtrating      *
*                 bytes to sent length.                                     *
*                 write counter is incremented                              *
*                 content of NextSduDataP is set to next SDU data pointer.  *                                   *
*                 Then it returns with result of free bytes values          *
*     Called by:  Spi_Irq.c/Init_SPI()                                      *
*                 Spi_Irq.c/SPI_InterruptHandler()                          *
*                                                                           *
*****************************************************************************
*/
#if ((!defined(LTQ_RAW_DPSU))&&defined(SDUSIZE))
EXPORT uint16 
LU10SduTx (uint8 Lln, uint16 Bytes2Send, FPTR *NextSduDataP, uint8 MBit )
#else
EXPORT int16 
LU10SduTx (uint8 Lln, uint16 Bytes2Send, FPTR *NextSduDataP )
#endif
{
                                      
SDU_BUFFER_STRUCT XDATA *SduBufPtr; // SDU buffer pointer for saving NextSduDataP
                                       
#ifdef FT // Fixed part terminal
  if(Lln >= DLC_U_LLN_MAX)
  {
    return(-1);
  }
  SduBufPtr = &SduTxBuf[Lln];   
#else // Portable part terminal
  Lln = Lln;
  SET_PORT_DEBUG(LU10TX_ACTIVE);
  SduBufPtr = &SduTxBuf[0]; // set TX buffer as data buffer for operations
#endif 

#if ((!defined(LTQ_RAW_DPSU))&&defined(SDUSIZE))
  DECT_DEBUG_UPLANE("TX REQ from APP:%02x %02x %04x %04x Mbit=%01x \r\n", SduBufPtr->Read, 
                    SduBufPtr->Write, Bytes2Send, SduBufPtr->FreeSduBuffer, MBit );
#endif
  if((Bytes2Send == 0)||(SduBufPtr->State != UPCON_ACTIV)) /* no data to send; used to get new SDU data pointer   */
  {
    // Check if buffer available
    if ( SduBufPtr->FreeSduBuffer <= 0)
    {// No buffer available; fixed buffer size is SDU_LEN_MAX
      *NextSduDataP = NULL;
      SduBufPtr->FreeSduBuffer = 0;
#ifdef FT // Fixed part terminal
      Send_UPMessage_To_APP(  FP_MEDIA_SDU_FLOW_IN, NULL, Lln,SduBufPtr->FreeSduBuffer,  
          (uint8) (SduBufPtr->MaxSduSize>>8), (uint8)SduBufPtr->MaxSduSize ,TXFLOWSTATE_ERROR );
      DECT_DEBUG_LU10TX("-4 %1d %4d",Lln,Bytes2Send,0,0);
#endif 
      SET_PORT_DEBUG(UPLANE_NOACTIVE);
      return(-4) ;
    }
    else
    {
      *NextSduDataP = SduBufPtr->Sdu[SduBufPtr->Write & SDU_BUFF_MOD].DataP;
#ifdef FT // Fixed part terminal
      DECT_DEBUG_LU10TX("Pt %1d %4d %4d",Lln,Bytes2Send,SduBufPtr->FreeBufferSize,0);
#endif
      return (SduBufPtr->FreeBufferSize); // Number of free bytes in SDU buffer
    }
  }
  else if (Bytes2Send > SduBufPtr->MaxSduSize) /*  SDU longer than max SDU size  */
  {
    NextSduDataP = NULL;
#ifdef FT // Fixed part terminal
    DECT_DEBUG_LU10TX("-1 %1d %4d",Lln,Bytes2Send,0,0);
#endif
    return(-1) ;
  }
/*  else if(Bytes2Send > SduBufPtr->PeerMaximumSduSize) 
  {
TODO    NextSduDataP = NULL;
    return(-2) ;
  }*/
  else if (Bytes2Send > SduBufPtr->FreeBufferSize) /*  Sdu longer than free bytes in buffer */
  {
    NextSduDataP = NULL;
    SET_PORT_DEBUG(UPLANE_NOACTIVE);
    return(-3) ;
  }
  else // SDU fits 
  {
    SduBufPtr->Sdu[SduBufPtr->Write & SDU_BUFF_MOD].Length    = Bytes2Send;   // Number of bytes to be sent
    SduBufPtr->Sdu[SduBufPtr->Write & SDU_BUFF_MOD].ReadBytes = 0;            // Read counter reset
#if ((!defined(LTQ_RAW_DPSU))&&defined(SDUSIZE))
    SduBufPtr->Sdu[SduBufPtr->Write & SDU_BUFF_MOD].MBit      = MBit;         // Last SDU?
#endif
    SduBufPtr->FreeBufferSize -= SduBufPtr->MaxSduSize ;      // adjust number of free bytes in SDT TX buffer use fixed value
    SduBufPtr->FreeSduBuffer--;
    SduBufPtr->Write++; // increment write counter, one more SDU written
    // New Buffer "Next"
    // Check if buffer available
    if ( SduBufPtr->FreeSduBuffer <= 0)
    {// No buffer available; fixed buffer size is SDU_LEN_MAX
      SduBufPtr->FreeSduBuffer = 0;
      NextSduDataP = NULL;
      SET_PORT_DEBUG(UPLANE_NOACTIVE);
      return(-4) ;
    }
    else
    {
      *NextSduDataP = SduBufPtr->Sdu[(SduBufPtr->Write) & SDU_BUFF_MOD].DataP; // set next SDU data buffer
#ifdef FT // Fixed part terminal
      DECT_DEBUG_LU10TX("OK %1d %4d %6d",Lln,Bytes2Send,SduBufPtr->FreeBufferSize,0);
#endif
      SET_PORT_DEBUG(UPLANE_NOACTIVE);
      return (SduBufPtr->FreeBufferSize); // Number of free bytes in SDU buffer
    }    
  }  
}

/*
*****************************************************************************
*                                                                           *
*     Function :  CopySdu2Pdu                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Copies a SDU part into PDU given by PduDataPtr            *
*     Parms    :  Locigal link number, Lln                                  *
*                 Pointer to PDU data, PduDataPtr                           *
*                 Pointer to referenced return variable for SDU indication  *
*                 Number of bytes available for PDU, AvailableSpace. This is*
*                 used in case a ack message has ocupied parts of the PDU   *
*                                                                           *
*     Returns  :  Number of bytes in PDU in PduDataPtr, PduLen              *
*     Remarks  :  Lln is only used for FT.                                  *
*                                                                           *
*                 It checks whether the current SDU has reached end of life *
*                 time. If this is the case it calls FU10ClearRelatedPdu for*
*                 stopping all retransmission of related PDUs. In addition  *
*                 it indicates that all data have been read by setting      *
*                 read counter to length value.                             *
*                                                                           *
*                 It checks whether length and read counter have the same   *
*                 value. This means that same number of SDUs have been read *
*                 as have been formaly written. In this case there are no   *
*                 more data waiting to be sent and it returns PDU length 0. *
*                                                                           *
*                 It checks whether the all bytes of current SDU data buffer*
*                 have been read. In this case the next SDU data buffer is  *
*                 used. Therefore read counter is incremented and used      *
*                 for new index of SDU data buffer. Temp SDU pointer is set *
*                 to this new pointer. The number of free bytes in buffer is*
*                 added by SDU_LEN_MAX to indicate that one buffer is free. *
*                                                                           *
*                 It checks whether remaining unread data length            *
*                 (SduTempP->Length - SduTempP->ReadBytes) is longer than   *
*                 max PDU length (PDU_DATA_LEN). In this case it sets the   *
*                 PduLen to max PDU length (PDU_DATA_LEN) and sets the More *
*                 bit to 1 in the PDU in order to indicate that another PDU *
*                 will follow with the rest of the SDU. Then it copies the  *
*                 SDU data in the PDU after the PDU header and increments   *
*                 the read counter by max PDU length. It returns max PDU    *
*                 length.                                                   *
*                                                                           *
*                 If remaining unread data length                           *
*                 (SduTempP->Length - SduTempP->ReadByte) is shorter than   *
*                 max PDU length (PDU_DATA_LEN) it set the return value     *
*                 (PduDataLen) to the result of this calculation.           *
*                 It doesn't set the more bit because SDU data fit PDU.     *
*                 Then it copies the SDU data in the PDU after the PDU      *
*                 header and fills the the remaining bytes of the PDU with a*
*                 fill value if needed. The read counter of the SDU data    *
*                 is added by PduDataLen. This means length and read are    *
*                 equal. It return PduDataLen.                               *
*     Called by:  FU10ACTX.C/FU10PduTx()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT int8
CheckSdu2Pdu(uint8 Lln)
{
   SDU_BUFFER_STRUCT XDATA *SduBufPtr;  // Temp SDU buffer struct

   SduBufPtr = &SduTxBuf[ Lln ];             // set TX buffer as data buffer for operations
   if( SduBufPtr->Write == SduBufPtr->Read ) // all written SDUs have been read, copied into PDUs respectively?
   { // no SDU data
      return( 0 );
   }
   return( 1 );
}

EXPORT int8 
CopySdu2Pdu (uint8 Lln, FPTR PduDataPtr, uint8 AvailableSpace, uint8 *Sdu_MOER_BIT)
{
uint8 XDATA PduDataLen = 0;         // length of PDU data
//uint8 XDATA CurrentSdu = 0;         // Indication of current SDU
SDU_DATA_STRUCT   XDATA *SduTempP;  // Temp SDU data struct
SDU_BUFFER_STRUCT XDATA *SduBufPtr; // Temp SDU buffer struct
                                      
#ifdef FT
  SduBufPtr = &SduTxBuf[Lln];
#else
  SduBufPtr = &SduTxBuf[0];// set TX buffer as data buffer for operations
#endif 

  if(SduBufPtr->Write == SduBufPtr->Read) // all written SDUs have been read, copied into PDUs respectively?
  { // no SDU data
    return(0);
  }

  SduTempP = &SduBufPtr->Sdu[SduBufPtr->Read & SDU_BUFF_MOD]; // Set to SDU data buffer at read index
  
#ifdef CATIQ_UPLANE_NO_JET
  if ( SduTempP->LifeTime == 0 ) // SDU life time has expired
  {
    CurrentSdu = SduBufPtr->Read;
    // Stop retransmission of all related PDUs
    FU10ClearRelatedPdu (CurrentSdu);
    // Indicate SDU as already read
    SduTempP->ReadBytes = SduTempP->Length;
  }
#endif

  
  if( (SduTempP->Length - SduTempP->ReadBytes) > AvailableSpace )
  { // SDU is larger than remaining space in one PDU
    PduDataLen = AvailableSpace; // Number of data which can be sent, Return value
    // copy PDU data 
    Mmu_Memcpy( PduDataPtr,&SduTempP->DataP[SduTempP->ReadBytes], AvailableSpace );
    SduTempP->ReadBytes += PduDataLen;
    *Sdu_MOER_BIT = FU10_MORE_BIT;
  }
  else
  { // SDU fits remaining space in one PDU
    PduDataLen = SduTempP->Length - SduTempP->ReadBytes; // set PDU data length
    // copy PDU data 
    Mmu_Memcpy( PduDataPtr,&SduTempP->DataP[SduTempP->ReadBytes], PduDataLen);

    *Sdu_MOER_BIT = FU10_NOMORE_BIT;
#if ((!defined(LTQ_RAW_DPSU))&&defined(SDUSIZE))
    if( SduTempP->MBit == 1 )
    *Sdu_MOER_BIT |= 0x80;
#endif

    SduBufPtr->FreeBufferSize += SduBufPtr->MaxSduSize; //Buffer has been freed
    SduBufPtr->FreeSduBuffer++;
    SduBufPtr->Read++; // Ready for next SDU
    DECT_DEBUG_UPLANE("TX Done:%02x %02x %04x\r\n", SduBufPtr->Read, SduBufPtr->Write, SduBufPtr->FreeSduBuffer );
#ifdef FT // Fixed part terminal
    Send_UPMessage_To_APP(  FP_MEDIA_SDU_FLOW_IN, NULL,Lln,SduBufPtr->FreeSduBuffer,  
          (uint8) (SduBufPtr->MaxSduSize>>8), (uint8)SduBufPtr->MaxSduSize ,TXFLOWSTATE_NEXT );
#else     // Portable part terminal
    Send_Message_To_APP(  PP_MEDIA_SDU_FLOW_IN, NULL, Lln ,SduBufPtr->FreeSduBuffer,  
          (uint8) (SduBufPtr->MaxSduSize>>8), (uint8) SduBufPtr->MaxSduSize ,TXFLOWSTATE_NEXT );
#endif 
  }

  return(PduDataLen);
}

/*
*****************************************************************************
*                                                                           *
*     Function :  LU10UpdateSduLifeTime                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Decrements life time counter of all SDUs                  *
*     Parms    :  Decrements value                                          *
*     Returns  :  none                                                      *
*     Remarks  :  The SDU life time is counted in TDMA frames. The decrement*
*                 determines the number of TDMA frames which have passed    *
*                 since last call of this function.
*                                                                           *
*     Called by:  TODO                                                      *
*                                                                           *
*****************************************************************************
*/
#ifdef CATIQ_UPLANE_NO_JET
EXPORT void
LU10UpdateSduLifeTime (uint8 Decrement)
{
  return;
}
#endif // #ifdef CATIQ_UPLANE   
/*
*****************************************************************************
*                                                                           *
*     Function : LU10SduTxGetPtr                                            *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Fills SDU Buffer and retrieves pointer to next SDU data   *
*     Parms    :  Locigal link number, Lln                                  *
*                 Number of bytes to be sent incl. SDU header, Bytes2Send   *
*                 Pointer to next SDU data to be sent, *NextSduDataP        *
*     Returns  :  = -1 if bytes to sent + SDU header is longer than max     *
*                   SDU size.                                               *
*                 = number free bytes in SDU buffer                         *
*                 = -3 if bytes to sent + SDU header is longer than free    *
*                   bytes in SDU buffer.                                    *
*                 = -4 if no buffer is available                            *
*                 by reference: Pointer to next SDU data to be sent,        *
*                 NextSduDataP                                              *
*     Remarks  :  Lln is only used for FT.                                  *
*                                                                           *
*     Called by:  Spi_Irq.c/Init_SPI()                                      *
*                 Spi_Irq.c/SPI_InterruptHandler()                          *
*                                                                           *
*****************************************************************************
*/
#if ((!defined(LTQ_RAW_DPSU))&&defined(SDUSIZE))
EXPORT uint16 
LU10SduTxGetPtr (uint8 Lln,FPTR *NextSduDataP )
#else
EXPORT int16 
LU10SduTxGetPtr (uint8 Lln,FPTR *NextSduDataP )
#endif
{
                                      
SDU_BUFFER_STRUCT XDATA *SduBufPtr; // SDU buffer pointer for saving NextSduDataP

                            
#ifdef FT // Fixed part terminal
  if(Lln >= DLC_U_LLN_MAX)
  {
    return(-1);
  }
  SduBufPtr = &SduTxBuf[Lln];
#else // Portable part terminal
  Lln = Lln;
  SET_PORT_DEBUG(LU10TX_ACTIVE);
  SduBufPtr = &SduTxBuf[0]; // set TX buffer as data buffer for operations
#endif 
  
  // Check if buffer available
  if (( SduBufPtr->FreeSduBuffer <= 0 )||(SduBufPtr->State != UPCON_ACTIV)) 
  {// No buffer available; fixed buffer size is SDU_LEN_MAX
    *NextSduDataP = NULL;
    SduBufPtr->FreeSduBuffer = 0;
#ifdef FT // Fixed part terminal
    Send_UPMessage_To_APP(  FP_MEDIA_SDU_FLOW_IN, NULL, Lln,SduBufPtr->FreeSduBuffer,  
        (uint8) (SduBufPtr->MaxSduSize>>8), (uint8)SduBufPtr->MaxSduSize ,TXFLOWSTATE_ERROR );
//    DECT_DEBUG_LU10TX("-4 %1d %4d",Lln,Bytes2Send,0,0);
#endif 
    SET_PORT_DEBUG(UPLANE_NOACTIVE);
    return(-4) ;
  }
    /* used to get new SDU data pointer   */
  *NextSduDataP = SduBufPtr->Sdu[SduBufPtr->Write & SDU_BUFF_MOD].DataP;
#ifdef FT // Fixed part terminal
  //DECT_DEBUG_LU10TX("Pt %1d %4d %4d",Lln,0 ,SduBufPtr->FreeBufferSize,0);
#endif
  SET_PORT_DEBUG(UPLANE_NOACTIVE);
  return (SduBufPtr->FreeBufferSize); // Number of free bytes in SDU buffer

}
#endif
