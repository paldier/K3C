#ifdef CATIQ_UPLANE   
/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V9.0       *
*                   (c) 2008 IFX / Peucon. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  FU10ARCRX.C                                             *
*     Date       :  8. August, 2008                                         *
*     Contents   :  U-Plane DLC Layer PDU receive Functions.                *
*     Hardware   :  IFX 97xx                                                *
*---------------------------------------------------------------------------*
* Change History:                                                           *
*                                                                           *
* Date         Author Description                                           *
* 31-Jul-2008  U.P.   Initial version                                       *
* 07-Aug-2008  C.S.   Additional comments                                   *
* 08-Aug-2008  C.S.   Additional comments                                   *
*                     InitFU10PduRx extended with PDU life time             *
*****************************************************************************
*/
/** \file
 *  \brief LU10 PDU RX handling
 */ 
#include "ifx_common_defs.h"
#include "DEFINE.H"                    /* Compiler switchs                 */
#include "SYSDEF.H"
#include "DECT_UP.H"
#include "DECT.H"
#include "CAT_UP.H"
#include "LUFU10AC.H"
#include "MMU.H"
#ifdef FT
#include "CONF_CP.H"
#include "uplane_if.h"
#include "FMAC_DEF.H"
#else
#include "PMAC_DEF.H"
#endif
#include "CP_SERVER.H"
#include "MESSAGE_DEF.H"
#include "FDEF.H"

#include <stdio.h>

   /* ===============                                                      */
   /* Global variables                                                     */
   /* ===============                                                      */
IMPORT XDATA BYTE FU10Method[DLC_U_LLN_MAX];    //!< Algorithm of FU10 Protocol
IMPORT uint8              FU10PduTxAckSync  (uint8 Lln, FPTR PduDataP );
IMPORT uint8              FU10PduTxAckSyncV131  (uint8 Lln, FPTR PduDataP );
IMPORT uint8              CopyPdu2Sdu   (uint8 Lln, uint8 *PduPtr,uint8 PduLength, uint8 Sdu_MOER_BIT);
//IMPORT void               FU10UpdateLifeTimeTxBuffer (uint8 Decrement);
//IMPORT void               FU10UpdateTxBufferRSN (uint8 Lln, uint8 RSN);

   /* ===============                                                      */
   /* Local variables                                                      */
   /* ===============                                                      */
// Number of PDU RX Buffers per logical links (LLN)
LOCAL PDU_BUFFER_STRUCT XDATA PduRxBuf[DLC_U_LLN_MAX];
// PDU data arrays for each PDU RX buffer (PDU_BUFF_MAX) of PDU length (PDU_LEN)
LOCAL uint8             XDATA PduRxMem[DLC_U_LLN_MAX][PDU_BUFF_MAX][PDU_LEN];
LOCAL uint8             UPlane_rx_data[ 64 ];

// Ack PDU data arrays
//LOCAL uint8             XDATA PduRxAckMem[DLC_U_LLN_MAX][PDU_LEN];
// Sync PDU data arrays
//LOCAL uint8             XDATA PduRxSyncMem[DLC_U_LLN_MAX][PDU_LEN];
   
   /* ===========================                                          */
   /* Local function declarations                                          */
   /* ===========================                                          */

   /* ===================                                                  */
   /* Function Definition                                                  */
   /* ===================                                                  */

/*
*****************************************************************************
*                                                                           *
*     Function :  InitPduRx                                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Initialisation of the PDU RX buffer number 0              *
*     Parms    :  Locigal link number, Lln                                  *
*              :  Local(static): PduRxBuf[0]                                *
*                 Local(static): PduRxMem[0] to PduRxMem[15]                *
*     Returns  :  Local(static): PduRxBuf[0]                                *
*                 Local(static): PduRxMem[0] to PduRxMem[15]                *
*     Remarks  :  For PDU_WIN_SIZE = 0x10 and after initialisation          *
*                 We have 1 PDU RX Buffer ([0]) buffering 16 PDUs ([0]-[15] *
*                 The 16 PDUs are PduTxMem 0 - 15                           *
*                                                                           *
*                 FU10 PDU RX Buffer (struct) is composed of                *
*                 Window:            PDU Window Counter                     *
*                 SSN:               Send sequence Number N(S)              *
*                 RSN:               Read = Receive sequence Number N(R)    *
*                 NAckCount:         Number of negative acknowledged PDUs   *
*                 AckReqCount:       Number of PDUs requested to be         *
*                                    acknowledged                           *
*RODO             AckNackPduP:       AckNack message PDU, pointer           *
*TODO             SycPduP:           Sync message PDU, pointer              * 
*                 Pdu[]:             PDU Buffer data pointer array          *
*                                                                           *
*                 FU10 PDU Data Buffer (struct) is composed of              *
*                 RelatedSDU;        SDU Buffer write counter in number of  *
*                                    SDUs, shows to which SDU it belongs    *
*                                    Not used for RX                        *
*                 AckState:          Status of achknowledgement             *
*                 LifeTime:          Lifetime of PDU in number of TDMA frames*
*                 Length:            Length of PDU in bytes                 *
*                 MBit:              More bit indication                    *
*                 DataP:             Pointer to the SDU data (here PduRxMem[])*
*     Called by:  LU10INI.C/InitUPlane()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT void InitFU10PduRx (  uint8 Lln  )
{
uint8 XDATA BuffCount;

  Mmu_Memset((FPTR)&PduRxBuf[Lln],0x00,sizeof(PDU_BUFFER_STRUCT));// Sets struct PduRxBuf to 0x00

  Mmu_Memset((FPTR)&PduRxMem[Lln],0x00,PDU_BUFF_MAX*PDU_LEN);// Sets data array PduRxMem to 0x00

   for(BuffCount = 0;BuffCount<PDU_BUFF_MAX ;BuffCount++ )
   {
      // Sets PDU data part to PduRxMem buffer pointers
      // This buffers are not used. So, no need.
      PduRxBuf[Lln].Pdu[BuffCount].DataP = PduRxMem[Lln][BuffCount]; 

      PduRxBuf[Lln].Pdu[BuffCount].AckState = FU10_IDLE;
   }

   PduRxBuf[Lln].RSN   = 0;                 // Expexted SN
   PduRxBuf[Lln].SSN   = 0;                 // Latest SN of ACK/NACK message
   PduRxBuf[Lln].uni.WindowIndex = 0;

   PduRxBuf[Lln].FrmCnt  = 0xFF;
   PduRxBuf[Lln].State = UPCON_ACTIV;
   
   // This buffers are not used. So, no need.
   Mmu_Memset( UPlane_rx_data, 0x00, 64 );
}

/*
*****************************************************************************
*                                                                           *
*     Function :  DeInitFU10PduRx                                           *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Deinitialisation of the PDU RX buffer number 0            *
*     Parms    :  Locigal link number, Lln                                  *
*              :  Set Connectuin  state                                     *
*     Returns  :  Local(static):                                            *
*                                                                           *
*     Remarks  :                                                            *
*     Called by:  LU10INI.C/InitUPlane()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT void
DeInitFU10PduRx ( uint8 Lln )
{
  PduRxBuf[Lln].State = UPCON_IDLE;
}

#ifdef CATIQ_UPLANE_FU10
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduRx                                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Fills RX buffer with new received PDU data                *
*                 Checks whether it is retransmission or new PDU            *
*     Parms    :  Pointer to received PDU data, PduDataP                    *
*                 Locigal link number, Lln, Rx CRC State                    *
*     Returns  :  = 0 if no data or synch PDU has been received             *
*                 = number of buffered bytes when data or synch PDU has     *
*                   been received                                           *
*     Remarks  :                                                            *
*     Called by:  Todo                                                      *
*                                                                           *
*****************************************************************************
*/
EXPORT int8 
FU10PduRx (uint8 Lln, FPTR PduDataP, uint8 RCrc, uint8  FrmCnt)   // Not Used
{
int8    XDATA ReceivedBytes  = 0;
int16   XDATA RecSSN = 0;
int16   XDATA RSNCount = 0;
int8    XDATA TxAckSync = 0xFF;
FPTR    XDATA PduTempP = NULL;
#ifdef _UPSIM
  uint8 XDATA TestArray[100];
#endif

PDU_DATA_STRUCT XDATA *PduDataTempP;

PDU_BUFFER_STRUCT XDATA *PduRxBufPtr;

#ifdef FT // Fixed part terminal
  if(Lln >= DLC_U_LLN_MAX)
  {
    return(-1);
  }
  PduRxBufPtr = &PduRxBuf[Lln];
#else // Portable part terminal
  SET_PORT_DEBUG(FU10RX_ACTIVE);
  PduRxBufPtr = &PduRxBuf[0]; // set the RX buffer as buffer for operation
#endif 

  if((PduRxBufPtr->State != UPCON_ACTIV)||((RCrc&IPALL_OK)==0))
  {
    SET_PORT_DEBUG(UPLANE_NOACTIVE);
    return(0);
  }

  PduTempP =  PduDataP; // set temp data pointer to received PDU data
  // Update TX ack PDUs if any ack has been received
  TxAckSync = FU10PduTxAckSync (Lln, PduTempP);
  if(TxAckSync == 1)
  {  //  ack has been received, no need to keep it in RX buffer
    SET_PORT_DEBUG(UPLANE_NOACTIVE);
    return (0);
  }
  else if ( (TxAckSync == 0) || (TxAckSync == 2))
  { // synch or data PDU, (ack may was included but has been removed by TxAckSync)
    // so must be buffered
    PduDataTempP = &PduRxBufPtr->Pdu[PduRxBufPtr->RSN & PDU_BUFF_MOD]; // set temp pointer to PDU RX buffer
   // Check buffer ack status
    if((PduDataTempP->AckState == FU10_IDLE)&&(RCrc&IPALL_OK))// Buffer is not used)
    {
      // fill data buffer
      PduDataTempP->Length      = (*(PduTempP + 1) & FU10_LENGTH_FIELD) >> 1;
      PduDataTempP->MBit        =  *(PduTempP + 1) & FU10_MORE_BIT;
      PduDataTempP->LifeTime    =  PDU_RX_LIFE_TIME;
      // copy data
      Mmu_Memcpy(  PduDataTempP->DataP, PduTempP , (PDU_HEADER_LEN + PduDataTempP->Length) );
      DECT_DEBUG_FU10RX("%1d %4d",Lln,RCrc,0,0);
    }
    else // Buffer is used?
    {
      //Error in buffer initialisation
      return (0);
    }

    // get RSN 
    RecSSN = *PduTempP; // copy 8 LSB of RSN
    PduTempP++;         // next byte ER9, length and more bit
    RecSSN    |= ((uint16)(*PduTempP & FU10_ES9_BIT))<<1; //copy bit 9 of RSN
     // check whether it is in or out of sequence PDU
    if(PduRxBufPtr->RSN == RecSSN) // is received SSN expected?
    {  // PDU is in sequence
      PduDataTempP->AckState    = FU10_RX_PDU_ACK;
      PduRxBufPtr->RSN++;
      PduRxBufPtr->Window++;
      PduRxBufPtr->AckReqCount++;
    }
    else
    {  // PDU is not in sequence
       PduDataTempP->AckState    = FU10_RX_PDU_NACK;
    }
  }// end if TxAckSynch

  // Copy acknowledged PDU to SDU, search in all data buffers
  for (RSNCount = 0 ; RSNCount < PDU_BUFF_MAX; RSNCount++ )
  {  //have to go to all buffer because of modulo operation with PDU_BUFF_MOD to determine ack status
    if(PduRxBufPtr->Pdu[RSNCount & PDU_BUFF_MOD].AckState == FU10_RX_ACK_TRUE)
    {   // copy PDU into SDU buffer
         PduDataTempP = &PduRxBufPtr->Pdu[RSNCount & PDU_BUFF_MOD]; // set temp pointer to PDU RX buffer
      if( CopyPdu2Sdu(Lln , &(PduDataTempP->DataP[FU10A_HEADER_LEN]), 
          (PduDataTempP->DataP[1]&FU10_LENGTH_FIELD)>>1, PduDataTempP->DataP[1]&FU10_MORE_BIT) )
      { // PDU could be copied, free the buffer
        PduRxBufPtr->Pdu[RSNCount & PDU_BUFF_MOD].AckState = FU10_IDLE;
        PduRxBufPtr->Pdu[RSNCount & PDU_BUFF_MOD].Length = 0;
        PduRxBufPtr->Pdu[RSNCount & PDU_BUFF_MOD].LifeTime = PDU_TX_LIFE_TIME;
        if(PduRxBufPtr->Window > 0)
        {
          PduRxBufPtr->Window--; // decrement window because PDU has been freed
        }
      }
      else
      {
      // mo data could be copied
      }
    }
    else
    {
      // PDU has not been acknowledged
    }
  }//end for loop

  return(PduDataTempP->Length);
}
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduRxAck                                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Determines whether ACK/NACK has to be sent and whether    *
*                 window size has been reached                              *
*                 Fills PduData pointer with ack frame (FU10c) in FU10a     *
*     Parms    :  Locigal link number, Lln                                  *
*                 Pointer to PDU data synch frame, PduDataP                 *
*     Returns  :  = 0 if no acknowledge frame has to be sent                *
*                 = Number of data in acknowledge frame,                    *
*                   can be used to start FU10a data after the FU10c frame   *
*     Remarks  :  Lln is only used for FT.                                  *
*                                                                           *
*                 It checks RX buffer whether ACK/NACK has been requested   *
*                 when window size has not been exceeded. In this case it   *
*                 means that a FU10a synch frame has to be sent. 1st byte   *
*                 is set to 8 LSB of SSN (write)of RX buffer. MSB of 2nd    *
*                 byte is set as Bit 9 of SSN (write) of RX buffer followed *
*                 by synch indication coding of length indication (63) and  *
*                 M bit set to 0 (EN 300 175-4, 14.3.4.1.1). Then it        *
*                 returns 1.                                                *
*                                                                           *
*                 It checks RX buffer whether ACK/NACK has not been         *
*                 requested when window size has not been exceeded or       *
*                 whether ACK/NACK has been requested when window size has  *
*                 been exceeded. In this case it builds a FU10a frame with a*
*                 FU10c frame included. 1st byte is set to 8 LSB of  SSN    *
*                 (write)of RX buffer. MSB of 2nd byte is set to Bit 9 of   *
*                 SSN (write) of RX buffer followed by synch indication     *
*                 coding of length indication (63) and M bit set to 1       *
*                 (EN 300 175-4, 12.11.2.1). 3rd byte is 8 LSB of RSN#1 and *
*                 is set to 8 LSB of SSN (write)of RX buffer. Next 5 bytes  *
*                 RSN#2 - RSN#6 are set to 0x00. Last byte includes ACK/NACK*
*                 indication set by NA1=0 (bit8) and NA2=1 (bit7) means     *
*                 "This frame contains only one ACK message in RSN#1, no    *
*                 NACKs" (EN 300 175-4, 14.3.4.2.1).  Bits 6 - 1 represent  *
*                 each bit 9 of RSN#6 - RSN#1. Therefore bits 6 - 2 are set *
*                 to 0 and bit 1 is set to bit 9 of SSN (write)of RX buffer.*
*                 Then it returns 2.                                        *
*     Called by:  FU10ACTX.C/FU10PduTx()                                    *
*                                                                           *
*****************************************************************************
*/
EXPORT uint8 
FU10PduRxAck (uint8 Lln, FPTR *PduDataP, uint8 UpDate )           // Not Used
{
uint8   XDATA Lu10Byte;
uint8   XDATA AckFlag = FALSE;
uint16  XDATA RSNCount = 0;
uint16  XDATA TempSSN = 0;
uint8   XDATA Count = 0;
uint8   XDATA FU10cNumberOfRsnCount = 0;
FPTR    XDATA PduDataTempP = NULL;
PDU_BUFFER_STRUCT XDATA *PduRxBufPtr = NULL;


#ifdef FT // Fixed part terminal
  PduRxBufPtr = &PduRxBuf[Lln];
#else // Portable part terminal
  PduRxBufPtr = &PduRxBuf[0]; // set RX buffer as buffer for operation
#endif 

  if(PduRxBufPtr->Window < FU10_WINDOW_SIZE)// Is window size not exceeded?
  { // window size not exceeded, no acknowledge has to be sent
    return(0);
  }
  else
  { // window size is exceeded, acknowledge has to be sent
    if(PduRxBufPtr->AckReqCount > 0)// Any PDU, which has to be acknowledged?
    { // Acknowledgement of some PDU is needed
      PduDataTempP = *PduDataP; // set temp pointer to PDU data array
      // Search for PDUs to be acknowledged
      for (Count = 0 ; Count < PDU_BUFF_MAX; Count++ )
      {  //have to go to all buffer because of modulo operation with PDU_BUFF_MOD to determine SSN
        if(PduRxBufPtr->Pdu[Count & PDU_BUFF_MOD].AckState == FU10_RX_PDU_ACK)
        { // positive ack has to be sent
          // Get SSN
          TempSSN = *PduRxBufPtr->Pdu[Count & PDU_BUFF_MOD].DataP; // copy 8 LSB of RSN
          TempSSN |= ((uint16)(*PduRxBufPtr->Pdu[Count & PDU_BUFF_MOD].DataP + 1 & FU10_ES9_BIT))<<1; //copy bit 9 of RSN
          if (RSNCount < TempSSN)
          { // for Go_Back_N only highest SSN has to be acknowledged
            RSNCount = TempSSN;
          }
        AckFlag = TRUE;
        PduRxBufPtr->AckReqCount--;
        PduRxBufPtr->Pdu[Count & PDU_BUFF_MOD].AckState = FU10_RX_ACK_TRUE; // mark as acknowledged
        }
        else if (PduRxBufPtr->Pdu[Count & PDU_BUFF_MOD].AckState == FU10_RX_PDU_NACK)
        { // negative ack has to be sent, for Go_Back_N, loop ends here because
          // only last error free PDU has to be in acknowledge message
          // else if can remain for implementing SELestive retransmission mode
          break;
        }
      }//end for
      if(!AckFlag) // no PDU in window can be positively acknowledged 
      { // Set last acknowledged RSN to highest RSN of last window concerning Go_Back_N
        RSNCount = PduRxBufPtr->RSN - 1;
      } 
      // Build FU10c frame without FU10a header
      Lu10Byte = FU10C_NA_ACK; // NA1=0, NA2=1 (This frame contains only one ACK message in RSN#1, no NACKs)
      // If no other valid RSN is in FU10c frame, RSN#1 has to be repeated for for RSN#2 to RSN#6, which is
      // the case for Go_Back_N
      // Build FU10c frame
      for (Count = 0;Count < 6; Count++)//ByteCount = 0 = RSN#1, ..., 5 = RSN#6
      {
        *PduDataTempP = (uint8) RSNCount; // RSN #x
        Lu10Byte     |= ((uint8) RSNCount >> (8 - Count) ) & ( 1 << Count); // bit 9 of SSN of RX buffer
        PduDataTempP++;  // next byte 
      }
    *PduDataTempP   = Lu10Byte; //NA1, NA2, bit 9 of RSN#1 - #6
 
      return (7); // for Go_Back_N only one FU10c is used so 7 bytes in FU10c frame 
    }
    else
    {// Acknowledgement is not needed but window size has been exceeded
     // Actually this point should never be reached
      return(-1);
    }
  }
}

/*
*****************************************************************************
*                                                                           *
*     Function :  FU10UpdateLifeTimeRxBuffer                                *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Decrements life time counter of all PDUs in Rx buffer     *
*     Parms    :  Decrements value                                          *
*     Returns  :  none                                                      *
*     Remarks  :  The PDU life time is counted in TDMA frames. The decrement*
*                 determines the number of TDMA frames which have passed    *
*                 since last call of this function.
*                                                                           *
*     Called by:  TODO                                                      *
*                                                                           *
*****************************************************************************
*/
#ifdef CATIQ_UPLANE_NO_JET
EXPORT void
FU10UpdateLifeTimeRxBuffer (uint8 Decrement)                      // Not Used
{
  uint8 XDATA Count = 0;

  for (Count = 0 ; Count <= PDU_BUFF_MAX; Count++ )
  {  //have to go to all buffers
    if( (PduRxBuf->Pdu[Count & PDU_BUFF_MOD].AckState != FU10_IDLE ) )
    {  // to be decremented
      if (PduRxBuf->Pdu[Count & PDU_BUFF_MOD].LifeTime >= Decrement)
      {
        PduRxBuf->Pdu[Count & PDU_BUFF_MOD].LifeTime -= Decrement;
      }
      else if (PduRxBuf->Pdu[Count & PDU_BUFF_MOD].LifeTime < Decrement)
      {
        PduRxBuf->Pdu[Count & PDU_BUFF_MOD].LifeTime = 0;
      }
    }
  }//end for loop

  return;
}
#endif


/*
*****************************************************************************
*                                                                           *
*     Function :  FU10UpdateRxBufferRSN                                     *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Updates SSN of RX buffer concerning SSN of TX buffer      *
*     Parms    :  SSN of TX Buffer                                          *
*                 Locigal link number, Lln                                  *
*     Returns  :  none                                                      *
*     Remarks  :                                                            *
*                                                                           *
*     Called by:  TODO                                                      *
*                                                                           *
*****************************************************************************
*/
EXPORT void
FU10UpdateRxBufferSSN (uint8 Lln, uint8 SSN)                      // Not Used
{
  PDU_BUFFER_STRUCT XDATA *PduRxBufPtr;

#ifdef FT
  PduRxBufPtr = &PduRxBuf[Lln];
#else
  PduRxBufPtr = &PduRxBuf[0];
#endif 

 PduRxBufPtr->SSN = SSN;

 return;
}
#endif  //

#ifdef CATIQ_UPLANE_FUXX
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduRx   only for LU10                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Fills RX buffer with new received PDU data                *
*                 Checks whether it is retransmission or new PDU            *
*     Parms    :  Pointer to received PDU data, PduDataP                    *
*                 Locigal link number, Lln, Rx CRC State                    *
*     Returns  :  = 0 if no data or synch PDU has been received             *
*                 = number of buffered bytes when data or synch PDU has     *
*                   been received                                           *
*     Remarks  :                                                            *
*     Called by:  Todo                                                      *
*                                                                           *
*****************************************************************************
*/
EXPORT int8 
FU10PduRx (uint8 Lln, FPTR PduDataP, uint8 RCrc, uint8  FrmCnt)   // Old Algorithm
{
   uint8 XDATA    PduALength;    // length of FU10A PDU
   int16 XDATA    PduSSN;
   int16 XDATA    RSN;
   int16 XDATA    PduDeltaSSN;

   PDU_BUFFER_STRUCT XDATA  *PduRxBufPtr;
   PDU_DATA_STRUCT   XDATA  *PduDataTempP;

   SET_PORT_DEBUG( FU10RX_ACTIVE );
   if( Lln >= DLC_U_LLN_MAX )
   {
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( -1 );
   }

   // Check FU10 Protocol Method and process related function call.
   if (FU10Method[ Lln ] != SUOTA_V1_1_1) {
      return (FU10PduRxV131 (Lln, PduDataP, RCrc, FrmCnt));
   }

   PduRxBufPtr = &PduRxBuf[ Lln ];
  
#if 1  // For RTX
   if( (PduDataP[0] == 0xA0) && (PduDataP[1] == 0x0F) && (PduDataP[2] == 0x0F) && (PduDataP[3] == 0x0F) )
   {
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( 0 );
   }
#endif

   if( (PduRxBufPtr->State != UPCON_ACTIV) || ((RCrc&IPALL_OK) == 0) ||
       (PduRxBufPtr->FrmCnt == FrmCnt) )
   {
      PduRxBufPtr->FrmCnt = FrmCnt;
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( 0 );
   }
   PduRxBufPtr->FrmCnt = FrmCnt;

   PduSSN       = PduDataP[ 1 ] & FU10_ES9_BIT;
   PduSSN       = (PduSSN << 1) | PduDataP[ 0 ];

   // set temp pointer to PDU RX buffer
   PduDataTempP = &PduRxBufPtr->Pdu[ PduSSN & PDU_BUFF_MOD ];

   // Check FU10C(ACK/NACK) messages
   PduDataP   += FU10PduTxAckSync (Lln, PduDataP );

   // FU10 A
   PduALength = (PduDataP[ 1 ] & FU10_LENGTH_FIELD_M) >> 1;
   if( (PduALength > PDU_DATA_LEN) || (PduALength == 0) )
   {
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( 0 );
   }

   // Acceptable PDU = expected RSN, last RSN of current Window (for sending ACK message to sender),
   //                  Within Window Size (for sending NACK message to sender)

   // expected RSN
   RSN         = (PduRxBufPtr->RSN + PduRxBufPtr->uni.WindowIndex) & FU10A_SSN_MOD;
   // Last RSN before current Window (Start RSN of Current Window - 1)
   PduDeltaSSN = (PduRxBufPtr->RSN - 1) & FU10A_SSN_MOD;
   if( (PduRxBufPtr->RSN + FU10_WINDOW_RANGE) > FU10A_SSN_MOD ) {
      if( PduSSN < FU10_WINDOW_RANGE ) {
         if( PduSSN > ((PduRxBufPtr->RSN + FU10_WINDOW_RANGE) & FU10A_SSN_MOD) ) {
            SET_PORT_DEBUG( UPLANE_NOACTIVE );
            return( 0 );
         }
      } else {
         if( PduSSN < PduDeltaSSN ) {  // CheckJonathan
            SET_PORT_DEBUG( UPLANE_NOACTIVE );
            return( 0 );
         }
      }
   } else {
      if( ((PduSSN < PduRxBufPtr->RSN) && (PduSSN != PduDeltaSSN) ) || 
           (PduSSN > (PduRxBufPtr->RSN + FU10_WINDOW_RANGE)) ) {
         SET_PORT_DEBUG( UPLANE_NOACTIVE );
         return( 0 );
      }
   }

   if( ((RSN == PduSSN) || (PduDeltaSSN == PduSSN)) && (PduALength > 0) &&
       ((PduDataTempP->AckState == FU10_IDLE) || (PduDataTempP->AckState == FU10_RX_PDU_NACK)) )
   {  // Copy PDU to SDU
      if( RSN == PduSSN )
      {
         PduDataTempP->Length   = PduALength;
         PduDataTempP->MBit     = (PduDataP[ 1 ] & FU10_MORE_BIT);
         CopyPdu2Sdu( Lln, &PduDataP[ PDU_HEADER_LEN ], PduALength, PduDataTempP->MBit );
         
         if( PduRxBufPtr->uni.WindowIndex < FU10_WINDOW_SIZE )
            PduRxBufPtr->uni.WindowIndex++;
         PduDataTempP->AckState = FU10_RX_PDU;
         PduRxBufPtr->Window++;
         PduRxBufPtr->AckReqCount++;
         //DECT_DEBUG_UPLANE("RX Data_1:%2x %2x %2x %2x\r\n", PduRxBufPtr->AckReqCount,
         //                  PduRxBufPtr->uni.WindowIndex, PduDataTempP->Length, PduDataTempP->MBit );
      }
      else if( PduDataTempP->MBit == 0 ) // PduDeltaSSN == PduSSN (Last PDU of previous Windows)
      {  // In order to send ACK again for latest received PDU
         PduDataTempP->Length   = PduALength;
         PduDataTempP->MBit     = (PduDataP[ 1 ] & FU10_MORE_BIT);
         PduRxBufPtr->SSN       = PduSSN;
         
         if( PduRxBufPtr->uni.WindowIndex < FU10_WINDOW_SIZE )
            PduRxBufPtr->uni.WindowIndex++;
         PduDataTempP->AckState = FU10_RX_PDU;
         PduRxBufPtr->Window++;
         PduRxBufPtr->AckReqCount++;
         //DECT_DEBUG_UPLANE("RX Data_2:%2x %2x %2x %2x\r\n", PduRxBufPtr->AckReqCount,
         //                  PduRxBufPtr->uni.WindowIndex, PduDataTempP->Length, PduDataTempP->MBit );
      }
   }
   else if( (PduDeltaSSN != PduSSN) && (PduSSN > RSN) )
   {  // request NACK
      for( PduDeltaSSN = RSN;  PduDeltaSSN != PduSSN;  PduDeltaSSN = (PduDeltaSSN + 1) & FU10A_SSN_MOD )
      {
         if( PduRxBufPtr->Pdu[ PduDeltaSSN & PDU_BUFF_MOD ].AckState == FU10_IDLE )
         {
            PduRxBufPtr->Pdu[ PduDeltaSSN & PDU_BUFF_MOD ].AckState  = FU10_RX_PDU_NACK;
            PduRxBufPtr->NAckCount++;
         }
      }
   }

   DECT_DEBUG_UPLANE("RX:%02x %02x %02x - %02x %02x - %04x %04x\r\n", PduRxBufPtr->AckReqCount,
                     PduRxBufPtr->uni.WindowIndex, PduRxBufPtr->NAckCount, PduDataTempP->Length,
                     PduDataTempP->MBit, PduRxBufPtr->RSN, PduRxBufPtr->SSN );
   SET_PORT_DEBUG( UPLANE_NOACTIVE );
   return( PduDataTempP->Length );
} 
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduRxAck   only for LU10                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Fills RX buffer with new received PDU data                *
*                 Checks whether it is retransmission or new PDU            *
*     Parms    :  Pointer to received PDU data, PduDataP                    *
*                 Locigal link number, Lln, Rx CRC State                    *
*     Returns  :  = 0 if no data or synch PDU has been received             *
*                 = number of buffered bytes when data or synch PDU has     *
*                   been received                                           *
*     Remarks  :                                                            *
*     Called by:  Todo                                                      *
*                                                                           *
*****************************************************************************
*/

EXPORT uint8 
FU10PduRxAck (uint8 Lln, FPTR PduDataP, uint8 UpDate )
{
   PDU_BUFFER_STRUCT XDATA *PduRxBufPtr;
   FPTR    XDATA           Fu10cP;
   uint16  XDATA           RSN;
   uint16  XDATA           SSN;
   uint8   XDATA           RSNmod;
   uint8   XDATA           TempCnt;
   uint8   XDATA           Fu10cER9 = 0;

   if( Lln >= DLC_U_LLN_MAX )
   {
      return( 0 );
   }
   PduRxBufPtr = &PduRxBuf[ Lln ];
   // Unused routine in new protocol scheme.
   if( (UpDate > 0) && ((PduDataP[FU10A_LENIN_FIELD]&FU10_LENGTH_FIELD_M) < FU10_SYNC_MESS) )
   {
      return( 0 );
   }

   // Any ACK or NACK messages are required ?
   if( (PduRxBufPtr->AckReqCount == 0) && (PduRxBufPtr->NAckCount == 0) )
   {
      return( 0 );
   }

   // FU10C_NA_ACK_5NACK.
   // This frame contains one ACK message in RSN#1plus five NACK messages in RSN#2-RSN#6
   if( PduRxBufPtr->NAckCount > 0 )
   {
      DECT_DEBUG_UPLANE("RX NACK1:%2x %4x %4x\r\n", PduRxBufPtr->NAckCount,
                        PduRxBufPtr->RSN, PduRxBufPtr->SSN );
      RSN = (PduRxBufPtr->RSN + PduRxBufPtr->uni.WindowIndex) & FU10A_SSN_MOD;
      for( ;  (PduRxBufPtr->Pdu[ PduRxBufPtr->SSN & PDU_BUFF_MOD ].AckState == FU10_RX_PDU) &&
              (RSN != PduRxBufPtr->SSN) && (PduRxBufPtr->AckReqCount > 0);  )
      {
         PduRxBufPtr->AckReqCount--;
         PduRxBufPtr->Window--;
         PduRxBufPtr->Pdu[ PduRxBufPtr->SSN & PDU_BUFF_MOD ].AckState = FU10_IDLE;
         PduRxBufPtr->SSN = (PduRxBufPtr->SSN + 1) & FU10A_SSN_MOD;
      }
      // Move RX PDU Window
      PduRxBufPtr->RSN = RSN;       
      PduRxBufPtr->uni.WindowIndex = 0;

      DECT_DEBUG_UPLANE("RX NACK2:%02x %02x %02x - %04x %04x\r\n", PduRxBufPtr->AckReqCount,
                        PduRxBufPtr->uni.WindowIndex, PduRxBufPtr->NAckCount, 
                        PduRxBufPtr->RSN, PduRxBufPtr->SSN );
      PduDataP++;  
      *PduDataP++ = FU10_ACK_MESS;

      // FU10c RSN # 1 
      Fu10cP = PduRxBufPtr->LastFu10c;
#if 1  // FIXED_SSN
      SSN = PduRxBufPtr->SSN;
#else
      SSN = (PduRxBufPtr->SSN - 1) & FU10A_SSN_MOD;
#endif
      if( SSN & 0x0100 )
      {
          Fu10cER9     = FU10C_RSN1_ER9_M;
      }
      *PduDataP++ = (uint8)(SSN);
      *Fu10cP++   = (uint8)(SSN);

      // FU10c RSN # 2 to #6
      // Go Back 2 NACK
      SSN = PduRxBufPtr->RSN;
      TempCnt = 0;
      for( RSNmod = 0;  RSNmod < PDU_BUFF_MAX;  RSNmod++ )
      {
         if( PduRxBufPtr->Pdu[ SSN & PDU_BUFF_MOD ].AckState != FU10_RX_PDU_NACK )
            break;

         if( PduRxBufPtr->NAckCount == 0 )
            break;

         PduRxBufPtr->NAckCount--;
         PduRxBufPtr->Pdu[ SSN & PDU_BUFF_MOD ].AckState = FU10_IDLE;
         *PduDataP = (uint8)(SSN);
         *Fu10cP   = (uint8)(SSN);
         if( SSN & 0x0100 )
         {
            Fu10cER9 |= (0x02 << TempCnt );
         }
         if( TempCnt < MAX_NACK )
         {
            PduDataP++;
            Fu10cP++;
            TempCnt++;
         }
         SSN = (SSN + 1) & FU10A_SSN_MOD;
      }
      for( ;  TempCnt < MAX_NACK;  TempCnt++ )
      {
         *PduDataP++ = (uint8)(SSN);
         *Fu10cP++   = (uint8)(SSN);
         if( SSN & 0x0100 )
            Fu10cER9 |= (0x02 << TempCnt );
      }

      *PduDataP = Fu10cER9 | FU10C_NA_ACK_5NACK;
      *Fu10cP   = Fu10cER9 | FU10C_NA_ACK_5NACK;

      PduRxBufPtr->NAckCount = 0;
      return( PDU_FU10AC_OFFSET + PDU_FU10C_HEADER_LEN );
   }
    
   // FU10C_NA_ACK. 
   // This frame contains only one ACK message in RSN#1, no NACKs.
   if( PduRxBufPtr->AckReqCount > 0 )
   {
      DECT_DEBUG_UPLANE("RX ACK:%2x %2x %4x %4x\r\n", PduRxBufPtr->AckReqCount,
                        PduRxBufPtr->uni.WindowIndex, PduRxBufPtr->RSN, PduRxBufPtr->SSN );
      if( PduRxBufPtr->RSN == PduRxBufPtr->SSN )
      {
         TempCnt = 0;
         RSN = PduRxBufPtr->RSN;
         for( RSNmod = 0;  RSNmod < PduRxBufPtr->uni.WindowIndex;  RSNmod++ )
         {
            if( PduRxBufPtr->Pdu[ RSN & PDU_BUFF_MOD ].MBit != FU10_MORE_BIT )
            {
               TempCnt = 1;
               break;
            }
            
            RSN = (RSN + 1) & FU10A_SSN_MOD;
         }
      
         // Not yet reached window full or no SDU finished.
         // So, wait until window full or last SDU data is received.
         if( (PduRxBufPtr->uni.WindowIndex < FU10_WINDOW_SIZE_ACK) && (TempCnt == 0) )
         //if( (PduRxBufPtr->uni.WindowIndex < FU10_WINDOW_SIZE) && (TempCnt == 0) )
            return( 0 );

         // Move RX PDU Window
         PduRxBufPtr->RSN = (PduRxBufPtr->RSN + PduRxBufPtr->uni.WindowIndex) & FU10A_SSN_MOD;
      }
      PduRxBufPtr->uni.WindowIndex = 0;
                  
      for( ;  (PduRxBufPtr->Pdu[PduRxBufPtr->SSN & PDU_BUFF_MOD].AckState == FU10_RX_PDU) &&
              (PduRxBufPtr->RSN != PduRxBufPtr->SSN) && (PduRxBufPtr->AckReqCount > 0);   )
      {
         PduRxBufPtr->AckReqCount--;
         PduRxBufPtr->Window--;
         PduRxBufPtr->Pdu[ PduRxBufPtr->SSN & PDU_BUFF_MOD ].AckState = FU10_IDLE;
         PduRxBufPtr->SSN = (PduRxBufPtr->SSN+1)&FU10A_SSN_MOD;
      }
      SSN = PduRxBufPtr->SSN;
      PduDataP++;  
      *PduDataP++ = FU10_ACK_MESS;

      // FU10c RSN # 1 to #6
      Fu10cP = PduRxBufPtr->LastFu10c;
#if 1  // FIXED_SSN
      SSN = PduRxBufPtr->SSN;             // ACK RSN should be received SSN + 1
#else
      SSN = (PduRxBufPtr->SSN - 1) & FU10A_SSN_MOD;
#endif
      if( SSN & 0x0100 )
      {
         Fu10cER9 = 0x3F;
         //Fu10cER9 = FU10C_RSN1_ER9_M;
      }
      *PduDataP++ = (uint8)(SSN);
      *PduDataP++ = (uint8)(SSN); // NULL SSN
      *PduDataP++ = (uint8)(SSN);
      *PduDataP++ = (uint8)(SSN);
      *PduDataP++ = (uint8)(SSN);
      *PduDataP++ = (uint8)(SSN);
      *PduDataP   =  Fu10cER9 | FU10C_NA_ACK;

      *Fu10cP++ = (uint8)(SSN);
      *Fu10cP++ = (uint8)(SSN);  // NULL SSN
      *Fu10cP++ = (uint8)(SSN);
      *Fu10cP++ = (uint8)(SSN);
      *Fu10cP++ = (uint8)(SSN);
      *Fu10cP++ = (uint8)(SSN);
      *Fu10cP   =  Fu10cER9 | FU10C_NA_ACK;
      return( PDU_FU10AC_OFFSET + PDU_FU10C_HEADER_LEN );
   }

   // Not used at this time.
   if( UpDate > 0 )
   {
      Mmu_Memcpy(&PduDataP[FU10C_RSN1],PduRxBufPtr->LastFu10c,FU10C_LEN);
      return( PDU_FU10AC_OFFSET + PDU_FU10C_HEADER_LEN );
   }

   return( 0 );
}

EXPORT uint8
FU10PduRxAck2( uint8 Lln, FPTR PduDataP )
{
   PDU_BUFFER_STRUCT XDATA *PduRxBufPtr;
   FPTR XDATA              Fu10cP;

   uint16  XDATA           SSN;
   uint8   XDATA           Fu10cER9 = 0;

#ifdef FT // Fixed part terminal
   if( Lln >= DLC_U_LLN_MAX )
   {
      return( 0 );
   }
   PduRxBufPtr = &PduRxBuf[Lln];
#else // Portable part terminal
   Lln = Lln;
   PduRxBufPtr = &PduRxBuf[ 0 ];    // set the RX buffer as buffer for operation
#endif

   /* FU10C_NA_ACK This frame contains only one ACK message in RSN#1, no NACKs */
   PduDataP++;
   *PduDataP++ = FU10_ACK_MESS;
   // FU10c RSN # 1 to #6
   Fu10cP = PduRxBufPtr->LastFu10c;
   SSN = (PduRxBufPtr->SSN - 1) & FU10A_SSN_MOD;
   if( SSN & 0x0100 )
   {
      Fu10cER9 = 0x3F;
   }
   *PduDataP++ = (BYTE)(SSN);
   *PduDataP++ = (BYTE)(SSN);
   *PduDataP++ = (BYTE)(SSN);
   *PduDataP++ = (BYTE)(SSN);
   *PduDataP++ = (BYTE)(SSN);
   *PduDataP++ = (BYTE)(SSN);
   *PduDataP   = Fu10cER9 | FU10C_NA_ACK;

   *Fu10cP++ = (BYTE)(SSN);
   *Fu10cP++ = (BYTE)(SSN);
   *Fu10cP++ = (BYTE)(SSN);
   *Fu10cP++ = (BYTE)(SSN);
   *Fu10cP++ = (BYTE)(SSN);
   *Fu10cP++ = (BYTE)(SSN);
   *Fu10cP   = Fu10cER9 | FU10C_NA_ACK;
   return( PDU_FU10AC_OFFSET + PDU_FU10C_HEADER_LEN );
}
#endif  //#ifndef CATIQ_UPLANE_FUXX

#ifdef CATIQ_UPLANE_FU10_NEW_STD
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduRx   only for LU10                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Fills RX buffer with new received PDU data                *
*                 Checks whether it is retransmission or new PDU            *
*     Parms    :  Pointer to received PDU data, PduDataP                    *
*                 Locigal link number, Lln, Rx CRC State                    *
*     Returns  :  = 0 if no data or synch PDU has been received             *
*                 = number of buffered bytes when data or synch PDU has     *
*                   been received                                           *
*     Remarks  :                                                            *
*     Called by:  Todo                                                      *
*                                                                           *
*****************************************************************************
*/
EXPORT int8 
FU10PduRxV131 (uint8 Lln, FPTR PduDataP, uint8 RCrc, uint8  FrmCnt)   // New Algorithm
{
   uint8  XDATA    PduALength;    // length of FU10A PDU
   uint16 XDATA    PduSSN;

   PDU_BUFFER_STRUCT XDATA  *PduRxBufPtr;
   PDU_DATA_STRUCT   XDATA  *PduDataTempP;

   SET_PORT_DEBUG( FU10RX_ACTIVE );
   
   if (Lln >= DLC_U_LLN_MAX) {
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( -1 );
   }
   
   PduRxBufPtr = &PduRxBuf[ Lln ];

   #if 1  // For RTX
   if ((PduDataP[0] == 0xA0) && (PduDataP[1] == 0x0F) && (PduDataP[2] == 0x0F) && (PduDataP[3] == 0x0F)) {
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( 0 );
   }
   #endif

   if ((PduRxBufPtr->State != UPCON_ACTIV) || ((RCrc&IPALL_OK) == 0) ||
       (PduRxBufPtr->FrmCnt == FrmCnt)) {
      PduRxBufPtr->FrmCnt = FrmCnt;
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( 0 );
   }
   
   PduRxBufPtr->FrmCnt = FrmCnt;
   PduSSN = PduDataP[ 1 ] & FU10_ES9_BIT;
   PduSSN = (PduSSN << 1) | PduDataP[ 0 ];

   // FU10 A
   PduALength = (PduDataP[ 1 ] & FU10_LENGTH_FIELD_M) >> 1;
   //PduRxBufPtr->AckReqCount++;
   // 0x7F => ACK PDU
   if (((PduALength > PDU_DATA_LEN) && (PduDataP[1] != 0x7F)) || (PduALength == 0)) {
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( 0 );
   }

   PduRxBufPtr->AckReqCount++;
   //DECT_DEBUG_UPLANE("RX:%02x %02x %02x\r\n", PduSSN, PduRxBufPtr->RSN, PduRxBufPtr->AckReqCount);

   // Acceptable PDU = Last RSN of current Window ~ (Last RSN + Window Size)
   if ((PduRxBufPtr->RSN + FU10C_WINDOW_RANGE) > FU10C_SSN_MOD) {
      if (PduSSN < FU10C_WINDOW_RANGE) {
         if (PduSSN > ((PduRxBufPtr->RSN + FU10C_WINDOW_RANGE) & FU10C_SSN_MOD)) {
            SET_PORT_DEBUG( UPLANE_NOACTIVE );
            return( 0 );
         }
      } else {
         if (PduSSN < PduRxBufPtr->RSN) {  // CheckJonathan
            if (PduSSN == ((PduRxBufPtr->RSN - 1) & FU10C_SSN_MOD)) {
               FU10PduTxAckSyncV131(Lln, PduDataP);
            }
            SET_PORT_DEBUG( UPLANE_NOACTIVE );
            return( 0 );
         }
      }
   } else {
      if ((PduSSN < PduRxBufPtr->RSN) || (PduSSN >= (PduRxBufPtr->RSN + FU10C_WINDOW_RANGE))) {
         if (PduSSN == ((PduRxBufPtr->RSN - 1) & FU10C_SSN_MOD)) {
            FU10PduTxAckSyncV131(Lln, PduDataP);
         }
         SET_PORT_DEBUG( UPLANE_NOACTIVE );
         return( 0 );
      }
   }

   // set temp pointer to PDU RX buffer
   PduDataTempP = &PduRxBufPtr->Pdu[ PduSSN & PDU_BUFF_MOD ];
   // Check FU10C(ACK/NACK) messages.
   // There is no (FU10C + FU10A) frame. So, if return > 0, then this frame not contain FU10A frame.
   if (FU10PduTxAckSyncV131(Lln, PduDataP) > 0) {
      //PduRxBufPtr->AckReqCount++;
      PduDataTempP->Length   = 0;
      PduDataTempP->MBit     = 0;
      PduDataTempP->AckState = FU10_RX_PDU;
      PduDataTempP->DataP[0] = PduDataP[0];
      PduDataTempP->DataP[1] = PduDataP[2];
      Mmu_Memset( &PduDataTempP->DataP[2], 0x00, PDU_DATA_LEN );
      
      SET_PORT_DEBUG( UPLANE_NOACTIVE );
      return( 0 );
   }

   if ((PduDataTempP->AckState == FU10_IDLE) || (PduDataTempP->AckState == FU10_RX_PDU_NACK)) {
      // Copy PDU to PDU RX Buffer
      PduDataTempP->Length   = PduALength;
      PduDataTempP->MBit     = (PduDataP[ 1 ] & FU10_MORE_BIT);
      Mmu_Memcpy( PduDataTempP->DataP, PduDataP, (PDU_HEADER_LEN + PduDataTempP->Length) );
      
      PduDataTempP->AckState = FU10_RX_PDU;
   }

   SET_PORT_DEBUG( UPLANE_NOACTIVE );
   return( PduDataTempP->Length );
} 
/*
*****************************************************************************
*                                                                           *
*     Function :  FU10PduRxAck   only for LU10                              *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  Fills RX buffer with new received PDU data                *
*                 Checks whether it is retransmission or new PDU            *
*     Parms    :  Pointer to received PDU data, PduDataP                    *
*                 Locigal link number, Lln, Rx CRC State                    *
*     Returns  :  = 0 if no data or synch PDU has been received             *
*                 = number of buffered bytes when data or synch PDU has     *
*                   been received                                           *
*     Remarks  :                                                            *
*     Called by:  Todo                                                      *
*                                                                           *
*****************************************************************************
*/

EXPORT uint8 
FU10PduRxAckV131 (uint8 Lln, FPTR PduDataP, uint8 UpDate )
{
   PDU_BUFFER_STRUCT XDATA *PduRxBufPtr;
   PDU_DATA_STRUCT   XDATA *PduDataTempP;
   FPTR    XDATA           Fu10cP;
   uint16  XDATA           RSN;
   uint16  XDATA           SSN;
   uint8   XDATA           RSNmod;
   uint8   XDATA           TempCnt;
   uint8   XDATA           Fu10cER9 = 0;

   if (Lln >= DLC_U_LLN_MAX) {
      return( 0 );
   }

   PduRxBufPtr = &PduRxBuf[ Lln ];
   // Unused routine in new protocol scheme.
   if ((UpDate > 0) && ((PduDataP[FU10A_LENIN_FIELD]&FU10_LENGTH_FIELD_M) < FU10_SYNC_MESS)) {
      return( 0 );
   }

   // Any ACK or NACK messages are required ?
   if (PduRxBufPtr->AckReqCount == 0) {
      return( 0 );
   }
    
   // FU10C_NA_ACK. 
   // This frame contains only one ACK message in RSN#1, no NACKs.
   if (PduRxBufPtr->AckReqCount > 0) {
      TempCnt = 0;
      RSN = PduRxBufPtr->RSN;
      PduRxBufPtr->uni.WindowIndex = 0;
      for (RSNmod = 0;  RSNmod < FU10C_WINDOW_SIZE;  RSNmod++) {
         PduDataTempP = &PduRxBufPtr->Pdu[ RSN & PDU_BUFF_MOD ];
         // Last PDU -> Stop evaluation and send ACK.
         if ((PduDataTempP->AckState == FU10_RX_PDU) && (PduDataTempP->Length > 0)) {
            if (PduDataTempP->MBit != FU10_MORE_BIT) {
               PduRxBufPtr->uni.WindowIndex++;
               TempCnt = 1;
               break;
            }
         }

         // No RX PDU -> Stop evaluation.
         if (PduDataTempP->AckState != FU10_RX_PDU) {
            if (PduRxBufPtr->AckReqCount >= FU10_WINDOW_SIZE_ACK) {
               // 4 PDUs or ACKs is received.
               TempCnt = 1;
            }
            if (PduRxBufPtr->NAckCount >= 8) {
               // 4 PDUs or ACKs is received.
               TempCnt = 1;
            }
            break;
         }
         
         PduRxBufPtr->uni.WindowIndex++;
         RSN = (RSN + 1) & FU10C_SSN_MOD;
      }

      //DECT_DEBUG_UPLANE("RXA:%02x %02x %02x %02x %02x\r\n", FU10_WINDOW_SIZE_ACK, RSN, PduRxBufPtr->RSN, PduRxBufPtr->uni.WindowIndex, TempCnt);
      if ((PduRxBufPtr->uni.WindowIndex < FU10_WINDOW_SIZE_ACK) && (TempCnt == 0))
         return( 0 );

      #if 0
      if (RSN == PduRxBufPtr->RSN) {
         if (++PduRxBufPtr->Window < (0x10 / FU10_WINDOW_SIZE_ACK)) {
            return( 0 );
         }
      }
      #endif

      PduRxBufPtr->Window = 0;
      PduRxBufPtr->RSN = (PduRxBufPtr->RSN + PduRxBufPtr->uni.WindowIndex) & FU10C_SSN_MOD;
                  
      for ( ; (PduRxBufPtr->Pdu[PduRxBufPtr->SSN & PDU_BUFF_MOD].AckState == FU10_RX_PDU) &&
              (PduRxBufPtr->RSN != PduRxBufPtr->SSN); ) {
         PduDataTempP = &PduRxBufPtr->Pdu[ PduRxBufPtr->SSN & PDU_BUFF_MOD ];
         CopyPdu2Sdu( Lln, &PduDataTempP->DataP[ PDU_HEADER_LEN ], PduDataTempP->Length, PduDataTempP->MBit );

         PduDataTempP->AckState = FU10_IDLE;
         PduRxBufPtr->SSN = (PduRxBufPtr->SSN+1) & FU10C_SSN_MOD;
      }
      DECT_DEBUG_UPLANE("RXACK:%02x %02x %02x\r\n", PduRxBufPtr->RSN, PduRxBufPtr->uni.WindowIndex, PduRxBufPtr->SSN);

      PduRxBufPtr->uni.WindowIndex = 0;
      PduRxBufPtr->AckReqCount = 0;
      PduRxBufPtr->NAckCount = 0;

      SSN = PduRxBufPtr->SSN;
      PduDataP++;  
      *PduDataP++ = FU10_ACK_MESS;

      // FU10c RSN # 1 to #6
      Fu10cP = PduRxBufPtr->LastFu10c;
      SSN = PduRxBufPtr->SSN;             // ACK RSN should be received SSN + 1

      if (SSN & 0x0100) {
         Fu10cER9 = FU10C_RSN1_ER9_M;
      }
      *PduDataP++ = (uint8)(SSN);
      *PduDataP++ = (uint8)(SSN);
      *PduDataP++ = (uint8)(SSN);
      *PduDataP++ = (uint8)(SSN);
      *PduDataP++ = (uint8)(SSN);
      *PduDataP++ = (uint8)(SSN);
      *PduDataP   =  Fu10cER9 | FU10C_NA_ACK;

      *Fu10cP++ = (uint8)(SSN);
      *Fu10cP++ = (uint8)(SSN);
      *Fu10cP++ = (uint8)(SSN);
      *Fu10cP++ = (uint8)(SSN);
      *Fu10cP++ = (uint8)(SSN);
      *Fu10cP++ = (uint8)(SSN);
      *Fu10cP   =  Fu10cER9 | FU10C_NA_ACK;
      return( PDU_FU10AC_OFFSET + PDU_FU10C_HEADER_LEN );
   }

   // Not used at this time.
   if (UpDate > 0) {
      #if 0
      Mmu_Memcpy(&PduDataP[FU10C_RSN1],PduRxBufPtr->LastFu10c,FU10C_LEN);
      return( PDU_FU10AC_OFFSET + PDU_FU10C_HEADER_LEN );
      #endif
   }

   return( 0 );
}
#endif  //#ifndef CATIQ_UPLANE_FUXX

#endif  //#ifdef CATIQ_UPLANE    

