/*
***********************************************************************************
*                                                                                 *
*     Project    :  PRODECT - DECT Home System Protocol Software V9.0             *
*                   (c) 2008 IFX / PEUCON. All rights reserved.                   *
*                                                                                 *
***********************************************************************************
*                                                                                 *
*     Workfile   :  uplane_if.c                                                   *
*     Date       :  16 Sep, 2008                                                  *
*     Contents   :  Implements interface between DECT Stack an DECT Uplane Agent  *
*     Hardware   :                                                                *
*                                                                                 *
***********************************************************************************
*/
/** \file
 * \brief Implements interface between DECT Stack an DECT Uplane Agent
 */

//------ INCLUDES -----------------------------------------------------------------
#ifdef LINUX
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#endif
#include "SYSDEF.H"
#include "uplane_if.h"
#include "MESSAGE_DEF.H"
#include "CAT_UP.H"
#include "DECT.H"
#include "ifx_common_defs.h"
#ifdef LINUX
#include "ifx_os.h"
#include "ifx_ipc.h"
#endif
#include "IFX_DECT_IEParser.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_MsgRouter.h"
#include "uplane_if.h"

//------ DEFINES CONDITIONAL COMPILATION -----------------------------------------

#if UPLANE_LOOP & UPLANE_FTLOOP1

// When UPLANE_FT1_LOOPBACK is set, all data that is sent from 
// stack-to-agent fifo is reflected into agent-to-stack fifo

#define UPLANE_FT1_LOOPBACK 1

#endif

#if 0  // JONATHAN_SUOTA_TEST
//#define MAX_TEST_SIZE   1324
//#define MAX_TEST_SIZE   10300
#define MAX_TEST_SIZE   12288
uint8  uTestArray[MAX_TEST_SIZE];
uint16 uIndex = 0;
uint8  SduRcvIn = 0;
uint8  TestData;
#endif


#ifdef LINUX
//------ DEFINES -----------------------------------------------------------------

#define FIFO_PERM 0644
#define AGENT_TO_STACK_UPLANE_FIFO DECT_STACK_FIFO_U
#endif
#define UPHEADERSIZE(pUpMsg)  (((unsigned long)&pUpMsg->acData) - (unsigned long)pUpMsg)
//#define UPSENDSIZE(pUpMsg)  (UPHEADERSIZE(pUpMsg)+(pUpMsg->ucPara1<<8)+pUpMsg->ucPara2)
#define UPSENDSIZE(x) (sizeof(x_IPC_UPlane_Msg))

#ifdef DECT_DEBUG_USER_APP_PRIMITIVE
typedef struct {
	BYTE key;
	char *string;
} DebugStringTable_t;

LOCAL DebugStringTable_t appMessageStringTable[] = {
   {FP_MEDIA_SDU_RCV_IN, "FP_MEDIA_SDU_RCV_IN"},
   {FP_MEDIA_SDU_FLOW_IN, "FP_MEDIA_SDU_FLOW_IN"},
   #ifdef ULE_SUPPORT
   {FP_ULE_MEDIA_SDU_RCV_IN, "FP_ULE_MEDIA_SDU_RCV_IN"},
   {FP_ULE_MEDIA_SDU_FLOW_IN, "FP_ULE_MEDIA_SDU_FLOW_IN"},
   {FP_ULE_MEDIA_SDU_STOP_CFM, "FP_ULE_MEDIA_SDU_STOP_CFM"},
   {FP_ULE_MEDIA_DLC_ERROR_IN, "FP_ULE_MEDIA_DLC_ERROR_IN"},
   #endif
   {0xFF, "Unknown Message"}
};
#endif

#ifdef DECT_DEBUG_USER_APP_PRIMITIVE
LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
{
	BYTE i;

	for (i = 0; tablePtr[i].key != 0xFF; i++) {
		if (tablePtr[i].key == key) {
			break;
		}
	}
	return tablePtr[i].string;
}
#endif

#ifdef LINUX
//------ Serve_UPMessage_Stack() --------------------------------------------------

// Fifo -> Stack
int Serve_UPMessage_Stack(x_IPC_UPlane_Msg *result)
{
  return IFX_DECT_MsgRt_ReadAppMsg(IFX_IPC_DECT_U_PLANE,(uchar8 *)result,sizeof(x_IPC_UPlane_Msg));
}

//------ Send_UPMessage_To_App() --------------------------------------------------
#endif
// Stack ->App

int Send_UPMessage_To_APP( unsigned  char aMsg, const unsigned  char *ptr, unsigned  char inc,
                           unsigned  char parameter1,  unsigned  char parameter2,  unsigned  char parameter3,  unsigned  char parameter4 )
{
  x_IPC_UPlane_Msg msg;
  int /*rc,*/len;

  #ifdef DECT_DEBUG_USER_APP_PRIMITIVE
  DECT_DEBUG_USER_APP_PRIMITIVE("%s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(aMsg, appMessageStringTable), inc,
                                parameter1, parameter2, parameter3, parameter4);
  #endif

   #if 0  // JONATHAN_SUOTA_TEST
   if (aMsg == FP_MEDIA_SDU_RCV_IN) {
      #ifdef DECT_DEBUG_USER_APP_PRIMITIVE
      DECT_DEBUG_USER_APP_PRIMITIVE("%s, %02x[%02x%02x%02x%02x]-[%02x%02x%02x%02x]\n", getDebugStringRef(aMsg, appMessageStringTable), inc,
                                 parameter1, parameter2, parameter3, parameter4, ptr[0], ptr[1], ptr[2], ptr[3]);
      #endif
      if (SduRcvIn == 0) {
         TestData = 0x30;
         for (len = 0;  len < MAX_TEST_SIZE;  len++) {
            uTestArray[len] = TestData;// 0x55;  //(uint8)(len & 0xFF);
            if (TestData == 0x39) {
               TestData = 0x30;
            } else {
               TestData++;
            }
         }
      }
      //usleep(500000);
      uIndex = 0;
      msg.ucMsgId=FP_MEDIA_SDU_SND_RQ;
      msg.ucInstance=inc;
      msg.ucPara1=(IFX_IPC_DECT_MAX_DATA_SIZE_U/256);
      //msg.ucPara2=0x78;    // 120 Bytes
      //msg.ucPara2=0x96;    // 150 Bytes
      msg.ucPara2=(IFX_IPC_DECT_MAX_DATA_SIZE_U%256);
      msg.ucPara3=0;
      msg.ucPara4=parameter4;
      memcpy(msg.acData, &uTestArray[uIndex], IFX_IPC_DECT_MAX_DATA_SIZE_U);
      uIndex = IFX_IPC_DECT_MAX_DATA_SIZE_U;
      SduRcvIn = 1;
      write(iDectUplaneFifoFd,&msg,sizeof(msg));
      return TRUE;
   }

   if (aMsg == FP_MEDIA_SDU_FLOW_IN) {
      if ((SduRcvIn & 0x0F) == 0) {
         return TRUE;
      }
      
      if ((uIndex > 0) && (uIndex < MAX_TEST_SIZE)) {
         msg.ucMsgId=FP_MEDIA_SDU_SND_RQ;
         if (uIndex < (MAX_TEST_SIZE - IFX_IPC_DECT_MAX_DATA_SIZE_U)) {
            msg.ucInstance=inc;
            msg.ucPara1=(IFX_IPC_DECT_MAX_DATA_SIZE_U/256);
            msg.ucPara2=(IFX_IPC_DECT_MAX_DATA_SIZE_U%256);
            msg.ucPara3=0;
            msg.ucPara4=parameter4;
            memcpy(msg.acData, &uTestArray[uIndex], IFX_IPC_DECT_MAX_DATA_SIZE_U);
            uIndex += IFX_IPC_DECT_MAX_DATA_SIZE_U;
         } else {
            msg.ucInstance=inc;
            msg.ucPara1=((MAX_TEST_SIZE - uIndex)/256);
            msg.ucPara2=((MAX_TEST_SIZE - uIndex)%256);
            msg.ucPara3=1;
            msg.ucPara4=parameter4;
            memcpy(msg.acData, &uTestArray[uIndex], MAX_TEST_SIZE - uIndex);
            uIndex += IFX_IPC_DECT_MAX_DATA_SIZE_U;
            SduRcvIn = 0x10;
         }
         write(iDectUplaneFifoFd,&msg,sizeof(msg));
      } else {
         uIndex = 0;
      }
      
      return TRUE;
   }
   #endif

  memset(&msg,0,sizeof(msg));
  msg.ucMsgId=aMsg;
  msg.ucInstance=inc;
  msg.ucPara1=parameter1;
  msg.ucPara2=parameter2;
  msg.ucPara3=parameter3;
  msg.ucPara4=parameter4;
  if(ptr)
  {
    len=(parameter1<<8)+parameter2;
    #ifdef KLOCWORK
    /* has to limit the max SDU uploading(from PP) IFX_IPC_DECT_MAX_DATA_SIZE_U(513), increase size to FIFO_MAX_LU10_SDU if enough resource  */
    if(len && (len<=IFX_IPC_DECT_MAX_DATA_SIZE_U))
    #else
    if(len && (len<=FIFO_MAX_LU10_SDU))
    #endif
      memcpy(msg.acData,ptr,len);
  }

  IFX_DECT_MsgRt_ProcessStackMessage(IFX_IPC_DECT_U_PLANE,&msg);

#if UPLANE_FT1_LOOPBACK
  // Set MsgId 
  msg.ucMsgId=FP_MEDIA_SDU_SND_RQ;
  rc=write(iDectUplaneFifoFd,&msg,sizeof(msg));
  
  DECT_DEBUG_UPLANE("FT1 Loop: Data send back to stack\n");
#endif
  
  return TRUE;
}

#ifdef LINUX
//------ Get_UPlaneAgentToStack_FifoDescriptor() -----------------------------------

int Get_UPlaneAgentToStack_FifoDescriptor(void)
{
  return iDectUplaneFifoFd;
}
#if 0
//------ UPFifoWrite() ------------------------------------------------------------

static int UPFifoWrite(int fd,const x_IPC_UPlane_Msg *applicationData)
{
  int rc,sizeSend;
  sizeSend=UPSENDSIZE(applicationData);
  rc=write(fd,(void*)applicationData,sizeSend);

  DECT_DEBUG_UPLANE("%s FIFO Write msg with %d bytes of data, %s\n", (fd==s_AgentToStackFifoFd)?"Ag->St":"St->Ag",     
    (applicationData->ucPara1<<8)+applicationData->ucPara2,(rc==sizeSend)?"OK":"Failed");
  return (rc==sizeSend) ? TRUE: FALSE;
}

//------ UPFifoRead() -------------------------------------------------------------

static int UPFifoRead(int fd,x_IPC_UPlane_Msg *result)
{

  // Always read full packets
  int rc;

  rc=read(fd,(void*)result,sizeof(*result));
  return (rc==sizeof(*result))?TRUE:FALSE;
}
#endif
#endif


