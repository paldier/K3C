/* -- SIEMENS AG  PCT -- Process: LAP         -  Mon Feb 26 14:22:28 2007 -- */
#include	"DEFINE.H"
#include <stdio.h>
# include "SYSDEF.H"
# include "FDEF.H"
# include "TYPEDEF.H"
extern void KNL_T0000(void);
# include "SYSEXT.H"

/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0       *
*                   (c) 2005 IFX / INTNIX. All rights reserved.             *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  FLAP.PSL                                                *
*     Date       :  18 Nov, 2005                                            *
*     Contents   :                                                          *
*     Hardware   :  IFX 87xx                                                *
*                                                                           *
*****************************************************************************
*/
/* ========                                                             */
/* Includes                                                             */
/* ========                                                             */
#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#include "FGLOBAL.H"
#include "PCT_DEF.H"
#include "KNL_SYSTEM.H"
#include "MMU.H"
#include "P_TIM.H"
#include "CC_DEF.H"
#include "CC_LIB.H"
#include "LC_LIB.H"

#include "LAP_LIB.H"

#include "DECT.H"		/* for debugging */
		
/* ==============                                                       */
/* Local typedefs                                                       */
/* ==============                                                       */
typedef struct
{
   BYTE NR;
   BYTE NS;
   BYTE RC200;
   BYTE VS;
   BYTE VA;
   BYTE VR;
   BYTE Ack_Pending;
   #ifdef CONFIG_UPDATE_LINK_RELEASE
   BOOL releasePending;
   BOOL releaseReqBySelf;
   #endif
   BYTE L3_Length;
   FPTR L3_Frame;
} LAP_TABLE_ELEMENT;

#ifdef DECT_DEBUG_USER_LAP_PRIMITIVE
typedef struct {
   BYTE key;
   char *string;
} DebugStringTable_t;
#endif
		
/* ===============                                                      */
/* Local Variables                                                      */
/* ===============                                                      */
LOCAL XDATA LAP_TABLE_ELEMENT LAP_Struct[ MAX_LINK ];

#ifdef DECT_DEBUG_USER_LAP_PRIMITIVE
LOCAL XDATA BOOL normalReleaseReqEnqueued;
LOCAL DebugStringTable_t stateStringTable[] = {
   {ULI_RELEASED, "ULI_RELEASED"},
   {ULI_CLASS_A_ESTABLISHED, "ULI_CLASS_A_ESTABLISHED"},
   {0xFF, "Unknown State"}
};

LOCAL DebugStringTable_t messageStringTable[] = {
   {LAP_DL_REL_RQ_NORMAL_LCE, "LAP_DL_REL_RQ_NORMAL_LCE"},
   {LAP_DL_REL_RQ_ABNORMAL_LCE, "LAP_DL_REL_RQ_ABNORMAL_LCE"},
   {LAP_I_FRAME_NLF_LC, "LAP_I_FRAME_NLF_LC"},
   {LAP_REL_IN_LC, "LAP_REL_IN_LC"},
   {LAP_REL_CFM_LC, "LAP_REL_CFM_LC"},
   {LAP_DL_DATA_RQ_LCE, "LAP_DL_DATA_RQ_LCE"},
   {LAP_I_FRAME_LC, "LAP_I_FRAME_LC"},
   {LAP_RR_FRAME_LC, "LAP_RR_FRAME_LC"},
   {LAP_RR_FRAME_NLF_LC, "LAP_RR_FRAME_NLF_LC"},
   {LAP_PRO_ERR_LC, "LAP_PRO_ERR_LC"},
   {LAP_TIM_DL_04_EXPIRED, "LAP_TIM_DL_04_EXPIRED"},
   {LAP_DL_ENC_KEY_RQ_LCE, "LAP_DL_ENC_KEY_RQ_LCE"},
   {LAP_DL_ENC_IND_LC, "LAP_DL_ENC_IND_LC"},
   #ifndef CONFIG_UPDATE_LINK_RELEASE
   {LAP_DL_REL_RQ_ABNORMAL_MM, "LAP_DL_REL_RQ_ABNORMAL_MM"},
   #endif
   {0xFF, "Unknown Message"}
};
#endif

/* ==========================                                           */
/* Global function definition                                           */
/* ==========================                                           */
EXPORT void
LAP_INIT( void )
{
   BYTE i;

   Init_Queue( LAP );
   for( i = 0; i < MAX_LINK; i++ )
   LAP_Struct[ i ].L3_Frame = NULL;
}

/* ==========================                                           */
/* Global function definition                                           */
/* ==========================                                           */
EXPORT void
RESET_LAP_INIT( void )
{
   BYTE i;

   for( i = 0; i < MAX_LINK; i++ )
      Discard_Queue(LAP, i);		// malloc queue clear by ralph_150508
   Init_Queue( LAP );
   for( i = 0; i < MAX_LINK; i++ )
      LAP_Struct[ i ].L3_Frame = NULL;
}

/* =========================                                            */
/* Local function definition                                            */
/* =========================                                            */
#ifdef DECT_DEBUG_USER_LAP_PRIMITIVE
LOCAL char *getDebugStringRef(BYTE key, DebugStringTable_t *tablePtr)
{
   BYTE i;

   for (i = 0; tablePtr[i].key != 0xFF; i++) {
      if (tablePtr[i].key == key) {
         break;
      }
   }
   return tablePtr[i].string;
}
#endif

LOCAL BIT
I_queue_empty( void )
{
   return( Empty_Queue( LAP, CurrentInc ));
}

LOCAL void
discard_I_queue( void )
{
   Discard_Queue( LAP, CurrentInc );
}

LOCAL FPTR
construct_RR_frame( BYTE nlf_bit )
{
   FPTR temp;

   temp = Construct_L2_Frame( nlf_bit, LLN_CLASS_A, S_SAP,
                              RESPONSE_TX, RR_TYP, M_BIT_CLEARED );
                                       /* The control field is updated !   */
      #ifdef KLOCWORK
      if( temp == NULL )   {
         return( temp );
      }
      #endif
   temp[ 1 + sizeof( struct HLI_Header ) ] |= ( LAP_Struct[ CurrentInc ].VR << 5  );
   return( temp );
}

LOCAL FPTR
get_next_I_queue_entry( void )
{
   FPTR temp;

                                       /* Only a 'copy' of the oldest      */
                                       /* LAP queue entry is requested. In */
                                       /* case of an unsuccessful          */
                                       /* transmission the I-frame must be */
                                       /* repeated !                       */
   temp = Get_Next_Queue_Entry_Copy( LAP, CurrentInc );
      #ifdef KLOCWORK
      if( temp == NULL )   {
         return( temp );
      }
      #endif
                                       /* The control field is updated !   */
   temp[ 1 + sizeof( struct HLI_Header ) ] |= ( LAP_Struct[ CurrentInc ].VR << 5  ) | ( LAP_Struct[ CurrentInc ].VS << 1 );
   return( temp );
}

LOCAL void
set_received_NR_value( void )
{
   LAP_Struct[ CurrentInc ].NR = ( G_PTR[ 1 + sizeof( struct HLI_Header ) ] >> 5 ) & 0x07;
}

LOCAL void
set_received_NR_NS_value( void )
{
   LAP_Struct[ CurrentInc ].NR = ( G_PTR[ 1 + sizeof( struct HLI_Header ) ] >> 5 ) & 0x07;
   LAP_Struct[ CurrentInc ].NS = ( G_PTR[ 1 + sizeof( struct HLI_Header ) ] >> 1 ) & 0x07;
}

LOCAL void
release_I_frame( void )
{
   Mmu_Free( Get_Next_Queue_Entry( LAP, CurrentInc ));
}

LOCAL FPTR
Assembly_L3_Frame( FPTR frame_ptr )
{
   BIT  M_Bit;
   BYTE Li;
   FPTR temp;

                                       /* Get the M-Bit setting !          */
   M_Bit = (frame_ptr[ 2 + sizeof( struct HLI_Header ) ] & 0x02) ? 1:0;
                                       /* Get L3 Frame Length !            */
   Li = ( frame_ptr[ 2 + sizeof( struct HLI_Header ) ] >> 2 ) & 0x3F;
                                       /* NTW Layer frame there ?          */
   if( Li == 0 )
   {
      Mmu_Free( frame_ptr );
      return( NULL );
   }
                                       /* Get the memory for the new       */
                                       /* L3 segment.                      */
   if( LAP_Struct[ CurrentInc ].L3_Frame == NULL )
   {
                                       /* No segment is stored. The        */
                                       /* Mmu_Malloc allocates memory for  */
                                       /* the first segment plus HLI       */
                                       /* Header size.                     */
      LAP_Struct[ CurrentInc ].L3_Length = sizeof( struct HLI_Header );
      LAP_Struct[ CurrentInc ].L3_Frame  = Mmu_Malloc( sizeof( struct HLI_Header ) + Li );
   }
   else
   {
                                       /* A segment is already stored. The */
                                       /* Mmu_Realloc function is called   */
                                       /* to adjust the memory.            */
      LAP_Struct[ CurrentInc ].L3_Frame = Mmu_Realloc( LAP_Struct[ CurrentInc ].L3_Frame,
      LAP_Struct[ CurrentInc ].L3_Length + Li );
   }
                                       /* Overflow condition.              */
                                       /* -------------------------------- */
                                       /* The whole MMU concept is based   */
                                       /* on a byte length indicator.      */
                                       /* If the L3-frame exceeds the      */
                                       /* maximum length, the frame is     */
                                       /* ignored !                        */
   if( LAP_Struct[ CurrentInc ].L3_Length + Li > 250 )
   {
      Mmu_Free( frame_ptr );
      Mmu_Free( LAP_Struct[ CurrentInc ].L3_Frame );
      LAP_Struct[ CurrentInc ].L3_Frame = NULL;
      LAP_Struct[ CurrentInc ].L3_Length = 0;
      return( NULL );
   }
                                       /* Copy frame content.              */
   Mmu_Memcpy( &LAP_Struct[ CurrentInc ].L3_Frame[ LAP_Struct[ CurrentInc ].L3_Length ],
               &frame_ptr[ CS_HEADER_LENGTH + sizeof( struct HLI_Header ) ],
               Li );
                                       /* Adjust new L3-Frame length.      */
   LAP_Struct[ CurrentInc ].L3_Length += Li;
                                       /* Release received I-frame buffer. */
   Mmu_Free( frame_ptr );

   if( M_Bit == M_BIT_CLEARED )
   {
                                       /* If the last segment is received, */
                                       /* the whole L3-Frame is returned.  */
      temp = LAP_Struct[ CurrentInc ].L3_Frame;
             (( struct HLI_Header * ) temp ) -> length = LAP_Struct[ CurrentInc ].L3_Length;
      LAP_Struct[ CurrentInc ].L3_Frame  = NULL;
      LAP_Struct[ CurrentInc ].L3_Length = 0;
      return( temp );
   }
   else
   {
                                       /* Assembly of the L3-Frame not yet */
                                       /* completed. Wait for the next     */
                                       /* segement to receive.             */
      return( NULL );
   }
}

LOCAL void
reset_LAP_Struct( void )
{
   LAP_Struct[ CurrentInc ].NR          = 0;
   LAP_Struct[ CurrentInc ].NS          = 0;
   LAP_Struct[ CurrentInc ].RC200       = 0;
   LAP_Struct[ CurrentInc ].VS          = 0;
   LAP_Struct[ CurrentInc ].VA          = 0;
   LAP_Struct[ CurrentInc ].VR          = 0;
   LAP_Struct[ CurrentInc ].Ack_Pending = FALSE;
   LAP_Struct[ CurrentInc ].L3_Length   = 0;
   #ifdef CONFIG_UPDATE_LINK_RELEASE
   LAP_Struct[ CurrentInc ].releasePending = NO;
   LAP_Struct[ CurrentInc ].releaseReqBySelf = NO;
   #endif
   if( LAP_Struct[ CurrentInc ].L3_Frame != NULL )
      Mmu_Free( LAP_Struct[ CurrentInc ].L3_Frame );
   LAP_Struct[ CurrentInc ].L3_Frame = NULL;
}


static void T0201( void )
{
   /* TRANSITION:      T201                                                 */
   /* EVENT:           LAP_REL_CFM_LC                                       */
   /* DESCRIPTION:     Data Link Release Confirm                            */
   /* REFERENCE:       ETS 300 175-4:1996                                   */
   /* STARTING STATE:  ULI_RELEASED                                         */
   /* END STATE:       ULI_RELEASED                                         */
   /* ----------------------------------------------------------------------*/
   #ifdef DECT_DEBUG_USER_LAP_PRIMITIVE
   if (CurrentMessage == LAP_DL_REL_RQ_NORMAL_LCE) {
      DECT_DEBUG_USER_LAP_PRIMITIVE("%s, %s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable),
      getDebugStringRef(CurrentState, stateStringTable), CurrentInc, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
      normalReleaseReqEnqueued = NO;
   }
   #endif
   #ifdef CONFIG_UPDATE_LINK_RELEASE
   if (LAP_Struct[CurrentInc].releasePending)
   #endif
   {
      #ifdef CONFIG_UPDATE_LINK_RELEASE
      BYTE message;

      if (LAP_Struct[CurrentInc].releaseReqBySelf) {
         message = LCE_DL_REL_IN_LAP;
      } else {
         message = LCE_DL_REL_CFM_LAP;
      }
      #endif
      
      discard_I_queue();
                                       /* Reset LAP Process Structure.     */
      reset_LAP_Struct();
                                       /* Stop all DLC-Timer.              */
      Stop_Pro_Timer( TIMER_DL_04, CurrentInc );
      #ifdef xxxCONFIG_REPEATER_SUPPORT
      KNL_SENDTASK_INC( LAP_REP, LAP_REL_CFM_LC, CurrentInc );
      #endif
      #ifdef CONFIG_UPDATE_LINK_RELEASE
      KNL_SENDTASK_INC( LCE, message, CurrentInc );
      #else
      KNL_SENDTASK_INC( LCE, LCE_DL_REL_CFM_LAP, CurrentInc );
      #endif
      KNL_Transit( ULI_RELEASED );
   }
}

static void T0100( void )
{
   /* TRANSITION:      T100                                                 */
   /* EVENT:           LAP_I_FRAME_NLF_LC                                   */
   /* DESCRIPTION:     Data Link Establish Request, CLASS A                 */
   /* REFERENCE:       ETS 300 175-4:1996                                   */
   /* STARTING STATE:  ULI_RELEASED                                         */
   /* END STATE:       ULI_RELEASED / ULI_CLASS_A_ESTABLISHED               */
   /* ----------------------------------------------------------------------*/
   FPTR temp;
                                       /* Discard I-Queue.                 */
   discard_I_queue();
                                       /* Reset LAP Process Structure.     */
   reset_LAP_Struct();
                                       /* Stop all DLC-Timer.              */
   Stop_Pro_Timer( TIMER_DL_04, CurrentInc );

   set_received_NR_NS_value();
                                       /* The Receive State Variable V(R)  */
                                       /* denotes the sequence number of   */
                                       /* the next-in-sequence I-frame     */
                                       /* expected to be received.         */
                                       /* The I-frame is only in-sequence, */
                                       /* when the Receive State Variable  */
                                       /* V(R) and the Send Sequence       */
                                       /* Number N(S) are equal.           */
   if( LAP_Struct[ CurrentInc ].NS == LAP_Struct[ CurrentInc ].VR )
   {
                                       /* The received I-frame is          */
                                       /* in-sequence !                    */
                                       /* -------------------------------- */
                                       /* The Receive State Variable V(R)  */
                                       /* is incremented.                  */
      LAP_Struct[ CurrentInc ].VR = Increment( LAP_Struct[ CurrentInc ].VR, SEQUENCEMAX );
                                       /* Report the link reestablishment  */
                                       /* to the LCE process.              */
      KNL_SENDTASK_INC( LCE, LCE_DL_EST_IN_LAP, CurrentInc );
                                       /* Assembly the received L3-Frame.  */
                                       /* -------------------------------- */
      temp = Assembly_L3_Frame( G_PTR );
                                       /* The L3 frame is only transferred */
                                       /* to the NTW-Layer when the last   */
                                       /* segment is received.             */
      if( temp != NULL )
      {
         KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_IN_LAP, temp, CurrentInc );
      }
                                       /* The I-frame must be acknowledged */
                                       /* with a RR-frame.                 */
      KNL_SENDTASK_NP_INC( LC, LC_CO_DATA_RQ_LAP, construct_RR_frame( NLF_SET ), CurrentInc );
      KNL_Transit( ULI_CLASS_A_ESTABLISHED );
   }
   else
   {
                                       /* The received I-frame is NOT      */
                                       /* in-sequence !                    */
                                       /* -------------------------------- */
                                       /* The I-frame is ignored.          */
      Mmu_Free( G_PTR );
   }
}

static void T0202( void )
{
   /* TRANSITION:      T202                                                 */
   /* EVENT:           LAP_REL_IN_LC / LAP_PRO_ERR_LC                       */
   /* DESCRIPTION:     Data Link Release Indication                         */
   /* REFERENCE:       ETS 300 175-4:1996                                   */
   /* STARTING STATE:  all                                                  */
   /* END STATE:       ULI_RELEASED                                         */
   /* ----------------------------------------------------------------------*/
   #ifdef CONFIG_UPDATE_LINK_RELEASE
   if (CurrentState == ULI_RELEASED) {
      if (!LAP_Struct[CurrentInc].releasePending) {
         return;
      }
   }
   #endif

   discard_I_queue();
                                       /* Reset LAP Process Structure.     */
   reset_LAP_Struct();
                                       /* Stop all DLC-Timer.              */
   Stop_Pro_Timer( TIMER_DL_04, CurrentInc );
   #ifdef xxxCONFIG_REPEATER_SUPPORT
   KNL_SENDTASK_INC( LAP_REP, LAP_REL_CFM_LC, CurrentInc );
   #endif
   KNL_SENDTASK_INC( LCE, LCE_DL_REL_IN_LAP, CurrentInc );
   KNL_Transit( ULI_RELEASED );
}

void DECODE_LAP(void)
{
   #ifdef DECT_DEBUG_USER_LAP_PRIMITIVE
   if (CurrentMessage != LAP_DL_REL_RQ_NORMAL_LCE) {
      DECT_DEBUG_USER_LAP_PRIMITIVE("%s, %s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable),
      getDebugStringRef(CurrentState, stateStringTable), CurrentInc, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
   }
   #endif

   switch (CurrentState) 
   {
      /**********************************
       ULI_RELEASED State
      **********************************/
      case ULI_RELEASED:
         switch (CurrentMessage) 
         {
            #ifndef CONFIG_UPDATE_LINK_RELEASE
            case LAP_DL_REL_RQ_NORMAL_LCE: 
            case LAP_DL_REL_RQ_ABNORMAL_LCE: 
            #endif
            case LAP_REL_CFM_LC: 
               T0201();
               return;

            case LAP_I_FRAME_NLF_LC: 
               T0100();
               return;

            case LAP_REL_IN_LC: 
               T0202();
               return;

            default:
               break;
         }                                   /* end of switch message            */
         break; 


      /**********************************
       ULI_CLASS_A_ESTABLISHED State
      **********************************/
      case ULI_CLASS_A_ESTABLISHED:
         switch (CurrentMessage) 
         {
            case LAP_DL_REL_RQ_NORMAL_LCE:  /*  IN LINE CODE T0200    */
            {
               /* TRANSITION:      T200                                                 */
               /* EVENT:           LAP_DL_REL_RQ_NORMAL_LCE                             */
               /* DESCRIPTION:     Data Link Release Request, normal                    */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
               /* END STATE:       ULI_CLASS_A_ESTABLISHED / ULI_RELEASED               */
               /* ----------------------------------------------------------------------*/
                                                   /* The normal link release request  */
                                                   /* is only processed, when the      */
                                                   /* I-Queue is empty !               */
               if( I_queue_empty() == TRUE )
               {
                  #ifdef DECT_DEBUG_USER_LAP_PRIMITIVE
                  DECT_DEBUG_USER_LAP_PRIMITIVE("%s, %s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable),
                  getDebugStringRef(CurrentState, stateStringTable), CurrentInc, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
                  normalReleaseReqEnqueued = NO;
                  #endif
                  KNL_SENDTASK_INC( LC, LC_REL_RQ_NORMAL_LAP, CurrentInc );
                  #ifdef CONFIG_UPDATE_LINK_RELEASE
                  LAP_Struct[CurrentInc].releasePending = YES;
                  #endif
                  KNL_Transit( ULI_RELEASED );
               }
               else
               {
                  #ifdef DECT_DEBUG_USER_LAP_PRIMITIVE
                  if (normalReleaseReqEnqueued != YES) {
                     DECT_DEBUG_USER_LAP_PRIMITIVE("%s, %s, %02x, %02x %02x %02x %02x\n", getDebugStringRef(CurrentMessage, messageStringTable),
                     getDebugStringRef(CurrentState, stateStringTable), CurrentInc, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4);
                     normalReleaseReqEnqueued = YES;
                  }
                  #endif
                  KNL_SENDTASK_INC( LAP, LAP_DL_REL_RQ_NORMAL_LCE, CurrentInc );
               }
            }
            return;

            case LAP_DL_REL_RQ_ABNORMAL_LCE:  /*  IN LINE CODE T0250    */
            {
               /* TRANSITION:      T250                                                 */
               /* EVENT:           LAP_DL_REL_RQ_ABNORMAL_LCE                           */
               /* DESCRIPTION:     Data Link Release Request, abnormal                  */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  all                                                  */
               /* END STATE:       ULI_RELEASED                                         */
               /* ----------------------------------------------------------------------*/
               discard_I_queue();
               #ifndef CONFIG_UPDATE_LINK_RELEASE
                                                   /* Reset LAP Process Structure.     */
               reset_LAP_Struct();
               #endif
                                                   /* Stop all DLC-Timer.              */
               Stop_Pro_Timer( TIMER_DL_04, CurrentInc );
               #ifdef xxxCONFIG_REPEATER_SUPPORT
               KNL_SENDTASK_INC( LAP_REP, LAP_REL_CFM_LC, CurrentInc );
               #endif
               KNL_SENDTASK_INC( LC, LC_REL_RQ_ABNORMAL_LAP, CurrentInc );
               #ifdef CONFIG_UPDATE_LINK_RELEASE
               LAP_Struct[CurrentInc].releasePending = YES;
               #endif
               KNL_Transit( ULI_RELEASED );
            }
            return;

            case LAP_I_FRAME_NLF_LC: 
               T0100();
               return;

            case LAP_REL_IN_LC: 
            case LAP_PRO_ERR_LC: 
               T0202();
               return;

            #ifndef CONFIG_UPDATE_LINK_RELEASE
            case LAP_REL_CFM_LC: 
               T0201();
               return;
            #endif

            case LAP_DL_DATA_RQ_LCE:  /*  IN LINE CODE T0400    */
            {
               /* TRANSITION:      T400                                                 */
               /* EVENT:           LAP_DL_DATA_RQ_LCE                                   */
               /* DESCRIPTION:     Data Request from LCE Process                        */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
               /* END STATE:       ULI_CLASS_A_ESTABLISHED                              */
               /* ----------------------------------------------------------------------*/
               FPTR temp;
               BYTE ntw_len, ntw_index;

                                                   /* Frame there ?                    */
               if( G_PTR == NULL )
               return;
                                             /* Get the Layer 3 frame length !   */
               ntw_len = ((( struct HLI_Header * ) G_PTR ) -> length ) - sizeof( struct HLI_Header );
                                                   /* NTW-Layer Frame too short ?      */
                                                   /* Protocol Discriminator,          */
                                                   /* Transaction Field and Message    */
                                                   /* Field must be always there !     */
               if( ntw_len < 2 )
               {
                  Mmu_Free( G_PTR );
                  return;
               }
                                                   /* Set the Index to first byte of   */
                                                   /* the NTW-Layer frame !            */
               ntw_index =  sizeof( struct HLI_Header );
                                                   /* Segmentation of the NTW-Layer    */
                                                   /* Message.                         */
                                                   /* -------------------------------- */
                                                   /* The M-Bit is set to indicate     */
                                                   /* that the information field only  */
                                                   /* contains part of a NWK layer     */
                                                   /* message - there is more to       */
                                                   /* follow.                          */
               for( ; ntw_len > MAXIMUM_INFORMATION; )
               {
                  temp = Construct_L2_Frame( NLF_CLEARED, LLN_CLASS_A, S_SAP,
                                             COMMAND_TX, I_TYP, M_BIT_SET );
                  temp = Conc_L2_Fr_with_L3_Info( temp, &G_PTR[ ntw_index ], MAXIMUM_INFORMATION );
                  Put_in_Queue( LAP, CurrentInc, temp );
                  ntw_len   -= MAXIMUM_INFORMATION;
                  ntw_index += MAXIMUM_INFORMATION;
               }
                                                   /* Last Segment is send with        */
                                                   /* cleared M-Bit !                  */

               temp = Construct_L2_Frame( NLF_CLEARED, LLN_CLASS_A, S_SAP,
                                          COMMAND_TX, I_TYP, M_BIT_CLEARED );
               temp = Conc_L2_Fr_with_L3_Info( temp, &G_PTR[ ntw_index ], ntw_len );
               Put_in_Queue( LAP, CurrentInc, temp );

                                                   /* Free NTW-Layer frame.            */
               Mmu_Free( G_PTR );

                                                   /* If currently no acknowledgment   */
                                                   /* is outstanding, the first        */
                                                   /* I-frame is send.                 */

               if( LAP_Struct[ CurrentInc ].Ack_Pending == FALSE )
               {
                  KNL_SENDTASK_NP_INC( LC, LC_CO_DATA_RQ_LAP, get_next_I_queue_entry(), CurrentInc );
                                                   /* Go to state 'Acknowledge         */
                                                   /* Pending'.                        */
                  LAP_Struct[ CurrentInc ].Ack_Pending = TRUE;
                                                   /* Increment the Send State         */
                                                   /* Variable V(S).                   */
                  LAP_Struct[ CurrentInc ].VS = Increment( LAP_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                  #ifdef CONFIG_UPDATE_I_FRAME_REPEAT_COUNT
                                                 /* Reset I-frame Repeat Counter.    */
                  LAP_Struct[ CurrentInc ].RC200 = 0;
                  #endif
                                                   /* Start Retransmission Timer       */
                                                   /* -------------------------------- */
                                                   /* Timer:     <DL.04>               */
                                                   /* Duration:  2 seconds             */
                  Start_Pro_Timer( TIMER_DL_04, CurrentInc );
               }

            }
            return;

            case LAP_I_FRAME_LC:  /*  IN LINE CODE T0301    */
            {
               /* TRANSITION:      T301                                                 */
               /* EVENT:           LAP_I_FRAME_LC                                       */
               /* DESCRIPTION:     I_Frame received                                     */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
               /* END STATE:       ULI_CLASS_A_ESTABLISHED                              */
               /* ----------------------------------------------------------------------*/
               FPTR temp;

               set_received_NR_NS_value();
                                                   /* The Receive State Variable V(R)  */
                                                   /* denotes the sequence number of   */
                                                   /* the next-in-sequence I-frame     */
                                                   /* expected to be received.         */
                                                   /* The I-frame is only in-sequence, */
                                                   /* when the Receive State Variable  */
                                                   /* V(R) and the Send Sequence       */
                                                   /* Number N(S) are equal.           */

               if( LAP_Struct[ CurrentInc ].NS == LAP_Struct[ CurrentInc ].VR )
               {
                                                   /* The received I-frame is          */
                                                   /* in-sequence !                    */
                                                   /* -------------------------------- */
                                                   /* The Receive State Variable V(R)  */
                                                   /* is incremented.                  */
                  LAP_Struct[ CurrentInc ].VR = Increment( LAP_Struct[ CurrentInc ].VR, SEQUENCEMAX );
                                                   /* Assembly the received L3-Frame.  */
                                                   /* -------------------------------- */
                  temp = Assembly_L3_Frame( G_PTR );
                                                   /* The L3 frame is only transferred */
                                                   /* to the NTW-Layer when the last   */
                                                   /* segment is received.             */

                  if( temp != NULL )
                     KNL_SENDTASK_NP_INC( LCE, LCE_DL_DATA_IN_LAP, temp, CurrentInc );

                                                   /* The I-frame is acknowledged      */
                                                   /* with a RR-frame.                 */
                  KNL_SENDTASK_NP_INC( LC, LC_CO_DATA_RQ_LAP, construct_RR_frame( NLF_CLEARED ), CurrentInc );
               }
               else
               {
                                                   /* The received I-frame is NOT      */
                                                   /* in-sequence !                    */
                                                   /* -------------------------------- */
                                                   /* The I-frame is ignored and a     */
                                                   /* RR-frame with the correct        */
                                                   /* Receive State Variable V(R) is   */
                                                   /* send back.                       */
                  Mmu_Free( G_PTR );
                  KNL_SENDTASK_NP_INC( LC, LC_CO_DATA_RQ_LAP, construct_RR_frame( NLF_CLEARED ), CurrentInc );
               }
                                    					/* The I-frame can be used to carry */
                                    					/* a valid acknowledgment. Evaluate */
                                    					/* the Receive Sequence Number      */
                                    					/* N(R).                            */
                                    					/* According to ETS 300 175-4 /     */
                                    					/* 7.5.2.2 Send state Variable      */
                                    					/* V(S), the windowsize k is fixed  */
                                    					/* to 1 for class A operations.     */
                                    					/* Therefore the Receive Sequence   */
                                    					/* Number N(R) must be equal to the */
                                    					/* Send State Variable V(S).        */
               if(( LAP_Struct[ CurrentInc ].NR == LAP_Struct[ CurrentInc ].VS ) &&
                  ( LAP_Struct[ CurrentInc ].VA != LAP_Struct[ CurrentInc ].NR ))
               {
                                                   /* Valid acknowledgment received.   */
                                                   /* -------------------------------- */
                                                   /* The I-frame is released and the  */
                                                   /* Acknowledge State Variable V(A)  */
                                                   /* is adjusted.                     */
                  release_I_frame();
                                                   /* Reset Acknowledge Pending State. */
                  LAP_Struct[ CurrentInc ].Ack_Pending = FALSE;
                  LAP_Struct[ CurrentInc ].VA = LAP_Struct[ CurrentInc ].NR;
                                                   /* Stop Acknowledgment Timer        */
                                                   /* -------------------------------- */
                  Stop_Pro_Timer( TIMER_DL_04, CurrentInc );
                                                   /* In case of queued I-frames, the  */
                                                   /* next frame is send !             */
                                                   /* -------------------------------- */
                  if( I_queue_empty() == FALSE )
                  {
                                                   /* The next I-frame is send !       */
                     KNL_SENDTASK_NP_INC( LC, LC_CO_DATA_RQ_LAP, get_next_I_queue_entry(), CurrentInc );
                                                   /* Go to state 'Acknowledge         */
                                                   /* Pending'.                        */
                     LAP_Struct[ CurrentInc ].Ack_Pending = TRUE;
                                                   /* Increment the Send State         */
                                                   /* Variable V(S).                   */
                     LAP_Struct[ CurrentInc ].VS = Increment( LAP_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                                                   /* Reset I-frame Repeat Counter.    */
                     LAP_Struct[ CurrentInc ].RC200 = 0;
                                                   /* Start Retransmission Timer       */
                                                   /* -------------------------------- */
                                                   /* Timer:     <DL.04>               */
                                                   /* Duration:  2 seconds             */
                     Start_Pro_Timer( TIMER_DL_04, CurrentInc );
                  }
               }
            }
            return;

            case LAP_RR_FRAME_LC:  /*  IN LINE CODE T0302    */
            {
               /* TRANSITION:      T302                                                 */
               /* EVENT:           LAP_RR_FRAME_LC                                      */
               /* DESCRIPTION:     RR_Frame received                                    */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
               /* END STATE:       ULI_CLASS_A_ESTABLISHED                              */
               /* ----------------------------------------------------------------------*/
               set_received_NR_value();
                                                   /* According to ETS 300 175-4 /     */
                                                   /* 7.5.2.2 Send state Variable      */
                                                   /* V(S), the windowsize k is fixed  */
                                                   /* to 1 for class A operations.     */
                                                   /* Therefore the Receive Sequence   */
                                                   /* Number N(R) must be equal to the */
                                                   /* Send State Variable V(S).        */
               if(( LAP_Struct[ CurrentInc ].NR == LAP_Struct[ CurrentInc ].VS ) &&
                  ( LAP_Struct[ CurrentInc ].VA != LAP_Struct[ CurrentInc ].NR ))
               {
                                                   /* Valid acknowledgment received.   */
                                                   /* -------------------------------- */
                                                   /* The I-frame is released and the  */
                                                   /* Acknowledge State Variable V(A)  */
                                                   /* is adjusted.                     */
                  release_I_frame();
                                                   /* Reset Acknowledge Pending State. */
                  LAP_Struct[ CurrentInc ].Ack_Pending = FALSE;
                  LAP_Struct[ CurrentInc ].VA = LAP_Struct[ CurrentInc ].NR;
                                                   /* Stop Acknowledgment Timer        */
                                                   /* -------------------------------- */
                  Stop_Pro_Timer( TIMER_DL_04, CurrentInc );
                                                   /* In case of queued I-frames, the  */
                                                   /* next frame is send !             */
                                                   /* -------------------------------- */
                  if( I_queue_empty() == FALSE )
                  {
                                                   /* The next I-frame is send !       */
                     KNL_SENDTASK_NP_INC( LC, LC_CO_DATA_RQ_LAP, get_next_I_queue_entry(), CurrentInc );
                                                   /* Go to state 'Acknowledge         */
                                                   /* Pending'.                        */
                     LAP_Struct[ CurrentInc ].Ack_Pending = TRUE;
                                                   /* Increment the Send State         */
                                                   /* Variable V(S).                   */
                     LAP_Struct[ CurrentInc ].VS = Increment( LAP_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                                                   /* Reset I-frame Repeat Counter.    */
                     LAP_Struct[ CurrentInc ].RC200 = 0;
                                                   /* Start Retransmission Timer       */
                                                   /* -------------------------------- */
                                                   /* Timer:     <DL.04>               */
                                                   /* Duration:  2 seconds             */
                     Start_Pro_Timer( TIMER_DL_04, CurrentInc );
                  }
               }
               Mmu_Free( G_PTR );
            }
            return;

            case LAP_RR_FRAME_NLF_LC:  /*  IN LINE CODE T0303    */
            {
               /* TRANSITION:      T303                                                 */
               /* EVENT:           LAP_RR_FRAME_NLF_LC                                  */
               /* DESCRIPTION:     RR_Frame received with NLF set                       */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
               /* END STATE:       current state maintained                             */
               /* ----------------------------------------------------------------------*/
               set_received_NR_value();
                                                   /* According to ETS 300 175-4 /     */
                                                   /* 7.5.2.2 Send state Variable      */
                                                   /* V(S), the windowsize k is fixed  */
                                                   /* to 1 for class A operations.     */
                                                   /* Therefore the Receive Sequence   */
                                                   /* Number N(R) must be equal to the */
                                                   /* Send State Variable V(S).        */
               if(( LAP_Struct[ CurrentInc ].NR == LAP_Struct[ CurrentInc ].VS ) &&
                  ( LAP_Struct[ CurrentInc ].VA != LAP_Struct[ CurrentInc ].NR ))
               {
                                                   /* Valid acknowledgment received.   */
                                                   /* -------------------------------- */
                                                   /* The I-frame is released and the  */
                                                   /* Acknowledge State Variable V(A)  */
                                                   /* is adjusted.                     */
                  release_I_frame();
                                                   /* Reset Acknowledge Pending State. */
                  LAP_Struct[ CurrentInc ].Ack_Pending = FALSE;
                  LAP_Struct[ CurrentInc ].VA = LAP_Struct[ CurrentInc ].NR;
                                                   /* Stop Acknowledgment Timer        */
                                                   /* -------------------------------- */
                  Stop_Pro_Timer( TIMER_DL_04, CurrentInc );
                                                   /* Report Re-establishment to LCE   */
                                                   /* process.                         */
                  KNL_SENDTASK_INC( LCE, LCE_DL_EST_IN_LAP, CurrentInc );
                                                   /* In case of queued I-frames, the  */
                                                   /* next frame is send !             */
                                                   /* -------------------------------- */
                  if( I_queue_empty() == FALSE )
                  {
                                                   /* The next I-frame is send !       */
                     KNL_SENDTASK_NP_INC( LC, LC_CO_DATA_RQ_LAP, get_next_I_queue_entry(), CurrentInc );
                                                   /* Go to state 'Acknowledge         */
                                                   /* Pending'.                        */
                     LAP_Struct[ CurrentInc ].Ack_Pending = TRUE;
                                                   /* Increment the Send State         */
                                                   /* Variable V(S).                   */
                     LAP_Struct[ CurrentInc ].VS = Increment( LAP_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                                                   /* Reset I-frame Repeat Counter.    */
                     LAP_Struct[ CurrentInc ].RC200 = 0;
                                                   /* Start Retransmission Timer       */
                                                   /* -------------------------------- */
                                                   /* Timer:     <DL.04>               */
                                                   /* Duration:  2 seconds             */
                     Start_Pro_Timer( TIMER_DL_04, CurrentInc );
                  }
               }
               Mmu_Free( G_PTR );
            }
            return;

            case LAP_TIM_DL_04_EXPIRED:  /*  IN LINE CODE T0454    */
            {
               /* TRANSITION:      T454                                                 */
               /* EVENT:           LAP_TIM_DL_04_EXPIRED ( Retransmission Timer )       */
               /* DESCRIPTION:     Timer P-<DL.04> expired                              */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
               /* END STATE:       ULI_RELEASED / ULI_CLASS_A_ESTABLISHED               */
               /* ----------------------------------------------------------------------*/
               if( LAP_Struct[ CurrentInc ].RC200 == N250 )
               {
                                                   /* Maximum number of                */
                                                   /* retransmissions reached, the     */
                                                   /* link is given up !               */
                  discard_I_queue();
                  #ifndef CONFIG_UPDATE_LINK_RELEASE
                                                   /* Reset LAP Process Structure.     */
                  reset_LAP_Struct();
                  #endif
                                                   /* Stop all DLC-Timer.              */
                  Stop_Pro_Timer( TIMER_DL_04, CurrentInc );
                  #ifdef xxxCONFIG_REPEATER_SUPPORT
                  KNL_SENDTASK_INC( LAP_REP, LAP_REL_CFM_LC, CurrentInc );
                  #endif
                  KNL_SENDTASK_INC( LC, LC_REL_RQ_ABNORMAL_LAP, CurrentInc );
                  #ifdef CONFIG_UPDATE_LINK_RELEASE
                  LAP_Struct[CurrentInc].releasePending = YES;
                  LAP_Struct[CurrentInc].releaseReqBySelf = YES;
                  #else
                  KNL_SENDTASK_INC( LCE, LCE_DL_REL_IN_LAP, CurrentInc );
                  #endif
                  KNL_Transit( ULI_RELEASED );
               }
               else
               {
                  if( I_queue_empty() == FALSE )
                  {
                                                   /* The I-frame is retransmitted     */
                                                   /* with the same Send State         */
                                                   /* Variable V(S).                   */
                     LAP_Struct[ CurrentInc ].VS = Decrement( LAP_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                                                   /* The I-frame is send again !      */
                     KNL_SENDTASK_NP_INC( LC, LC_CO_DATA_RQ_LAP, get_next_I_queue_entry(), CurrentInc );
                                                   /* Go to state 'Acknowledge         */
                                                   /* Pending'.                        */
                     LAP_Struct[ CurrentInc ].Ack_Pending = TRUE;
                                                   /* Increment the Send State         */
                                                   /* Variable V(S).                   */
                     LAP_Struct[ CurrentInc ].VS = Increment( LAP_Struct[ CurrentInc ].VS, SEQUENCEMAX );
                                                   /* Increment I-frame Repeat Counter.*/
                     LAP_Struct[ CurrentInc ].RC200++;
                                                   /* Start Retransmission Timer       */
                                                   /* -------------------------------- */
                                                   /* Timer:     <DL.04>               */
                                                   /* Duration:  2 seconds             */
                     Start_Pro_Timer( TIMER_DL_04, CurrentInc );
                  }
               }
            }
            return;

            case LAP_DL_ENC_KEY_RQ_LCE:  /*  IN LINE CODE T0600    */
            {
               /* TRANSITION:      T600                                                 */
               /* EVENT:           LAP_DL_ENC_KEY_RQ_LCE                                */
               /* DESCRIPTION:     Encryption key provision                             */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
               /* END STATE:       ULI_CLASS_A_ESTABLISHED                              */
               /* ----------------------------------------------------------------------*/
               KNL_SENDTASK_NP_INC( LC, LC_DL_ENC_KEY_RQ_LAP, G_PTR, CurrentInc );
            }
            return;

            case LAP_DL_ENC_IND_LC:  /*  IN LINE CODE T0602    */
            {
               /* TRANSITION:      T602                                                 */
               /* EVENT:           LAP_DL_ENC_IND_LC                                    */
               /* DESCRIPTION:     Encryption mode confirmation                         */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  ULI_CLASS_A_ESTABLISHED                              */
               /* END STATE:       ULI_CLASS_A_ESTABLISHED                              */
               /* ----------------------------------------------------------------------*/
               KNL_SENDTASK_WP_INC( LCE, LCE_DL_ENC_IND_LAP, PARAMETER1, PARAMETER2, PARAMETER3, PARAMETER4, CurrentInc );
            }
            return;

            #ifndef CONFIG_UPDATE_LINK_RELEASE
            case LAP_DL_REL_RQ_ABNORMAL_MM:  /*  IN LINE CODE T0251    */
            {
               /* TRANSITION:      T251                                                 */
               /* EVENT:           LAP_DL_REL_RQ_ABNORMAL_MM                            */
               /* DESCRIPTION:     Data Link Release Request, abnormal from MM          */
               /* REFERENCE:       ETS 300 175-4:1996                                   */
               /* STARTING STATE:  all                                                  */
               /* END STATE:       ULI_RELEASED                                         */
               /* ----------------------------------------------------------------------*/
               discard_I_queue();
               /* Reset LAP Process Structure.     */
               reset_LAP_Struct();
               /* Stop all DLC-Timer.              */
               Stop_Pro_Timer( TIMER_DL_04, CurrentInc );
               #ifdef xxxCONFIG_REPEATER_SUPPORT
               KNL_SENDTASK_INC( LAP_REP, LAP_REL_CFM_LC, CurrentInc );
               #endif
               KNL_SENDTASK_INC( LCE, LCE_DL_REL_IN_LAP, CurrentInc );
               KNL_SENDTASK_INC( LC, LC_REL_RQ_ABNORMAL_LAP, CurrentInc );
               KNL_Transit( ULI_RELEASED );
            }
            return;
            #endif

            default:
               break;
         }										/* end of switch message				*/
         break; 
   }												/* end of switch state					*/
   KNL_T0000();
}													/* end of DECODE_LAP()					*/
