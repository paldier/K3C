/*
*****************************************************************************
*                                                                           *
*     Project    :  PRODECT - DECT Home System Protocol Software V8.0        *
*                   (c) 2005 IFX / INTNIX. All rights reserved.               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Workfile   :  SWI_LIB.C                                               *
*     Date       :  18 Nov, 2005                                       *
*     Contents   :  Library for Process 'SWITCHING PROCESS ( DIS )'         *
*     Hardware   :  IFX 87xx                                               *
*                                                                           *
*****************************************************************************
*/
   /* ========                                                             */
   /* Includes                                                             */
   /* ========                                                             */
#include "DEFINE.H"


#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#ifdef FT
#include "FGLOBAL.H"
#endif
#include "DECT.H"
#include "PCT_DEF.H"
#include "FDEF.H"

#include "CONF_DEF.H"

#include "CC_DEF.H"

EXPORT FPTR
Mmu_Malloc( WORD word_size );

  /* ==========================                                           */
  /* External Stack library function definition                                            */
  /* ==========================                                           */


   /* ===============                                                      */
   /* Local variables                                                      */
   /* ===============                                                      */
#ifdef DECT_NG
EXPORT XDATA  uchar8 Primary_Codec;//=CODEC_G722;
#endif
   /* ==========================                                           */
   /* Global function definition                                           */
   /* ==========================                                           */
extern BYTE
scan_IE( FPTR frame_ptr, BYTE info_element_id, BYTE min_length, BYTE max_length );

/****************************************************************************
This is a call-back function called by stack library(during Location-Registration/Registration ),
=> applcaiiton must provide this to offer user Proprietary IE content(Data fame with length info)
****************************************************************************/
#ifdef DECT_NG
EXPORT FPTR
Get_Progress_Indicator( void )
{
   FPTR frame_ptr = Mmu_Malloc( sizeof( DATA_FRAME )+1);

   #ifdef KLOCWORK
   if(frame_ptr != NULL)
   #endif
   {
      ((DATA_FRAME *) frame_ptr)->length = 2;
                                                                  /* Coding standard(00:ITU_T)/Location(0000:User)  */
                                                                  /* -------------------------------- */
      ((DATA_FRAME *) frame_ptr)->dat[0]= 0x00 | 0x80;
                                                                  /* Progress description                            */
                                                                  /* -------------------------------- */
      ((DATA_FRAME *) frame_ptr)->dat[1]=IN_BAND_INFORMATION_NOW_AVAILABLE | 0x80;
   }
   return ( frame_ptr );
}
#endif

/****************************************************************************
This is a call-back function called by stack library(during Location-Registration/Registration ),
=> applcaiiton must provide this to offer user Proprietary IE content(Data fame with length info)
****************************************************************************/
#ifdef DECT_NG
EXPORT FPTR
Get_Codec_List( BYTE codec )
{
   FPTR  frame_ptr;

   if( codec == 0 )
   {
      // All available Codec List is requested, attach all available Codec Info.
      frame_ptr = Mmu_Malloc( sizeof( DATA_FRAME ) + 7 - 1 );
      #ifdef KLOCWORK
      if(frame_ptr != NULL)
      #endif
      {
                                                                 /* Negotiation_indicator(1)/RES       */
                                                                 /* -> Byte 3: 0x90                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[0] = 0x90;
                                                                 /* 1st codec-id(3:G722)                 */
                                                                 /* -> Byte 4: 0x03                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[1] = CODEC_G722;
                                                                 /* MAC_DLC service( In_minimum_delay )   */
                                                                 /* -> Byte 4a: 0x00                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[2] = 0x00;
                                                                 /* C-plan(0:Cs only)/slot_size(Long slot;j=640)  */
                                                                 /* -> Byte 4b: 0x01                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[3] = 0x01;
                                                                 /* last codec-id(2:G726)                 */
                                                                 /* -> Byte 4: 0x03                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[4] = CODEC_G726;
                                                                 /* MAC_DLC service( In_minimum_delay )   */
                                                                 /* -> Byte 4a: 0x00                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[5] = 0x00;
                                                                 /* C-plan(0:Cs only)/slot_size(Full slot)  */
                                                                 /* -> Byte 4b: 0x84                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[6] = 0x84;
         ((DATA_FRAME *) frame_ptr)->length = 7;
      }
   }
   else if( codec == CODEC_G722 )
   {
      // If G.722 Codec attachment is requested, attach G.722 & G.726 Codec Info.
      frame_ptr = Mmu_Malloc( sizeof( DATA_FRAME ) + 4 - 1 );
      #ifdef KLOCWORK
      if(frame_ptr != NULL)
      #endif
      {
                                                                 /* Negotiation_indicator(1)/RES       */
                                                                 /* -> Byte 3: 0x90                         */
                                                                 /* -------------------------------- */
        ((DATA_FRAME *) frame_ptr)->dat[0]=0x90;
                                                                 /* 1st codec-id(3:G722)                 */
                                                                 /* -> Byte 4: 0x03                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[1] = CODEC_G722;
                                                                 /* MAC_DLC service( In_minimum_delay )   */
                                                                 /* -> Byte 4a: 0x00                         */
                                                                 /* -------------------------------- */
        ((DATA_FRAME *) frame_ptr)->dat[2]=0x00;
                                                                 /* C-plan(0:Cs only)/slot_size(Long slot;j=640)  */
                                                                 /* -> Byte 4b: 0x01                         */
                                                                 /* -------------------------------- */
        ((DATA_FRAME *) frame_ptr)->dat[3]=0x81;
                                                                 /* last codec-id(2:G726)                 */
                                                                 /* -> Byte 4: 0x03                         */
                                                                 /* -------------------------------- */
        // ((DATA_FRAME *) frame_ptr)->dat[4] = CODEC_G726;
                                                                 /* MAC_DLC service( In_minimum_delay )   */
                                                                 /* -> Byte 4a: 0x00                         */
                                                                 /* -------------------------------- */
       // ((DATA_FRAME *) frame_ptr)->dat[5]=0x00;
                                                                 /* C-plan(0:Cs only)/slot_size(Full slot)  */
                                                                 /* -> Byte 4b: 0x84                         */
                                                                 /* -------------------------------- */
       // ((DATA_FRAME *) frame_ptr)->dat[6]=0x84;
        ((DATA_FRAME *) frame_ptr)->length = 4;
     }
   }
   else if(codec == 1){
      // All available Codec List is requested, attach all available Codec Info.
      frame_ptr = Mmu_Malloc( sizeof( DATA_FRAME ) + 7 - 1 );
      #ifdef KLOCWORK
      if(frame_ptr != NULL)
      #endif
      {
                                                                 /* Negotiation_indicator(1)/RES       */
                                                                 /* -> Byte 3: 0x90                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[0] = 0x90;
                                                                 /* 1st codec-id(3:G726)                 */
                                                                 /* -> Byte 4: 0x02                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[1] = CODEC_G726;
                                                                 /* MAC_DLC service( In_minimum_delay )   */
                                                                 /* -> Byte 4a: 0x00                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[2] = 0x00;

                                                                 /* C-plan(0:Cs only)/slot_size(Full slot)  */

                                                                 /* -> Byte 4b: 0x84                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[3] = 0x04;
                                                                 /* last codec-id(2:G726)                 */
                                                                 /* -> Byte 4: 0x03                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[4] = CODEC_G722;
                                                                 /* MAC_DLC service( In_minimum_delay )   */
                                                                 /* -> Byte 4a: 0x00                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[5] = 0x00;

																						/* C-plan(0:Cs only)/slot_size(Long slot;j=640)  */
                                                                 /* -> Byte 4b: 0x01                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[6] = 0x81;
         ((DATA_FRAME *) frame_ptr)->length = 7;
      }

	}
   else
   {
      // If G.726 Codec attachment is requested, attach only G.726 Codec Info.
      frame_ptr = Mmu_Malloc( sizeof( DATA_FRAME ) + 4 - 1 );
      #ifdef KLOCWORK
      if(frame_ptr != NULL)
      #endif
      {
                                                                 /* Negotiation_indicator(1)/RES       */
                                                                 /* -> Byte 3: 0x90                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[0] = 0x90;
                                                                 /* 1st/last codec-id(3:G726                */
                                                                 /* -> Byte 4: 0x02                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[1] = CODEC_G726;
                                                                 /* MAC_DLC service( In_minimum_delay )   */
                                                                 /* -> Byte 4a: 0x00                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[2] = 0x00;
                                                                 /* C-plan(0:Cs only)/slot_size(Long slot;j=640)  */
                                                                 /* -> Byte 4b: 0x01                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[3] = 0x84;
         ((DATA_FRAME *) frame_ptr)->length = 4;
      }
   }

   return ( frame_ptr );
}
#endif

#ifdef DECT_NG
EXPORT FPTR
Get_Designated_Codec_List( BYTE codec )
{
	FPTR frame_ptr;

   if( codec == CODEC_G722 )
   {
      // If G.722 Codec attachment is requested, attach G.722 & G.726 Codec Info.
      frame_ptr = Mmu_Malloc( sizeof( DATA_FRAME ) + 4 - 1 );
      #ifdef KLOCWORK
      if(frame_ptr != NULL)
      #endif
      {
                                                                 /* Negotiation_indicator(1)/RES       */
                                                                 /* -> Byte 3: 0x90                         */
                                                                 /* -------------------------------- */
        ((DATA_FRAME *) frame_ptr)->dat[0]=0x90;
                                                                 /* 1st codec-id(3:G722)                 */
                                                                 /* -> Byte 4: 0x03                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[1] = CODEC_G722;
                                                                 /* MAC_DLC service( In_minimum_delay )   */
                                                                 /* -> Byte 4a: 0x00                         */
                                                                 /* -------------------------------- */
        ((DATA_FRAME *) frame_ptr)->dat[2]=0x00;
                                                                 /* C-plan(0:Cs only)/slot_size(Long slot;j=640)  */
                                                                 /* -> Byte 4b: 0x01                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[3] = 0x81;
         ((DATA_FRAME *) frame_ptr)->length = 4;
      }
   }
   else
   {
      // If G.726 Codec attachment is requested, attach only G.726 Codec Info.
      frame_ptr = Mmu_Malloc( sizeof( DATA_FRAME ) + 4 - 1 );
      #ifdef KLOCWORK
      if(frame_ptr != NULL)
      #endif
      {
                                                                 /* Negotiation_indicator(1)/RES       */
                                                                 /* -> Byte 3: 0x90                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[0] = 0x90;
                                                                 /* 1st/last codec-id(3:G726                */
                                                                 /* -> Byte 4: 0x02                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[1] = CODEC_G726;
                                                                 /* MAC_DLC service( In_minimum_delay )   */
                                                                 /* -> Byte 4a: 0x00                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[2] = 0x00;
                                                                 /* C-plan(0:Cs only)/slot_size(Long slot;j=640)  */
                                                                 /* -> Byte 4b: 0x01                         */
                                                                 /* -------------------------------- */
         ((DATA_FRAME *) frame_ptr)->dat[3] = 0x84;
         ((DATA_FRAME *) frame_ptr)->length = 4;
      }
   }

     return ( frame_ptr );
}
#endif

#ifdef DECT_NG
EXPORT BYTE
Evaluate_CODEC_LIST_IE( void )
{
   BYTE pos;

   /*******************************************************************
   (1)   7C : CODEC_LIST
   --------------------------------------------------------------------
   (2)   07 : length(07)
   (3)   90 : Negotiation_indicator(1)/RES
   (4)   03 : 1st codec-id(3:G722)=>highest priority
   (4a) 00 : res/MAC_DLC service( In_minimum_delay )
   (4b) 01 : C-plan(0:Cs only)/slot_size(Long slot;j=640)
   (5)   02 : last codec-id(2:G726)
   (5a) 00 : res/MAC_DLC service( In_minimum_delay )
   (5b) 84 : C-plan(0:Cs only)/slot_size(Full slot)
   *******************************************************************/
   pos = scan_IE( G_PTR, CODEC_LIST, 2, 20 );
   if( pos != 0 )
   {
// narendra	if( G_PTR[ pos + 2 ] == 0x10 )	   //if negotiation is ppossible,
		    return( G_PTR[ pos + 3 ] );	   //return codec ID
   }
   else
   {
      return( DUMMY_FILL );
   }
}
#endif

#ifdef DECT_NG
EXPORT BYTE
Evaluate_Terminal_Capability_IE( void )
{
   BYTE pos;

   /*******************************************************************
   (1)   63 : terminal Capability
   --------------------------------------------------------------------
   (2)   xx : length
   (3)   xx : tone capability/display capability
   (4)   xx : echo parameter/N-REJ
   (5)   xx : slot type capability
   *******************************************************************/
   pos = scan_IE( G_PTR, TERMINAL_CAPABILITY, 3, 23 );
   if( pos != 0 )
   {
	 	if( G_PTR[ pos + 4 ] & 0x02 )	   //if long slot is support,
	 return( TRUE );	   //return true
   }
   return( FALSE );
}
#endif
