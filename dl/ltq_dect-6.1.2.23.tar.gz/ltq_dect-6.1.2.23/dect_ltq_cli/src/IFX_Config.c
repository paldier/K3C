/*
 * =====================================================================================
 *
 *       Filename:  IFX_Config.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  05/27/2010 12:29:19 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  S.Karthikeyan (SK), skarthitw@gmail.com
 *        Company:  IFIN
 *
 * =====================================================================================
 */
#define boolean int
#include<stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <fcntl.h>
#include"ifx_common_defs.h"
#include "IFX_DECT_Stack.h"
#include "IFX_Config.h"
#include "IFX_CLI.h"
#define KLOCWORK 
extern char RcConffile[],DECTRcConffile[];
/*****************************************************************************
* Function Name: IFX_CM_SetCfgData
* Description  : set configuration data
* Input Value  : pFileName       ==> Open File Name
*                pTag            ==> TAG_xxx
*                nDataCount      ==> Data number for setting.
*                pData           ==> Data content for setting.
* Output Value :
* Return Value : 0:Fail 1: Success
* Notes :
*****************************************************************************/
int32
IFX_CM_SetRcCfgData (IN const char8 * pcFileName,
                   IN const char8 * pcTag,
                   IN int32 iDataCount,
                   OUT const char8 * pcData, ...)
{
  FILE *fdIn, *fdOut;
  char8 acInLine[IFX_CM_MAX_FILENAME_LEN];
  char8 acTempName[IFX_CM_MAX_FILENAME_LEN];
  char8 acbuf[IFX_CM_BUF_SIZE_50K];
  char8 acBeginTag[IFX_CM_MAX_TAG_LEN], acEndTag[IFX_CM_MAX_TAG_LEN];
  char8 cTagArea = 0;
  va_list args;

  /* First, extract data for list and store into buffer*/
  va_start (args, pcData);
  strcpy (acbuf, pcData);


  while (--iDataCount)
  {
    pcData = va_arg (args, char8 *);
    strcat (acbuf, pcData);
  }
  va_end (args);

  memset (acBeginTag, 0x00, IFX_CM_MAX_TAG_LEN);
  memset (acEndTag, 0x00, IFX_CM_MAX_TAG_LEN);
  sprintf (acBeginTag, "#<< %s", pcTag);
  sprintf (acEndTag, "#>> %s", pcTag);

  if ((fdIn = fopen (pcFileName, "r+t")) == NULL)
  {
    //fclose (fdIn);
    return 0;
  }

  sprintf (acTempName, "%s.tmp", pcFileName);
  if ((fdOut = fopen (acTempName, "w+")) == NULL)
  {
    fclose (fdIn);
    return 0;
  }

  while (fgets (acInLine, sizeof (acInLine), fdIn))
  {
    if (!strlen (acInLine)){
      continue;  /*Null line*/
    }

    /* remove "\n" and keep string only*/
    acInLine[strlen (acInLine) - 1] = 0;

    if (strncmp (acInLine, acBeginTag, strlen(acBeginTag)) == 0)
    {
      cTagArea = 1;
    }


    if (cTagArea)
    {
      /* Print all datas to file*/
      int32 iret;
    	fprintf (fdOut, "%s ##%d\n", acBeginTag,strlen(acbuf)+strlen(acEndTag)+2);
      iret = fprintf (fdOut, acbuf);

      while (fgets (acInLine, sizeof (acInLine), fdIn))
      {
        acInLine[strlen (acInLine) - 1] = 0;
        if (strncmp (acInLine, acEndTag, sizeof (acEndTag)) == 0)
        {
          fprintf (fdOut, "%s\n", acInLine);
          cTagArea = 0;
          break;
        }
      }
    }
	else
	{
    	fprintf (fdOut, "%s\n", acInLine);
	}	
  }


  fclose (fdIn);
  fclose (fdOut);
  if (remove (pcFileName) == 0)
  {
    rename (acTempName, pcFileName);
  }
  return 1;
}
/**************************************************************************
* Function NAme : ifx_GetCfgDatafromString(...)
* DESCRIPTION   :    find the data in the string pString
* Input         :
				pString :
                pSymbol : Search Name
* Return Value :  a pointer to the beginning of the Data which found,
*                      or NULL if the pSymbol is not found
**********************************************************************/
char8 *ifx_GetCfgDatafromString(char8 *pcString, char8 *pcSymbol)
{
        char8  acseps[]   = "\t\n\"";
        if ((pcString = strstr(pcString, pcSymbol)) == NULL)
        {
                return NULL;
        }

        if (strtok(pcString, "=") == NULL)
        {
                return NULL;
        }

        pcString = strtok(NULL, acseps);
        return pcString;
}
/***************************************************************************8
*  Function Name        :   IFX_CM_GetCfgData
*  Description          : set configuration data
*  Input Values         :
*  Variable Name   ==>     File Name               Pipe Command
*-------------------------------------------------------------------------------
*  pFileName       ==>     Open File Name         Open pipe command
*  pTag            ==>     TAG_xxx                NULL
*  pData           ==>     Search Name            which Line obtained
*  pRetValue       ==>     Return string.         Return string.
*
*  Return Value :  0 is FALSE. 1 is TRUE
*
*  ex1. File Name ==>      if ( ifx_GetCfgData(FILE_RC_CONF,
*                               TAG_DHCP_BINPOND, "Server", sValue) == 1)
*  ex2. Pipe     ==>  if ( ifx_GetCfgData(&command, NULL, "1", sValue) == 1 )
*****************************************************************************/

#define IFX_CM_RC_SIZE_K 32

int32 IFX_CM_GetRcCfgData(IN char8 *pcFileName,
                        IN char8 *pcTag,
                        IN char8 *pcData,
                        OUT char8 *pcRetValue)
{
  FILE   *fd=NULL,*temp=NULL;
  char8  *pcString = NULL;
  char8  acbuffer[IFX_CM_MAX_BUFF_LEN*IFX_CM_RC_SIZE_K];
  char8  acBeginTag[IFX_CM_MAX_TAG_LEN];
  char8  acValue[IFX_CM_MAX_BUFF_LEN];
  int32  iReturn = 0;
  int32  iLine = 0;
  int32  iIndex = 1;

  if ( pcTag && *pcTag )
  {
     if ((fd = fopen(pcFileName, "r")) != NULL)
      {
				  temp = fd;
          if (acbuffer != NULL)
          {
              memset(acbuffer, 0x00, IFX_CM_MAX_BUFF_LEN*IFX_CM_RC_SIZE_K);
          }
          else
          {
              iReturn = 0;
              goto exit;
          }
		  
          fread(acbuffer, sizeof(char8), IFX_CM_MAX_BUFF_LEN*IFX_CM_RC_SIZE_K, fd);
		  #ifdef KLOCWORK
		  acbuffer[(IFX_CM_MAX_BUFF_LEN*IFX_CM_RC_SIZE_K)-1] = '\0';
		  #endif
		
          sprintf(acBeginTag, "#<< %s", pcTag);
     
          if ((pcString = strstr(acbuffer, acBeginTag)) == NULL)
          {
             iReturn = 0;
             goto exit;
          }


          pcString = ifx_GetCfgDatafromString(pcString, pcData);

          if (pcString == NULL)
          {
             iReturn = 0;
             goto exit;
          }
		   #ifdef KLOCWORK
			if(strlen(pcString) < 128)
		   #endif
          strcpy(pcRetValue, pcString);
					//printf("Val = %s\n",pcRetValue);
          iReturn = 1;
      }
      else
      {
         iReturn = 0;
      }
    }
    else
    {
       memset(acValue, 0x00, IFX_CM_MAX_BUFF_LEN);
       iLine = atoi(pcData);

       if ((fd = popen(pcFileName, "r")) == NULL)
       {
           iReturn = 0;
           goto exit;
       }

       while ( fgets(acValue, IFX_CM_MAX_BUFF_LEN, fd) )
       {
          if (iIndex == iLine)
          {
              acValue[strlen(acValue)-1] = 0; 
		   #ifdef KLOCWORK
			if(strlen(acValue) < 128)
		   #endif
              strcpy(pcRetValue, acValue);
              iReturn = 1;
              goto exit;
          }
          iIndex++;
       }

       iReturn = 0;
   }

exit:
  if(pcTag)
  {
     if (temp)
     {
        fclose(temp);
     }
   }
   else
   {
      if (fd)
      {
         pclose(fd);
       }
   }

   return iReturn;
}
void
ifx_setrc_Tpc(x_IFX_DECT_TransmitPowerParam *pxTPCParams)
{
	char a[25][128]={0};
	int i=0;
	//printf("Set TPC\n");
	sprintf(a[0],"TransPower_0_cpeId=\"%d\"\n",1);
	sprintf(a[1],"TransPower_0_pcpeId=\"%d\"\n",1);
	sprintf(a[2],"TransPower_0_TunDgtRef=\"%d\"\n",pxTPCParams->ucTuneDigitalRef);
	sprintf(a[3],"TransPower_0_PABiasRef=\"%d\"\n",pxTPCParams->ucPABiasRef);
	sprintf(a[4],"TransPower_0_Pwroffset0=\"%d\"\n",pxTPCParams->ucPowerOffset[0]);
	sprintf(a[5],"TransPower_0_Pwroffset1=\"%d\"\n",pxTPCParams->ucPowerOffset[1]);
	sprintf(a[6],"TransPower_0_Pwroffset2=\"%d\"\n",pxTPCParams->ucPowerOffset[2]);
	sprintf(a[7],"TransPower_0_Pwroffset3=\"%d\"\n",pxTPCParams->ucPowerOffset[3]);
	sprintf(a[8],"TransPower_0_Pwroffset4=\"%d\"\n",pxTPCParams->ucPowerOffset[4]);
	sprintf(a[9],"TransPower_0_TD1=\"%d\"\n",pxTPCParams->ucTD1);
	sprintf(a[10],"TransPower_0_TD2=\"%d\"\n",pxTPCParams->ucTD2);
	sprintf(a[11],"TransPower_0_TD3=\"%d\"\n",pxTPCParams->ucTD3);
	sprintf(a[12],"TransPower_0_PA1=\"%d\"\n",pxTPCParams->ucPA1);
	sprintf(a[13],"TransPower_0_PA2=\"%d\"\n",pxTPCParams->ucPA2);
	sprintf(a[14],"TransPower_0_PA3=\"%d\"\n",pxTPCParams->ucPA3);
	sprintf(a[15],"TransPower_0_SwPwrMde=\"%d\"\n",pxTPCParams->ucSWPowerMode);
	sprintf(a[16],"TransPower_0_Txpow0=\"%d\"\n",pxTPCParams->ucTXPOW_0);
	sprintf(a[17],"TransPower_0_Txpow1=\"%d\"\n",pxTPCParams->ucTXPOW_1);
	sprintf(a[18],"TransPower_0_Txpow2=\"%d\"\n",pxTPCParams->ucTXPOW_2);
	sprintf(a[19],"TransPower_0_Txpow3=\"%d\"\n",pxTPCParams->ucTXPOW_3);
	sprintf(a[20],"TransPower_0_Txpow4=\"%d\"\n",pxTPCParams->ucTXPOW_4);
	sprintf(a[21],"TransPower_0_Txpow5=\"%d\"\n",pxTPCParams->ucTXPOW_5);
	sprintf(a[22],"TransPower_0_Dbpow=\"%d\"\n",pxTPCParams->ucDBPOW);
	sprintf(a[23],"TransPower_0_TuneDigit=\"%d\"\n",pxTPCParams->ucTuneDigital);
	sprintf(a[24],"TransPower_0_TxBias=\"%d\"\n",pxTPCParams->ucTxBias);
	//printf("Set TPC1 %s\n",a);
	IFX_CM_SetRcCfgData (IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,25,a[0],a[1],a[2],a[3],
			a[4],a[5],a[6],a[7],a[8],a[9],a[10],a[11],a[12],a[13],a[14],a[15],a[16],
			a[17],a[18],a[19],a[20],a[21],a[22],a[23],a[24]);

#ifdef DECT_PART
	//printf("Set TPC to dect_rc.conf %s\n",a);
	//Write data to the dect partition....
	IFX_CM_SetRcCfgData (IFX_CM_FILE_DECT_RC_CONF,IFX_CM_TAG_TPC,25,a[0],a[1],a[2],a[3],
			a[4],a[5],a[6],a[7],a[8],a[9],a[10],a[11],a[12],a[13],a[14],a[15],a[16],
			a[17],a[18],a[19],a[20],a[21],a[22],a[23],a[24]);
	//There is a separate menu option to store in to flash. So commeneted below line
	//system("/etc/rc.d/backup_dect_config");
#endif

	//printf("Set TPC2\n");
}

	
void
ifx_getrc_Tpc(x_IFX_DECT_TransmitPowerParam *pxTPCParams)
{
	char a[128];
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_TunDgtRef",a);
	pxTPCParams->ucTuneDigitalRef = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_PABiasRef",a);
	pxTPCParams->ucPABiasRef = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Pwroffset0",a);
	pxTPCParams->ucPowerOffset[0] = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Pwroffset1",a);
	pxTPCParams->ucPowerOffset[1] = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Pwroffset2",a);
	pxTPCParams->ucPowerOffset[2] = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Pwroffset3",a);
	pxTPCParams->ucPowerOffset[3] = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Pwroffset4",a);
	pxTPCParams->ucPowerOffset[4] = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_TD1",a);
	pxTPCParams->ucTD1 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_TD2",a);
	pxTPCParams->ucTD2 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_TD3",a);
	pxTPCParams->ucTD3 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_PA1",a);
	pxTPCParams->ucPA1 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_PA2",a);
	pxTPCParams->ucPA2 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_PA3",a);
	pxTPCParams->ucPA3 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_SwPwrMde",a);
	pxTPCParams->ucSWPowerMode = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Txpow0",a);
	pxTPCParams->ucTXPOW_0 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Txpow1",a);
	pxTPCParams->ucTXPOW_1 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Txpow2",a);
	pxTPCParams->ucTXPOW_2 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Txpow3",a);
	pxTPCParams->ucTXPOW_3 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Txpow4",a);
	pxTPCParams->ucTXPOW_4 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Txpow5",a);
  pxTPCParams->ucTXPOW_5 = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_Dbpow",a);
	pxTPCParams->ucDBPOW = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_TuneDigit",a);
	pxTPCParams->ucTuneDigital = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_TPC,"TransPower_0_TxBias",a);
	pxTPCParams->ucTxBias = atoi(a);
}

void
ifx_setrc_Bmc(x_IFX_DECT_BMCRegParams *pxBMC)
{
	char a[18][128]={0};
	/* Get existing values */
	sprintf(a[0],"BmcParams_0_cpeId=\"%d\"\n",1);
	sprintf(a[1],"BmcParams_0_pcpeId=\"%d\"\n",1);
	sprintf(a[2],"BmcParams_0_RssiFreeLevel=\"%d\"\n",pxBMC->ucRSSIFreeLevel);
	sprintf(a[3],"BmcParams_0_RssiBusyLevel=\"%d\"\n",pxBMC->ucRSSIBusyLevel);
	sprintf(a[4],"BmcParams_0_BearerChgLimit=\"%d\"\n",pxBMC->ucBearerChgLim);
	sprintf(a[5],"BmcParams_0_DefaultAntenna=\"%d\"\n",pxBMC->ucDefaultAntenna);
	sprintf(a[6],"BmcParams_0_WOPNSF=\"%d\"\n",pxBMC->ucWOPNSF);
	sprintf(a[7],"BmcParams_0_WWSF=\"%d\"\n",pxBMC->ucWWSF);
	sprintf(a[8],"BmcParams_0_CNTUPCtrlReg=\"%d\"\n",pxBMC->ucCNTUPCtrlReg);
	sprintf(a[9],"BmcParams_0_DelayReg=\"%d\"\n",pxBMC->ucDelayReg);
	sprintf(a[10],"BmcParams_0_HandOverEvalper=\"%d\"\n",pxBMC->ucHandOverEvalper);
	sprintf(a[11],"BmcParams_0_SYNCMCtrlReg=\"%d\"\n",pxBMC->ucSYNCMCtrlReg);
	sprintf(a[12],"BmcParams_0_Reserved_0=\"%d\"\n",255);
	sprintf(a[13],"BmcParams_0_Reserved_1=\"%d\"\n",255);
	sprintf(a[14],"BmcParams_0_Reserved_2=\"%d\"\n",3);
	sprintf(a[15],"BmcParams_0_Reserved_3=\"%d\"\n",0);
	sprintf(a[16],"BmcParams_0_Reserved_4=\"%d\"\n",0);
	sprintf(a[17],"BmcParams_0_Reserved_5=\"%d\"\n",0);
	IFX_CM_SetRcCfgData (IFX_CM_FILE_RC_CONF,IFX_CM_TAG_BMC,18,a[0],a[1],a[2],a[3],
			a[4],a[5],a[6],a[7],a[8],a[9],a[10],a[11],a[12],a[13],a[14],a[15],a[16],a[17]);

#ifdef DECT_PART
	//printf("Set BMC to dect_rc.conf %s\n",a);
	//Set data to dect config
	IFX_CM_SetRcCfgData (IFX_CM_FILE_DECT_RC_CONF,IFX_CM_TAG_BMC,18,a[0],a[1],a[2],a[3],
			a[4],a[5],a[6],a[7],a[8],a[9],a[10],a[11],a[12],a[13],a[14],a[15],a[16],a[17]);
	//There is a separate menu option to store in to flash. So commeneted below line
	//system("/etc/rc.d/backup_dect_config");
#endif
}

void
ifx_getrc_Bmc(x_IFX_DECT_BMCRegParams *pxBMC)
{
	char a[128];
	/* Get existing values */
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_BMC,IFX_CM_TAG_BMC_RSSIFREE,a);
	pxBMC->ucRSSIFreeLevel = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_BMC,IFX_CM_TAG_BMC_RSSIBUSY,a);
	pxBMC->ucRSSIBusyLevel = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_BMC,IFX_CM_TAG_BMC_BRLIMIT,a);
	pxBMC->ucBearerChgLim = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_BMC,IFX_CM_TAG_BMC_DEFANT,a);
	pxBMC->ucDefaultAntenna = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_BMC,IFX_CM_TAG_BMC_WOPNSF,a);
	pxBMC->ucWOPNSF = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_BMC,IFX_CM_TAG_BMC_WWSF,a);
	pxBMC->ucWWSF = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_BMC,IFX_CM_TAG_BMC_DRONCTRL,a);
	pxBMC->ucCNTUPCtrlReg = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_BMC,IFX_CM_TAG_BMC_DVAL,a);
	pxBMC->ucDelayReg = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_BMC,IFX_CM_TAG_BMC_HOFRAME,a);
	pxBMC->ucHandOverEvalper = atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,IFX_CM_TAG_BMC,IFX_CM_TAG_BMC_SYNCMODE,a);
	pxBMC->ucSYNCMCtrlReg = atoi(a);
}

void
ifx_getrc_Freq(uchar8 *pucFreqTx, uchar8 *pucFreqRx, uchar8 *pucFreqRange)
{
	char a[128];
	                  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"CtrySet","CtrySet_0_Txoffset",a);
									 *pucFreqTx = atoi(a);

                   IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"CtrySet","CtrySet_0_Rxoffset",a);
									 *pucFreqRx = atoi(a);
									
                   IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"CtrySet","CtrySet_0_FreqRange",a);
									 *pucFreqRange = atoi(a);


}
void
ifx_setrc_Freq(uchar8 ucFreqTx, uchar8 ucFreqRx, uchar8 ucFreqRange)
{
	char a[16][128]={0};
	//Just for dummy to keep the data intact in flash which is not used by DECT as of now
	uchar8 ucEci=1,ucChmaskHigh=3,ucChmaskLow=255;
  /* Store  values To Rc.conf */
     sprintf(a[0],"CtrySet_0_cpeId=\"%d\"\n",1);
     sprintf(a[1],"CtrySet_0_pcpeId=\"%d\"\n",1);
     sprintf(a[2],"CtrySet_0_Txoffset=\"%d\"\n",
								 ucFreqTx);
     sprintf(a[3],"CtrySet_0_Rxoffset=\"%d\"\n",
								 ucFreqRx);
     sprintf(a[4],"CtrySet_0_FreqRange=\"%d\"\n",
								 ucFreqRange);
	 
	 sprintf(a[5],"CtrySet_0_Eci=\"%d\"\n",
										ucEci);
	 sprintf(a[6],"CtrySet_0_MaskHigh=\"%d\"\n",
										ucChmaskHigh);
	 sprintf(a[7],"CtrySet_0_MaskLow=\"%d\"\n",
										ucChmaskLow);
	IFX_CM_SetRcCfgData (IFX_CM_FILE_DECT_RC_CONF,"CtrySet",8,a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7]);
		

}

void
ifx_getrc_Osc(uint16 *puiOscTrimValue, uchar8 *pucP10Status)
{
	char a[128];
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Osctrim","Osctrim_0_Osctrimhigh",a);
									    *puiOscTrimValue = atoi(a)<<8;
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Osctrim","Osctrim_0_Osctrimlow",a);
									 *puiOscTrimValue |= atoi(a);
  IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Osctrim","Osctrim_0_P10Status",a);
										*pucP10Status = atoi(a);
	
}
void
ifx_setrc_Osc(uint16 uiOscTrimValue, uchar8 ucP10Status)
{
	char a[16][128]={0};
	 /* Store  values To Rc.conf */
   sprintf(a[0],"Osctrim_0_cpeId=\"%d\"\n",1);
   sprintf(a[1],"Osctrim_0_pcpeId=\"%d\"\n",1);
   sprintf(a[2],"Osctrim_0_Osctrimhigh=\"%d\"\n",
	         uiOscTrimValue>>8);
   sprintf(a[3],"Osctrim_0_Osctrimlow=\"%d\"\n",
		       uiOscTrimValue&0xFF);
   sprintf(a[4],"Osctrim_0_P10Status=\"%d\"\n",ucP10Status);
	 IFX_CM_SetRcCfgData (IFX_CM_FILE_RC_CONF,"Osctrim",5,a[0],a[1],a[2],a[3],a[4]);
#ifdef DECT_PART
	//Set data to dect config 
	printf("Setting OSCtrim to dect_rc.conf\n");
	IFX_CM_SetRcCfgData (IFX_CM_FILE_DECT_RC_CONF,"Osctrim",5,a[0],a[1],a[2],a[3],a[4]);
	//There is a separate menu option to store in to flash. So commeneted below line
	//system("/etc/rc.d/backup_dect_config");
#endif
}
void ifx_getrc_Gfsk(uint16 *puiGfskValue)
{
	char a[128];
	                   IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Gfsk","Gfsk_0_Gfskhigh",a);
									    *puiGfskValue= atoi(a)<<8;

                   IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Gfsk","Gfsk_0_Gfsklow",a);
									 *puiGfskValue |= atoi(a);
	
}
void
ifx_setrc_Gfsk(uint16 unGfskValue)
{
	char a[16][128]={0};
	                 /* Store  values To Rc.conf */
                     sprintf(a[0],"Gfsk_0_cpeId=\"%d\"\n",1);
                     sprintf(a[1],"Gfsk_0_pcpeId=\"%d\"\n",1);
                     sprintf(a[2],"Gfsk_0_Gfskhigh=\"%d\"\n",
												 unGfskValue>>8);
                     sprintf(a[3],"Gfsk_0_Gfsklow=\"%d\"\n",
												 unGfskValue&0xFF);
										 IFX_CM_SetRcCfgData (IFX_CM_FILE_RC_CONF,"Gfsk",4,a[0],a[1],a[2],a[3]);

#ifdef DECT_PART
			//Set data to dect config							 
			printf("Setting Gfsk to dect_rc.conf\n");
			IFX_CM_SetRcCfgData (IFX_CM_FILE_DECT_RC_CONF,"Gfsk",4,a[0],a[1],a[2],a[3]);
			//There is a separate menu option to store in to flash. So commeneted below line
			//system("/etc/rc.d/backup_dect_config");
#endif
}
void ifx_getrc_Rfpi(uchar8 *pcRFPI)
{
	char a[128];
	                   IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Rfpi","Rfpi_0_byte1",a);
									 pcRFPI[0] = atoi(a);

                   IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Rfpi","Rfpi_0_byte2",a);
									 pcRFPI[1] = atoi(a);
									
                   IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Rfpi","Rfpi_0_byte3",a);
									 pcRFPI[2] = atoi(a);
								 	 
                   IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Rfpi","Rfpi_0_byte4",a);
									 pcRFPI[3] = atoi(a);
									 
                   IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Rfpi","Rfpi_0_byte5",a);
									 pcRFPI[4] = atoi(a);
	
}
void
ifx_setrc_Rfpi(uchar8 *pcRFPI)
{
	char a[16][128]={0};
		                   /* Store  values To Rc.conf */
                     sprintf(a[0],"Rfpi_0_cpeId=\"%d\"\n",1);
                     sprintf(a[1],"Rfpi_0_pcpeId=\"%d\"\n",1);
                     sprintf(a[2],"Rfpi_0_byte1=\"%d\"\n",
												 pcRFPI[0]);
                     sprintf(a[3],"Rfpi_0_byte2=\"%d\"\n",
												 pcRFPI[1]);

                     sprintf(a[4],"Rfpi_0_byte3=\"%d\"\n",
												 pcRFPI[2]);
										 
                     sprintf(a[5],"Rfpi_0_byte4=\"%d\"\n",
												 pcRFPI[3]);
										 
                     sprintf(a[6],"Rfpi_0_byte5=\"%d\"\n",
												 pcRFPI[4]);

                     sprintf(a[7],"Rfpi_0_byte6=\"0\"\n");
										 IFX_CM_SetRcCfgData (IFX_CM_FILE_RC_CONF,"Rfpi",8,a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7]);
	

}
void
ifx_getrc_RfMode(uchar8 *pucRFMode , uchar8 *pucChannelNumber,uchar8 *pucSlotNumber)
{
	char a[128];
                    IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Rfmode","Rfmode_0_TstMode",a);
										*pucRFMode = atoi(a);

                    IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Rfmode","Rfmode_0_Channel",a);
										*pucChannelNumber	= atoi(a);
							  		
                    IFX_CM_GetRcCfgData(IFX_CM_FILE_RC_CONF,"Rfmode","Rfmode_0_Slot",a);
										*pucSlotNumber = atoi(a);
	
}	

void
ifx_setrc_RfMode(uchar8 ucRFMode , uchar8 ucChannelNumber,uchar8 ucSlotNumber)
{
	char a[16][128]={0};
	                   /* Store  values To Rc.conf */
                     sprintf(a[0],"Rfmode_0_cpeId=\"%d\"\n",1);
                     sprintf(a[1],"Rfmode_0_pcpeId=\"%d\"\n",1);
                     sprintf(a[2],"Rfmode_0_TstMode=\"%d\"\n",ucRFMode);
                     sprintf(a[3],"Rfmode_0_Channel=\"%d\"\n",
												 ucChannelNumber);
                     sprintf(a[4],"Rfmode_0_Slot=\"%d\"\n",ucSlotNumber);
										 IFX_CM_SetRcCfgData (IFX_CM_FILE_RC_CONF,"Rfmode",5,a[0],a[1],a[2],a[3],
													      a[4]);
	
}	
