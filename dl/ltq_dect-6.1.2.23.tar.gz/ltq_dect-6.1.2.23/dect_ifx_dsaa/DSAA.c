/*

* ========================================================================  *
* IMPORTANT: THIS FILE IS COMPANY-CONFIDENTIAL INFINEON. DO NOT RELEASE     *
*            THIS SOURCE CODE TO PARTIES EXTERNAL OF INFINEON!              *
* ========================================================================  *

*****************************************************************************
*                                                                           *
*     Project  ::   PRODECT - DECT Home System Protocol Software V2.1       *
*                   (c) 1998 SIEMENS AG. All rights reserved.               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     $Workfile::   dsaa.c                                                 $*
*     $Revision::   1.6                                                    $*
*     $Author::   Maesel_82123                                             $*
*     $Date::   Feb 19 1998 14:05:28                                       $*
*     $Modtime::   Feb 19 1998 13:59:22                                    $*
*     $Log::   G:/Prodect/ARCHIVES/DSAA.C_V                                $*
 * 
 *    Rev 1.6   Feb 19 1998 14:05:28   Maesel_82123
 *  PVCS header
*                                                                           *
*     Contents   :  DECT Standard Authentication Algorithm                  *
*                                                                           *
*****************************************************************************
*/
   /* ========                                                             */
   /* Includes                                                             */
   /* ========                                                             */

#include "DSAA.h"


   /* ===========================                                          */
   /* Local function declarations                                          */
   /* ===========================                                          */
static void function_block( unsigned char *, unsigned char *, unsigned char, unsigned char );
static void combine_fct   ( unsigned char *, unsigned char, unsigned char );

                                       /* The following variable holds     */
                                       /* the DSAA Substitution Box        */
                                       /* (SBOX).                          */
unsigned char sbox[ 256 ] = {
176, 104, 111, 246, 125, 232,  22, 133,  57, 124, 127, 222,  67, 240,  89, 169,
251, 128,  50, 174,  95,  37, 140, 245, 148, 107, 216, 234, 136, 152, 194,  41,
207,  58,  80, 150,  28,   8, 149, 244, 130,  55,  10,  86,  44, 255,  79, 196,
 96, 165, 131,  33,  48, 248, 243,  40, 250, 147,  73,  52,  66, 120, 191, 252,
 97, 198, 241, 167,  26,  83,   3,  77, 134, 211,   4, 135, 126, 143, 160, 183,
 49, 179, 231,  14,  47, 204, 105, 195, 192, 217, 200,  19, 220, 139,   1,  82,
193,  72, 239, 175, 115, 221,  92,  46,  25, 145, 223,  34, 213,  61,  13, 163,
 88, 129,  62, 253,  98,  68,  36,  45, 182, 141,  90,   5,  23, 190,  39,  84,
 93, 157, 214, 173, 108, 237, 100, 206, 242, 114,  63, 212,  70, 164,  16, 162,
 59, 137, 151,  76, 110, 116, 153, 228, 227, 187, 238, 112,   0, 189, 101,  32,
 15, 122, 233, 158, 155, 199, 181,  99, 230, 170, 225, 138, 197,   7,   6,  30,
 94,  29,  53,  56, 119,  20,  17, 226, 185, 132,  24, 159,  42, 203, 218, 247,
166, 178, 102, 123, 177, 156, 109, 106, 249, 254, 202, 201, 168,  65, 188, 121,
219, 184, 103, 186, 172,  54, 171, 146,  75, 215, 229, 154, 118, 205,  21,  31,
 78,  74,  87, 113,  27,  85,   9,  81,  51,  12, 180, 142,  43, 224, 208,  91,
 71, 117,  69,  64,   2, 209,  60, 236,  35, 235,  11, 210, 161, 144,  38,  18 };

   /* ==========================                                           */
   /* Global function definition                                           */
   /* ==========================                                           */
/*
*****************************************************************************
*                                                                           *
*     Function :  Dsaa                                                      *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  The function implements the										 *
*                 DECT Standard Authentication Algorithm (DSAA)             *
* 						as specified in the document:										 *
*                 "Design Specification												 *
*                  DECT Standard Authentication Algorithm, Issue 1.0			 *
*                  by ETSI - 28 May 1991"												 *
*     Parms    :  d1              : pointer to 16 byte DSAA key             *
*                 d2              : pointer to 8 byte DSAA input            *
*                 e               : pointer to 16 byte DSAA result          *
*     Returns  :  none                                                      *
*     Remarks  :                                                            *
*                                                                           * 
*****************************************************************************
*/

void
Dsaa ( unsigned char * d1, unsigned char * d2, unsigned char * e )
{
	unsigned char in_1[ 8 ];
	unsigned char in_2[ 8 ];
    unsigned char i;
													/*	Copy d2 for in_1						*/
	for( i = 0; i < 8; i++ )
		in_1[ i ] = d2[ i ];
													/*	Copy middle of d1 for in_2 		*/
   for( i = 0; i < 8; i++ )
		in_2[ i ] = d1[ i + 4 ];
													/*	F( 6, 11 ) Function					*/
   function_block( in_1, in_2, 6, 11 ); 
													/*	Copy d2 for in_1						*/
   for( i = 0; i < 8; i++ )
		in_1[ i ] = d2[ i ];
													/*	F( 9, 15 ) Function					*/
   function_block( in_2, in_1, 9, 15 );
													/*	Copy in_1 to middle of result	   */
	for( i = 0; i < 8; i++ )
      e[ i + 4 ] = in_1[ i ];
													/*	Copy border of d1 to in_2			*/
   for( i = 0; i < 4; i++)
      in_2[ i ] = d1[ i ];          
   for( i = 4; i < 8; i++ )
      in_2[ i ] = d1[ i + 8 ];        
													/*	F( 12, 19 ) Function					*/
	function_block( in_1, in_2, 12, 19 );
													/*	Copy middle of e to in_1			*/
	for( i = 0; i < 8; i++ )
    	in_1[ i ] = e[ i + 4 ];  
													/*	F( 15, 23 ) Function					*/
   function_block( in_2, in_1, 15, 23 );              
													/*	Copy result to e						*/
	for( i = 0; i < 4; i++ )
      e[ i ] = in_1[ i ];  
	for( i = 4; i < 8; i++ )
      e[ i + 8 ] = in_1[ i ];  
}

   /* =========================                                            */
   /* Local function definition                                            */
   /* =========================                                            */
/*
*****************************************************************************
*                                                                           *
*     Function :  function_block                                            *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  The function implements the block F(m,n).    				 *
*     Parms    :  key             : pointer to 8 byte key                   *
*                 input           : pointer to 8 byte input                 *
*                 m               : bit position m                          *
*                 n               : bit position n                          *
*     Returns  :  none                                                      *
*     Remarks  :                                                            *
*                                                                           * 
*****************************************************************************
*/
static void
function_block( unsigned char * key, unsigned char * input, unsigned char m, 
                unsigned char n )
{
	unsigned char r, i, help;
	unsigned char new2[ 8 ];

   #ifdef KLOCWORK
   memset(new2,0,sizeof(new2));
   #endif
													/*	Apply the "Key Schedule" &			*/
													/*	"Round Function " six times !		*/
	for( r = 0; r < 6; r++ )
	{
													/*	Key Schedule							*/
													/*	--------------------------------	*/
													/*	Ref. DSAA Design Specificaton		*/
													/*	2.5 / page 7							*/
		for( i = 0; i < 64; i++ )
		{
			help = ( m + n * i ) % 64;
			if( key[ help / 8 ] & ( 0x01 << ( help % 8 )))
		 		 new2[ i / 8 ] |= ( 0x01 << ( i % 8 ));
			else
		 		 new2[ i / 8 ] &= ~( 0x01 << ( i % 8 ));
		}
   	for (i=0; i<8; i++)
      	key[i] = new2[i];
													/*	Round Function - Block A			*/
													/*	--------------------------------	*/
													/*	Ref. DSAA Design Specificaton		*/
													/*	2.4 / page 5							*/
   	for( i = 0; i < 8; i++ )
		{
      	input[ i ] = sbox[ (input[ i ] ^ key[ i ]) ];
		}
													/*	Round Function - Block B			*/
													/*	--------------------------------	*/
													/*	Ref. DSAA Design Specificaton		*/
													/*	2.4 / page 6							*/
		if(( r%3 ) == 0 )
		{
													/*	Round 1&3								*/
			combine_fct( input, 0, 4 );
   		combine_fct( input, 1, 5 );
   		combine_fct( input, 2, 6 );
   		combine_fct( input, 3, 7 );
		}
		if(( r%3 ) == 1 )
		{
													/*	Round 2&4								*/
			combine_fct( input, 0, 2 );
   		combine_fct( input, 1, 3 );
   		combine_fct( input, 4, 6 );
   		combine_fct( input, 5, 7 );
		}
		if(( r%3 ) == 2 )
		{
													/*	Round 3&6								*/
			combine_fct( input, 0, 1 );
   		combine_fct( input, 2, 3 );
   		combine_fct( input, 4, 5 );
   		combine_fct( input, 6, 7 );
		}
	}
}

/*
*****************************************************************************
*                                                                           *
*     Function :  combine_fct                                               *
*                                                                           *
*****************************************************************************
*                                                                           *
*     Purpose  :  The function implements the Round function - Block B. 	 *
*     Parms    :  input           : pointer to 8 byte input                 *
*                 i_pos           : first bit position                      *
*                 j_pos           : second bit position                     *
*     Returns  :  none                                                      *
*     Remarks  :                                                            *
*                                                                           * 
*****************************************************************************
*/
static void
combine_fct( unsigned char * input, unsigned char i_pos, unsigned char j_pos )
{
	unsigned char help;

	help           =     input[ i_pos ]; 
   input[ i_pos ] = 2 * input[ i_pos ] +     input[ j_pos ];
   input[ j_pos ] =     help           + 3 * input[ j_pos ];
}
