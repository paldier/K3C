#!/bin/sh

if [ ! -n "$1" ] ; then
   echo "Usage : create_customer_package.sh SOURCE_PATH"
   echo "Help : create_customer_package.sh -h"
   exit 0
fi

if [ "$1" = "-h" ]; then
	echo "Note 1: From UGW-7.1.1 onwards GW sources has both Voice and ULE support always"	
	echo "Note 2: For ULE feature a separate ULE Firmware package is available"	
	echo "  "
	echo "  "
	echo "  "
	echo "Command usage : For No Source Package (Voice+ULE)"	
   echo "Usage : create_customer_package.sh SOURCE_PATH "
	echo "  "
	echo "  "
	echo "  "
	echo "Command usage : For Source Package (Voice+ULE)"	
   echo "Usage : create_customer_package.sh SOURCE_PATH SOURCE"
	echo "  "
	echo "  "
	exit 0;
fi

if [ "$2" = "SOURCE" ]; then
	echo "Source Package!!!!!!!!!!"
	rm -rf dect_ifx_dsaa
	find dect_ifx_catiq_stack/ \( -name *.o \) -o \( -name *.c \) -o \( -name *.d \) -o \( -name *.a \) -o \( -name Makefile \)  |xargs rm -rf

elif [ ! -n "$2" ] ; then
	echo "No Source Package!!!!!!!!!!"
	rm -rf dect_ifx_dsaa

	find dect_ifx_stack_toolkit -type d \( -name lib \) -o \( -name obj \) -o \( -name src \) -o \( -name make \) |xargs rm -rf
	find dect_ifx_stack_toolkit -type f -name build.sh |xargs rm -f

	find dect_ifx_catiq_stack/ \( -name *.o \) -o \( -name *.c \) -o \( -name *.d \) -o \( -name *.a \) -o \( -name Makefile \)  |xargs rm -rf
else
	exit 0;

fi


#Copy the required binaries
mkdir -p lib

cp -f $1/lib/libdectstack.a lib/
cp -f $1/lib/libdtk.a lib/
cp -f $1/lib/DSAA.obj dect_ifx_catiq_stack/DSAA_OBJS/
cp -f $1/lib/DSAA.obj lib/

rm -f create_customer_package.sh
rm -f dect_ifx_stack_toolkit/create_customer_package.sh



