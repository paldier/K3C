/**************************************************************************
**   FILE NAME     : IFX_DECT_DPSU.c
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "MESSAGE_DEF.H"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_StackIf.h"
#include "IFX_DECT_MsgEncoder.h"
#include <sys/time.h>
//#define DPSU_TEST
//#define DPSU_TIMESTAMP
#define printf(...)

#define print_data(...)

/*! \brief acHandsetMap defined in IFX_DECT_GlobalInfo.h
*/
#define acHandsetMap vxGlobalInfo.xDPSU.acHandsetMap

#ifdef ULE_SUPPORT
#define IFX_DECT_MAX_DATACON_HS  255
#else
#define IFX_DECT_MAX_DATACON_HS 6
#endif

/*! \brief vxSessionList defined in IFX_DECT_GlobalInfo.h
*/
#define vpxSessionList vxGlobalInfo.xDPSU.vxSessionList
#ifndef LTQ_RAW_DPSU
#define IFX_DECT_SUOTA_DECODE_2BYTECMD(pucBuff,nCmd); {\
	   if((*pucBuff)&0x80){\
	     nCmd = (*pucBuff)&0x7f;\
		 pucBuff++;\
	   }\
	   else if((*(pucBuff+1)&0x80)){\
	     nCmd = (((*pucBuff)<<7)|(*(pucBuff+1)&0x7f));\
		 pucBuff+=2;\
	   }\
	 }

#ifdef DPSU_TEST 
   static int32 iFlowcnt[IFX_DECT_MAX_DATACON_HS];
   static uchar8 ucNextGet;
#endif
x_IFX_DECT_IE_IWUAttributes vxIWUAttributesInfo[IFX_DECT_MAX_DATACON_HS];
uchar8 ucLastSdu;
uchar8 vacGmci[IFX_DECT_MAX_DATACON_HS][IFX_DECT_DPSU_MAX_APPLN];

x_IFX_DECT_DPSU_SuotaSession avxSuotaSess[IFX_DECT_MAX_SUOTACON];
x_IFX_DECT_SUOTA_CallBks vxSuotaCallBks;

e_IFX_Return IFX_DECT_DPSU_FreeGmci(IN uchar8 ucHandset, IN uchar8 ucGmci);
extern e_IFX_Return IFX_DECT_SetFTCap(x_IFX_DECT_FTCap *pxFTCapabilities);

#ifdef ULE_SUPPORT
extern e_IFX_Return IFX_DECT_ULE_ResetDPSUCallType(uchar8 ucInstanceId);
#endif

/* ======================= Utility Functions =========================  */
#ifdef DPSU_TIMESTAMP
e_IFX_Return 
IFX_DECT_DPSU_GetTimeStamp(){
  char buffer[30];
	struct timeval tv;
	time_t curtime;

	gettimeofday(&tv, NULL); 
	curtime=tv.tv_sec;

	strftime(buffer,30,"%m-%d-%Y  %T.",localtime(&curtime));
	printf("%s%ld\n",buffer,tv.tv_usec);
  return IFX_SUCCESS;
}
#endif

void 
IFX_DECT_DPSU_DumpData(IN uint32 uiLen, uchar8* pucData)
{
  int32 i=0;
  for(i=0;i<uiLen;i++){
	  printf("%c",pucData[i]);
	  //printf("%02x",pucData[i]);
	  if( i%16 == 0){
	    printf("\n");
	  }
  }
}
#endif
/*! \brief Get Free Connection Index for a Session Index.
    \param[in] iSessionIndex Session Index.
    \return Connection Index or IFX_FAILURE.
*/
 int32 IFX_DECT_DPSU_GetFreeConnectionIndex(IN int32 iSessionIndex){
   int32 iCount = 0;
   if((iSessionIndex < 0) || (iSessionIndex >= IFX_DECT_MAX_DATASESS)){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	                  "<API GetFreeConnectionIndex>Invalid iSessionIndex.API failed.");
					  
    return IFX_FAILURE;
   }
   for(iCount =0;iCount <IFX_DECT_MAX_DATACON; iCount++){
     if(vpxSessionList[iSessionIndex].xConnectionList[iCount].ucHandset == 0){
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	           "<API GetFreeConnectionIndex>Successful.");
							
      return iCount;
     }
   }
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
            "<API GetFreeConnectionIndex>API failed.");
						 
   return IFX_FAILURE;
 }

/*! \brief Get Matching Connection Index for a Session Index.
    \param[in] iSessionIndex Session Index.
	\param[in] ucHandset Handset Number.
	\return Connection Index or IFX_FAILURE.
*/

int32 IFX_DECT_DPSU_GetMatchConnectionIndex(IN int32 iSessionIndex,
                                            IN uchar8 ucHandset){
  int32 iCount = 0;

  #if 1
  if((iSessionIndex < 0) || (iSessionIndex >= IFX_DECT_MAX_DATASESS)) {
  #else
  if((iSessionIndex < 0) || (iSessionIndex >= IFX_DECT_MAX_DATASESS) || 
     (ucHandset >= IFX_DECT_MAX_DATACON)){
  #endif
	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		     "<API GetMatchConnectionIndex>Invalid iSessionIndex or ucHandset.API failed.");
    return IFX_FAILURE;
  }
  for(iCount =0;iCount <IFX_DECT_MAX_DATACON; iCount++){
    if(vpxSessionList[iSessionIndex].xConnectionList[iCount].ucHandset == ucHandset){
	    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		         "<API GetMatchConnectionIndex>Successful.");
		return iCount;
	}
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "<API GetMatchConnectionIndex>API failed.");
			 
  return IFX_FAILURE;
}
  
	   			
/*! \brief Get Matching Session Index based on Protocol Identifier for C Plane.
    \param[in] ucProtocolID Protocol Identifier.
    \return Connection Index or IFX_FAILURE.
*/
int32 IFX_DECT_DPSU_GetMatchSessionIndex_CPlane(IN uchar8 ucProtocolID){
  int32 iCount = 0;
  for(iCount =0;iCount <IFX_DECT_MAX_DATASESS; iCount++){
    if(vpxSessionList[iCount].acProtocol_ID == ucProtocolID){
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	             "<API GetMatchSessionIndex_CPlane>Successful.");
      return iCount;
    }
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "<API GetMatchSessionIndex_CPlane>API failed.");
  return IFX_FAILURE;
}

/*! \brief  Get Free Session Index.
    \return Session Index or IFX_FAILURE.
*/
int32 IFX_DECT_DPSU_GetFreeSessionIndex(){
  int32 iCount = 0;
  for(iCount =0;iCount <IFX_DECT_MAX_DATASESS; iCount++){
    if(vpxSessionList[iCount].acProtocol_ID == 0){
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	                   "<API GetFreeSessionIndex>Successful.");
					   
      return iCount;
    }
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                         "<API GetFreeSessionIndex>API failed.");
						 
  return IFX_FAILURE;
}

/*! \brief Get Matching Session on the basis of Incarnation Number for U Plane.
    \param[in] ucInstance Incarnation Number.
    \return Session Index of IFX_FAILURE.
*/
int32 IFX_DECT_DPSU_GetMatchSessionIndex_UPlane(IN uchar8 ucInstance){
  int32 iCount1 = 0;
  int32 iCount2 = 0;
  for(iCount1 =0;iCount1 <IFX_DECT_MAX_DATASESS; iCount1++){
    for(iCount2 =0;iCount2 <IFX_DECT_MAX_DATACON; iCount2++){
      if(vpxSessionList[iCount1].xConnectionList[iCount2].ucInstance == ucInstance){
	    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		             "<API GetMatchSessionIndex_UPlane>Successful.");
					 
        return iCount1;
      }  
    }
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       "<API GetMatchSessionIndex_UPlane>Failed.");
  return IFX_FAILURE;
}


/*! \brief IFX_DECT_DPSU_ReleaseConnectionResources is used to free Connection 
           by releasing allocated resources.
    \param[in] uiCallHdl Connection handle.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ReleaseConnectionResources(IN uint32 uiCallHdl){


  x_IFX_DECT_DPSU_ConnectionInfo *pxConn = NULL;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "<API ReleaseConnectionResources>Entry.");

  pxConn = (x_IFX_DECT_DPSU_ConnectionInfo*)uiCallHdl;
#ifdef DPSU_TEST
  iFlowcnt[pxConn->ucHandset] = 0;
  ucNextGet = 0;
#endif

if (pxConn == NULL)
	return IFX_FAILURE;
  
  if((pxConn->ucHandset > 0) && (pxConn->ucHandset <= IFX_DECT_MAX_HS))
  {
  IFX_DECT_FreeMCEI(pxConn->ucHandset,pxConn->ucInstance);
  IFX_DECT_MU_SetModuleOwner(pxConn->ucHandset,IFX_DECT_MU_REMOVE_OWNER,IFX_DECT_DPSU_ID);
  }
#ifdef ULE_SUPPORT
  else if (pxConn->ucHandset > IFX_DECT_MAX_HS)
  {
  	IFX_DECT_ULE_ResetDPSUCallType(pxConn->ucHandset);
  }
#endif

  acHandsetMap[pxConn->ucInstance] = 0;

  IFX_DECT_DPSU_FreeGmci(pxConn->ucHandset,pxConn->xDgmep.ucGMCI);

  memset(pxConn,0,sizeof(x_IFX_DECT_DPSU_ConnectionInfo));
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "<API ReleaseConnectionResources>Successful.");
  return IFX_SUCCESS;
}

#ifndef LTQ_RAW_DPSU
/*! \brief IFX_DECT_DPSU_CleanUpConnectionResources is used to cleanup Connection 
           by releasing allocated resources.
    \param[in] ucHandsetId Handset Id.
    \return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return
IFX_DECT_DPSU_CleanUpConnectionResources(IN uchar8 ucHandsetId)
{
  int32 iCount1 = 0;
  int32 iCount2 = 0;
  uint32 uiIEHdl = 0;
  x_IFX_DECT_DPSU_ConnectionInfo *pxConn = NULL;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                       "Entry.");
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                       "HandsetId",ucHandsetId);
  for(iCount1 =0;iCount1 <IFX_DECT_MAX_DATASESS; iCount1++){
    for(iCount2 =0;iCount2 <IFX_DECT_MAX_DATACON; iCount2++){
      if(vpxSessionList[iCount1].xConnectionList[iCount2].ucHandset == ucHandsetId){
	      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		             "Match Found.");
        printf("iCount1: %d iCount2 %d\n",iCount1,iCount2);
			  pxConn = &vpxSessionList[iCount1].xConnectionList[iCount2];
        if(vpxSessionList[iCount1].xCallBks.pfnCallRelease != NULL){

	        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		                   "CallBk is called.");
          if(vpxSessionList[iCount1].xCallBks.pfnCallRelease(
              (uint32)pxConn,uiIEHdl,IFX_DECT_RELEASE_NORMAL,pxConn->uiPrivateData) == IFX_FAILURE){

            IFX_DECT_DPSU_ReleaseConnectionResources((uint32)pxConn);
          }
        }
        //memset(&vpxSessionList[iCount1].xConnectionList[iCount2],0,sizeof(x_IFX_DECT_DPSU_ConnectionInfo));
      }  
    }
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                       "Exit.");
  return IFX_SUCCESS;
}

/*! \brief IFX_DECT_DPSU_IsCallExisting is used to check for any  
           connection is available or not.
    \param[in] ucHandSet Handset Id.
    \return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return
IFX_DECT_DPSU_IsCallExisting(IN uchar8 ucHandSet)
{
  uint32 uiModuleOwner;
  uchar8 ucInstance;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
                       "Entry.");
  if(IFX_DECT_MU_IsCallExisting(ucHandSet,&ucInstance)== IFX_SUCCESS) {
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "Call already exists on the handset");
    uiModuleOwner = 
      IFX_DECT_MU_GetModuleOwner(ucHandSet);
	  if(uiModuleOwner & IFX_DECT_DPSU_ID){
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
              "Data Call already exists on the handset");
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}
#endif
/*! \brief Registers the Protocol and Call back functions.
    \param[in] ucProtocolID is the protocol Identifier.
    \param[in] pxCallBks are the call control call back functions.
    \note Functions that are not being registered should be set to NULL.
    This API should be usually called for creating the instance.
    Subsequent calls to this API would result in overwriting the previously
    registered functions with the new functions.
*/
e_IFX_Return IFX_DECT_DPSU_RegisterDataApp(IN uchar8 ucProtocolID,
                                           IN x_IFX_DECT_DPSU_CallBks *pxCallBks){
  
  int32 iSessionIndex = 0;
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "<API RegisterCallBks>Entry.");

  if(pxCallBks == NULL){
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "<API RegisterCallBks>Unsuccessful.Pointer to Callbks NULL.");

   return IFX_FAILURE;
  }
   
  iSessionIndex = IFX_DECT_DPSU_GetFreeSessionIndex();
  if(iSessionIndex != IFX_FAILURE){
    if(IFX_DECT_DPSU_ValidateProtoID(ucProtocolID) == IFX_SUCCESS){
       vpxSessionList[iSessionIndex].acProtocol_ID = ucProtocolID;
       memcpy(&vpxSessionList[iSessionIndex].xCallBks,pxCallBks,
              sizeof(x_IFX_DECT_DPSU_CallBks));
    }
  }
#ifndef LTQ_RAW_DPSU
  memset(vacGmci,0,sizeof(vacGmci));
  memset(&vxIWUAttributesInfo, 0, sizeof(vxIWUAttributesInfo)); // sizeof(x_IFX_DECT_IE_IWUAttributes)*IFX_DECT_MAX_DATACON_HS);
  ucLastSdu = 0;  
#endif  
  return IFX_SUCCESS;
}

#ifndef LTQ_RAW_DPSU
/*=========================== SUOTA APIs Defined Here ===============================*/
/*! \brief The Api IFX_DECT_SUOTA_GetStatusStr gives the state of SUOTA session.           
    \param[in] ucIsLink specifies whether a link exists or not.
	  \param[in] ucInstance Incarnation Number.
	  \return IFX_SUCCESS or IFX_FAILURE.
*/
char8* IFX_DECT_SUOTA_GetStatusStr(e_IFX_DECT_SUOTA_States eState)
{
	char8* pszMsgStr = 0;
	switch(eState)
	{
		case IFX_DECT_SUOTA_IDLE:
 			pszMsgStr = "IDLE"; break;	
		case IFX_DECT_SUOTA_INDICATION:
 			pszMsgStr = "INDICATION"; break;	
		case IFX_DECT_SUOTA_WAIT_FOR_URL:
 			pszMsgStr = "WAIT_FOR_URL"; break;	
		case IFX_DECT_SUOTA_INITIATED:
 			pszMsgStr = "INITIATED"; break;	
		case IFX_DECT_SUOTA_IN_PROCESS:
 			pszMsgStr = "IN_PROCESS"; break;				
    default:
			{
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
	              "Unknown State : ", eState);
			 	pszMsgStr = "Unknown State"; break;
			}
	}
	return pszMsgStr;
}

/************************************************************************
* Function Name  : IFX_DECT_SUOTA_AreCallBksRegistered
* Description    : This function register Application notification call backs
* Input Values   : call backs
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
PUBLIC e_IFX_Return
IFX_DECT_SUOTA_AreCallBksRegistered(IN x_IFX_DECT_SUOTA_CallBks *pxSuotaCallBks)
{
  if(pxSuotaCallBks->pfnVerIndication == NULL
     || pxSuotaCallBks->pfnNack == NULL
  ){
    return IFX_FAILURE;
  }
  return IFX_SUCCESS;
}

e_IFX_Return 
IFX_DECT_SUOTA_RegisterCallBks(IN x_IFX_DECT_SUOTA_CallBks *pxCallBks) 
{
	x_IFX_DECT_FTCap xFTCapabilities;
	memset(&xFTCapabilities,0,sizeof(xFTCapabilities));
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Enter Register CallBacks.");
  if(IFX_SUCCESS != IFX_DECT_SUOTA_AreCallBksRegistered(pxCallBks)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	              "All mandatory CallBacks are not registered.");
    return IFX_FAILURE;
  }
  memcpy(&vxSuotaCallBks,pxCallBks,sizeof(x_IFX_DECT_SUOTA_CallBks));
  memset(avxSuotaSess,0,sizeof(avxSuotaSess));
	vxGlobalInfo.xStackCfg.xFTCapabilities.aucExtended2FixedCap[4] |= 0x04;/*SUOTA supported 45th bit set*/
	IFX_DECT_SetFTCap(&vxGlobalInfo.xStackCfg.xFTCapabilities);
  return IFX_SUCCESS;
}

#if 0
/*This is all done to get MCEI but JN confirmed that it is not needed from TK Sending side*/

/*! \brief The Api IFX_DECT_DPSU_ReleaseInstance helps to free instance number procured 
           during any of event notification events.
    \param[in] ucIsLink specifies whether a link exists or not.
	  \param[in] ucInstance Incarnation Number.
	  \return IFX_SUCCESS or IFX_FAILURE.
*/
	
e_IFX_Return 
IFX_DECT_DPSU_ReleaseInstance(IN uchar8 ucIsLink,
                              IN uchar8 ucInstance,
										          IN uchar8 ucHandsetId){

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                 "Entry.");				
    
  if(IFX_DECT_DPSU_LINK_PRESENT == ucIsLink){
                        
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Link exists.");
  }else{
     
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
        "No link present.");
    IFX_DECT_FreeMCEI(ucHandsetId,ucInstance);

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                 "Freed Instance Number.");
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	              "Successful.");				  
  return IFX_SUCCESS;				  
}

#endif

/*! \brief The Api IFX_DECT_SUOTA_EncodeNACK sends the NACK command 
           using Facility message.
    \param[in] ucHandsetId Handset Identifier.
    \param[in] ucReason reason code
    \return IFX_SUCCESS or IFX_FAILURE. 
*/
e_IFX_Return 
IFX_DECT_SUOTA_EncodeNACK(IN uchar8 ucHandsetId, IN uchar8 ucReason){ 
  char8 ucInstance=0;
  uint32 uiIEHdl=0;
  x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
  x_IFX_DECT_IPC_Msg xIpcReply = {0};
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  
  xIWUToIWUInfo.ucDefault1 = 1; /* Dont care */
  xIWUToIWUInfo.ucSR = 1;/* Stats/Rej */
  xIWUToIWUInfo.ucPD = 0x06;//Protocol Discriminator for SUOTA
  xIWUToIWUInfo.ucIWUToIWULen = 0;

  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Encode IWU Info");
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = 0x03|0x80;//SUOTA NACK Command	  
  xIWUToIWUInfo.ucIWUToIWULen++;
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = ucReason;//NACK Reason	  
  xIWUToIWUInfo.ucIWUToIWULen++;
  if((uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcReply.acData))!=IFX_FAILURE){
	if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUTOIWU,(void *)&xIWUToIWUInfo) 
	         != IFX_SUCCESS){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IE add failed");
	  return IFX_FAILURE;
	}
  }
  else{
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Create NEW IE failed");
	return IFX_FAILURE;
  }
  IFX_DECT_EncodeFacility(ucHandsetId,ucInstance,&xIpcReply);
  sleep(2);
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
  memset(&xIpcReply,0,sizeof(xIpcReply));
  memset(&xIWUToIWUInfo,0,sizeof(xIWUToIWUInfo));
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Exit.");	
  return IFX_SUCCESS;
}

/*! \brief The Api IFX_DECT_SUOTA_EncodeVersionAvailable sends the Version Available command 
           using Facility message.
    \param[in] ucHandsetId Handset Identifier.
    \param[in] x_IFX_DECT_SUOTA_VersionAvailableInfo structure
    \return IFX_SUCCESS or IFX_FAILURE. 
*/
e_IFX_Return 
IFX_DECT_SUOTA_EncodeVersionAvailable(IN uchar8 ucHandsetId, 
                    IN x_IFX_DECT_SUOTA_VersionAvailableInfo *pxVerAvailInfo){ 
  char8 ucInstance=0;
  uint32 uiIEHdl=0;  
  uint16 unCount=0;
  uint16 unDatalen=0;
  uchar8 ucSwLen=0;
  x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
  x_IFX_DECT_IPC_Msg xIpcReply = {0};
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");  
  
  if(pxVerAvailInfo == NULL){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
	         "Pointer to VersionAvailable  is NULL");
    return IFX_FAILURE;
  }
  ucSwLen = strlen(pxVerAvailInfo->acNewSwIdentifier);
  if(pxVerAvailInfo->acUrl[0] != '\0') {
    unDatalen = strlen(pxVerAvailInfo->acUrl);
    unCount = ((unDatalen % IFX_DECT_DPSU_MAX_DATA_PER_PKT)==0)?(unDatalen/IFX_DECT_DPSU_MAX_DATA_PER_PKT):
																														 (unDatalen/IFX_DECT_DPSU_MAX_DATA_PER_PKT)+1;
  }
  xIWUToIWUInfo.ucDefault1 = 1; /* Dont care */
  xIWUToIWUInfo.ucSR = 1;/* Stats/Rej */
  xIWUToIWUInfo.ucPD = 0x06;//Protocol Discriminator for SUOTA
  xIWUToIWUInfo.ucIWUToIWULen = 0;
 
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Encode IWU Info");
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = IFX_DECT_SUOTA_CMD_VERSION_AVAILABLE | 0x80;//SUOTA Version Available Command	  
  xIWUToIWUInfo.ucIWUToIWULen++;

//  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = (char8)((pxVerAvailInfo->unDelayMin)&(0xFF00));//delay min high byte	  
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = (char8)((pxVerAvailInfo->unDelayMin>>8)&(0xFF));//delay min high byte	  
  xIWUToIWUInfo.ucIWUToIWULen++;
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = (char8)((pxVerAvailInfo->unDelayMin)&(0x00FF));//delay min low byte	  
  xIWUToIWUInfo.ucIWUToIWULen++;
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = unCount;	//Url to follow  
  xIWUToIWUInfo.ucIWUToIWULen++;
 
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = (char8)(pxVerAvailInfo->user_interaction<<4|0x80);	//0x00|0x80;//User interaction	  
  xIWUToIWUInfo.ucIWUToIWULen++;
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = 0x01;//S/w Version Identifier	  
  xIWUToIWUInfo.ucIWUToIWULen++;
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = ucSwLen; //pxVerAvailInfo->ucSwLen;//Sw Version Identifier Length	  
  xIWUToIWUInfo.ucIWUToIWULen++;
  memcpy(&xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen],pxVerAvailInfo->acNewSwIdentifier,ucSwLen);
  xIWUToIWUInfo.ucIWUToIWULen += ucSwLen;//IWUTOIWU Length		   
#if 0	//don't want it..Spec does not say about this
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = (char8)((pxVerAvailInfo->uiSwTotalSize) >> 24);//SW Total size high byte	  
  xIWUToIWUInfo.ucIWUToIWULen++;
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = (char8)(((pxVerAvailInfo->uiSwTotalSize)&(0x00FF0000)) >> 16);	  
  xIWUToIWUInfo.ucIWUToIWULen++;
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = (char8)(((pxVerAvailInfo->uiSwTotalSize)&(0x0000FF00)) >> 8) ;	  
  xIWUToIWUInfo.ucIWUToIWULen++;
  xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = (char8)((pxVerAvailInfo->uiSwTotalSize)&(0x000000FF));//SW Total size low byte	  
  xIWUToIWUInfo.ucIWUToIWULen++;
#endif
  printf("IWUTOIWU length %d\n",xIWUToIWUInfo.ucIWUToIWULen);
  if((uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcReply.acData))!=IFX_FAILURE){
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUTOIWU,(void *)&xIWUToIWUInfo) 
	         != IFX_SUCCESS){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IE add failed");
	    return IFX_FAILURE;
	  }
  }
  else{
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Create NEW IE failed");
	  return IFX_FAILURE;
  }
  IFX_DECT_EncodeFacility(ucHandsetId,ucInstance,&xIpcReply);
  //IFX_DECT_DPSU_DumpData(20, xIWUToIWUInfo.acIWUToIWU);
  sleep(2);
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
  memset(&xIpcReply,0,sizeof(xIpcReply));
  memset(&xIWUToIWUInfo,0,sizeof(xIWUToIWUInfo));
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Exit.");	
  return IFX_SUCCESS;
}

/*! \brief The Api IFX_DECT_SUOTA_EncodeUrl sends the URL Indication command using Facility message.
    \param[in] ucHandsetId Handset Identifier.
    \param[in] x_IFX_DECT_SUOTA_VersionAvailableInfo structure
    \return IFX_SUCCESS or IFX_FAILURE. 
*/
e_IFX_Return 
IFX_DECT_SUOTA_EncodeUrl(IN uchar8 ucHandsetId, 
               IN x_IFX_DECT_SUOTA_VersionAvailableInfo *pxVerAvailInfo){ 
  char8 ucInstance=0,*pcUrl=NULL;
  uint32 uiIEHdl=0;
  uint16 unDataLen=0,unTemp=0;
  x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
  x_IFX_DECT_IPC_Msg xIpcReply = {0};
  uint16 unCount=0;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  
  if(pxVerAvailInfo == NULL){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Pointer to VersionAvailable  is NULL");
    return IFX_FAILURE;
  }
  pcUrl=pxVerAvailInfo->acUrl;
  unDataLen = strlen(pxVerAvailInfo->acUrl);
  unCount = ((unDataLen % (IFX_DECT_DPSU_MAX_DATA_PER_PKT-1))==0)?(unDataLen/(IFX_DECT_DPSU_MAX_DATA_PER_PKT-1)):
																														 (unDataLen/(IFX_DECT_DPSU_MAX_DATA_PER_PKT-1))+1;
  
  xIWUToIWUInfo.ucDefault1 = 1; /* Dont care */
  xIWUToIWUInfo.ucSR = 1;/* Stats/Rej */
  xIWUToIWUInfo.ucPD = 0x06;//Protocol Discriminator For SUOTA
  xIWUToIWUInfo.ucIWUToIWULen = 0;

  /*  
  if(IFX_DECT_MU_IsCallExisting(ucHandSetId,&ucInstance) != IFX_SUCCESS){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Link Exists");
    return IFX_FAILURE;
  }*/

  while(unDataLen > 0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Inside encode IWU Info");
    xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = 0x02|0x80;//Command For Url Indication	  
    xIWUToIWUInfo.ucIWUToIWULen++;
    xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = (--unCount);//Url to follow	  
    xIWUToIWUInfo.ucIWUToIWULen++;
    unTemp = (unDataLen > (IFX_DECT_DPSU_MAX_DATA_PER_PKT-1))?(IFX_DECT_DPSU_MAX_DATA_PER_PKT-1):unDataLen;
    xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen] = unTemp;//Length of Url in this IE	  
    xIWUToIWUInfo.ucIWUToIWULen++;
    unDataLen -= unTemp;
    memcpy(&xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen],pcUrl,unTemp);
	pcUrl +=unTemp;
	xIWUToIWUInfo.ucIWUToIWULen += unTemp;		 //IWUTOIWU Length  
  	if((uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcReply.acData))!=IFX_FAILURE){
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUTOIWU,(void *)&xIWUToIWUInfo) 
	         != IFX_SUCCESS){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IE add failed");
		return IFX_FAILURE;
	  }
	}
	else{
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Create NEW IE failed");
	  return IFX_FAILURE;
	}
    IFX_DECT_EncodeFacility(ucHandsetId,ucInstance,&xIpcReply);
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
	memset(&xIpcReply,0,sizeof(xIpcReply));
	memset(xIWUToIWUInfo.acIWUToIWU,0,sizeof(xIWUToIWUInfo.acIWUToIWU));
    xIWUToIWUInfo.ucIWUToIWULen = 0;
  }
  memset(&xIWUToIWUInfo,0,sizeof(xIWUToIWUInfo));
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Exit.");	
  return IFX_SUCCESS;
}

/*! \brief The Api IFX_DECT_USU_SUOTA_VersionAvailable sends the Version available info followed by the URL's.
    \param[in] ucHandsetId Handset Identifier.
    \param[in] x_IFX_DECT_SUOTA_VersionAvailableInfo structure
    \return IFX_SUCCESS or IFX_FAILURE. 
*/
e_IFX_Return 
IFX_DECT_SUOTA_VersionAvailable(IN uchar8 ucHandsetId,
                        IN x_IFX_DECT_SUOTA_VersionAvailableInfo *pxVerAvailInfo)
{ 
  //char8 ucInstance = 0;
  //uchar8 ucIsLink = IFX_DECT_DPSU_NO_LINK_PRESENT;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Entry.");	
#ifdef ULE_SUPPORT   
	 if((ucHandsetId < 1)||(ucHandsetId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1)){
  
	   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		   "Invalid HandsetId");
	   return IFX_FAILURE;
	 }
#else
	  if((ucHandsetId < 1)||(ucHandsetId > IFX_DECT_MAX_HS)){

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Invalid HandsetId");
    return IFX_FAILURE;
  }

#endif

#if 0
/*This is all done to get MCEI but JN confirmed that it is not needed from TK Sending side*/
  if((ucHandsetId > 0 ) && (ucHandsetId <= IFX_DECT_MAX_HS))
  {

  if(!IFX_DECT_MU_IsCAT2(ucHandsetId)){
     
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Handset is not Catiq 2.0 compatible.");
    return IFX_FAILURE;
  }

  if(IFX_DECT_MU_IsCallExisting(ucHandsetId,((uchar8 *)&ucInstance)) == IFX_SUCCESS){

    ucIsLink = IFX_DECT_DPSU_LINK_PRESENT;
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		       "Call already existing.");
  }else{

	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			  "Call doesn't exist,no link present.");
         
	  if(IFX_FAILURE == (ucInstance = IFX_DECT_GetMCEI(ucHandsetId))){
       
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				         "GetMCEI failed.");
	    return IFX_FAILURE;
	  }
  }												
  }
#endif

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_ATA_STRING_INFO,
        "New SwIdentifier", pxVerAvailInfo->acNewSwIdentifier);
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
        "DelayMin", pxVerAvailInfo->unDelayMin);
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
        "Sw Totalsize", pxVerAvailInfo->uiSwTotalSize);
  /*printf("NewSw: %s delayMin: %d SwTotalSize: %d\n",
             pxVerAvailInfo->acNewSwIdentifier,
             pxVerAvailInfo->unDelayMin,
             pxVerAvailInfo->uiSwTotalSize);*/	
  if(pxVerAvailInfo->acUrl[0] != '\0')
    //printf("Url: %s\n", pxVerAvailInfo->acUrl);
    IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_ATA_STRING_INFO,
           "URL", pxVerAvailInfo->acUrl);

  if(IFX_FAILURE == 
    IFX_DECT_SUOTA_EncodeVersionAvailable(ucHandsetId,pxVerAvailInfo)){

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             " IFX_DECT_SUOTA_EncodeVersionAvailable Failed.");
    return IFX_FAILURE;
  }
  if(pxVerAvailInfo->uiSwTotalSize) {
    if(IFX_FAILURE == 
      IFX_DECT_SUOTA_EncodeUrl(ucHandsetId,pxVerAvailInfo)){

      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               " IFX_DECT_SUOTA_EncodeUrl Failed.");
      return IFX_FAILURE;
    }
  } else {
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
               "No URL.");
  }
  avxSuotaSess[ucHandsetId-1].eState = IFX_DECT_SUOTA_IN_PROCESS;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_ATA_STRING_INFO,
        "State changed to =", 
              IFX_DECT_SUOTA_GetStatusStr(avxSuotaSess[ucHandsetId-1].eState));
  #if 0  
  /*This is all done to get MCEI but JN confirmed that it is not needed from TK Sending side*/
  IFX_DECT_DPSU_ReleaseInstance(ucIsLink,ucInstance,ucHandsetId);
  #endif
  
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	      		 "Exit.");
  return IFX_SUCCESS;

}

/*! \brief The Api IFX_DECT_SUOTA_SendNACK sends the NACK for SUOTA.
    \param[in] ucHandsetId Handset Identifier.
    \param[in] ucReason Reason code
    \return IFX_SUCCESS or IFX_FAILURE. 
*/
e_IFX_Return IFX_DECT_SUOTA_SendNACK(IN uchar8 ucHandsetId,
                              IN e_IFX_DECT_SUOTA_NACKReason eNack){

 
   //char8 ucInstance = 0;
   //uchar8 ucIsLink = IFX_DECT_USU_NO_LINK_PRESENT;

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Entry.");	
  
#ifdef ULE_SUPPORT   
   if((ucHandsetId < 1)||(ucHandsetId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1)){

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Invalid HandsetId");
     return IFX_FAILURE;
   }
#else
	if((ucHandsetId < 1)||(ucHandsetId > IFX_DECT_MAX_HS)){

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         "Invalid HandsetId");
     return IFX_FAILURE;
   }

#endif
#if 0
   /*This is all done to get MCEI but JN confirmed that it is not needed from TK Sending side*/

   if(!IFX_DECT_MU_IsCAT2(ucHandsetId)){
     
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         " Handset is not Catiq 2.0 compatible.");
     return IFX_FAILURE;
   }

   if(IFX_DECT_MU_IsCallExisting(ucHandsetId,((uchar8 *)&ucInstance)) == IFX_SUCCESS){

      ucIsLink = IFX_DECT_USU_LINK_PRESENT;
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		       "Call already existing.");
   }else{

	    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			  "Call doesn't exist,no link present.");
         
	    if(IFX_FAILURE == (ucInstance = IFX_DECT_GetMCEI(ucHandsetId))){
       
		    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				         "GetMCEI failed.");
		    return IFX_FAILURE;
	    }
    }												
   #endif
	
   if(IFX_FAILURE == 
     IFX_DECT_SUOTA_EncodeNACK(ucHandsetId,eNack)){

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
             "API EncodeVersion Available Failed.");
     return IFX_FAILURE;
   }    
   /*This is all done to get MCEI but JN confirmed that it is not needed from TK Sending side*/
   //IFX_DECT_USU_ReleaseInstance(ucIsLink,ucInstance,ucHandsetId);
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	      		 " Exit.");
	 return IFX_SUCCESS;

}
#endif
/*=========================================================*/

/*! \brief API to accept data call initiated by PP.
    \param[in] uiCallHdl is connection handle.
    \param[in] uiIEHdl is Information Element handle.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_CallAccept(IN uint32 uiCallHdl,
                                      IN uint32 uiIEHdl){
  

   #if 1 // #ifdef CONFIG_UPDATE_SUOTA
   uint32 uiIEHandle=0;
   #endif
   x_IFX_DECT_DPSU_ConnectionInfo *pxConn=NULL;
   #if 1 // #ifdef CONFIG_UPDATE_SUOTA
   x_IFX_DECT_IE_IWUAttributes xIWUAttributesInfo={0};
   #endif
   x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                       " <API CallAccept>Entry,invoked by FT Application.");

   if(0 == uiCallHdl){
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              " <API CallAccept>Failed.Invalid uiCallHdl.");

     return IFX_FAILURE;
   }  

   pxConn = (x_IFX_DECT_DPSU_ConnectionInfo*)uiCallHdl;
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
              " pxConn= ",pxConn);

   if(/*(pxConn->ucHandset == 0)||(pxConn->ucHandset > 6)||*/
      (pxConn->eState != IFX_DECT_DPSU_PENDING)){

     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
              " Failed!!!state not PENDING= ",pxConn->eState);
     return IFX_FAILURE;
   }else{  
    
     IFX_DECT_EncodeConnect(pxConn->ucHandset,pxConn->ucInstance,IFX_DECT_DPSU_NARROWBAND_CALL,&xIpcMsg);
	 /*codec info not needed since SUOTA*/
	 xIpcMsg.ucPara3=0xFF;

      #if 1 // #ifdef CONFIG_UPDATE_SUOTA
      if(vxIWUAttributesInfo[pxConn->ucHandset - 1].ucCodeStd == IFX_DECT_DPSU_PROFILE_DEFINED_CODING &&
         vxIWUAttributesInfo[pxConn->ucHandset - 1].ucProfileOrITC == IFX_DECT_DPSU_DPRS &&
         vxIWUAttributesInfo[pxConn->ucHandset - 1].uxDectOrProf.xProfileSS.ucPST == IFX_DECT_DPSU_DGMEP_PROFILE_SUBTYPE &&
         vxIWUAttributesInfo[pxConn->ucHandset - 1].uxDectOrProf.xProfileSS.ucDefault3 == 1){
         memcpy(&xIWUAttributesInfo, &vxIWUAttributesInfo[pxConn->ucHandset - 1], sizeof(x_IFX_DECT_IE_IWUAttributes));
         xIWUAttributesInfo.uxDectOrProf.xProfileSS.ucPSAa = 0x01; // seq = 0, GMCI = 1
      
         if((uiIEHandle = IFX_DECT_IE_NewIECreate(xIpcMsg.acData))!=IFX_FAILURE){
            if(IFX_DECT_IE_IEAdd(uiIEHandle,IFX_DECT_IE_IWUATTRIBUTES,(void *)&xIWUAttributesInfo)
               != IFX_SUCCESS){
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IE add failed");
               return IFX_FAILURE;
            }
         }
         else{
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Create NEW IE failed");
            return IFX_FAILURE;
         }
      }
      #endif

	 /*codec info not needed since SUOTA*/
#if 0
     if(uiIEHdl != 0){
	   
	   uiDIEHdl = IFX_DECT_IE_GetIEHandler(&xIpcMsg);
	   if(IFX_DECT_IE_IEAppend(uiDIEHdl,uiIEHdl) == IFX_FAILURE){
		
		  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		           " <API CallAccept>IFX_DECT_IE_IEAppend failed.");

		  return IFX_FAILURE;
	   }
	 }
#endif
     if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg) == IFX_SUCCESS){
		          
		IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
				 " <API CallAccept>FP_CC_CONNECT_RQ Message Encoded and Posted Successfully to Stack.");
		pxConn->eState = IFX_DECT_DPSU_CONNECTED;

		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
				 " <API CallAccept>Encode DataEnable.");

        IFX_DECT_EncodeEnableData(pxConn->ucInstance,pxConn->ucHandset,&xIpcMsg);
	        
	    if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg) == IFX_SUCCESS){
		
		
		   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			    " FP_MAC_ENABLE_DATA_RQ Message Encoded and Posted \nSuccessfully to Stack.State changed to CONNECTED."); 

		   return IFX_SUCCESS;
		}else{

          IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       " FP_MAC_ENABLE_DATA_RQ Message not Posted to Stack.");

		  return IFX_FAILURE;				

		 }

	 }else{

       pxConn->eState = IFX_DECT_DPSU_PENDING;
	   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			    " <API CallAccept>Api Unsuccessful.FP_CC_CONNECT_RQ Message not Posted to Stack.");

	 }
    }    
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                   " <API CallAccept>Unsuccessful.");
    return IFX_FAILURE;
} 


/*! \brief API to send data to DECT stack.
    \param[in] uiCallHdl is Connection handle.
    \param[in] pcData contains data buffer to be transmitted
    \param[in] iLen is length of the buffer.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

#ifndef LTQ_RAW_DPSU
e_IFX_Return IFX_DECT_DPSU_DataSendToDECT(IN uint32 uiCallHdl, 
                                          IN char8 *pcData, 
                                          IN int32 iLen,
                                          IN int32 iAppDataLen)
#else
e_IFX_Return IFX_DECT_DPSU_DataSendToDECT(IN uint32 uiCallHdl, 
                                          IN char8 *pcData, 
                                          IN int32 iLen)
#endif
{
  
   x_IFX_DECT_DPSU_ConnectionInfo *pxConn=NULL;
  
#ifdef DPSU_TIMESTAMP
   printf("DataSendToDect\t");
   IFX_DECT_DPSU_GetTimeStamp(); 
#endif
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            " <API SendDataToDECT>Entry,invoked by FT Application.");
 
   if((0 == uiCallHdl)||(NULL == pcData)){
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              " <API SendDataToDECT>Failed.Invalid uiCallHdl or pcData is NULL.");

     return IFX_FAILURE;
   }
  
   pxConn = (x_IFX_DECT_DPSU_ConnectionInfo*)uiCallHdl;

   if(/*(pxConn->ucHandset == 0)||(pxConn->ucHandset > 6)||*/
      (pxConn->eState != IFX_DECT_DPSU_ACTIVE)){

     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              " <API SendDataToDECT>Failed.ucHandset invalid or state not ACTIVE.");
     return IFX_FAILURE;
   }else{
             
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
              " <API SendDataToDECT>Calling FrameOutgoingPkts.");

   if(pxConn->uiRXbyte+iLen > IFX_DECT_DPSU_MAX_WINDOWSIZE){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
              " <API SendDataToDECT> Max window size supported is 2K.");
     return IFX_FAILURE;
    }
 
	 memcpy(pxConn->acBuff + pxConn->uiRXbyte,pcData,iLen);
     pxConn->uiRXbyte += iLen;
#ifdef LTQ_RAW_DPSU
    if(pxConn->uiTXbyte == 0)
#else
		 pxConn->uiMaxSDUSize= iAppDataLen;
    if(pxConn->uiRXbyte >= iAppDataLen)
#endif
		{   
        if(IFX_DECT_DPSU_GetBuffer(pxConn->ucInstance,pxConn->ucHandset,(uint32)pxConn) == IFX_SUCCESS){
             IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                   " <API SendDataToDECT>First data buffer From Server.Buffer Sent to PT.");
             return IFX_SUCCESS;
         }
     }
	 IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	             " <API SendDataToDECT>Successful.");
				 
     return IFX_SUCCESS;
    } 

}   

/*! \brief API to close data call.
	\param[in] uiCallHdl is connection handle.
    \param[in] uiIEHdl is connection handle.
    \param[in] eReason Reason for failure.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_CallRelease(IN uint32 uiCallHdl,
									   IN uint32 uiIEHdl,
									   IN e_IFX_DECT_RelType eReason){
  
   
   x_IFX_DECT_DPSU_ConnectionInfo *pxConn = NULL;
   x_IFX_DECT_IPC_Msg xIpcMsg = {0};
   uint32 uiDIEHdl = 0;

   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                       " <API CallRelease>Entry,invoked by FT Application.");

   if(0 == uiCallHdl){
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       " <API CallRelease>Failed.Invalid uiCallHdl.");

     return IFX_FAILURE;
   }

   pxConn = (x_IFX_DECT_DPSU_ConnectionInfo*)uiCallHdl;


#ifdef ULE_SUPPORT
if((pxConn->ucHandset == 0)||(pxConn->ucHandset > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1)||
   (pxConn->eState == IFX_DECT_DPSU_IDLE))

#else
   if(/*(pxConn->ucHandset == 0)||(pxConn->ucHandset > 6)||*/
      (pxConn->eState == IFX_DECT_DPSU_IDLE))
#endif
      {

     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "<API CallRelease>Failed.ucHandset invalid or state is IDLE.");
     return IFX_FAILURE;
   }else{
   #if 0
   /*Can parallel call happen??*/
     if(IFX_DECT_MU_CanCallBeReleased(pxConn->ucHandset) == IFX_SUCCESS)
   #endif
	 {
   
       switch(pxConn->eState){
         
         case IFX_DECT_DPSU_PENDING:
             
             IFX_DECT_EncodeReject(pxConn->ucHandset,pxConn->ucInstance,eReason,&xIpcMsg);

             break;

         case IFX_DECT_DPSU_CONNECTED:
         case IFX_DECT_DPSU_ACTIVE:
             

			 IFX_DECT_EncodeRelease(pxConn->ucHandset,pxConn->ucInstance,eReason,&xIpcMsg);

             break;
   
         default : IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       " <API DataCallClose>Failed.Invalid State.");
                   return IFX_FAILURE;
       }
       if(uiIEHdl != 0){

	     uiDIEHdl = IFX_DECT_IE_GetIEHandler(&xIpcMsg);
		 if(IFX_DECT_IE_IEAppend(uiDIEHdl,uiIEHdl) == IFX_FAILURE){
		 
            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				     " <API CallRelease(Reason:CLOSE)>IFX_DECT_IE_IEAppend failed.");

		    return IFX_FAILURE;
		 }
	   }
																							
       if(IFX_SUCCESS == IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg)){
        if(IFX_OS_LockAcquire(vxGlobalInfo.xDPSApiLock) == IFX_SUCCESS){

         IFX_DECT_DPSU_ReleaseConnectionResources((uint32)pxConn);
         //IFX_DECT_MU_SetModuleOwner(pxConn->ucHandset,IFX_DECT_MU_REMOVE_OWNER,IFX_DECT_DPSU_ID);
        }else{
          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "<API CallRelease>Failed to Acquire Lock.");
         }
        if(IFX_OS_LockRelease(vxGlobalInfo.xDPSApiLock) != IFX_SUCCESS){
          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "<API CallRelease>Failed to Release Lock.");
        }
 
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 " <API CallRelease>Successful.FP_CC_RELEASE_RQ Message Encoded and Posted Successfully to Stack.");

         return IFX_SUCCESS;
       }
     }
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              " <API CallRelease>Unsuccessful.FP_CC_RELEASE_RQ Message not Posted to Stack.");

     return IFX_FAILURE;
    }   
}

/*! \brief Internal API to send data buffer to PT when flow in message arrives.
    \param[in] ucInstance Instance Number.
	\param[in] ucHandset Handset Number.
	\param[in] uiCallHdl is connection handle.
    \return IFX_SUCCESS or IFX_FAILURE.
*/
				
e_IFX_Return IFX_DECT_DPSU_GetBuffer(IN uchar8 ucInstance,
                                     IN uchar8 ucHandset,
                                     IN uint32 uiCallHdl){

  x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};
  x_IFX_DECT_DPSU_ConnectionInfo *pxConn = NULL;
  int32 iLen = 0;
  
  pxConn = (x_IFX_DECT_DPSU_ConnectionInfo*)uiCallHdl;
#ifndef LTQ_RAW_DPSU  
  pxConn->xDgmep.ucIsChop =1;  
#endif
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                    " <API GetBuffer>Entry.");
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
              "Instance",ucInstance);
  if(pxConn->uiTXbyte < pxConn->uiRXbyte){
    if((pxConn->uiRXbyte - pxConn->uiTXbyte)<= IFX_DECT_DPSU_MAX_BUFFERSIZE){
      
      iLen = pxConn->uiRXbyte -pxConn->uiTXbyte;
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API GetBuffer>Last Data Buffer.");
    }else{
      
      iLen = IFX_DECT_DPSU_MAX_BUFFERSIZE;
    }
#ifndef LTQ_RAW_DPSU  
	  if(pxConn->xDgmep.ucIsChop == 1)
    {/* Chopping is enabled then sequencing is must*/
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " Chopping is enabled.");
	    if(iLen <= IFX_DECT_DPSU_MAX_BUFFERSIZE-2)
	    {
	      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API GetBuffer>Last SDU.");	 
	      ucLastSdu = 1;
	    }
			ucLastSdu=1;
	    /* Bit 8 : 0 if next octet follows, 1 if no next octet */
			if(pxConn->uiTXbyte == 0)
			{
	    	xUPlaneIpcMsg.acData[0] = pxConn->xDgmep.ucGMCI;	
      /* Bit 8 : 0 if Last segment, 1 if next segment */	  
	    xUPlaneIpcMsg.acData[1] = (ucLastSdu)?
             (++pxConn->ucSSN):(((IFX_DECT_DPSU_DGMEP_MORE_BIT) | (++pxConn->ucSSN)));
        memcpy(&xUPlaneIpcMsg.acData[2],pxConn->acBuff+pxConn->uiTXbyte,iLen-2);
	      pxConn->uiTXbyte += iLen-2;
	      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API GetBuffer>First part of SDU");	

			}
			else
			{
	      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API GetBuffer>Next part of SDU");	
        memcpy(&xUPlaneIpcMsg.acData[0],pxConn->acBuff+pxConn->uiTXbyte,iLen);
	      pxConn->uiTXbyte += iLen;
			}
#ifdef MURALI1234
	    if(ucLastSdu)
	    {
        memcpy(&xUPlaneIpcMsg.acData[2],pxConn->acBuff+pxConn->uiTXbyte,iLen);
	      pxConn->uiTXbyte += iLen;
        iLen += 2;
	    }  
      else {
        memcpy(&xUPlaneIpcMsg.acData[2],pxConn->acBuff+pxConn->uiTXbyte,iLen-2);
	      pxConn->uiTXbyte += iLen-2;
      }
#endif
    }
    else if((pxConn->xDgmep.ucIsChop == 0) && (pxConn->xDgmep.ucIsSeq == 1))
    {/* Chopping is enabled then sequencing is must*/
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " Chopping is not enabled but sequencing is enabled.");
	    xUPlaneIpcMsg.acData[0] = pxConn->xDgmep.ucGMCI;	
      memcpy(&xUPlaneIpcMsg.acData[1],pxConn->acBuff+pxConn->uiTXbyte,iLen-1);
	    pxConn->uiTXbyte += iLen-1;
    }
    else
    {/* Chopping is not enabled */
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    " Chopping/Sequencing are not enabled.");
	    if(iLen <= IFX_DECT_DPSU_MAX_BUFFERSIZE-1)
	    {
	      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API GetBuffer>Last SDU.");	
	      ucLastSdu = 1;
	    }
	    if(pxConn->acBuff+pxConn->uiTXbyte == 0)
	    {
	    	xUPlaneIpcMsg.acData[0] = IFX_DECT_DPSU_IS_SEQ_OCTET | pxConn->xDgmep.ucGMCI;	
      		memcpy(&xUPlaneIpcMsg.acData[1],pxConn->acBuff+pxConn->uiTXbyte,iLen-1);
	    	pxConn->uiTXbyte += iLen-1;
	    }
	    else
	    {
      		memcpy(&xUPlaneIpcMsg.acData[0],pxConn->acBuff+pxConn->uiTXbyte,iLen);
	    	pxConn->uiTXbyte += iLen;
	    }
    }  
	  if(ucLastSdu == 1)
    {
      /*Reset the SSN counter.  */
	    pxConn->ucSSN = 0;
      ucLastSdu = 0;
#ifdef DPSU_TEST
      iFlowcnt[pxConn->ucHandset] = 0;
      ucNextGet = 1;
#endif
    }
#if 0
{
  int32 i;
  printf("DATA for handset %d\n",ucHandset);
  printf("Data0:%x data1:%x\n",xUPlaneIpcMsg.acData[0],xUPlaneIpcMsg.acData[1]);
  for(i=0;i<iLen;i++){
	  printf("%c",xUPlaneIpcMsg.acData[i]);
	  if( i%20 == 0){
	    printf("\n");
	  }
  }
  printf("\n");
}
#endif
#endif
 
  }
else if((pxConn->uiTXbyte == pxConn->uiRXbyte)){
   
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API GetBuffer>No more Data Buffers to be sent.");
#ifdef LTQ_RAW_DPSU
    pxConn->uiTXbyte = 0;
    pxConn->uiRXbyte = 0;
#endif 
    return IFX_SUCCESS;
   }
else{
    
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API GetBuffer>Error TXbyte>RXbyte."); 
     return IFX_FAILURE;
    }
 
  
#ifdef LTQ_RAW_DPSU  
  memcpy(&xUPlaneIpcMsg.acData,pxConn->acBuff+pxConn->uiTXbyte,iLen);
  pxConn->uiTXbyte += iLen;
#endif

  IFX_DECT_EncodeDataToStack(iLen,pxConn->ucInstance,&xUPlaneIpcMsg);
#ifndef LTQ_RAW_DPSU
	if(pxConn->uiTXbyte >= pxConn->uiMaxSDUSize)
  {
			xUPlaneIpcMsg.ucPara3=1;


			pxConn->uiTotalTXbyte+=pxConn->uiTXbyte;
			pxConn->uiTotalRXbyte+=pxConn->uiRXbyte;
//tmp_iprintf_onoff(1);
//iprintf("Middle TX %d RX %d Total Tx %d Rx %d\n",pxConn->uiTXbyte,pxConn->uiRXbyte,pxConn->uiTotalTXbyte,pxConn->uiTotalRXbyte);
//tmp_iprintf_onoff(0);
    	pxConn->uiTXbyte =0;
    	pxConn->uiRXbyte =0;
  }
#endif
  if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) == IFX_SUCCESS){
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                " <API GetBuffer>Successful.FP_MEDIA_SDU_SND_RQ  Message Encoded and Posted Successfully to Stack.");
    return IFX_SUCCESS;
  }else{
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               " <API GetBuffer>Unsuccessful.FP_MEDIA_SDU_SND_RQ  Message not Posted to Stack.");
   }
    
  return IFX_SUCCESS;

}

              
/*! \brief IFX_DECT_DPSU_SendReleaseMsgToStacks is an internal function.If the routing of incoming
     msg fails it sends back close connection to DECT stack.
    \param[in] pxIpcMsg pointer to C Plane IPC Message.
    \return IFX_SUCCESS or IFX_FAILURE. 
*/

e_IFX_Return IFX_DECT_DPSU_SendReleaseMsgToStack(IN x_IFX_DECT_IPC_Msg* pxIpcMsg,IN e_IFX_DECT_RelType eReason){
     
   x_IFX_DECT_IPC_Msg xIpcMsg = {0};
     
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            " <API SendReleaseMsgToStack>Entry.");
   IFX_DECT_EncodeRelease(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,eReason,&xIpcMsg);  
   if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg) == IFX_FAILURE){
     
	 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	             " <API SendReleaseMsgToStack>Failure.");
				 
     return IFX_FAILURE;
   }

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	                  " <API SendReleaseMsgToStack>Success.");
					  
   return IFX_SUCCESS;	
}


/*! \brief IFX_DECT_DPSU_GetProtocolID is an internal function used to extract Protocol Identifier
     from incoming IPC Message.
    \param[in] puiIEHdl Information Element Handler.
    \param[out] pucProtocolID Protocol Identifier.
    \return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_DPSU_GetProtocolID(IN uint32 *puiIEHdl,
                                         OUT uchar8 *pucProtocolID){

   x_IFX_DECT_IE_IWUAttributes xIWUAttributesInfo = {0};

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " <API GetProtocolID>Entry.");
			   
   if((NULL == puiIEHdl) || (NULL == pucProtocolID)){
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	                " <API GetProtocolID>puiIEHdl = NULL or pucProtocolID = NULL.");
     return IFX_FAILURE;
   } 
   
   while(IFX_DECT_IE_TypeGet(*puiIEHdl) != IFX_DECT_IE_IWUATTRIBUTES){
      if(IFX_DECT_IE_NextIEHandlerGet(puiIEHdl) == IFX_FAILURE){
	    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		               " <API GetProtocolID>GetNextIEHandler failed.");
        return IFX_FAILURE;
      }
	    
   }
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	                 " <API GetProtocolID>IWU Attributes IE found.");
      if(IFX_DECT_IE_IWUAttributesGet(*puiIEHdl,&xIWUAttributesInfo) == IFX_SUCCESS){
         if(xIWUAttributesInfo.ucCodeStd == IFX_DECT_DPSU_PROFILE_DEFINED_CODING && 
            xIWUAttributesInfo.ucProfileOrITC == IFX_DECT_DPSU_DPRS 
                  && xIWUAttributesInfo.uxDectOrProf.xProfileSS.ucPST == IFX_DECT_DPSU_DGMEP_PROFILE_SUBTYPE){
           *pucProtocolID = xIWUAttributesInfo.uxDectOrProf.xProfileSS.ucPSA;
		   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		                  " <API GetProtocolID>Successful.");
           return IFX_SUCCESS;
         }       
      }
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API GetProtocolID>Failed.");
   return IFX_FAILURE;
}

/*! \brief IFX_DECt_DPSU_ValidateProtoID is an internal function used to validate Protocol Identifier
     as one of those permitted by standards. 
    \param[in] ucProtocolID Protocol Identifier.
    \return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_DPSU_ValidateProtoID(IN uchar8 ucProtocolID){
 
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  " <API ValidateProtoID>Entry.");
   switch(ucProtocolID){
   
     case IFX_DECT_DPSU_HTTP:

         break;

     case IFX_DECT_DPSU_FULL_HTTP: 
								
         break;

     case IFX_DECT_DPSU_SMTP: 
								
         break;

     case IFX_DECT_DPSU_ODAP: 
								
         break;

     case IFX_DECT_DPSU_POP3: 
								
         break;

     case IFX_DECT_DPSU_RTP: 
								
         break;

     case IFX_DECT_DPSU_SIP: 
								
         break;
     
     default:
	         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			          " <API ValidateProtoID>Failed.");
									
	         return IFX_FAILURE;
             break;
   }
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                     " <API ValidateProtoID>Successful.");
   return IFX_SUCCESS;					 
}
#ifndef LTQ_RAW_DPSU
/************************************************************************
* Function Name  : IFX_DECT_DPSU_CheckPD
* Description    : Check if protocol descriminator is of SUOTA
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_DPSU_CheckPD(x_IFX_DECT_IPC_Msg *pxIPCMsg)
{
  uint32 uiIEHdl = 0;
  x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo;
  if(0 == (uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIPCMsg)) ){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
    return IFX_FAILURE;
  }

  while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_IWUTOIWU){
    if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
       return IFX_FAILURE;
    }
  }
  if(IFX_DECT_IE_IWUToIWUGet(uiIEHdl,&xIWUToIWUInfo) != IFX_SUCCESS){
      return IFX_FAILURE;
  }
  if(xIWUToIWUInfo.ucPD == 0x06){
    return IFX_SUCCESS;
  }
  return IFX_FAILURE;

}

/************************************************************************
* Function Name  : IFX_DECT_DPSU_ValidateIWUAttributes
* Description    : This function validates the IWU_ATTRIBUTES IE in setup msg
* Input Values   : pxIPCMsg IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_DPSU_ValidateIWUAttributes(IN x_IFX_DECT_IPC_Msg* pxIPCMsg,
                                  IN x_IFX_DECT_IE_IWUAttributes *pxIWUAttributesInfo)
{
  uint32 uiIEHdl = 0;
  if(pxIPCMsg == NULL){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
    return IFX_FAILURE;
  }
  uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIPCMsg);
  while(uiIEHdl != 0){
    if(IFX_DECT_IE_TypeGet(uiIEHdl) == IFX_DECT_IE_IWUATTRIBUTES){
      IFX_DECT_IE_IWUAttributesGet(uiIEHdl,pxIWUAttributesInfo);
      return IFX_SUCCESS;
    }else if((IFX_DECT_IE_TypeGet(uiIEHdl) == IFX_DECT_IE_NOTIE)||
						(IFX_DECT_IE_TypeGet(uiIEHdl) == IFX_DECT_IE_GENERICIE)){
			return IFX_FAILURE;
		}else{
      IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl);
    }
  }
  return IFX_FAILURE;
}

/************************************************************************
* Function Name  : IFX_DECT_DPSU_SetDefaultIWUAttributes
* Description    : Get GMCI
* Input Values   :  
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_DPSU_SetDefaultIWUAttributes(IN x_IFX_DECT_IE_IWUAttributes *pxIWUAttributesInfo)
{
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_DPSU_SetIWUAttributes
* Description    : Get GMCI
* Input Values   :  
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_DPSU_SetIWUAttributes(IN x_IFX_DECT_IE_IWUAttributes *pxIWUAttributesInfo)
{
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_DPSU_GetGmci
* Description    : Get GMCI
* Input Values   :  
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          : GMCI starts from 1
* *************************************************************************/
e_IFX_Return IFX_DECT_DPSU_GetGmci(uchar8 ucHandsetId, uchar8 *pucGMCI)
{
  uchar8 ucIndex; 
#ifdef ULE_SUPPORT   
 if((ucHandsetId < 1)||(ucHandsetId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1)){

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	   "Invalid HandsetId");
  	return IFX_FAILURE; 
 }
#else
  if((ucHandsetId < 1)||(ucHandsetId > IFX_DECT_MAX_HS)){

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	   "Invalid HandsetId");
   return IFX_FAILURE;
 }
  
#endif


  for(ucIndex =0; ucIndex < IFX_DECT_DPSU_MAX_APPLN; ucIndex++){
    if(!vacGmci[ucHandsetId-1][ucIndex]){
      vacGmci[ucHandsetId-1][ucIndex] =1;
      *pucGMCI = ucIndex + 1;
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE; 
}

/************************************************************************
* Function Name  : IFX_DECT_DPSU_FreeGmci
* Description    : Free GMCI
* Input Values   : GMCI
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_DPSU_FreeGmci(IN uchar8 ucHandsetId,IN uchar8 ucGmci)
{
#ifdef ULE_SUPPORT   
	 if((ucHandsetId < 1)||(ucHandsetId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1)){
  
	   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		   "Invalid HandsetId");
  		return IFX_FAILURE;
	 }
#else
	  if((ucHandsetId < 1)||(ucHandsetId > IFX_DECT_MAX_HS)){

	   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		   "Invalid HandsetId");
	   return IFX_FAILURE;
	 }
	  
#endif


    if(vacGmci[ucHandsetId-1][ucGmci-1]){
      vacGmci[ucHandsetId-1][ucGmci-1] =0;
      return IFX_SUCCESS;
    }
    return IFX_FAILURE;

}

/************************************************************************
* Function Name  : IFX_DECT_DPSU_ValidateBasicService
* Description    : This function validates the BASIC_SERVICE IE in setup msg
* Input Values   : pxIPCMsg IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_DPSU_ValidateBasicService(IN x_IFX_DECT_IPC_Msg* pxIPCMsg,
                                  IN x_IFX_DECT_IE_BasicService* pxBSInfo)
{
  uint32 uiIEHdl = 0;
  if(pxIPCMsg == NULL){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
    return IFX_FAILURE;
  }
  uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIPCMsg);
  while(uiIEHdl != 0){
    if(IFX_DECT_IE_TypeGet(uiIEHdl) == IFX_DECT_IE_BASICSERVICE){
      IFX_DECT_IE_BasicServiceGet(uiIEHdl,pxBSInfo);
      return IFX_SUCCESS;
    }else{
      IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl);
    }
  }
  return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_DPSU_ValidateGMCI
* Description    : This function validates the GMCI of received SDU
* Input Values   : pxIPCMsg IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_DPSU_ValidateGMCI(IN x_IFX_DECT_DPSU_ConnectionInfo *pxConn, 
                          IN x_IFX_DECT_IPC_Msg_u* pxUpMsg)
{
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
           "Assigned GMCI: ",pxConn->xDgmep.ucGMCI);
  if((pxUpMsg->acData[0] & IFX_DECT_DPSU_VALIDATE_GMCI) == pxConn->xDgmep.ucGMCI)
  {
    return IFX_SUCCESS;
  }
  return IFX_FAILURE;
}


/************************************************************************
* Function Name  : IFX_DECT_SUOTA_DecodeCmd
* Description    : Decode the SUOTA command
* Input Values   : Command specific buffer
* Output Values  : Decoded Structure
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_SUOTA_DecodeCmd(IN uchar8 ucHandsetId,
                         IN uchar8 *pucBuff,
                         IN int32 iLen)
{
  uchar8 *pucEnd = NULL;
  uchar8 ucCmd = 0;
  int32 eRet = IFX_SUCCESS;
  x_IFX_DECT_DPSU_SuotaSession *pxSuotaSess = NULL;  
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  if((pucBuff == NULL) || (iLen ==0)){
    eRet = IFX_FAILURE;
    goto Fail;	   
  }

#ifdef ULE_SUPPORT   
 if((ucHandsetId < 1)||(ucHandsetId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1)){

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	   "Invalid HandsetId");
   return IFX_FAILURE;
 }
#else
  if((ucHandsetId < 1)||(ucHandsetId > IFX_DECT_MAX_HS)){

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	   "Invalid HandsetId");
  	return IFX_FAILURE;
 }
	  
#endif

	
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
         "Command Length:",iLen);
  pxSuotaSess = &avxSuotaSess[ucHandsetId-1];
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_ATA_STRING_INFO,
            "State is =", 
              IFX_DECT_SUOTA_GetStatusStr(pxSuotaSess->eState));
  pucEnd = pucBuff + iLen;
  IFX_DECT_SUOTA_DECODE_2BYTECMD(pucBuff,ucCmd);
  switch(ucCmd){
     /* Octet 4 */
     case IFX_DECT_SUOTA_CMD_VERSION_INDICATION:
	   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	           "Command=Handset Version Indication");
	   /* Octet 5 & Octet 6 */
	   pxSuotaSess->xVerInfo.unEMC = ( ((*pucBuff)<<8) | (*(pucBuff+1)) );
	   pucBuff+=2;
	   /* Octet 7 */
	   pxSuotaSess->ucUrl1ToFollow = *pucBuff;
	   pucBuff++;
	   /* Octet 8 */
	   pxSuotaSess->xVerInfo.ucFileNum = ((*pucBuff) & 0x0F);
	   pucBuff++;
	   /* Octet 8a */
	   pxSuotaSess->xVerInfo.eReason = ((*pucBuff) & 0x0F);
	   pxSuotaSess->xVerInfo.user_interaction =0;
	   if((*pucBuff) & 0x10)/*extracing flg which is used for UIS*/
	   {
	   		pxSuotaSess->xVerInfo.user_interaction =1;
	   }
	   if(!((*pucBuff) & 0x80)) //extension bit is set?
	     pucBuff++;
	   
     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_INT,
          "EMC", pxSuotaSess->xVerInfo.unEMC);
     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_INT,
          "Url2Follow", pxSuotaSess->ucUrl1ToFollow);
     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_INT,
          "FileNum", pxSuotaSess->xVerInfo.ucFileNum);
     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_INT,
          "Reason", pxSuotaSess->xVerInfo.eReason);

	   /*The SW version identifier value is software provider specific, and shall be 
	     defined by the PP vendor. It shall not be empty. The value used shall represent
    	 the currently installed version of the software, not the targeted SW version 
		   identifier (although it is known from the first response of the FP on). */
	   if((pucEnd - pucBuff) < 3 )
	   {
	     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		         "SW Version Identifier is missing");
       eRet = IFX_FAILURE;
       goto Fail;	   
	   }
	   
	   {
	   pucBuff++;
     IFX_DECT_DPSU_DumpData(8, pucBuff);
		 if(*pucBuff == IFX_DECT_SUOTA_SW_VID) {
		   /* Octet 9 */
		   uchar8 ucLs;
		   pucBuff++;
		   /* Length Identifier Octet 10*/
		   if((20 < (*pucBuff)) || ((*pucBuff) < 1))
		   {
		     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		         "SW Version Length is wrong!!!");
         eRet = IFX_FAILURE;
         goto Fail;	   
		   }
		   ucLs = *pucBuff;
	     pucBuff++;
		   strncpy(&pxSuotaSess->xVerInfo.acSwVer[0],(char8*) pucBuff, ucLs);
       IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_INT,
            "Sw Ver Length", ucLs);
		   IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO,
            "Sw Ver Identifier",pxSuotaSess->xVerInfo.acSwVer);
		   pucBuff = pucBuff + ucLs;
		 }
		 if((pucEnd - pucBuff) < 3 )
	   {
	     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		         "No Hw Identifier");
		   break;
	   }
		 else if(*pucBuff == IFX_DECT_SUOTA_HW_VID) {		   
		   uchar8 ucLh;
		   pucBuff++;
		   /* Length Identifier */
		   if((20 < (*pucBuff)) || ((*pucBuff) < 1))
		   {
		     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		         "HW Version Length is wrong!!!");
         eRet = IFX_FAILURE;
         goto Fail;	   
		   }
		   ucLh = *pucBuff;
	     pucBuff++;
		   strncpy(pxSuotaSess->xVerInfo.acHwVer, (char8*)pucBuff, ucLh);
       IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_INT,
            "Hw Ver Length", ucLh);
		   IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO,
            "Hw Ver Identifier",pxSuotaSess->xVerInfo.acHwVer);
		   pucBuff = pucBuff + ucLh;		   
		 }
     }
	   if(pxSuotaSess->eState > IFX_DECT_SUOTA_INDICATION)
	   {
	     if((pxSuotaSess->eState == IFX_DECT_SUOTA_IN_PROCESS) 
		     && (pxSuotaSess->ucUrl1ToFollow == 0))
		   {
         /*In order to retrieve subsequent files (in case more than one 
           file is needed, i.e. in case of multiple file software upgrade). 
           In that case, the <URL to follow> field should be set to "0". */
		     x_IFX_DECT_SUOTA_VersionIndicationInfo xSuotaVerInfo;
		   
		     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		           "Next Version Indication for same SUOTA session");
	       
		     memset(&xSuotaVerInfo,0,sizeof(x_IFX_DECT_SUOTA_VersionIndicationInfo));
		     memcpy(&xSuotaVerInfo,&pxSuotaSess->xVerInfo,
                 sizeof(x_IFX_DECT_SUOTA_VersionIndicationInfo));
		     /* Call the CallBack */
		     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		           "Invoking pfnVerIndication callbk");
				 if(vxSuotaCallBks.pfnVerIndication == NULL)
				 {
		     		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		           "pfnVerIndication callbk not registered");
       			eRet = IFX_FAILURE;
       			goto Fail;	   
				 }
	       if(IFX_SUCCESS != vxSuotaCallBks.pfnVerIndication(
                           ucHandsetId,&xSuotaVerInfo)){
		       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		             "Callbk failed !!!!!");
       			eRet = IFX_FAILURE;
       			goto Fail;	   
         }
		     pxSuotaSess->eState = IFX_DECT_SUOTA_INITIATED;
		     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO,
               "State changed to =", 
                   IFX_DECT_SUOTA_GetStatusStr(pxSuotaSess->eState));
	     }
       /*else {
         eRet = IFX_FAILURE;
         goto Fail;	   
       }*/
	   }
	   else if(((pxSuotaSess->eState == IFX_DECT_SUOTA_INDICATION) 
               || (pxSuotaSess->eState == IFX_DECT_SUOTA_WAIT_FOR_URL)
               || (pxSuotaSess->eState == IFX_DECT_SUOTA_INITIATED))
	             && (pxSuotaSess->ucUrl1ToFollow > 0))
	   {
	     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		           "Next Version Indication before the session initiated");
		   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		           "Reset the earlier and consider this");
		
		   // ???? Need to check
	   }
	   else
	   {
	     pxSuotaSess->eState = IFX_DECT_SUOTA_INDICATION;
		   IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO,
            "State changed to =", 
              IFX_DECT_SUOTA_GetStatusStr(pxSuotaSess->eState));
	   }
	   break;
	 
	 /* Octet 4 */
	 case IFX_DECT_SUOTA_CMD_URL_INDICATION:
     {
	     uchar8 ucUrlLen=0;
	     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	             "Command=URL Indication");
	     /* Octet 5 */
	     pxSuotaSess->ucUrl1ToFollow = *pucBuff;
	     pucBuff++;
	     /* Octet 6 */
	     ucUrlLen = *pucBuff;
	     printf("Url2Follow: %d UrlLen: %d\n",pxSuotaSess->ucUrl1ToFollow,ucUrlLen);
	     pucBuff++;
       //printf("URL fragment %s\n",pucBuff);
	     if(pxSuotaSess->eState == IFX_DECT_SUOTA_IDLE)
         eRet = IFX_FAILURE;
	     else
	       memcpy(&pxSuotaSess->xVerInfo.acUrl[pxSuotaSess->unUrlLen], pucBuff, ucUrlLen);
	   
       pxSuotaSess->unUrlLen += ucUrlLen;
		   IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO,
                 "URL is:",pxSuotaSess->xVerInfo.acUrl);
       //printf("URL length till now %d\n",pxSuotaSess->unUrlLen);
	     if(pxSuotaSess->ucUrl1ToFollow == 0)
	     {
	       x_IFX_DECT_SUOTA_VersionIndicationInfo xSuotaVerInfo;
		     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		             "Last URL Indication received.");
         pxSuotaSess->xVerInfo.acUrl[pxSuotaSess->unUrlLen] = '\0';
		     memset(&xSuotaVerInfo,0,sizeof(x_IFX_DECT_SUOTA_VersionIndicationInfo));
		     memcpy(&xSuotaVerInfo,&pxSuotaSess->xVerInfo,
                   sizeof(x_IFX_DECT_SUOTA_VersionInfo));
		     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		             "Invoking pfnVerIndication callbk");
					if( vxSuotaCallBks.pfnVerIndication == NULL)
					{
		     		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		           "pfnVerIndication callbk not registered");
       			eRet = IFX_FAILURE;
       			goto Fail;	   
					}
         if(IFX_SUCCESS != vxSuotaCallBks.pfnVerIndication(
                           ucHandsetId,&xSuotaVerInfo)){
		       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		                "Callbk failed !!!!!");
           memset(pxSuotaSess ,0, sizeof(x_IFX_DECT_DPSU_SuotaSession));  
       			eRet = IFX_FAILURE;
       			goto Fail;	   
         }
         pxSuotaSess->unUrlLen = 0;
	       pxSuotaSess->eState = IFX_DECT_SUOTA_INITIATED;
		     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO,
               "State changed to =", 
                   IFX_DECT_SUOTA_GetStatusStr(pxSuotaSess->eState));
	     }
	     else
       {
	       pxSuotaSess->eState = IFX_DECT_SUOTA_WAIT_FOR_URL;
		     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO,
               "State changed to =", 
                   IFX_DECT_SUOTA_GetStatusStr(pxSuotaSess->eState));
       }
     }
	 break;
	 
	 /* Octet 4 */
	 case IFX_DECT_SUOTA_CMD_NACK:
		 {
		  e_IFX_DECT_SUOTA_NACKReason eNack;
	   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	           "Command=Negative acknowledgement");
	  
	   /* Octet 5 */
	   eNack = *pucBuff;
		if(vxSuotaCallBks.pfnNack == NULL)
		{
		    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		           "pfnNack callbk not registered");
       	eRet = IFX_FAILURE;
       	goto Fail;	   
		}
	   pxSuotaSess->xCallBks.pfnNack(ucHandsetId,eNack);
	 break;
		 }
   default:
     eRet = IFX_FAILURE;
  }

Fail:
  if(eRet == IFX_FAILURE)
  {
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_LOW,IFX_DBG_STR,
		      "Command Format Error!! Sending NACK");
    IFX_DECT_SUOTA_SendNACK(ucHandsetId,IFX_DECT_SUOTA_NACK_COM_FORMAT_ERR);
    return IFX_FAILURE;    
  }
  return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_DPSU_HandleFacilityMsg
* Description    : Handle DPSU Facility message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_DPSU_HandleFacilityMsg(x_IFX_DECT_IPC_Msg *pxIPCMsg)
{
  uint32 uiIEHdl = 0;
  x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo;
  e_IFX_Return eRet;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  if(0 == (uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIPCMsg)) ){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
    return IFX_FAILURE;
  }

  while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_IWUTOIWU){
    if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"NO IWU TO IWU IE");
       return IFX_FAILURE;
    }
  }
  if(IFX_DECT_IE_IWUToIWUGet(uiIEHdl,&xIWUToIWUInfo) != IFX_SUCCESS){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"NO IWU TO IWU IE");
      return IFX_FAILURE;
  }
  
  //xIWUToIWUInfo.ucPD,xIWUToIWUInfo.ucSR,xIWUToIWUInfo.ucDefault1,xIWUToIWUInfo.ucIWUToIWULen
  if((xIWUToIWUInfo.ucPD != 0x06)&&(xIWUToIWUInfo.ucIWUToIWULen<=0)){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Not For SUOTA");
    return IFX_FAILURE;
  }
  IFX_DECT_DPSU_DumpData(xIWUToIWUInfo.ucIWUToIWULen, xIWUToIWUInfo.acIWUToIWU);
  eRet=IFX_DECT_SUOTA_DecodeCmd(pxIPCMsg->ucPara1,
             xIWUToIWUInfo.acIWUToIWU,xIWUToIWUInfo.ucIWUToIWULen);
  if(eRet != IFX_SUCCESS){
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Decode Command Failed");
    goto Fail;	   
  }
    
  Fail:
    /* Send negative ack with eReason */
	  return IFX_FAILURE;
}

#endif
//===========================================================================================


/*! \brief IFX_DECT_DPSU_ProcessCPlaneMsg function processes messages received from DECT stack.
    \param[in] pxIpcMsg Pointer to DECT IPC message struct.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ProcessCPlaneMsg(IN x_IFX_DECT_IPC_Msg *pxIpcMsg){
  
   uchar8 ucProtocolID = 0;
   uint32 uiIEHdl = 0;
   int32 iSessionIndex =0;
   int32 iConnIndex =0;
   uchar8 ucReleaseReason;
   x_IFX_DECT_DPSU_ConnectionInfo *pxConn = NULL;
   x_IFX_DECT_IPC_Msg xIpcMsg = {0};
#ifndef LTQ_RAW_DPSU
   x_IFX_DECT_IE_BasicService xBSInfo ={0};
	 uchar8 ucBasicService;
#endif
   uchar8 ucHandset;

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                     " <API ProcessCPlaneMsg>Entry.");
					 
   if(NULL == pxIpcMsg){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	                     " <API ProcessCPlaneMsg>pxIpcMsg is NULL.API Failed.");
    return IFX_FAILURE;
   }
   
	 ucHandset = pxIpcMsg->ucPara1;

   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
              "Handset:",ucHandset);
#ifdef ULE_SUPPORT   
	if((ucHandset < 1)||(ucHandset > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1)){
   
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		  "Invalid HandsetId");
  	 return IFX_FAILURE;
	}
#else
	 if((ucHandset < 1)||(ucHandset > IFX_DECT_MAX_HS)){
   
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		  "Invalid HandsetId");
	  return IFX_FAILURE;
	}
		 
#endif


   uiIEHdl =  IFX_DECT_IE_GetIEHandler(pxIpcMsg);
    
#if 0	
   if(IFX_DECT_DPSU_GetProtocolID(&uiIEHdl,&ucProtocolID) == IFX_FAILURE){

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	                          " <API ProcessCPlaneMsg>Failure.GetProtocolID failed.");
     return IFX_FAILURE;
   }
#endif

   ucProtocolID = IFX_DECT_DPSU_HTTP;
   
   if(IFX_DECT_DPSU_ValidateProtoID(ucProtocolID) == IFX_FAILURE){

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          " <API ProcessCPlaneMsg>Failure.ValidateProtoID failed.");
     return IFX_FAILURE;
   }	 
   
   switch(pxIpcMsg->ucMsgId){
     
     case FP_SETUP_IN_CC:
	 
         printf("Instance %d\n",pxIpcMsg->ucInstance);		 
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
              "Instance:",pxIpcMsg->ucInstance);
         acHandsetMap[pxIpcMsg->ucInstance] = ucHandset;
             
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
              "<API ProcessCPlaneMsg>FP_SETUP_IN_CC Message Arrived From PT.");
            
        
		 if((iSessionIndex = IFX_DECT_DPSU_GetMatchSessionIndex_CPlane(ucProtocolID)) != IFX_FAILURE){
		 
           if(IFX_OS_LockAcquire(vxGlobalInfo.xDPSApiLock) == IFX_SUCCESS){
         
		       iConnIndex = IFX_DECT_DPSU_GetFreeConnectionIndex(iSessionIndex);
            }else{
              
			  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    "<ProcessCPlaneMsg>CB DataCallArrived to be issued.Failed to Acquire Lock.");
             }
            if(IFX_OS_LockRelease(vxGlobalInfo.xDPSApiLock) != IFX_SUCCESS){
            
			   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    "<ProcessCPlaneMsg>CB DataCallArrived to be issued.Failed to Release Lock.");
            }
            if(iConnIndex != IFX_FAILURE){
          //printf("SessIndex %d ConnIndex %d\n",iSessionIndex,iConnIndex); 
		  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
              "iConnIndex:",iConnIndex);
		  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
              "SessIndex:",iSessionIndex);
		      pxConn = &vpxSessionList[iSessionIndex].xConnectionList[iConnIndex];
          //printf("Conn Handle %d\n",(uint32)pxConn);
			  
              if(pxConn->eState == IFX_DECT_DPSU_IDLE){
#ifndef LTQ_RAW_DPSU             
			          /* Check whether BASIC_SERVICE IE is present or not.
                   If Yes, then return the basic service info else Reject*/
                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Checking Basic service");
                if(IFX_DECT_DPSU_ValidateBasicService(pxIpcMsg,&xBSInfo) != IFX_SUCCESS){
                      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                    "Mandatory Parameters Are Missing" );
                    //??????
                    
					IFX_DECT_DPSU_ReleaseConnectionResources((uint32)pxConn);
					IFX_DECT_EncodeRelease(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,
                        		IFX_DECT_MANDATORY_IE_MISSING,&xIpcMsg);
  					return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
                }
                else {
                  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
                           "BASIC SERVICE found" );
				          ucBasicService = ((xBSInfo.ucCallClass)<<4) | xBSInfo.ucBasicService ;
	                      if((ucHandset > 0 )&&(ucHandset <= IFX_DECT_MAX_HS))
	                      {
				          IFX_DECT_MU_SetBasicService(ucHandset,ucBasicService);
	                      }
						  
				          if(xBSInfo.ucBasicService == 0x09)
				          {
				            IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
					                "LDS ME Calss 4" );
					          memset(&vxIWUAttributesInfo[ucHandset-1],0,
                                   sizeof(x_IFX_DECT_IE_IWUAttributes));
					          if(IFX_DECT_DPSU_ValidateIWUAttributes(pxIpcMsg,
                           &vxIWUAttributesInfo[ucHandset-1]) != IFX_SUCCESS){
                      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                                   "IWU Attributes IE is not present" );
                      
					            IFX_DECT_DPSU_SetDefaultIWUAttributes(
                                    &vxIWUAttributesInfo[ucHandset-1]);
                    }
					          else
					          {
					            IFX_DECT_DPSU_SetIWUAttributes(
                                    &vxIWUAttributesInfo[ucHandset-1]);
								IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                                   "IWU Attributes IE is present" );
					          }
					
				          }
                  else if(xBSInfo.ucBasicService == 0x0A) {
				            IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
					                "LDS ME Calss 3" );
                  }
                }
                pxConn->xDgmep.ucIsChop = 0;
				        /* Assign GMCI */
				        IFX_DECT_DPSU_GetGmci(ucHandset, &pxConn->xDgmep.ucGMCI);
				        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                               "Assign GMCI:",pxConn->xDgmep.ucGMCI);
                //pxConn->xDgmep.ucGMCI = 1;
#endif			  
				if((ucHandset > 0 )&&(ucHandset <= IFX_DECT_MAX_HS))
				{
					IFX_DECT_MU_SetModuleOwner(ucHandset,IFX_DECT_MU_ADD_OWNER,IFX_DECT_DPSU_ID);
					IFX_DECT_BlockMCEI(ucHandset,pxConn->ucInstance);
				}
			    
                {
			      if(IFX_OS_LockAcquire(vxGlobalInfo.xDPSApiLock) == IFX_SUCCESS){
				      pxConn->ucInstance = pxIpcMsg->ucInstance;
              pxConn->ucHandset = ucHandset;
              pxConn->eState = IFX_DECT_DPSU_PENDING;
            }
            else{
				      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                              "<ProcessCPlaneMsg>CB CallInitiate to be issued.Failed to Acquire Lock.");
            }
            if(IFX_OS_LockRelease(vxGlobalInfo.xDPSApiLock) != IFX_SUCCESS){
              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       "<ProcessCPlaneMsg>CB CallInitiate to be issued.Failed to Release Lock.");
            }
            printf("Mode %d IFX_ON:%d",IFX_DECT_ENCRYPTION_MODE,IFX_ON);
            if(IFX_DECT_ENCRYPTION_MODE == IFX_ON){

				if((ucHandset > 0 )&&(ucHandset <= IFX_DECT_MAX_HS))
				{
              IFX_DECT_MU_SetCipherStatus(pxConn->ucHandset,IFX_TRUE); 
				}
              IFX_DECT_EncodeAuthPTReq(pxConn->ucHandset ,
                                       pxConn->ucInstance, &xIpcMsg);
              IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
              return IFX_SUCCESS;
            }

			 IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
					                "DPSU State=", pxConn->eState);
			 IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
					                "DPSU pxConn=", pxConn);
            if(vpxSessionList[iSessionIndex].xCallBks.pfnCallInitiate != NULL){
#ifndef LTQ_RAW_DPSU
           pxConn->uiTotalRXbyte=0;
           pxConn->uiTotalTXbyte=0;
#endif
				      if(vpxSessionList[iSessionIndex].xCallBks.pfnCallInitiate(
                       (uint32)pxConn,ucHandset,uiIEHdl,&ucReleaseReason,
					             &(pxConn->uiPrivateData)) == IFX_FAILURE){
						  
                     if(IFX_OS_LockAcquire(vxGlobalInfo.xDPSApiLock) == IFX_SUCCESS){
  
                       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                               "<ProcessCPlaneMsg>CB CallInitiate Failed.Reason for Release"
                               ,ucReleaseReason);
                       //IFX_DECT_DPSU_ReleaseConnectionResources((uint32)pxConn);
					   
                     }else{
                      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                              "<ProcessCPlaneMsg>CB CallInitiate Failed.Failed to Acquire Lock.");
                      }
                    
					if(IFX_OS_LockRelease(vxGlobalInfo.xDPSApiLock) != IFX_SUCCESS){
                    
					  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                              "<ProcessCPlaneMsg>CB CallInitiate Failed.Failed to Release Lock.");
                    }
					IFX_DECT_DPSU_ReleaseConnectionResources((uint32)pxConn);
					IFX_DECT_EncodeRelease(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,
                        		ucReleaseReason,&xIpcMsg);
  					IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
                  
				   }else{
                   
				     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       " <ProcessCPlaneMsg>Callback CallInitiate Issued Successfully.");


                     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       " <ProcessCPlaneMsg>Successful.");
 
                     
                     return IFX_SUCCESS;
                    }
                 }
                }
              }
            } 
		 } 
      
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "<ProcessCPlaneMsg>Failed for call from PT.Callback CallInitiate could not be registered.");

        break;
						

     case FP_RELEASE_IN_CC:
        
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "<API ProcessCPlaneMsg>FP_RELEASE_IN_CC Message Arrived From PT.");
             
		 if((iSessionIndex = IFX_DECT_DPSU_GetMatchSessionIndex_CPlane(ucProtocolID)) != IFX_FAILURE){
          
		   if((iConnIndex = IFX_DECT_DPSU_GetMatchConnectionIndex(iSessionIndex,ucHandset)) != IFX_FAILURE){
            
			 pxConn = &vpxSessionList[iSessionIndex].xConnectionList[iConnIndex];
            
			 if(pxConn->eState != IFX_DECT_DPSU_IDLE){
             
			   if(IFX_OS_LockAcquire(vxGlobalInfo.xDPSApiLock) == IFX_SUCCESS){
              
				if((ucHandset > 0 )&&(ucHandset <= IFX_DECT_MAX_HS))
				{
			     IFX_DECT_MU_SetModuleOwner(pxConn->ucHandset,IFX_DECT_MU_REMOVE_OWNER,IFX_DECT_DPSU_ID);
                 IFX_DECT_FreeMCEI(ucHandset,pxConn->ucInstance);				 
				}
#ifdef ULE_SUPPORT
  				else if (ucHandset > IFX_DECT_MAX_HS)
  				{
  					IFX_DECT_ULE_ResetDPSUCallType(pxConn->ucHandset);
  				}
#endif              			     
			     acHandsetMap[pxConn->ucInstance] = 0;
                 				 
                 pxConn->eState=IFX_DECT_DPSU_IDLE;
				 
               }else{
			   
                 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       "<ProcessCPlaneMsg>CB CallRelease to be Issued.Failed to Acquire Lock.");
                }
             
			   if(IFX_OS_LockRelease(vxGlobalInfo.xDPSApiLock) != IFX_SUCCESS){
               
			     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                        "<ProcessCPlaneMsg>CB CallRelease to be Issued.Failed to Release Lock.");
               }

               if(vpxSessionList[iSessionIndex].xCallBks.pfnCallRelease != NULL){
			   
                 if(vpxSessionList[iSessionIndex].xCallBks.pfnCallRelease(
                   (uint32)pxConn,uiIEHdl,IFX_DECT_RELEASE_NORMAL,pxConn->uiPrivateData) == IFX_FAILURE){
                 
				   if(IFX_OS_LockAcquire(vxGlobalInfo.xDPSApiLock) == IFX_SUCCESS){
                 
                   IFX_DECT_DPSU_ReleaseConnectionResources((uint32)pxConn);
                   }else{
                   
				     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                              "<ProcessCPlaneMsg>CB CallRelease Failed.Failed to Acquire Lock.");
                    }
                   if(IFX_OS_LockRelease(vxGlobalInfo.xDPSApiLock) != IFX_SUCCESS){
                    
					  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                              "<ProcessCPlaneMsg>CB CallRelease Failed.Failed to Release Lock.");
                   }

                 }else{
                 
				   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       " <ProcessCPlaneMsg>Callback CallRelease Issued Successfully.");

                   IFX_DECT_DPSU_ReleaseConnectionResources((uint32)pxConn);
                   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       " <ProcessCPlaneMsg>Successful.");

                  return IFX_SUCCESS;
                  }
               }
            }
		   } 
         }     
       
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		        "<ProcessCPlaneMsg>Failed for call close from PT.Callback CallRelease could not be registered.");
				
		 break;
#ifndef LTQ_RAW_DPSU		 
     case FP_FACILITY_IN_CLSS:
	     IFX_DECT_DPSU_HandleFacilityMsg(pxIpcMsg);
	     return IFX_SUCCESS;
#endif
		 case FP_AUTHENTICATE_PT_CFM_MM:
		 {
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "<API ProcessCPlaneMsg>FP_AUTHENTICATE_PT_CFM_MM Message Arrived From PT.");
       if(pxIpcMsg->ucPara2 ==1){
          x_IFX_DECT_IPC_Msg xIpcMsg={0};
			    IFX_DECT_EncodeEnableCipher(pxIpcMsg->ucPara1,
                                      pxIpcMsg->ucInstance, 
	                                    1,
                                      &xIpcMsg);
          IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
          return IFX_SUCCESS;
       }else
       {
          IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "PT Authenticate CFM Failed");
			    //IFX_DECT_CC_HandleCiphering(pxIPCMsg);
       }
		   break;
		}
		case FP_CIPHER_ON_CFM_MM:
		case FP_CIPHER_OFF_CFM_MM:
        
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "<API ProcessCPlaneMs>FP_CIPHER_OFF_CFM_MM Message Arrived From PT.");
		   if((iSessionIndex = IFX_DECT_DPSU_GetMatchSessionIndex_CPlane(ucProtocolID)) != IFX_FAILURE){
		   
         if((iConnIndex = IFX_DECT_DPSU_GetMatchConnectionIndex(iSessionIndex,ucHandset)) != IFX_FAILURE){
		 
           printf("SessIndex %d ConnIndex %d\n",iSessionIndex,iConnIndex); 
		       pxConn = &vpxSessionList[iSessionIndex].xConnectionList[iConnIndex];
           //printf("Conn Handle %d\n",(uint32)pxConn);
               
			     if(IFX_OS_LockAcquire(vxGlobalInfo.xDPSApiLock) == IFX_SUCCESS){
                    pxConn->eState = IFX_DECT_DPSU_PENDING;
           }else{
                 
				   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                              "<ProcessCPlaneMsg>CB CallInitiate to be issued.Failed to Acquire Lock.");
           }
           if(IFX_OS_LockRelease(vxGlobalInfo.xDPSApiLock) != IFX_SUCCESS){
                     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                              "<ProcessCPlaneMsg>CB CallInitiate to be issued.Failed to Release Lock.");
           }

           if(vpxSessionList[iSessionIndex].xCallBks.pfnCallInitiate != NULL){
#ifndef LTQ_RAW_DPSU
	           pxConn->uiTotalRXbyte=0;
	           pxConn->uiTotalTXbyte=0;
#endif           

                 
				     if(vpxSessionList[iSessionIndex].xCallBks.pfnCallInitiate(
                      (uint32)pxConn,ucHandset,uiIEHdl,&ucReleaseReason,
					      &(pxConn->uiPrivateData)) == IFX_FAILURE){
						  
                     if(IFX_OS_LockAcquire(vxGlobalInfo.xDPSApiLock) == IFX_SUCCESS){
  
                       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                               "<ProcessCPlaneMsg>CB CallInitiate Failed.Reason for Release"
                               ,ucReleaseReason);
                       IFX_DECT_DPSU_ReleaseConnectionResources((uint32)pxConn);
                     }else{
                      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                              "<ProcessCPlaneMsg>CB CallInitiate Failed.Failed to Acquire Lock.");
                      }
                    
					if(IFX_OS_LockRelease(vxGlobalInfo.xDPSApiLock) != IFX_SUCCESS){
                    
					  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                              "<ProcessCPlaneMsg>CB CallInitiate Failed.Failed to Release Lock.");
                    }
                  
				   }else{
                   
				     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       " <ProcessCPlaneMsg>Callback CallInitiate Issued Successfully.");


                     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       " <ProcessCPlaneMsg>Successful.");
 
                     
                     return IFX_SUCCESS;
                    }
                 }
              }
            } 
      
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "<ProcessCPlaneMsg>Failed for call from PT.Callback CallInitiate could not be registered.");

      break;
	 default:
	     return IFX_SUCCESS;

   }
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	              "<API ProcessCPlaneMsg>Invalid message arrived.Sending Release Msg to Stk.");
   return IFX_DECT_DPSU_SendReleaseMsgToStack(pxIpcMsg,IFX_DECT_RELEASE_ABNORMAL);
     
}   
   
   
/*! \brief IFX_DECT_DPSU_ProcessUPlaneMsg processes messages received from DECT stack.
    \param[in] pxUPlaneIpcMsg Pointer to DECT U Plane IPC message struct.
    \return IFX_SUCCESS or IFX_FAILURE.
 */

e_IFX_Return 
IFX_DECT_DPSU_ProcessUPlaneMsg(IN x_IFX_DECT_IPC_Msg_u *pxUPlaneIpcMsg){

  e_IFX_Return eRet =  IFX_FAILURE;
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  uint16 uiBufferLen = 0;
  uint16 uiLen = 0;

  int32 iSessionIndex =0;
  int32 iConnIndex =0;
  x_IFX_DECT_DPSU_ConnectionInfo *pxConn = NULL;
		   

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            " <API ProcessUPlaneMsg>Entry.");
						
  if(NULL == pxUPlaneIpcMsg){
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	          " <API ProcessCPlaneMsg>pxUPlaneIpcMsg is NULL.");
						  
     return IFX_FAILURE;
   }
#ifdef DPSU_TEST 
	char *pHttpdata2="GET http://10.10.10.203/dwld/tl/ HTTP/1.1\x0D\x0A"\
	              "Host: 10.10.10.203:80\x0D\x0A"\
	              "Range:bytes=0-400\x0D\x0A"\
								"Content-Length:0\x0D\x0A\x0D\x0A\x0D\x0A";

	char *pHttpdata3="GET http://10.10.10.203/dwld/tl/tone1.midi HTTP/1.1\x0D\x0A"\
	              "Host: 10.10.10.203:80\x0D\x0A"\
	              "Range:bytes=0-400\x0D\x0A"\
								"Content-Length:0\x0D\x0A\x0D\x0A\x0D\x0A";
#if 0
  char *pHttpdata3="GET http://172.20.22.68/Mydata.html HTTP/1.1\x0D\x0A"\
                 "User-Agent:SNIP_CLIENT/1.0\x0D\x0A"\
                "Host: 172.20.22.68:80\x0D\x0A"\
                "Content-Length:0\x0D\x0A\x0D\x0A\x0D\x0A";

  char *pHttpdata4="GET http://172.20.22.68/Hello.txt HTTP/1.1\x0D\x0A"\
                 "User-Agent:SNIP_CLIENT/1.0\x0D\x0A"\
                "Host: 172.20.22.68:80\x0D\x0A"\
                "Content-Length:0\x0D\x0A\x0D\x0A\x0D\x0A";
  char *pHttpdata="GET /GigaSetFiles/RingTone/Bouncey.wav HTTP/1.1\x0D\x0A"\
  	             "accept: application/octet-stream\x0D\x0A"\
	              "range:bytes=0-10239\x0D\x0A"\
                "Content-Length:0\x0D\x0A\x0D\x0A\x0D\x0A";
#endif
#endif

  switch(pxUPlaneIpcMsg->ucMsgId){
     
    case FP_MEDIA_SDU_RCV_IN:
#ifdef DPSU_TIMESTAMP
       printf("RCV_IN\t");
       IFX_DECT_DPSU_GetTimeStamp();
#endif 
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "<API ProcessUPlaneMsg>FP_MEDIA_SDU_RCV_IN Arrived from Stack.");

       uiLen = pxUPlaneIpcMsg->ucPara1;
       uiLen <<= IFX_DECT_OCTET;
       uiLen |= pxUPlaneIpcMsg->ucPara2;

#ifndef DPSU_TEST
		   if((iSessionIndex = IFX_DECT_DPSU_GetMatchSessionIndex_UPlane(pxUPlaneIpcMsg->ucInstance)) != IFX_FAILURE){
         
		     if((iConnIndex = IFX_DECT_DPSU_GetMatchConnectionIndex(iSessionIndex,acHandsetMap[pxUPlaneIpcMsg->ucInstance])) 
		      != IFX_FAILURE){
           printf("SessionIndex %d ConnIndex %d\n",iSessionIndex,iConnIndex);
			     pxConn = &vpxSessionList[iSessionIndex].xConnectionList[iConnIndex];
           print_data("Conn Handle %d\n",(uint32)pxConn);
#ifndef LTQ_RAW_DPSU
  printf("GMCI:%x SEQ:%x\n",pxUPlaneIpcMsg->acData[0],pxUPlaneIpcMsg->acData[1]);
		     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
               "Instance: ", pxUPlaneIpcMsg->ucInstance);
		     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
               "GMCI: ", pxUPlaneIpcMsg->acData[0]);
		     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
               "SEQ: ", pxUPlaneIpcMsg->acData[1]);
		     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
               "REQ Length: ", uiLen);
		     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_ATA_STRING_INFO,
               "REQ: ", pxUPlaneIpcMsg->acData);
#endif
         //IFX_DECT_DPSU_DumpData(uiLen, &pxUPlaneIpcMsg->acData[0]);
         //printf("Length %d\n",uiLen);
			   if(pxConn->eState == IFX_DECT_DPSU_ACTIVE){
             
			     pxConn->uiTXbyte = 0;
           pxConn->uiRXbyte = 0;
#ifndef LTQ_RAW_DPSU
     if(IFX_FAILURE != IFX_DECT_DPSU_ValidateGMCI(pxConn, pxUPlaneIpcMsg))
     {
        /*If  Bit 8 is 0 then next octet follows */
        if(!(pxUPlaneIpcMsg->acData[0] & 0x80))
        {
          /* Bit 1-7 is the Sequence Number */
          if((pxUPlaneIpcMsg->acData[1] & 0x7F) == (pxConn->ucRSN++))
          {
				    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                       "RSN:",pxConn->ucRSN);
          }
          else {
	          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "Wrong Sequence Number Received");	 
          }
	        memcpy(pxConn->acReqBuff + pxConn->unReqByte,&pxUPlaneIpcMsg->acData[2],uiLen-2);
          pxConn->unReqByte += uiLen-2;
           
          /* Check the 8th Bit. If 0: last segment 1: SDU follows   */
          if((pxUPlaneIpcMsg->acData[1] & 0x80) == IFX_DECT_DPSU_DGMEP_MORE_BIT)
          {
	          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "More SDU to follow.");
            return IFX_SUCCESS;	 
          }
          else {
	          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "Last SDU.");
	          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "Send Data Buffer to Agent.");

          }
        }  
        else {
	        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "Sequence Number is not present.");	 
	        memcpy(pxConn->acReqBuff + pxConn->unReqByte,&pxUPlaneIpcMsg->acData[1],uiLen-1);
          pxConn->unReqByte += uiLen-1;
        }
	    }
      else {
	      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Wrong GMCI!!!");	 
        return IFX_FAILURE;
      }
#endif
           if(vpxSessionList[iSessionIndex].xCallBks.pfnDataSendToIP != NULL){
               
			       if(vpxSessionList[iSessionIndex].xCallBks.pfnDataSendToIP(
#ifdef LTQ_RAW_DPSU               
               (uint32)pxConn,((char8*)pxUPlaneIpcMsg->acData),uiLen,pxConn->uiPrivateData)
#else
               (uint32)pxConn,pxConn->acReqBuff,pxConn->unReqByte,pxConn->uiPrivateData)
#endif 
               != IFX_FAILURE){
                   
				         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                        "Callback SendDataToIP issued successfully.");
#ifndef LTQ_RAW_DPSU               
                 memset(pxConn->acReqBuff,0,sizeof(pxConn->acReqBuff));
                 pxConn->unReqByte = 0;
                 pxConn->ucRSN = 0;
#endif
                 return IFX_SUCCESS;
               }
               else {
				         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                        "Callback SendDataToIP failed.");
               }
             }
           }
           }
         }
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
          "<ProcessUPlaneMsg>Failed for Data Transfer.Callback SendDataToIP not registered.");

         return IFX_FAILURE;
#else
         return IFX_SUCCESS;
#endif
         break;

     case FP_MEDIA_SDU_FLOW_IN:
         
#ifdef DPSU_TIMESTAMP
       printf("FLOW_IN\t");
       IFX_DECT_DPSU_GetTimeStamp();
#endif 
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                       " <API ProcessUPlaneMsg>FP_MEDIA_SDU_FLOW_IN Arrived from Stack.");

         uiBufferLen = pxUPlaneIpcMsg->ucPara2;
         uiBufferLen <<= IFX_DECT_OCTET;
         uiBufferLen |= pxUPlaneIpcMsg->ucPara3;
		 
		 if((iSessionIndex = IFX_DECT_DPSU_GetMatchSessionIndex_UPlane(pxUPlaneIpcMsg->ucInstance)) != IFX_FAILURE){
         
		   if((iConnIndex = IFX_DECT_DPSU_GetMatchConnectionIndex(iSessionIndex,acHandsetMap[pxUPlaneIpcMsg->ucInstance])) 
		      != IFX_FAILURE){
            
			 pxConn = &vpxSessionList[iSessionIndex].xConnectionList[iConnIndex];
            
			 if(pxConn->eState == IFX_DECT_DPSU_CONNECTED){
             
			   pxConn->eState = IFX_DECT_DPSU_ACTIVE;
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                   "<ProcessUPlaneMsg0>First Flow In Message Received.State Changed from CONNECTED to ACTIVE.");
             }
             if(pxConn->eState == IFX_DECT_DPSU_ACTIVE){   
			   if(IFX_DECT_DPSU_GetBuffer(pxConn->ucInstance,pxConn->ucHandset,(uint32)pxConn) == IFX_SUCCESS){
               
			     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                    "<ProcessUPlaneMsg>Successful.Buffer Sent.");
                 eRet = IFX_SUCCESS;
               }
             }else{
			   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                   " <ProcessUPlaneMsg>Flow In Message Received.State not ACTIVE.Failed.");

			   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			                      "<ProcessUPlaneMsg>Unsuccessful.");
						
              }  
           }
           
         }
#if 0
        x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};
        char8 *pcBuff = "HELLO MAHIPATI HOW R U";
        memcpy(pxUPlaneIpcMsg->acData,pcBuff,strlen(pcBuff));
	
		IFX_DECT_EncodeDataToStack(strlen(pcBuff),pxUPlaneIpcMsg->ucInstance,&xUPlaneIpcMsg);
 
        if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) == IFX_SUCCESS){
          
		  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                    " <ProcessUPlaneMsg>FP_MEDIA_SDU_SND_RQ  Message Encoded and Posted Successfully to Stack.");
          eRet =  IFX_SUCCESS;
		  
        }else{
		
           IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    " <ProcessUPlaneMsg>FP_MEDIA_SDU_SND_RQ  Message not Posted to Stack.");

           eRet = IFX_FAILURE;
         }

#endif

#ifdef DPSU_TEST
       if((IFX_SUCCESS == eRet)&&(0 == iFlowcnt[(uint32)acHandsetMap[pxUPlaneIpcMsg->ucInstance]])){
	       
		   eRet = IFX_FAILURE;
           iFlowcnt[(uint32)acHandsetMap[pxUPlaneIpcMsg->ucInstance]]++;
         
         if((iSessionIndex = IFX_DECT_DPSU_GetMatchSessionIndex_UPlane(pxUPlaneIpcMsg->ucInstance)) 
		     != IFX_FAILURE){
		          
		    if((iConnIndex =
			  IFX_DECT_DPSU_GetMatchConnectionIndex(iSessionIndex,acHandsetMap[pxUPlaneIpcMsg->ucInstance])) !=
				  IFX_FAILURE){
				              
			  pxConn = &vpxSessionList[iSessionIndex].xConnectionList[iConnIndex];
			  if(pxConn->eState == IFX_DECT_DPSU_ACTIVE){
			              
				pxConn->uiTXbyte = 0;
				pxConn->uiRXbyte = 0;
				if(vpxSessionList[iSessionIndex].xCallBks.pfnDataSendToIP != NULL){
											
          if(ucNextGet == 1)
          {
            if(vpxSessionList[iSessionIndex].xCallBks.pfnDataSendToIP((uint32)pxConn,
				      pHttpdata3,strlen(pHttpdata3),pxConn->uiPrivateData) != IFX_FAILURE){
				                      
					    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
						       "Test Message phttpdata3 Successfully routed.");
              eRet =  IFX_SUCCESS;
              ucNextGet = 0;
				    }
          }
          else if(ucNextGet == 0) {		                  
				    if(vpxSessionList[iSessionIndex].xCallBks.pfnDataSendToIP((uint32)pxConn,
				      pHttpdata2,strlen(pHttpdata2),pxConn->uiPrivateData) != IFX_FAILURE){
				                      
					    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
						       "<ProcessUPlaneMsg>Successful.Callback SendDataToIP issued successfully.");
					    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
						       "<ProcessUPlaneMsg>Test Message Successfully routed.");
              eRet =  IFX_SUCCESS;
				    }
          }
          else {
            eRet = IFX_FAILURE;
          }
	      }
	    }
			}
		 }
																			  
         //IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         //         " <API ProcessUPlaneMsg>Routing Test Message Failed.");
       }    
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,"<API ProcessUPlaneMsg>iFlowcnt in Route.",
                  iFlowcnt[(int32)acHandsetMap[pxUPlaneIpcMsg->ucInstance]]);
#endif
       break;
  
     default:IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "<API ProcessUPlaneMsg>Invalid U Plane IPC Message.Sending Release Message to Stack.");
   }

   if(eRet == IFX_FAILURE){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
          "<API ProcessUPlaneMsg>Processing U Plane IPC Message Unsuccessful.Sending Release Message to Stack.");

    xIpcMsg.ucPara1 = acHandsetMap[pxUPlaneIpcMsg->ucInstance];
    xIpcMsg.ucInstance = pxUPlaneIpcMsg->ucInstance;
    return IFX_DECT_DPSU_SendReleaseMsgToStack(&xIpcMsg,IFX_DECT_RELEASE_ABNORMAL);
   }else{
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	           "<API ProcessUPlaneMsg>ProcessUPlaneIpcMsg Successful.");
     return IFX_SUCCESS;
    } 
}
#ifndef LTQ_RAW_DPSU
int getHandsetId(int uiCallHdl)
{
	x_IFX_DECT_DPSU_ConnectionInfo *pxConn;
	pxConn= ((x_IFX_DECT_DPSU_ConnectionInfo *)uiCallHdl);
	if (pxConn!=NULL)
		return pxConn->ucHandset;
	else
		return -1;
}
#if 0
int check_contendownload_status(int uiCallHdl,int isRelease,char *InBuf,char *OutBuf)
{
	x_IFX_DECT_DPSU_ConnectionInfo *pxConn;
	pxConn= ((x_IFX_DECT_DPSU_ConnectionInfo *)uiCallHdl);

	if (isRelease==1) {
		pxConn->uiTotalTXbyte+=pxConn->uiTXbyte;
		pxConn->uiTotalRXbyte+=pxConn->uiRXbyte;
		if (pxConn->uiTotalTXbyte!=pxConn->uiTotalRXbyte || pxConn->uiTotalTXbyte<500000) {
			ClearSUOTAFlag(pxConn->ucHandset-1,NULL);
		}
	}
	else if (InBuf!=NULL && OutBuf!=NULL) {
		int i;
		char *p;
		char *q;
		char tmpbuf[80];
		
		p=strcasestr(InBuf,"GET");
		if (p!=NULL) {
			p += 3;
			while( *p == ' ') p++;
			q=strcasestr(p,"+DTP");
			if (q!=NULL) {
				for(i=0;i<80;i++) {
					if (p==q) break;
					tmpbuf[i]=*p;  p++;
				}
				tmpbuf[i]=0;
				while (i>0) {
					p=&(tmpbuf[i-1]);
					if (*p=='/') {
						strncpy(OutBuf,&(tmpbuf[i]),20);
						break;
					}
					i--;
				}
			}
		}
	}
}
#endif
#endif
