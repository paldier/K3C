/**************************************************************************
**   FILE NAME     : IFX_DECT_LAU.c
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "IFX_DECT_Platform.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_StackIf.h"
#include "IFX_DECT_MsgRouter.h"
#include "IFX_DECT_MsgEncoder.h"
#include "IFX_DECT_IEParser.h"
#include "IFX_DECT_CCInfo.h"
#include "IFX_DECT_LAU.h"
#include "IFX_DECT_GlobalInfo.h"

#define printf(...)
e_IFX_Return
IFX_DECT_LAU_EncodeCmd(IN x_IFX_DECT_LAU_ListCommands *pxCmd,
                       OUT uchar8 *pucBuff,
                       OUT int32 *piLen);
e_IFX_Return
IFX_DECT_LAU_Reset(IN uchar8 ucHandset,IN x_IFX_DECT_LAU_Info *pxLauInfo);

//#define LAU_TEST
#define axLauInfo vxGlobalInfo.xLAU.axLauInfo 
#define vxLauCallBks vxGlobalInfo.xLAU.vxLauCallBks
#define iListSupported vxGlobalInfo.xLAU.iListSupported
#define uiEMCVal vxGlobalInfo.xLAU.uiEMCVal
#define aunSupportedFieldMap vxGlobalInfo.xLAU.aunSupportedFieldMap

//#ifdef LTQ_DT_SUPPORT
#define axPropListInfo vxGlobalInfo.xLAU.axPropListInfo
#define iPropListCount vxGlobalInfo.xLAU.iPropListCount
//#endif



#define IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,nId); {\
	   if((*pucBuff)&0x80){\
	     nId = (*pucBuff)&0x7f;\
		 pucBuff++;\
	   }\
	   else if((*(pucBuff+1)&0x80)){\
	     nId = (((*pucBuff)<<7)|(*(pucBuff+1)&0x7f));\
		 pucBuff+=2;\
	   }\
	 }

#define IFX_DECT_LAU_DECODE_2BYTEID_LEN(pucBuff,iId, iLen); {\
	   if(pucBuff[iLen]&0x80){\
	     iId = pucBuff[iLen]&0x7f;\
       iLen++;\
	   }\
	   else if(pucBuff[iLen+1]&0x80){\
	     iId = ((pucBuff[iLen]<<7)|(pucBuff[iLen+1]&0x7f));\
		   iLen+=2;\
	   }\
	 }

#define IFX_DECT_LAU_DECODE_2BYTEID_LEN_V2(pucBuff,iLen); {\
     if(pucBuff[iLen]&0x80){\
       iLen++;\
     }\
     else if(pucBuff[iLen+1]&0x80){\
       iLen+=2;\
     }\
   }


#define IFX_DECT_LAU_ENCODE_2BYTEID(nVal,pucBuff,iLen); {\
	  if(nVal <= 0x7F){\
        pucBuff[iLen++] = nVal|0x80;\
	  }\
	  else{\
        pucBuff[iLen++] = nVal >> 7;\
        pucBuff[iLen++] = (nVal & 0x7F) | 0x80;\
	  }\
	 }

	 
void
IFX_DECT_LAU_DbgInfo()
{
  int i,j;
  for(i=0;i<IFX_DECT_MAX_HS;i++){
    for(j=0;j<IFX_DECT_LAU_MAX_SESS_PER_HS;j++){
	  printf("axLauInfo[%d][%d] = %d\n",i,j,axLauInfo[i][j].ucIsUsed);
	}
  }
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeLineNam 
* Description    : Encode Line name
* Input Values   : Command type, editable or not and line name
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeLineNam(IN uchar8 CmdType,
                           IN uint32 uiEditable,
                           IN char8* pLineName,
						   OUT uint16* pPayloadSize,
						   OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" ); 
#if 0
  pDataPayload[size++]=(strlen(pLineName)+1)|0x80;
#else
  IFX_DECT_LAU_ENCODE_2BYTEID((strlen((char8 *)(pLineName))+1),pDataPayload,size);
#endif
  if(((uiEditable) & (IFX_DECT_LAU_LSE_LINENAME)) != 0){
    pDataPayload[size]=0xC0;
  }
  else{
    pDataPayload[size]=0x80;
  }
	if((uiEditable & IFX_DECT_LAU_LSE_LINENAME_PIN) !=0){
		if(pDataPayload[size] == 0xC0)
			pDataPayload[size]|=0x01;
	}
	size++;
  memcpy(&pDataPayload[size],pLineName,strlen((char8 *)(pLineName)));
  size=size+strlen((char8 *)(pLineName));
  *pPayloadSize=size;	  
  printf("\nEXIT...ENCODE LINE NAME");
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeLineId
* Description    : Encode Line Identifier
* Input Values   : Command type, editable or not, command sub type and Line ID
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeLineId(IN uchar8 CmdType,
                          IN uint32 uiEditable,
                          IN uchar8 SubType,
						  IN uchar8 ucLineId,
						  OUT uint16* pPayloadSize,
						  OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
	uchar8 ucLength=0;
  
  pDataPayload[size++]=CmdType;
#if 0
  pDataPayload[size++]=3|0x80;
#else
	ucLength=(SubType != IFX_DECT_STYPE_ALL)?3:2;
  IFX_DECT_LAU_ENCODE_2BYTEID(ucLength,pDataPayload,size);
#endif
  printf("\nENTER...ENCODE LINE ID");
  if(((uiEditable) & (IFX_DECT_LAU_LSE_LINEID)) != 0){
    pDataPayload[size]=0xC0;
  }
  else{
    pDataPayload[size]=0x80;
  }

	if((uiEditable & IFX_DECT_LAU_LSE_LINEID_PIN) !=0){
		if(pDataPayload[size] == 0xC0)
			pDataPayload[size]|=0x01;
		}
	size++;
	printf("Line Sub Type %d\n",SubType);
  pDataPayload[size++]=SubType;
  if(SubType != IFX_DECT_STYPE_ALL){ 
    pDataPayload[size++]=ucLineId|0x80;
  }
  *pPayloadSize=size;
  printf("\nEXIT...ENCODE LINE ID");
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeDateTime 
* Description    : Encode Date and time
* Input Values   : Command type, Time and date Information, Editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeDateTime(IN uchar8 CmdType,
                            IN uint32 uiEditable,
                            IN x_IFX_DECT_USU_TimeDate *pxTimeDate,
							OUT uint16* pPayloadSize,
							OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]= 9|0x80;
  printf("\nENTER...DATE TIME");
  if(uiEditable != 0){
    pDataPayload[size++]=0xC0;
  }
  else{
    pDataPayload[size++]=0x80;
  }
   
  /* TIME and DATE IE from oct 3*/
  pDataPayload[size++] = 0xC0;//octet 3 coding and interpretation
  memcpy(&pDataPayload[size],pxTimeDate,7);
  *pPayloadSize+=11;
  printf("\nEXIT...DATE TIME");
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeNum 
* Description    : Encode number
* Input Values   : Command type, number to encode, if number is editable
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeNum(IN uchar8 CmdType,
                       IN uint32 uiEditable,
					   IN uchar8 ucFlag,
                       IN char8* pNumber,
					   OUT uint16* pPayloadSize,
					   OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=(strlen((char8 *)(pNumber))+1)|0x80;
  printf("\nENTER...ENCODE NUM");
  if(CmdType == IFX_DECT_LAU_INT_NAME_LIST_NUMBER){
	pDataPayload[size++]=0xA0|ucFlag;
  }
  else if(uiEditable != 0){
    pDataPayload[size++]=0xC0|ucFlag;
  }
  else{
    pDataPayload[size++]=0x80|ucFlag;
  }
  memcpy(&pDataPayload[size],pNumber,strlen((char8 *)(pNumber)));
  printf("\nNumber=%s\n",pNumber);
  size=size+strlen((char8 *)(pNumber));
  *pPayloadSize=size;
  printf("\nEXIT...ENCODE NUM");
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeName
* Description    : Encode name
* Input Values   : Command type, name to encode, if name is editable
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeName(IN uchar8 CmdType,
                        IN uint32 uiEditable,
                        IN char8* pName,
						OUT uint16* pPayloadSize,
						OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;

  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=(strlen((char8 *)(pName))+1)|0x80;
  printf("\nENTER...ENCODE NAME");

 if(CmdType==IFX_DECT_LAU_INT_NAME_LIST_NAME){
	printf("\n Edit---%x---Flag %x\n",uiEditable,IFX_DECT_LAU_IL_FNAME);	
		if((IFX_DECT_LAU_IL_FNAME&uiEditable)!=0)
		pDataPayload[size]=0xC0;
		else
		pDataPayload[size]=0x80;

		if(((IFX_DECT_LAU_IL_FNAME_PIN&uiEditable)!=0)&&(pDataPayload[size]==0xC0))
		pDataPayload[size]|=0x01;
	size++;
		}
else if(uiEditable != 0){
    pDataPayload[size++]=0xC0;
  }
  else{
    pDataPayload[size++]=0x80;
  }
  memcpy(&pDataPayload[size],pName,strlen((char8 *)(pName)));
  printf("\nName=%s\n",pName);
  size=size+strlen((char8 *)(pName));
  *pPayloadSize=size;
  printf("\nEXIT...ENCODE NAME");
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeContactFirstName
* Description    : Encode First name
* Input Values   : Command type, first name to encode, if editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeContactFirstName(IN uchar8 CmdType,
                                    IN uint32 uiEditable,
                                    IN char8* pContactFName,
									OUT uint16* pPayloadSize,
									OUT uchar8* pDataPayload)
{	
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=(strlen(pContactFName)+1)|0x80;
  if(uiEditable != 0){
    pDataPayload[size++]=0xC0;
  }
  else{
    pDataPayload[size++]=0x80;
  }
  memcpy(&pDataPayload[size],pContactFName,strlen(pContactFName));
  size=size+strlen(pContactFName);
  *pPayloadSize=size;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeNew
* Description    : Encode New missed call entry
* Input Values   : Command type, New or old, editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeNew(IN uchar8 CmdType,
                       IN uint32 uiEditable,
                       IN uchar8 bNew,
					   OUT uint16* pPayloadSize,
					   OUT uchar8* pDataPayload)

{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=1|0x80;
  printf("\nENTER...ENCODE NEW");
  if(uiEditable != 0){
    pDataPayload[size] = 0xC0;
  }
  else{
    pDataPayload[size] = 0x80;
  }
  if(bNew){
    pDataPayload[size] |= (1<<5);
  }
  size++;
  *pPayloadSize=size;
  printf("\nEXIT...ENCODE NEW");
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeNumberOfCalls
* Description    : Encode Number of calls
* Input Values   : Command type, Number of calls, editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeNumberOfCalls(IN uchar8 CmdType,
                                 IN uint32 uiEditable,
                                 IN uchar8* NoOfCalls,
								 OUT uint16* pPayloadSize,
								 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=2|0x80;
  printf("\nENTER...ENCODE NOCalls");
  if(uiEditable != 0){
    pDataPayload[size++]=0xC0;
  }
  else{
    pDataPayload[size++]=0x80;
  }
  pDataPayload[size++]=*NoOfCalls;
  *pPayloadSize=size;
  printf("\nEXIT...ENCODE NOCalls");
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeMode
* Description    : Encode Mode
* Input Values   : Command type, Mode, editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeMode(IN uchar8 CmdType,
                        IN uint32 uiEditable,
                        IN uchar8 ucMode,
						OUT uint16* pPayloadSize,
						OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=2|0x80;
  if((uiEditable & IFX_DECT_LAU_LSE_CALLMODE) != 0){
    pDataPayload[size]=0xC0;
  }
  else{
    pDataPayload[size]=0x80;
  }
	if((uiEditable & IFX_DECT_LAU_LSE_CALLMODE_PIN) !=0){
		if(pDataPayload[size] == 0xC0)
			pDataPayload[size]|=0x01;
	}
	size++;
  pDataPayload[size++]=ucMode;
  *pPayloadSize=size;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeBlockNumber
* Description    : Encode Block number
* Input Values   : Command type, Number of Block nums,Block nums,editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeBlockNumber(IN uchar8 CmdType,
                               IN uint32 uiEditable,
                               IN uchar8* pBlockNum,
							   OUT uint16* pPayloadSize,
							   OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;

	if(pBlockNum == NULL)
	pDataPayload[size++]=0x81;
	else  
	pDataPayload[size++]=(strlen((char8 *)(pBlockNum))+1)|0x80;

  if((uiEditable & IFX_DECT_LAU_LSE_BLOCKNUM) != 0){
    pDataPayload[size]=0xC0;
  }
  else{
    pDataPayload[size]=0x80;
  }
	if((uiEditable & IFX_DECT_LAU_LSE_BLOCKNUM_PIN) !=0){
		if(pDataPayload[size] == 0xC0)
			pDataPayload[size]|=0x01;
	}
	size++;
  if(pBlockNum != NULL){
	memcpy(&pDataPayload[size],pBlockNum,strlen((char8 *)(pBlockNum)));
  size=size+strlen((char8 *)(pBlockNum));
	}
  *pPayloadSize=size;
}  
/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeDialPrefix
* Description    : Encode Dial Prefix
* Input Values   : Command type, Dial prefix, editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeDialPrefix(IN uchar8 CmdType,
                              IN uint32 uiEditable,
                              IN uchar8 ucDialPrefix,
							  OUT uint16* pPayloadSize,
							  OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=2|0x80;
  if((uiEditable & IFX_DECT_LAU_LSE_DIALPREFIX) != 0){
    pDataPayload[size]=0xC0;
  }
  else{
    pDataPayload[size]=0x80;
  }
	if((uiEditable & IFX_DECT_LAU_LSE_DIALPREFIX_PIN) != 0){
		if(pDataPayload[size] == 0xC0)
			pDataPayload[size]|=0x01;
	}
	size++;
  pDataPayload[size++]=ucDialPrefix;
  *pPayloadSize=size;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeCallForward
* Description    : Encode Call forward
* Input Values   : Command type,editable or not, Fwd type, Fwd num
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeCallForward(IN uchar8 CmdType,
                               IN uint32 uiEditable,
                               IN x_IFX_DECT_LAU_CFInfo *pxCFInfo,
							                 OUT uint16* pPayloadSize,
							                 OUT uchar8*pDataPayload)
{
  uint16 size=*pPayloadSize,nEntrySize,nLen;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Entry" ); 
  pDataPayload[size++]=CmdType;
  nEntrySize = size;
  printf("\n CallForward Entry.\n");

  /*Leave 2 octets for encoding length.*/
  size+=2;

  if(CmdType == IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_U){
		if(((uiEditable) & (IFX_DECT_LAU_LSE_CFU)) != 0){
    	pDataPayload[size]=0xC0;
  	}
  	else{
    	pDataPayload[size]=0x80;
  	}
	}
	else if(CmdType == IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_N){
		if(((uiEditable) & (IFX_DECT_LAU_LSE_CFN)) != 0){
    	pDataPayload[size]=0xC0;
  	}
  	else{
    	pDataPayload[size]=0x80;
  	}
	}
	else if(CmdType == IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_B){
		if(((uiEditable) & (IFX_DECT_LAU_LSE_CFB)) != 0){
    	pDataPayload[size]=0xC0;
  	}
  	else{
    	pDataPayload[size]=0x80;
  	}
	}
  if(CmdType == IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_U){
		if(((uiEditable) & (IFX_DECT_LAU_LSE_CFU_PIN)) !=0){
			if(pDataPayload[size] == 0xC0)
				pDataPayload[size] |= 0x01;
		}
	}
  else if(CmdType == IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_N){
    if(((uiEditable) & (IFX_DECT_LAU_LSE_CFN_PIN)) !=0){
			if(pDataPayload[size] == 0xC0)
    		pDataPayload[size] |= 0x01;
    }
  }
  else if(CmdType == IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_B){
    if(((uiEditable) & (IFX_DECT_LAU_LSE_CFB_PIN)) !=0){
			if(pDataPayload[size] == 0xC0)
    		pDataPayload[size] |= 0x01;
    }
  }
	size++;

  /* Encode Value */
  pDataPayload[size++] = (pxCFInfo->ucStatus == 0)?IFX_DECT_LAU_CF_OFF :pxCFInfo->ucStatus;

  /* If call Forward no ans update no of secs */
  if(CmdType == IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_N){
      pDataPayload[size++]=pxCFInfo->ucNoOfSec;
  }

  /* Populate Activation code if present else set length to 0. */
  pDataPayload[size++] = strlen((char8 *)(pxCFInfo->acCFAct));
  if(strlen(((char8 *)pxCFInfo->acCFAct)) != 0){ 
    printf("\nAct code present.\n");
    memcpy(&pDataPayload[size],pxCFInfo->acCFAct,strlen((char8 *)(pxCFInfo->acCFAct)));
    size=size+strlen((char8 *)(pxCFInfo->acCFAct));
  } 

  /* Populate Deactivation code if present, else set length to 0 */
  pDataPayload[size++]=strlen((char8 *)(pxCFInfo->acCFDeAct));
  if(strlen((char8 *)(pxCFInfo->acCFDeAct)) != 0){
    printf("\nDeAct code present.\n");
    memcpy(&pDataPayload[size],pxCFInfo->acCFDeAct,strlen((char8 *)(pxCFInfo->acCFAct)));
    size=size+strlen((char8 *)(pxCFInfo->acCFDeAct));
  }
 
  /* Populate number if present */
  printf("\nCall Forward Number.\n");
  pDataPayload[size++]=strlen((char8 *)(pxCFInfo->ucCFNum));
  if(strlen((char8 *)(pxCFInfo->ucCFNum)) != 0){
    memcpy(&pDataPayload[size],pxCFInfo->ucCFNum,strlen((char8 *)(pxCFInfo->ucCFNum)));
    size=size+strlen((char8 *)(pxCFInfo->ucCFNum));
  }

  /* Encode the length */
  if((size-(nEntrySize+2)) <= 127){
    memmove(&pDataPayload[nEntrySize+1],&pDataPayload[nEntrySize+2],(size-(nEntrySize+2)));
    size--;
    nLen = (size-(nEntrySize+1));
  }
  else{
    nLen = (size-(nEntrySize+2));
  }
  IFX_DECT_LAU_ENCODE_2BYTEID(nLen,pDataPayload,nEntrySize);
  *pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Exit" ); 
  printf("\nCall Forward Exit.\n");
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodePCLIR
* Description    : Encode CLIR
* Input Values   : Command type, CLIR statsu, code, editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodePCLIR(IN uchar8 CmdType,
                         IN uint32 uiEditable,
                         IN uchar8 CLIRStatus,
						 IN uchar8* pCLIRCode,
							IN uchar8* pCLIRDeactCode,
						 OUT uint16* pPayloadSize,
						 OUT uchar8*pDataPayload)
{
  uint16 size=*pPayloadSize;

  pDataPayload[size++]=CmdType;
	//if((strlen(pCLIRCode)+strlen(pCLIRDeactCode))!=0){
  if(CLIRStatus!=0){
    pDataPayload[size++]=(strlen((char8 *)(pCLIRCode))+4+strlen((char8 *)(pCLIRDeactCode)))|0x80;
  }else{
    pDataPayload[size++]=0x81;
   }
	//ucflag=1;
	//}
	//else{
	 //pDataPayload[size++]=0x82;	
		//}
  if(((uiEditable) & (IFX_DECT_LAU_LSE_CLIR)) != 0){
    pDataPayload[size]=0xC0;
  }
  else{
    pDataPayload[size]=0x80;
  }
	if((uiEditable & IFX_DECT_LAU_LSE_CLIR_PIN) !=0){
		if(pDataPayload[size] == 0xC0)
			pDataPayload[size]|=0x01;
	}
	size++;
  pDataPayload[size++] = (CLIRStatus == 0)? IFX_DECT_LAU_CLIR_DEACTIVATE :CLIRStatus;
  
  /*Populate Activation code if present, else set length to 0*/
	pDataPayload[size++]=strlen((char8 *)(pCLIRCode));
	if(strlen((char8 *)(pCLIRCode))!=0){
  memcpy(&pDataPayload[size],pCLIRCode,strlen((char8 *)(pCLIRCode)));
  size=size+strlen((char8 *)(pCLIRCode));
	}
  /*Populate Deactivation code if present, else set length to 0*/
	pDataPayload[size++]=strlen((char8 *)(pCLIRDeactCode));
	if(strlen((char8 *)(pCLIRDeactCode))!=0){
	 memcpy(&pDataPayload[size],pCLIRDeactCode,strlen((char8 *)(pCLIRDeactCode)));
  size=size+strlen((char8 *)(pCLIRDeactCode));
	}
  *pPayloadSize=size;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeVolume
* Description    : Encode Volume
* Input Values   : Command type, Number of calls, editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeVolume(IN uchar8 CmdType,
                          IN uint32 uiEditable,
                          IN uchar8 ucVol,
						  OUT uint16* pPayloadSize,
						  OUT uchar8*pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=2|0x80;
  if((uiEditable & IFX_DECT_LAU_LSE_VOL) != 0){
    pDataPayload[size]=0xC0;
  }
  else{
    pDataPayload[size]=0x80;
  }
	if((uiEditable & IFX_DECT_LAU_LSE_VOL_PIN) !=0){
		if(pDataPayload[size] == 0xC0)
			pDataPayload[size]|=0x01;
	}
	size++;
  pDataPayload[size++]=ucVol;
  *pPayloadSize=size;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeAssocMelody
* Description    : Encode Associated melody
* Input Values   : Command type, Melody, editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeAssocMelody(IN uchar8 CmdType,
                               IN uint32 uiEditable,
							   IN uchar8 ucMelody,
							   OUT uint16* pPayloadSize,
							   OUT uchar8*pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=2|0x80;
  if((uiEditable & IFX_DECT_LAU_LSE_ASCMEL) !=0){
    pDataPayload[size]=0xC0;
  }
  else{
	pDataPayload[size]=0x80;
  }

	if((uiEditable & IFX_DECT_LAU_LSE_ASCMEL_PIN) !=0){
		if(pDataPayload[size] == 0xC0)
			pDataPayload[size]|=0x01;
	}
	size++;
  pDataPayload[size++]=ucMelody;
  *pPayloadSize=size;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeAttachedPP
* Description    : Encode Attached PPs
* Input Values   : Command type, Number of PPs, Attached PPs, editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeAttachedPP(IN uchar8 CmdType,
                              IN uint32 uiEditable,
                              IN uchar8 NoOfPP,
							  IN uchar8* pAttachedPP ,
							  OUT uint16* pPayloadSize,
							  OUT uchar8* pDataPayload)
{
  uchar8 i=0;
  uint16 size=*pPayloadSize,nLenLoc,nNumPP=0;

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Entry" ); 
	printf("Line Settings Editable------%x\n",uiEditable);
	printf("Flag Editable for Attached PP---%x\n",IFX_DECT_LAU_LSE_ATCHPP);

  pDataPayload[size++]=CmdType;
  nLenLoc=size;
  pDataPayload[size++]=2|0x80;

  if((uiEditable & IFX_DECT_LAU_LSE_ATCHPP) != 0){
    pDataPayload[size]=0xC0;
  }else{
	  pDataPayload[size]=0x80;
   }
  
	if((uiEditable & IFX_DECT_LAU_LSE_ATCHPP_PIN) !=0){
		if(pDataPayload[size] == 0xC0)
			pDataPayload[size] |= 0x01;
	}
	size++;
	pDataPayload[size++]=NoOfPP|0x80;
  if(NoOfPP == 0){
    *pPayloadSize=size;
    return;
  }
  pDataPayload[size]=0x80;
  pDataPayload[nLenLoc] += 1;
  for(i=0;i<IFX_DECT_LAU_MAX_HS;i++){

   if(pAttachedPP[i] == 1){

    if(i>=7){
      pDataPayload[size] &= 0x7F;
      pDataPayload[size+1] |= ((1<<(i%7)) | 0x80);
    }else{
      pDataPayload[size] |= ((1<<(i%7)) | 0x80);
     }

    nNumPP++;
   }
   if(nNumPP==NoOfPP) break;
  }
  if((pDataPayload[size] & 0x80) == 0){
    pDataPayload[nLenLoc] += 1;
    size++;
  }
  size++;
  for(i=*pPayloadSize;i<size;i++){
    printf("%x\t",pDataPayload[i]);
  }
  printf("\n");
 *pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Exit" ); 
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeCalltype
* Description    : Encode Call type
* Input Values   : Command type, Call type, editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeCalltype(IN uchar8 CmdType,
                            IN uint32 uiEditable,
							IN uchar8 *CallType,
							OUT uint16* pPayloadSize,
							OUT uchar8* pDataPayload)
{
   uint16 size=*pPayloadSize;
   pDataPayload[size++]=CmdType;
   pDataPayload[size++]=1|0x80;
   switch(*CallType){
     case IFX_DECT_LAU_CALL_LIST_TYPE_MISSED:
     {
       pDataPayload[size]=1<<5|0x80;
       size++;
       break;
     }
     case IFX_DECT_LAU_CALL_LIST_TYPE_ACCEPTED:
     {
       pDataPayload[size]=1<<4|0x80;
       size++;
       break;
     }
     case IFX_DECT_LAU_CALL_LIST_TYPE_OUTGOING:
     {
       pDataPayload[size]=1<<3|0x80;
       size++;
       break;
     }
  }
  if(uiEditable!=0){
    pDataPayload[size-1] |= 0x80|(1<<6);
  }
  *pPayloadSize=size;
}
/*System settings encode and decode */
void 
IFX_DECT_LAU_EncodeClockMaster(IN uchar8 CmdType,IN uint32 uiEditable,
							   IN uchar8 pClockmaster,OUT uint16* pPayloadSize,
							   OUT uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;

  printf("\n Encode Clock Master Entry\n");
	pDataPayload[size++]=CmdType;
	pDataPayload[size++]=2|0x80;
	if((uiEditable & IFX_DECT_LAU_SSE_CLKMSTR)  != 0){
	 pDataPayload[size]=0xC0;
	}
	else{
	 pDataPayload[size]=0x80;
	}
	if((IFX_DECT_LAU_SSE_CLKMSTR_PIN & uiEditable) !=0){
		if(pDataPayload[size]==0xC0)
			pDataPayload[size]|=0x01;
	}
	size++;
	pDataPayload[size++]=pClockmaster;
	*pPayloadSize=size;
  printf("\n Encode Clock Master Exit\n");
}
void 
IFX_DECT_LAU_EncodeBaseReset(IN uchar8 CmdType,IN uint32 uiEditable,
				             IN uchar8 pBasereset,OUT uint16* pPayloadSize,
					         OUT uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
  printf("\n Encode Base Reset Entry\n");
	pDataPayload[size++]=CmdType;
	pDataPayload[size++]=2|0x80;
	if((uiEditable & IFX_DECT_LAU_SSE_BASERESET) != 0){
	 pDataPayload[size]=0xC0;
    }
    else{
     pDataPayload[size]=0x80;
    }

	if((IFX_DECT_LAU_SSE_BASERESET_PIN & uiEditable) !=0){
		if(pDataPayload[size]==0xC0)
			pDataPayload[size]|=0x01;
	}
	size++;
	pDataPayload[size++]=pBasereset;
	*pPayloadSize=size;
  printf("\n Encode Base Reset Exit\n");
}	
void
IFX_DECT_LAU_EncodeIPaddress(IN uchar8 CmdType,IN uint32 uiEditable,
							 IN uchar8 pIPaddress,OUT uint16* pPayloadSize,
							 OUT uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	pDataPayload[size++]=CmdType;
	pDataPayload[size++]=1|0x80;
	if( pIPaddress == IFX_DECT_LAU_FP_ADD_CFG_DHCP){
		pDataPayload[size++]=1<<6;
	}
	else{
	 pDataPayload[size++]=1<<5;
	}
	if((uiEditable & IFX_DECT_LAU_SSE_BASEIPCFG) !=0){
	 pDataPayload[size-1]|=0xC0;
	}else{
	 pDataPayload[size-1]|=0x80;
	}

	if((IFX_DECT_LAU_SSE_BASEIPCFG_PIN & uiEditable) !=0){
		if(pDataPayload[size-1]==0xC0)
			pDataPayload[size-1]|=0x01;
	}
		  
	*pPayloadSize=size;
}
void
IFX_DECT_LAU_EncodeIPaddressVal(IN uchar8 CmdType,IN uint32 uiEditable,
								IN x_IFX_DECT_LAU_IP_Address* pIpval,
								OUT uint16* pPayloadSize,
								OUT uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	pDataPayload[size++]=CmdType;
	if(pIpval->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6){
	 pDataPayload[size++]=(strlen(pIpval->uxIPAddress.cIPv6Address)+1)|0x80;
	}
	else{
	 pDataPayload[size++]=(strlen(pIpval->uxIPAddress.cIPv4Address)+1)|0x80;
	}
	if(pIpval->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6){
	 pDataPayload[size++]=1<<5;
	}
	else{
	 pDataPayload[size++]=0;
	}
	if((uiEditable & IFX_DECT_LAU_SSE_BASEIP) !=0){
	 pDataPayload[size-1] |= 0xC0;
	}else{
	 pDataPayload[size-1] |= 0x80;
	}
  if((IFX_DECT_LAU_SSE_BASEIP_PIN & uiEditable) !=0){
    if((pDataPayload[size-1]==0xC0))
      pDataPayload[size-1]|=0x01;
  }

	if(pIpval->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6){
	 memcpy(&pDataPayload[size],pIpval->uxIPAddress.cIPv6Address,
	 		strlen(pIpval->uxIPAddress.cIPv6Address));
	 size=size+strlen(pIpval->uxIPAddress.cIPv6Address);
	}
	else{
	 memcpy(&pDataPayload[size],pIpval->uxIPAddress.cIPv4Address,
	 		strlen(pIpval->uxIPAddress.cIPv4Address));
	 size=size+strlen(pIpval->uxIPAddress.cIPv4Address);
	}
	 *pPayloadSize=size;
}

void
IFX_DECT_LAU_EncodeSubnetMask(IN uchar8 CmdType,IN uchar8 uiEditable,
							  IN x_IFX_DECT_LAU_SubnetMask *pSubnet,
	                          OUT uint16* pPayloadSize,OUT uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	pDataPayload[size++]=CmdType;
	if(pSubnet->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6){
	 pDataPayload[size++]=(strlen(pSubnet->uxIPAddress.cIPv6Address)+1)|0x80;
	}
	else{
	 pDataPayload[size++]=(strlen(pSubnet->uxIPAddress.cIPv4Address)+1)|0x80;
	}
	if(pSubnet->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6){
		 pDataPayload[size++]=1<<5;
	}
	else{
	 	pDataPayload[size++]=0;
	}
	if((uiEditable&IFX_DECT_LAU_SSE_BASESUBNET)!=0){
	     pDataPayload[size-1] |= 0xC0;
	}else{
		 pDataPayload[size-1] |= 0x80;
	}
  if((IFX_DECT_LAU_SSE_BASESUBNET_PIN & uiEditable) !=0){
    if((pDataPayload[size-1]==0xC0))
      pDataPayload[size-1]|=0x01;
  }
	if(pSubnet->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6){
	   memcpy(&pDataPayload[size],pSubnet->uxIPAddress.cIPv6Address,
	   strlen(pSubnet->uxIPAddress.cIPv6Address));
	   size=size+strlen(pSubnet->uxIPAddress.cIPv6Address);
	}
	else{
		memcpy(&pDataPayload[size],pSubnet->uxIPAddress.cIPv4Address,
			   strlen(pSubnet->uxIPAddress.cIPv4Address));
	    size=size+strlen(pSubnet->uxIPAddress.cIPv4Address);
	}
	 *pPayloadSize=size;
}	 
	 

void 
IFX_DECT_LAU_EncodeGateway(IN uchar8 CmdType,IN uchar8 uiEditable,
						     IN x_IFX_DECT_LAU_GwAddress* pGatewayAddr,
						     OUT uint16* pPayloadSize,
						     OUT uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	pDataPayload[size++]=CmdType;
	if(pGatewayAddr->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6 ){
	 pDataPayload[size++]=(strlen(pGatewayAddr->uxIPAddress.cIPv6Address)+1)|0x80;
	}
	else{
	 pDataPayload[size++]=(strlen(pGatewayAddr->uxIPAddress.cIPv4Address)+1)|0x80;
	}
	if( pGatewayAddr->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6 ){
	 pDataPayload[size++]=1<<5;
	}
	else{
	 pDataPayload[size++]=0;
	}
	if((uiEditable&IFX_DECT_LAU_SSE_BASEGW) != 0){
	  pDataPayload[size-1] |= 0xC0;
	}else{
	  pDataPayload[size-1] |= 0x80;
	}
  if((IFX_DECT_LAU_SSE_BASEGW_PIN & uiEditable) !=0){
    if(pDataPayload[size-1]==0xC0)
      pDataPayload[size-1]|=0x01;
  }
	if( pGatewayAddr->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6 ){
	  memcpy(&pDataPayload[size],pGatewayAddr->uxIPAddress.cIPv6Address,
	  	 	 strlen(pGatewayAddr->uxIPAddress.cIPv6Address));
	  size=size+strlen(pGatewayAddr->uxIPAddress.cIPv6Address);
	}
	else{
	 memcpy(&pDataPayload[size],pGatewayAddr->uxIPAddress.cIPv4Address,
	        strlen(pGatewayAddr->uxIPAddress.cIPv4Address));
	 size=size+strlen(pGatewayAddr->uxIPAddress.cIPv4Address);
	}
	*pPayloadSize=size;
}
void
IFX_DECT_LAU_EncodeDNSServer(IN uchar8 CmdType,
                            IN uchar8 uiEditable,
						    IN x_IFX_DECT_LAU_DNSServer *pDNSServer,
							OUT uint16* pPayloadSize,
							OUT uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	pDataPayload[size++]=CmdType;
	if( pDNSServer->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6 ){
	 pDataPayload[size++]=(strlen(pDNSServer->uxIPAddress.cIPv6Address)+1)|0x80;
	}
	else{
	 pDataPayload[size++]=(strlen(pDNSServer->uxIPAddress.cIPv4Address)+1)|0x80;
	}
	if( pDNSServer->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6 ){
	 pDataPayload[size++]=1<<5;
	}
	else{
	 pDataPayload[size++]=0;
	}
	if((uiEditable&IFX_DECT_LAU_SSE_BASEDNS) != 0){
	 pDataPayload[size-1] |= 0xC0;
	}else{
	  pDataPayload[size-1] |= 0x80;
	}
  if((IFX_DECT_LAU_SSE_BASEDNS_PIN & uiEditable) !=0){
    if(pDataPayload[size-1]==0xC0)
      pDataPayload[size-1]|=0x01;
  }
	if( pDNSServer->cIPAddType == IFX_DECT_LAU_FP_ADD_TYPE_IPV6 ){
	 memcpy(&pDataPayload[size],pDNSServer->uxIPAddress.cIPv6Address,strlen(pDNSServer->uxIPAddress.cIPv6Address));
	 size=size+strlen(pDNSServer->uxIPAddress.cIPv6Address);
	}
	else{
	 memcpy(&pDataPayload[size],pDNSServer->uxIPAddress.cIPv4Address,strlen(pDNSServer->uxIPAddress.cIPv4Address));
	 size=size+strlen(pDNSServer->uxIPAddress.cIPv4Address);
	}
	*pPayloadSize=size;
			
}
void
IFX_DECT_LAU_EncodeFirmwareVersion(IN uchar8 CmdType,
				                   IN uchar8 uiEditable,
				   				   IN uchar8* pfirmwarever,
								   OUT uint16* pPayloadSize,
								   OUT uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
  printf("\n Encode FW Version Entry\n");
	pDataPayload[size++]=CmdType;
	pDataPayload[size++]=(strlen((char8 *)(pfirmwarever))+1)|0x80;
  pDataPayload[size++]=0x80;
	memcpy(&pDataPayload[size],pfirmwarever,strlen((char8 *)(pfirmwarever)));
	size=size+strlen((char8 *)(pfirmwarever));
	*pPayloadSize=size;
  printf("\n Encode Base Reset Exit\n");
}
void
IFX_DECT_LAU_EncodeEpromVersion(IN uchar8 CmdType,
                                IN uchar8 uiEditable,
								IN uchar8* pEpromver,
								OUT uint16* pPayloadSize,
								OUT uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	pDataPayload[size++]=CmdType;
	pDataPayload[size++]=(strlen((char8 *)(pEpromver))+1)|0x80;
	pDataPayload[size++] = 0x80;
	memcpy(&pDataPayload[size],pEpromver,strlen((char8 *)(pEpromver)));
	size=size+strlen((char8 *)(pEpromver));
	*pPayloadSize=size;
}
void
IFX_DECT_LAU_EncodeHardwarever(IN uchar8 CmdType,
							   IN uchar8 uiEditable,
							   IN uchar8* pHardwarever,
							   OUT uint16* pPayloadSize,
							   OUT uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	pDataPayload[size++]=CmdType;
	pDataPayload[size++]=(strlen((char8 *)(pHardwarever))+1)|0x80;
  pDataPayload[size++] = 0x80;
	memcpy(&pDataPayload[size],pHardwarever,strlen((char8 *)(pHardwarever)));
	size=size+strlen((char8 *)(pHardwarever));
	*pPayloadSize=size;
	
}
void
IFX_DECT_LAU_EncodePinCode(IN uchar8 CmdType,IN uint32 uiEditable,
               IN uchar8 *pPinCode,OUT uint16* pPayloadSize,
               OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  uchar8 i;
  printf("\n Encode PIN Entry\n");
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=5|0x80;
  if(CmdType == IFX_DECT_LAU_SYS_SET_LIST_PIN){
	pDataPayload[size++]=0xC0;
	}
	else{
	pDataPayload[size++]=0xC1;
	}
  for(i=0;i<4;i++){
  pDataPayload[size++]= 0xFF;
  }
  *pPayloadSize=size;
  printf("\n Encode PIN Exit\n");
}


void
IFX_DECT_LAU_DecodePin(OUT char8* pPIN,IN uint16* pPayloadSize,IN uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  uint16 field_length=(pDataPayload[size++]& 0x7F)-1;
  size++;

  for(;field_length>0;field_length--){
   if((pDataPayload[size] & 0xFF) == 0xFF){
     size++;
   }else if((pDataPayload[size] & 0xF0) == 0xF0){
     *pPIN = (pDataPayload[size++] & 0x0F)+48;
      pPIN++;
    }else{
     break;
     }
  }
  for(;field_length>0;field_length--){
   *pPIN = ((pDataPayload[size] & 0xF0) >> 4)+48;
   pPIN++;
   *pPIN = (pDataPayload[size] & 0x0F) +48;
   pPIN++;
   size++;
  }
  printf("\n PIN CODE:%x\n",*pPIN);
  *pPayloadSize=size;
}

void
IFX_DECT_LAU_EncodeEmissionMode(IN uchar8 CmdType,IN uint32 uiEditable,
               IN uchar8 ucNEM,OUT uint16* pPayloadSize,
               OUT uchar8* pDataPayload)
{

  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=2|0x80;
  if((uiEditable&IFX_DECT_LAU_SSE_NEM)!= 0){
    pDataPayload[size]=0xC0;
  }
  else{
  pDataPayload[size]=0x80;
  }
  if((uiEditable&IFX_DECT_LAU_SSE_NEM_PIN) != 0){
		if( pDataPayload[size]==0xC0)
    pDataPayload[size]|=0x01;
  }
	size++;
  pDataPayload[size++]= ucNEM | 0x80;
  *pPayloadSize = size;
}

void
IFX_DECT_LAU_DecodeEmissionMode(OUT uchar8* pNEM,
                               IN uint16* pPayloadSize,
                               IN uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;

  size += 2;
  /* Decode the Mode :Bit1 */
  *pNEM=pDataPayload[size++] & 0x01;
  /* Update the Size */
  *pPayloadSize=size;
}
void
IFX_DECT_LAU_EncodeCallIntercept(IN uchar8 CmdType,IN uint32 uiEditable,
                 IN uchar8 ucCallIntercept,OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=2|0x80;
  if((uiEditable & IFX_DECT_LAU_IL_INTERCEPTION) != 0){
   pDataPayload[size]=0xC0;
  }
  else{
   pDataPayload[size]=0x80;
  }
	  if(((uiEditable & IFX_DECT_LAU_IL_INTERCEPTION_PIN) != 0)&&( pDataPayload[size]==0xC0))
			pDataPayload[size]|=0x01;			
	size++;
  pDataPayload[size++]=ucCallIntercept;
  *pPayloadSize=size;
}

void
IFX_DECT_LAU_DecodeCallIntercept(OUT uchar8 *pCallIntercept,
                                 IN uint16* pPayloadSize,
                                 IN uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  size=size+2;
  *pCallIntercept=pDataPayload[size++];
  *pPayloadSize=size;
}


void
IFX_DECT_LAU_EncodeIntrusionCall(IN uchar8 CmdType,IN uint32 uiEditable,
                 IN uchar8 ucIntrusionCall,OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=2|0x80;
  if((uiEditable & IFX_DECT_LAU_LSE_INTR) != 0){
   pDataPayload[size]=0xC0;
  }
  else{
   pDataPayload[size]=0x80;
  }
	if(((uiEditable & IFX_DECT_LAU_LSE_INTR_PIN)!=0)&&(pDataPayload[size]==0xC0)){
   pDataPayload[size]|=0x01;
  }
	size++;
  pDataPayload[size++]=ucIntrusionCall;
  *pPayloadSize=size;
}

void
IFX_DECT_LAU_DecodeIntrusionCall(OUT uchar8 *pIntrusionCall,
                                 IN uint16* pPayloadSize,
                                 IN uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  size=size+2;
  *pIntrusionCall=pDataPayload[size++];
  *pPayloadSize=size;
}



void 
IFX_DECT_LAU_DecodeClockMaster(OUT char8 *pClockVal,IN uint16* pPayloadSize,IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	size=size+2;
	*pClockVal=pDataPayload[size++];
	*pPayloadSize=size;
}
void
IFX_DECT_LAU_DecodeBaseReset(OUT char8* pBaseReset,IN uint16* pPayloadSize,IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	size=size+2;
	*pBaseReset=pDataPayload[size++];
	*pPayloadSize=size;
}
	
void
IFX_DECT_LAU_DecodeIPtype(OUT char8* pIPtype,IN uint16* pPayloadSize,IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	uint32 ip_type;
	//uint16 field_length=(pDataPayload[size++] ^ 0x80)-1;
	size++;
	
	ip_type=pDataPayload[size] ^ 0x80;
	if(ip_type & 1<<5){ 
	 *pIPtype=IFX_DECT_LAU_FP_ADD_CFG_DHCP;
	}
	else if (ip_type & 1<<4){ 
	 *pIPtype=IFX_DECT_LAU_FP_ADD_CFG_STATIC;
	}
	size++;
	*pPayloadSize=size;
}
void
IFX_DECT_LAU_DecodeFirmwarever(OUT char8* pFirmwarever,IN uint16* pPayloadSize,IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	uint16 field_len=(pDataPayload[size]& 0x7F)-1;
	size=size+2;
	memcpy(pFirmwarever,&pDataPayload[size],field_len);
	size=size+field_len;
	*pPayloadSize=size;
}

void
IFX_DECT_LAU_DecodeEpromver(OUT char8* pEpromver,IN uint16* pPayloadSize,IN uchar8* pDataPayload)
{
    uint16 size=*pPayloadSize;
	uint16 field_len=(pDataPayload[size]& 0x7F)-1;
	size=size+2;
	memcpy(pEpromver,&pDataPayload[size],field_len);
	size=size+field_len;
	*pPayloadSize=size;
}	
void
IFX_DECT_LAU_DecodeHardwarever(OUT char8* pHardwarever,IN uint16* pPayloadSize,IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	uint16 field_len=(pDataPayload[size]& 0x7F)-1;
	size=size+2;
	memcpy(pHardwarever,&pDataPayload[size],field_len);
	size=size+field_len;
	*pPayloadSize=size;
						
}
void
IFX_DECT_LAU_DecodeIPval(OUT x_IFX_DECT_LAU_IP_Address* pIPAddress,IN uint16* pPayloadSize,IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	uint16 field_len=(pDataPayload[size++]& 0x7F)-1;
	uint16 ip_type= pDataPayload[size] ^ 0x40;
	size++;
	if(ip_type & (1<<5)){
	 pIPAddress->cIPAddType=IFX_DECT_LAU_FP_ADD_TYPE_IPV6;
	 memcpy(pIPAddress->uxIPAddress.cIPv6Address,&pDataPayload[size],field_len);
	 size=size+field_len;
	}
	else{
	 pIPAddress->cIPAddType=IFX_DECT_LAU_FP_ADD_TYPE_IPV4;
	 memcpy(pIPAddress->uxIPAddress.cIPv4Address,&pDataPayload[size],field_len);
	 size=size+field_len;
	}
	*pPayloadSize=size;
}

void
IFX_DECT_LAU_DecodeSubnet(OUT x_IFX_DECT_LAU_SubnetMask* pSubnet,IN uint16* pPayloadSize,IN uchar8* pDataPayload)
{
    uint16 size=*pPayloadSize;
	uint16 field_len=(pDataPayload[size++]& 0x7F)-1;
	uint16 ip_type=pDataPayload[size] ^ 0x40;
	size++;
	if(ip_type & (1<<5)){
	 pSubnet->cIPAddType=IFX_DECT_LAU_FP_ADD_TYPE_IPV6;
	 memcpy(pSubnet->uxIPAddress.cIPv6Address,&pDataPayload[size],field_len);
	 size=size+field_len;
	}
	else{
	 pSubnet->cIPAddType=IFX_DECT_LAU_FP_ADD_TYPE_IPV4;
	 memcpy(pSubnet->uxIPAddress.cIPv4Address,&pDataPayload[size],field_len);
	 size=size+field_len;
    }
	*pPayloadSize=size;
}
void
IFX_DECT_LAU_DecodeGWAddress(OUT x_IFX_DECT_LAU_GwAddress* pGateWay,IN uint16* pPayloadSize,IN uchar8* pDataPayload)
{
    uint16 size=*pPayloadSize;
	uint16 field_len=(pDataPayload[size++]& 0x7F)-1;
	uint16 ip_type=pDataPayload[size] ^ 0x40;
	size++;
    if(ip_type & (1<<5)){
	 pGateWay->cIPAddType=IFX_DECT_LAU_FP_ADD_TYPE_IPV6;
	 memcpy(pGateWay->uxIPAddress.cIPv6Address,&pDataPayload[size],field_len);
	 size=size+field_len;
    }
	else{
	 pGateWay->cIPAddType=IFX_DECT_LAU_FP_ADD_TYPE_IPV4;
	 memcpy(pGateWay->uxIPAddress.cIPv4Address,&pDataPayload[size],field_len);
	 size=size+field_len;
	}
	*pPayloadSize=size;
}


void
IFX_DECT_LAU_DecodeDNSServer(OUT x_IFX_DECT_LAU_DNSServer* pDNSserver,IN uint16* pPayloadSize,
							 IN uchar8* pDataPayload)
{
    uint16 size=*pPayloadSize;
	uint16 field_len=(pDataPayload[size++]& 0x7F)-1;
	uint16 ip_type=pDataPayload[size] ^ 0x40;
	size++;
	if(ip_type & (1<<5)){
	 pDNSserver->cIPAddType=IFX_DECT_LAU_FP_ADD_TYPE_IPV6;
	 memcpy(pDNSserver->uxIPAddress.cIPv4Address,&pDataPayload[size],field_len);
	 size=size+field_len;
	}
	else{
	 pDNSserver->cIPAddType=IFX_DECT_LAU_FP_ADD_TYPE_IPV4;
	 memcpy(pDNSserver->uxIPAddress.cIPv4Address,&pDataPayload[size],field_len);
	 size=size+field_len;
	}
	*pPayloadSize=size;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeSystemSetting
* Description    : Encode Line setting entry
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_EncodeSystemSetting(IN int16 nSessId,
                               IN uchar8 ucHSId,
                               IN x_IFX_DECT_LAU_SystemSettingsList* pSystemSettingList,
						       OUT uint16* punPayloadSize,
						       OUT uchar8* pucDataPayload)
{
  uchar8 entry_size=0;
  uchar8 j=0;
  uint16 size =0;
  int16 nId; 
  /*Entry Identifier*/
  pucDataPayload[size++]=1|0x80;
  entry_size=size;
  /* 2 bytes left for length*/
  size += 2;
  j=0;
  while(j < IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE && axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
    switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
      case IFX_DECT_LAU_SYS_SET_LIST_PIN:
	     IFX_DECT_LAU_EncodePinCode(IFX_DECT_LAU_SYS_SET_LIST_PIN,
		                            (pSystemSettingList->uiEditField),
								    ((uchar8 *)pSystemSettingList->acPIN),&size,pucDataPayload);
	     break;
	  case IFX_DECT_LAU_SYS_SET_LIST_CLOCK_MASTER:
			IFX_DECT_LAU_EncodeClockMaster(IFX_DECT_LAU_SYS_SET_LIST_CLOCK_MASTER,
										  (pSystemSettingList->uiEditField),
										  pSystemSettingList->cClockMaster,&size,pucDataPayload);
        break;
	  case IFX_DECT_LAU_SYS_SET_LIST_BASE_RESET:
		    IFX_DECT_LAU_EncodeBaseReset(IFX_DECT_LAU_SYS_SET_LIST_BASE_RESET,
										(pSystemSettingList->uiEditField),
										pSystemSettingList->cBaseReset,&size,pucDataPayload);
        break;
	  case IFX_DECT_LAU_SYS_SET_LIST_IPADD_TYPE:
			IFX_DECT_LAU_EncodeIPaddress(IFX_DECT_LAU_SYS_SET_LIST_IPADD_TYPE,
											  (pSystemSettingList->uiEditField),
											  pSystemSettingList->cBaseIPAddCfg,&size,pucDataPayload);
       break;
	 case IFX_DECT_LAU_SYS_SET_LIST_IPADD_VALUE:
			 IFX_DECT_LAU_EncodeIPaddressVal(IFX_DECT_LAU_SYS_SET_LIST_IPADD_VALUE,
			 								(pSystemSettingList->uiEditField),
										    &pSystemSettingList->xBaseIPAdd,&size,pucDataPayload);
	  break;
	case IFX_DECT_LAU_SYS_SET_LIST_IPADD_SUBNET:
			 IFX_DECT_LAU_EncodeSubnetMask(IFX_DECT_LAU_SYS_SET_LIST_IPADD_SUBNET,
			 							  (pSystemSettingList->uiEditField),
										  &pSystemSettingList->xBaseSubnetMask,&size,pucDataPayload);
     break;
   case IFX_DECT_LAU_SYS_SET_LIST_IPADD_GW:
			 IFX_DECT_LAU_EncodeGateway(IFX_DECT_LAU_SYS_SET_LIST_IPADD_GW,
			 						   (pSystemSettingList->uiEditField),
									   &pSystemSettingList->xBaseGwIPAdd,&size,pucDataPayload);
    break;
  case IFX_DECT_LAU_SYS_SET_LIST_IPADD_DNS:
			 IFX_DECT_LAU_EncodeDNSServer(IFX_DECT_LAU_SYS_SET_LIST_IPADD_DNS,
			 							 (pSystemSettingList->uiEditField),
										 &pSystemSettingList->xBaseDNSServerAdd,&size,pucDataPayload);
    break;
  case IFX_DECT_LAU_SYS_SET_LIST_FW_VER:							  
		 IFX_DECT_LAU_EncodeFirmwareVersion(IFX_DECT_LAU_SYS_SET_LIST_FW_VER,
			 								   (pSystemSettingList->uiEditField),
											   ((uchar8 *)pSystemSettingList->acBaseFwVersion),&size,pucDataPayload);
    break;
  case IFX_DECT_LAU_SYS_SET_LIST_EE_VER:
		 IFX_DECT_LAU_EncodeEpromVersion(IFX_DECT_LAU_SYS_SET_LIST_EE_VER,
			 							    (pSystemSettingList->uiEditField),
											((uchar8 *)pSystemSettingList->acBaseEepromVersion),&size,pucDataPayload);
    break;
  case IFX_DECT_LAU_SYS_SET_LIST_HW_VER:
		 IFX_DECT_LAU_EncodeHardwarever(IFX_DECT_LAU_SYS_SET_LIST_HW_VER,
			 							   (pSystemSettingList->uiEditField),
										   ((uchar8 *)pSystemSettingList->acBaseHwVersion),&size,pucDataPayload);
    break;
  case IFX_DECT_LAU_SYS_SET_LIST_NEW_PIN:
      IFX_DECT_LAU_EncodePinCode(IFX_DECT_LAU_SYS_SET_LIST_NEW_PIN,
                                    pSystemSettingList->uiEditField,
                                     ((uchar8 *)pSystemSettingList->acNewPIN),&size,pucDataPayload);/*QUERY:param 4?*/
      break;
  case IFX_DECT_LAU_SYS_SET_LIST_EMISSION_MODE:
      IFX_DECT_LAU_EncodeEmissionMode(IFX_DECT_LAU_SYS_SET_LIST_EMISSION_MODE,
                                      pSystemSettingList->uiEditField,
                                      pSystemSettingList->cEmissionMode,&size,pucDataPayload);
      break;
 }
    j++;
}
  /* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID(nId,pucDataPayload,entry_size);

  *punPayloadSize=size;
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeLineSetting
* Description    : Encode Line setting entry
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_EncodeLineSetting(IN int16 nSessId,
                               IN uchar8 ucHSId,
                               IN x_IFX_DECT_LAU_LineSettingsList *pLineSettingList,
						       OUT uint16* punPayloadSize,
						       OUT uchar8* pucDataPayload)
{
  uchar8 LidSubType=IFX_DECT_STYPE_RELATING_TO;
  uint16 entry_size=0;
  uchar8 j=0,k=0,l=0;
  uint16 size =0;
  int16 nId; 
  
  for(k=0;k<pLineSettingList->ucNoOfLines;k++){
	  j=0;
  /*Entry Identifier*/
  IFX_DECT_LAU_ENCODE_2BYTEID(pLineSettingList->axLineEntry[k].nEntryId,
                              pucDataPayload,size);
  entry_size=size;
  /* 2 bytes left for length*/
  size += 2;

  while(j < IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE && axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
    printf("Field ID %d\n",axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]);
    switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
      case IFX_DECT_LAU_LINE_SET_LIST_LINE_NAME:
		 IFX_DECT_LAU_EncodeLineNam(IFX_DECT_LAU_LINE_SET_LIST_LINE_NAME,
		                           (pLineSettingList->axLineEntry[k].uiEditField),
	 						       						pLineSettingList->axLineEntry[k].acLineName,&size,pucDataPayload);

	  break;
      case IFX_DECT_LAU_LINE_SET_LIST_LINE_ID:
	    IFX_DECT_LAU_EncodeLineId(IFX_DECT_LAU_LINE_SET_LIST_LINE_ID,
		                          (pLineSettingList->axLineEntry[k].uiEditField),
								  LidSubType, pLineSettingList->axLineEntry[k].ucLineId,
								  &size,pucDataPayload);
	  break;
      case IFX_DECT_LAU_LINE_SET_LIST_MELODY:
	    IFX_DECT_LAU_EncodeAssocMelody(IFX_DECT_LAU_LINE_SET_LIST_MELODY,
		                               (pLineSettingList->axLineEntry[k].uiEditField),
		                               pLineSettingList->axLineEntry[k].ucAssocMelody,&size,pucDataPayload);
      break;
      case IFX_DECT_LAU_LINE_SET_LIST_ATTACH_PP:
	    IFX_DECT_LAU_EncodeAttachedPP(IFX_DECT_LAU_LINE_SET_LIST_ATTACH_PP,
		                              (pLineSettingList->axLineEntry[k].uiEditField),
	                                  pLineSettingList->axLineEntry[k].xAttachedPP.cNoOfPP,
									  ((uchar8 *)pLineSettingList->axLineEntry[k].xAttachedPP.acAttachedPP),&size,pucDataPayload);
      break;
      case IFX_DECT_LAU_LINE_SET_LIST_DIAL_PREFIX:
	    IFX_DECT_LAU_EncodeDialPrefix(IFX_DECT_LAU_LINE_SET_LIST_DIAL_PREFIX,
		                              (pLineSettingList->axLineEntry[k].uiEditField),
	                                  pLineSettingList->axLineEntry[k].ucDialPrefix,
								      &size,pucDataPayload);
      break;
      case IFX_DECT_LAU_LINE_SET_LIST_VOLUME:
        IFX_DECT_LAU_EncodeVolume(IFX_DECT_LAU_LINE_SET_LIST_VOLUME,
		                       (pLineSettingList->axLineEntry[k].uiEditField),
	 						   pLineSettingList->axLineEntry[k].ucVolume,
							   &size,pucDataPayload);
      break;
      case IFX_DECT_LAU_LINE_SET_LIST_BLOCK_NUM:
			if(pLineSettingList->axLineEntry[k].xBlockNumList.ucNoOfNumbers == 0){//swaroop
			IFX_DECT_LAU_EncodeBlockNumber(IFX_DECT_LAU_LINE_SET_LIST_BLOCK_NUM,
                              (pLineSettingList->axLineEntry[k].uiEditField),
            									NULL,&size,pucDataPayload);
			}
			else{
		  for(l=0;l<pLineSettingList->axLineEntry[k].xBlockNumList.ucNoOfNumbers;l++){
	    IFX_DECT_LAU_EncodeBlockNumber(IFX_DECT_LAU_LINE_SET_LIST_BLOCK_NUM,
		                          (pLineSettingList->axLineEntry[k].uiEditField),
	 				  (uchar8 *)&pLineSettingList->axLineEntry[k].xBlockNumList.acNumList[l],//Ghosh
								   &size,pucDataPayload);
		  		}
			}
      break;
      case IFX_DECT_LAU_LINE_SET_LIST_CALL_MODE:
	    IFX_DECT_LAU_EncodeMode(IFX_DECT_LAU_LINE_SET_LIST_CALL_MODE,
		                    (pLineSettingList->axLineEntry[k].uiEditField),
	 						pLineSettingList->axLineEntry[k].ucCallMode,&size,pucDataPayload);
      break;
      case IFX_DECT_LAU_LINE_SET_LIST_PERM_CLIR:
	    IFX_DECT_LAU_EncodePCLIR(IFX_DECT_LAU_LINE_SET_LIST_PERM_CLIR,
		                    (pLineSettingList->axLineEntry[k].uiEditField),
	 						 pLineSettingList->axLineEntry[k].xCLIRInfo.ucCLIRStatus,
							 pLineSettingList->axLineEntry[k].xCLIRInfo.ucCLIRCode,
							 pLineSettingList->axLineEntry[k].xCLIRInfo.ucCLIRDeactCode,
							 &size,pucDataPayload);
      break;
      case IFX_DECT_LAU_LINE_SET_LIST_CALL_INTRU:
      IFX_DECT_LAU_EncodeIntrusionCall(IFX_DECT_LAU_LINE_SET_LIST_CALL_INTRU,
                       pLineSettingList->axLineEntry[k].uiEditField,
                       pLineSettingList->axLineEntry[k].ucCallIntrusion,&size,pucDataPayload);
      break;
      case IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_U:
	      IFX_DECT_LAU_EncodeCallForward(IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_U,
		                           (pLineSettingList->axLineEntry[k].uiEditField),
									              &pLineSettingList->axLineEntry[k].xCFInfoU,
									              &size,pucDataPayload);
        break;
      case IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_N:
	      IFX_DECT_LAU_EncodeCallForward(IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_N,
		                           (pLineSettingList->axLineEntry[k].uiEditField),
									&pLineSettingList->axLineEntry[k].xCFInfoN,
									&size,pucDataPayload);
        break;

      case IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_B:
	      IFX_DECT_LAU_EncodeCallForward(IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_B,
		                           (pLineSettingList->axLineEntry[k].uiEditField),
									&pLineSettingList->axLineEntry[k].xCFInfoB,
									&size,pucDataPayload);
      break;
    }
    j++;
  }
  /* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID(nId,pucDataPayload,entry_size);
  }
  *punPayloadSize=size;
  return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeContactList 
* Description    : Encode Contact list
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_EncodeContactList(IN int16 nSessId,
                               IN uchar8 ucHSId,
                               IN x_IFX_DECT_LAU_ContactList *pContactList,
						       OUT uint16* punPayloadSize,
						       OUT uchar8* pucDataPayload)
{
  //uchar8 LidSubType=IFX_DECT_STYPE_RELATING_TO;
  uint16 entry_size=0;
  uchar8 i=0,j=0,k=0;
  uint16 size =0;
  int16 nId;
  printf("\n pContactList->unNoOfEntries:%d\n",pContactList->unNoOfEntries);
  for(i=0;i<pContactList->unNoOfEntries;i++){

    /*Entry Identifier*/
    IFX_DECT_LAU_ENCODE_2BYTEID(pContactList->axContactList[i].nEntryId,
	                            pucDataPayload,size);
	  printf("\n$$$$$$$$$$$$$$$$$$Entry ID is %d\n",pucDataPayload[size-1]);
    entry_size=size;
    /* 2 bytes left for length*/
    size += 2;
	j=0;
        k=0;
    while(j < IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE && axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
      switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
		case IFX_DECT_LAU_CON_LIST_NAME:
		  IFX_DECT_LAU_EncodeName(IFX_DECT_LAU_CON_LIST_NAME,
		                          (pContactList->axContactList[i].uiEditField & IFX_DECT_LAU_CL_LNAME),
								  		pContactList->axContactList[i].acLastName,
						          &size,pucDataPayload);
		break;
		case IFX_DECT_LAU_CON_LIST_FIRST_NAME:
		  IFX_DECT_LAU_EncodeContactFirstName(IFX_DECT_LAU_CON_LIST_FIRST_NAME,
		                                     (pContactList->axContactList[i].uiEditField & IFX_DECT_LAU_CL_FNAME),
											 pContactList->axContactList[i].acFirstName,
											 &size,pucDataPayload);
		break;
		case IFX_DECT_LAU_CON_LIST_NUMBER:
		 //for(k=0;k<pContactList->axContactList[i].xNumber.ucNoOfContactNumbers;k++){
				printf("$$$$$$ No of Contact Number's : %d\n",pContactList->axContactList[i].xNumber.ucNoOfContactNumbers);
        if(k >= pContactList->axContactList[i].xNumber.ucNoOfContactNumbers){
			 		j++;
          continue;
        }
				printf("*********$$$$$$Encoding Contact Number : %d =  %s\n",k+1,pContactList->axContactList[i].xNumber.xNum[k].acNumber);
				IFX_DECT_LAU_EncodeNum(IFX_DECT_LAU_CON_LIST_NUMBER,
					pContactList->axContactList[i].uiEditField & IFX_DECT_LAU_CL_NUM,
								  pContactList->axContactList[i].xNumber.xNum[k].ctype,
							      pContactList->axContactList[i].xNumber.xNum[k].acNumber,
								  &size,pucDataPayload);
        k++;
			//}
        break;
        case IFX_DECT_LAU_CON_LIST_MELODY:
		  IFX_DECT_LAU_EncodeAssocMelody(IFX_DECT_LAU_CON_LIST_MELODY,
		                                 (pContactList->axContactList[i].uiEditField & IFX_DECT_LAU_CL_ASCMEL),
									     pContactList->axContactList[i].ucAssocMelody,
									     &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CON_LIST_LINE_ID:
		  IFX_DECT_LAU_EncodeLineId(IFX_DECT_LAU_CON_LIST_LINE_ID,
		                            (pContactList->axContactList[i].uiEditField & IFX_DECT_LAU_CL_LINEID),
									pContactList->axContactList[i].ucSubType,pContactList->axContactList[i].ucLineId,
                                    &size, pucDataPayload);
        break;
      }
      j++;
    }
    /* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
	  printf("\nLength occupies one octet.\n");
  }else{
    nId = (size-(entry_size+2));
   }
	  printf("\nEntry Length is %d\n",nId);
    IFX_DECT_LAU_ENCODE_2BYTEID(nId,pucDataPayload,entry_size);
  }

  *punPayloadSize=size;
	printf("\nPayload Size is %d\n",size);
  return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeAllCall 
* Description    : Encode All call list
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_EncodeAllCall(IN int16 nSessId,
                          IN uchar8 ucHSId,
                          IN x_IFX_DECT_LAU_AllCallList *pAllCall,
						  OUT uint16* punPayloadSize,
						  OUT uchar8* pucDataPayload)
{
  uchar8 LidSubType=IFX_DECT_STYPE_LINE_ID_EXT;
  uint16 entry_size=0;
  uchar8 i=0,j=0;
  uint16 size =0;
  int16 nId;
  for(i=0;i<pAllCall->cNoOfEntries;i++){
#if 0	
    /*Entry Identifier*/
    if(axLauInfo[ucHSId][nSessId].ucOrder == IFX_DECT_LAU_LIST_ORDER_ASC){
      pucDataPayload[size++]=axLauInfo[ucHSId][nSessId].nStartIdx+i;
	}
	else{
      pucDataPayload[size++]=axLauInfo[ucHSId][nSessId].nStartIdx-i;
	}
#else
    //pAllCall->axAllCallList[i].nEntryId--;
    IFX_DECT_LAU_ENCODE_2BYTEID(pAllCall->axAllCallList[i].nEntryId,
	                            pucDataPayload,size);
#endif
    entry_size=size;
    /* 2 bytes left for length*/
    size += 2;
	j=0;
    while(j < IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE && axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
      switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
		case IFX_DECT_LAU_CL_ALL_CALL_TYPE:
		  IFX_DECT_LAU_EncodeCalltype(IFX_DECT_LAU_CL_ALL_CALL_TYPE,0,
		                              ((uchar8 *)&pAllCall->axAllCallList[i].cCallListType),
									  &size,pucDataPayload);
		break;
		case IFX_DECT_LAU_CL_ALL_CALL_NUMBER:
		 IFX_DECT_LAU_EncodeNum(IFX_DECT_LAU_CL_ALL_CALL_NUMBER,0,pAllCall->axAllCallList[i].ucInternal,
							    pAllCall->axAllCallList[i].acNum,
								&size,pucDataPayload);
		break;
		case IFX_DECT_LAU_CL_ALL_CALL_NAME:
		  IFX_DECT_LAU_EncodeName(IFX_DECT_LAU_CL_ALL_CALL_NAME,0,
								  pAllCall->axAllCallList[i].acName,
								  &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_ALL_CALL_DATE_TIME:
		IFX_DECT_LAU_EncodeDateTime(IFX_DECT_LAU_CL_ALL_CALL_DATE_TIME,0,
		                            &pAllCall->axAllCallList[i].xTimeDate,
								    &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_ALL_CALL_LINE_NAME:
		  IFX_DECT_LAU_EncodeLineNam(IFX_DECT_LAU_CL_ALL_CALL_LINE_NAME,0,
		                             pAllCall->axAllCallList[i].acLineName,
									 &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_ALL_CALL_LINE_ID:
		  IFX_DECT_LAU_EncodeLineId(IFX_DECT_LAU_CL_ALL_CALL_LINE_ID,0,
								    LidSubType,pAllCall->axAllCallList[i].ucLineId,
									&size,pucDataPayload);
        break;
      }
      j++;
    }
    /* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID(nId,pucDataPayload,entry_size);
  }

  *punPayloadSize=size;
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeOutCall 
* Description    : Encode Outgoing call list
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_EncodeOutCall(IN int16 nSessId,
                          IN uchar8 ucHSId,
                          IN x_IFX_DECT_LAU_OutgoingCallList *pOutgoingCall,
						  OUT uint16* punPayloadSize,
						  OUT uchar8* pucDataPayload)
{
  uchar8 LidSubType=IFX_DECT_STYPE_LINE_ID_EXT;
  uint16 entry_size=0;
  uchar8 i=0,j=0;
  uint16 size =0;
  int16 nId;
  
  for(i=0;i<pOutgoingCall->cNoOfEntries;i++){
    /*Entry Identifier*/
#if 0	
    if(axLauInfo[ucHSId][nSessId].ucOrder == IFX_DECT_LAU_LIST_ORDER_ASC){
      pucDataPayload[size++]=axLauInfo[ucHSId][nSessId].nStartIdx+i;
	}
	else{
      pucDataPayload[size++]=axLauInfo[ucHSId][nSessId].nStartIdx-i;
	}
#else
    //pOutgoingCall->axOutgoingCallList[i].nEntryId--;
    IFX_DECT_LAU_ENCODE_2BYTEID(pOutgoingCall->axOutgoingCallList[i].nEntryId,
	                            pucDataPayload,size);
#endif

    entry_size=size;
    /* 2 bytes left for length*/
    size += 2;
	j=0;
    while(j < IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE && axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
      switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
		case IFX_DECT_LAU_CL_OUTGOING_NUMBER:
		  IFX_DECT_LAU_EncodeNum(IFX_DECT_LAU_CL_OUTGOING_NUMBER,0,pOutgoingCall->axOutgoingCallList[i].ucInternal,
							     pOutgoingCall->axOutgoingCallList[i].acCalledNum,
				                 &size,pucDataPayload);
		break;
		case IFX_DECT_LAU_CL_OUTGOING_NAME:
		  IFX_DECT_LAU_EncodeName(IFX_DECT_LAU_CL_OUTGOING_NAME,0,
		                          pOutgoingCall->axOutgoingCallList[i].acCalledName,
								  &size,pucDataPayload);
		break;
		case IFX_DECT_LAU_CL_OUTGOING_DATE_TIME:
		  IFX_DECT_LAU_EncodeDateTime(IFX_DECT_LAU_CL_OUTGOING_DATE_TIME,0,
		                              &pOutgoingCall->axOutgoingCallList[i].xTimeDate,
								      &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_OUTGOING_LINE_NAME:
		  IFX_DECT_LAU_EncodeLineNam(IFX_DECT_LAU_CL_OUTGOING_LINE_NAME,0,
		                             pOutgoingCall->axOutgoingCallList[i].acLineName,
									 &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_OUTGOING_LINE_ID:
		  IFX_DECT_LAU_EncodeLineId(IFX_DECT_LAU_CL_OUTGOING_LINE_ID,0,
		                            LidSubType,
									pOutgoingCall->axOutgoingCallList[i].ucLineId,
								    &size,pucDataPayload);
        break;
      }
      j++;
    }
    /* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID(nId,pucDataPayload,entry_size);
  }

  *punPayloadSize=size;
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeInCall 
* Description    : Encode Incoming call list
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_EncodeInCall(IN int16 nSessId,
                          IN uchar8 ucHSId,
                          IN x_IFX_DECT_LAU_IncomingCallList *pIncomingCall,
						  OUT uint16* punPayloadSize,
						  OUT uchar8* pucDataPayload)
{
  uchar8 LidSubType=IFX_DECT_STYPE_LINE_ID_EXT;
  uint16 entry_size=0;
  uchar8 i=0,j=0;
  uint16 size =0;
  int16 nId;

  for(i=0;i<pIncomingCall->cNoOfEntries;i++){
    /*Entry Identifier*/
#if 0	
	if(axLauInfo[ucHSId][nSessId].ucOrder == IFX_DECT_LAU_LIST_ORDER_ASC){
      pucDataPayload[size++]=axLauInfo[ucHSId][nSessId].nStartIdx+i;
	}
	else{
      pucDataPayload[size++]=axLauInfo[ucHSId][nSessId].nStartIdx-i;
	}
#else
    //pIncomingCall->axIncomingCallList[i].nEntryId--;
    IFX_DECT_LAU_ENCODE_2BYTEID(pIncomingCall->axIncomingCallList[i].nEntryId,
	                            pucDataPayload,size);
#endif
    entry_size=size;
    /* 2 bytes left for length*/
    size += 2;
	j=0;
    while(j < IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE && axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
      switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
		case IFX_DECT_LAU_CL_INCOMING_NUMBER:
		  IFX_DECT_LAU_EncodeNum(IFX_DECT_LAU_CL_INCOMING_NUMBER,0,pIncomingCall->axIncomingCallList[i].ucInternal,
			  					 pIncomingCall->axIncomingCallList[i].acCallerNum,
							     &size,pucDataPayload);
		break;
		case IFX_DECT_LAU_CL_INCOMING_NAME:
		  IFX_DECT_LAU_EncodeName(IFX_DECT_LAU_CL_INCOMING_NAME,0,
								  pIncomingCall->axIncomingCallList[i].acCallerName,
							      &size,pucDataPayload);
		break;
		case IFX_DECT_LAU_CL_INCOMING_DATE_TIME:
		  IFX_DECT_LAU_EncodeDateTime(IFX_DECT_LAU_CL_INCOMING_DATE_TIME,0,
			                          &pIncomingCall->axIncomingCallList[i].xTimeDate,
			                          &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_INCOMING_LINE_NAME:
          IFX_DECT_LAU_EncodeLineNam(IFX_DECT_LAU_CL_INCOMING_LINE_NAME,0,
			                         pIncomingCall->axIncomingCallList[i].acLineName,
									 &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_INCOMING_LINE_ID:
          IFX_DECT_LAU_EncodeLineId(IFX_DECT_LAU_CL_INCOMING_LINE_ID,0,
			                        LidSubType,
									pIncomingCall->axIncomingCallList[i].ucLineId,
									&size,pucDataPayload);
        break;
      }
      j++;
    }
    /* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID(nId,pucDataPayload,entry_size);
  }

  *punPayloadSize=size;
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeIntNameList 
* Description    : Encode Internal name list
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_EncodeIntNameList(IN int16 nSessId,
                               IN uchar8 ucHSId,
                               IN x_IFX_DECT_LAU_IntNameList *pIntNameList,
							   OUT uint16* punPayloadSize,
							   OUT uchar8* pucDataPayload)
{
  uint16 entry_size=0;
  uchar8 i=0,j=0;
  uint16 size =0;
  int16 nId;
  printf("\nEntered Encode Missed Call fun");
  for(i=0;i<pIntNameList->cNoOfEntries;i++){
    /*Entry Identifier*/
    IFX_DECT_LAU_ENCODE_2BYTEID(pIntNameList->axIntNameList[i].nEntryId,
	                            pucDataPayload,size);
    entry_size=size;
    /* 2 bytes left for length*/
    size += 2;
    j=0;
    while(j < IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE && axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
      switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
        case IFX_DECT_LAU_INT_NAME_LIST_NUMBER:
          IFX_DECT_LAU_EncodeNum(IFX_DECT_LAU_INT_NAME_LIST_NUMBER,pIntNameList->axIntNameList[i].uiEditField,pIntNameList->axIntNameList[i].ucOwn|0x20,
		                         pIntNameList->axIntNameList[i].acTermIdNum,
			   				     &size,pucDataPayload);	
        break;
        case IFX_DECT_LAU_INT_NAME_LIST_NAME:
          IFX_DECT_LAU_EncodeName(IFX_DECT_LAU_INT_NAME_LIST_NAME,pIntNameList->axIntNameList[i].uiEditField,
		                          ((char8 *)pIntNameList->axIntNameList[i].acName),
	 			          		  &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_INT_NAME_LIST_CALL_INTERCEPT:
          IFX_DECT_LAU_EncodeCallIntercept(IFX_DECT_LAU_INT_NAME_LIST_CALL_INTERCEPT,pIntNameList->axIntNameList[i].uiEditField,
                              		pIntNameList->axIntNameList[i].ucCallIntercept,
                        					&size,pucDataPayload);
        break;

      }
	  j++;
    }
	
	printf("size=%d, entry_size=%d\n",size,entry_size);
	/* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID(nId,pucDataPayload,entry_size);
  }

  *punPayloadSize=size;
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeMissedCall 
* Description    : Encode Missed Call
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_EncodeMissedCall(IN int16 nSessId,
                              IN uchar8 ucHSId,
                              IN x_IFX_DECT_LAU_MissedCallList *pxMissedCall,
							  OUT uint16* punPayloadSize,
							  OUT uchar8* pucDataPayload)
{
  uchar8 LidSubType=1;
  uint16 entry_size=0;
  uchar8 i=0,j=0;
  uint16 size =0;
  int16 nId;
  printf("\nEntered Encode Missed Call fun");
  printf("\n pxMissedCall->cNoOfEntries = %d",pxMissedCall->cNoOfEntries);
  for(i=0;i<pxMissedCall->cNoOfEntries;i++){
    /*Entry Identifier*/
    IFX_DECT_LAU_ENCODE_2BYTEID(pxMissedCall->axMissedCallList[i].nEntryId,
	                            pucDataPayload,size);
    entry_size=size;
    /* 2 bytes left for length*/
    size += 2;
    j=0;
    while( j < IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE && axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
      switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
        case IFX_DECT_LAU_CL_MISSED_NUMBER:
          IFX_DECT_LAU_EncodeNum(IFX_DECT_LAU_CL_MISSED_NUMBER,0,pxMissedCall->axMissedCallList[i].ucInternal,
		                         pxMissedCall->axMissedCallList[i].acCallerNum,
			   				     &size,pucDataPayload);	
        break;
        case IFX_DECT_LAU_CL_MISSED_NAME:
          IFX_DECT_LAU_EncodeName(IFX_DECT_LAU_CL_MISSED_NAME,0,
		                          pxMissedCall->axMissedCallList[i].acCallerName,
				          		  &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_MISSED_DATE_TIME:
          IFX_DECT_LAU_EncodeDateTime(IFX_DECT_LAU_CL_MISSED_DATE_TIME,0,
		                              &pxMissedCall->axMissedCallList[i].xTimeDate,
						              &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_MISSED_NEW:
          IFX_DECT_LAU_EncodeNew(IFX_DECT_LAU_CL_MISSED_NEW,0,
		                         pxMissedCall->axMissedCallList[i].bNew,
				   		         &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_MISSED_LINE_NAME:
          IFX_DECT_LAU_EncodeLineNam(IFX_DECT_LAU_CL_MISSED_LINE_NAME,0,
		                             pxMissedCall->axMissedCallList[i].acLineName,
		           				     &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_MISSED_LINE_ID: 
	      IFX_DECT_LAU_EncodeLineId(IFX_DECT_LAU_CL_MISSED_LINE_ID,0,
		                   LidSubType,pxMissedCall->axMissedCallList[i].ucLineId,
						   &size,pucDataPayload);
		break;
		case IFX_DECT_LAU_CL_MISSED_NUM_CALLS:
		  IFX_DECT_LAU_EncodeNumberOfCalls(IFX_DECT_LAU_CL_MISSED_NUM_CALLS,0,
			                               &pxMissedCall->axMissedCallList[i].ucNoOfCalls,
				  						   &size,pucDataPayload);
        break;
      }
	  j++;
    }
	
	printf("size=%d, entry_size=%d\n",size,entry_size);
	/* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
  IFX_DECT_LAU_ENCODE_2BYTEID(nId,pucDataPayload,entry_size);
  }

  *punPayloadSize=size;
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeAllIncomingCall 
* Description    : Encode All Incoming Call
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_EncodeAllIncomingCall(IN int16 nSessId,
                              IN uchar8 ucHSId,
                              IN x_IFX_DECT_LAU_AllIncomingCallList *pxAllIncomingCall,
							                OUT uint16* punPayloadSize,
							                OUT uchar8* pucDataPayload)
{
  uchar8 LidSubType=9;
  uint16 entry_size=0;
  uchar8 i=0,j=0;
  uint16 size =0;
  int16 nId;
  printf("\nEntered Encode All Incoming Call fun");
  for(i=0;i<pxAllIncomingCall->cNoOfEntries;i++){
    /*Entry Identifier*/
#if 0	
	if(axLauInfo[ucHSId][nSessId].ucOrder == IFX_DECT_LAU_LIST_ORDER_ASC){
      pucDataPayload[size++]=axLauInfo[ucHSId][nSessId].nStartIdx+i;
	}
	else{
      pucDataPayload[size++]=axLauInfo[ucHSId][nSessId].nStartIdx-i;
	}
#else	
    //pxMissedCall->axMissedCallList[i].nEntryId--;
    IFX_DECT_LAU_ENCODE_2BYTEID(pxAllIncomingCall->axAllIncomingCallList[i].nEntryId,
	                            pucDataPayload,size);
#endif								
    entry_size=size;
    /* 2 bytes left for length*/
    size += 2;
    j=0;
    while(j < IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE && axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
      switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
        case IFX_DECT_LAU_CL_ALL_INCOMING_NUMBER:
          IFX_DECT_LAU_EncodeNum(IFX_DECT_LAU_CL_ALL_INCOMING_NUMBER,0,
                                 pxAllIncomingCall->axAllIncomingCallList[i].ucInternal,
		                             pxAllIncomingCall->axAllIncomingCallList[i].acCallerNum,
			   				                 &size,pucDataPayload);	
        break;
        case IFX_DECT_LAU_CL_ALL_INCOMING_NAME:
          IFX_DECT_LAU_EncodeName(IFX_DECT_LAU_CL_ALL_INCOMING_NAME,0,
		                          pxAllIncomingCall->axAllIncomingCallList[i].acCallerName,
			   				              &size,pucDataPayload);	
        break;
        case IFX_DECT_LAU_CL_ALL_INCOMING_DATE_TIME:
          IFX_DECT_LAU_EncodeDateTime(IFX_DECT_LAU_CL_ALL_INCOMING_DATE_TIME,0,
		                                  &pxAllIncomingCall->axAllIncomingCallList[i].xTimeDate,
						                          &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_ALL_INCOMING_NEW:
          IFX_DECT_LAU_EncodeNew(IFX_DECT_LAU_CL_ALL_INCOMING_NEW,0,
		                             pxAllIncomingCall->axAllIncomingCallList[i].bNew,
				   		                   &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_ALL_INCOMING_LINE_NAME:
          IFX_DECT_LAU_EncodeLineNam(IFX_DECT_LAU_CL_ALL_INCOMING_LINE_NAME,0,
		                             pxAllIncomingCall->axAllIncomingCallList[i].acLineName,
		           				           &size,pucDataPayload);
        break;
        case IFX_DECT_LAU_CL_ALL_INCOMING_LINE_ID: 
	      IFX_DECT_LAU_EncodeLineId(IFX_DECT_LAU_CL_ALL_INCOMING_LINE_ID,0,
		                              LidSubType,pxAllIncomingCall->axAllIncomingCallList[i].ucLineId,
						                      &size,pucDataPayload);
		break;
		case IFX_DECT_LAU_CL_ALL_INCOMING_NUM_CALLS:
		  IFX_DECT_LAU_EncodeNumberOfCalls(IFX_DECT_LAU_CL_ALL_INCOMING_NUM_CALLS,0,
			                               &pxAllIncomingCall->axAllIncomingCallList[i].ucNoOfCalls,
				  						               &size,pucDataPayload);
        break;
      }
	  j++;
    }
	
	printf("size=%d, entry_size=%d\n",size,entry_size);
	/* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID(nId,pucDataPayload,entry_size);
  }

  *punPayloadSize=size;
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_DataPktPayloadEncode 
* Description    : Encode the data packet
* Input Values   : Session Id,Command type, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Session ID is required to encode only the requested fields
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_DataPktPayloadEncode( IN int16 nSessId,
                                   IN uchar8 ucListCmdType,
								   IN void* pvPayloadStruct, 
								   OUT uint16* punPayloadSize,
								   OUT char8* pucDataPayload)
								   
{
	uchar8 ucHSId=0;
	uchar8 i=0;
	//#ifdef LTQ_DT_SUPPORT
		uchar8 j=0;
	//#endif
	*punPayloadSize=0;
	/* Store the requested fields locally */
	if(IFX_DECT_LAU_GetHSIdFromSessId(&ucHSId,nSessId) != IFX_SUCCESS){
	     return IFX_FAILURE;
	}
#ifdef KLOCWORK	
	if(ucHSId <= 0 || ucHSId > IFX_DECT_MAX_HS )
					return IFX_FAILURE;	
#endif	
	
	printf("\nEntered Encode function....");
	switch(ucListCmdType)
	{
		case IFX_DECT_LAU_LIST_OF_SUPPORTED_LIST:
			{
				char8* pucLengthDataPtr =NULL;
				int k=1;
   IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Data Pkt Payload Enocde for LIST SUPPORTED");
		  pucDataPayload[i++]=0x81;
			pucDataPayload[i++]=0x8D;
			pucDataPayload[i++]=0x01;
			#if 0
			#ifdef LTQ_DT_SUPPORT
			pucDataPayload[i++]=(2 + IFX_DECT_LAU_MAX_SUPPORTED_LISTS + iPropListCount )| 0x80;
			#else
			pucDataPayload[i++]=(2 + IFX_DECT_LAU_MAX_SUPPORTED_LISTS)| 0x80;
			#endif
			#endif
			pucLengthDataPtr =pucDataPayload+i;/*Pointer for Length filled later*/
			i++;
			//pucDataPayload[i++]=(2 + IFX_DECT_LAU_MAX_SUPPORTED_LISTS + iPropListCount )| 0x80;
			pucDataPayload[i++]=0x80;
			pucDataPayload[i++]=IFX_DECT_LAU_SUPPORTED; //k=1;
      if(iListSupported & IFX_DECT_LAU_MISSED_CALLS_LS){
		    pucDataPayload[i++]=IFX_DECT_LAU_MISSED_CALLS;
			k++;
      }
      if(iListSupported & IFX_DECT_LAU_OUTGOING_CALLS_LS){
			  pucDataPayload[i++]=IFX_DECT_LAU_OUTGOING_CALLS;
			  k++;
      }

      if(iListSupported & IFX_DECT_LAU_INCOMING_ACCEPT_CALLS_LS){
			pucDataPayload[i++]=IFX_DECT_LAU_INCOMING_ACCEPT_CALLS;
			k++;
      }

      if(iListSupported & IFX_DECT_LAU_ALL_CALLS_LS){
			  pucDataPayload[i++]=IFX_DECT_LAU_ALL_CALLS;
			  k++;
      }

      if(iListSupported & IFX_DECT_LAU_CONTACTS_LS){
			  pucDataPayload[i++]=IFX_DECT_LAU_CONTACTS;
			  k++;
      }
      if(iListSupported & IFX_DECT_LAU_INTERNAL_NAMES_LS){
			  pucDataPayload[i++]=IFX_DECT_LAU_INTERNAL_NAMES;
			  k++;
      }
      if(iListSupported & IFX_DECT_LAU_SYS_SETTINGS_LS){
			  pucDataPayload[i++]=IFX_DECT_LAU_SYS_SETTINGS;
			  k++;
      }
      if(iListSupported & IFX_DECT_LAU_LINE_SETTINGS_LS){
			  pucDataPayload[i++]=IFX_DECT_LAU_LINE_SETTINGS;
			  k++;
      }
      if(iListSupported & IFX_DECT_LAU_ALL_INCOMING_CALLS_LS){
			  pucDataPayload[i++]=IFX_DECT_LAU_ALL_INCOMING_CALLS;	
			  k++;
      }
			// Get the Proprietry List Info
		//#ifdef LTQ_DT_SUPPORT
			IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
							" Proprietry List Count",iPropListCount);
			for(j=0 ; j < iPropListCount ; j++){
					 //printf("Number of Configuraed PropList : %d \n",axPropListInfo[j].ucListId);
					 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
							" Proprietry List ID",axPropListInfo[j].ucListId);
					 pucDataPayload[i++]=axPropListInfo[j].ucListId;	
			}
		//#endif
		 /* if(iListSupported & IFX_DT_LAU_RSS_CHANNEL_LIST){
			  pucDataPayload[i++]=IFX_DT_LAU_RSS_CHANNEL_LIST;	
      }
		  if(iListSupported & IFX_DT_LAU_EMAIL_ACCOUNT_LIST){
			  pucDataPayload[i++]=IFX_DT_LAU_EMAIL_ACCOUNT_LIST;	
      }
		  if(iListSupported & IFX_DT_LAU_NET_PHONE_BOOK){
			  pucDataPayload[i++]=IFX_DT_LAU_NET_PHONE_BOOK;	
      }*/
			pucDataPayload[1]=0x80 | (i-2);
			*punPayloadSize = i;
			i=0;
			/*Update the Length*/
			*pucLengthDataPtr = (2 + k + iPropListCount )| 0x80;
			}
			break;
		case IFX_DECT_LAU_CALL_LIST_TYPE_MISSED:
	 {
       x_IFX_DECT_LAU_MissedCallList *pxMissedCall = (x_IFX_DECT_LAU_MissedCallList *)pvPayloadStruct;
	   for(i=0;i<2;i++){
	   	printf("\nMissed Call Num....%s", pxMissedCall->axMissedCallList[i].acCallerNum);
	   	printf("\nMissed Call Name...%s",pxMissedCall->axMissedCallList[i].acCallerName);
		}
	   IFX_DECT_LAU_EncodeMissedCall((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
	                                 pxMissedCall,
									 punPayloadSize,
									 ((uchar8 *)pucDataPayload));
     }
	 break;
	 case IFX_DECT_LAU_CALL_LIST_TYPE_ACCEPTED:
	 {
	 	x_IFX_DECT_LAU_IncomingCallList* pIncomingCall=(x_IFX_DECT_LAU_IncomingCallList*)pvPayloadStruct;
        IFX_DECT_LAU_EncodeInCall((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
                                  pIncomingCall, punPayloadSize, ((uchar8 *)pucDataPayload));
	 }
	 break;
	 case IFX_DECT_LAU_CALL_LIST_TYPE_OUTGOING:
	 {
	   x_IFX_DECT_LAU_OutgoingCallList* pOutgoingCall=(x_IFX_DECT_LAU_OutgoingCallList*)pvPayloadStruct;
       IFX_DECT_LAU_EncodeOutCall((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
	                               pOutgoingCall, punPayloadSize, ((uchar8 *)pucDataPayload));
	 }
	 break;
	 case IFX_DECT_LAU_ALL_CALL_LIST:
	 {
	   x_IFX_DECT_LAU_AllCallList* pAllCall=(x_IFX_DECT_LAU_AllCallList*)pvPayloadStruct;
       IFX_DECT_LAU_EncodeAllCall((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
	                              pAllCall, punPayloadSize, ((uchar8 *)pucDataPayload));
	 }
	 break;
 	 case IFX_DECT_LAU_CONTACT_LIST:
	 {
	   x_IFX_DECT_LAU_ContactList* pContactList=(x_IFX_DECT_LAU_ContactList*)pvPayloadStruct;
       IFX_DECT_LAU_EncodeContactList((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
	                                  pContactList, punPayloadSize, ((uchar8 *)pucDataPayload));
     }
	 break;
	 case IFX_DECT_LAU_LINE_SETTING_LIST:
	 {
	   //x_IFX_DECT_LAU_LineSettingsEntry* pLineSettingList=(x_IFX_DECT_LAU_LineSettingsEntry*)pvPayloadStruct;
	   x_IFX_DECT_LAU_LineSettingsList* pLineSettingList=(x_IFX_DECT_LAU_LineSettingsList*)pvPayloadStruct;
	   IFX_DECT_LAU_EncodeLineSetting((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
	                                  pLineSettingList, punPayloadSize, ((uchar8 *)pucDataPayload));
     }
	 break;
	 case IFX_DECT_LAU_SYSTEM_SETTING_LIST:
	 {
	  x_IFX_DECT_LAU_SystemSettingsList *pxSystemSet = (x_IFX_DECT_LAU_SystemSettingsList*)pvPayloadStruct;
	  IFX_DECT_LAU_EncodeSystemSetting((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
	                                   pxSystemSet, punPayloadSize, ((uchar8 *)pucDataPayload));
      break;									   
	 }
	 case IFX_DECT_LAU_INTERNAL_NAME_LIST:
	 {
	   x_IFX_DECT_LAU_IntNameList *pIntNameList = (x_IFX_DECT_LAU_IntNameList*)pvPayloadStruct;
       IFX_DECT_LAU_EncodeIntNameList((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,
	   								  ucHSId-1,
                                      pIntNameList,punPayloadSize,((uchar8 *)pucDataPayload));
	   break;								  
	}
 	 case IFX_DECT_LAU_ALL_INCOMING_CALL_LIST:
	 {
       x_IFX_DECT_LAU_AllIncomingCallList *pxAllIncomingCall = (x_IFX_DECT_LAU_AllIncomingCallList *)pvPayloadStruct;
	   IFX_DECT_LAU_EncodeAllIncomingCall((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
	                                       pxAllIncomingCall,
									                       punPayloadSize,
									                       ((uchar8 *)pucDataPayload));
     }
	 break;

	 default:
		return IFX_FAILURE;
	}
	return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeCallForward 
* Description    : Decode Call Forward
* Input Values   : Buffer, size
* Output Values  : Call forward number, Type
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeCallForward(IN uchar8 ucType,
                               OUT x_IFX_DECT_LAU_CFInfo* pxCF,
							                 IN uint16* pPayloadSize,
							                 IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	//int32 field_length =0;
	uchar8 uclength=0;
  int32 i=0;

  printf("\n DecodeCallForward Entry\n");
  /* Decode the length */
  //IFX_DECT_LAU_DECODE_2BYTEID_LEN(pDataPayload,field_length,size);
  IFX_DECT_LAU_DECODE_2BYTEID_LEN_V2(pDataPayload,size);

  /* skip Edit octet */
  size++;

  /* Decode the value */
  pxCF->ucStatus = pDataPayload[size++];
  printf("\nStatus=%x\n",pxCF->ucStatus);

  if(ucType == IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_N){
    /* Decode the seconds */
	  pxCF->ucNoOfSec=pDataPayload[size++];
    printf("\nNoOfSec=%x\n",pxCF->ucNoOfSec);
  }
  /* Decode Activation code */
  if(pDataPayload[size]>0){
    size++;
		uclength=(pDataPayload[size-1]>=IFX_DECT_LAU_FEAT_CODE_LEN?IFX_DECT_LAU_FEAT_CODE_LEN-1:pDataPayload[size-1]);
    memcpy(pxCF->acCFAct,&pDataPayload[size],uclength);
    pxCF->acCFAct[uclength] = '\0';
    for(i=0;i<uclength;i++){
      printf("\nAct Code[%d]=%x ",i,pxCF->acCFAct[i]);
    }
    size += pDataPayload[size-1];
  }
  else{
    pxCF->acCFAct[0]='\0';
    printf("\nAct Code is 0\n");
    size++;
  }
  /* Decode Deactivation code */
  if(pDataPayload[size]>0){
    size++;
		uclength=(pDataPayload[size-1]>=IFX_DECT_LAU_FEAT_CODE_LEN?IFX_DECT_LAU_FEAT_CODE_LEN-1:pDataPayload[size-1]);
    memcpy(pxCF->acCFDeAct,&pDataPayload[size],uclength);
    pxCF->acCFDeAct[uclength] = '\0';
    for(i=0;i<uclength;i++){
      printf("\nAct Code[%d]=%x ",i,pxCF->acCFDeAct[i]);
    }
    size += pDataPayload[size-1];
  }
  else{
    pxCF->acCFDeAct[0]='\0';
    printf("\nDeAct Code is 0\n");
    size++;
  }
  /* Decode the number */
  if(pDataPayload[size]>0){
    size++;
		uclength=(pDataPayload[size-1]>=IFX_DECT_LAU_MAX_NUMBER_LEN?IFX_DECT_LAU_MAX_NUMBER_LEN-1:pDataPayload[size-1]);
    memcpy(pxCF->ucCFNum,&pDataPayload[size],uclength);
    pxCF->ucCFNum[uclength] = '\0';
    for(i=0;i<uclength;i++){
      printf("\nCFNum[%d]=%x ",i,pxCF->ucCFNum[i]);
    }
    size += pDataPayload[size-1];
  }
  else{
    pxCF->ucCFNum[0]='\0';
    printf("\nNum is 0\n");
    size++;
  }
	*pPayloadSize=size;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodePCLIR 
* Description    : Decode CLIR
* Input Values   : Buffer and Size
* Output Values  : CLIR status and code
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodePCLIR(OUT uchar8* pCLIRStatus,
                         OUT uchar8* pCLIRCode,
												 OUT uchar8* pCLIRDeactCode,
						 IN uint16* pPayloadSize,
						 IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	int32 field_length=0;
	uchar8 uclength=0;

  printf("\n Decode PCLIR Entry.\n");
  IFX_DECT_LAU_DECODE_2BYTEID_LEN(pDataPayload,field_length,size);

  /*Skip editable octet.*/
	size++;

	*pCLIRStatus=pDataPayload[size++];

  printf("\n pCLIRStatus=%x\n",*pCLIRStatus);
  field_length = 0;
		if(pDataPayload[size]!=0){
			field_length=pDataPayload[size];
			size++;	
			uclength=(field_length>IFX_DECT_LAU_FEAT_CODE_LEN?IFX_DECT_LAU_FEAT_CODE_LEN:field_length);
			memcpy(pCLIRCode,&pDataPayload[size],uclength);
			pCLIRCode[uclength]='\0';
			}
		else{
			size++;
			pCLIRCode[0]='\0';
			}
		size=size+field_length;
		field_length=0;
	 if(pDataPayload[size]!=0){
  		field_length=pDataPayload[size];
  		size++;
			uclength=(field_length>IFX_DECT_LAU_FEAT_CODE_LEN?IFX_DECT_LAU_FEAT_CODE_LEN:field_length);
  		memcpy(pCLIRDeactCode,&pDataPayload[size],uclength);
			pCLIRDeactCode[uclength]='\0';
  		}
  	else{
    	size++;
			pCLIRDeactCode[0]='\0';
    	}
  	size=size+field_length;
	*pPayloadSize=size;
  printf("\n Decode PCLIR Exit.\n");
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeMode 
* Description    : Decode Mode
* Input Values   : Buffer and size
* Output Values  : Mode
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeMode(OUT uchar8* pMode,
                        IN uint16* pPayloadSize,
						IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
  printf("\n Decode Mode Entry.\n");
	size+=2;
	*pMode=pDataPayload[size++];
	*pPayloadSize=size;
  printf("\n Decode Mode Exit.\n");
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeBlockNumber 
* Description    : Decodes the Block numbers
* Input Values   : Buffer and size
* Output Values  : No of digits and blocked number
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeBlockNumber(OUT uchar8* pBlockNum,
							   IN uint16* pPayloadSize,
							   IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	int32 field_length=(pDataPayload[size++]&0x7f)-1;

  printf("\n BLock Number Entry.\n");
	size++;
	memcpy(pBlockNum,&pDataPayload[size],field_length);
	size=size+field_length;
	*pPayloadSize=size;
  printf("\n BLock Number Exit.\n");
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeVolume 
* Description    : Decode Volume
* Input Values   : Buffer and size
* Output Values  : Volume
* Return Value   : None
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeVolume(OUT uchar8* pVol,
                          IN uint16* pPayloadSize,
						  IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
  //int16 nLen;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  /* Decode Len */
  //IFX_DECT_LAU_DECODE_2BYTEID_LEN(pDataPayload,nLen,size);
  IFX_DECT_LAU_DECODE_2BYTEID_LEN_V2(pDataPayload,/*nLen,*/size);
  /* Skip Editable Field Octet */
	size++;
  /* Set the voume value */
	*pVol=pDataPayload[size++];
	*pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeAttachedPP 
* Description    : Decode attached PPs
* Input Values   : Buffer and size
* Output Values  : Number of PPs and attached PPs
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeAttachedPP(OUT char8* pNoOfPP,
                              OUT uchar8* pAttachedPP,
							                IN uint16* pPayloadSize,
							                IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
  //int16 nLen;
	uchar8 i=0,val=0;
  uchar8 bitFlag = 0;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  /* Decode Len */
  //IFX_DECT_LAU_DECODE_2BYTEID_LEN(pDataPayload,nLen,size);
  IFX_DECT_LAU_DECODE_2BYTEID_LEN_V2(pDataPayload,size);
  /* Skip Editable Field Octet */
	size++;
  /* Decode No of Handsets attached */
  IFX_DECT_LAU_DECODE_2BYTEID_LEN(pDataPayload,(*pNoOfPP),size);
  /* Decode Handset bitmap */
  /* Note: assuming only 7 handsets at the moment */
  bitFlag = pDataPayload[size] & 0x80;
	val=pDataPayload[size++] ^ 0x80;
  //for(i=0;i<*pNoOfPP;i++){
  for(i=0;i<7;i++){//Swaroop.
    if(val & (1<<i)){
      pAttachedPP[i]=1;
    }
    else{
      pAttachedPP[i]=0;
    }
  }

  /*
   "The line selection operation from the handset fails after the pin code entry. 
   On dect trace it seems that the base does not like the 'save entry' command from 
   the handset. It may be that the handset specifies two-octet field for the attached
   handset bit map (catering for 12 handsets) and the gateway does not like it. If this
   is the case, however, this is according to CAT-iq specification, whereby up to 127
   handsets could be specified using the extension bit field mechanism."
  */
  #if 1
  if(!bitFlag)
  {
   /* skip last bitmap */
   size++;
  }
  #endif
 *pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeAssocMelody 
* Description    : Decode associated melody
* Input Values   : Buffer and size
* Output Values  : Melody
* Return Value   : None
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeAssocMelody(OUT uchar8* pMelody,
                               IN uint16* pPayloadSize,
							                 IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
  //int16 nLen;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  /* Decode Len */
  //IFX_DECT_LAU_DECODE_2BYTEID_LEN(pDataPayload,nLen,size);
  IFX_DECT_LAU_DECODE_2BYTEID_LEN_V2(pDataPayload,size);
	/* Skip editable octets */
	size++;
  /* Decode the Melody */
	*pMelody=pDataPayload[size++];
  /* Update the Size */
	*pPayloadSize=size;
   printf("MElody %x \n",pDataPayload[*pPayloadSize]);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeCallType 
* Description    : Decode Call Type
* Input Values   : Buffer and size
* Output Values  : Call type
* Return Value   : None
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeCallType(OUT char8* pCallType,
                            IN uint16* pPayloadSize,
							IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	uchar8 Cmdtype;
	/* Skip the length */
	size++;
	Cmdtype=pDataPayload[size];
	switch(Cmdtype)
	{
		case ((1<<5)|0x80):
		{
			*pCallType=IFX_DECT_LAU_CALL_LIST_TYPE_MISSED;
			break;
		}
		case ((1<<4)|0x80):
		{
			*pCallType=IFX_DECT_LAU_CALL_LIST_TYPE_ACCEPTED;
			break;
		}
		case ((1<<3)|0x80):
		{
			*pCallType=IFX_DECT_LAU_CALL_LIST_TYPE_OUTGOING;
			break;
		}
	}
	size++;
    *pPayloadSize=size;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeFirstName 
* Description    : Decode the first name
* Input Values   : Buffer and size
* Output Values  : First name
* Return Value   : None
* Notes          : 
* *************************************************************************/
void 
IFX_DECT_LAU_DecodeFirstName(OUT char8* pFirstName,
                             IN uint16* pPayloadSize,
							 IN uchar8* pDataPayload)
{
	char8 name[IFX_DECT_LAU_MAX_NAME_LEN]="\0";
	uint16 size=*pPayloadSize;
	uchar8 i=0;
	int32 field_length=(pDataPayload[size]&0x7f)-1;
	size=size+2;
	*pPayloadSize += (field_length+2);
	if(field_length >= IFX_DECT_LAU_MAX_NAME_LEN){
		field_length = IFX_DECT_LAU_MAX_NAME_LEN-1;
	}
	for(i=0;i<field_length;i++)
	{
		name[i]=pDataPayload[size++];
	}
	
	name[i]='\0';
	strcpy(pFirstName,name);
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeLineId 
* Description    : Decode Line ID
* Input Values   : Buffer and size
* Output Values  : Line Identifier
* Return Value   : None
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeLineId(OUT uchar8* pLineId,
													OUT uchar8* pucSubtype,
                          IN uint16* pPayloadSize,
						              IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
  uchar8 ucSubType;
  int16 nLen=0;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  /* Decode Len */
  IFX_DECT_LAU_DECODE_2BYTEID_LEN(pDataPayload,nLen,size);
  /* Skip edit field and Identifier type*/
  size++;
  ucSubType = pDataPayload[size];
	size++;
  if(ucSubType != IFX_DECT_STYPE_ALL){
    /* Decode Line ID */
    IFX_DECT_LAU_DECODE_2BYTEID_LEN(pDataPayload,*pLineId,size);
  }else if((ucSubType == IFX_DECT_STYPE_ALL)&&(nLen>=3)){
		size=size+nLen-2;
	}
  if(pucSubtype != NULL ){
    *pucSubtype = ucSubType;
  }
	*pPayloadSize =size;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeNew 
* Description    : Decode New field
* Input Values   : Buffer and size
* Output Values  : New
* Return Value   : None
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeNew(OUT uchar8* pNew,
                       IN uint16* pPayloadSize,
					   IN uchar8* pDataPayload)
{
    uchar8 val;
	uint16 size=*pPayloadSize;
	uchar8 check=1<<5;
	size++;
	val=pDataPayload[size++];
	if (val & check)
		*pNew=IFX_TRUE;
	else
		*pNew=IFX_FALSE;
	*pPayloadSize=size;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeNumberOfCalls 
* Description    : Decode Number of calls
* Input Values   : Buffer and size
* Output Values  : Number of calls
* Return Value   : None
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeNumberOfCalls(OUT uchar8* pNoofCalls,
                                 IN uint16* pPayloadSize,
								 IN uchar8* pDataPayload)
{
	uchar8 calls=0;
	uint16 size=*pPayloadSize;
	size=size+2;
	calls=pDataPayload[size];
	size++;
	*pNoofCalls=calls;
	*pPayloadSize=size;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeDateTime 
* Description    : Decode date and time
* Input Values   : Buffer and size
* Output Values  : Date and time
* Return Value   : None
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeDateTime(OUT x_IFX_DECT_USU_TimeDate *pxDateTime,
							IN uint16* pPayloadSize,
							IN uchar8* pDataPayload)
{
  x_IFX_DECT_IE_TimeDate xTimeDate ={0};
  if(IFX_DECT_IE_TimeDateGet((uint32)pDataPayload,&xTimeDate) == IFX_FAILURE){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "<USU_FetchTimeDateInfo>Api IFX_DECT_IE_TimeDateGet failed.");
    return; 
  }
  memcpy(pxDateTime,xTimeDate.acTimeDate,sizeof(x_IFX_DECT_USU_TimeDate));
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	            "<USU_FetchTimeDateInfo>Api Successful.");
  *pPayloadSize += 10;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeLineName 
* Description    : Decode Line name
* Input Values   : Buffer and size
* Output Values  : Line Name
* Return Value   : None
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeLineName(OUT char8* pLineName,
                            IN uint16* pPayloadSize,
							              IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	int32 iFieldLen=0; 
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  /* Decode Len */
  IFX_DECT_LAU_DECODE_2BYTEID_LEN(pDataPayload,iFieldLen, size);
  /* Substract Octet 3 from Len */
  iFieldLen--;
  /* Skip octet 3 */ 
	size++;
	/* Verify the size and copy */
  if(iFieldLen > IFX_DECT_LAU_MAX_LINE_NAME_LEN){
    memcpy(pLineName,&pDataPayload[size],IFX_DECT_LAU_MAX_LINE_NAME_LEN-1);
    pLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN] = '\0';
  }
  else{
    memcpy(pLineName,&pDataPayload[size],iFieldLen);
    pLineName[iFieldLen+1] = '\0';
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,pLineName);
  size += iFieldLen;
	*pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeName 
* Description    : Decode Name
* Input Values   : Buffer and size
* Output Values  : Name
* Return Value   : None
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeName(OUT char8* pListName,
                        IN uint16* pPayloadSize,
						IN uchar8* pDataPayload)
{
	uint16 size=*pPayloadSize;
	uint32 i=0;
	char8 name[IFX_DECT_LAU_MAX_NAME_LEN];
	int32 field_length=(pDataPayload[size]&0x7f)-1;
	size=size+2;
	*pPayloadSize += (field_length+2);
	if(field_length >= IFX_DECT_LAU_MAX_NAME_LEN){
		field_length = IFX_DECT_LAU_MAX_NAME_LEN-1;
	}
	for(i=0;i<field_length;i++)
	{
		name[i]=pDataPayload[size++];
	}
	name[i]='\0';
	strcpy(pListName,name);
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeNumber 
* Description    : Decode number
* Input Values   : Buffer and size
* Output Values  : Number
* Return Value   : None
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeNumber(OUT char8* pListNumber,
                          IN uint16* pPayloadSize,
						              IN uchar8* pDataPayload)
{
	
	uint16 size=*pPayloadSize;
	uint32 i;
	char8 number[IFX_DECT_LAU_MAX_NUMBER_LEN];
  int16 nLen=0;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  /* Decode Len */
  IFX_DECT_LAU_DECODE_2BYTEID_LEN(pDataPayload,nLen,size);
  /* Skip editable field */
	size++;
  /* Update Payload sixe */
	*pPayloadSize += (nLen+1);
  /* Copy the number */
	if(nLen >= IFX_DECT_LAU_MAX_NUMBER_LEN){
		nLen = IFX_DECT_LAU_MAX_NUMBER_LEN-1;
	}
	for(i=0;i<nLen;i++)
	{
		number[i]=pDataPayload[size++];
	}
	number[i]='\0';
	strcpy(pListNumber,number);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeContactNumber 
* Description    : Decode contact number
* Input Values   : Buffer and size
* Output Values  : Number
* Return Value   : None
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_DecodeContactNumber(OUT char8* pListNumber,
								 OUT char8* pType,
                          IN uint16* pPayloadSize,
						  IN uchar8* pDataPayload)
{
	
	uint16 size=*pPayloadSize;
	uint32 i;
	char8 number[IFX_DECT_LAU_MAX_NUMBER_LEN];
	int32 field_length;
  int iTemp=*pPayloadSize;
  printf("Decode contact Num\n");
        for(;iTemp<(*pPayloadSize+10);iTemp++){
          printf("%x\t",pDataPayload[iTemp]);
        }
  printf("\n");
	field_length=(pDataPayload[size++]&0x7f)-1;
  *pType = pDataPayload[size++]& 0x3E;
  *pPayloadSize += (field_length+2);
	if(field_length >= IFX_DECT_LAU_MAX_NUMBER_LEN){
		field_length = IFX_DECT_LAU_MAX_NUMBER_LEN-1;
	}
	for(i=0;i<field_length;i++)
	{
		number[i]=pDataPayload[size++];
    printf("Copy %d\n",number[i]);
	}
	number[i]='\0';
        for(iTemp=size;iTemp<size+10;iTemp++){
          printf("%x\t",pDataPayload[iTemp]);
        }
  printf("\n");
	strcpy(pListNumber,number);
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_DataPktPayloadDecode 
* Description    : Decode data packet
* Input Values   : Buffer and size
* Output Values  : Appropriate data structure
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : 
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_DataPktPayloadDecode(OUT uchar8 ucListCmdType,
                                  OUT void* pvPayloadStruct,
								  IN uint16 unPayloadSize,
								  IN uchar8* pucDataPayload)
{
	uint16 size=0;
	//uint16 entryId_size=0;
	uchar8 command_type=0, *pucTemp;
	uchar8 i=0,j=0;
	int16 nLen=0;
	
	x_IFX_DECT_LAU_MissedCallList* pMissedCallList=NULL;
	x_IFX_DECT_LAU_OutgoingCallList* pOutgoingCallList=NULL;
  x_IFX_DECT_LAU_IncomingCallList* pIncomingCallList=NULL;
  x_IFX_DECT_LAU_ContactList* pContactList=NULL;
  x_IFX_DECT_LAU_AllCallList* pAllCallList=NULL;
  x_IFX_DECT_LAU_AllIncomingCallList* pAllIncomingCallList=NULL;
  x_IFX_DECT_LAU_LineSettingsList* pLineSettingList=NULL;
  x_IFX_DECT_LAU_SystemSettingsList* pSystemSettingList=NULL;
	x_IFX_DECT_LAU_IntNameList* pIntNameList=NULL;					
	//memset(pvPayloadStruct,0,sizeof(x_IFX_DECT_LAU_ContactList));
	command_type=ucListCmdType;
	while(size<unPayloadSize){
	  switch(command_type)
	  {
	    case IFX_DECT_LAU_CALL_LIST_TYPE_MISSED:
	    {
	 	    pMissedCallList=(x_IFX_DECT_LAU_MissedCallList*)pvPayloadStruct;
		    i = pMissedCallList->cNoOfEntries;
		    /* Decode Entry ID */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,pMissedCallList->axMissedCallList[i].nEntryId);
		    size +=pucTemp - &(pucDataPayload[size]);
		    //entryId_size=pucTemp - &(pucDataPayload[size]);
	      //size += entryId_size;
		    /* Decode Len */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,nLen);
		    size += pucTemp - &(pucDataPayload[size]);
	   	  if((size+nLen) > unPayloadSize){
	        return IFX_FAILURE;
	      }
	      while(size <= nLen){
          switch(pucDataPayload[size++])
          {
            case IFX_DECT_LAU_CL_MISSED_NUMBER:
		          IFX_DECT_LAU_DecodeNumber(pMissedCallList->axMissedCallList[i].acCallerNum,
			                                  &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_MISSED_NAME:
		          IFX_DECT_LAU_DecodeName(pMissedCallList->axMissedCallList[i].acCallerName,
			                                &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_MISSED_DATE_TIME:
		          IFX_DECT_LAU_DecodeDateTime(&pMissedCallList->axMissedCallList[i].xTimeDate,
                                          &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_MISSED_NEW:
		          IFX_DECT_LAU_DecodeNew((uchar8 *)&pMissedCallList->axMissedCallList[i].bNew,
                                     &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_MISSED_LINE_NAME:
		          IFX_DECT_LAU_DecodeLineName(pMissedCallList->axMissedCallList[i].acLineName,
                                          &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_MISSED_LINE_ID:
		          IFX_DECT_LAU_DecodeLineId(&pMissedCallList->axMissedCallList[i].ucLineId,NULL,
                                        &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_MISSED_NUM_CALLS:
			        IFX_DECT_LAU_DecodeNumberOfCalls(&pMissedCallList->axMissedCallList[i].ucNoOfCalls,
                                               &size,pucDataPayload);
            break;
          }/*End switch */
        }/* End while */
        /* Increment number of entries */ 
		    pMissedCallList->cNoOfEntries++;
	      break;
	    }
	    case IFX_DECT_LAU_CALL_LIST_TYPE_ACCEPTED:
	    {
		    pIncomingCallList=(x_IFX_DECT_LAU_IncomingCallList *)pvPayloadStruct;
		    i=pIncomingCallList->cNoOfEntries;
  	    /* Decode Entry ID */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,pIncomingCallList->axIncomingCallList[i].nEntryId);
		    size += pucTemp - &(pucDataPayload[size]);
		    /* Decode Len */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,nLen);
		    size += pucTemp - &(pucDataPayload[size]);
    	  if((size+nLen) > unPayloadSize){
	        return IFX_FAILURE;
	      }
	      while(size <= nLen){
          switch(pucDataPayload[size++])
          {
            case IFX_DECT_LAU_CL_INCOMING_NUMBER:
		          IFX_DECT_LAU_DecodeNumber(pIncomingCallList->axIncomingCallList[i].acCallerNum,
                                        &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_INCOMING_NAME:
		          IFX_DECT_LAU_DecodeName(pIncomingCallList->axIncomingCallList[i].acCallerName,
                                      &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_INCOMING_DATE_TIME:
		          IFX_DECT_LAU_DecodeDateTime(&pIncomingCallList->axIncomingCallList[i].xTimeDate,
                                          &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_INCOMING_LINE_NAME:
		          IFX_DECT_LAU_DecodeLineName(pIncomingCallList->axIncomingCallList[i].acLineName,
                                          &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_INCOMING_LINE_ID:
		          IFX_DECT_LAU_DecodeLineId(&pIncomingCallList->axIncomingCallList[i].ucLineId,NULL,
                                        &size,pucDataPayload);
            break;
          }/* End switch */
        }/* End while */
		    pIncomingCallList->cNoOfEntries++;
		    break;
	    }
      case IFX_DECT_LAU_CALL_LIST_TYPE_OUTGOING:
	    {
		    pOutgoingCallList=(x_IFX_DECT_LAU_OutgoingCallList*)pvPayloadStruct;
		    i = pOutgoingCallList->cNoOfEntries; 
  	    /* Decode Entry ID */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,pOutgoingCallList->axOutgoingCallList[i].nEntryId);
		    size += pucTemp - &(pucDataPayload[size]);
		    /* Decode Len */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,nLen);
		    size += pucTemp - &(pucDataPayload[size]);
    	  if((size+nLen) > unPayloadSize){
	        return IFX_FAILURE;
	      }
        while(size <= nLen){
          switch(pucDataPayload[size++])
          {
            case IFX_DECT_LAU_CL_OUTGOING_NUMBER:
		          IFX_DECT_LAU_DecodeNumber(pOutgoingCallList->axOutgoingCallList[i].acCalledNum,
                                        &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_OUTGOING_NAME:
		          IFX_DECT_LAU_DecodeName(pOutgoingCallList->axOutgoingCallList[i].acCalledName,
                                      &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_OUTGOING_DATE_TIME:
		          IFX_DECT_LAU_DecodeDateTime(&pOutgoingCallList->axOutgoingCallList[i].xTimeDate,
                                          &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_OUTGOING_LINE_NAME:
		          IFX_DECT_LAU_DecodeLineName(pOutgoingCallList->axOutgoingCallList[i].acLineName,
                                          &size,pucDataPayload);
            break;
          }/* End switch */
        }/* End while */
		    pOutgoingCallList->cNoOfEntries++; 
		    break;
	    }
	    case IFX_DECT_LAU_ALL_CALL_LIST:
	    {
		    pAllCallList=(x_IFX_DECT_LAU_AllCallList*)pvPayloadStruct;
        i = pAllCallList->cNoOfEntries;
        /* Decode Entry ID */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,pAllCallList->axAllCallList[i].nEntryId);
		    size=pucTemp - &(pucDataPayload[size]);
		    /* Decode Len */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,nLen);
		    size=pucTemp - &(pucDataPayload[size]);
    	  if((size+nLen) > unPayloadSize){
	        return IFX_FAILURE;
	      }
        while(size <= nLen){
          switch(pucDataPayload[size++])
          {
            case IFX_DECT_LAU_CL_ALL_CALL_TYPE:
		          IFX_DECT_LAU_DecodeCallType(&pAllCallList->axAllCallList[i].cCallListType,
                                          &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_ALL_CALL_NUMBER:
		          IFX_DECT_LAU_DecodeNumber(pAllCallList->axAllCallList[i].acNum,
                                        &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_ALL_CALL_NAME:
		          IFX_DECT_LAU_DecodeName(pAllCallList->axAllCallList[i].acName,
                                      &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_ALL_CALL_DATE_TIME:
		          IFX_DECT_LAU_DecodeDateTime(&pAllCallList->axAllCallList[i].xTimeDate,
                                          &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_ALL_CALL_LINE_NAME:
		          IFX_DECT_LAU_DecodeLineName(pAllCallList->axAllCallList[i].acLineName,
                                          &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_ALL_CALL_LINE_ID:
		          IFX_DECT_LAU_DecodeLineId(&pAllCallList->axAllCallList[i].ucLineId,NULL,
                                        &size,pucDataPayload);
            break;
          }/* End switch */
        }/* End while */
        pAllCallList->cNoOfEntries++;
		    break;
	    }
	    case IFX_DECT_LAU_CONTACT_LIST:
	    {
        int iTemp;
				memset(pvPayloadStruct,0,sizeof(x_IFX_DECT_LAU_ContactList));
				printf("Decode contact\n");
        for(iTemp=0;iTemp<unPayloadSize;iTemp++){
          printf("%x\t",pucDataPayload[iTemp]);
        }
        printf("\n");
		    pContactList=(x_IFX_DECT_LAU_ContactList*)pvPayloadStruct;
        i = pContactList->unNoOfEntries;
        /* Decode Entry ID */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,pContactList->axContactList[i].nEntryId);
		    size += (pucTemp - &(pucDataPayload[size]));
		    /* Decode Len */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,nLen);
		    size += (pucTemp - &(pucDataPayload[size]));
        if((size+nLen) > unPayloadSize){
          IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                  "Invalid Length/Data" ); 
          return IFX_FAILURE;
	      }
        printf("size %d len %d \n",size ,nLen);
		
		/*In order to resolve some bugs with Gigaset A540 . The A540 only provides the 
		modification part of the LAU list each time. So the uiEditfield should be 
		recorded here--Below line 1*/
		pContactList->axContactList[i].uiEditField = 0;
		
		    while(size <= nLen){
        printf("size1 %d len1 %d \n",size ,nLen);
		      switch(pucDataPayload[size++]){
	          case IFX_DECT_LAU_CON_LIST_NAME:
		          IFX_DECT_LAU_DecodeName(pContactList->axContactList[i].acLastName,
                                      &size,pucDataPayload);
				  
				  /*In order to resolve some bugs with Gigaset A540 . The A540 only provides the 
		modification part of the LAU list each time. So the uiEditfield should be 
		recorded here--Below line 2*/
				  pContactList->axContactList[i].uiEditField |= IFX_DECT_LAU_CL_LNAME;
				  
		        break;
		        case IFX_DECT_LAU_CON_LIST_FIRST_NAME:
		          IFX_DECT_LAU_DecodeFirstName(pContactList->axContactList[i].acFirstName,
                                      &size,pucDataPayload);

				  /*In order to resolve some bugs with Gigaset A540 . The A540 only provides the 
		modification part of the LAU list each time. So the uiEditfield should be 
		recorded here--Below line 3*/
				  pContactList->axContactList[i].uiEditField |= IFX_DECT_LAU_CL_FNAME;
				  
			      break;
		        case IFX_DECT_LAU_CON_LIST_NUMBER:
                printf("*******Enter Decode contact list number ****** \n");
                //printf("Number is = %s\n",pContactList->axContactList[i].xNumber.xNum[j].acNumber);
              
		          j=0;
		          do{
		            IFX_DECT_LAU_DecodeContactNumber(pContactList->axContactList[i].xNumber.xNum[j].acNumber,
			                                           &pContactList->axContactList[i].xNumber.xNum[j].ctype,
						              				               &size,pucDataPayload);
                printf("**** Contact Number is = %s\n",pContactList->axContactList[i].xNumber.xNum[j].acNumber);
		            j++;
		          }while(pucDataPayload[size++] == IFX_DECT_LAU_CON_LIST_NUMBER);
              size--; /*Decrementing, since its not moving one byte next even though it not req*/
              pContactList->axContactList[i].xNumber.ucNoOfContactNumbers =j;
		        break;
		        case IFX_DECT_LAU_CON_LIST_MELODY:
		          IFX_DECT_LAU_DecodeAssocMelody(&pContactList->axContactList[i].ucAssocMelody,
                                             &size,pucDataPayload);
			      break;
		        case IFX_DECT_LAU_CON_LIST_LINE_ID:
		          IFX_DECT_LAU_DecodeLineId(&pContactList->axContactList[i].ucLineId,
																				&pContactList->axContactList[i].ucSubType,
                                        &size,pucDataPayload);
			      break;
		      }/* end of switch*/
		    }/* end of While*/
        pContactList->unNoOfEntries++;
		    break;
      }
      case IFX_DECT_LAU_LINE_SETTING_LIST:
      {
   	    pLineSettingList=(x_IFX_DECT_LAU_LineSettingsList*)pvPayloadStruct;
	      j=pLineSettingList->ucNoOfLines;
        /* Decode Entry ID */
	      pucTemp = &(pucDataPayload[size]);
	      IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,pLineSettingList->axLineEntry[j].nEntryId);
				printf("Decoded Entry ID Success value is %d \n",pLineSettingList->axLineEntry[j].nEntryId);
	      size+=(pucTemp - &(pucDataPayload[size]));
	      /* Decode Len */
	      pucTemp = &(pucDataPayload[size]);
	      IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,nLen);
				printf("Decoded length  value is %d %d\n",size,nLen);
	      size+=(pucTemp - &(pucDataPayload[size]));
				printf("Decoded length  value is %d %d\n",size,nLen);
	      if((size+nLen) > unPayloadSize){
          IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                  "Invalid Length/Data" ); 
	        return IFX_FAILURE;
        }
		    while(size <= nLen){
          switch(pucDataPayload[size++]){
            case IFX_DECT_LAU_LINE_SET_LIST_LINE_NAME:
	            IFX_DECT_LAU_DecodeLineName(pLineSettingList->axLineEntry[j].acLineName,
                                          &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_LINE_SET_LIST_LINE_ID:
	            IFX_DECT_LAU_DecodeLineId(&pLineSettingList->axLineEntry[j].ucLineId,NULL,
                                        &size,pucDataPayload);
            break;
           case IFX_DECT_LAU_LINE_SET_LIST_CALL_INTRU:
              IFX_DECT_LAU_DecodeIntrusionCall(&pLineSettingList->axLineEntry[j].ucCallIntrusion,&size,pucDataPayload);
           break;

            case IFX_DECT_LAU_LINE_SET_LIST_MELODY:
	            IFX_DECT_LAU_DecodeAssocMelody(&pLineSettingList->axLineEntry[j].ucAssocMelody,
                                             &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_LINE_SET_LIST_ATTACH_PP:
	            IFX_DECT_LAU_DecodeAttachedPP(&pLineSettingList->axLineEntry[j].xAttachedPP.cNoOfPP,
	                                          (uchar8 *)&pLineSettingList->axLineEntry[j].xAttachedPP.acAttachedPP,
                                            &size,pucDataPayload);
                break;
            case IFX_DECT_LAU_LINE_SET_LIST_DIAL_PREFIX:
              /* Dial prefix is same as number */
              IFX_DECT_LAU_DecodeNumber(((char8 *)&pLineSettingList->axLineEntry[j].ucDialPrefix),
                                        &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_LINE_SET_LIST_VOLUME:
   	          IFX_DECT_LAU_DecodeVolume(&pLineSettingList->axLineEntry[j].ucVolume,
                                        &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_LINE_SET_LIST_BLOCK_NUM:
              //i=pLineSettingList->axLineEntry[j].xBlockNumList.ucNoOfNumbers;
              IFX_DECT_LAU_DecodeBlockNumber((uchar8 *)&pLineSettingList->axLineEntry[j].xBlockNumList.acNumList[i],
					                        				   &size,pucDataPayload);
              if(!strlen(pLineSettingList->axLineEntry[j].xBlockNumList.acNumList[i]))
	             pLineSettingList->axLineEntry[j].xBlockNumList.ucNoOfNumbers = 0;
              else
	             pLineSettingList->axLineEntry[j].xBlockNumList.ucNoOfNumbers = ++i;
              printf("\npLineSettingList->axLineEntry[j].xBlockNumList.ucNoOfNumbers=%d\n",i); 
                break;
            case IFX_DECT_LAU_LINE_SET_LIST_CALL_MODE:
              IFX_DECT_LAU_DecodeMode(&pLineSettingList->axLineEntry[j].ucCallMode,&size,pucDataPayload);
            break;
            case IFX_DECT_LAU_LINE_SET_LIST_PERM_CLIR:
								printf("CLIR Section\n");
              IFX_DECT_LAU_DecodePCLIR(&pLineSettingList->axLineEntry[j].xCLIRInfo.ucCLIRStatus,
							                         &pLineSettingList->axLineEntry[j].xCLIRInfo.ucCLIRCode[0],
							                         &pLineSettingList->axLineEntry[j].xCLIRInfo.ucCLIRDeactCode[0],
							                         &size,pucDataPayload);
								printf("CLIR Section Exit\n");
							break;
            case IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_U:
              IFX_DECT_LAU_DecodeCallForward(IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_U,
                                             &pLineSettingList->axLineEntry[j].xCFInfoU,
								                             &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_N:
                IFX_DECT_LAU_DecodeCallForward(IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_N,
                                               &pLineSettingList->axLineEntry[j].xCFInfoN,
								                               &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_B:
              IFX_DECT_LAU_DecodeCallForward(IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_B,
                                             &pLineSettingList->axLineEntry[j].xCFInfoB,
								                             &size,pucDataPayload);
            break;
          }
	      }
        pLineSettingList->ucNoOfLines++;
        break;
      }
      case IFX_DECT_LAU_SYSTEM_SETTING_LIST:
      {
        int iTemp;
				printf("Decode system setting payload ssize = %d 1st element = %d\n",unPayloadSize,*pucDataPayload);
        for(iTemp=0;iTemp<unPayloadSize;iTemp++){
          printf("%x\t",pucDataPayload[iTemp]);
					}
        printf("\n");
				memset(pvPayloadStruct,0,sizeof(x_IFX_DECT_LAU_SystemSettingsList));
	 	    pSystemSettingList=(x_IFX_DECT_LAU_SystemSettingsList*)pvPayloadStruct;
				pSystemSettingList->cEmissionMode = -1;
	        /* Decode Entry ID */
	      pucTemp = &(pucDataPayload[size]);
	      IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,nLen);
	      size+=(pucTemp - &(pucDataPayload[size]));
	      /* Decode Len */
	      pucTemp = &(pucDataPayload[size]);
	      IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,nLen);
	      size+=(pucTemp - &(pucDataPayload[size]));
				printf("Inside Decode\n");
        if((size+nLen) > unPayloadSize){
				  printf("Invalid length\n");
	        return IFX_FAILURE;
	      }
		    while(size <= nLen){
				printf("Inside while loop\n");
				printf("%x",pucDataPayload[size]);
          switch(pucDataPayload[size++]){
			      case IFX_DECT_LAU_SYS_SET_LIST_PIN:
			 	      IFX_DECT_LAU_DecodePin(pSystemSettingList->acPIN,&size,pucDataPayload);
              printf("Current PIN code is  %s\n",pSystemSettingList->acPIN);
            break;
            case IFX_DECT_LAU_SYS_SET_LIST_CLOCK_MASTER:
			 	      IFX_DECT_LAU_DecodeClockMaster(&pSystemSettingList->cClockMaster,
                                             &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_SYS_SET_LIST_BASE_RESET:
			 	      IFX_DECT_LAU_DecodeBaseReset(&pSystemSettingList->cBaseReset,
                                           &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_SYS_SET_LIST_IPADD_TYPE:
			 	      IFX_DECT_LAU_DecodeIPtype(&pSystemSettingList->cBaseIPAddCfg,
                                        &size,pucDataPayload);
            break;
			      case IFX_DECT_LAU_SYS_SET_LIST_IPADD_VALUE:
			 	      IFX_DECT_LAU_DecodeIPval(&pSystemSettingList->xBaseIPAdd,
                                       &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_SYS_SET_LIST_IPADD_SUBNET:
			 	      IFX_DECT_LAU_DecodeSubnet(&pSystemSettingList->xBaseSubnetMask,
                                        &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_SYS_SET_LIST_IPADD_GW:
			 	      IFX_DECT_LAU_DecodeGWAddress(&pSystemSettingList->xBaseGwIPAdd,
                                           &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_SYS_SET_LIST_IPADD_DNS:
			 	      IFX_DECT_LAU_DecodeDNSServer(&pSystemSettingList->xBaseDNSServerAdd,
                                           &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_SYS_SET_LIST_FW_VER:
			 	      IFX_DECT_LAU_DecodeFirmwarever(pSystemSettingList->acBaseFwVersion,
                                             &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_SYS_SET_LIST_EE_VER:
			 	      IFX_DECT_LAU_DecodeEpromver(pSystemSettingList->acBaseEepromVersion,
                                          &size,pucDataPayload);
            break;
			      case IFX_DECT_LAU_SYS_SET_LIST_HW_VER:
			 	      IFX_DECT_LAU_DecodeHardwarever(pSystemSettingList->acBaseHwVersion,
                                             &size,pucDataPayload);
            break;
           case IFX_DECT_LAU_SYS_SET_LIST_NEW_PIN:
             IFX_DECT_LAU_DecodePin(pSystemSettingList->acNewPIN,
                                       &size,pucDataPayload);/*QUERY:DecodePin = DecodeNewPin*/
              printf("New PIN code is  %s\n",pSystemSettingList->acNewPIN);
           break;

           case IFX_DECT_LAU_SYS_SET_LIST_EMISSION_MODE:
             IFX_DECT_LAU_DecodeEmissionMode((uchar8*)&pSystemSettingList->cEmissionMode,
                                       &size,pucDataPayload);
           break;

          }
        }
        break;
      }
      case IFX_DECT_LAU_INTERNAL_NAME_LIST:
      {
      	pIntNameList=(x_IFX_DECT_LAU_IntNameList*)pvPayloadStruct;
	      i=pIntNameList->cNoOfEntries;
        /* Decode Entry ID */
	      pucTemp = &(pucDataPayload[size]);
	      IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,pIntNameList->axIntNameList[i].nEntryId);
	      size += pucTemp - &(pucDataPayload[size]);
	      /* Decode Len */
	      pucTemp = &(pucDataPayload[size]);
	      IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,nLen);
	      size += pucTemp - &(pucDataPayload[size]);
        if((size+nLen) > unPayloadSize){
	        return IFX_FAILURE;
	      }
		    while(size <= nLen){
          switch(pucDataPayload[size++]){
            case IFX_DECT_LAU_INT_NAME_LIST_NAME:
	            IFX_DECT_LAU_DecodeName(((char8 *)pIntNameList->axIntNameList[i].acName),
	                                    &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_INT_NAME_LIST_NUMBER:
	            IFX_DECT_LAU_DecodeNumber(pIntNameList->axIntNameList[i].acTermIdNum,
	            	                        &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_INT_NAME_LIST_CALL_INTERCEPT:
                IFX_DECT_LAU_DecodeCallIntercept((uchar8*)&pIntNameList->axIntNameList[i].ucCallIntercept,
                                        &size,pucDataPayload);
            break;

          }
        }
	      pIntNameList->cNoOfEntries++;
        break;
	   } 
	    case IFX_DECT_LAU_ALL_INCOMING_CALL_LIST:
	    {
	 	    pAllIncomingCallList=(x_IFX_DECT_LAU_AllIncomingCallList*)pvPayloadStruct;
		    i = pAllIncomingCallList->cNoOfEntries;
		    /* Decode Entry ID */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,pAllIncomingCallList->axAllIncomingCallList[i].nEntryId);
		    size=pucTemp - &(pucDataPayload[size]);
		    /* Decode Len */
		    pucTemp = &(pucDataPayload[size]);
		    IFX_DECT_LAU_DECODE_2BYTEID(pucTemp,nLen);
		    size=pucTemp - &(pucDataPayload[size]);
	   	  if((size+nLen) > unPayloadSize){
	        return IFX_FAILURE;
	      }
	      while(size <= nLen){
          switch(pucDataPayload[size++])
          {
            case IFX_DECT_LAU_CL_ALL_INCOMING_NUMBER:
		          IFX_DECT_LAU_DecodeNumber(pAllIncomingCallList->axAllIncomingCallList[i].acCallerNum,
			                                  &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_ALL_INCOMING_NAME:
		          IFX_DECT_LAU_DecodeName(pAllIncomingCallList->axAllIncomingCallList[i].acCallerName,
			                                &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_ALL_INCOMING_DATE_TIME:
		          IFX_DECT_LAU_DecodeDateTime(&pAllIncomingCallList->axAllIncomingCallList[i].xTimeDate,
                                          &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_ALL_INCOMING_NEW:
		          IFX_DECT_LAU_DecodeNew((uchar8 *)&pMissedCallList->axMissedCallList[i].bNew,
                                     &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_ALL_INCOMING_LINE_NAME:
		          IFX_DECT_LAU_DecodeLineName(pAllIncomingCallList->axAllIncomingCallList[i].acLineName,
                                          &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_ALL_INCOMING_LINE_ID:
		          IFX_DECT_LAU_DecodeLineId(&pAllIncomingCallList->axAllIncomingCallList[i].ucLineId,NULL,
                                        &size,pucDataPayload);
            break;
            case IFX_DECT_LAU_CL_ALL_INCOMING_NUM_CALLS:
			        IFX_DECT_LAU_DecodeNumberOfCalls(&pAllIncomingCallList->axAllIncomingCallList[i].ucNoOfCalls,
                                               &size,pucDataPayload);
            break;
          }/*End switch */
        }/* End while */
        /* Increment number of entries */ 
		    pAllIncomingCallList->cNoOfEntries++;
        break;
     }  
     default:
     {
       return IFX_FAILURE;
     }  
   }
 }
 return IFX_SUCCESS;
}

/*###############################################################################*/



/*************************************************************************/
/*                             Init/Misc functions                       */
/*************************************************************************/
/************************************************************************
* Function Name  : IFX_DECT_LAU_CheckListSupport 
* Description    : Check if the List is supported by the FT application 
* Input Values   : List Identifier
* Output Values  : None
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_CheckListSupport(IN uchar8 ucListId)
{
  switch(ucListId){
	    case IFX_DECT_LAU_MISSED_CALLS:
		  if(iListSupported & IFX_DECT_LAU_MISSED_CALLS_LS){
		    return IFX_SUCCESS;
		  }
		break;
	    case IFX_DECT_LAU_OUTGOING_CALLS:
		  if(iListSupported & IFX_DECT_LAU_OUTGOING_CALLS_LS){
		    return IFX_SUCCESS;
		  }
		break;
	    case IFX_DECT_LAU_INCOMING_ACCEPT_CALLS:  
		  if(iListSupported & IFX_DECT_LAU_INCOMING_ACCEPT_CALLS_LS){
		    return IFX_SUCCESS;
		  }
		break;
		case IFX_DECT_LAU_ALL_CALLS:
		  if(iListSupported & IFX_DECT_LAU_ALL_CALLS_LS){
		    return IFX_SUCCESS;
		  }
		break;
	    case IFX_DECT_LAU_CONTACTS:
		  if(iListSupported & IFX_DECT_LAU_CONTACTS_LS){
		    return IFX_SUCCESS;
		  }
		break;
	    case IFX_DECT_LAU_INTERNAL_NAMES:
		  if(iListSupported & IFX_DECT_LAU_INTERNAL_NAMES_LS){
		    return IFX_SUCCESS;
		  }
		break;
	    case IFX_DECT_LAU_SYS_SETTINGS:
		  if(iListSupported & IFX_DECT_LAU_SYS_SETTINGS_LS){
		    return IFX_SUCCESS;
		  }
		break;
	    case IFX_DECT_LAU_LINE_SETTINGS:
		  if(iListSupported & IFX_DECT_LAU_LINE_SETTINGS_LS){
		    return IFX_SUCCESS;
		  }
		break;
	    case IFX_DECT_LAU_ALL_INCOMING_CALLS:
		  if(iListSupported & IFX_DECT_LAU_ALL_INCOMING_CALLS_LS){
		    return IFX_SUCCESS;
		  }
		break;
		  case IFX_DECT_LAU_SUPPORTED:
				return IFX_SUCCESS;
		break;
		default:
		if( 0x80 &  ucListId ){
		int32 i=0;
        for(i=0 ; i < iPropListCount ; i++)
          if(axPropListInfo[i].ucListId == ucListId)
        		return IFX_SUCCESS;
      }
#if 0
	    case IFX_DECT_LAU_PROPRIETARY:
		  if(iListSupported & IFX_DECT_LAU_PROPRIETARY_LS){
		    return IFX_SUCCESS;
		  }
		break;
#ifdef LTQ_DT_SUPPORT	
	default:
	if( 0x80 &  ucListId ){
		int32 i=0;
        for(i=0 ; i < iPropListCount ; i++)
          if(axPropListInfo[i].ucListId == ucListId)
        		return IFX_SUCCESS;
      }
#endif
#endif
	  }
  return IFX_FAILURE;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_Init 
* Description    :initialize the LAU with the set of lists supported in the FT application 
* Input Values   : 
* Output Values  : 
* Return Value   :
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_Init(IN uint32 *puiLists, IN uint32 uiEMCValue)
{
  uchar8 ucListId,uFlag;
	while(*puiLists != '\0'){
			uFlag=1;
    ucListId = *puiLists;
		printf("IFX_DEC_LAU_Init : %x\n",ucListId);

	  switch(ucListId){
	    case IFX_DECT_LAU_MISSED_CALLS:
		  iListSupported |= IFX_DECT_LAU_MISSED_CALLS_LS;
		break;
	    case IFX_DECT_LAU_OUTGOING_CALLS:
		  iListSupported |= IFX_DECT_LAU_OUTGOING_CALLS_LS;
		break;
	    case IFX_DECT_LAU_INCOMING_ACCEPT_CALLS:  
		  iListSupported |= IFX_DECT_LAU_INCOMING_ACCEPT_CALLS_LS;
		break;
		case IFX_DECT_LAU_ALL_CALLS:
		  iListSupported |= IFX_DECT_LAU_ALL_CALLS_LS;
		break;
	    case IFX_DECT_LAU_CONTACTS:
		  iListSupported |= IFX_DECT_LAU_CONTACTS_LS;
		break;
	    case IFX_DECT_LAU_INTERNAL_NAMES:
		  iListSupported |= IFX_DECT_LAU_INTERNAL_NAMES_LS;
		break;
	    case IFX_DECT_LAU_SYS_SETTINGS:
		  iListSupported |= IFX_DECT_LAU_SYS_SETTINGS_LS;
		break;
	    case IFX_DECT_LAU_LINE_SETTINGS:
		  iListSupported |= IFX_DECT_LAU_LINE_SETTINGS_LS;
		break;
	    case IFX_DECT_LAU_ALL_INCOMING_CALLS:
		  iListSupported |= IFX_DECT_LAU_ALL_INCOMING_CALLS_LS;
		break;
		default:
					if(( 0x80 &  ucListId) && iPropListCount < IFX_DECT_LAU_MAX_PROP_LIST){
						IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
							" Proprietry List Info Adding",iPropListCount + 1);
    				
						axPropListInfo[iPropListCount].ucListId=ucListId;
						puiLists++;
						axPropListInfo[iPropListCount].unSupportedFieldMap=*puiLists;
						iPropListCount = iPropListCount + 1;
						uFlag=0;
					}
#if 0
	    case IFX_DECT_LAU_PROPRIETARY:
		  iListSupported |= IFX_DECT_LAU_PROPRIETARY_LS;		 
		break;
#ifdef LTQ_DT_SUPPORT
		default:
					if(( 0x80 &  ucListId) && iPropListCount < 5){
    				printf("\n Proprietry List Info Adding : %d \n",iPropListCount + 1);
						axPropListInfo[iPropListCount].ucListId=ucListId;
						puiLists++;
						axPropListInfo[iPropListCount].unSupportedFieldMap=*puiLists;
						iPropListCount = iPropListCount + 1;
						uFlag=0;
					}
#endif
#endif


	  }

    puiLists++;
		if(uFlag){
  		  /*Populate Supported Fields map for list*/	
    		//aunSupportedFieldMap[ucListId-1] = *puiLists;
    		aunSupportedFieldMap[ucListId] = *puiLists;
		  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
							" ListID = ",ucListId);
		  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
							" aunSupportedFieldMap = ",aunSupportedFieldMap[ucListId]);
		  
    		//printf("\n aunSupportedFieldMap[%d]=%x\n",ucListId,aunSupportedFieldMap[ucListId]);
	  		puiLists++;
		}
	}

	/*Store EMC Value*/
	uiEMCVal = uiEMCValue;

	return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_NackSend 
* Description    : Send out a Negative acknowledgement 
* Input Values   : Session ID and Nack reason
* Output Values  : none
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_NackSend(IN int16 nSessId,
                      IN e_IFX_DECT_LAU_NackReason eReason) 
{
	char8 ucInstance=0;
	uint32 uiIEHdl=0;
	uchar8 ucHandSetId=0;
	uint32 uiLen=0;
	x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
	x_IFX_DECT_IPC_Msg xIpcReply = {0};
	x_IFX_DECT_LAU_ListCommands xCmd={0};
	
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"In NACK send API");
	xIWUToIWUInfo.ucDefault1 = 1; /* Dont care */
    xIWUToIWUInfo.ucSR = 1;/* Status/Rej */
    xIWUToIWUInfo.ucPD = 0x03;

	IFX_DECT_LAU_GetHSIdFromSessId(&ucHandSetId,nSessId);
	/* For handling cases where Session ID is 0 */
	if(nSessId < 0){
	  xCmd.nSessionId = 0;
	}
	else{
	  xCmd.nSessionId = nSessId;
	}
	xCmd.eNackReason = eReason;
	xCmd.ucListCmd = IFX_DECT_LAU_CMD_NACK; 

    IFX_DECT_LAU_EncodeCmd(&xCmd,xIWUToIWUInfo.acIWUToIWU,
                           ((int32 *)&uiLen));//Ghosh
	xIWUToIWUInfo.ucIWUToIWULen =uiLen;					 
	if((uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcReply.acData))!=IFX_FAILURE){
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUTOIWU,(void *)&xIWUToIWUInfo) !=
	      IFX_SUCCESS){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IE add failed");
		return IFX_FAILURE;
	  }
	}
	else{
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Create NEW IE failed");
	}
/*
	if(IFX_DECT_MU_IsCallExisting(ucHandSetId,&ucInstance) != IFX_SUCCESS){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Link exists");
		return IFX_FAILURE;
	}
*/
	IFX_DECT_EncodeIWUInfo(ucHandSetId,ucInstance,&xIpcReply);
    xIpcReply.ucPara3=0xFF;
	IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);

	return IFX_SUCCESS;
			
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_ConfirmationSend
* Description    : Send out a Confirmation for the request
* Input Values   : Filled List command structure
* Output Values  : none
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_ConfirmationSend(x_IFX_DECT_LAU_ListCommands *pxCmd)	
{
	char8 ucInstance=0;
	uint32 uiIEHdl=0;
	uchar8 ucHandSetId=0;
	uint32 uiLen=0,iCount=0;
	x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
	x_IFX_DECT_IPC_Msg xIpcReply = {0};
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"In Confirmation send API");
	
	xIWUToIWUInfo.ucDefault1 = 1; /* Dont care */
    xIWUToIWUInfo.ucSR = 1;/* Status/Rej */
    xIWUToIWUInfo.ucPD = 0x03;

	/* for some cases -ve session ID (-ve of HS Num) sent to handle error case so that 
	the function IFX_DECT_LAU_GetHSIdFromSessId returns correct HS Num. So check 
	for nSessionId -ve not needed*/

	IFX_DECT_LAU_GetHSIdFromSessId(&ucHandSetId,pxCmd->nSessionId);

	/*Now set Session ID to 0 to send error case confirmation*/
	if(pxCmd->nSessionId < 0){
	  pxCmd->nSessionId = 0;
	}
	
    IFX_DECT_LAU_EncodeCmd(pxCmd,xIWUToIWUInfo.acIWUToIWU,
                           ((int32 *)&uiLen));//Ghosh
	xIWUToIWUInfo.ucIWUToIWULen = uiLen;	 
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Command encoded adding to IE");

	if((uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcReply.acData))!=IFX_FAILURE){
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUTOIWU,(void *)&xIWUToIWUInfo) !=
	     IFX_SUCCESS){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IE add failed");
		return IFX_FAILURE;
	  }
	}
	else{
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Create NEW IE failed");
	  return IFX_FAILURE;
 	}
	printf("\n Encode Cmd\n");
	for(iCount=0;iCount<20;iCount++){
		printf("%x\n",xIpcReply.acData[iCount]);
	}
			
	printf("<ConfirmationSend>HSID is %d Sess ID %d\n",ucHandSetId,pxCmd->nSessionId);
	if(IFX_DECT_MU_IsCallExisting(ucHandSetId,(uchar8*)&ucInstance) != IFX_SUCCESS){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Link exists");
      return IFX_FAILURE;
	}
	IFX_DECT_EncodeIWUInfo(ucHandSetId,ucInstance,&xIpcReply);
	xIpcReply.ucPara3=0xFF;
	IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);

	if(pxCmd->nSessionId > 0 && pxCmd->nSessionId <= IFX_DECT_LAU_MAX_SESS_PER_HS*IFX_DECT_MAX_HS)
	{
				    
	    if(ucHandSetId > 0 && ucHandSetId <= IFX_DECT_MAX_HS && pxCmd->ucListCmd == IFX_DECT_LAU_CMD_SESS_END_CFM){
	      IFX_DECT_LAU_Reset(ucHandSetId,&axLauInfo[ucHandSetId-1][(pxCmd->nSessionId %
		                     IFX_DECT_LAU_MAX_SESS_PER_HS)-1]);
		}
		/* For handling Session ID 0 case in Read request */
		
	    if(pxCmd->ucListCmd == IFX_DECT_LAU_CMD_SESS_START_CFM){
	      axLauInfo[ucHandSetId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].
		         ucNoOfEntries = pxCmd->uxListCmd.xSessionStartCfm.nNoOfAvailEntries; 
		}
	}

	return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_Proprietary_RespSend
* Description    : This function is used to send Proprietary Response to the PP. 
* Input Values   : HS Id, Pointer to Proprietary data, length of data
* Output Values  : none
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_Proprietary_RespSend(IN uchar8 ucHandSetId,IN uchar8 *pucBuff,IN int32 iLen)	
{
	char8 ucInstance=0;
	uint32 uiIEHdl=0;
	
	x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
	x_IFX_DECT_IPC_Msg xIpcReply = {0};
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"In IFX_DECT_LAU_Proprietary_RespSend API");
	if((pucBuff == NULL) || (iLen <= 0) || (ucHandSetId == 0) || (ucHandSetId > 6))
	{
		IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			"In IFX_DECT_LAU_Proprietary_RespSend API wrong params");
		return IFX_FAILURE;
	}
	
	xIWUToIWUInfo.ucDefault1 = 1; /* Dont care */
    xIWUToIWUInfo.ucSR = 1;/* Status/Rej */
    xIWUToIWUInfo.ucPD = 0x03;
		    
    memcpy(&xIWUToIWUInfo.acIWUToIWU,pucBuff,iLen);
	xIWUToIWUInfo.ucIWUToIWULen = iLen;	 
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Command encoded adding to IE");

	if((uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcReply.acData))!=IFX_FAILURE){
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUTOIWU,(void *)&xIWUToIWUInfo) !=
	     IFX_SUCCESS){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IE add failed");
		return IFX_FAILURE;
	  }
	}
	else{
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Create NEW IE failed");
	  return IFX_FAILURE;
 	}
	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
				"After Encode HS ID =",ucHandSetId);

	#if 0
	for(iCount=0;iCount<20;iCount++){
		printf("%x\n",xIpcReply.acData[iCount]);
	}
	#endif
				
	if(IFX_DECT_MU_IsCallExisting(ucHandSetId,(uchar8*)&ucInstance) != IFX_SUCCESS){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Link exists");
      return IFX_FAILURE;
	}
	IFX_DECT_EncodeIWUInfo(ucHandSetId,ucInstance,&xIpcReply);
	xIpcReply.ucPara3=0xFF;
	IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);	

	return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_SessionEnd
* Description    : Called to send End session request from FT side
* Input Values   : Session ID
* Output Values  : none
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_SessionEnd(IN int16 nSessId)
{
	char8 ucInstance=0;
	uint32 uiIEHdl=0,i=0;
	uchar8 ucHandSetId=0;
	x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
	x_IFX_DECT_IPC_Msg xIpcReply = {0};
	x_IFX_DECT_LAU_ListCommands xCmd={0};
	uint32 uiLen=0;
	
	xIWUToIWUInfo.ucDefault1 = 1; /* Dont care */
    xIWUToIWUInfo.ucSR = 1;/* Status/rej */
    xIWUToIWUInfo.ucPD = 0x03;

	xCmd.nSessionId = nSessId;
	xCmd.ucListCmd = IFX_DECT_LAU_CMD_SESS_END_REQ; 

    IFX_DECT_LAU_EncodeCmd(&xCmd,xIWUToIWUInfo.acIWUToIWU,
                         ((int32 *)&uiLen)); //Ghosh
	
	xIWUToIWUInfo.ucIWUToIWULen = uiLen;			 
	if((uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcReply.acData))!=IFX_FAILURE){
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUTOIWU,(void *)&xIWUToIWUInfo) !=
	      IFX_SUCCESS){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IE add failed");
		return IFX_FAILURE;
	  }
	}
	else{
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Create NEW IE failed");
	  return IFX_FAILURE;
	}

	IFX_DECT_LAU_GetHSIdFromSessId(&ucHandSetId,nSessId);
	if(IFX_DECT_MU_IsCallExisting(ucHandSetId,(uchar8*)&ucInstance) != IFX_SUCCESS){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Link Exists");
	  return IFX_FAILURE;
	}																
	IFX_DECT_EncodeIWUInfo(ucHandSetId,ucInstance,&xIpcReply);
	xIpcReply.ucPara3=0xFF;
	IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
	if(ucHandSetId > 0 && ucHandSetId <= IFX_DECT_MAX_HS && nSessId > 0 && nSessId <= IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS){ 
    IFX_DECT_LAU_Reset(ucHandSetId,&axLauInfo[ucHandSetId-1][(nSessId %
	                   IFX_DECT_LAU_MAX_SESS_PER_HS)-1]);
		
	   for(i=0;i<IFX_DECT_LAU_MAX_SESS_PER_HS;i++){
  		   if( axLauInfo[ucHandSetId-1][i].ucIsUsed == 1){
	   			break;
	 		}
	}

   }
	 /*
   if(i==IFX_DECT_LAU_MAX_SESS_PER_HS){
     IFX_DECT_MU_SetModuleOwner(ucHandSetId,IFX_DECT_MU_REMOVE_OWNER,IFX_DECT_LAU_ID);
   }*/
   return IFX_SUCCESS;
}

/************************************************************************
* Function Name  :IFX_DECT_LAU_ListChangeNotify
* Description    :Indicate list change notify to PP using Facility msg
* Input Values   :Handset ID, Line ID, List ID, Number of entires
* Output Values  :None 
* Return Value   :IFX_SUCCESS/IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_LAU_ListChangeNotify(IN uchar8 ucHandsetId,
                              IN uchar8 ucLineId,
							  IN e_IFX_DECT_LAU_ListId eListId,
							  IN uchar8 ucNoOfListEntries)
{
  int32 i = 0;
  x_IFX_DECT_USU_EventList xEventList = {0};
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API List Change Notify>Entry.");
   
  if((0 == ucHandsetId)||(ucHandsetId > IFX_DECT_MAX_HS)){
    return IFX_FAILURE;
  }
									
  if(!IFX_DECT_MU_IsCAT2(ucHandsetId)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         " <API ListChangeNotify>Handset is not Catiq 2.0 compatible.");
    return IFX_FAILURE;
  }
  /* Fill up the Event list structure */
  xEventList.ucNoOfEvents = 1;
  xEventList.axEvent[i].ucEventType = IFX_DECT_EVT_TYPE_LCI; /* Indicating List Change */
  xEventList.axEvent[i].ucEventSubtype = eListId;
  xEventList.axEvent[i].unEventMultiplicity = ucNoOfListEntries;
  
  if(ucLineId !=0){
    xEventList.acLineId[0] = ucLineId;
    if((eListId == IFX_DECT_LAU_OUTGOING_CALLS)||(eListId == IFX_DECT_LAU_INCOMING_ACCEPT_CALLS)){//Call List-"External"
      xEventList.ucIsAllLines = 2;
    }
    //Contact List-"Relating to" xEventList.ucIsAllLines = 0; 
    xEventList.ucNoOfLineId = 1;
  }else{
    
    if(eListId == IFX_DECT_LAU_LINE_SETTINGS){ //Line Settings List-"All Lines"
      xEventList.acLineId[0] = 0;
      xEventList.ucIsAllLines = 1;
      xEventList.ucNoOfLineId = 1;
     }
    //In case of Internal Names/System Settings List,No Call Information IE needs to be sent so all three Line Id params are 0. 
  }
  if(IFX_DECT_USU_GenericEventNotify(ucHandsetId,&xEventList) == IFX_FAILURE){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	             " <API List Change Notify>GenericEventNotify failed.Failure.");
    return IFX_FAILURE;
  }
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API List Change Notify>Success.");
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_MissedCallNotify
* Description    : Notify Missed call Event to the PP
* Input Values   : Handset ID, Line ID, Sub type, Num unread Missed calls
*                  Total number of missed calls
* Output Values  : None
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          :
* *************************************************************************/


e_IFX_Return
IFX_DECT_LAU_MissedCallNotify(IN uchar8  ucHandsetId,
                              IN uchar8  ucLineId,
							  IN uchar8  ucSubType,
							  IN uchar8  ucNoOfUnreadMissedCalls, 
							  IN uchar8 ucNoOfMissedCallListEntries)
{
  int32 i=0;
  x_IFX_DECT_USU_EventList xEventList={0};
  xEventList.ucNoOfEvents=2;
  xEventList.axEvent[i].ucEventType=IFX_DECT_EVT_TYPE_MC;/*Missed call type*/
  xEventList.axEvent[i].ucEventSubtype = ucSubType;
  xEventList.axEvent[i].unEventMultiplicity = ucNoOfUnreadMissedCalls;
	xEventList.axEvent[i+1].ucEventType=IFX_DECT_EVT_TYPE_LCI;/*List Change Indication*/
	xEventList.axEvent[i+1].ucEventSubtype = IFX_DECT_EVT_TYPE_MC;
	xEventList.axEvent[i+1].unEventMultiplicity = ucNoOfMissedCallListEntries;
  if(ucLineId !=0){
    xEventList.acLineId[0] = ucLineId;
    xEventList.ucIsAllLines = 2;//Check with Swaroop
    xEventList.ucNoOfLineId = 1;
  }
  if(IFX_DECT_USU_GenericEventNotify(ucHandsetId,&xEventList) != IFX_SUCCESS){
    return IFX_FAILURE;
  }
  
  return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_CallBksRegister
* Description    : Register LAU call backs
* Input Values   : LAU call backs structure
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_CallBksRegister(IN x_IFX_DECT_LAU_CallBks *pxLAUCallBks)
{
  memcpy(&vxLauCallBks,pxLAUCallBks,sizeof(x_IFX_DECT_LAU_CallBks));
  return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_Reset
* Description    : Reset LAU
* Input Values   : LAU Info
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_Reset(IN uchar8 ucHandset,IN x_IFX_DECT_LAU_Info *pxLauInfo)
{
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "<IFX_DECT_LAU_Reset>Entry." );
  memset(pxLauInfo,0,sizeof(x_IFX_DECT_LAU_Info));
	IFX_DECT_MU_SetModuleOwner(ucHandset,
				                     IFX_DECT_MU_REMOVE_OWNER,
										         IFX_DECT_LAU_ID);

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "<IFX_DECT_LAU_Reset>Success." );
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_CheckPD
* Description    : Check if protocol descriminator is of LAU
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_CheckPD(x_IFX_DECT_IPC_Msg *pxIPCMsg)
{
  uint32 uiIEHdl = 0;
  x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo;
  if(0 == (uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIPCMsg)) ){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
    return IFX_FAILURE;
  }

  while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_IWUTOIWU){
    if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
       return IFX_FAILURE;
    }
  }
  if(IFX_DECT_IE_IWUToIWUGet(uiIEHdl,&xIWUToIWUInfo) != IFX_SUCCESS){
      return IFX_FAILURE;
  }
  if(xIWUToIWUInfo.ucPD == 0x03){
    return IFX_SUCCESS;
  }
  return IFX_FAILURE;

}
/************************************************************************
* Function Name  : IFX_DECT_LAU_GenerateSessId
* Description    : Generates a session Identifier
* Input Values   : Handset ID
* Output Values  : Eseeion ID
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_GenerateSessId(uchar8 ucHandsetId,
                            int16* pnSessId)
{
if(ucHandsetId > 0 && ucHandsetId <= IFX_DECT_MAX_HS ){
  for(*pnSessId=0;*pnSessId<IFX_DECT_LAU_MAX_SESS_PER_HS;(*pnSessId)++)
  {
    if(axLauInfo[ucHandsetId-1][*pnSessId].ucIsUsed == 0){
	  axLauInfo[ucHandsetId-1][*pnSessId].ucIsUsed = 1;
	  /* Return SESSID = HSID*MAX_SESS_PER_HS + SessID */
	  *pnSessId += ((ucHandsetId-1)*IFX_DECT_LAU_MAX_SESS_PER_HS);
	  (*pnSessId)++;
	  printf("Sess ID %d HSID %d \n",*pnSessId,ucHandsetId);
	  return IFX_SUCCESS;
	}
  }
}
  return IFX_FAILURE;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_AssocSessIdGet
* Description    : Generates a session Identifier
* Input Values   : Handset ID
* Output Values  : Eseeion ID
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_AssocSessIdGet(uchar8 ucHsId,
                            uchar8 ucCallId,
                            int16 anSessId[IFX_DECT_LAU_MAX_SESS_PER_HS])
{
  int16 nLoc=0;
  uchar8 ucSessLoc;
  memset(anSessId,0,IFX_DECT_LAU_MAX_SESS_PER_HS);
  if((ucHsId == 0) || (ucHsId > IFX_DECT_MAX_HS)){
    return IFX_FAILURE;
  }
  for(ucSessLoc =0; ucSessLoc<IFX_DECT_LAU_MAX_SESS_PER_HS;ucSessLoc++){
	if(axLauInfo[ucHsId-1][ucSessLoc].ucCallId == ucCallId){
	  anSessId[nLoc] = ((ucHsId-1)*IFX_DECT_LAU_MAX_SESS_PER_HS) + ucSessLoc + 1;
      nLoc++;
	}
  }
  return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_GetHSIdFromSessId
* Description    : Get Handset ID from session Identifier
* Input Values   : Session ID
* Output Values  : Handset ID
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_GetHSIdFromSessId(OUT uchar8 *pucHandsetId,
                               IN int16 nSessId)
{
  /* This is introduced for internal use where the session ID can be 0
     In such case pass the -(hanset num) as session ID */
  if(nSessId < 0){
    *pucHandsetId = abs(nSessId);
  }
  else{
    *pucHandsetId = (nSessId-1)/IFX_DECT_LAU_MAX_SESS_PER_HS;
    (*pucHandsetId)++;
  }
  if(*pucHandsetId > IFX_DECT_MAX_HS){
    return IFX_FAILURE;
  }
  return IFX_SUCCESS;
}

/*************************************************************************/
/*                           FP to PP Handling                           */
/*************************************************************************/



/*************************************************************************/
/*                           PP to FP Handling                           */
/*************************************************************************/


/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeCmd
* Description    : Encode the LAU command
* Input Values   : Structure to be encoded
* Output Values  : Populated buffer, updated Length
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_EncodeCmd(IN x_IFX_DECT_LAU_ListCommands *pxCmd,
                       OUT uchar8 *pucBuff,
                       OUT int32 *piLen)
{
  int32 iLen=0,i;
  //uchar8 ucHSId = 0;
  //int32 j = 1;
  if(pucBuff == NULL){
    return IFX_FAILURE;
  }
  switch(pxCmd->ucListCmd){
     case IFX_DECT_LAU_CMD_SESS_END_REQ:
	   /* Session ID */
	   pucBuff[iLen++] = IFX_DECT_LAU_CMD_SESS_END_REQ;
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->nSessionId,pucBuff,iLen);
	 break; 
     case IFX_DECT_LAU_CMD_NACK:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"NACK");
	   /* Command */
       pucBuff[iLen++] = IFX_DECT_LAU_CMD_NACK;
	   /* Session ID */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->nSessionId,pucBuff,iLen);
       /* Reason */
       pucBuff[iLen++] = pxCmd->eNackReason;
	 break; 
     case IFX_DECT_LAU_CMD_SESS_START_CFM:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Start Sess CFM");
	   /* Command */
       pucBuff[iLen++] = IFX_DECT_LAU_CMD_SESS_START_CFM;
	   /* List ID */
       pucBuff[iLen++] = pxCmd->uxListCmd.xSessionStartCfm.eListId;
	   printf("List ID is %d\n",pxCmd->uxListCmd.xSessionStartCfm.eListId);
	   /* Session ID */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->nSessionId,pucBuff,iLen);
	   printf("Sess ID is %d\n",pxCmd->nSessionId);
	   /* Number of Entries */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->uxListCmd.
	              xSessionStartCfm.nNoOfAvailEntries,pucBuff,iLen);
	   printf("Num Entries is %d\n",pxCmd->uxListCmd.
	                   xSessionStartCfm.nNoOfAvailEntries);
	   /* EMD discriminators and value */			 
	   if(uiEMCVal == 0){
         pucBuff[iLen++] = 0;
		 /* Discriminator value is dont care */
         pucBuff[iLen++] = 0;
         pucBuff[iLen++] = 0;
	   }
	   else{
         pucBuff[iLen++] = 0x01;
	 	 /* Discriminator value */
         pucBuff[iLen++] = (uiEMCVal >> 8) & 0xFF;
         pucBuff[iLen++] = uiEMCVal & 0xFF;
	   }
	   /* Reason for rejection*/
     if(pxCmd->nSessionId == 0){
       pucBuff[iLen++] = pxCmd->uxListCmd.xSessionStartCfm.ucRejectReason;
     }else{
       pucBuff[iLen++] = 0;
      }
	     printf("Added reject reason if any %x\n",pxCmd->uxListCmd.xSessionStartCfm.ucRejectReason);
	   /* Number of sorting fields */
       pucBuff[iLen++] = pxCmd->uxListCmd.xSessionStartCfm.ucNoOfSortingFields;
       /* Entries */
	   for(i=0;i<pxCmd->uxListCmd.xSessionStartCfm.ucNoOfSortingFields;i++){
         pucBuff[iLen++] = pxCmd->uxListCmd.xSessionStartCfm.aucSortingFields[i];
	   }
	 break;
	 case IFX_DECT_LAU_CMD_LIST_DELETE_CFM:
	 case IFX_DECT_LAU_CMD_ENTRY_EDIT_CFM:
     case IFX_DECT_LAU_CMD_SESS_END_CFM:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Edit/End/Del CFM");
	   /* Command */
       pucBuff[iLen++] = pxCmd->ucListCmd;
	   /* Session ID */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->nSessionId,pucBuff,iLen);
	 break;
	 case IFX_DECT_LAU_CMD_FIELD_QUERY_CFM:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Query CFM");
	   /* Command */
       pucBuff[iLen++] = IFX_DECT_LAU_CMD_FIELD_QUERY_CFM;
	   /* Session ID */

	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->nSessionId,pucBuff,iLen);
#if 0
#ifndef SWARNA
     /* Store locally the supported fields */
	   if(IFX_DECT_LAU_GetHSIdFromSessId(&ucHSId,pxCmd->nSessionId) != IFX_SUCCESS){
	     return IFX_FAILURE;
	   }
	   memset(&axLauInfo[ucHSId-1][0].aucFieldIdsList,0,IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE*sizeof(uchar8));
      axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].ucNoOfReqFields = 
      pxCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields+pxCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields;
#endif
#endif
	   /* Editable entry fields */

       pucBuff[iLen++] = pxCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields;
	   printf("Num Editable Fields %d\n",pxCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields);
	   /* Editable Fields */
	   for(i=0;i<pxCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields;i++){
         pucBuff[iLen++] = pxCmd->uxListCmd.xFieldQueryCfm.aucEditableFields[i]; 
	     printf("Editable Fields %d\n",pxCmd->uxListCmd.xFieldQueryCfm.aucEditableFields[i]);
	   }
	   /* Uneditable entry fields */
       pucBuff[iLen++] = pxCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields;
	   printf("Num UnEditable Fields %d\n",pxCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields);
	   /* Uneditable Fields */
	   for(i=0;i<pxCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields;i++){
         pucBuff[iLen++] = pxCmd->uxListCmd.xFieldQueryCfm.aucUneditableFields[i];
	     printf("UnEditable Fields %d\n",pxCmd->uxListCmd.xFieldQueryCfm.aucUneditableFields[i]);
	   }
	 break;
	 case IFX_DECT_LAU_CMD_ENTRIES_READ_CFM:
	   /* Command */
       pucBuff[iLen++] = IFX_DECT_LAU_CMD_ENTRIES_READ_CFM;
	   /* Session ID */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->nSessionId,pucBuff,iLen);
	   	   /* Start Idx */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->uxListCmd.xEntryReadCfm.nStartIndex,pucBuff,iLen);
	   /* Number of delivered entries */
       pucBuff[iLen++] = pxCmd->uxListCmd.xEntryReadCfm.ucNoOfDeliveredEntries;
	 break;
     case IFX_DECT_LAU_CMD_ENTRY_SAVE_CFM:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Save CFM");
	   /* Command */
       pucBuff[iLen++] = IFX_DECT_LAU_CMD_ENTRY_SAVE_CFM;
	   /* Session ID */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->nSessionId,pucBuff,iLen);
	   /* Entry ID */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->uxListCmd.xEntrySaveCfm.nEntryId,pucBuff,iLen);
	   /* Position Idx */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->uxListCmd.xEntrySaveCfm.nPostionIndex,pucBuff,iLen);

	   /* Available Entires */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->uxListCmd.xEntrySaveCfm.nAvailEntries,pucBuff,iLen);

	 break; 
     case IFX_DECT_LAU_CMD_ENTRY_DELETE_CFM:
	   /* Command */
       pucBuff[iLen++] = IFX_DECT_LAU_CMD_ENTRY_DELETE_CFM;
	   /* Session ID */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->nSessionId,pucBuff,iLen);
	   /* Available Entires */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->uxListCmd.xEntryDeleteCfm.nAvailEntries,pucBuff,iLen);
	 break; 
	 case IFX_DECT_LAU_CMD_ENTRIES_SEARCH_CFM:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Search CFM");
	   printf("Start Idx %d Num Entries %d\n",pxCmd->uxListCmd.xEntrySearchCfm.nStartIndex,pxCmd->uxListCmd.xEntrySearchCfm.ucCounter);
	   /* Command */
       pucBuff[iLen++] = IFX_DECT_LAU_CMD_ENTRIES_SEARCH_CFM;
	   /* Session ID */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->nSessionId,pucBuff,iLen);
	   /* Start Idx */
	   IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->uxListCmd.xEntrySearchCfm.nStartIndex,pucBuff,iLen);
	   /* Number of returned entries */
       pucBuff[iLen++] = pxCmd->uxListCmd.xEntrySearchCfm.ucCounter;
	 break;
#ifdef LTQ_DT_SUPPORT	
	case IFX_DECT_LAU_CMD_SESS_MOVE_CFM: 
			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Move Session CFM");
     printf("Num Of Entries %d\n",pxCmd->uxListCmd.xSessionMoveCfm.nNoOfAvailEntries);
     /* Command */
       pucBuff[iLen++] = IFX_DECT_LAU_CMD_SESS_MOVE_CFM;
     /* Session ID */
     IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->nSessionId,pucBuff,iLen);
     /* Start Idx */
     IFX_DECT_LAU_ENCODE_2BYTEID(pxCmd->uxListCmd.xSessionMoveCfm.nNoOfAvailEntries,pucBuff,iLen);
		/* Reason for rejection */
     if(pxCmd->nSessionId == 0){
       pucBuff[iLen++] = pxCmd->uxListCmd.xSessionMoveCfm.ucRejectReason;
     }else{
       pucBuff[iLen++] = 0;
      }
       printf("Added reject reason if any %x\n",pxCmd->uxListCmd.xSessionMoveCfm.ucRejectReason);
     /* Number of sorting fields */
       pucBuff[iLen++] = pxCmd->uxListCmd.xSessionMoveCfm.ucNoOfSortingFields;
       /* Entries */
     for(i=0;i<pxCmd->uxListCmd.xSessionMoveCfm.ucNoOfSortingFields;i++){
         pucBuff[iLen++] = pxCmd->uxListCmd.xSessionMoveCfm.aucSortingFields[i];
     }
	break;
#endif
	 default:
	   return IFX_FAILURE;
  }
  *piLen = iLen;
  return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_LAU_ValidSessId
* Description    : Check if Session ID is valid
* Input Values   : Session ID
* Output Values  : None
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_ValidSessId(int16 nSessId)
{
  uchar8 ucHSId;
  if(IFX_DECT_LAU_GetHSIdFromSessId(&ucHSId, nSessId) != IFX_SUCCESS){
    return IFX_FAILURE;
  }
  if(ucHSId > 0 && ucHSId <= IFX_DECT_MAX_HS && nSessId > 0 && nSessId <= IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS) {
	printf("HSID %d SID %d SESSSID %d IsUsed %d\n",ucHSId,nSessId,(nSessId %
 	 IFX_DECT_LAU_MAX_SESS_PER_HS)-1,axLauInfo[ucHSId-1][(nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].ucIsUsed);
  	if(ucHSId > 0 && ucHSId <= IFX_DECT_MAX_HS  && axLauInfo[ucHSId-1][(nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].ucIsUsed == 1){
    		return IFX_SUCCESS;
  	}
  }
	return IFX_FAILURE;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_DecodeCmd
* Description    : Decode the LAU command
* Input Values   : Command specific buffer
* Output Values  : Decoded Structure
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_DecodeCmd(IN uchar8 *pucBuff,
                       IN int32 iLen,
                       OUT x_IFX_DECT_LAU_ListCommands *pxCmd)
{
  uchar8 ucHSId;
  uchar8 *pucEnd;
  int32 i,iTemp;
	uchar8 ucListId=0;
	uint16 unTempFieldMap = 0;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Decode CMD Entry");
  if((pucBuff == NULL) || (iLen ==0)){
    return IFX_FAILURE;
  }
  for(iTemp=0;iTemp<iLen;iTemp++){
    printf("%x\n",pucBuff[iTemp]);
  }
  printf("\n");
  pucEnd = pucBuff + iLen;
	pxCmd->ucListCmd = *pucBuff;
  pucBuff++;
  if (pxCmd->ucListCmd & 0x80)
  {
  	/*Proprietary Cmds application should Handle*/
	return IFX_SUCCESS;
  }
  else 
  {
  	/*Till end of Switch cmd; note that DT specific flow will not come in else
  	despite code in compilation flag as it passes to application in if case*/
  switch(pxCmd->ucListCmd){
     case IFX_DECT_LAU_CMD_SESS_START_REQ:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Start Sess Req");
							  
	   /* 1 Byte List identifier */
	   pxCmd->uxListCmd.xSessionStartReq.eListId = *pucBuff;
       pucBuff++;
	   /* Number of sorting fields */
	   pxCmd->uxListCmd.xSessionStartReq.ucNoOfSortingFields = *pucBuff;
       pucBuff++;
	   if(pxCmd->uxListCmd.xSessionStartReq.ucNoOfSortingFields >
	      IFX_DECT_LAU_MAX_SORTING_FIELDS){
		  return IFX_FAILURE;
		}
	   /* sorting field list */
	   for(i=0;i<pxCmd->uxListCmd.xSessionStartReq.ucNoOfSortingFields;i++){
	     pxCmd->uxListCmd.xSessionStartReq.aucSortingFields[i] = *pucBuff;
         pucBuff++;
	   }
	 break;
     case IFX_DECT_LAU_CMD_SESS_END_REQ:
	 case IFX_DECT_LAU_CMD_FIELD_QUERY_REQ:
	 case IFX_DECT_LAU_CMD_LIST_DELETE_REQ:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"END/QUERY/DEL Req");
	   /* session Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->nSessionId);
	   printf("Decoded Sess ID  is %d \n",pxCmd->nSessionId);
	 break; 
	 case IFX_DECT_LAU_CMD_ENTRIES_READ_REQ:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Read Req");
	   /* session Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->nSessionId);
	   /* start Index */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->uxListCmd.xEntryReadReq.nStartIndex);
	   /* Counter - 1byte */
       pxCmd->uxListCmd.xEntryReadReq.ucNoOfReqFields = (*pucBuff & 0x7F);
	   if(*pucBuff & IFX_DECT_LAU_LIST_ORDER_DES){
	     pxCmd->uxListCmd.xEntryReadReq.ucOrder = IFX_DECT_LAU_LIST_ORDER_DES;
	   }
	   else{
	     pxCmd->uxListCmd.xEntryReadReq.ucOrder = IFX_DECT_LAU_LIST_ORDER_ASC; 
	   }
       pucBuff++;
     /* ucMarkEntriesReq - 1 byte */
       pxCmd->uxListCmd.xEntryReadReq.ucMarkEntriesReq = *pucBuff;
       pucBuff++; 
	   if((pucEnd-pucBuff) > IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE){
	   	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE=",(pucEnd-pucBuff));
		 return IFX_FAILURE;
       }
	   /* Store the requested fields locally */
	   if(IFX_DECT_LAU_GetHSIdFromSessId(&ucHSId,pxCmd->nSessionId) != IFX_SUCCESS){
	   	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IFX_DECT_LAU_GetHSIdFromSessId failed");
	     return IFX_FAILURE;
	   }
		if(ucHSId <= 0 || ucHSId > IFX_DECT_MAX_HS || pxCmd->nSessionId <= 0 || pxCmd->nSessionId >IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS)
		{
			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed because");
			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"ucHSId=",ucHSId);
			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"pxCmd->nSessionId=",pxCmd->nSessionId);
			return IFX_FAILURE;
		}

	   axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].
	       ucNoOfReqFields = pxCmd->uxListCmd.xEntryReadReq.ucNoOfReqFields;
	   if(pxCmd->uxListCmd.xEntryReadReq.nStartIndex != 0){
         axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].nStartIdx = 
	       pxCmd->uxListCmd.xEntryReadReq.nStartIndex;
	   }
	   else{
         axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].nStartIdx = 
           axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].
		    ucNoOfEntries;
	   }
       axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].ucOrder = 
	       pxCmd->uxListCmd.xEntryReadReq.ucOrder;

	   /* Clear the fields if any */
	   i=0;
	   memset(&axLauInfo[ucHSId-1][0].aucFieldIdsList,0,IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE*sizeof(uchar8));
		 ucListId=axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId;
	//#ifdef LTQ_DT_SUPPORT
		if( 0x80 &  ucListId ){
				for(i=0 ; i < iPropListCount ; i++){
					if(axPropListInfo[i].ucListId == ucListId){
								unTempFieldMap = axPropListInfo[i].unSupportedFieldMap;
								IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Prop ucListId=",ucListId);
								IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Prop ucListId unTempFieldMap=",unTempFieldMap);
								//printf("Got the Fields for List %x is %d\n",ucListId,unTempFieldMap);
								break;	
				}
			}
		}else{
		//#endif

		if(/*ucListId < 0 || */ ucListId >= IFX_DECT_LAU_MAX_SUPPORTED_LISTS)
			{
			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"List id is > IFX_DECT_LAU_MAX_SUPPORTED_LISTS =",ucListId);
			return IFX_FAILURE;
			}
		
				unTempFieldMap=aunSupportedFieldMap[ucListId];
	//#ifdef LTQ_DT_SUPPORT
		}
		//#endif
		i=0;
	   while(pucBuff < pucEnd){
	     /* Store Req Fields Locally */
  	//if(unTempFieldMap & 1<<((*pucBuff)-1))
	{
           printf("\n Here i=%d ucHSId = %d",i,ucHSId);
           axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].
                       aucFieldIdsList[i] = *pucBuff;  
	         pxCmd->uxListCmd.xEntryReadReq.aucFieldIdsList[i] = *pucBuff;
           i++;  
     } 
       //printf("Requested Field %d\n",*pucBuff);
	   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Requested Field =",*pucBuff);
	   
         pucBuff++;
	   }
	   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Number of Requested Fields =",i);
     axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].ucNoOfReqFields = i;
	 break; 
	 case IFX_DECT_LAU_CMD_ENTRY_EDIT_REQ:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Edit Req");
	   /* session Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->nSessionId);
	   /* Entry Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->uxListCmd.xEntryEditReq.nEntryId);
	   /* Field List */
	   if((pucEnd - pucBuff) > IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE){
	   	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE=",(pucEnd-pucBuff));
		 return IFX_FAILURE;
       }
	   if(IFX_DECT_LAU_GetHSIdFromSessId(&ucHSId,pxCmd->nSessionId) != IFX_SUCCESS){
	   	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IFX_DECT_LAU_GetHSIdFromSessId failed");
	     return IFX_FAILURE;
	   }
#ifdef KLOCWORK	   
	   if(ucHSId <= 0 || ucHSId > IFX_DECT_MAX_HS || pxCmd->nSessionId <= 0 || pxCmd->nSessionId > IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS)
	   	{
	   	    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed because");
			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"ucHSId=",ucHSId);
			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"pxCmd->nSessionId=",pxCmd->nSessionId);
			return IFX_FAILURE;
	   	}
#endif
	   /* Store entry ID in start Index */
	   axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].
	     nStartIdx = pxCmd->uxListCmd.xEntryEditReq.nEntryId;
	   /* Clear the fields if any */
	   i=0;
		ucListId=axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId;

	   //if(/*ucListId >= 0 &&*/ ucListId < IFX_DECT_LAU_MAX_SUPPORTED_LISTS)
	   {
	   memset(&axLauInfo[ucHSId-1][0].aucFieldIdsList,0,IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE*sizeof(uchar8));
	   while(pucBuff < pucEnd){
	     /* Store the content locally */

#ifndef SWARNA
         //if(aunSupportedFieldMap[ucListId] & 1<<((*pucBuff)-1))
		 {
           axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].
                       aucFieldIdsList[i] = *pucBuff;  
           pxCmd->uxListCmd.xEntryEditReq.aucFieldIdsList[i] = *pucBuff;
           i++;  
         } 
#endif 
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Requested Field =",*pucBuff);
         pucBuff++; 
	   }
		}
	   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Number of Requested Fields =",i);
       pxCmd->uxListCmd.xEntryEditReq.ucNoOfReqFields=i;
	     axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].
	       ucNoOfReqFields = i;
	 break; 
     case IFX_DECT_LAU_CMD_ENTRY_SAVE_REQ:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Save Req");
	   /* session Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->nSessionId);
	   /* Entry Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->uxListCmd.xEntrySaveReq.nEntryId);
	 break; 
     case IFX_DECT_LAU_CMD_ENTRY_DELETE_REQ:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Delete Req");
	   /* session Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->nSessionId);
	   /* Entry Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->uxListCmd.xEntryDeleteReq.nEntryId);
	 break; 
	 case IFX_DECT_LAU_CMD_ENTRIES_SEARCH_REQ:
	 {
	   uchar8 ucLen;
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Search Req");
	   /* session Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->nSessionId);
	   pxCmd->uxListCmd.xEntrySearchReq.ucMatchingOption = *pucBuff;
	   pucBuff++;
	   ucLen = *pucBuff;
	   pucBuff++;
	   memcpy(&pxCmd->uxListCmd.xEntrySearchReq.cSearchValue,pucBuff,ucLen);
	   pucBuff += ucLen;
	   pxCmd->uxListCmd.xEntrySearchReq.uiCounter= *pucBuff;
	   pucBuff++;
	   pucBuff++; //skip Mark Entries
	   i=0;
	   if((pucEnd - pucBuff) > IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"More Field IDs");
		 return IFX_FAILURE;
	   }
	   
   	   /* Store the requested fields locally */
	   if(IFX_DECT_LAU_GetHSIdFromSessId(&ucHSId,pxCmd->nSessionId) != IFX_SUCCESS){
		  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Could not get HandsetID");
	     return IFX_FAILURE;
	   }
#ifdef KLOCWORK	   
	   if(ucHSId <= 0 || ucHSId > IFX_DECT_MAX_HS || pxCmd->nSessionId <= 0 || pxCmd->nSessionId > IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS)
		{
			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Failed because");
			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"ucHSId=",ucHSId);
			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"pxCmd->nSessionId=",pxCmd->nSessionId);
			return IFX_FAILURE;
		}
#endif	   
   	   memset(&axLauInfo[ucHSId-1][0].aucFieldIdsList,0,IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE*sizeof(uchar8));
	   
	   while(pucBuff < pucEnd){

#ifndef SWARNA
         if(aunSupportedFieldMap[axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId] 
            & 1<<((*pucBuff)-1)){
           axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].
                       aucFieldIdsList[i] = *pucBuff;  
	         pxCmd->uxListCmd.xEntrySearchReq.aucFieldIdsList[i]=*pucBuff;
           i++;  
         } 
#endif 
 	     pucBuff++;;
	   }
       pxCmd->uxListCmd.xEntrySearchReq.ucNoOfReqFields = i;//TODO:ASK: This member to be removed.Redundant.
	   axLauInfo[ucHSId-1][(pxCmd->nSessionId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1].
	       ucNoOfReqFields = i;
	 }
	 break; 
	 case IFX_DECT_LAU_CMD_DATA_PKT:
	 case IFX_DECT_LAU_CMD_DATA_PKT_LAST:
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Data Pkt");
	   /* session Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->nSessionId);
	 break; 
#ifdef LTQ_DT_SUPPORT	
	case IFX_DECT_LAU_CMD_SESS_MOVE_REQ:
	 IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Move Session Req");
	   /* session Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->nSessionId);
	   /* Entry Identifier */
       IFX_DECT_LAU_DECODE_2BYTEID(pucBuff,pxCmd->uxListCmd.xSessionMoveReq.uiSubListId);
			/* Number of sorting fields */
     pxCmd->uxListCmd.xSessionMoveReq.ucNoOfSortingFields = *pucBuff;
       pucBuff++;
     if(pxCmd->uxListCmd.xSessionMoveReq.ucNoOfSortingFields >
        IFX_DECT_LAU_MAX_SORTING_FIELDS){
      return IFX_FAILURE;
    }
     /* sorting field list */
     for(i=0;i<pxCmd->uxListCmd.xSessionMoveReq.ucNoOfSortingFields;i++){
       pxCmd->uxListCmd.xSessionMoveReq.aucSortingFields[i] = *pucBuff;
         pucBuff++;
     }
		break;
#endif 

 }
}/*Else part of Proprietary cmd*/
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_HandleReleaseMsg
* Description    : Handle LAU release message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_HandleReleaseMsg(x_IFX_DECT_IPC_Msg *pxIPCMsg)
{
  uchar8 ucSessLoc,ucHsId = pxIPCMsg->ucPara1;
  int16 nSessionId;
  //e_IFX_Return eRet = IFX_FAILURE;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "<IFX_DECT_LAU_HandleReleaseMsg>Entry." );
  /* Call the End session for all the sessions associated with that Handset */
  for(ucSessLoc =0; ucSessLoc<IFX_DECT_LAU_MAX_SESS_PER_HS;ucSessLoc++){
	if(ucHsId > 0 && ucHsId <= IFX_DECT_MAX_HS && axLauInfo[ucHsId-1][ucSessLoc].ucIsUsed == 1){
	  nSessionId = ((ucHsId-1)*IFX_DECT_LAU_MAX_SESS_PER_HS) + ucSessLoc + 1;
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "<IFX_DECT_LAU_HandleReleaseMsg>Invoking Session End Callbk." );
      printf("Handset=%d\n",ucHsId);

      if(vxLauCallBks.pfnSessionEnd != NULL){
        /*eRet=*/vxLauCallBks.pfnSessionEnd(nSessionId);
      }
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "<IFX_DECT_LAU_HandleReleaseMsg>Invoking LAU Reset." );
      IFX_DECT_LAU_Reset(ucHsId,&axLauInfo[ucHsId-1][ucSessLoc]);
	}
  }
  if(vxLauCallBks.pfnLinkRelease != NULL){
        /*eRet=*/vxLauCallBks.pfnLinkRelease(ucHsId);
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "<IFX_DECT_LAU_HandleReleaseMsg>Success" );
  return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_HandleIWUInfoMsg
* Description    : Handle LAU IWU Info message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_HandleIWUInfoMsg(x_IFX_DECT_IPC_Msg *pxIPCMsg)
{
  uint32 uiIEHdl = 0;
  int16 nSessId=0;
  x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
  x_IFX_DECT_LAU_ListCommands xInCmd={0};
  x_IFX_DECT_LAU_ListCommands xOutCmd={0};
  e_IFX_Return eRet=IFX_FAILURE;
  static uchar8 aucTempBuffer[250]="\0";
	static uchar8 ucLen=0;
	xOutCmd.eNackReason = 0xFF;
  if(0 == (uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIPCMsg)) ){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
    return IFX_FAILURE;
  }

  while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_IWUTOIWU){
    if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"NO IWU TO IWU IE");
       return IFX_FAILURE;
    }
  }
  if(IFX_DECT_IE_IWUToIWUGet(uiIEHdl,&xIWUToIWUInfo) != IFX_SUCCESS){
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"NO IWU TO IWU IE");
      return IFX_FAILURE;
  }
  
  //xIWUToIWUInfo.ucPD,xIWUToIWUInfo.ucSR,xIWUToIWUInfo.ucDefault1,xIWUToIWUInfo.ucIWUToIWULen
  if((xIWUToIWUInfo.ucPD != 0x03)||(xIWUToIWUInfo.ucIWUToIWULen<=0)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No For list access");
    return IFX_FAILURE;
  }
  eRet=IFX_DECT_LAU_DecodeCmd(xIWUToIWUInfo.acIWUToIWU,xIWUToIWUInfo.ucIWUToIWULen,
                         &xInCmd);
  if(eRet != IFX_SUCCESS){
  	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IFX_DECT_LAU_DecodeCmd failed");
     xOutCmd.nSessionId=-pxIPCMsg->ucPara1;
	 xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW; 
     goto Fail;	   
  }
  IFX_DECT_LAU_DbgInfo();
  if (xInCmd.ucListCmd & 0x80)
  {
  	/*Application call back to Handle Proprietary cmds*/
	if(vxLauCallBks.pfnHandleProprietaryCmds != NULL){
     if(vxLauCallBks.pfnHandleProprietaryCmds(pxIPCMsg->ucPara1,
	 	xIWUToIWUInfo.acIWUToIWU,xIWUToIWUInfo.ucIWUToIWULen)!= IFX_SUCCESS) 
     {
        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			"pfnHandleProprietaryCmds CB failed!!!");
		     xOutCmd.nSessionId=-pxIPCMsg->ucPara1;
	        xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW; 
            goto Fail;	  
     }
	}
	else
	{
		IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			"pfnHandleProprietaryCmds CB not registered!!!");
		     xOutCmd.nSessionId=-pxIPCMsg->ucPara1;
	        xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW; 
            goto Fail;	  
	}
	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			"pfnHandleProprietaryCmds CB Returned SUCCESS!!!");
	return IFX_SUCCESS;
  }
  
  /* If session Identifier is not valid return failure */
  if((xInCmd.ucListCmd != IFX_DECT_LAU_CMD_SESS_START_REQ) &&
     (IFX_DECT_LAU_ValidSessId(xInCmd.nSessionId) != IFX_SUCCESS)){
	
	 printf("\n Ignore Sess End Req\n");	 
	 if(xInCmd.ucListCmd == IFX_DECT_LAU_CMD_SESS_END_REQ){
	 	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Ignore Sess End Req\n");
	   return IFX_SUCCESS;
	 }	 
	 IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Invalid ?? xInCmd.nSessionId=",xInCmd.nSessionId);
	 xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM; 
     xOutCmd.nSessionId=xInCmd.nSessionId;
	 goto Fail;	   
  }
  /* Identify the command and call appropriate Call back */
  switch(xInCmd.ucListCmd)
  {
    case IFX_DECT_LAU_CMD_SESS_START_REQ:
        
	 /* Check if the List is supported */
	 if(IFX_DECT_LAU_CheckListSupport(xInCmd.uxListCmd.xSessionStartReq.eListId) 
	     != IFX_SUCCESS){
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"List Not supported");
	   //xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP; 
	   /*Here -ve HS is filled so that function IFX_DECT_LAU_ConfirmationSend
	   picks up right HS and then sets Session ID to 0*/
       xOutCmd.nSessionId=-pxIPCMsg->ucPara1;
	   xOutCmd.uxListCmd.xSessionStartCfm.ucRejectReason = 
	   	   IFX_DECT_LAU_SESS_START_REJ_REASON_NO_SUPPORT;
	   xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_SESS_START_CFM;     
       xOutCmd.uxListCmd.xSessionStartCfm.eListId = xInCmd.uxListCmd.xSessionStartReq.eListId;     
	   return IFX_DECT_LAU_ConfirmationSend(&xOutCmd);	   
	 }
	 /*Check if already a session with same List is ongoing?*/
	 {
	  int i=0;
	  for(i=0;i<IFX_DECT_LAU_MAX_SESS_PER_HS;i++)
	  {
	    if((axLauInfo[pxIPCMsg->ucPara1-1][i].ucIsUsed == 1) &&
			(axLauInfo[pxIPCMsg->ucPara1-1][i].eListId == xInCmd.uxListCmd.xSessionStartReq.eListId)){
		   
		  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Second session with same List??");		    
	       /*Here -ve HS is filled so that function IFX_DECT_LAU_ConfirmationSend
		   picks up right HS and then sets Session ID to 0*/
	       xOutCmd.nSessionId=-pxIPCMsg->ucPara1;
		   xOutCmd.uxListCmd.xSessionStartCfm.ucRejectReason = 
		   	   IFX_DECT_LAU_SESS_START_REJ_REASON_IN_USE;
		   xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_SESS_START_CFM;     
	       xOutCmd.uxListCmd.xSessionStartCfm.eListId = xInCmd.uxListCmd.xSessionStartReq.eListId;
		   return IFX_DECT_LAU_ConfirmationSend(&xOutCmd);   
		}
	  }
	 }

	 
	 /* Generate a session ID */
	 if(IFX_DECT_LAU_GenerateSessId(pxIPCMsg->ucPara1,&nSessId)!=IFX_SUCCESS){
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Gen SessID failed");
	   //xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_LIST_FULL; 
       /*Here -ve HS is filled so that function IFX_DECT_LAU_ConfirmationSend
	   picks up right HS and then sets Session ID to 0*/
       xOutCmd.nSessionId=-pxIPCMsg->ucPara1;
	   xOutCmd.uxListCmd.xSessionStartCfm.ucRejectReason = 
	   	   IFX_DECT_LAU_SESS_START_REJ_MAX_SESS_REACHED;
	   xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_SESS_START_CFM;     
       xOutCmd.uxListCmd.xSessionStartCfm.eListId = xInCmd.uxListCmd.xSessionStartReq.eListId;
	   return IFX_DECT_LAU_ConfirmationSend(&xOutCmd);   
	 }
	 
#ifdef KLOCWORK
	if((nSessId == 0) || (nSessId > IFX_DECT_MAX_HS*IFX_DECT_LAU_MAX_SESS_PER_HS)) 
		goto Fail;	
#endif

	/*Store the List ID*/	
	if(pxIPCMsg->ucPara1 > 0 && pxIPCMsg->ucPara1 <= IFX_DECT_MAX_HS && nSessId >0 && nSessId <= IFX_DECT_MAX_HS*IFX_DECT_LAU_MAX_SESS_PER_HS)  
	 axLauInfo[pxIPCMsg->ucPara1-1][(nSessId%IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId = xInCmd.uxListCmd.xSessionStartReq.eListId;
#ifdef LAU_TEST	
       IFX_DECT_MU_SetModuleOwner(pxIPCMsg->ucPara1,
                                  IFX_DECT_MU_ADD_OWNER,
						          IFX_DECT_LAU_ID);
#endif	
	 IFX_DECT_LAU_DbgInfo();
	 /* Fill Session ID in xInCmd */
     xInCmd.nSessionId = nSessId; 

	 /* Store the Active Call IDentifier */
	 if(pxIPCMsg->ucPara1 > 0 && pxIPCMsg->ucPara1 <= IFX_DECT_MAX_HS && nSessId >0 && nSessId <= IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS)  
	 IFX_DECT_CSU_GetActiveCallId(pxIPCMsg->ucPara1,&axLauInfo[pxIPCMsg->ucPara1-1][(nSessId %
				   IFX_DECT_LAU_MAX_SESS_PER_HS)-1].ucCallId);
	 IFX_DECT_LAU_DbgInfo();
   if(xInCmd.uxListCmd.xSessionStartReq.eListId == IFX_DECT_LAU_SUPPORTED){
     xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_SESS_START_CFM;
     xOutCmd.uxListCmd.xSessionStartCfm.aucSortingFields[0]=1;
     xOutCmd.nSessionId = xInCmd.nSessionId;
     xOutCmd.uxListCmd.xSessionStartCfm.eListId = xInCmd.uxListCmd.xSessionStartReq.eListId;
     xOutCmd.uxListCmd.xSessionStartCfm.nNoOfAvailEntries = 1;
     eRet = IFX_SUCCESS;
     break;
    }
	 /* Call the application call back */ 
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Calling Start sess CB");
	 if(vxLauCallBks.pfnSessionStart != NULL){
	   eRet = vxLauCallBks.pfnSessionStart(pxIPCMsg->ucPara1,&xInCmd,&xOutCmd);
	 }
	 IFX_DECT_LAU_DbgInfo();
	break;  
    case IFX_DECT_LAU_CMD_SESS_END_REQ:
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Calling sess end CB");
#ifdef KLOCWORK
	if((xInCmd.nSessionId > 0) && (xInCmd.nSessionId <= IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS))		
#endif
     if(axLauInfo[pxIPCMsg->ucPara1-1][(xInCmd.nSessionId%IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId == IFX_DECT_LAU_SUPPORTED){
     xOutCmd.nSessionId=xInCmd.nSessionId;
	   xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_SESS_END_CFM;
     eRet = IFX_SUCCESS;
     break;
   }
     if(vxLauCallBks.pfnSessionEnd != NULL){
	   eRet=vxLauCallBks.pfnSessionEnd(xInCmd.nSessionId);
	 }
     xOutCmd.nSessionId=xInCmd.nSessionId;
	 xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_SESS_END_CFM;
	 eRet=IFX_SUCCESS;
	break; 
	case IFX_DECT_LAU_CMD_FIELD_QUERY_REQ:
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Calling QUERY CB");
#ifdef KLOCWORK
	if((xInCmd.nSessionId > 0) && (xInCmd.nSessionId <= IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS))		
#endif
     if(axLauInfo[pxIPCMsg->ucPara1-1][(xInCmd.nSessionId%IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId == IFX_DECT_LAU_SUPPORTED){
     xOutCmd.nSessionId=xInCmd.nSessionId;
	   xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_FIELD_QUERY_CFM;
     xOutCmd.uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields =1;
     xOutCmd.uxListCmd.xFieldQueryCfm.aucUneditableFields[0]=1;
     xOutCmd.uxListCmd.xFieldQueryCfm.ucNoOfEditableFields = 0;
     eRet = IFX_SUCCESS;
     break;
   }
   if(vxLauCallBks.pfnFieldQuery != NULL){
	   eRet=vxLauCallBks.pfnFieldQuery(&xInCmd,&xOutCmd);
	 }
	break; 
	case IFX_DECT_LAU_CMD_ENTRIES_READ_REQ:
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Calling Read Entry CB");
#ifdef KLOCWORK
		 if((xInCmd.nSessionId > 0) && (xInCmd.nSessionId <= IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS))	 
#endif
     if(axLauInfo[pxIPCMsg->ucPara1-1][(xInCmd.nSessionId%IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId == IFX_DECT_LAU_SUPPORTED){
       uchar8 *pucDataPayload = NULL;
       uint16 unPayldSize=0;
       xOutCmd.nSessionId=xInCmd.nSessionId;
	     xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_ENTRIES_READ_CFM;
       xOutCmd.uxListCmd.xEntryReadCfm.ucNoOfDeliveredEntries =1;
       xOutCmd.uxListCmd.xEntryReadCfm.nStartIndex =1;
       IFX_DECT_LAU_ConfirmationSend(&xOutCmd);
       pucDataPayload = (uchar8*) malloc(1000 * sizeof(uchar8));
       IFX_DECT_LAU_DataPktPayloadEncode(xInCmd.nSessionId,
                                    IFX_DECT_LAU_SUPPORTED,
                                    NULL,
                                    &unPayldSize,
                                    ((char8 *)pucDataPayload));
       IFX_DECT_LAU_DataPktSend(xInCmd.nSessionId,
                           unPayldSize,
                           pucDataPayload);

       free(pucDataPayload);
       eRet = IFX_PROCESSED;
       break;
     }

     if(vxLauCallBks.pfnEntryRead != NULL){
	   eRet=vxLauCallBks.pfnEntryRead(&xInCmd,&xOutCmd);
	 }
	break; 
	case IFX_DECT_LAU_CMD_ENTRY_EDIT_REQ:
#ifdef KLOCWORK
	if((xInCmd.nSessionId > 0) && (xInCmd.nSessionId <= IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS))		
#endif
     if(axLauInfo[pxIPCMsg->ucPara1-1][(xInCmd.nSessionId%IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId == IFX_DECT_LAU_SUPPORTED){
       xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
       eRet = IFX_FAILURE; 
	     break; 
     } 
     if(vxLauCallBks.pfnEntryEdit != NULL){
	     eRet=vxLauCallBks.pfnEntryEdit(&xInCmd,&xOutCmd);
	   }
	break; 
    case IFX_DECT_LAU_CMD_ENTRY_SAVE_REQ:
#ifdef KLOCWORK
			if((xInCmd.nSessionId > 0) && (xInCmd.nSessionId <= IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS))		
#endif
     if(axLauInfo[pxIPCMsg->ucPara1-1][(xInCmd.nSessionId%IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId == IFX_DECT_LAU_SUPPORTED){
       xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
       eRet = IFX_FAILURE; 
	     break; 
     } 
     if(vxLauCallBks.pfnEntrySave != NULL){
	   eRet=vxLauCallBks.pfnEntrySave(&xInCmd,&xOutCmd);
	 }
	break; 
    case IFX_DECT_LAU_CMD_ENTRY_DELETE_REQ:
#ifdef KLOCWORK
			if((xInCmd.nSessionId > 0) && (xInCmd.nSessionId <= IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS))		
#endif
     if(axLauInfo[pxIPCMsg->ucPara1-1][(xInCmd.nSessionId%IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId == IFX_DECT_LAU_SUPPORTED){
       xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
       eRet = IFX_FAILURE; 
	     break; 
     } 
     if(vxLauCallBks.pfnEntryDelete != NULL){
	   eRet=vxLauCallBks.pfnEntryDelete(&xInCmd,&xOutCmd);
	 }
	break; 
	case IFX_DECT_LAU_CMD_LIST_DELETE_REQ:
#ifdef KLOCWORK
			if((xInCmd.nSessionId > 0) && (xInCmd.nSessionId <= IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS))		
#endif
     if(axLauInfo[pxIPCMsg->ucPara1-1][(xInCmd.nSessionId%IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId == IFX_DECT_LAU_SUPPORTED){
       xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
       eRet = IFX_FAILURE; 
	     break; 
     } 
     if(vxLauCallBks.pfnListDelete != NULL){
	   eRet=vxLauCallBks.pfnListDelete(&xInCmd,&xOutCmd);
	 }
	break; 
	case IFX_DECT_LAU_CMD_ENTRIES_SEARCH_REQ:
#ifdef KLOCWORK
			if((xInCmd.nSessionId > 0) && (xInCmd.nSessionId <= IFX_DECT_MAX_HS * IFX_DECT_LAU_MAX_SESS_PER_HS))		
#endif
     if(axLauInfo[pxIPCMsg->ucPara1-1][(xInCmd.nSessionId%IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId == IFX_DECT_LAU_SUPPORTED){
       xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
       eRet = IFX_FAILURE; 
	     break; 
     } 
     if(vxLauCallBks.pfnEntrySearch != NULL){
	   eRet=vxLauCallBks.pfnEntrySearch(&xInCmd,&xOutCmd);
	 }
	break; 
	case IFX_DECT_LAU_CMD_DATA_PKT:
     if(xInCmd.nSessionId <= 127){
      memcpy(aucTempBuffer+ucLen,(xIWUToIWUInfo.acIWUToIWU+2),(xIWUToIWUInfo.ucIWUToIWULen-2)+1);
			ucLen+=(xIWUToIWUInfo.ucIWUToIWULen-2);
			}
     else{
      memcpy(aucTempBuffer+ucLen,(xIWUToIWUInfo.acIWUToIWU+3),(xIWUToIWUInfo.ucIWUToIWULen-3)+1);
      ucLen+=(xIWUToIWUInfo.ucIWUToIWULen-3);
				}
        eRet = IFX_PROCESSED;
	break;
	case IFX_DECT_LAU_CMD_DATA_PKT_LAST:
     if(vxLauCallBks.pfnDataPktRecv != NULL){
	   if(xInCmd.nSessionId <= 127){
      memcpy(aucTempBuffer+ucLen,(xIWUToIWUInfo.acIWUToIWU+2),(xIWUToIWUInfo.ucIWUToIWULen-2)+1);
      ucLen+=(xIWUToIWUInfo.ucIWUToIWULen-2);
			printf("Length %d\n",ucLen);
	     eRet =vxLauCallBks.pfnDataPktRecv(xInCmd.nSessionId,
	                                /* (xIWUToIWUInfo.ucIWUToIWULen-2)*/ucLen,
		  						    /* (xIWUToIWUInfo.acIWUToIWU+2)*/aucTempBuffer);
		  }
	   else{
      memcpy(aucTempBuffer+ucLen,(xIWUToIWUInfo.acIWUToIWU+3),(xIWUToIWUInfo.ucIWUToIWULen-3)+1);
      ucLen+=(xIWUToIWUInfo.ucIWUToIWULen-3);
	     eRet =vxLauCallBks.pfnDataPktRecv(xInCmd.nSessionId,
	                                /* (xIWUToIWUInfo.ucIWUToIWULen-3)*/ucLen,
		  						    /* (xIWUToIWUInfo.acIWUToIWU+3)*/aucTempBuffer);
		  }
			ucLen=0;
			memset(aucTempBuffer,0,sizeof(aucTempBuffer));
	 }

			printf("Exit IFX_DECT_LAU_CMD_DATA_PKT_LAST\n");
	break;
#ifdef LTQ_DT_SUPPORT
	case IFX_DECT_LAU_CMD_SESS_MOVE_REQ:
#ifdef KLOCWORK
	if(xInCmd.nSessionId > 0)		
#endif		
				if(axLauInfo[pxIPCMsg->ucPara1-1][(xInCmd.nSessionId%IFX_DECT_LAU_MAX_SESS_PER_HS)-1].eListId == IFX_DECT_LAU_SUPPORTED){
       xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
       eRet = IFX_FAILURE;
       break;
     }
			if(vxLauCallBks.pfnSessionMove != NULL){
     eRet=vxLauCallBks.pfnSessionMove(&xInCmd,&xOutCmd);
		}
	break; 
#endif 
	  default:
	  return IFX_FAILURE;
  }
  if((eRet == IFX_PENDING)||(eRet == IFX_PROCESSED)){
	return IFX_SUCCESS;
  }
  if(eRet == IFX_SUCCESS){
    return IFX_DECT_LAU_ConfirmationSend(&xOutCmd);
  }
  Fail:
		if(xOutCmd.eNackReason == 0xFF)
      xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
    /* Send negative ack with eReason */
    IFX_DECT_LAU_NackSend(xInCmd.nSessionId,xOutCmd.eNackReason);
	return IFX_FAILURE;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_ProcessStackMsg
* Description    : Process LAU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_ProcessStackMsg(IN x_IFX_DECT_IPC_Msg *pxIPCMsg)
{
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IFX_DECT_LAU_ProcessStackMsg Entry");
  switch (pxIPCMsg->ucMsgId){
    case FP_RELEASE_IN_CC:
	{	
	  IFX_DECT_LAU_HandleReleaseMsg(pxIPCMsg);
	  break;
	}
	case FP_IWU_INFO_IN_CC:
    {
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IWU_INFO Msg");
	  IFX_DECT_LAU_HandleIWUInfoMsg(pxIPCMsg);	
      break;
	}
	default:
	{
	  break;
	}
  }
  return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_DataPktSend
* Description    : Send Data packet
* Input Values   : Session ID, Data Len and data
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_LAU_DataPktSend(IN int16 nSessId,
                         IN uint16 unDataLen, 
                         IN uchar8 *pucData)
{
  char8 ucInstance=0;
  uint32 uiIEHdl=0;
  uchar8 ucHandSetId=0;
  uchar8 *pcTemp=NULL;
  x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
  x_IFX_DECT_IPC_Msg xIpcReply = {0};
  uint16 unCount=0;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"In Data Pkt send API");
  
  if((pucData == NULL)||(unDataLen==0)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Len is 0 or buff is NULL");
    return IFX_FAILURE;
  }
  for(unCount=0;unCount<unDataLen;unCount++){
    printf("%x ",pucData[unCount]);	  
  }
  printf("\n");
  
  xIWUToIWUInfo.ucDefault1 = 1; /* Dont care */
  xIWUToIWUInfo.ucSR = 1;/* Stats/Rej */
  xIWUToIWUInfo.ucPD = 0x03;
  xIWUToIWUInfo.ucIWUToIWULen = 0;

  IFX_DECT_LAU_GetHSIdFromSessId(&ucHandSetId,nSessId);
  
  if(IFX_DECT_MU_IsCallExisting(ucHandSetId,(uchar8*)&ucInstance) != IFX_SUCCESS){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Link Exists");
    return IFX_FAILURE;
  }

  while(unDataLen > 0){
    printf("\n unDataLen = %d\n",unDataLen);  
    if(unDataLen > IFX_DECT_LAU_MAX_DATA_PER_PKT){
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Data greater than 56 bytes");
      xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen]=
		                                     IFX_DECT_LAU_CMD_DATA_PKT;	  
      //xIWUToIWUInfo.ucIWUToIWULen++;
	  pcTemp = &xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen];
      xIWUToIWUInfo.ucIWUToIWULen++;
      printf("\n Session Id:%d\n",nSessId);  
      IFX_DECT_LAU_ENCODE_2BYTEID(nSessId,pcTemp,
	                            xIWUToIWUInfo.ucIWUToIWULen);
      unDataLen -= IFX_DECT_LAU_MAX_DATA_PER_PKT;
      memcpy(&xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen],pucData,
	           IFX_DECT_LAU_MAX_DATA_PER_PKT);
        
	  xIWUToIWUInfo.ucIWUToIWULen += IFX_DECT_LAU_MAX_DATA_PER_PKT;		   
      for(unCount=0;unCount<xIWUToIWUInfo.ucIWUToIWULen;unCount++){
         printf("%x ",xIWUToIWUInfo.acIWUToIWU[unCount]);	  
      }
    pucData += IFX_DECT_LAU_MAX_DATA_PER_PKT;
	}
	else{
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Data less than 56 bytes");
      xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen]=
		                                     IFX_DECT_LAU_CMD_DATA_PKT_LAST;	  
	  xIWUToIWUInfo.ucIWUToIWULen++;
      pcTemp = (uchar8*)&xIWUToIWUInfo.acIWUToIWU;

      printf("\n Session Id:%d\n",nSessId);  
	  IFX_DECT_LAU_ENCODE_2BYTEID(nSessId,pcTemp,
	                            xIWUToIWUInfo.ucIWUToIWULen);
      memcpy(&xIWUToIWUInfo.acIWUToIWU[xIWUToIWUInfo.ucIWUToIWULen],pucData,unDataLen);
	  xIWUToIWUInfo.ucIWUToIWULen += unDataLen;

      for(unCount=0;unCount<xIWUToIWUInfo.ucIWUToIWULen;unCount++){
         printf("%x ",xIWUToIWUInfo.acIWUToIWU[unCount]);	  
      }
	  unDataLen = 0;
	}
  	if((uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcReply.acData))!=IFX_FAILURE){
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUTOIWU,(void *)&xIWUToIWUInfo) 
	         != IFX_SUCCESS){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IE add failed");
		return IFX_FAILURE;
	  }
	}
	else{
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Create NEW IE failed");
	  return IFX_FAILURE;
	}
	IFX_DECT_EncodeIWUInfo(ucHandSetId,ucInstance,&xIpcReply);
	xIpcReply.ucPara3=0xFF;
	IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
	memset(&xIpcReply,0,sizeof(xIpcReply));
	memset(xIWUToIWUInfo.acIWUToIWU,0,sizeof(xIWUToIWUInfo.acIWUToIWU));
  xIWUToIWUInfo.ucIWUToIWULen = 0;
  }
  
  return IFX_SUCCESS;
}

