/**************************************************************************
**   FILE NAME     : IFX_DECT_MU.c
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "IFX_DECT_Platform.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_StackIf.h"
#include "IFX_DECT_MsgEncoder.h"
#include "IFX_DECT_MsgRouter.h"
#include "IFX_DECT_DIAG_Int.h"
#include "IFX_DECT_DIAG.h"
#include "IFX_DECT_ULE_Global.h"
#define printf(...)
#ifdef CONFIG_REPEATER_SUPPORT
//#define RPT_TEST
#ifdef RPT_TEST
extern e_IFX_Return IFX_DECT_Repeater_ProcessCPlaneMsg(IN x_IFX_DECT_IPC_Msg *pxIpcMsg);
#endif
#endif



#define vxMUCallBks vxGlobalInfo.xMU.vxMUCallBks
#define vuiRegistrationTimerId vxGlobalInfo.xMU.vuiRegistrationTimerId
#define vacMCEI vxGlobalInfo.xMU.vacMCEI
#define vacCallId vxGlobalInfo.xMU.vacCallId
#define vxMUInfo vxGlobalInfo.xMU.vxMUInfo
#define veNemoState vxGlobalInfo.xMU.veNemoState
#define vuiNemoTimer vxGlobalInfo.xMU.vuiNemoTimer
#define vauiEMC vxGlobalInfo.xMU.vauiEMC

#define ucRegMode vxGlobalInfo.xMU.ucRegMode
#define ucRegInstance vxGlobalInfo.xMU.ucRegInstance
#define vacPropInfo vxGlobalInfo.xMU.vacPropInfo
#define vuiRingTimeOut vxGlobalInfo.uiRingTimeOut
#define vbRingPauseOn vxGlobalInfo.bRingPauseOn
unsigned int vuiNemoEnableFlag=1;
e_IFX_Return HandleDectDbg();
//e_IFX_Return IFX_DECT_MU_ULE_UnregisterPP(IN uchar8 ucInstance,IN uchar8 ucHandset);
//e_IFX_Return IFX_DECT_MU_ULE_UnRegister(IN uchar8 isAll,IN uchar8 ucHandset);
e_IFX_Return IFX_DECT_IE_TermCapGet(IN uint32 uiIEHdl,
                                    OUT x_IFX_DECT_IE_Term_Capability *pxTermCap);
extern e_IFX_Return IFX_DECT_SetFTCap(x_IFX_DECT_FTCap *pxFTCapabilities);
/*Variable maintaining the state of Alert reception while paging, 1 bit per handset 
  If no alerting followed by release - Treated as Handset out of range or switched off, continue paging
  Alerting followed by release - Explicit rejection of page so cancel page on all handsets*/
static uint32 uiPageResp;
#ifdef CAT_IQ2_0
/*******************************************************************************
*  Function Name   :IFX_DECT_MU_NemoIdleTimerFunc
*  Description     : This routine is used as callback function for nemo idle 
*                   timer event. In this routine nemo is retried if disabled.
*  Input Values    : uiTimerId - Expired timer-id.
*                   pvPrivateData - Pointer to private data that is passed to
*                      while starting timer.
*  Return Value    : None
*  Notes           :
******************************************************************************/
void IFX_DECT_MU_NemoIdleTimerFunc (IN uint32 uiTimerId,
                                     IN void* pvPrivateData)
{  
   uchar8 ucIndex = 0, Unregistered_PP = 0;

   IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
           "Nemo Idle Timer Expired.");
   vuiNemoTimer = 0;
	if(vuiNemoEnableFlag)
	{
   		IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
           "SBB: NEMO OFF");
		return;
	}
	if(veNemoState == IFX_DECT_MU_NEMO_OFF)
	{
   		IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
           "SBB: NEMO OFF state");
		return;
	}
	if(veNemoState == IFX_DECT_MU_NONEMO)
	{
   		IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
           "SBB: NO NEMO state");
		return;
	}
   if( ucRegMode == 1 )
   {
      // If Base is in the registration mode, no NoEmo.
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Base is in Registration mode, so start timer again");
	  veNemoState=IFX_DECT_MU_NEMO_IDLE;
      IFX_DECT_StartTimer(IFX_DECT_MU_NEMO_IDLE_TIME,NULL,0,
                          IFX_DECT_MU_NemoIdleTimerFunc, &vuiNemoTimer);
      return;
   }

   for( ucIndex = 0;  ucIndex < IFX_DECT_MAX_HS;  ucIndex++ )
   {
      if( vxMUInfo[ucIndex].eState == IFX_DECT_MU_HS_IDLE )
      {
         Unregistered_PP++;
	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT,
           "HS is IDLE:",ucIndex);
         continue;
      }
	  else if(!(vxMUInfo[ ucIndex ].uiTermCap & IFX_DECT_MU_HS_NEMO))
      {
		veNemoState=IFX_DECT_MU_NONEMO;
		
        IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "HS does not support NEMO",ucIndex);
        IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "HS State",vxMUInfo[ucIndex].eState);
		return;
	  }
      else if( vxMUInfo[ucIndex].eState < IFX_DECT_MU_HS_ATTACHED )
         {
					veNemoState=IFX_DECT_MU_NEMO_IDLE;
            IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                     "registered handsets not attached/lost sync? so start timer again",ucIndex);
		
            IFX_DECT_StartTimer(IFX_DECT_MU_NEMO_IDLE_TIME,NULL,0,
                                IFX_DECT_MU_NemoIdleTimerFunc, &vuiNemoTimer);
		
					return;
      }
      else if(vxMUInfo[ucIndex].eState > IFX_DECT_MU_HS_ATTACHED)
      {
         // If registered Handset is not Idle state, no NoEmo.
         IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "handsets are not idle, so start timer again",ucIndex);
		 veNemoState=IFX_DECT_MU_NEMO_IDLE;
         IFX_DECT_StartTimer(IFX_DECT_MU_NEMO_IDLE_TIME,NULL,0,
                             IFX_DECT_MU_NemoIdleTimerFunc, &vuiNemoTimer);
         return;
      }
   }
   // If there is no registered PP, no NoEmo.
   if( Unregistered_PP < IFX_DECT_MAX_HS )
   {
	  if(veNemoState == IFX_DECT_MU_NEMO_IDLE)
	  {
      IFX_DECT_MU_NemoStart( );
	  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "**********NEMO START*****");
   		veNemoState = IFX_DECT_MU_NEMO_PENDING; 
	  }
	  else
	  {
      	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "NEMO state is not Idle",veNemoState);
	  }
         return;
   }
   else
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "SBB: NEMO:None of the HS registered?");
         return;
   }
   if((uiTimerId == 0) && (pvPrivateData == NULL))
   {
   	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
           "Nemo Idle Timer Expired TimerId 0 PrvtData NULL.");
		 veNemoState=IFX_DECT_MU_NEMO_IDLE;
         IFX_DECT_StartTimer(IFX_DECT_MU_NEMO_IDLE_TIME,NULL,0,
                             IFX_DECT_MU_NemoIdleTimerFunc, &vuiNemoTimer);
		 
         return;
   }

}
#endif

/******************************************************************
*  Function Name    :IFX_DECT_MU_DenyRegistration
*  Description      : Deny Registration mode
*  Input Values     : 
*  Output Values    : 
*  Return Value     :IFX_SUCCESS/IFX_FAILURE 
*  Notes            :
*********************************************************************/
e_IFX_Return IFX_DECT_MU_DenyRegistration()
{
	
	x_IFX_DECT_IPC_Msg xIpcMsg = {0};
	
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Posting Deny Registration" );
  IFX_DECT_StopTimer(vuiRegistrationTimerId);
	xIpcMsg.ucMsgId = FP_ME_A44_CLEAR_RQ;
	ucRegMode = 0;
	return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
}


/************************************************************************
* Function Name  : IFX_DECT_MU_ProcessStackMsg
* Description    : Process MU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_MU_ProcessStackMsg(IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
   uchar8 ucHandsetNo = pxIpcMsg->ucPara1-1;
   uchar8 ucIndex =0;
   x_IFX_DECT_MU_NotifyInfo xAttachInfo={0};
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
             "Entered IFX_DECT_MU_ProcessStackMsg" );
  if(ucHandsetNo >= IFX_DECT_MAX_HS){
    return IFX_FAILURE;
  }
   switch (pxIpcMsg->ucMsgId){
     case FP_PORTABLE_REGISTERED_IN_MM:
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
               "FP_PORTABLE_REGISTERED_IN_MM message arrived",pxIpcMsg->ucPara1 );
        ucRegMode =2;
        ucRegInstance = pxIpcMsg->ucInstance;
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
               "FP_PORTABLE_REGISTERED_IN_MM message arrived Instance present within VcMMInfo",vxMUInfo[pxIpcMsg->ucPara1-1].ucInstance);
           IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                    "Handset Is  Registered" );
            vxMUInfo[pxIpcMsg->ucPara1-1].ucInstance = pxIpcMsg->ucInstance;
            vxMUInfo[pxIpcMsg->ucPara1-1].xSubscInfo.cmodel_id = pxIpcMsg->ucPara2;
        vxMUInfo[ucHandsetNo].eState = IFX_DECT_MU_HS_REGISTERD; 
        if( vxMUCallBks.pfn_MU_Notify != NULL){
          xAttachInfo.ucHandSet = pxIpcMsg->ucPara1;
          xAttachInfo.eEvent = IFX_DECT_MU_REGISTERED;
					vauiEMC[ucHandsetNo] = (pxIpcMsg->ucPara3 << 8); 
					vauiEMC[ucHandsetNo] |= (pxIpcMsg->ucPara4 ); 
					xAttachInfo.uiEMC=vauiEMC[ucHandsetNo]; 
		  		xAttachInfo.uiReserved = IFX_DECT_IE_GetIEHandler(pxIpcMsg);


	/*To Check proprietery IEs*/
	{			
		e_IFX_Return eRet = IFX_SUCCESS;
		x_IFX_DECT_IE_EscapeToProprietary xETPInfo;
		uint32 uiIEHdl = xAttachInfo.uiReserved;

		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	            "Start of <MU_FetchESCAPETOPROPRIETARY>Api");
		
		while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_ESCAPETOPROPRIETARY){
    
     		if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
	         
	     	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		      	   "<MU_FetchESCAPETOPROPRIETARY>NextIEHandlerGet Failed.");

	     	eRet = IFX_FAILURE;
	     	break;
	   		}
   		}
   		if(IFX_SUCCESS == eRet){
	    
     		if(IFX_DECT_IE_EscapeToProprietaryGet(uiIEHdl,&xETPInfo) == IFX_FAILURE){

       				IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "<MU_FetchESCAPETOPROPRIETARY>Api IFX_DECT_IE_EscapeToProprietaryGet failed.");
       			//return IFX_FAILURE; 
     		}
			else
			{     		
	   			IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	            "<MU_FetchESCAPETOPROPRIETARY>Api Successful.");
			}
   		}   
	} /*To Check proprietery IEs*/
          vxMUCallBks.pfn_MU_Notify(&xAttachInfo);
        }
#ifdef ENABLE_PAGING
		IFX_DECT_STOP_REGISTRATION(); 
#endif
       break;
     case FP_PORTABLE_ATTACHED_IN_MM:
        if(vxMUInfo[pxIpcMsg->ucPara1-1].eState == IFX_DECT_MU_HS_IDLE){
			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " Handset not yet registered so returning" );
			return IFX_SUCCESS;
		}

        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "FP_PORTABLE_ATTACHED_IN_MM message arrived" );
       if( IFX_DECTNG_CODEC_G722_64 == pxIpcMsg->ucPara2 ||
           IFX_DECTNG_CODEC_G722_64 == pxIpcMsg->ucPara3 ||
           IFX_DECTNG_CODEC_G722_64 == pxIpcMsg->ucPara4   ){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,
                  IFX_DBG_STR,
                  "This Handset Supports Wideband Calls" );
          vxMUInfo[pxIpcMsg->ucPara1-1].bWidebandEnabled = IFX_TRUE;
       }else{
          IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,
                   IFX_DBG_STR,
                   "This Handset Does Not Support Wideband Calls" );
           vxMUInfo[pxIpcMsg->ucPara1-1].bWidebandEnabled = IFX_FALSE;
      }
      vxMUInfo[ucHandsetNo].eState = IFX_DECT_MU_HS_ATTACHED;
#ifdef CAT_IQ2_0
		if(veNemoState == IFX_DECT_MU_NEMO_OFF){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"NEMO OFF??" );
			/*Nothing to do*/
		}else if((vxMUInfo[ucHandsetNo].uiTermCap & IFX_DECT_MU_HS_NEMO)&&
	     (veNemoState == IFX_DECT_MU_NEMO_IDLE)){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"NEMO HS supports" );
	     if(vuiNemoTimer ==0){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"NEMO Timer1" );
		    IFX_DECT_StartTimer(IFX_DECT_MU_NEMO_IDLE_TIME,NULL,0,
			                    IFX_DECT_MU_NemoIdleTimerFunc,
								&vuiNemoTimer);
		 }
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"NEMO Timer2" );
	  }else if(!(vxMUInfo[ucHandsetNo].uiTermCap & IFX_DECT_MU_HS_NEMO)){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Set NONEMO state" );
	     veNemoState = IFX_DECT_MU_NONEMO;
	     if(vuiNemoTimer){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Stop NEMO timer" );
		   IFX_DECT_StopTimer(vuiNemoTimer);
		   vuiNemoTimer =0;
		 }
	  }
#endif

#ifndef ENABLE_PAGING
   	  IFX_DBGA(vucDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
				"No Paging Button. Allowing Registration ");
	  IFX_DECT_MU_AllowRegistration(IFX_DECT_REG_DURATION);
#else
	  if((ucRegMode == 2) && (ucRegInstance == pxIpcMsg->ucInstance)){
	    IFX_DECT_MU_DenyRegistration();
     IFX_DECT_StopTimer(vuiRegistrationTimerId);
		vuiRegistrationTimerId=0;
	  }
#endif


#if(defined RPT_TEST && defined CONFIG_REPEATER_SUPPORT)

pxIpcMsg->ucPara1=224;

IFX_DECT_Repeater_ProcessCPlaneMsg(pxIpcMsg);

#else
 
      if(1/*vxMUInfo[ucHandsetNo].bPPAttached != 1*/ ){
        x_IFX_DECT_SubscInfo *pxDectSubsInfo;
        vxMUInfo[ucHandsetNo].bPPAttached =1; 
        pxDectSubsInfo = (x_IFX_DECT_SubscInfo*)
                         (pxIpcMsg->acData + sizeof(struct HLI_Header));
        memcpy(&vxMUInfo[ucHandsetNo].xSubscInfo, pxDectSubsInfo,
               sizeof(x_IFX_DECT_SubscInfo));
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "Calling Callback pf_MU_Attached if not null");
        if( vxMUCallBks.pfn_MU_Notify != NULL){
          xAttachInfo.ucHandSet = pxIpcMsg->ucPara1;
          xAttachInfo.eEvent = IFX_DECT_MU_ATTACHED; 
          xAttachInfo.pxSubscInfo = pxDectSubsInfo;
          xAttachInfo.ucCodec_Pri1= pxIpcMsg->ucPara2;
          xAttachInfo.ucCodec_Pri2= pxIpcMsg->ucPara3;
          xAttachInfo.ucCodec_Pri3= pxIpcMsg->ucPara4;
					xAttachInfo.uiEMC=vauiEMC[ucHandsetNo]; 
		  xAttachInfo.uiReserved = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
		  xAttachInfo.uiTermCap = vxMUInfo[ucHandsetNo].uiTermCap;
          xAttachInfo.ucDspLines = vxMUInfo[ucHandsetNo].ucDspLines;
		  xAttachInfo.ucCharPerLine = vxMUInfo[ucHandsetNo].ucCharPerLine;
		  printf("The Term Cap is %x\n",xAttachInfo.uiTermCap); 
		  printf("The Sbsiscrption Term Cap is %x\n",pxDectSubsInfo->uiTermCap); 
          vxMUCallBks.pfn_MU_Notify(&xAttachInfo);        
        }
      }
#endif
     break;
   case FP_ACCESS_RIGHTS_TERMINATE_CFM_MM:
			/* Clearing the info is done at Unregister initiate itself*/
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
               "FP_ACCESS_RIGHTS_TERMINATE_CFM_MM: message arrived",pxIpcMsg->ucPara1 );
     break;
   case FP_PROP_INFO_IN_MM:
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "FP_PROP_INFO_IN_MM: message arrived" );
	 memcpy(vacPropInfo,pxIpcMsg->acData,IFX_IPC_DECT_MAX_DATA_SIZE);
     if( vxMUCallBks.pfn_MU_Notify != NULL){
          xAttachInfo.ucHandSet = pxIpcMsg->ucPara1;
          xAttachInfo.eEvent = IFX_DECT_MU_PROP_INFO;
					xAttachInfo.uiEMC=vauiEMC[ucHandsetNo]; 
          xAttachInfo.uiIEHdlr = (uint32)(vacPropInfo + sizeof( struct HLI_Header ) + 2);
          vxMUCallBks.pfn_MU_Notify(&xAttachInfo);        
     }
     break;
#ifdef CAT_IQ2_0
   case FP_MAC_NOEMO_IN_ME:
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "FP_PROP_NEMO_IN_MM: message arrived" );
     switch(pxIpcMsg->ucPara1){
	   case MAC_NOEMOM_ACTIVE:
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "MAC NEMO ACTIVE: message arrived" );
			if(veNemoState == IFX_DECT_MU_NEMO_PENDING)
			{
	     veNemoState = IFX_DECT_MU_NEMO_ACTIVE;
			}
	     break;
	   case MAC_NOEMOM_WAKEUP:
	   {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "MAC NEMO WAKEUP: message arrived posting STOP NEMO" );
			//if((veNemoState == IFX_DECT_MU_NEMO_STOP_PENDING) || (veNemoState == IFX_DECT_MU_NEMO_ACTIVE))
			if((veNemoState != IFX_DECT_MU_NEMO_OFF) || (veNemoState != IFX_DECT_MU_NONEMO))
			{
         		IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               	"MAC NEMO WAKEUP: message arrived posting STOP NEMO" );
		 		//veNemoState = IFX_DECT_MU_NEMO_STOP_PENDING;
         		//IFX_DECT_MU_NemoStop();
		 veNemoState = IFX_DECT_MU_NEMO_IDLE;
		 if(vuiNemoTimer == 0){
		    IFX_DECT_StartTimer(IFX_DECT_MU_NEMO_IDLE_TIME,NULL,0,
			                    IFX_DECT_MU_NemoIdleTimerFunc,
								&vuiNemoTimer);
				
				}
		 }
#if 0
			else{
         			IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "MAC NEMO WAKEUP: message arrived posting STOP NEMO but in wrong sate pls chk!!!!!" );
					veNemoState = IFX_DECT_MU_NEMO_IDLE;
			}
#endif
	   }
	     break;
	   case MAC_NOEMOM_TBC_ACTIVE:
	   {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "MAC NEMO TBC Active: message arrived posting START NEMO after timer fires");
		 if((veNemoState != IFX_DECT_MU_NONEMO) && (veNemoState != IFX_DECT_MU_NEMO_OFF))
		 {
		 if(vuiNemoTimer == 0){
		    IFX_DECT_StartTimer(IFX_DECT_MU_NEMO_IDLE_TIME,NULL,0,
			                    IFX_DECT_MU_NemoIdleTimerFunc,
								&vuiNemoTimer);
		 }
		 veNemoState = IFX_DECT_MU_NEMO_IDLE;
	   }
	   }
	     break;
   
	 }
     break;
#endif
   case FP_MODEM_BOOT_IND:
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "FP_MODEM_BOOT_IND: message arrived" );
     /* check if registration is going on than stop it*/
     for(ucIndex = 0 ; ucIndex < IFX_DECT_MAX_HS; ++ucIndex){
	    if(vxMUInfo[ucIndex].uiModuleOwner & IFX_DECT_MU_ID){
          /* go out of the loop, since this shall stop the paging process on all handsets*/
          IFX_DECT_MU_PageCancel();
		  break; 
        }
	 }
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "Calling vxMUCallBks.pf_MU_ModemReset if not null" );
     if( vxMUCallBks.pfn_MU_ModemReset != NULL){
       vxMUCallBks.pfn_MU_ModemReset();
     }
     for(ucIndex = 0 ; ucIndex < IFX_DECT_MAX_HS; ++ucIndex){
        if( vxMUInfo[ucIndex].eState != IFX_DECT_MU_HS_IDLE )
        {
           vxMUInfo[ucIndex].eState = IFX_DECT_MU_HS_ATTACHED;
        }
        vxMUInfo[ucIndex].uiModuleOwner =0; 
     }

     break;
	case FP_ALERT_IN_CC:
			{	
				IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"ALERT Received For Paging");
        uiPageResp |= (1<<ucHandsetNo);
				if((vxMUInfo[pxIpcMsg->ucPara1-1].uiTermCap & IFX_DECT_MU_HS_CAT2) && (IFX_DECT_ENCRYPTION_MODE == IFX_TRUE))
				{
					x_IFX_DECT_IPC_Msg xIpcMsg={0};
					IFX_DECT_EncodeAuthPTReq(pxIpcMsg->ucPara1,vxMUInfo[ucHandsetNo].ucInstance,&xIpcMsg);
					IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
				}
	   break;
	}
	case FP_AUTHENTICATE_PT_CFM_MM:
	{
			if(pxIpcMsg->ucPara2 ==1)
			{
			x_IFX_DECT_IPC_Msg xIpcMsg={0};
			IFX_DECT_EncodeEnableCipher(pxIpcMsg->ucPara1,
                                        pxIpcMsg->ucInstance, 
	                                    1,
                                        &xIpcMsg);
            IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
			}
			break;
	}
#if 0
	case FP_RELEASE_IN_CC:
    {	
	  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"Release Received For Paging,stop paging only on that handset, but continue paging on others");
	   break;
	}
#endif
	 case FP_DEBUG_INFO_IND:
	 break;
		case FP_RELEASE_IN_CC:
		{
         IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"RELEASE Received For Paging");
  				if( vxMUCallBks.pfn_MU_Notify != NULL){
          	xAttachInfo.ucHandSet = ucHandsetNo;
          	xAttachInfo.eEvent = IFX_DECT_MU_REJECT_PAGING; 
         		vxMUCallBks.pfn_MU_Notify(&xAttachInfo);        
     			} 
			break;
		}
    case FP_CONNECT_IN_CC:
//		default:
         IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"CONNECT Received For Paging");
     if((FP_RELEASE_IN_CC == pxIpcMsg->ucMsgId)&&(!(uiPageResp & (1<<ucHandsetNo)))){
       break;
     }
     IFX_DECT_MU_PageCancel();
     if( vxMUCallBks.pfn_MU_Notify != NULL){
          xAttachInfo.ucHandSet = ucHandsetNo;
          xAttachInfo.eEvent = IFX_DECT_MU_STOPPED_PAGING; 
					xAttachInfo.uiEMC=vauiEMC[ucHandsetNo]; 
         vxMUCallBks.pfn_MU_Notify(&xAttachInfo);        
     }       
     break;
   } 
  return IFX_SUCCESS;
}
#ifdef CAT_IQ2_0 
uint32 IFX_DECT_CheckWB(uint32 uiTermCap)
{
	return uiTermCap & IFX_DECT_MU_HS_WB;
}
uint32 IFX_DECT_DecodeTermCap(uchar8 ucHandset,
                             uchar8 *ucGPTR)
{
  uint32 uiIEHdlr = (uint32)ucGPTR,uiTermCap=0;
  uint32 *puiTermCap =&uiTermCap;
  x_IFX_DECT_IE_Term_Capability xTermCap={0};
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		  "Getting Terminal Cap");
	
  IFX_DECT_IE_TermCapGet(uiIEHdlr,&xTermCap);
  
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		  "Terminal Cap IE Found ");

  if(xTermCap.ucToneCap & 0x3){
    *puiTermCap|= IFX_DECT_MU_HS_CALLWAITTONE;
  }
  
  if((xTermCap.ucSlotTypeCap == 8)||(xTermCap.ucSlotTypeCap == 9)){
     *puiTermCap|= IFX_DECT_MU_HS_FULLSLOT;
   }

  if((xTermCap.ucSlotTypeCap & 0x4)||(xTermCap.ucSlotTypeCap & 0x2)){
     *puiTermCap|= IFX_DECT_MU_HS_WB;
   }
   
   
  if(xTermCap.ucProfInd1 & 0x2){
    *puiTermCap|= IFX_DECT_MU_HS_GAP;
  } 
  
  if((xTermCap.ucProfInd1 & 0x32)&&
     (xTermCap.ucProfInd2 & 0x3)){
     *puiTermCap|= IFX_DECT_MU_HS_DPRS;
   }
   
  if((xTermCap.ucProfInd6 & 0x40)==0x40){
     *puiTermCap|= IFX_DECT_MU_HS_NEMO;
  }


  if(xTermCap.ucProfInd7 & 0x2){
    *puiTermCap|= IFX_DECT_MU_HS_WB;
  }
  if(xTermCap.ucProfInd7 & 0x08){
    *puiTermCap|= IFX_DECT_MU_HS_HPP;
  }
	switch(xTermCap.ucEchoParam) {
		case 0x00:
    *puiTermCap|= IFX_DECT_MU_HS_ECHO_NA;
		 break;
		case 0x01:
    *puiTermCap|= IFX_DECT_MU_HS_ECHO_MINTCL;
		 break;
		case 0x02:
    *puiTermCap|= IFX_DECT_MU_HS_ECHO_TCL_46;
		 break;
		case 0x03:
    *puiTermCap|= IFX_DECT_MU_HS_ECHO_TCL_55;
		 break;
		default:
		break;
	}
  if((xTermCap.ucProfInd7 & 0x06)==0x06){
    *puiTermCap|= IFX_DECT_MU_HS_CAT2;
    *puiTermCap|= IFX_DECT_MU_HS_CID;
    *puiTermCap|= IFX_DECT_MU_HS_PCALL;
    *puiTermCap|= IFX_DECT_MU_HS_MLINE;
  }
  printf("TermCap is %x and Profile 7 is %x\n",*puiTermCap,xTermCap.ucProfInd7);
  printf("Call Waiting is %x\n Full Slot is %x\n, GAP is %x\n DPRS is %x\n NEMO is %x\n,WB is %x\n",
         IFX_DECT_MU_HS_CALLWAITTONE,IFX_DECT_MU_HS_FULLSLOT,IFX_DECT_MU_HS_GAP,IFX_DECT_MU_HS_DPRS,
		 IFX_DECT_MU_HS_NEMO,IFX_DECT_MU_HS_WB);
  
  printf("CATIQ2 is %x\n CID %x\n  PCALL %x\n MLINE %x\n",
         IFX_DECT_MU_HS_CAT2,IFX_DECT_MU_HS_CID,IFX_DECT_MU_HS_PCALL,IFX_DECT_MU_HS_MLINE);

   if(ucHandset > 0 && ucHandset <= IFX_DECT_MAX_HS)
   {
      vxMUInfo[ucHandset-1].ucDspLines =xTermCap.ucNoOfLinesPhyDisp;
      vxMUInfo[ucHandset-1].ucCharPerLine=xTermCap.ucNoOfChrInLine;
      vxMUInfo[ucHandset-1].uiTermCap = uiTermCap;
   }
 
  return uiTermCap;

}


/************************************************************************
* Function Name  : IFX_DECT_MU_NemoStart
* Description    : This function starts nemo mode
* Input Values   : 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_MU_NemoStart()
{
  if(veNemoState == IFX_DECT_MU_NONEMO){
      return IFX_FAILURE;
  }else if(veNemoState == IFX_DECT_MU_NEMO_IDLE){
     x_IFX_DECT_IPC_Msg xIpcMsg={0};
	 xIpcMsg.ucPara1 = MAC_NOEMOM_START;
     // This value should be stored into Flash Memory
	 xIpcMsg.ucPara2 = 8;
	 xIpcMsg.ucPara3 = vxGlobalInfo.xStackCfg.uiNoOfFramesNeMo;     // 256 + uiNoOfFramesNeMo
	 xIpcMsg.ucMsgId = FP_ME_MAC_NOEMO_RQ;
   return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  }
  /* Already NEMO Started*/
  return IFX_FAILURE;
}

/************************************************************************
* Function Name  : IFX_DECT_MU_NemoStop
* Description    : This function stops nemo mode
* Input Values   : 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_MU_NemoStop()
{
  if(veNemoState == IFX_DECT_MU_NONEMO){
      return IFX_FAILURE;
  }else if(veNemoState != IFX_DECT_MU_NEMO_IDLE){
     x_IFX_DECT_IPC_Msg xIpcMsg={0};
	 xIpcMsg.ucPara1 = MAC_NOEMOM_STOP;
     // This value should be stored into Flash Memory
	 xIpcMsg.ucPara2 = 8;
	 xIpcMsg.ucPara3 = vxGlobalInfo.xStackCfg.uiNoOfFramesNeMo;     // 256 + uiNoOfFramesNeMo
	 xIpcMsg.ucMsgId = FP_ME_MAC_NOEMO_RQ;
     return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  }
  /* Already NEMO Started*/
  return IFX_FAILURE;
}
#endif

/************************************************************************
* Function Name  : IFX_DECT_MU_RegisterCallBks
* Description    : This function register Application notification call backs
* Input Values   : call backs
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
 PUBLIC e_IFX_Return
 IFX_DECT_MU_RegisterCallBks(IN x_IFX_DECT_MU_CallBks *pxCCCallBks)
 {
   uchar8 ucIndex=0;
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "Callbacks of MU module registerd" );
   memcpy(&vxMUCallBks,pxCCCallBks,sizeof(x_IFX_DECT_MU_CallBks));
   memset(&vxMUInfo,0,sizeof(x_IFX_DECT_MUInfo)*IFX_DECT_MAX_HS);
   memset(&vacMCEI,0,sizeof(vacMCEI));
   memset(&vacCallId,0,sizeof(vacCallId));
   ucRegMode =0;
   vuiNemoTimer =0;
   vuiRegistrationTimerId = 0;
   vuiRingTimeOut=0;
   for(ucIndex=0;ucIndex <IFX_DECT_MAX_HS;ucIndex++){
     vxMUInfo[ucIndex].eState =IFX_DECT_MU_HS_IDLE;
     vxMUInfo[ucIndex].ucInstance = IFX_DECT_INVALID_INSTANCE;
   }
   return IFX_SUCCESS;
 }

/*******************************************************************************
*  Function Name   : IFX_DECT_RegistrationTimerFired
*  Description     : This routine is used as callback function for regitration
*                   timer event. In this routine registration is disabled.
*  Input Values    : uiTimerId - Expired timer-id.
*                   pvPrivateData - Pointer to private data that is passed to
*                      while starting timer.
*  Return Value    : None
*  Notes           :
******************************************************************************/
void IFX_DECT_RegistrationTimerFired(IN uint32 uiTimerId,
                                     IN void* pvPrivateData)
{
#ifdef ENABLE_PAGING
   IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
           "Registration Timer Expired. Stopping Registration");
   vuiRegistrationTimerId = 0;
   IFX_DECT_MU_DenyRegistration();
#else
   /* This part is used only during development. This enables base into
      registration mode and registration mode is never disabled.*/
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
            "Allowing Registration Now................");
   IFX_DECT_MU_AllowRegistration(IFX_DECT_REG_DURATION);
#endif
}

/************************************************************************
* Function Name  : IFX_DECT_MU_RegistrationAllow
* Description    : Allows registration
* Input Values   : 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
 PUBLIC e_IFX_Return IFX_DECT_MU_RegistrationAllow(IN uint32 uiTime,
                                                   IN char8 * pcBaseName)
 {
	 x_IFX_DECT_IPC_Msg xIpcMsg = {0};
   char* send_data=NULL;
   int iLen=0;
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Allow Registration from App" );
	 xIpcMsg.ucMsgId = FP_ME_A44_SET_RQ;
	 ucRegMode =1;
	 IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
   /* Send the basename only if the given data is less than 18 bytes */
   if((pcBaseName != NULL)&&((iLen=strlen(pcBaseName))<IFX_MAX_BASENAME)){
     /* This is done as the TestAppWriteDebugInfo frees the buffer in the end */
     send_data = malloc(G_PTR_MAX_DEBUG_COUNT);
     if(send_data == NULL){
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR ,
            "Malloc failed for base name");
       return IFX_FAILURE;
     }
     /* Cosic modem expects GW to contruct the data sections and provide the total length
        using a debug packet. Broadcasting is taken care in the modem once registration mode is entered */
     send_data[0]=iLen+3;/* Length indication to the Cosic modem for filling length in Address section */
     send_data[1]=NETWORK_PARAMETER;/* Network Parameter */
     send_data[2]=iLen+1;/* Actual length to be filled in the data section*/
     send_data[3]=DEVICE_NAME;/* Device Name */
     strcpy((char*)&send_data[4],pcBaseName);
     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "pcBaseName");
     printf("Sending Base name in debug pkt %s\n",pcBaseName);
     TestAppWriteDebugInfo(0x05, 1, 0,(FPTR)send_data);
   }
   if(uiTime >0){
       if( IFX_SUCCESS != IFX_DECT_StartTimer(uiTime,
           0, 0, IFX_DECT_RegistrationTimerFired, &vuiRegistrationTimerId) )
       {
          IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "Could Not Start Timer. Registration Of PPs Will Not Be Stopped");
       }

    }
    return IFX_SUCCESS;
 }
/******************************************************************
*  Function Name    :IFX_DECT_UnregisterPP
*  Description      : Unregisters handset
*  Input Values     : handset number and ucInstance
*  Output Values    : 
*  Return Value     : IFX_SUCCESS/IFX_FAILURE
*  Notes            :
*********************************************************************/

e_IFX_Return IFX_DECT_MU_UnregisterPP(
	                      IN uchar8 ucInstance,
	                      IN uchar8 ucHandset)
{
   x_IFX_DECT_IPC_Msg xIpcMsg = {0};
	 x_IFX_DECT_MU_NotifyInfo xAttachInfo = {0};
	 //boolean bRegPP=0, bNoNemoPP=0;
//	 uint16 i=0;
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Unregister from App" );
   xIpcMsg.ucMsgId = FP_MM_ACCESS_RIGHTS_TERMINATE_RQ;
   xIpcMsg.ucInstance = ucInstance;
   xIpcMsg.ucPara1 = ucHandset;

#ifdef ULE_SUPPORT
	if((ucHandset >= IFX_DECT_ULE_OFFSET) && (ucHandset < (IFX_DECT_ULE_OFFSET + IFX_DECT_MAX_ULE_DEVICES)))
	{
		IFX_DECT_MU_ULE_UnregisterPP(ucInstance,ucHandset);
		return IFX_SUCCESS;
 	}
#endif
	if(ucHandset <=0 || ucHandset > IFX_DECT_MAX_HS)
		return IFX_FAILURE;

		if(!(vxMUInfo[ucHandset-1].uiTermCap & IFX_DECT_MU_HS_NEMO)&&
	     (veNemoState == IFX_DECT_MU_NONEMO)){
	veNemoState=IFX_DECT_MU_NEMO_IDLE;
#if 0
				for(i=0;i<IFX_DECT_MAX_HS;i++){
					if((vxMUInfo[i].eState>=IFX_DECT_MU_HS_REGISTERD)&&(i+1 != ucHandset)){
						bRegPP=1;
						if(!(vxMUInfo[i].uiTermCap & IFX_DECT_MU_HS_NEMO))
							bNoNemoPP=1;
					}
				}
	     if( (bNoNemoPP == 0) && (bRegPP == 1)){
				veNemoState = IFX_DECT_MU_NEMO_IDLE;
		    IFX_DECT_StartTimer(IFX_DECT_MU_NEMO_IDLE_TIME,NULL,0,
			                    IFX_DECT_MU_NemoIdleTimerFunc,
								&vuiNemoTimer);
		 	}else if(bNoNemoPP == 0){
				veNemoState = IFX_DECT_MU_NEMO_IDLE;
			}
#endif
		}
		IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
/*Freeing the MU Info without waiting for confirmation from HS*/
/*Needed when we dont get any response from HS or HS is switched off while unregistering*/
     vxMUInfo[ucHandset-1].bPPAttached =0;
     //IFX_DECT_FreeMCEI(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance);
     vxMUInfo[ucHandset-1].eState = IFX_DECT_MU_HS_IDLE;
     vxMUInfo[ucHandset-1].uiModuleOwner =0; 
     memset(&vxMUInfo[ucHandset-1].xSubscInfo,0,sizeof(x_IFX_DECT_SubscInfo));
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  "Calling Callback pf_MU_Attached if not null",vxMUInfo[ucHandset-1].ucInstance);
     if( vxMUCallBks.pfn_MU_Notify != NULL){
          xAttachInfo.ucHandSet = ucHandset;
          xAttachInfo.eEvent = IFX_DECT_MU_UNREGISTERED; 
					//xAttachInfo.uiEMC=vauiEMC[ucHandsetNo]; 
         vxMUCallBks.pfn_MU_Notify(&xAttachInfo);        
     }       
     vxMUInfo[ucHandset-1].ucInstance = IFX_DECT_INVALID_INSTANCE;
		IFX_DECT_MU_NemoIdleTimerFunc(0,NULL);
		 return IFX_SUCCESS;
}
/************************************************************************
* Function Name  :IFX_DECT_MU_UNRegister 
* Description    : Unregister Handsets 
* Input Values   : unregister all or perticular handset
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
PUBLIC e_IFX_Return IFX_DECT_MU_UNRegister(IN uchar8 isAll,
                                           IN uchar8 ucHandset)
{
  uchar8 ucIndex;
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Unregister from App" );
  if(isAll){
    for ( ucIndex=0;ucIndex < IFX_DECT_MAX_HS;ucIndex++){
      if((vxMUInfo[ucIndex].eState >= IFX_DECT_MU_HS_REGISTERD)){/*Unregister HS if registered irrespective of any other state*/

         IFX_DECT_MU_UnregisterPP(ucIndex,ucIndex+1);
      }
    }
  }else{
      if(ucHandset > 0 && ucHandset <= IFX_DECT_MAX_HS && (vxMUInfo[ucHandset-1].eState >= IFX_DECT_MU_HS_REGISTERD)){/*Unregister HS if registered irrespective of any other state*/
         IFX_DECT_MU_UnregisterPP(ucHandset-1,ucHandset);
    }
  }
#ifdef ULE_SUPPORT
	IFX_DECT_MU_ULE_UNRegister(isAll,ucHandset);
#endif

  return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_MU_Add_Prop_IE_2
*  Description      : Add prop IE
*  Input Values     : 
*  Output Values    : 
*  Return Value     : IFX_SUCCESS/IFX_FAILURE
*  Notes            :
*********************************************************************/
void
IFX_DECT_MU_Add_Prop_IE_2( FPTR frame_ptr, BYTE ie_identifier, BYTE ie_byte_1 )
{
   FPTR buff;
   BYTE current_pos;

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Paging from App" );
   if ( frame_ptr == NULL || ie_byte_1 == DUMMY_FILL )
   {
      return;
   }

   current_pos = ((DATA_FRAME *) frame_ptr)->length;

   if ( current_pos + 2 > MAX_PROPRIETARY_CODE_LENGTH )
   {
      //FATAL_ERROR( UNKNOWN_ERROR );
      return;
   }

   buff = ((DATA_FRAME *) frame_ptr)->dat;

   buff[ current_pos++ ] = ie_identifier;
   buff[ current_pos++ ] = ie_byte_1;

   ((DATA_FRAME *) frame_ptr)->length = current_pos;
}
/******************************************************************
*  Function Name    :IFX_DECT_MU_Append_IE
*  Description      : Append an IE to the End
*  Input Values     : buffer, ietype,ielength and source ptr
*  Output Values    : 
*  Return Value     : IFX_SUCCESS/IFX_FAILURE
*  Notes            :
*********************************************************************/
EXPORT FPTR
IFX_DECT_MU_Append_IE( FPTR frame_ptr, BYTE ie_identifier, BYTE ie_length, FPTR source_ptr )
{
   FPTR  buff;
   BYTE  current_pos;

   if( frame_ptr == NULL )
      return( frame_ptr );
                                       /* Get current frame length.        */
   current_pos = ((DATA_FRAME *) frame_ptr)->length;
   buff = ((DATA_FRAME *) frame_ptr)->dat;
                                       /* Append the IE.                   */
   buff[ current_pos++ ] = ie_identifier;
   buff[ current_pos++ ] = ie_length;
   memcpy( &buff[ current_pos ], source_ptr, ie_length );
                                       /* Update of HLI_Header.            */
   ( (DATA_FRAME *) frame_ptr)->length = current_pos + ie_length;

   return( frame_ptr );
}


/******************************************************************
*  Function Name    :IFX_DECT_MU_PageCallSetup
*  Description      : Send Paging message to handser
*  Input Values     : handset number, Instance and modelID
*  Output Values    : 
*  Return Value     : IFX_SUCCESS/IFX_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_Return IFX_DECT_MU_PageCallSetup(
                         IN uchar8 ucHandset,
	                      IN uchar8 ucPPInstance,
	                      IN uchar8 ucPPModelId,
						  IN uchar8 *pcCnip,
						  IN uchar8 *pcClip)
{
   x_IFX_DECT_IPC_Msg xIpcMsg = {0};
   uint32 uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);

   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Paging  from App in Page Call Setup" );
	if(ucHandset <= 0 || ucHandset > IFX_DECT_MAX_HS){

   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Paging  Invalid Handset ID" );
			return IFX_FAILURE;
	}
	
  xIpcMsg.ucMsgId = FP_CC_SETUP_RQ;
  xIpcMsg.ucInstance = ucPPInstance;
  xIpcMsg.ucPara1 = ucHandset;
  if((ucPPModelId == 0x01) && ((vxMUInfo[ucHandset-1].uiTermCap & IFX_DECT_MU_HS_CAT2)==0)){
     xIpcMsg.ucPara2 = ALERTING_ON_PATTERN_0;
  }else{
     xIpcMsg.ucPara2 = ALERTING_ON_CONTINUOUS;
  }
  xIpcMsg.ucPara4 = EXTERNAL_CALL;
  xIpcMsg.ucPara3 =  DUMMY_FILL;

       
  /* Logic to add Cnip like paging */
  if ((vxMUInfo[ucHandset-1].uiTermCap & IFX_DECT_MU_HS_CAT2)!=0){
    if(pcCnip != NULL)
    {
      x_IFX_DECT_IE_CallingPartyName xCallingPartyNameInfo={0};
      xCallingPartyNameInfo.ucDefault1 = 0;
      xCallingPartyNameInfo.ucPI = 3;
      xCallingPartyNameInfo.ucUA = 0;
      xCallingPartyNameInfo.ucSI = 0;

      strncpy((char*)&xCallingPartyNameInfo.acCPN[0],(char*)pcCnip,strlen((char8*)pcCnip));
      xCallingPartyNameInfo.ucCPNLen = strlen((char8*)pcCnip);
	
      if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_CALLINGPARTYNAME,
						(void *)&xCallingPartyNameInfo) == IFX_FAILURE){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE Calling party name Failed.");
        return IFX_FAILURE;
      }
    }
    /*ADD Call ID 0  and call status setup ack in IE */
    {
     x_IFX_DECT_IE_CallInfo xCallInfo={0};
     xCallInfo.ucNoOfIdentifiers = 0;
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDType = IFX_DECT_TYPE_CALL_ID;
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDSubType = IFX_DECT_STYPE_CALL_ID;
     /* To avoid conflicts with existing calls 6*2calls per HS = 12 is added */
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueFirstByte = ucHandset+12;
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueExtn = 1;
     xCallInfo.ucNoOfIdentifiers ++;
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDType = IFX_DECT_TYPE_CALL_STATUS;
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDSubType = IFX_DECT_STYPE_CALL_STATUS;
     /* To avoid conflicts with existing calls 6*2calls per HS = 12 is added */
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueFirstByte = IFX_DECT_CS_SETUP;
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueExtn = 1;
     xCallInfo.ucNoOfIdentifiers ++;
 
    IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_CALLINFORMATION,(void *)&xCallInfo);
    }
  }
  else {
   if(pcClip != NULL){
     x_IFX_DECT_IE_CallingPartyNumber xCallingPartyNumberInfo={0};
     xCallingPartyNumberInfo.ucExtn3 = 0;
     xCallingPartyNumberInfo.ucNumberType =0;
     xCallingPartyNumberInfo.ucNPI = 9;
     xCallingPartyNumberInfo.ucExtn3a = 1;
     xCallingPartyNumberInfo.ucPI = 0;
     xCallingPartyNumberInfo.ucSpare = 0;
     xCallingPartyNumberInfo.ucSI = 0;
     if( (ucPPModelId == 0x01) && ((vxMUInfo[ucHandset-1].uiTermCap & IFX_DECT_MU_HS_CAT2)==0)){
        strncpy((char*)&xCallingPartyNumberInfo.acCPA[0],"=",1);
	xCallingPartyNumberInfo.ucCPALen = 1;
     }else{
        xCallingPartyNumberInfo.ucNumberType =3;
        xCallingPartyNumberInfo.ucSI = 3;
        strncpy((char*)&xCallingPartyNumberInfo.acCPA[0],(char*)pcClip,strlen((char8*)pcClip));
        xCallingPartyNumberInfo.ucCPALen = strlen((char8*)pcClip);
     }
     if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_CALLINGPARTYNUMBER,
						(void *)&xCallingPartyNumberInfo) == IFX_FAILURE){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE Calling party number Failed.");
        return IFX_FAILURE;
      }
    }
  }
	if( IFX_DECT_MODEL_ID == ucPPModelId )
	{
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Model matched constructing Prop IE and appending it" );
#ifndef NARENDRA
	 IFX_DECT_ConstructProprietaryMsg( &Prop_Element );
	 IFX_DECT_MU_Add_Prop_IE_2((FPTR) &Prop_Element, CALL_TYPE, SERVICE_CALL /* INTERNAL_CALL */ );
     IFX_DECT_MU_Append_IE( xIpcMsg.acData, ESCAPE_TO_PROPRIETARY, Prop_Element.length, Prop_Element.data );
#endif /* NARENDRA */
	}
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Posting paging to stack" );
	return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
}
#ifdef FT_CLMS
/******************************************************************
*  Function Name    :IFX_DECT_MU_PageCLMSSetup
*  Description      : Send Paging message to handser
*  Input Values     : handset number, Instance and modelID
*  Output Values    : 
*  Return Value     : IFX_SUCCESS/IFX_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_Return IFX_DECT_MU_PageCLMSSetup(
						  IN uchar8 *pcCnip,
						  IN uchar8 *pcClip)
{
	x_IFX_DECT_IPC_Msg xIpcMsg = {0};
   uint32 uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Paging  from App in Page Call Setup" );
	
	xIpcMsg.ucMsgId = FP_CLMS_UNITDATA_RQ;
	xIpcMsg.ucInstance = 0;
	xIpcMsg.ucPara1 = 1;
	xIpcMsg.ucPara2 = ALERTING_ON_CONTINUOUS;
	xIpcMsg.ucPara3 = 0xFF;
	xIpcMsg.ucPara4 = 0x11;
	    
	/* Logic to add Cnip like paging */
	if(pcCnip != NULL)
	{
      x_IFX_DECT_IE_CallingPartyName xCallingPartyNameInfo={0};
	  xCallingPartyNameInfo.ucDefault1 = 0;
      xCallingPartyNameInfo.ucPI = 3;
      xCallingPartyNameInfo.ucUA = 0;
      xCallingPartyNameInfo.ucSI = 0;

      strncpy((char*)&xCallingPartyNameInfo.acCPN[0],(char*)pcCnip,strlen((char*)pcCnip));
      xCallingPartyNameInfo.ucCPNLen = strlen((char*)pcCnip);
	
      if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_CALLINGPARTYNAME,
						(void *)&xCallingPartyNameInfo) == IFX_FAILURE){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE Failed.");
        return IFX_FAILURE;
      }
	}
	if(pcClip != NULL){
	  x_IFX_DECT_IE_CallingPartyNumber xCallingPartyNumberInfo={0};
      xCallingPartyNumberInfo.ucExtn3 = 0;
      xCallingPartyNumberInfo.ucNumberType =3;
      xCallingPartyNumberInfo.ucNPI = 9;
      xCallingPartyNumberInfo.ucExtn3a = 1;
      xCallingPartyNumberInfo.ucPI = 0;
      xCallingPartyNumberInfo.ucSpare = 0;
      xCallingPartyNumberInfo.ucSI = 3;
      strncpy((char*)&xCallingPartyNumberInfo.acCPA[0],(char*)pcClip,strlen((char*)pcClip));
      xCallingPartyNumberInfo.ucCPALen = strlen((char*)pcClip);
	
      if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_CALLINGPARTYNUMBER,
						(void *)&xCallingPartyNumberInfo) == IFX_FAILURE){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE Failed.");
        return IFX_FAILURE;
      }

	}
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Posting paging to stack" );
	return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
}
#endif

void IFX_DECT_MU_Continous_paging(IN uint32 uiTimerId,
                                  IN void* pvPrivateData)
{

    uchar8 ucIndex;
	x_IFX_DECT_IPC_Msg xIpcMsg = {0};
	uint32 uiSignal =0;
	uint16 unTimeOut =0;
    for ( ucIndex=0;ucIndex < IFX_DECT_MAX_HS;ucIndex++){
      if((vxMUInfo[ucIndex].uiModuleOwner == IFX_DECT_MU_ID)&&
		  ((vxMUInfo[ucIndex].xSubscInfo.cmodel_id != 0x01)||((vxMUInfo[ucIndex].uiTermCap & IFX_DECT_MU_HS_CAT2)!=0))){
         uiSignal = vbRingPauseOn?ALERTING_ON_CONTINUOUS:ALERTING_OFF;
		 IFX_DECT_EncodeCCInfo(ucIndex+1,
                        vxMUInfo[ucIndex].ucInstance,
                        uiSignal,
						&xIpcMsg);
		 IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
         
      }
    }
	vbRingPauseOn = (vbRingPauseOn)?0:1;
	unTimeOut = vbRingPauseOn?
	IFX_DECT_MU_RINGPAUSE_ON_DURATION:IFX_DECT_MU_RINGPAUSE_OFF_DURATION;
    IFX_DECT_StartTimer(unTimeOut,NULL,0,
			          IFX_DECT_MU_Continous_paging,
					  &vuiRingTimeOut);


}
/************************************************************************
* Function Name  : IFX_DECT_MU_PageAllHandsets
* Description    : page all hand sets
* Input Values   : 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
PUBLIC e_IFX_Return IFX_DECT_MU_PageAllHandsets(IN uchar8 *pcCnip,IN uchar8 *pcClip)
{
  uchar8 ucIndex;
  uchar8 ucIsPagedHs=0;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Page all handsets" );
#ifndef FT_CLMS
  for ( ucIndex=0;ucIndex < IFX_DECT_MAX_HS;ucIndex++){
    /* Paging is done for only those handsets, which do not have any call
	   IFX_DECT_MU_HS_ATTACHED means no calls*/
    if((vxMUInfo[ucIndex].eState == IFX_DECT_MU_HS_REGISTERD)||(vxMUInfo[ucIndex].eState == IFX_DECT_MU_HS_ATTACHED) ){
       vxMUInfo[ucIndex].eState =IFX_DECT_MU_HS_BUSY;
       vxMUInfo[ucIndex].uiModuleOwner = IFX_DECT_MU_ID;
       vxMUInfo[ucIndex].ucInstance = IFX_DECT_GetMCEI(ucIndex+1);
       IFX_DECT_MU_PageCallSetup(ucIndex+1,
                          vxMUInfo[ucIndex].ucInstance,
                          vxMUInfo[ucIndex].xSubscInfo.cmodel_id,
						  pcCnip,pcClip);
       ucIsPagedHs++;
    }
  }
  #if 1 
  if(ucIsPagedHs){
    uint16 unTimeOut =0;
    vbRingPauseOn = (vbRingPauseOn)?0:1;
    unTimeOut = vbRingPauseOn?
    IFX_DECT_MU_RINGPAUSE_ON_DURATION:IFX_DECT_MU_RINGPAUSE_OFF_DURATION;
    IFX_DECT_StartTimer(unTimeOut,NULL,0,
			          IFX_DECT_MU_Continous_paging,
					  &vuiRingTimeOut);
  return IFX_SUCCESS;

  }else{
   return IFX_FAILURE;
  }
#else
  if(!ucIsPagedHs){
  	return IFX_FAILURE; 
  }
#endif
#else
  for ( ucIndex=0;ucIndex < IFX_DECT_MAX_HS;ucIndex++){
    /* Paging is done for only those handsets, which do not have any call
	   IFX_DECT_MU_HS_ATTACHED means no calls*/
    if((vxMUInfo[ucIndex].eState == IFX_DECT_MU_HS_REGISTERD)||(vxMUInfo[ucIndex].eState == IFX_DECT_MU_HS_ATTACHED) ){
       vxMUInfo[ucIndex].eState =IFX_DECT_MU_HS_BUSY;
       vxMUInfo[ucIndex].uiModuleOwner = IFX_DECT_MU_ID;
	   vxMUInfo[ucIndex].ucInstance = IFX_DECT_GetMCEI(ucIndex+1);
       ucIsPagedHs++;
	}
  }
  if(ucIsPagedHs){
  IFX_DECT_MU_PageCLMSSetup(pcCnip,pcClip);
  return IFX_SUCCESS;

  }else{
   return IFX_FAILURE;
  }
#endif
return IFX_FAILURE;


}
/************************************************************************
* Function Name  : IFX_DECT_MU_PageHandset
* Description    : page hand sets
* Input Values   : 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
PUBLIC e_IFX_Return IFX_DECT_MU_PageHandset(IN uchar8 ucHandset,IN uchar8 *pcCnip,IN uchar8 *pcClip)
{
  uint16 unTimeOut =0;
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Page handsets" );
  /* Reset the page response bit */
  uiPageResp &= ~(1<<ucHandset); 
	if(ucHandset <= 0 || ucHandset > IFX_DECT_MAX_HS)
		return IFX_FAILURE;
  
/* Paging is done for only those handsets, which do not have any call
	   IFX_DECT_MU_HS_ATTACHED means no calls*/
    if((vxMUInfo[ucHandset-1].eState == IFX_DECT_MU_HS_REGISTERD) ||
       (vxMUInfo[ucHandset-1].eState == IFX_DECT_MU_HS_ATTACHED) ){
       vxMUInfo[ucHandset-1].eState =IFX_DECT_MU_HS_BUSY;
       vxMUInfo[ucHandset-1].uiModuleOwner = IFX_DECT_MU_ID;
       vxMUInfo[ucHandset-1].ucInstance = IFX_DECT_GetMCEI(ucHandset);
       IFX_DECT_MU_PageCallSetup(ucHandset,
                          vxMUInfo[ucHandset-1].ucInstance,
                          vxMUInfo[ucHandset-1].xSubscInfo.cmodel_id,pcCnip,pcClip);
	   }else{
		   return IFX_FAILURE;
	   }
	   #if 1
       vbRingPauseOn = (vbRingPauseOn)?0:1;
	   unTimeOut = vbRingPauseOn?
	   IFX_DECT_MU_RINGPAUSE_ON_DURATION:IFX_DECT_MU_RINGPAUSE_OFF_DURATION;
       IFX_DECT_StartTimer(unTimeOut,NULL,0,
			          IFX_DECT_MU_Continous_paging,
					  &vuiRingTimeOut);
	   #endif

  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_MU_StopPagingHandset
* Description    : stop paging hand sets
* Input Values   : 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
PUBLIC e_IFX_Return IFX_DECT_MU_StopPagingHandset(IN uchar8 ucHandset)
{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  uchar8 ucIndex=0,ucFlag=0;
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Stop Paging  handsets" );
 if(ucHandset <= 0 || ucHandset > IFX_DECT_MAX_HS)
    return IFX_FAILURE;

    if(vxMUInfo[ucHandset-1].uiModuleOwner==IFX_DECT_MU_ID){
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Cancel paging, Posting to Stack" );
       vxMUInfo[ucHandset-1].eState =IFX_DECT_MU_HS_ATTACHED;
       vxMUInfo[ucHandset-1].uiModuleOwner = 0;
       xIpcMsg.ucMsgId = FP_CC_RELEASE_RQ;
       xIpcMsg.ucInstance = vxMUInfo[ucHandset-1].ucInstance;
       xIpcMsg.ucPara1 = ucHandset;
       xIpcMsg.ucPara2 = PARTIAL_RELEASE;
       IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
       IFX_DECT_FreeMCEI(ucHandset,vxMUInfo[ucHandset-1].ucInstance);
    }
   for ( ucIndex=0;ucIndex < IFX_DECT_MAX_HS;ucIndex++){
      if(vxMUInfo[ucIndex].uiModuleOwner == IFX_DECT_MU_ID){
		  ucFlag++;
	  }
   }
   if(ucFlag == 0){
	IFX_DECT_StopTimer(vuiRingTimeOut);
   }
    return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_MU_PageCancel
* Description    : Stop paging handsets
* Input Values   : IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_MU_PageCancel()
{
  uchar8 ucIndex;
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Cancel Paging" );
  /* Reset the alert recv state */
  uiPageResp = 0;
#ifndef FT_CLMS
  for ( ucIndex=0;ucIndex < IFX_DECT_MAX_HS;ucIndex++){
    if(vxMUInfo[ucIndex].uiModuleOwner==IFX_DECT_MU_ID){
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Cancel Posting to Stack" );
       vxMUInfo[ucIndex].eState =IFX_DECT_MU_HS_ATTACHED;
       vxMUInfo[ucIndex].uiModuleOwner = 0;
       xIpcMsg.ucMsgId = FP_CC_RELEASE_RQ;
       xIpcMsg.ucInstance = vxMUInfo[ucIndex].ucInstance;
       xIpcMsg.ucPara1 = ucIndex+1;
       xIpcMsg.ucPara2 = PARTIAL_RELEASE;
       IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
       IFX_DECT_FreeMCEI(ucIndex+1,vxMUInfo[ucIndex].ucInstance);
    }
  }
  IFX_DECT_StopTimer(vuiRingTimeOut);
#else
  for ( ucIndex=0;ucIndex < IFX_DECT_MAX_HS;ucIndex++){
    if(vxMUInfo[ucIndex].uiModuleOwner==IFX_DECT_MU_ID){
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received Cancel Posting to Stack" );
       vxMUInfo[ucIndex].eState =IFX_DECT_MU_HS_ATTACHED;
       vxMUInfo[ucIndex].uiModuleOwner = 0;
       IFX_DECT_FreeMCEI(ucIndex+1,vxMUInfo[ucIndex].ucInstance);
    }
  }
  xIpcMsg.ucMsgId = FP_CLMS_UNITDATA_RQ;
  xIpcMsg.ucInstance = 0;
  xIpcMsg.ucPara1 = 1;
  xIpcMsg.ucPara2 = 0x0A; // CALL_RELEASED_BY_FP
  xIpcMsg.ucPara3 = 0;
  xIpcMsg.ucPara4 = 0xFF;
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
#endif
  
  return IFX_FAILURE;
}
#ifdef __PIN_CODE__
/******************************************************************
*  Function Name    :IFX_DECT_MU_ChangeBasePin
*  Description      : Change Base Pin Code
*  Input Values     : pszPin
*  Output Values    :
*  Return Value     : IFX_SUCCESS/IFX_FAILURE 
*  Notes            :
*********************************************************************/
e_IFX_Return IFX_DECT_MU_ChangeBasePin(char8* pszPin)
{
	
	x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  uchar8 ucLen=strlen(pszPin);
	xIpcMsg.ucMsgId = FP_PIN_CH_RQ;
#ifdef SBB /*Not required now because we may have PIN more han 4 bytes*/
	xIpcMsg.ucPara1 = pszPin[0];
	xIpcMsg.ucPara2 = pszPin[1];
	xIpcMsg.ucPara3 = pszPin[2];
	xIpcMsg.ucPara4 = pszPin[3];
#endif

	if(ucLen > 8)
	{
		xIpcMsg.ucPara2 = 8;
		memcpy(xIpcMsg.acData,pszPin,8);
		xIpcMsg.acData[8]='\0';
	}
	else
	{
		xIpcMsg.ucPara2 = ucLen;
		strcpy((char *)xIpcMsg.acData,pszPin);
	}

	return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
}
#endif
/************************************************************************
* Function Name  : IFX_DECT_GetMCEI
* Description    : Gets Free Instance number
* Input Values   : handset ID
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
int8 IFX_DECT_GetMCEI(uchar8 ucHandset)
{
  uchar8 ucIndex;
  if(((ucHandset-1) <0 )|| ((ucHandset-1) >= IFX_DECT_MAX_HS)){
    return IFX_FAILURE;
  }
  for(ucIndex =0; ucIndex < IFX_DECT_MAX_HS; ucIndex++){
    if(!vacMCEI[ucIndex]){
      vacMCEI[ucIndex] =1;
      vxMUInfo[ucHandset-1].ucInstance = ucIndex;
      return ucIndex;
    }
  }
  return IFX_FAILURE;
}
/************************************************************************
* Function Name  : IFX_DECT_BlockMCEI
* Description    : Blocks Instance number
* Input Values   : Instance Number
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
int8 IFX_DECT_BlockMCEI(uchar8 ucHandset,uchar8 ucInstance)
{
  if(ucInstance >= IFX_DECT_MAX_HS){
    return IFX_FAILURE;
  }
   if(ucHandset <= 0 || ucHandset > IFX_DECT_MAX_HS)
    return IFX_FAILURE;
  
	if(!vacMCEI[ucInstance]){
      vacMCEI[ucInstance] =1;
      vxMUInfo[ucHandset-1].ucInstance = ucInstance;
      return IFX_SUCCESS;
    }
  return IFX_FAILURE;
}
/************************************************************************
* Function Name  : IFX_DECT_FreeMCEI
* Description    : Frees allocated instance number
* Input Values   : Instance number
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_FreeMCEI(uchar8 ucHandset,uchar8 ucInstance)
{
  if(ucInstance >= IFX_DECT_MAX_HS){
    return IFX_FAILURE;
  }

 if(ucHandset <= 0 || ucHandset > IFX_DECT_MAX_HS)
    return IFX_FAILURE;

    if(vacMCEI[ucInstance]){
      vacMCEI[ucInstance] =0;
      vxMUInfo[ucHandset-1].ucInstance = ucInstance;
      return IFX_SUCCESS;
    }
    return IFX_FAILURE;
}
/************************************************************************
* Function Name  : IFX_DECT_MU_GetCallID
* Description    : Get Call Identifier
* Input Values   : 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_MU_GetCallID(uchar8 *pucCallId)
{
   uchar8 ucIndex; 
  for(ucIndex =0; ucIndex < IFX_DECT_MAX_FT_CALLS; ucIndex++){
    if(!vacCallId[ucIndex]){
      vacCallId[ucIndex] =1;
      *pucCallId = ucIndex;
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE; 
}
/************************************************************************
* Function Name  : IFX_DECT_MU_FreeCallID
* Description    : Free call identifier
* Input Values   : call identifier
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_MU_FreeCallID(IN uchar8 ucCallId)
{
    if(vacCallId[ucCallId]){
      vacCallId[ucCallId] =0;
      return IFX_SUCCESS;
    }
    return IFX_FAILURE;

}
/************************************************************************
* Function Name  : IFX_DECT_MU_IsHandSetBusy
* Description    : return success if handset is capable of taking one extra call
* Input Values   : handset id
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_MU_IsHandSetBusy(IN uchar8 ucHandset)
{
  if(((ucHandset-1 )<0 )|| ((ucHandset-1) >= IFX_DECT_MAX_HS)){
    return IFX_FAILURE;
  }
  return vxMUInfo[ucHandset-1].eState == IFX_DECT_MU_HS_BUSY? IFX_SUCCESS:IFX_FAILURE; 
}
/************************************************************************
* Function Name  : IFX_DECT_MU_IsCallExisting
* Description    : does any call exists
* Input Values   : handset id and 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_MU_IsCallExisting(IN uchar8 ucHandset, IN uchar8 *pcInc)
{ 
  if(((ucHandset-1) <0 )|| ((ucHandset-1) >= IFX_DECT_MAX_HS)){
    return IFX_FAILURE;
  }
  *pcInc =  vxMUInfo[ucHandset-1].ucInstance;
  return vxMUInfo[ucHandset-1].eState >= IFX_DECT_MU_HS_IN_CALL ? IFX_SUCCESS:IFX_FAILURE;
}
/************************************************************************
* Function Name  : IFX_DECT_MU_SetModuleOwner
* Description    : Sets the handset state and ownership of the calls to busy
* Input Values   : ucHandset and uiModuleOwner
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_MU_SetModuleOwner(IN uchar8 ucHandset,
                                        IN uchar8 ucOperation,
                                        IN uint32 uiModuleOwner )
{
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
             "Module ID is",uiModuleOwner);
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
             "handset is",ucHandset);

  if(((ucHandset-1) <0 )|| ((ucHandset-1) >= IFX_DECT_MAX_HS)){
    return IFX_FAILURE;
  }
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
             "handset is in state",vxMUInfo[ucHandset-1].eState);

  if(ucOperation == IFX_DECT_MU_ADD_OWNER){
    
    switch(uiModuleOwner){
	  case IFX_DECT_CSU_ID:
		  if(vxMUInfo[ucHandset-1].ucCSURefCount+1 == IFX_DECT_MAX_CALLS_PER_HS){
		    return IFX_FAILURE;
		  }
	      if((vxMUInfo[ucHandset-1].uiModuleOwner & IFX_DECT_CSU_ID)&&
		     (vxMUInfo[ucHandset-1].eState != IFX_DECT_MU_HS_BUSY)){
		     vxMUInfo[ucHandset-1].ucCSURefCount++;
             IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                "Ref Count is",vxMUInfo[ucHandset-1].ucCSURefCount);
		     if(vxMUInfo[ucHandset-1].ucCSURefCount+1 == IFX_DECT_MAX_CALLS_PER_HS){
                vxMUInfo[ucHandset-1].eState = IFX_DECT_MU_HS_BUSY;
		     }
             vxMUInfo[ucHandset-1].eState = IFX_DECT_MU_HS_IN_CALL; //SINGLE bit set
		     return IFX_SUCCESS;
	      }
	      vxMUInfo[ucHandset-1].uiModuleOwner |= uiModuleOwner;
          vxMUInfo[ucHandset-1].eState = IFX_DECT_MU_HS_IN_CALL; //SINGLE bit set
		  break;
	case  IFX_DECT_DPSU_ID:
	     if(vxMUInfo[ucHandset-1].uiModuleOwner ==0){
            vxMUInfo[ucHandset-1].eState = IFX_DECT_MU_HS_BUSY;
	        vxMUInfo[ucHandset-1].uiModuleOwner |= uiModuleOwner;
	        return IFX_SUCCESS;
	     }else{
	       return IFX_FAILURE;
	     }
	default:
	     vxMUInfo[ucHandset-1].uiModuleOwner |= uiModuleOwner;
	}
   }else{
    switch(uiModuleOwner){
	  case IFX_DECT_CSU_ID:
    /* This case is where handset is busy due to max calls reached, there by reduce
	   reference count and move to in call state*/
		  if(vxMUInfo[ucHandset-1].ucCSURefCount+1 == IFX_DECT_MAX_CALLS_PER_HS){
		    vxMUInfo[ucHandset-1].ucCSURefCount--;
            vxMUInfo[ucHandset-1].eState = IFX_DECT_MU_HS_IN_CALL;
		    return IFX_SUCCESS;
		  }
		  /* This case is where handset is in call and handset has more than one call due to max
	       * there by reduce reference count*/
         if( (uiModuleOwner == IFX_DECT_CSU_ID)&&
	         (vxMUInfo[ucHandset-1].ucCSURefCount > 0)){
		     vxMUInfo[ucHandset-1].ucCSURefCount--;
		     return IFX_SUCCESS;
 	      }
	default:
	  vxMUInfo[ucHandset-1].uiModuleOwner &= ~uiModuleOwner;
 	  if(vxMUInfo[ucHandset-1].uiModuleOwner ==0){
        vxMUInfo[ucHandset-1].eState = IFX_DECT_MU_HS_ATTACHED; //no bit set
      }/*else{
       vxMUInfo[ucHandset-1].eState = IFX_DECT_MU_HS_IN_CALL; //Single bit set
      }*/
	}
 }
   return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_MU_GetModuleOwner
* Description    : Gets the list of module owners
* Input Values   : ucInstance
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
uint32 IFX_DECT_MU_GetModuleOwner(IN uchar8 ucHandset)
{
  if(((ucHandset-1) <0 )|| ((ucHandset-1) >= IFX_DECT_MAX_HS)){
    return IFX_FAILURE;
  }
  return vxMUInfo[ucHandset-1].uiModuleOwner;
}
/************************************************************************
* Function Name  : IFX_DECT_MU_CanCallBeReleased
* Description    : Can the call be released by this module owner
* Input Values   : handset number and module owner
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_MU_CanCallBeReleased(IN uchar8 ucHandset)
{
  if(((ucHandset-1) <0 )|| ((ucHandset-1) >= IFX_DECT_MAX_HS)){
    return IFX_FAILURE;
  }
  if(vxMUInfo[ucHandset-1].uiModuleOwner & IFX_DECT_DPSU_ID){
	  return IFX_SUCCESS;
  }
	if(vxMUInfo[ucHandset-1].uiModuleOwner & IFX_DECT_LAU_ID){
		return IFX_FAILURE;
	}
  return vxMUInfo[ucHandset-1].eState == IFX_DECT_MU_HS_IN_CALL? vxMUInfo[ucHandset-1].ucCSURefCount == 0? IFX_SUCCESS:IFX_FAILURE:IFX_FAILURE;
}

/*! \brief  This function is used to switch on/off the NEMO. 
        \param[in] bOnOff Turn On/Off NEMO. 0 to turn on NEMO, 
                           1 to turn off NEMO
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_MU_NemoConfig(IN boolean bOnOff)
{
	//uint16 i;
	//x_IFX_DECT_FTCap xFTCapabilities;
	//memset(&xFTCapabilities,0,sizeof(xFTCapabilities));
	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
           "IFX_DECT_MU_NemoConfig = ",bOnOff);
	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
           "IFX_DECT_MU_NemoConfig nemo state= ",veNemoState);
		   vuiNemoEnableFlag=bOnOff;
	if(bOnOff){
		if(vuiNemoTimer){
	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
           "Stoping Timer = ",bOnOff);
			
  		IFX_DECT_StopTimer(vuiNemoTimer);
			vuiNemoTimer = 0;
		}
		if ((veNemoState == IFX_DECT_MU_NEMO_ACTIVE) || (veNemoState == IFX_DECT_MU_NEMO_PENDING)) {
			veNemoState= IFX_DECT_MU_NEMO_STOP_PENDING;
	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
           "Stoping NEMO = ",bOnOff);
		IFX_DECT_MU_NemoStop();
            
		}
	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
           " NEMO OFF Now= ",bOnOff);
		veNemoState=IFX_DECT_MU_NEMO_OFF;
	}else{
//		if(veNemoState == IFX_DECT_MU_NEMO_OFF)
		{
	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
           "Star NEMO IDLE function with 0 null = ",bOnOff);
		veNemoState =IFX_DECT_MU_NEMO_IDLE;
			IFX_DECT_MU_NemoIdleTimerFunc (0,NULL);
		}
	}
	/*IFX_DECT_SetFTCap(&xFTCapabilities);
	i = system("grep 'App' /proc/driver/dect/gw-stats 2>/dev/null");
	if(i==0){
		sleep(3);
		IFX_DECT_DIAG_ModemRestart();
	}
	*/
	return IFX_SUCCESS;
}
