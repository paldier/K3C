/**************************************************************************
**   FILE NAME     : IFX_DECT_USU.c
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/

#include "IFX_DECT_Platform.h"
#include "IFX_DECT_StackIf.h"
#include "dect_drv_if.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_MsgRouter.h"
#include "IFX_DECT_MsgEncoder.h"
#include "IFX_DECT_IEParser.h"

#define printf(...)
#define vxUSUCallBks vxGlobalInfo.xUSU.vxUSUCallBks
#define vxMUInfo1 vxGlobalInfo.xMU.vxMUInfo
#define vxUSURFState vxGlobalInfo.xUSU.ucRFState 

#ifdef FW_DOWNLOAD
#define vucLoaderMode vxGlobalInfo.xUSU.vucLoaderMode
#define vucBank vxGlobalInfo.xUSU.vucBank
#define vunLoaderAddr vxGlobalInfo.xUSU.vunLoaderAddr
#define vaucBMCFileName vxGlobalInfo.xUSU.aucBMCFileName
#define vaucUserAppFileName vxGlobalInfo.xUSU.aucUserAppFileName
#define iFileFd vxGlobalInfo.xUSU.iBmcFileFd
#define iFileFd1 vxGlobalInfo.xUSU.iUserSwFileFd
#endif
#define FW_TIMER 1
#ifdef FW_TIMER
#define vuiFwTimer vxGlobalInfo.xUSU.vuiFwTimer
#define vxFramebackup vxGlobalInfo.xUSU.vxFramebackup
#define vucRetryCount vxGlobalInfo.xUSU.vucRetryCount
#endif

extern void IFX_DECT_Stack_PrintVersion();
uchar8 vucDownloadBmcOnBootInd;
//#define TEST_RI

/*! \brief The API IFX_DECT_USU_HandleRF enables or disables RF.
    \param[in] ucRFState indicates whether to switch on/off RF.
	\return IFX_SUCCESS or IFX_FAILURE
*/
	   
e_IFX_Return IFX_DECT_USU_HandleRF(IN uchar8 ucRFState){

   uchar8 ucHandsetId =0;
   x_IFX_DECT_IPC_Msg xIpcMsg={0};
   
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    " <API HandleRF>Entry.");
   
   for(ucHandsetId=0;ucHandsetId<IFX_DECT_MAX_HS;ucHandsetId++){

	  if(vxMUInfo1[ucHandsetId].eState > IFX_DECT_MU_HS_ATTACHED){

	    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
	             " <API HandleRF>Handset is in call.",ucHandsetId+1);
		return IFX_FAILURE;
	  }
   }
   switch(ucRFState){

	 case IFX_DECT_USU_RF_OFF:
		   
		   xIpcMsg.ucPara1 = MAC_NOEMOM_START;
		   xIpcMsg.ucPara2 = vxGlobalInfo.xStackCfg.uiNoOfFramesNeMo;
		   xIpcMsg.ucMsgId = FP_ME_MAC_NOEMO_RQ;
           return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
		   break;	
		   
	 case IFX_DECT_USU_RF_ON:

		   xIpcMsg.ucPara1 = MAC_NOEMOM_STOP;
		   xIpcMsg.ucPara2 = vxGlobalInfo.xStackCfg.uiNoOfFramesNeMo;
		   xIpcMsg.ucMsgId = FP_ME_MAC_NOEMO_RQ;
		   return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,
											  &xIpcMsg);
           break;
		   
	 default:

		 return IFX_FAILURE;
   }

   return IFX_SUCCESS;
}
																											  
/*! \brief The API IFX_DECT_USU_RegisterCallBks registers callbacks for
           Utility Service Unit.
*/

e_IFX_Return IFX_DECT_USU_RegisterCallBks(IN x_IFX_DECT_USU_CallBks *pxUSUCallBks){

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "<RegisterCallBks>Entry." );

   memcpy(&vxUSUCallBks,pxUSUCallBks,sizeof(x_IFX_DECT_USU_CallBks));
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "<RegisterCallBks>Successful.CallBacks Registered." );

   return IFX_SUCCESS;
}


/*! \brief The Api IFX_DECT_USU_DateTimeSync synchronizes date and time between
           FT and PT.It is FT initiated.This is usually invoked during Handset 
           attachment with the base or during a call.
    \param[in] ucHandsetId Handset Identifier.
    \param[in] pxTimeDate pointer to Date-Time structure.
    \return IFX_SUCCESS or IFX_FAILURE. 
*/

e_IFX_Return IFX_DECT_USU_DateTimeSync(IN uchar8 ucHandsetId,
                                       IN x_IFX_DECT_USU_TimeDate *pxTimeDate){

 
   char8 ucInstance = 0;
   uchar8 ucIsLink = IFX_DECT_USU_NO_LINK_PRESENT;
   x_IFX_DECT_IPC_Msg xIpcReply = {0};

   if((0 == ucHandsetId)||(ucHandsetId > IFX_DECT_MAX_HS)||(NULL == pxTimeDate)){

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         " <API DateTimeSync>Api Failed.ucHandsetId invalid or pxTimeDate is NULL.");
     return IFX_FAILURE;
   }

   if(!IFX_DECT_MU_IsCAT2(ucHandsetId)){
     
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         " <API DateTimeSync>Handset is not Catiq 2.0 compatible.");
     return IFX_FAILURE;
   }

   if(IFX_DECT_MU_IsCallExisting(ucHandsetId,((uchar8 *)&ucInstance)) == IFX_SUCCESS){

      ucIsLink = IFX_DECT_USU_LINK_PRESENT;
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		       " <API DateTimeSync>Call already existing.");
   }else{

	    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			  " <API DateTimeSync>Call doesn't exist,no link present.");
         
	    if(IFX_FAILURE == (ucInstance = IFX_DECT_GetMCEI(ucHandsetId))){
       
		    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				         " <API DateTimeSync>Api GetMCEI failed.");
		    return IFX_FAILURE;
	    }
    }												
	
   if(IFX_FAILURE == 
     IFX_DECT_USU_EncodeTimeDate((uchar8*)pxTimeDate,
                                  sizeof(x_IFX_DECT_USU_TimeDate),
                                  xIpcReply.acData)){

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
             " <API DateTimeSync>API EncodeTimeDate Failed.");
     return IFX_FAILURE;
   }
    
   IFX_DECT_EncodeFacility(ucHandsetId,ucInstance,&xIpcReply);

   IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
   
   IFX_DECT_USU_ReleaseInstance(ucIsLink,ucInstance,ucHandsetId);
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	      		 " <API DateTimeSync>Successful.");
	 return IFX_SUCCESS;

}

/*! \brief IFX_DECT_USU_VoiceMesgWaitingNotify is used to notify the PT of any voice
           messages.It is invoked by FT Application when it receives any information that
		   voice message has been recorded.
	  \param[in] ucHandsetId Handset Identifier.
	  \param[in] cLineId Line Identifier.
    \param[in] ucSubType Line SubType.
	  \param[in] ucNoOfUnreadMails Number of unread voice messages.
	  \return IFX_SUCCESS of IFX_FAILURE.
*/
										  
e_IFX_Return IFX_DECT_USU_VoiceMesgWaitingNotify(IN uchar8 ucHandsetId,
                                                 IN char8 cLineId,
                                                 IN uchar8 ucNoOfUnreadMails){

   int32 i = 0;
   x_IFX_DECT_USU_EventList xEventList = {0};

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API VoiceMesgWaitingNotify>Entry.");
   
   if((0 == ucHandsetId)||(ucHandsetId > IFX_DECT_MAX_HS)){

	    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		      	   " <API VoiceMesgWaitingNotify>Api Failed.ucHandsetId invalid.");
	    return IFX_FAILURE;
   }
									
   if(!IFX_DECT_MU_IsCAT2(ucHandsetId)){

     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         " <API VoiceMesgWaitingNotify>Handset is not Catiq 2.0 compatible.");
     return IFX_FAILURE;
   }

   xEventList.ucNoOfEvents = 1;
	  
   xEventList.axEvent[i].ucEventType = IFX_DECT_EVT_TYPE_MW;
	  
   xEventList.axEvent[i].ucEventSubtype = IFX_DECT_MW_EVT_STYPE_VM;
   xEventList.axEvent[i].unEventMultiplicity = ucNoOfUnreadMails;
   
   if(cLineId !=0){
   xEventList.acLineId[0] = cLineId;
   xEventList.ucIsAllLines = 2;
   xEventList.ucNoOfLineId = 1;
   }

   if(IFX_DECT_USU_GenericEventNotify(ucHandsetId,&xEventList) == IFX_FAILURE){
   
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	             " <API VoiceMesgWaitingNotify>GenericEventNotify failed.Failure.");
				 
     return IFX_FAILURE;
   }
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
      			" <API VoiceMesgWaitingNotify>Successful.");
   
   return IFX_SUCCESS;
}

/*! \brief The Api IFX_DECT_USU_GenericEventNotify is used to send notification
           to PT of various events such as Voice Message Waiting,Missed Call,
		   List Change.It is invoked by FT Application when some event occurs and 
		   PT needs to be notified.A Facility based notification is composed and sent
		   to PT.
    \param[in] ucHandsetId Handset Identifier.
	\param[in] pxEventList pointer to structure containing event
               and line information.
    \return IFX_SUCCESS or IFX_FAILURE.			   
*/

e_IFX_Return IFX_DECT_USU_GenericEventNotify(IN uchar8 ucHandsetId,
											 IN x_IFX_DECT_USU_EventList *pxEventList){

   char8 ucInstance = 0;
   uint32 uiIEHdl = 0;
   uchar8 ucIsLink = IFX_DECT_USU_NO_LINK_PRESENT;
   x_IFX_DECT_IPC_Msg xIpcReply = {0};
	  
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            " <API GenericEventNotify>Entry.");

   if((0 == ucHandsetId)||(ucHandsetId > IFX_DECT_MAX_HS)){

      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		       " <API GenericEventNotify>Api Failed.ucHandsetId invalid.");
	  return IFX_FAILURE;
   }

   if(!IFX_DECT_MU_IsCAT2(ucHandsetId)){

     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         " <API GenericEventNotify>Handset is not Catiq 2.0 compatible.");
     return IFX_FAILURE;
   }  
 								 
   if(IFX_DECT_MU_IsCallExisting(ucHandsetId,((uchar8 *)&ucInstance)) == IFX_SUCCESS){

      ucIsLink = IFX_DECT_USU_LINK_PRESENT; 
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		       " <API GenericEventNotify>Call already existing.");
   }else{

	   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		      	  " <API GenericEventNotify>Call doesn't exist,no link present.");

     if((ucInstance = IFX_DECT_GetMCEI(ucHandsetId)) == IFX_FAILURE){

	     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			        	 " <API GenericEventNotify>Api GetMCEI failed.");
		   return IFX_FAILURE;
	   }

    }

   if((uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcReply.acData)) != IFX_FAILURE){
	   if(IFX_DECT_USU_EncodeEventNotify(pxEventList,uiIEHdl) == IFX_FAILURE){

       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 " <API GenericEventNotify>Api EncodeEventNotify failed.");
       return IFX_FAILURE;
     }
	
     if((pxEventList->ucNoOfLineId != 0)||(pxEventList->ucIsAllLines)){

    	 if(IFX_DECT_USU_EncodeCallInformation(pxEventList,uiIEHdl) == IFX_FAILURE){
       
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 " <API GenericEventNotify>Api EncodeCallInformation failed.");
         return IFX_FAILURE;
       }
	   } 

   }else{
  
     return IFX_FAILURE;
    }
     
   IFX_DECT_EncodeFacility(ucHandsetId,ucInstance,&xIpcReply);

	 IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
	
   IFX_DECT_USU_ReleaseInstance(ucIsLink,ucInstance,ucHandsetId);

	 IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	                 " <API GenericEventNotify>Api Successful.");
	 return IFX_SUCCESS;	  
}


/*! \brief API IFX_DECT_EncodeEventNotify encodes Event Notification Information 
           Element and adds it to the IPC Message to be sent to PT.
    \param[in] pxEventList pointer to structure containing Event Information for 
	             different events.
	  \param[out] pcData pointer to acData in IPC Message.
	  \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_USU_EncodeEventNotify(IN x_IFX_DECT_USU_EventList *pxEventList,
                                            IN uint32 uiIEHdl){

   int32 i = 0;
   x_IFX_DECT_IE_EventNotify xEventNotify = {0};

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            " <API EncodeEventNotify>Entry.");
					 
   if((NULL == pxEventList)||(0 == uiIEHdl)){
    
	 IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          " <API EncodeEventNotify>Api Failed.pxEventList or pcData is NULL.");
					   
	 return IFX_FAILURE;
   }	 
   
   xEventNotify.ucNoOfEvents = pxEventList->ucNoOfEvents;
	 printf("\n Number of Events:%d\n",pxEventList->ucNoOfEvents);
   for(i = 0; i < pxEventList->ucNoOfEvents; i++){
     
    xEventNotify.axEvent[i].ucEventType = pxEventList->axEvent[i].ucEventType;
	
	  if(pxEventList->axEvent[i].ucEventSubtype == IFX_DECT_MW_EVT_STYPE_UK){
	
	    xEventNotify.axEvent[i].ucIsEventSubType = 1;
	  
	  }else{

      xEventNotify.axEvent[i].ucIsEventSubType = 0;
	    xEventNotify.axEvent[i].ucEventSubType = pxEventList->axEvent[i].ucEventSubtype;
	   }
    xEventNotify.axEvent[i].ucDefault1 = 1;
	  if((pxEventList->axEvent[i].unEventMultiplicity & 0X7F00) == 0){
	
	    printf("\n Event Multiciplity one byte:%d\n",pxEventList->axEvent[i].unEventMultiplicity & 0X7F);
	    xEventNotify.axEvent[i].ucEventMultiExtn = 1;
	    xEventNotify.axEvent[i].ucEventMultiSecondByte = 0;
	    xEventNotify.axEvent[i].ucEventMultiFirstByte = 
                              (pxEventList->axEvent[i].unEventMultiplicity & 0X7F);
	  }else{

      xEventNotify.axEvent[i].ucEventMultiExtn = 0;
      xEventNotify.axEvent[i].ucEventMultiSecondByte = 
                              (pxEventList->axEvent[i].unEventMultiplicity & 0X00FF);
      xEventNotify.axEvent[i].ucEventMultiFirstByte = 
                              ((pxEventList->axEvent[i].unEventMultiplicity >> 8) & 0X7F);
	   }
   }	
   if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_EVENTNOTIFY,(void *)&xEventNotify) != IFX_FAILURE){

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	            " <API EncodeEventNotify>Api Successful.");
     return IFX_SUCCESS;
	 }else{

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
              " <API EncodeEventNotify>Api IEAdd failed.");
     return IFX_FAILURE;
    }
}

/*! \brief This Api sends notification to the PT whether Ciphering is enabled 
           or not.It is invoked by FT Application.
    \note This infomation is sent only if there is an ongoing call else it is 
	      not applicable and is a failure condition.
    \param[in] ucHandsetId Handset Identifier.
  	\param[in] bOnOff indicating Cipher On=1,Off=0.
    \return IFX_SUCCESS of IFX_FAILURE.		   
*/

e_IFX_Return IFX_DECT_USU_Cipher(IN uchar8 ucHandsetId,IN boolean bOnOff){

   uchar8 ucInstance = 0;
   x_IFX_DECT_IPC_Msg xIpcReply = {0};
   
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            " <API Cipher>Entry.");
				  
   if((0 == ucHandsetId)||(ucHandsetId > IFX_DECT_MAX_HS)){

     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		       " <API Cipher>Api Failed.ucHandsetId invalid or No unread mails.");
     return IFX_FAILURE;
   }
								 
   if(!IFX_DECT_MU_IsCAT2(ucHandsetId)){

     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
         " <API Cipher>Handset is not Catiq 2.0 compatible.");
     return IFX_FAILURE;
   }
#if 0
   if(IFX_DECT_MU_GetCipherStatus(ucHandsetId) == bOnOff){
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Link is already ciphered/non ciphered");
     if(vxUSUCallBks.pfn_USU_CipherStatus != NULL){
            vxUSUCallBks.pfn_USU_CipherStatus(bOnOff);
  		      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			            "<USU_ProcessStkMesg>Callback cipher ON/OFF.");
		 }

     return IFX_SUCCESS;
   }
#endif

   if(IFX_DECT_MU_IsCallExisting(ucHandsetId,((uchar8 *)&ucInstance)) == IFX_SUCCESS){

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		       " <API Cipher>Call already existing.");
     if(bOnOff == IFX_TRUE){	
	   IFX_DECT_EncodeEnableCipher(ucHandsetId,ucInstance,bOnOff,&xIpcReply);
     }else{
         IFX_DECT_EncodeAuthPTReq(ucHandsetId,ucInstance,
                                  &xIpcReply);  
     }
	   IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
   }else{
						   
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          " <API Cipher>Call doesn't exist.Failure.");
	   return IFX_FAILURE;
	  } 
					
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                 " <API Cipher>Api Successful.");
   return IFX_SUCCESS;
}

/*! \brief The Api IFX_DECT_EncodeCallInformation encodes Call Information
           IE and appends it to the IPC Message to be sent to PT.It contains 
		   Line/Call Information.
    \param[in] pxIdList pointer to structure containing Identifier List.		   
    \param[out] pcData pointer to acData in IPC Message.
	  \return IFX_SUCCESS or IFX_FAILURE; 
*/

e_IFX_Return IFX_DECT_USU_EncodeCallInformation(IN x_IFX_DECT_USU_EventList *pxIdList,
                                                IN uint32 uiIEHdl){

   int32 i = 0;
   x_IFX_DECT_IE_CallInfo xCallInfo = {0};

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		    " <API EncodeCallInformation>Entry.");

   if((NULL == pxIdList)||(0 == uiIEHdl)){

	   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	           " <API EncodeCallInformation>Api Failed.pxIdList or pcData is NULL.");

	   return IFX_FAILURE;
   }
   if(pxIdList->ucIsAllLines == 0){	
											   
     xCallInfo.ucNoOfIdentifiers = pxIdList->ucNoOfLineId;

     for(i = 0; i < pxIdList->ucNoOfLineId; i++){

	    xCallInfo.axID[i].ucIDType = IFX_DECT_TYPE_LINE_ID;
	    xCallInfo.axID[i].ucIDSubType = IFX_DECT_STYPE_RELATING_TO;
	    xCallInfo.axID[i].axIDValue[0].ucIDValueExtn = 1;
	    xCallInfo.axID[i].axIDValue[0].ucIDValueFirstByte = pxIdList->acLineId[i] ;
     }
   }
		else if(pxIdList->ucIsAllLines == 2){
     xCallInfo.ucNoOfIdentifiers = pxIdList->ucNoOfLineId;

     for(i = 0; i < pxIdList->ucNoOfLineId; i++){

      xCallInfo.axID[i].ucIDType = IFX_DECT_TYPE_LINE_ID;
      xCallInfo.axID[i].ucIDSubType = IFX_DECT_STYPE_LINE_ID_EXT;
      xCallInfo.axID[i].axIDValue[0].ucIDValueExtn = 1;
      xCallInfo.axID[i].axIDValue[0].ucIDValueFirstByte = pxIdList->acLineId[i] ;
    }
	}
	  else{
        xCallInfo.ucNoOfIdentifiers = pxIdList->ucNoOfLineId;
	    xCallInfo.axID[0].ucIDType = IFX_DECT_TYPE_LINE_ID;
	    xCallInfo.axID[0].ucIDSubType = IFX_DECT_STYPE_ALL;
	    xCallInfo.axID[0].axIDValue[0].ucIDValueExtn = 1;
	    xCallInfo.axID[0].axIDValue[0].ucIDValueFirstByte =  0;
   }   
   if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_CALLINFORMATION,(void *)&xCallInfo) != IFX_FAILURE){

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	            " <API EncodeCallInformation>Api Successful.");

	   return IFX_SUCCESS;			   
   }else{
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		      " <API EncodeCallInformation>Api Failed.IEAdd failed.");
	   return IFX_FAILURE;
    }
}

/*! \brief The Api IFX_DECT_USU_EncodeTimeDate helps encode TimeDate Information 
 *         Element and add it to the IPC message to be sent to PT.
    \param[in] pcTimeDate pointer to the structure containing TimeDate Information.
    \param[in] ucTimeDateLen size of the TimeDate structure.
    \param[out] pointer to acData in IPC Message.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_USU_EncodeTimeDate(IN uchar8 *pcTimeDate,
                                         IN uchar8 ucTimeDateLen,
                                         OUT uchar8 *pcData){

   uint32 uiIEHdl = 0;
   x_IFX_DECT_IE_TimeDate xTimeDate = {0};
   //uchar8 ucSK = 0X7B; 
   //uchar8 ucSD = 0X7E; 

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            " <API EncodeTimeDate>Entry.");
	
   if(NULL == pcData){

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          " <API EncodeTimeDate>pcData is NULL.");
				 
     return IFX_FAILURE;
   }
   xTimeDate.ucCoding = 3;
   xTimeDate.ucInterpretation = 0;
   xTimeDate.ucTimeDateLen = ucTimeDateLen;
   memcpy(xTimeDate.acTimeDate,pcTimeDate,ucTimeDateLen);
   
   if((uiIEHdl = IFX_DECT_IE_NewIECreate(pcData)) != IFX_FAILURE){
	   
     if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_TIMEDATE,(void *)&xTimeDate) != IFX_FAILURE){

	   /* for(i = 0;i < 50 ;i++){

         printf("\n acData[%d] = 0X%x\n",i,pcData[i]);
		}*/
#ifdef TEST_RI
	  
     if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_TIMEDATE,(void *)&xTimeDate) != IFX_FAILURE){
		
		 for(i = 0;i < 50 ;i++){

           //printf("\n acData[%d] = 0X%x\n",i,pcData[i]);
		 }
		 
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_SINGLEKEYPAD,(void *)&ucSK) != IFX_FAILURE){	 
	  
		 for(i = 0;i < 50 ;i++){

           //printf("\n acData[%d] = 0X%x\n",i,pcData[i]);
		 }
		 
     if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_TIMEDATE,(void *)&xTimeDate) != IFX_FAILURE){
		
		 for(i = 0;i < 50 ;i++){

           //printf("\n acData[%d] = 0X%x\n",i,pcData[i]);
		 }
		 
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_SINGLEKEYPAD,(void *)&ucSK) != IFX_FAILURE){	 
	  
		 for(i = 0;i < 50 ;i++){

           //printf("\n acData[%d] = 0X%x\n",i,pcData[i]);
		 }
		 
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_SINGLEDISPLAY,(void *)&ucSD) != IFX_FAILURE){	 
	  
		 for(i = 0;i < 50 ;i++){

           //printf("\n acData[%d] = 0X%x\n",i,pcData[i]);
		 }
	  	 
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_SINGLEKEYPAD,(void *)&ucSK) != IFX_FAILURE){	 
	  
		 for(i = 0;i < 50 ;i++){

           //printf("\n acData[%d] = 0X%x\n",i,pcData[i]);
		 }
		 
	  if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_SINGLEDISPLAY,(void *)&ucSD) != IFX_FAILURE){	 
	  
		 for(i = 0;i < 50 ;i++){

           //printf("\n acData[%d] = 0X%x\n",i,pcData[i]);
		 }
	  return IFX_SUCCESS;
	 } 
	 } 
	 } 
	 } 
	 } 
	 }
	 }
#else
       return IFX_SUCCESS;
#endif		
     }	 


  
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              " <API EncodeTimeDate>Api Failed.IEAdd failed.");
     return IFX_FAILURE;
   } 
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
            " <API EncodeTimeDate>NewIECreate failed.");
					
   return IFX_FAILURE;
}

/*! \brief The Api IFX_DECT_USU_ReleaseInstance helps to free instance number procured 
           during any of event notification events.
    \param[in] ucIsLink specifies whether a link exists or not.
	  \param[in] ucInstance Incarnation Number.
	  \return IFX_SUCCESS or IFX_FAILURE.
*/
	
e_IFX_Return IFX_DECT_USU_ReleaseInstance(IN uchar8 ucIsLink,
                                          IN uchar8 ucInstance,
										  IN uchar8 ucHandsetId){

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                 " <API ReleaseInstance>Entry.");
				
    
   if(IFX_DECT_USU_LINK_PRESENT == ucIsLink){
                        
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           " <API ReleaseInstance>Link exists.");

   }else{
     
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
        " <API ReleaseInstance>No link present.");
     IFX_DECT_FreeMCEI(ucHandsetId,ucInstance);

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                 " <API ReleaseInstance>Freed Instance Number.");


   }
	 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	              " <API ReleaseInstance>Api Successful.");
				  
   return IFX_SUCCESS;				  
}

/*! \brief The Api IFX_DECT_USU_FetchTimeDateInfo obtains TimeDate Information from the
           IPC Message and returns it in the form of a structure.
	  \param[in] pxIpcMesg pointer to IPC Message.
	  \param[out] pxTimeDate pointer to structure containing TimeDate Info.
	  \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_USU_FetchTimeDateInfo(IN x_IFX_DECT_IPC_Msg *pxIpcMesg,
                                            OUT x_IFX_DECT_USU_TimeDate *pxTimeDate ){

   uint32 uiIEHdl = 0;
   e_IFX_Return eRet = IFX_SUCCESS;
   x_IFX_DECT_IE_TimeDate xTimeDate ={0};
   
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "<USU_FetchTimeDateInfo>Entry.");

   if(0 == (uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIpcMesg)) ){
	  
	   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
	           "<USU_FetchTimeDateInfo>No IE found");
	   return IFX_FAILURE;
   }
   while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_TIMEDATE){
    
     if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
	         
	     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		      	   "<USU_FetchTimeDateInfo>NextIEHandlerGet Failed.");

	     eRet = IFX_FAILURE;
	     break;
	   }
   }
   if(IFX_SUCCESS == eRet){
	    
     if(IFX_DECT_IE_TimeDateGet(uiIEHdl,&xTimeDate) == IFX_FAILURE){

       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "<USU_FetchTimeDateInfo>Api IFX_DECT_IE_TimeDateGet failed.");
       return IFX_FAILURE; 
     }
     memcpy(pxTimeDate,xTimeDate.acTimeDate,sizeof(x_IFX_DECT_USU_TimeDate));
	   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	            "<USU_FetchTimeDateInfo>Api Successful.");
   }   
   return eRet; 
}

/*! \brief The Api IFX_DECT_USU_ProcessStkMesg processes IPC Message coming
           from the stack.
	  \param[in] pxIpcMesg pointer to IPC Message.
	  \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_USU_ProcessStkMesg(IN x_IFX_DECT_IPC_Msg *pxIpcMesg){


  uchar8 ucHandsetId = 0;
  x_IFX_DECT_USU_TimeDate xTimeDate = {0};
  
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "<USU_ProcessStkMesg>Entry.");

	if(NULL != pxIpcMesg)
  		ucHandsetId = pxIpcMesg->ucPara1;
  if((0 == ucHandsetId) || (ucHandsetId > IFX_DECT_MAX_HS)){

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
            "<USU_ProcessStkMesg>Invalid handset id or IpcMesg is NULL.");
    return IFX_FAILURE;
  }
			

  switch(pxIpcMesg->ucMsgId){

  	case FP_DEBUG_INFO_IND:
          if((vxUSUCallBks.pfn_USU_XRAM != NULL )&& 
							(vxUSUCallBks.pfn_USU_XRAM(pxIpcMesg->acData) == IFX_SUCCESS)){
		  
  		      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			            "<USU_ProcessStkMesg>Callback XRAM  Successful.");
		        return IFX_SUCCESS;
		      }
		    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		             "<USU_ProcessStkMesg> callback XRAM not registered or API failed.");
		    return IFX_FAILURE;
        break;
    case FP_FACILITY_IN_CLSS:

        if(IFX_DECT_USU_FetchTimeDateInfo(pxIpcMesg,&xTimeDate) == IFX_SUCCESS){

          if((vxUSUCallBks.pfn_USU_DateTimeSync != NULL )&& 
							(vxUSUCallBks.pfn_USU_DateTimeSync(ucHandsetId,&xTimeDate) == IFX_SUCCESS)){
		  
  		      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			            "<USU_ProcessStkMesg>Callback DateTimeSync Successful.");
		        return IFX_SUCCESS;
		      }
		    }
		    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		             "<USU_ProcessStkMesg> callback not registered or API failed.");
		    return IFX_FAILURE;
        break;

    case FP_MAC_NOEMO_IN_ME:

        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		                        "<USU_ProcessStkMesg>FP_MAC_NOEMO_IN_ME message arrived.");
								
	    switch(pxIpcMesg->ucPara1){
		
		  case MAC_NOEMOM_ACTIVE:
              
			  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
			                          "<USU_ProcessStkMesg>MAC_NOEMOM_ACTIVE arrived.",MAC_NOEMOM_ACTIVE);
									  
									  
			    vxUSURFState=0;
			    for(ucHandsetId=0;ucHandsetId<IFX_DECT_MAX_HS;ucHandsetId++){

			      vxMUInfo1[ucHandsetId].eState = IFX_DECT_MU_HS_BUSY;
			    }
				IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
				                                      "<USU_ProcessStkMesg>Moved all handsets to Busy State.");
			  break;

          case MAC_NOEMOM_WAKEUP:  

		      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
			                          "<USU_ProcessStkMesg>MAC_NOEMOM_WAKEUP.",MAC_NOEMOM_WAKEUP);

              vxUSURFState=1;
		      for(ucHandsetId=0;ucHandsetId<IFX_DECT_MAX_HS;ucHandsetId++){

		         vxMUInfo1[ucHandsetId].eState = IFX_DECT_MU_HS_ATTACHED;
			  }
			  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			                                        "<USU_ProcessStkMesg>Moved all Handsets to Attached State.");
		      break;
#if 0 
      case FP_CIPHER_ON_CFM_MM:
         if(vxUSUCallBks.pfn_USU_CipherStatus != NULL){
		  
            vxUSUCallBks.pfn_USU_CipherStatus(IFX_TRUE);
  		      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			            "<USU_ProcessStkMesg>Callback cipher ON.");
		        return IFX_SUCCESS;
		     }
         break; 
      case FP_CIPHER_OFF_CFM_MM:
         if(vxUSUCallBks.pfn_USU_CipherStatus != NULL){
		  
            vxUSUCallBks.pfn_USU_CipherStatus(IFX_OFF);
  		      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			            "<USU_ProcessStkMesg>Callback cipher OFF.");
		        return IFX_SUCCESS;
		     }
#endif
		  default:
		     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
			          "<USU_ProcessStkMesg>Para1 in pxIpcMsg does not match.Value:",pxIpcMesg->ucPara1);
			 return IFX_FAILURE;
		}
			
		return IFX_SUCCESS;
		break;
		
    default:
	   
	    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		         "<USU_ProcessStkMesg>Invalid IPC Message.");
	    return IFX_FAILURE;
  } 
  return IFX_SUCCESS;

}
/*! \brief  This function is used to switch on/off the DECT RF. 
        \param[in] bOnOff Turn On/Off RF. IFX_ON to turn on RF, 
                           IFX_OFF to turn off RF
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_USU_RFConfig(IN boolean bOnOff)
{
	if(bOnOff){
	  vucDownloadBmcOnBootInd =0;
	  write_to_hmac_ioctl(1, 34
         ,0, 0, 0, 0
         ,0, 0, 0, 0);
	}else{
		vucDownloadBmcOnBootInd =1;
	}
  return IFX_SUCCESS;
}
/*! \brief  This function is used to DECT Version information. 
    \return IFX_SUCCESS / IFX_FAILURE
*/                                       
void IFX_DECT_USU_PrintVersion()
{
	printf(" The DECT Stack and Toolkit Version is %s\n",IFX_DECT_TK_VERSION);
	printf(" Dect Toolkit compiled on Date:%s:%s\n",__DATE__,__TIME__);
	IFX_DECT_Stack_PrintVersion();
	printf(" The cosic modem version is %s\n",IFX_DECT_COSIC_MODEM_SW_VERSION);
	
		
}

#ifdef FW_DOWNLOAD
#define vxMUInfo vxGlobalInfo.xMU.vxMUInfo
/*! \brief  This function is used to download the firmware files to the Cosic Modem. 
                   The FT application shall invoke this function when it needs to download 
                   the firmware files to the modem. Typically, this function is called by 
                   the FT application during the boot/initialization time when the modem 
                   needs to be initialized. This function takes care to segment the firmware 
                   contents into different chunks, sequences the chunks and delivers the 
                   chunks to the Cosic Driver. The Cosic Driver in turn uses the SPI interface 
                   to deliver the chunks to the Cosic Modem. This function uses the modem 
                   bootloader commands to manage the download. Since the download is 
                   expected to take some time, this function shall return immediately with 
                   a return value of IFX_PENDING. Upon completion of the download the 
                   DECT TK shall invoke the pfn_IFX_DECT_USU_ModemFirmwareDownload 
                   callback function to communicate the download status to the FT application. 
                   If there is an error in the Path or in the names of the firmware files, 
                   this function returns an error immediately. 
        \param[in] pcPath Path where the firmware files are stored in the filesystem.
        \param[in] pcBmcFwFileName Name of the BMC Firmware file. If no name is provided, default shall be assumed. 
        \param[in] pcUserApplnFileName Name of the User Application file. If no name is provided, default shall be assumed.
        \return IFX_SUCCESS / IFX_FAILURE
*/
extern int32 dect_drv_fd;
uchar8 IFX_DECT_USU_ComputeCRC(char8 *pcBuff, uint16 unLen)
{
  uint16 unCRC=0;
  uint32 uiCount=0;
  #ifdef KLOCWORK
  pcBuff += 4;/*point to aucOpcode member of str x_IFX_DECT_LoaderFrame*/
  #endif
  for(uiCount=0;uiCount<unLen;uiCount++){
       unCRC += *pcBuff&0xFF;
       pcBuff++;
      if(unCRC >0xFF){
        unCRC-=0x100;
        unCRC&=0xFF;
      }
  }
  if(unCRC){
    unCRC = 0x100-unCRC; // 2's complement
  }
  return unCRC&0xFF;
}
char8 IFX_DECT_USU_PrintByteMap(char8 *pcBuff, uint16 unLen){
   
  uint32 uiCount=0;
  printf("\n");
  for(uiCount=0;uiCount<unLen;uiCount++){
    printf("%x\t",*pcBuff&0xFF);
    pcBuff++;
    if((uiCount%10 == 1)&&(uiCount != 1)){
      printf("\n");
    }
  }
  printf("\n");
  return 0;
}

#ifdef FW_TIMER
/*! \brief The is a timer callback function to handle retransmisson of the fw frame
	  \param[in] uiTimerId Timer Identifier.
	  \param[in] pvPrivateData private data.
	  \return none.
*/
void IFX_DECT_FirmwareNoStatusTimerFired(IN uint32 uiTimerId,
                                     IN void* pvPrivateData)
{
  if(vucLoaderMode ==0){ //special handling if any time outs
       return;
   }
	 IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "!!!!Timed Out Sending Frame Again no response from Modem!!!!!\n");
   if(ioctl(dect_drv_fd,DECT_DRV_FW_WRITE,&vxFramebackup)<0){
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "ioctl write Failed");
   }
   if(vucRetryCount <5){
      vucRetryCount++;
      IFX_DECT_StartTimer(vucRetryCount*5000,
           0, 0, IFX_DECT_FirmwareNoStatusTimerFired, &vuiFwTimer);
   }else
   {
     if(vxUSUCallBks.pfn_USU_FirmwareDownloadStatus != NULL)
	   {
		   vxUSUCallBks.pfn_USU_FirmwareDownloadStatus(IFX_FAILURE);
	   }
#ifdef COSIC_BMC_FW_ON_RAM
     IFX_DECT_USU_ModemFirmwareDownload("/flash/","BMCFw.BIN","COSICFw.BIN");
#else
     IFX_DECT_USU_ModemFirmwareDownload("/opt/ifx/downloads/","BMCFw.BIN","COSICFw.BIN");
#endif
     vucRetryCount =0;  
   }
}
#endif

e_IFX_Return  IFX_DECT_USU_ModemFirmwareDownload (IN char8 *pcPath, IN char8 *pcBmcFwFileName,
												  IN char8 *pcUserApplnFileName)
{
  x_IFX_DECT_LoaderFrame xFrame={{0}};
  uint16 unSize=0;
  vunLoaderAddr =0;
	xFrame.ucStart =0x02;
	xFrame.ucTag =0x02;
  
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Entry");

	/*Step1 Check for file  and path existance*/
	if(pcPath == NULL)goto FirmFail;
	
	strcpy(vaucBMCFileName,pcPath);
	
	if(pcBmcFwFileName == NULL){
        strcpy(&vaucBMCFileName[strlen(pcPath)],"BmcMpv9_1_31.bin");
	}else{
       strcpy(&vaucBMCFileName[strlen(pcPath)],pcBmcFwFileName);
	}
	
	strcpy(vaucUserAppFileName,pcPath);
    
	if(pcUserApplnFileName == NULL){
       strcpy(&vaucUserAppFileName[strlen(pcPath)],"FT9643.BIN");
	}else{
		strcpy(&vaucUserAppFileName[strlen(pcPath)],pcUserApplnFileName);
	}
	
  if(access(vaucBMCFileName, F_OK)==-1){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            vaucBMCFileName);
     goto FirmFail;
  }
  
  if(access(vaucUserAppFileName, F_OK)==-1){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            vaucUserAppFileName);
      goto FirmFail;
  }
  
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "Path and file found");
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "No Calls moving to Download mode");
  vucLoaderMode = 1;
 	if(ioctl(dect_drv_fd,DECT_DRV_SET_LOADER_MODE,NULL)<0){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "ioctl write Failed");
    goto FirmFail;
  }
  sleep(5);
#if 1
  xFrame.aucOpcode[0] =0x03;
  xFrame.aucOpcode[1] =0x38;
  xFrame.aucData[0]=0x01;
  xFrame.aucData[1]=0x00;
  unSize =2;
  xFrame.aucSize[0]=unSize>>8;
  xFrame.aucSize[1]=unSize&0xFF;
  #ifdef KLOCWORK
  xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(((char8 *)&xFrame),unSize+4); 
  #else
  xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(((char8 *)xFrame.aucOpcode),unSize+4); 
  #endif
  xFrame.aucData[unSize]=xFrame.ucCRC;
  unSize +=7;
  xFrame.aucLen[0]= unSize>>8;
  xFrame.aucLen[1]= unSize&0xFF;
#else
  xFrame.aucOpcode[0] =0x05;
  xFrame.aucOpcode[1] =0x18;
  xFrame.aucData[0]=0x01;
  xFrame.aucData[1]=0x02;
  xFrame.aucData[2]=0x03;
  unSize =3;
  xFrame.aucSize[0]=unSize>>8;
  xFrame.aucSize[1]=unSize&0xFF;
  xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(xFrame.aucOpcode,unSize+4); 
  xFrame.aucData[unSize]=xFrame.ucCRC;
  unSize +=7;
  xFrame.aucLen[0]= unSize>>8;
  xFrame.aucLen[1]= unSize&0xFF;
#endif

  //IFX_DECT_USU_PrintByteMap((char8 *)&xFrame,unSize+2);
#ifdef FW_TIMER
  vucRetryCount=0;
  memcpy(&vxFramebackup,&xFrame,sizeof(vxFramebackup));
  IFX_DECT_StartTimer(5000,
           0, 0, IFX_DECT_FirmwareNoStatusTimerFired, &vuiFwTimer);
#endif

	if(ioctl(dect_drv_fd,DECT_DRV_FW_WRITE,&xFrame)<0){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "ioctl write Failed");
    goto FirmFail;
  }
	 return IFX_SUCCESS;
FirmFail:
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "Failed for Various reasons");
  return IFX_FAILURE;
         
}
#define IFX_DECT_FW_BLOCK_SIZE 490


e_IFX_Return IFX_DECT_ReceivedFwDownloadStatus(x_IFX_DECT_LoaderFrame *pxConFrame)
{
	x_IFX_DECT_LoaderFrame xFrame={{0}};
  uint16 unSize=0,nReadBytes=0/*,unTemp=0*/;
  
	xFrame.ucStart =0x02;
	xFrame.ucTag =0x02;
  if(vucLoaderMode ==0){
	  printf("Hitting here.. not good !\n");
#ifdef FW_TIMER
	   vucRetryCount=0;
	   IFX_DECT_StopTimer(vuiFwTimer);
#endif
  }

#ifdef RAD_DBG
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Entry");
#endif
	switch(pxConFrame->aucOpcode[0]<<8|pxConFrame->aucOpcode[1]){
    case 0x0519:
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "Echo  Confirm arrived");
      break;

    case 0x1009:
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "SRF Write Confirm arrived");
      break;
    case 0x339:
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "Baud Rate Confirm arrived");
      sleep(2);
#ifdef FW_TIMER
	   vucRetryCount=0;
	   IFX_DECT_StopTimer(vuiFwTimer);
#endif

     vunLoaderAddr =0;
     xFrame.aucOpcode[0] =0x14;
     xFrame.aucOpcode[1] =0x08;
      iFileFd = open(vaucBMCFileName,O_RDONLY);
	    unSize = read(iFileFd,&xFrame.aucData[5],IFX_DECT_FW_BLOCK_SIZE);
	    if(unSize <= 0 || unSize >= 517-5-7){
        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "<IFX_DECT_USU_ModemFirmwareDownload> read Failed");
		    goto FirmConfFail;
	    }
      xFrame.aucData[0]=0x00; //bank
      xFrame.aucData[1]=vunLoaderAddr>>8; // MSB addr
      xFrame.aucData[2]=vunLoaderAddr&0x00FF; //LSB addr
      xFrame.aucData[3]=unSize>>8; //MSB Length
      xFrame.aucData[4]=unSize&0x00FF;//LSB Length
      vunLoaderAddr += unSize;
      unSize += 5;
      xFrame.aucSize[0]=unSize>>8;
      xFrame.aucSize[1]=unSize&0xFF;
	  #ifdef KLOCWORK
  	  xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(((char8 *)&xFrame),unSize+4); 
  	  #else
      xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(((char8 *)xFrame.aucOpcode),unSize+4);
      #endif
      xFrame.aucData[unSize]=xFrame.ucCRC;
      unSize +=7;
      xFrame.aucLen[0]= unSize>>8;
      xFrame.aucLen[1]= unSize&0xFF;
      //IFX_DECT_USU_PrintByteMap((char8 *)&xFrame,unSize);
#ifdef FW_TIMER
	   memcpy(&vxFramebackup,&xFrame,sizeof(vxFramebackup));
	   IFX_DECT_StartTimer(5000,
           0, 0, IFX_DECT_FirmwareNoStatusTimerFired, &vuiFwTimer);
#endif

	    if(ioctl(dect_drv_fd,DECT_DRV_FW_WRITE,&xFrame)<0){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "ioctl write Failed");
        goto FirmConfFail;
     }
     break;  
		case 0x1409:
             printf("#");
			 fflush(stdout);
#ifdef FW_TIMER
	   vucRetryCount=0;
	   IFX_DECT_StopTimer(vuiFwTimer);
#endif

           //unTemp = pxConFrame->aucData[1]<<8| pxConFrame->aucData[2];
           //printf("The Address at confirmation is %x\n",unTemp);
           if(iFileFd == 0){
             break;
           }
           xFrame.aucOpcode[0] =0x14;
           xFrame.aucOpcode[1]= 0x08;
           unSize = read(iFileFd,&xFrame.aucData[5],IFX_DECT_FW_BLOCK_SIZE);
		   	   if(unSize <= 0){
               close(iFileFd);
               iFileFd =0;
		           iFileFd1 = open(vaucUserAppFileName,O_RDONLY);
               xFrame.aucOpcode[0] =0x13;
               xFrame.aucOpcode[1] =0x08;
               unSize = read(iFileFd1,&xFrame.aucData[5],IFX_DECT_FW_BLOCK_SIZE);
               vunLoaderAddr =0;
               vucBank=0;
	          }
            xFrame.aucData[0]=0x00; //bank
            xFrame.aucData[1]=vunLoaderAddr>>8; // MSB addr
            xFrame.aucData[2]=vunLoaderAddr&0x00FF; //LSB addr
            xFrame.aucData[3]=unSize>>8; //MSB Length
            xFrame.aucData[4]=unSize&0x00FF;//LSB Length
            vunLoaderAddr += unSize;
            unSize+=5;
            xFrame.aucSize[0]=unSize>>8;
            xFrame.aucSize[1]=unSize&0xFF;
			#ifdef KLOCWORK
            xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(((char8 *)&xFrame),unSize+4); 
            #else
            xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(((char8 *)xFrame.aucOpcode),unSize+4);
			#endif
            xFrame.aucData[unSize]=xFrame.ucCRC;
            unSize +=7;
            xFrame.aucLen[0]= unSize>>8;
            xFrame.aucLen[1]= unSize&0xFF;
            //IFX_DECT_USU_PrintByteMap((char8 *)&xFrame,unSize+2);
#ifdef FW_TIMER
        	   memcpy(&vxFramebackup,&xFrame,sizeof(vxFramebackup));
        	   IFX_DECT_StartTimer(5000,
               0, 0, IFX_DECT_FirmwareNoStatusTimerFired, &vuiFwTimer);
#endif

	          if(ioctl(dect_drv_fd,DECT_DRV_FW_WRITE,&xFrame)<0){
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "ioctl write Failed");
              goto FirmConfFail;
           }
		       break;
		case 0x140A:
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "BMC Status Failed moving to App mode");
	          if(ioctl(dect_drv_fd,DECT_DRV_FW_WRITE,&xFrame)<0){
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                    "ioctl write Failed");
               goto FirmConfFail;
           }
			     break;
    case 0x1309:
           printf("$");
			     fflush(stdout);
#ifdef FW_TIMER
	   vucRetryCount=0;
       IFX_DECT_StopTimer(vuiFwTimer);
#endif 
           //unTemp = pxConFrame->aucData[1]<<8| pxConFrame->aucData[2];
           //printf("The Address at confirmation is %x\n",unTemp);
           if(iFileFd1 == 0){
             break;
           }
			      xFrame.aucOpcode[0] =0x13;
            xFrame.aucOpcode[1] =0x08;
            nReadBytes=IFX_DECT_FW_BLOCK_SIZE;
            if(vunLoaderAddr+IFX_DECT_FW_BLOCK_SIZE > 0xFFFF){
               nReadBytes = 0xFFFF-vunLoaderAddr;
            }
            unSize = read(iFileFd1,&xFrame.aucData[5],nReadBytes);
            if(unSize <= 0){
               close(iFileFd1);
               iFileFd1 =0;
               IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "DOWNLOAD COMPLETE Moving to APP Mode");
              vucLoaderMode = 0;
			        xFrame.aucOpcode[0] =0x10;
              xFrame.aucOpcode[1] =0x08;
              xFrame.aucData[0]=0x00; 
              xFrame.aucData[1]=0x00; 
              xFrame.aucData[2]=0xC8; 
              xFrame.aucData[3]=0x00; 
              xFrame.aucData[4]=0x01; 
              xFrame.aucData[5]=0x02; 
              unSize=6; 
              xFrame.aucSize[0]=unSize>>8;
              xFrame.aucSize[1]=unSize&0xFF;
			  #ifdef KLOCWORK
               xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(((char8 *)&xFrame),unSize+4); 
              #else
              xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(((char8 *)xFrame.aucOpcode),unSize+4);
			  #endif
              xFrame.aucData[unSize]=xFrame.ucCRC;
              unSize +=7;
              xFrame.aucLen[0]= unSize>>8;
              xFrame.aucLen[1]= unSize&0xFF;
              
              //IFX_DECT_USU_PrintByteMap((char8 *)&xFrame,unSize+2);
#if 0
         	    memcpy(&vxFramebackup,&xFrame,sizeof(vxFramebackup));
	            IFX_DECT_StartTimer(5000,
                                  0, 0, IFX_DECT_FirmwareNoStatusTimerFired, &vuiFwTimer);
#endif
              if(ioctl(dect_drv_fd,DECT_DRV_FW_WRITE,&xFrame)<0){
                 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                          "ioctl write Failed");
                 goto FirmConfFail;
              }
           }
#if 0
              xFrame.aucData[0]=0x00; 
              xFrame.aucData[1]=0x00; 
              xFrame.aucData[2]=0xD1; 
              xFrame.aucData[3]=0x00; 
              xFrame.aucData[4]=0x01; 
              xFrame.aucData[5]=0x0E; 
              unSize=6; 
              xFrame.aucSize[0]=unSize>>8;
              xFrame.aucSize[1]=unSize&0xFF;
              xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(xFrame.aucOpcode,unSize+4);
              xFrame.aucData[unSize]=xFrame.ucCRC;
              unSize +=7;
              xFrame.aucLen[0]= unSize>>8;
              xFrame.aucLen[1]= unSize&0xFF;
              
             // IFX_DECT_USU_PrintByteMap((char8 *)&xFrame,unSize+2);
	            
              if(ioctl(dect_drv_fd,DECT_DRV_FW_WRITE,&xFrame)<0){
                 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                          "ioctl write Failed");
                 goto FirmConfFail;
              }
			        xFrame.aucOpcode[0] =0x10;
              xFrame.aucOpcode[1] =0x04;
              xFrame.aucData[0]=0x00; 
              xFrame.aucData[1]=0x00; 
              xFrame.aucData[2]=0xC8; 
              xFrame.aucData[3]=0x00; 
              xFrame.aucData[4]=0x01; 
              unSize=5; 
              xFrame.aucSize[0]=unSize>>8;
              xFrame.aucSize[1]=unSize&0xFF;
              xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(xFrame.aucOpcode,unSize+4);
              xFrame.aucData[unSize]=xFrame.ucCRC;
              unSize +=7;
              xFrame.aucLen[0]= unSize>>8;
              xFrame.aucLen[1]= unSize&0xFF;
              
             // IFX_DECT_USU_PrintByteMap((char8 *)&xFrame,unSize+2);
	            
              if(ioctl(dect_drv_fd,DECT_DRV_FW_WRITE,&xFrame)<0){
                 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                          "ioctl write Failed");
                 goto FirmConfFail;
              }

              break; 
	         }
#endif
           xFrame.aucData[0]=vucBank; //bank
           xFrame.aucData[1]=vunLoaderAddr>>8; // MSB addr
           xFrame.aucData[2]=vunLoaderAddr&0x00FF; //LSB addr
           xFrame.aucData[3]=unSize>>8; //MSB Length
           xFrame.aucData[4]=unSize&0x00FF;//LSB Length
           vunLoaderAddr += unSize;
           if(vunLoaderAddr == 0xFFFF){
             vucBank++;
             vunLoaderAddr =0;
           }
           unSize+=5;
           xFrame.aucSize[0]=unSize>>8;
           xFrame.aucSize[1]=unSize&0xFF;
		   #ifdef KLOCWORK
  			xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(((char8 *)&xFrame),unSize+4); 
  		   #else
           xFrame.ucCRC = IFX_DECT_USU_ComputeCRC(((char8 *)xFrame.aucOpcode),unSize+4);
		   #endif
           xFrame.aucData[unSize]=xFrame.ucCRC;
           unSize +=7;
           xFrame.aucLen[0]= unSize>>8;
           xFrame.aucLen[1]= unSize&0xFF;
           //IFX_DECT_USU_PrintByteMap((char8 *)&xFrame,unSize+2);
#ifdef FW_TIMER
	    memcpy(&vxFramebackup,&xFrame,sizeof(vxFramebackup));
	    IFX_DECT_StartTimer(500,
           0, 0, IFX_DECT_FirmwareNoStatusTimerFired, &vuiFwTimer);
#endif

	         if(ioctl(dect_drv_fd,DECT_DRV_FW_WRITE,&xFrame)<0){
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                          "ioctl write Failed");
               goto FirmConfFail;
           }

			     break;
		case 0x130A:
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "User SW Status Failed moving to App mode");
			if(ioctl(dect_drv_fd,DECT_DRV_SET_APP_MODE,NULL)<0) goto FirmConfFail;
			break;
	}
	return IFX_SUCCESS;
FirmConfFail:
	return IFX_SUCCESS;
}

#endif

















