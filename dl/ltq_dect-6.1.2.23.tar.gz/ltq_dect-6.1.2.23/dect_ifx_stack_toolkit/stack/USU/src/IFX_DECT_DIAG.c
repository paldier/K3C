/**************************************************************************
**   FILE NAME     : IFX_DECT_DIAG.c
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "FDEF.H"
#include "IFX_DECT_StackIf.h"
#include "dect_drv_if.h"
#include "IFX_DECT_Platform.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_DIAG.h"
#include "IFX_DECT_DIAG_Int.h"
#define printf(...)


#define viDiagMode vxGlobalInfo.xDIAG.viDiagMode
#define uiTC vxGlobalInfo.xDIAG.uiTC
#define isDiagOnGoing vxGlobalInfo.xDIAG.isDiagOnGoing


/* XRAM related stuff*/
//unsigned char *xram_ptr; 
unsigned char mem_buf[43];
unsigned char xram_tpc_buf[43];
unsigned char xram_tpc_buf1[43];
unsigned char xram_tpc_buf2[43];

/* Flags indicating the values set before modem reset*/
unsigned char ucBmcParamSet= FALSE;
unsigned char ucFreqParamSet= FALSE;
unsigned char ucOscParamSet = FALSE;
unsigned char ucGfskParamSet = FALSE;
unsigned char ucRFPIParamSet = FALSE;
unsigned char ucTPCParamSet = FALSE;

unsigned char ucMEMSet = FALSE;

/*Set buffers */
int MAC_Test_Mode1 = FALSE;
x_IFX_DECT_BMCRegParams vxBMCPrams;
uchar8 vucOsc_Trim_H;
uchar8 vucOsc_Trim_L;
uchar8 vucP10Status=0;
uchar8 vauRfpi[5];
uchar8 vauCMRfpi[5];
uint16 vunGFSK_Value;
uchar8 Mem_length=0;

/* Get buffers*/
uchar8 vucRFMode;
uchar8 vucChannelNumber;
uchar8 vucSlotNumber;

extern int dect_drv_fd;//Move to GlobalInfo
extern unsigned char * Get_Rfpi_Ptr( void );


#define TEST

/******************************************************************
 *  Function Name    : IFX_DECT_DIAG_TestAppSelectRead 
 *  Description      : The Api blocks on Cosic Driver Fd for reading 
                       data from Modem.
 *  Input Values     : None
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/

e_IFX_Return IFX_DECT_DIAG_TestAppSelectRead(){
 
    
    fd_set xReadFds;
    int32 iNoOfFds;

  	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               " <API IFX_DECT_DIAG_TestAppSelectRead>Entry TestAppSelectRead.");

    FD_ZERO(&xReadFds);

    isDiagOnGoing = TRUE;
	
	  FD_SET(dect_drv_fd, &xReadFds);
  
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
               " <API IFX_DECT_DIAG_TestAppSelectRead>dect_drv_fd",dect_drv_fd);
	
    //IFX_OS_LockAcquire(vxGlobalInfo.xDIAGApiLock);
	sleep(2); 
	while(1){

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               " <API IFX_DECT_DIAG_TestAppSelectRead>Waiting on SelectRead...");
	
    iNoOfFds = select(FD_SETSIZE,&xReadFds,NULL,NULL,NULL);//blocking

    printf("\n iNoOfFds:%d\n",iNoOfFds);

	if(iNoOfFds < 0){
	
      
	  isDiagOnGoing = FALSE;
      return IFX_FAILURE;
	} 
      
	if ( dect_drv_fd && FD_ISSET(dect_drv_fd,&xReadFds) ){
       
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               " <API IFX_DECT_DIAG_TestAppSelectRead>Read fd unblocked.");

	   if(HandleDrvMsg1() == IFX_SUCCESS){

	     break;
	   }	 
	}
	
	}
	 //IFX_OS_LockRelease(vxGlobalInfo.xDIAGApiLock);
	
	FD_CLR(dect_drv_fd,&xReadFds);
	
    isDiagOnGoing = FALSE;	
    return IFX_SUCCESS;
	
}


/******************************************************************
 *  Function Name    : IFX_DECT_DIAG_TestAppSelectDebug 
 *  Description      : 
 *  Input Values     : None
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/

e_IFX_Return IFX_DECT_DIAG_TestAppSelectDebug(){
 
    
    fd_set xReadFds;
    int32 iNoOfFds;

    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               " <API IFX_DECT_DIAG_TestAppSelectDebug>Entry TestAppSelectDebug.");

    FD_ZERO(&xReadFds);

    isDiagOnGoing = TRUE;
	
	FD_SET(dect_drv_fd, &xReadFds);

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
               " <API IFX_DECT_DIAG_TestAppSelectDebug>dect_drv_fd",dect_drv_fd);


     //IFX_OS_LockAcquire(vxGlobalInfo.xDIAGApiLock);
	
	while(1){

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               " <API IFX_DECT_DIAG_TestAppSelectDebug>Waiting on SelectDebug...");

    //iNoOfFds = select(FD_SETSIZE,&xReadFds,NULL,NULL,NULL);//blocking
    iNoOfFds = select(FD_SETSIZE,NULL,&xReadFds,NULL,NULL);//TODO:CHECK READ AND WRITE

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
               " <API IFX_DECT_DIAG_TestAppSelectDebug>iNoOfFds",iNoOfFds);


	if(iNoOfFds < 0){
      
	  isDiagOnGoing = FALSE;
      return IFX_FAILURE;
	} 
      
	if ( dect_drv_fd && FD_ISSET(dect_drv_fd,&xReadFds) ){

     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               " <API IFX_DECT_DIAG_TestAppSelectDebug>Write fd unblocked..");

	   if(HandleDectDbg() == IFX_SUCCESS){
         break; 
	   }
	}
	}
	 //IFX_OS_LockRelease(vxGlobalInfo.xDIAGApiLock);
	FD_CLR(dect_drv_fd,&xReadFds);
	
    isDiagOnGoing = FALSE;	
    return IFX_SUCCESS;
	
}


/******************************************************************
 *  Function Name    : HandleDrvMsg
 *  Description      : This function handles cosic driver messages
 *  Input Values     : 
 *                   : 
 *                   : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
e_IFX_Return HandleDrvMsg1()
{
         HMAC_QUEUES data[200];
         int  i;
		 e_IFX_Return eRet = IFX_FAILURE;
		 int ret=0;
         memset(data, 0, 200 * sizeof(HMAC_QUEUES));

  	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               " <API HandleDrvMsg1>Entry.");
         do
         {
           ret = ioctl(dect_drv_fd,DECT_DRV_FROM_HMAC_MSG, data);
		   
           /* return value                0  :  continues data,
            -1  :  last data
            -2  :  null data         */
  	       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                    " <API HandleDrvMsg1>HandleDrvMsg1 returned ",ret);
           if(ret > 0)
           {
             for(i=0; i<ret;i++) 
             {
               /* put queue */
               /* TestAppInitMac(&data[i]); */
  	       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                    " <API HandleDrvMsg1>Packet ",i+1);
               if(TestAppPrcMsg(&data[i]) == IFX_FAILURE){
			     if(eRet == IFX_SUCCESS){
  	          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                        " <API HandleDrvMsg1>IFX_SUCCESS returned.");
				   return IFX_SUCCESS;
				 }  
  	       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               " <API HandleDrvMsg1>IFX_FAILURE returned.");
			     return IFX_FAILURE;
			   }else{
                 eRet = IFX_SUCCESS;
			    }
             }
		   }
         } while (!ret);

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
               " <API HandleDrvMsg1>Api returned ",eRet);
  return eRet;		 
}
/******************************************************************
 *  Function Name    : HandleDectDbg
 *  Description      : This function handles cosic driver debug messages
 *  Input Values     : 
 *                   : 
 *                   : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
e_IFX_Return HandleDectDbg()
{
	     int i;
         int ret_read_debug =0;
		 e_IFX_Return eRet = IFX_FAILURE;
		 
         DECT_MODULE_DEBUG_INFO data[10/*RECEIVED_BUFFER_COUNT*/];
         memset(&data, 0x00, sizeof(data));

  	     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API HandleDectDbg>Entry.");
         ret_read_debug =  ioctl(dect_drv_fd,DECT_DRV_DEBUG_INFO_FROM_MODULE, data);
		 
  	     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API HandleDectDbg>HandleDectDbg returned ",ret_read_debug);
         if(ret_read_debug > 0)
         {
            for(i=0; i< ret_read_debug; i++)
            {
  	       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API HandleDectDbg>Invoking TestAppPrcDbgMsg ");
               if(TestAppPrcDbgMsg(&data[i]) == IFX_FAILURE){
  	       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API HandleDectDbg>IFX_FAILURE returned ");
			     return IFX_FAILURE;
			   }else{
  	       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API HandleDectDbg>IFX_SUCCESS returned ");

			     eRet = IFX_SUCCESS;
				} 										  
            }
         }
  	 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API HandleDectDbg>Api returned ",eRet);
		 return eRet;
}
/******************************************************************
 *  Function Name    : FlushOldPackets
 *  Description      : This function handles flush packets
 *  Input Values     : 
 *                   : 
 *                   : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
void FlushOldPackets(void)
{
   HMAC_QUEUES data[200];
   int  ret;
   memset(data, 0, 200 * sizeof(HMAC_QUEUES));
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               " <API FlushOldPackets>Flush Old Packets.");
   do
   {  
     ret = ioctl(dect_drv_fd,DECT_DRV_FROM_HMAC_MSG, data);
   } while (!ret);
   return;
}

/******************************************************************
 *  Function Name    : SetFreqDef
 *  Description      : This function sets deafult frequency
 *  Input Values     : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
void SetFreqDef()
{
   ucFreqParamSet = TRUE;
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API SetFreqDef>Set Default Frequency.");
   /* Defaults set to ETSI */
   vxBMCPrams.ucGENMUTCTRL0= Bmc_Rssi_Settings.ucGENMUTCTRL0; /** General Mute control reg - first byte */
   vxBMCPrams.ucGENMUTCTRL1= Bmc_Rssi_Settings.ucGENMUTCTRL1; /** GEneral Mute control reg - second byte */
   vxBMCPrams.ucEXTMUTCTRL0= Bmc_Rssi_Settings.ucEXTMUTCTRL0; /** External Mute control reg - first byte */
}


/******************************************************************
 *  Function Name    : SetTPCDef
 *  Description      : This function sets BMC default
 *  Input Values     : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
void SetTPCDef()
{

   uint16 unAddr = 0x04F7;
   uint16 unAddr1 = 0x1DF6;
   uint16 unAddr2 = 0x01F9;

   ucTPCParamSet = TRUE;
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API SetTPCDef>Set Default TPC.");

   xram_tpc_buf[0] = 0x01; // xram
   xram_tpc_buf[1] = (unAddr & 0xff00) >> 8;
   xram_tpc_buf[2] = (unAddr & 0x00ff);

   xram_tpc_buf1[0] = 0x01; // xram
   xram_tpc_buf1[1] = (unAddr1 & 0xff00) >> 8;
   xram_tpc_buf1[2] = (unAddr1 & 0x00ff);

   xram_tpc_buf2[0] = 0x01; // xram
   xram_tpc_buf2[1] = (unAddr2 & 0xff00) >> 8;
   xram_tpc_buf2[2] = (unAddr2 & 0x00ff);

   memcpy(&xram_tpc_buf[3],Tpc_Param_Buf,7);
   memcpy(&xram_tpc_buf1[3],Tpc_Param_Buf1,14);
   memcpy(&xram_tpc_buf2[3],Tpc_Param_Buf2,1);

}
/******************************************************************
 *  Function Name    : SetBmcDef
 *  Description      : This function sets BMC default
 *  Input Values     : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
void SetBmcDef()
{
   ucBmcParamSet = TRUE;
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API SetBmcDef>Set Default BMC Parameters.");
   /* Get Values from Stack*/
   memcpy(&vxBMCPrams,&Bmc_Rssi_Settings,sizeof(vxBMCPrams));
 }
/******************************************************************
 *  Function Name    : SetOscDef
 *  Description      : This function set Oscilator default values
 *  Input Values     : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/

void SetOscDef()
{
   ucOscParamSet = TRUE;
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API SetOscDef>Set Default Oscillator Trim Values.");
   /* default OSC parameters  */
   vucOsc_Trim_H = Osc_Trim_H;
   vucOsc_Trim_L= Osc_Trim_L;
   vucP10Status=0;
}
/******************************************************************
 *  Function Name    : SetGfskDef
 *  Description      : This function sets deafult GFSK values
 *  Input Values     : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
void SetGfskDef()
{
   ucGfskParamSet = TRUE;
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API SetGfskDef>Set Default Gfsk Values.");
   /* default GFSK parameters  */
   vunGFSK_Value= GFSK_Value;  /* 0xaf */
}
/******************************************************************
 *  Function Name    : SetRFPIDef1
 *  Description      : This function sets deafult defualt RFPI values
 *  Input Values     : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
void SetRFPIDef1()
{
   int i=0;
   char8 *pcTemp = ((char8 *)Get_Rfpi_Ptr());
   ucRFPIParamSet = TRUE;
  
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API SetRFPIDef1>Set Default RFPI Values.");
   /* Set RFPI default */
   for (i=0; i<5; i++)
   {
	 vauRfpi[i] = pcTemp[i];
   }
   printf("RFPI: 0x%x 0x%x 0x%x 0x%x 0x%x\n", vauRfpi[0],
	   vauRfpi[1], vauRfpi[2], vauRfpi[3], vauRfpi[4]);
   return; 
}
/******************************************************************
 *  Function Name    : TestAppWriteToHmac
 *  Description      : This function writes to HMAC
 *  Input Values     : 
 *                   : 
 *                   : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
void TestAppWriteToHmac(BYTE procid, BYTE msgnr
                  ,BYTE param1, BYTE param2, BYTE param3, BYTE param4
                  ,BYTE param5, BYTE param6, FPTR pdata, BYTE inc)
{
   HMAC_QUEUES send_data;
   int ret = 0;
 
   memset(&send_data, 0x00, sizeof(HMAC_QUEUES));
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppWriteToHmac>Entry.");
 
   send_data.PROCID = procid;
   send_data.MSG = msgnr;
   send_data.Parameter1 = param1;
   send_data.Parameter2 = param2;
   send_data.Parameter3 = param3;
   send_data.Parameter4 = param4;

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API TestAppWriteToHmac>PROCID ",procid);

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API TestAppWriteToHmac>MSG ",msgnr);
   if (pdata != NULL)
   {
      if(param5)  /* include HLI_Header pointer */
         memcpy(send_data.G_PTR_buf, &pdata[sizeof( struct HLI_Header )], 
                (((struct HLI_Header *)pdata)->length) - 
                   sizeof( struct HLI_Header ));
      else /*   Not HLI_Header            param6 is length */
         memcpy(send_data.G_PTR_buf, pdata, param6);
   }
   send_data.CurrentInc = inc;
   
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppWriteToHmac>TestAppWriteToHmac wrote message to hmac.");
   ret = ioctl(dect_drv_fd,DECT_DRV_TO_HMAC_MSG, &send_data);
   
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API TestAppWriteToHmac>ioctl returned ",ret);
   
   if( (pdata!=NULL) && (send_data.MSG!= MAC_SEND_DUMMY_RQ_ME)){
         free(pdata);
   }
}
/******************************************************************
 *  Function Name    : TestAppPrcMsg
 *  Description      : This function process the data read from the driver
 *  Input Values     : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
e_IFX_Return TestAppPrcMsg(HMAC_QUEUES* data)
{
   
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcMsg>Entry.");
   switch (uiTC)
   {
      case TC_RESET:
         /* Expect Boot indication */
         {

       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcMsg>uiTC is TC_RESET.");
         if(data->PROCID == PROCMAX && data->MSG == STACK_INITAL_CMD)
         {
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcMsg>Invoking TestAppInitMac.");
		    
            TestAppInitMac(data);
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcMsg>IFX_SUCCESS returned.");
            return IFX_SUCCESS;
			
         }else{
		 
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcMsg>Got unexpected msg.IFX_FAILURE returned.");

            return IFX_FAILURE;
         }
		} 
         break;

      case TC_TBR6:

            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcMsg>uiTC is TC_TBR6.");
         if(data->PROCID == PROCMAX && data->MSG == STACK_INITAL_CMD)
         {
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcMsg>Invoking TestAppInitMac.");
            TestAppInitMac(data);
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcMsg>IFX_SUCCESS returned.");
			return IFX_SUCCESS;
			
         }else{
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcMsg>Got unexpected msg.IFX_FAILURE returned.");
		   return IFX_FAILURE;
		 }
         break;
     
     default : 
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcMsg>Invalid test case.");
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API TestAppPrcMsg>Got some other message MSG ID ",data->MSG);
            return IFX_FAILURE;
   } 
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcMsg>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
} /* TestAppPrcMsg */

/******************************************************************
 *  Function Name    : TestAppPrcDbgMsg
 *  Description      : This function process Cosic Debug Message
 *  Input Values     : 
 *                   : 
 *                   : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
e_IFX_Return TestAppPrcDbgMsg(DECT_MODULE_DEBUG_INFO *data)
{
   int32 i=0;
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcDbgMsg>Entry.");
   if (!data)
   {
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcDbgMsg>Failed to obtain data from modem.IFX_FAILURE returned.");
      return IFX_FAILURE;
   }
#ifdef TEST
   for(i = 0;i<30;i++){
      printf("\n G_PTR_buf[%d] = %x\n",i,data->G_PTR_buf[i]);  
   }
 #endif  
   switch (uiTC)
   {
       case TC_BMC6GET:
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcDbgMsg>Obtained BMC Info.");
            printf("BMC INFO\n");
            printf("\n");
            printf("RSSI Free Level: 0x%x\n",data->G_PTR_buf[0]);
            printf("RSSI Busy Level: 0x%x\n",data->G_PTR_buf[1]);
            printf("RSSI DB Change Limit: 0x%x\n",data->G_PTR_buf[2]);
            printf("Default Antenna: 0x%x\n",data->G_PTR_buf[3]);
            printf("Window Open Sync Free Mode: 0x%x\n",data->G_PTR_buf[4]);
            printf("Window Width Sync Free Mode: 0x%x\n",data->G_PTR_buf[5]);
            printf("Control Reg. for DRON: 0x%x\n",data->G_PTR_buf[6]);
            printf("Delay Compensation: 0x%x\n",data->G_PTR_buf[7]);
            printf("Handover Evaluation Period: 0x%x\n",data->G_PTR_buf[8]);
            printf("General Sync Mode Setting: 0x%x\n",data->G_PTR_buf[9]);
            printf("\n");
            printf("NTP INFO\n");
            printf("\n");
            printf("Direct Biasing to PA1: 0x%x\n",data->G_PTR_buf[10]);
            printf("Direct Biasing to PA2: 0x%x\n",data->G_PTR_buf[11]);
            printf("Internal Power Amplifier Mode: 0x%x\n",data->G_PTR_buf[12]);
            printf("Power Amplifier OffsetControl: 0x%x\n",data->G_PTR_buf[13]);

			 /* BMC parameters */
			memset(&vxBMCPrams,0,sizeof(vxBMCPrams));
			memcpy(&vxBMCPrams,&data->G_PTR_buf[0],14);
			 

         break;
       case TC_BMCETSIGET:
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcDbgMsg>Obtained BMC ETSI Info.");
             printf("BMC ETSI INFO\n");
 	         printf("0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x \n", data->G_PTR_buf[0], data->G_PTR_buf[1], data->G_PTR_buf[2], data->G_PTR_buf[3],data->G_PTR_buf[4],data->G_PTR_buf[5],data->G_PTR_buf[6],data->G_PTR_buf[7],data->G_PTR_buf[8],data->G_PTR_buf[9]);

         break;
       case TC_OSCGET:
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcDbgMsg>Obtained OSCILLATOR TRIM Info.");
              printf("OSCILLATOR TRIM INFO \n");
              printf("\n");
              printf("OSC Trim Byte High Value: 0x%x\n",data->G_PTR_buf[14]);
              printf("OSC Trim Byte Low Value: 0x%x\n",data->G_PTR_buf[15]);
              printf("P10 Status: 0x%x\n",data->G_PTR_buf[3]);
              printf("\n");
	 break;
       case TC_GFSKGET:
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcDbgMsg>Obtained GFSK Info.");
              printf("GFSK INFO \n");
              printf("\n");
              printf("GFSK High Value: 0x%x\n",data->G_PTR_buf[16]);
              printf("GFSK Low Value: 0x%x\n",data->G_PTR_buf[17]);
              printf("\n");
         break;
       case TC_RFGET:
              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcDbgMsg>Obtained RF TEST MODE Info.");
               printf("RF TEST MODE INFO\n"); 
               printf("\n");
               printf("RF Test Mode: 0x%x\n", data->G_PTR_buf[24]);
			   vucRFMode = data->G_PTR_buf[24];
               printf("Channel Number: 0x%x\n", data->G_PTR_buf[25]);
			   vucChannelNumber = data->G_PTR_buf[25];
               printf("Slot Number: 0x%x\n", data->G_PTR_buf[26]);
			   vucSlotNumber = data->G_PTR_buf[26];
               printf("\n");
         break;
        case TC_MEMGET:
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcDbgMsg>Obtained MEM Info.");
               memset(mem_buf, 0, 43);
               printf("MEM INFO:\n"); 
               printf("\n");
               printf("MEM Id:0x%x Hibyte:0x%x Lobyte:0x%x\nBuffer(40 bytes):", data->G_PTR_buf[0], data->G_PTR_buf[1], data->G_PTR_buf[2]);
#ifdef TEST
			   for (i=3; i < 43; i++){
                   printf("0x%x ", data->G_PTR_buf[i]);
			   }
#endif
               memcpy(mem_buf,  &data->G_PTR_buf[0], 43); 
               printf("\n");

         break;
         case TC_FREQGET:
              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcDbgMsg>Obtained COUNTRY SETTINGS Info.");
               printf("COUNTRY SETTINGS  INFO\n");
               printf("\n");
               printf("Frequency Tx: 0x%x\n",data->G_PTR_buf[21]);
               vxBMCPrams.ucGENMUTCTRL0 = data->G_PTR_buf[21];

               printf("Frequency Rx: 0x%x\n",data->G_PTR_buf[22]);
               vxBMCPrams.ucGENMUTCTRL1 = data->G_PTR_buf[22];

               printf("Frequency Range: 0x%x\n",data->G_PTR_buf[23]);
               vxBMCPrams.ucEXTMUTCTRL0 = data->G_PTR_buf[23];
               printf("\n");
         break;

     default : 
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcDbgMsg>Invalid test case in TestAppPrcDbgMsg.IFX_FAILURE returned.");
			return IFX_FAILURE;
         break;

		 
   }
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppPrcDbgMsg>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
   
} 
/******************************************************************
 *  Function Name    : 
 *  Description      : 
 *  Input Values     : 
 *                   : 
 *                   : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/

void TestAppInitMac(HMAC_QUEUES* data)
{

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppInitMac>Entry.");
   /* from LMAC initial command */
   printf("###### Tool Init ### Proc: %d %d\n",  data->PROCID, data->MSG);
   
   /* set hmac status init */
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppInitMac>Invoking TestAppWriteToHmac with MAC_INIT_CMD Msg");
   TestAppWriteToHmac(HMAC, MAC_INIT_CMD ,0, 0, 0, 0 ,0, 0, 0, 0);

   /* Download Parameters */
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppInitMac>######## Downloading COSIC Modem Parameters ########");

   
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppInitMac>Invoking TestAppParamInit.");
   TestAppParamInit();

}
/******************************************************************
 *  Function Name    : 
 *  Description      : 
 *  Input Values     : 
 *                   : 
 *                   : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/

void TestAppParamInit ()
{

   FPTR malloc_temp=NULL;
   BYTE     Freq_Run = 0x09;
   BYTE     Freq_TX_Offset = 0;  
   BYTE     Freq_RX_Offset = 0; 

   int32 i = 0;
   /* changing as per new mail from JN */
   malloc_temp = (unsigned char *)malloc(18);
   if(malloc_temp == NULL)
   	{
   	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>malloc failed");
   		return;
   	}
   memset((FPTR)malloc_temp, 0, 18);

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Entry");
   
   if (ucBmcParamSet != TRUE){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking SetBmcDef");
      SetBmcDef(); 
   } 
 
   if (ucFreqParamSet != TRUE){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking SetFreqDef");
      SetFreqDef(); 
   } 

   if (ucOscParamSet != TRUE){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking SetOscDef");
      SetOscDef(); 
   }

   if (ucGfskParamSet != TRUE){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking SetGfskDef");
      SetGfskDef(); 
   }

   if (ucRFPIParamSet !=TRUE){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking SetRFPIDef1");
      SetRFPIDef1();
   }

   if(ucTPCParamSet != TRUE){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking SetTPCDef");
     SetTPCDef();
   }
	 
#ifdef TEST
   for(i=0;i<10;i++){
     printf("\nxram_tpc_buf[%d]=%x\n",i,xram_tpc_buf[i]);   
   }
   for(i=0;i<10;i++){
     printf("\nxram_tpc_buf1[%d]=%x\n",i,xram_tpc_buf1[i]);   
   }
   for(i=0;i<10;i++){
     printf("\nxram_tpc_buf2[%d]=%x\n",i,xram_tpc_buf2[i]);   
   }
#endif

  
#ifdef TEST
   for(i=0;i<20;i++){
     printf("\nmem_buf[%d]=%x\n",i,mem_buf[i]);   
   }
#endif
   Freq_TX_Offset = vxBMCPrams.ucGENMUTCTRL0;
   Freq_RX_Offset = vxBMCPrams.ucGENMUTCTRL1;
   Freq_Run = vxBMCPrams.ucEXTMUTCTRL0 & 0x7F;
   /* the MAC is requested to forward boot request to LMAC */
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking TestAppWriteToHmac with MAC_BOOT_RQ_ME.");
   TestAppWriteToHmac(HMAC, MAC_BOOT_RQ_ME, Freq_TX_Offset, Freq_RX_Offset, 
         Freq_Run, 0, 0, 0, 0, 0 );

   printf("\n");
   printf( "TX_Offset:%02X, RX_Offset:%02X, Freq:%02X \r\n",
         Freq_TX_Offset, Freq_RX_Offset, Freq_Run );
   printf("\n");
	 memcpy(&malloc_temp[0],&vxBMCPrams,10);
   
   printf( "BMC Parameters : \n");
   printf( "RSSI Free Level: %02X\n", malloc_temp[0]);
   printf( "RSSI Busy Level: %02X\n", malloc_temp[1]);
   printf( "RSSI DB Change Limit: %02X\n", malloc_temp[2]);
   printf( "Default Antenna: %02X\n", malloc_temp[3]);
   printf( "Window Open Sync Free Mode: %02X\n", malloc_temp[4]);
   printf( "Window Width Sync Free Mode: %02X\n", malloc_temp[5]);
   printf( "Control Reg. for DRON: %02X\n", malloc_temp[6]);
   printf( "Delay Compensation: %02X\n", malloc_temp[7]);
   printf( "Handover Evaluation Period: %02X\n", malloc_temp[8]);
   printf( "General Sync Mode Setting: %02X \r\n", malloc_temp[9]);

   printf( "NTP Parameters : \n");
   printf("\n");
   printf( "Direct Biasing to PA1: %02X\n",vxBMCPrams.ucReserved_0);
   printf( "Direct Biasing to PA2: %02X\n",vxBMCPrams.ucReserved_1);
   printf( "Internal Power Amplifier Mode: %02X\n",vxBMCPrams.ucReserved_2);
   printf( "Power Amplifier OffsetControl: %02X \r\n",vxBMCPrams.ucReserved_3);
   printf("\n");

   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking TestAppWriteToHmac with MAC_PARAMETER_PRELOAD_RQ_ME.");
   TestAppWriteToHmac(HMAC, MAC_PARAMETER_PRELOAD_RQ_ME,
         vxBMCPrams.ucReserved_0, vxBMCPrams.ucReserved_1,
         vxBMCPrams.ucReserved_2, vxBMCPrams.ucReserved_3,
         0, 10, malloc_temp, 0 );
		 
   printf( "Oscillator Trim Parameters\n");
   printf("\n");
   printf( "Osc Trim High Value:%02X Osc Trim Low Value:%02X \r\n", vucOsc_Trim_H, vucOsc_Trim_L);
   printf("\n");
   printf( "GFSK Parameters\n");
   printf("\n");
   printf( "GFSK Value:%02X  \r\n", vunGFSK_Value);
   printf("\n");

   /* the MAC is requested to forward boot request to LMAC */
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking TestAppWriteToHmac with MAC_OSC_SET_RQ_ME.");
   TestAppWriteToHmac(HMAC, MAC_OSC_SET_RQ_ME, vucOsc_Trim_H, vucOsc_Trim_L, 0, 
                                   0, 0, 0, 0, 0 );
 
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking TestAppWriteToHmac with MAC_GFSK_SET_RQ_ME.");
   TestAppWriteToHmac(HMAC, MAC_GFSK_SET_RQ_ME,
         (BYTE)(vunGFSK_Value & 0x00FF), (BYTE)((vunGFSK_Value >> 8) & 0x00FF), 0, 0,
         0, 0, 0, 0 );

  
   /* MAC_Test_Mode1 = FALSE; */
   /* In CTR6-Test the RFPI is         */
   /* 0x 00 00 00 00 00                */
   if ( MAC_Test_Mode1 == TRUE )
   {
      memset( (FPTR) vauCMRfpi, 0x00, 5 );
      /* In TBR6-Test the RFPI is         */
      /* 0x 00 00 00 00 08                */
      vauCMRfpi[4] = 0x08;
   }else{
     memcpy((FPTR) vauCMRfpi,(FPTR) vauRfpi,5);
	}
   /* the MAC is requested to send a   */
   /* dummy bearer                     */

   printf("RFPI: 0x%x 0x%x 0x%x 0x%x 0x%x\n", vauCMRfpi[0], vauCMRfpi[1], vauCMRfpi[2], vauCMRfpi[3], vauCMRfpi[4]);
      
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking TestAppWriteToHmac with MAC_SEND_DUMMY_RQ_ME.");
   TestAppWriteToHmac(HMAC, MAC_SEND_DUMMY_RQ_ME
         ,0, 0, 0, 0
         ,0, 5, vauCMRfpi, 0);
 
   if ( MAC_Test_Mode1 == TRUE ){

   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking TestAppWriteToHmac with MAC_TBR6_MODE_RQ_ME.");
      TestAppWriteToHmac(HMAC, MAC_TBR6_MODE_RQ_ME
            ,TRUE, 0, 0, 0
            ,0, 0, 0, 0);
   }
  sleep(2);

     Mem_length =14;
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking TestAppWriteDebug for address 0X1DF6.");
     TestAppWriteDebug(MEMORY_INFOMATION, 1, xram_tpc_buf1);
	 
	 usleep(2000);
	 
     Mem_length =7;
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking TestAppWriteDebug for address 0X04F7.");
     TestAppWriteDebug(MEMORY_INFOMATION, 1, xram_tpc_buf);

   usleep(2000);

     Mem_length =1;
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppParamInit>Invoking TestAppWriteDebug for address 0X01F9.");
     TestAppWriteDebug(MEMORY_INFOMATION, 1, xram_tpc_buf2);

}


e_IFX_Return IFX_DECT_DIAG_ModemDiagnostics_tmp(IN uchar8 ucFlag){
  x_IFX_DECT_IPC_Msg xIpcMsg={0};
  if(ucFlag){
     xIpcMsg.ucMsgId = IFX_DECT_DIAGMODE;
  }else{
     xIpcMsg.ucMsgId = IFX_DECT_NODIAGMODE;
  }
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg); 
  return IFX_SUCCESS;
}


/*! \brief  This function is used to put the modem in the diagnostic operation mode.
                    This function needs to be called by the FT application before other
                    diagnostics functions are invoked.  This diagnostic mode is more relevant
                    for the DECT TK than the modem.  In the diagnostic mode, the DECT TK 
                    disables operations involving other service units.  The function needs to
                    called with a disable value to put the DECT TK in the normal operation
                    mode.
        \param[in] ucFlag Flag to enable/disable diagnostic mode.  
                           One of IFX_DECT_DIAG_DISABLE/IFX_DECT_DIAG_ENABLE
        \return IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_DIAG_ModemDiagnostics(IN uchar8 ucFlag)
{
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Entry.");
	if(ucFlag == IFX_DECT_DIAG_ENABLE){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Enable Diagnostics Mode.");
		if(viDiagMode){
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Already in Diagnostic mode .. so returning.IFX_FAILURE returned.");
			return IFX_FAILURE;
		}
	  viDiagMode =1;
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>viDiagMode ", viDiagMode);
	  vucDownloadBmcOnBootInd =0;
	  
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Invoking FlushOldPackets.");
	  FlushOldPackets();
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Invoking SetRFPIDef1.");
    SetRFPIDef1();
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Invoking SetGfskDef.");
	  SetGfskDef();
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Invoking SetOscDef.");
	  SetOscDef();
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Invoking SetBmcDef.");
	  SetBmcDef();
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Invoking SetFreqDef.");
	  SetFreqDef();
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Invoking SetTPCDef.");
    SetTPCDef();
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Invoking IFX_DECT_DIAG_ModemRestart.");
      IFX_DECT_DIAG_ModemRestart();
	 }else{
  
    uchar8 *pcTemp = NULL;
    int32 i = 0; 

		if(viDiagMode==0){
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      " <API IFX_DECT_DIAG_ModemDiagnostics>Already in NON-Diagnostic mode .. so returning.IFX_FAILURE returned.");
			return IFX_FAILURE;
		}

    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Copying Calibrated values to Stack Global Var.");
   
    memcpy(Tpc_Param_Buf,&xram_tpc_buf[3],7);
    memcpy(Tpc_Param_Buf1,&xram_tpc_buf1[3],14);
    memcpy(Tpc_Param_Buf2,&xram_tpc_buf2[3],1);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             " <API IFX_DECT_DIAG_ModemDiagnostics>Copied TPC Params to Stack.");

    memcpy(&Bmc_Rssi_Settings,&vxBMCPrams,sizeof(vxBMCPrams));
    Bmc_Rssi_Settings.ucEXTMUTCTRL0 |= 0x80;//TODO
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             " <API IFX_DECT_DIAG_ModemDiagnostics>Copied BMC and Freq Offset Params to Stack.");
      
    Osc_Trim_H = vucOsc_Trim_H;
    Osc_Trim_L = vucOsc_Trim_L;
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             " <API IFX_DECT_DIAG_ModemDiagnostics>Copied OSC Trim Values to Stack.");

    GFSK_Value = vunGFSK_Value;
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             " <API IFX_DECT_DIAG_ModemDiagnostics>Copied GFSK Values to Stack.");

    pcTemp = Get_Rfpi_Ptr();
    for (i=0; i<5; i++){

       pcTemp[i]=vauRfpi[i];
    }
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             " <API IFX_DECT_DIAG_ModemDiagnostics>Copied RFPI Values to Stack.");
    
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Disable Diagnostics Mode!!");
	   
	   viDiagMode = 0; 
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>viDiagMode ",viDiagMode);
	   vucDownloadBmcOnBootInd =1;

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>Invoking TestAppWriteToHmac.");
	   TestAppWriteToHmac(HMAC, MAC_SOFT_RESET_RQ_LMAC
         ,0, 0, 0, 0
         ,0, 0, 0, 0);
	   	 
	 }
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_ModemDiagnostics>IFX_SUCCESS returned.");
	return IFX_SUCCESS;
}


/*! \brief  This function is used to reset the cosic modem and download the BMC, RFPI
                    TBR6 Mode, Oscillator trimming and DECT country settings when the modem
                    restarts.  Often this is the first step in the modem diagnostic procedure.
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_ModemRestart(void)
{
 uiTC = TC_RESET;
 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
 TestAppWriteToHmac(HMAC, MAC_SOFT_RESET_RQ_LMAC
         ,0, 0, 0, 0
         ,0, 0, 0, 0);
 if(viDiagMode  == 1){
   IFX_DECT_DIAG_TestAppSelectRead();
  }
 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"SUCCESS returned.");

 return IFX_SUCCESS;
}

/*! \brief  This function is used to reset the cosic modem and download the BMC, RFPI
                    TBR6 Mode, Oscillator trimming and DECT country settings when the modem
                    restarts.  Often this is the first step in the modem diagnostic procedure.
        \return IFX_SUCCESS / IFX_FAILURE
*/
extern unsigned char vucDownloadBmcOnBootInd;

e_IFX_Return IFX_DECT_DIAG_RfCtrl(void)
{
#if 0 
 static uchar8 i;
 i=vxGlobalInfo.xStackCfg.bRfEnable;
 printf("Calling ioctl with value %d\n",i);
#endif
 if(vxGlobalInfo.xStackCfg.bRfEnable)
 {
	 vucDownloadBmcOnBootInd=1;
 }
 else
 {
		 vucDownloadBmcOnBootInd=0;
 }
 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
 TestAppWriteToHmac(HMAC, MAC_SOFT_RESET_RQ_LMAC
         ,0, 0, 0, 0
         ,0, 0, 0, 0);
// ioctl(dect_drv_fd,DECT_DRV_IRQ_CTRL, &i);

 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"SUCCESS returned.");

 return IFX_SUCCESS;
}


 /* ****************************************************************************
 * Set Functions
 * ****************************************************************************/

/*! \brief  This function is used to set the RFPI value at the modem.  The supplied
                   value is cached within the DECT TK and applied when the modem restarts.
                   The IFX_DECT_DIAG_ModemRestart function needs to be called 
                   subsequently by the FT application to apply the values.
        \param[in] pcRFPI RFPI string of 6 bytes.  
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_RFPISet(IN char8 * pcRFPI)
{
  char * rfpi_ptr;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RFPISet>Entry.");
#if 0
	if(viDiagMode ==0){
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RFPISet>Diagnostic Mode is disabled.Data  is cached into stack.");
     if(pcRFPI != NULL){
        char *pcTemp = ((char8 *)Get_Rfpi_Ptr());
        memcpy(pcTemp,pcRFPI,5);
     }
		 return IFX_FAILURE;
	}
#endif

	if(isDiagOnGoing){
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RFPISet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
   ucRFPIParamSet = TRUE;
      

   /* Set RFPI  */
   if(pcRFPI != NULL){
     memcpy(vauRfpi,pcRFPI,5);
	 /*update Stack buffer; so that when COSIC reboots the new RFPI is given to modem*/
	 rfpi_ptr = ((char8 *)Get_Rfpi_Ptr());
        memcpy(rfpi_ptr,pcRFPI,5);
   }else{
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RFPISet>pcRFPI pointer is NULL.IFX_FAILURE returned.");
	   return IFX_FAILURE;
   }
   printf("RFPI: 0x%x 0x%x 0x%x 0x%x 0x%x\n",
	   vauRfpi[0], vauRfpi[1], vauRfpi[2], vauRfpi[3], vauRfpi[4]);
     	 

    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RFPISet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
}

/*! \brief  This function is used to set the Frequency Offset values at the modem.  
                   The frequency offset values determine the DECT Country settings.
                   The supplied values are cached within the DECT TK and 
                   applied when the modem restarts. The IFX_DECT_DIAG_ModemRestart 
                   function needs to be called subsequently by the FT application to apply
                   the values.
        \param[in] ucOffset1 Frequency Offset 1
        \param[in] ucOffset2 Frequency Offset 2
        \param[in] ucOffset3 Frequency Offset 3
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_FreqOffSet(IN uchar8 ucFreqTx,
                                      IN uchar8 ucFreqRx,
                                      IN uchar8 ucFreqRange)
{
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_FreqOffSet>Entry.");
	if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_FreqOffSet>Diagnostic Mode is disabled. data is cached into stack.");
   Bmc_Rssi_Settings.ucGENMUTCTRL0     = ucFreqTx; //goes
   Bmc_Rssi_Settings.ucGENMUTCTRL1     = ucFreqRx; //goes
   Bmc_Rssi_Settings.ucEXTMUTCTRL0     = ucFreqRange|0x80; //goes
		return IFX_FAILURE;
	}
	if(isDiagOnGoing){
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_FreqOffSet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
   ucFreqParamSet = TRUE;
   vxBMCPrams.ucGENMUTCTRL0     = ucFreqTx; //goes
   vxBMCPrams.ucGENMUTCTRL1     = ucFreqRx; //goes
   vxBMCPrams.ucEXTMUTCTRL0     = ucFreqRange|0x80; //goes
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_FreqOffSet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
}

/*! \brief  This function is used to set the BMC values at the modem.  
                   The supplied value is cached within the DECT TK and 
                   applied when the modem restarts. The IFX_DECT_DIAG_ModemRestart 
                   function needs to be called subsequently by the FT application to apply
                   the values.
        \param[in] pxBMC BMC Parameters
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_BmcSet(IN x_IFX_DECT_BMCRegParams * pxBMC)
{
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_BmcSet>Entry.");
	if(pxBMC == NULL){
		//printf("Null pointer passed in %s\n",__FUNCTION__);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_BmcSet>pxBMC pointer is NULL.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
	if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_BmcSet>Diagnostic Mode is disabled. Data cached into stack.");
    memcpy(&Bmc_Rssi_Settings,pxBMC,14);
		return IFX_FAILURE;
	}
	if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_BmcSet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
	 ucBmcParamSet = TRUE;
 
    /* BMC parameters */

   //vxBMCPrams.ucPLLSettleTime= xram_tpc_buf2[3]; //Tx Bias
   //vxBMCPrams.ucGaussianEnable= xram_tpc_buf1[9];//SW Power Mode 
   memcpy(&vxBMCPrams,pxBMC,14);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_BmcSet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
}
          

/*! \brief  This function is used to put the modem in the TBR06 testing mode.
                    This function sets the activation/deactivation value within the toolkit.
                    The IFX_DECT_DIAG_ModemRestart function needs to be called
                    subsequently by the FT application is put the modem in the TBR 06 test
                    mode.
        \param[in] ucFlag Flag to activate/deactivate TBR 06 Test mode.  
                           One of IFX_DECT_DIAG_TBR06_ACTIVATE/IFX_DECT_DIAG_TBR06_DEACTIVATE
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_TBR06Mode(IN uchar8 ucFlag)
{
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TBR06Mode>Entry.");
	if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TBR06Mode>Diagnostic Mode is disabled.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
	if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TBR06Mode>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
	uiTC = TC_TBR6;
    if(MAC_Test_Mode1)    //  test mode ?
      {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TBR06Mode>MAC_Test_Mode1 is TRUE.");
         if(!ucFlag)      // if TBR6 mode off
         {
           IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TBR06Mode>ucFlag is 0.Turn off TBR06 Mode.");
            MAC_Test_Mode1 = FALSE;
           IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TBR06Mode>Invoking TestAppWriteToHmac with MAC_SOFT_RESET_RQ_LMAC.");
            TestAppWriteToHmac(HMAC, MAC_SOFT_RESET_RQ_LMAC
                    ,0, 0, 0, 0
                    ,0, 0, 0, 0);
         }
      }
      else
      {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TBR06Mode>MAC_Test_Mode1 is FALSE.");
         if(ucFlag)    //  if  TBR6 mode on
         {
           IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TBR06Mode>ucFlag is 1.Turn on TBR06 Mode.");
            MAC_Test_Mode1 = TRUE;
           IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TBR06Mode>Invoking TestAppWriteToHmac with MAC_SOFT_RESET_RQ_LMAC.");
            TestAppWriteToHmac(HMAC, MAC_SOFT_RESET_RQ_LMAC
                    ,0, 0, 0, 0
                    ,0, 0, 0, 0);
         }
      }
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TBR06Mode>Invoking TestAppSelectRead.");
    IFX_DECT_DIAG_TestAppSelectRead();
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TBR06Mode>IFX_SUCCESS returned.");
	return IFX_SUCCESS;
}

void TestAppWriteDebug(unsigned char ucDbgInfoId, unsigned char operation, 
                        FPTR  G_PTR)
{
 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppWriteDebug>Entry.");

if( (ucDbgInfoId == BMC_REGISTER_READ_REQ) && (operation == 1) )
      {
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppWriteDebug>DbgInfoId is BMC_REGISTER_READ_REQ and operation is Write.");
         int cur_index = 0;
         //int osc_trim_flag = 0;
         //int osc_index = 0;
         while( cur_index < 40 )
         {
            switch( G_PTR[ cur_index ] )
            {
               case  BMC_REGISTER:
                     cur_index += 15;
                     break;

               case  OSC_TRIMMING_VAL:
                     //osc_trim_flag = 1;
                     //osc_index = cur_index;

               case  GFSK_VALUE:
                     cur_index += 3;
                     break;

               case  RF_TEST_MODE_SET:
               case  SPI_SETUP_PACKET:
                     cur_index += 4;
                     break;

               case  DEBUG_MESSAGE_ONOFF:
                     cur_index += 2;
                     break;

               default:
                     cur_index++;
                     break;
            }
         }
         
      }
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppWriteDebug>Invoking TestAppWriteDebugInfo.");
      TestAppWriteDebugInfo( ucDbgInfoId, operation, 1, G_PTR );

} /* TestAppWriteDebug */
 
void TestAppWriteDebugInfo(BYTE info_id, BYTE rw_indicator, BYTE inc, FPTR pdata)
{              
   DECT_MODULE_DEBUG_INFO send_data;
   int ret=0;
      
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppWriteDebugInfo>Entry.");
   memset(&send_data, 0x00, sizeof(DECT_MODULE_DEBUG_INFO));
   
   send_data.debug_info_id = info_id;
   send_data.rw_indicator = rw_indicator;
   if(info_id == MEMORY_INFOMATION){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API TestAppWriteDebugInfo>DbgInfoId is MEMORY_INFORMATION.");
     send_data.CurrentInc = Mem_length;
   }else{
     send_data.CurrentInc = inc;
   }
   if (pdata != NULL)
   {
      memcpy(send_data.G_PTR_buf, pdata, G_PTR_MAX_DEBUG_COUNT);
      if((pdata != mem_buf)&&(pdata != xram_tpc_buf)&&(pdata != xram_tpc_buf1)&&(pdata!=xram_tpc_buf2)){
         free(pdata);
	  }
   }
   ret = ioctl(dect_drv_fd,DECT_DRV_DEBUG_INFO, &send_data);
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API TestAppWriteDebugInfo>ioctl returned ",ret);
#ifdef TOOL_DBG
   printf("Debug Packet sent to modem, Status %d\n",ret);   
#endif

}

/*! \brief  This function is used to set the TPC values at the modem.  
            The supplied value is cached within the DECT TK and 
            applied when the modem restarts. The IFX_DECT_DIAG_ModemRestart 
            function needs to be called subsequently by the FT application to apply
            the values.
     \param[in] pxTPCParams TPC Parameters
     \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_TPCSet(IN x_IFX_DECT_TransmitPowerParam *pxTPCParams)
{
   uint16 unAddr = 0x04F7;
   uint16 unAddr1 = 0x1DF6;
   uint16 unAddr2 = 0X01F9;
   int32 i=0;
   
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCSet>Entry.");
   //if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCSet>Diagnostic Mode is disabled.Data cached into stack.");
     memcpy(Tpc_Param_Buf,pxTPCParams,7);         
     /*To remove clokworks warning*/
	 #ifdef KLOCWORK
     memcpy(Tpc_Param_Buf1,(((uchar8 *)pxTPCParams)+7),14);   
	 #else
	 memcpy(Tpc_Param_Buf1,&pxTPCParams->ucTD1,14);    
	 #endif
     memcpy(Tpc_Param_Buf2,&pxTPCParams->ucTxBias,1);    
		 //return IFX_FAILURE;
   //}
   /*if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCSet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
   }*/
   
   memset(xram_tpc_buf, 0, 43);
   memset(xram_tpc_buf1, 0, 43);
   memset(xram_tpc_buf2, 0, 43);

   xram_tpc_buf[0] = 0x01; // xram
   xram_tpc_buf[1] = (unAddr & 0xff00) >> 8;
   xram_tpc_buf[2] = (unAddr & 0x00ff);
   
   xram_tpc_buf1[0] = 0x01; // xram
   xram_tpc_buf1[1] = (unAddr1 & 0xff00) >> 8;
   xram_tpc_buf1[2] = (unAddr1 & 0x00ff);
  
   xram_tpc_buf2[0] = 0x01; // xram
   xram_tpc_buf2[1] = (unAddr2 & 0xff00) >> 8;
   xram_tpc_buf2[2] = (unAddr2 & 0x00ff);

   ucTPCParamSet = TRUE;
   
   memcpy(&xram_tpc_buf[3],pxTPCParams,7);   
   /*To remove clokworks warning*/
   #ifdef KLOCWORK
   memcpy(&xram_tpc_buf1[3],(((uchar8 *)pxTPCParams)+7),14); 
   #else
    memcpy(&xram_tpc_buf1[3],&pxTPCParams->ucTD1,14);    
   #endif
   memcpy(&xram_tpc_buf2[3],&pxTPCParams->ucTxBias,1);    

#ifdef TEST   
   printf("<IFX_DECT_DIAG_TPCSet>Printing xram_tpc_buf");
   for(i=0;i<10;i++){

    printf("\nxram_tpc_buf[%d]=%x\n",i,xram_tpc_buf[i]);
   }
   printf("<IFX_DECT_DIAG_TPCSet>Printing xram_tpc_buf1");
   for(i=0;i<10;i++){

    printf("\nxram_tpc_buf1[%d]=%x\n",i,xram_tpc_buf1[i]);
   }
   for(i=0;i<10;i++){

    printf("\nxram_tpc_buf1[%d]=%x\n",i,xram_tpc_buf2[i]);
   }
#endif
     Mem_length =14;
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_TPCSet>Invoking TestAppWriteDebug for address ",unAddr);
     TestAppWriteDebug(MEMORY_INFOMATION, 1, xram_tpc_buf1);

   usleep(2000);

     Mem_length =7;
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_TPCSet>Invoking TestAppWriteDebug for address ",unAddr1);
     TestAppWriteDebug(MEMORY_INFOMATION, 1, xram_tpc_buf);

   usleep(2000);

     Mem_length =1;
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_TPCSet>Invoking TestAppWriteDebug for address ",unAddr2);
     TestAppWriteDebug(MEMORY_INFOMATION, 1, xram_tpc_buf2);
    
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCSet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
}

/*! \brief  This function is used to set the XRAM/SFR values at the modem.  The
                   XRAM/SFR values are sent to the modem immediately.  
        \param[in] uiAddr XRAM/SFR Address
        \param[in] ucBufferOffset Offset from the start of the XRAM/SFR Address
        \param[in] pcBuffer Buffer of 10 bytes
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_MEMSet( IN uchar8 ucMemType,
                                   IN uint16 uiAddr,
                                   IN char8 * pcBuffer,
								                   IN uchar8 ucLength_Maccess)
{
   
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_MEMSet>Entry.");
   /*if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_MEMSet>Diagnostic Mode is disabled.IFX_FAILURE returned.");
		return IFX_FAILURE;
   }
   if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_MEMSet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
   }*/
   if(ucLength_Maccess >40){
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
     " <API IFX_DECT_DIAG_MEMSet>Length of contents to write exceeds max allowed bytes(40 bytes).IFX_FAILURE returned.");
	 return IFX_FAILURE;
   }

   ucMEMSet = TRUE;
   
   mem_buf[0] = ucMemType; // xram = 0x01, sfr = 0x00
   mem_buf[1] = (uiAddr & 0xff00) >> 8;
   mem_buf[2] = (uiAddr & 0x00ff);

   memcpy(&mem_buf[3],pcBuffer,ucLength_Maccess);         
   Mem_length =ucLength_Maccess;
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_MEMSet>Invoking TestAppWriteDebug for address ",uiAddr);
   TestAppWriteDebug(MEMORY_INFOMATION, 1, mem_buf);
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_MEMSet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
}
                                         
/*! \brief  This function is used to set the Oscillator Trimming values at the modem.  
            In addition this function is also used to turn on/off the oscillator trimming
            mode at the modem.  The Oscillator trimming values are sent to the modem
            immediately.
     \param[in] uiOscTrimValue Oscillator Trimming Value containing both Hi and Low Bytes
     \param[in] ucP10Status Status of the P1.0 GPIO PIN.
                            One of IFX_DECT_DIAG_P10_OFF / IFX_DECT_DIAG_P10_ON
     \return IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_DIAG_OscTrimSet(IN uint16 uiOscTrimValue,
                                      IN uchar8 ucP10Status)
{
 #if 0 
  unsigned char ucDbgInfoId = BMC_REGISTER_READ_REQ;
 #endif 
  FPTR G_PTR;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_OscTrimSet>Entry.");
  //if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_OscTrimSet>Diagnostic Mode is disabled.Data cached into stack.");
   Osc_Trim_H = (uiOscTrimValue&0xFF00)>>8;
   Osc_Trim_L =  (uiOscTrimValue&0x00FF);
	 //return IFX_FAILURE;
  //}
  /*if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_OscTrimSet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
  }*/

   G_PTR = malloc(43);
	 if (G_PTR == NULL)
	 	return IFX_FAILURE;
	 
   memset(G_PTR, 0, 43);

   ucOscParamSet = TRUE;

   G_PTR[0] = OSC_TRIMMING_VAL;
   G_PTR[1] = (uiOscTrimValue&0xFF00)>>8;  // 2 bytes data
   G_PTR[2] = (uiOscTrimValue&0x00FF);

   /* What is the handling for the P10 field ?? 
    * Should we simply set the Status or operate
    * through the driver for the GPIO ON/OFF
   */
   G_PTR[4] = ucP10Status;

   vucOsc_Trim_H = G_PTR[1];
   vucOsc_Trim_L= G_PTR[2];
  
   TestAppWriteToHmac(HMAC, MAC_OSC_SET_RQ_ME, vucOsc_Trim_H, vucOsc_Trim_L, 0,
                                   0, 0, 0, 0, 0 );

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_OscTrimSet>Invoking TestAppWriteDebug.");
#if 0
   TestAppWriteDebug(ucDbgInfoId, 1, G_PTR); 
#else
	free(G_PTR);// this ptr is freed in TestAppWriteDebug, since its not called freeing fere
#endif
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_OscTrimSet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
}

/*! \brief  This function is used to set the GFSK values at the modem.  The GFSK
            values are sent to the modem immediately.
    \param[in] unGfskValue GFSK Value containing both Hi and Low Bytes.
    \return IFX_SUCCESS / IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_DIAG_GfskSet(IN uint16 unGfskValue)
{
    
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_GfskSet>Entry.");
	//if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_GfskSet>Diagnostic Mode is disabled.Data cached into stack.");
   GFSK_Value = unGfskValue;  /* 0xaf */
		//return IFX_FAILURE;
	//}
	/*if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_GfskSet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}*/
 
#ifdef MAC_CMD   

	ucGfskParamSet = TRUE;

    /* default GFSK parameters  */
    vunGFSK_Value= unGfskValue;  /* 0xaf */
#else

   unsigned char ucDbgInfoId = BMC_REGISTER_READ_REQ;//
   FPTR G_PTR;

   G_PTR = malloc(43);
   if (G_PTR == NULL)
	 	return IFX_FAILURE;
   
   memset(G_PTR, 0, 43);

   ucGfskParamSet = TRUE;

   G_PTR[0] = GFSK_VALUE;
   G_PTR[1] = (unGfskValue & 0x00FF);//2 bytes data
   G_PTR[2] = (unGfskValue & 0xFF00)>>8; 

    /* default GFSK parameters  */
   vunGFSK_Value= unGfskValue;  /* 0xaf */

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_GfskSet>Invoking TestAppWriteDebug.");
    TestAppWriteDebug(ucDbgInfoId, 1, G_PTR);

#endif
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_GfskSet>IFX_SUCCESS returned.");
	return IFX_SUCCESS;
}
                   
/*! \brief  This function is used to set the RF Test Mode values at the modem.  
            The RF Test Mode values are sent to the modem immediately.
    \param[in] ucRFMode RF Test Mode.
    \param[in] ucChannelNumber Channel Number.
    \param[in] ucSlotNumber Slot Number.
    \return IFX_SUCCESS / IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DIAG_RfTestModeSet(IN uchar8 ucRFMode,
                                         IN uchar8 ucChannelNumber,
                                         IN uchar8 ucSlotNumber)
{
  unsigned char ucDbgInfoId = BMC_REGISTER_READ_REQ;
  FPTR G_PTR;
  
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RfTestModeSet>Entry.");
	if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RfTestModeSet>Diagnostic Mode is disabled.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
	if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RfTestModeSet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
 
   G_PTR = malloc(43);
   if (G_PTR == NULL)
	 	return IFX_FAILURE;
   
   memset(G_PTR, 0, 43);

   G_PTR[0] = RF_TEST_MODE_SET;
 
   G_PTR[1] = ucRFMode; 
   G_PTR[2] = ucChannelNumber; 
   G_PTR[3] = ucSlotNumber; 

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RfTestModeSet>Invoking TestAppWriteDebug.");
  TestAppWriteDebug(ucDbgInfoId, 1, G_PTR);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RfTestModeSet>IFX_SUCCESS returned.");
  return IFX_SUCCESS;
}

/* ****************************************************************************
 * Get Functions
 * ****************************************************************************/

/*! \brief  This function is used to get the BMC values from the modem.  This is a blocking
            function.  This function blocks till the BMC register values are obtained from
            the modem over the SPI interface.
     \param[out] pxBMC BMC Parameters
     \return IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_DIAG_BmcGet(OUT x_IFX_DECT_BMCRegParams * pxBMC)
{
   unsigned char ucDbgInfoId = BMC_REGISTER_READ_REQ;
   FPTR G_PTR;
   
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_BmcGet>Entry.");
	if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_BmcGet>Diagnostic Mode is disabled.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
	if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_BmcGet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
   uiTC = TC_BMC6GET;
 
   G_PTR = malloc(43);
   if (G_PTR == NULL)
	 	return IFX_FAILURE;
   
   memset(G_PTR, 0, 43);
   G_PTR[0] = BMC_REGISTER;

   TestAppWriteDebug(ucDbgInfoId, 0, G_PTR); 
   
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_BmcGet>Invoking TestAppSelectDebug.");
   IFX_DECT_DIAG_TestAppSelectDebug();

   memcpy(pxBMC,&vxBMCPrams,sizeof(x_IFX_DECT_BMCRegParams));
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_BmcGet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
}


/*! \brief  This function is used to get the TPC values from the modem.  This is a blocking
            function.  This function blocks till the TPC values are obtained from
            the modem over the SPI interface.
     \param[out] pxTpc Transmit Power Param Structure.
     \return IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_DIAG_TPCGet(OUT x_IFX_DECT_TransmitPowerParam *pxTpc){

   int32 i=0;
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCGet>Entry.");
   if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCGet>Diagnostic Mode is disabled.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
	if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCGet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCGet>Invoking IFX_DECT_DIAG_MEMGet for address 0x04F7.");
    IFX_DECT_DIAG_MEMGet(1,0X04F7,(char8 *)pxTpc,7);
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCGet>Invoking IFX_DECT_DIAG_MEMGet for address 0x1DF6.");
    IFX_DECT_DIAG_MEMGet(1,0X1DF6,(char8 *)pxTpc+7,14);
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCGet>Invoking IFX_DECT_DIAG_MEMGet for address 0x03FF.");
    IFX_DECT_DIAG_MEMGet(1,0X03FF,(char8 *)pxTpc+21,1);
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCGet>Invoking IFX_DECT_DIAG_MEMGet for address 0x01F9.");
    IFX_DECT_DIAG_MEMGet(1,0X01F9,(char8 *)pxTpc+22,1);
#ifdef TEST
   printf("<IFX_DECT_DIAG_TPCGet>Printing struct pxTpc");

   printf("\nucTuneDigitalRef=%x\n",pxTpc->ucTuneDigitalRef);
   printf("\nucPABiasRef=%x\n",pxTpc->ucPABiasRef);
   for(i=0;i<5;i++){
   printf("\nucPowerOffset[%d]=%x\n",i,pxTpc->ucPowerOffset[i]);
   }

   printf("\nucTD1=%x\n",pxTpc->ucTD1);
   printf("\nucTD2=%x\n",pxTpc->ucTD2);
   printf("\nucTD3=%x\n",pxTpc->ucTD3);

   printf("\nucPA1=%x\n",pxTpc->ucPA1);
   printf("\nucPA2=%x\n",pxTpc->ucPA2);
   printf("\nucPA3=%x\n",pxTpc->ucPA3);
   
   printf("\nucSWPowerMode=%x\n",pxTpc->ucSWPowerMode);

   printf("\nucTXPOW_0=%x\n",pxTpc->ucTXPOW_0);
   printf("\nucTXPOW_1=%x\n",pxTpc->ucTXPOW_1);
   printf("\nucTXPOW_2=%x\n",pxTpc->ucTXPOW_2);
   printf("\nucTXPOW_3=%x\n",pxTpc->ucTXPOW_3);
   printf("\nucTXPOW_4=%x\n",pxTpc->ucTXPOW_4);
   printf("\nucTXPOW_5=%x\n",pxTpc->ucTXPOW_5);
   printf("\nucTXPOW_5=%x\n",pxTpc->ucDBPOW);
   printf("\nucTuneDigital=%x\n",pxTpc->ucTuneDigital);
   printf("\nucTxBias=%x\n",pxTpc->ucTxBias);
#endif
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_TPCGet>IFX_SUCCESS returned.");
	return IFX_SUCCESS; 
}


/*! \brief  This function is used to get the XRAM/SFR values from the modem.  This is a blocking
            function.  This function blocks till the XRAM/SFR values are obtained from
            the modem over the SPI interface.
    \param[in] uiAddr XRAM/SFR Address.
    \param[in] ucLength_Maccess Number of bytes to be read,starting from uiAddr.
    \param[out] pcBuffer Buffer of 10 bytes.
    \return IFX_SUCCESS / IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_DIAG_MEMGet( IN uchar8 ucMemType,
                                   IN uint16 uiAddr,
                                   OUT char8 *pcBuffer,
								   IN uchar8 ucLength_Maccess)
{
   unsigned char ucDbgInfoId = MEMORY_INFOMATION;
   int32 i = 0;
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_MEMGet>Entry.");
   /*if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_MEMGet>Diagnostic Mode is disabled.IFX_FAILURE returned.");
		return IFX_FAILURE;
   }
   if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_MEMGet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
   }*/
   if(ucLength_Maccess >40){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
     " <API IFX_DECT_DIAG_MEMGet>Length of contents exceeds max bytes(40 bytes) allowed to read.IFX_FAILURE returned.");
     printf("Length exceeds max bytes to read\n");
	 return IFX_FAILURE;
   }
   uiTC = TC_MEMGET;
 
   memset(mem_buf, 0, 43);

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_MEMGet>Address to Access ",uiAddr);
   mem_buf[0] = ucMemType; //xram = 0x01, sfr = 0x00
   mem_buf[1] = (uiAddr&0xFF00)>>8;
   mem_buf[2] = uiAddr&0x00FF;
   Mem_length = ucLength_Maccess;   

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_MEMGet>Invoking TestAppWriteDebug.");
   TestAppWriteDebug(ucDbgInfoId, 0, mem_buf); 
   
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_MEMGet>Invoking TestAppSelectDebug.");
   if(viDiagMode ==1){
     IFX_DECT_DIAG_TestAppSelectDebug();
    }
#ifdef TEST
   printf("<IFX_DECT_DIAG_MEMGet>Printing mem_buf");
   for(i=0;i<20;i++){

    printf("\nmem_buf[%d]=%x\n",i,mem_buf[i]);
   }
#endif   
   memcpy(pcBuffer,&mem_buf[3],ucLength_Maccess);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_MEMGet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
   
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//                                       TESTING
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

/*! \brief  This function is used to get the RF Test Mode values from the modem.  
                    This is a blocking function.  This function blocks till the RF Mode
                    values are obtained from the modem over the SPI interface.
        \param[out] ucRFMode RF Test Mode
        \param[out] ucChannelNumber Channel Number
        \param[out] ucSlotNumber Slot Number
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_RfTestModeGet(OUT uchar8 *pucRFMode,
                                         OUT uchar8 *pucChannelNumber,
                                         OUT uchar8 *pucSlotNumber)
{
	unsigned char ucDbgInfoId = BMC_REGISTER_READ_REQ;
   FPTR G_PTR;
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RfTestModeGet>Entry.");
	if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RfTestModeGet>Diagnostic Mode is disabled.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
	if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RfTestModeGet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
   G_PTR = malloc(43);
   if (G_PTR == NULL)
	 	return IFX_FAILURE;
   
   memset(G_PTR, 0, 43);
   uiTC = TC_RFGET;
   G_PTR[0] = RF_TEST_MODE_SET;
 
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RfTestModeGet>Invoking TestAppWriteDebug.");
   TestAppWriteDebug(ucDbgInfoId, 0, G_PTR);
   
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RfTestModeGet>Invoking TestAppSelectDebug.");
   IFX_DECT_DIAG_TestAppSelectDebug();
   
   *pucRFMode=vucRFMode;
   *pucChannelNumber=vucChannelNumber;
   *pucSlotNumber=vucSlotNumber;

    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_RfTestModeGet>RfMode ",vucRFMode);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_RfTestModeGet>Channel Number ",vucChannelNumber);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_RfTestModeGet>Slot Number ",vucSlotNumber);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_RfTestModeGet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
}


/*! \brief  This function is used to get the GFSK values from the modem. This is
            a blocking function. This function blocks till the GFSK values are 
			obtained from the modem over the SPI interface.
    \param[in] unGfskValue GFSK Value containing both Hi and Low Bytes.
    \return IFX_SUCCESS / IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_DIAG_GfskGet(OUT uint16 *punGfskValue)
{
    
   unsigned char ucDbgInfoId = BMC_REGISTER_READ_REQ;//
   FPTR G_PTR;
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_GfskGet>Entry.");
	if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_GfskGet>Diagnostic Mode is disabled.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
	if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_GfskGet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
   
    uiTC = TC_GFSKGET; 
	
    G_PTR = malloc(43);
	if (G_PTR == NULL)
	 	return IFX_FAILURE;
	
    memset(G_PTR, 0, 43);
    G_PTR[0] = GFSK_VALUE;

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_GfskGet>Invoking TestAppWriteDebug.");
   TestAppWriteDebug(ucDbgInfoId, 0, G_PTR); 
   
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_GfskGet>Invoking TestAppSelectDebug.");
   IFX_DECT_DIAG_TestAppSelectDebug();

   *punGfskValue = vunGFSK_Value;
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_GfskGet>Gfsk Value ",vunGFSK_Value);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_GfskGet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
}
                 
				 
/*! \brief  This function is used to get the Osc Trim values from the modem. This is
            a blocking function. This function blocks till the Osc Trim values are 
			obtained from the modem over the SPI interface.
    \param[in] unGfskValue GFSK Value containing both Hi and Low Bytes.
    \return IFX_SUCCESS / IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_DIAG_OscTrimGet(OUT uint16 *punOscTrimValue)
{
    
   unsigned char ucDbgInfoId = BMC_REGISTER_READ_REQ;//
   FPTR G_PTR;
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_OscTrimGet>Entry.");
	if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_OscTrimGet>Diagnostic Mode is disabled.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
	if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_OscTrimGet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
		return IFX_FAILURE;
	}
   
    uiTC = TC_OSCGET; 
	
    G_PTR = malloc(43);
	if (G_PTR == NULL)
	 	return IFX_FAILURE;
	
    memset(G_PTR, 0, 43);
    G_PTR[0] = OSC_TRIMMING_VAL;

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_OscTrimGet>Invoking TestAppWriteDebug.");
   TestAppWriteDebug(ucDbgInfoId, 0, G_PTR); 
   
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_OscTrimGet>Invoking TestAppSelectDebug.");
   IFX_DECT_DIAG_TestAppSelectDebug();

   *punOscTrimValue = vucOsc_Trim_H;
   *punOscTrimValue <<= 8;
   *punOscTrimValue |= vucOsc_Trim_L;
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  " <API IFX_DECT_DIAG_OscTrimGet>Osc Trim Value ",*punOscTrimValue);
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_OscTrimGet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
}


/*! \brief  This function is used to get the Country Settings values from the modem. This is
          a blocking function. This function blocks till the Country Settings values are
          obtained from the modem over the SPI interface.
    \param[in]
    \return IFX_SUCCESS / IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_DIAG_FreqOffGet(OUT uchar8 *pucFreqTx,
                                      OUT uchar8 *pucFreqRx,
                                      OUT uchar8 *pucFreqRan)
{

   unsigned char ucDbgInfoId = BMC_REGISTER_READ_REQ;//
   FPTR G_PTR;

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_FreqOffGet>Entry.");
   if(viDiagMode ==0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_FreqOffGet>Diagnostic Mode is disabled.IFX_FAILURE returned.");
        return IFX_FAILURE;
    }
    if(isDiagOnGoing){
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_FreqOffGet>Diagnostics going on,can't start a new one.IFX_FAILURE returned.");
        return IFX_FAILURE;
    }

    uiTC = TC_FREQGET;

    G_PTR = malloc(43);
	if (G_PTR == NULL)
	 	return IFX_FAILURE;
	
    memset(G_PTR, 0, 43);
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_FreqOffGet>Invoking TestAppWriteDebug.");
   TestAppWriteDebug(ucDbgInfoId, 0, G_PTR);
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_FreqOffGet>Invoking TestAppSelectDebug.");

   IFX_DECT_DIAG_TestAppSelectDebug();

   *pucFreqTx = vxBMCPrams.ucGENMUTCTRL0;
   *pucFreqRx = vxBMCPrams.ucGENMUTCTRL1;
   *pucFreqRan = vxBMCPrams.ucEXTMUTCTRL0;

     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  " <API IFX_DECT_DIAG_FreqOffGet>IFX_SUCCESS returned.");
   return IFX_SUCCESS;
}


