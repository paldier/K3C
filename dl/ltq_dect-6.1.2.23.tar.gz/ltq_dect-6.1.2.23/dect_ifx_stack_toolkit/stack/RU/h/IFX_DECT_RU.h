/**************************************************************************
**   FILE NAME     : IFX_DECT_RU.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 21-03-2016
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Repeater support
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Intel;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_RU.h
    \brief This file contains the DECT Repeater  Unit (RU) 
				Procedures.  The RU is a collection of 
				procedures that provide support registration and exchange of
				subscription data between the FT application and the Repeater
				device.  
*/

/** \ingroup DECT_TOOLKIT_MODULES
       \defgroup REPEATER_MODULE Unit
       \brief The Repeater Unit is a collection of procedures that 
				provide support registration and exchange of subscription data 
			       between the FT application and the Repeater device.  
				
*/
/* @{ */
/* @} */


#ifndef __IFX_DECT_RU_H__
#define __IFX_DECT_RU_H__

#ifdef CONFIG_REPEATER_SUPPORT

#include "IFX_DECT_Stack.h"
#include "IFX_DECT_Repeater.h"




/*! \def IFX_DECT_REPEATERS_OFFSET
    \brief Macro that specifies the offset from where the repeater device numbering starts.
*/
#define IFX_DECT_REPEATERS_OFFSET 224



typedef struct{
	uint16 unMaxRepeaterSupported;	
	uint16 unMaxInstancesPerRepeater;	
	x_IFX_DECT_SubscInfo *pxSubscData;
	x_IFX_DECT_Repeater_CallBks xRepeaterCallBks;		
}IFX_DECT_RU_GlobalData;

e_IFX_Return IFX_DECT_Repeater_ProcessCPlaneMsg(IN x_IFX_DECT_IPC_Msg *pxIpcMsg);



#endif
#endif

