#ifdef CONFIG_REPEATER_SUPPORT
#include <stdio.h>
#include "IFX_DECT_Platform.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_StackIf.h"
#include "IFX_DECT_IEParser.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_Repeater.h"
#include "IFX_DECT_RU.h"

//#define RPT_TEST
uint32 IFX_DBGA_GetStackModuleDebugID(void);

IFX_DECT_RU_GlobalData xRepeater;

void Print_Rpt_Data(void)
{
	 int i,j;
			
	for (i=0;i<6;i++)
	{
		IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT ,"Status =",xRepeater.pxSubscData[i].cstatus);
		for(j=0;j<IFX_DECT_IPUI_SIZE;j++)
		{
			IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT ,"ipui =",
				xRepeater.pxSubscData[i].acipui_array[j]);
		}
		for(j=0;j<IFX_DECT_TPUI_SIZE;j++)
		{
			IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT ,"Tpui =",
				xRepeater.pxSubscData[i].actpui_array[j]);
		}
		for(j=0;j<IFX_DECT_AUTH_KEY_SIZE;j++)
		{
			IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT ,"AuthKey =",
				xRepeater.pxSubscData[i].acuak_array[j]);
		}
		for(j=0;j<IFX_DECT_CIPHER_KEY_SIZE;j++)
		{
			IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT ,"DCK =",
				xRepeater.pxSubscData[i].acdck_array[j]);
		}
							   
	}
		
	return;
}


/*! \brief  This function is used to initialize the Repeater Unit of the
				   DECT Toolkit.  This function shall be invoked by the FT 
				   application after it has received the confirmation from the 
				   Toolkit that the Toolkit and the Stack initialization has been
				   successful.  
        \param[in] unMaxRepeaterSupported  Max repeater devices supported
         \param[in] unMaxInstancesPerRepeater Max instances per repeater device    
        \param[in] pxRepeaterSubscData Pointer to Subscription Data of all registered Repeaters 
        \param[in] pxRepeaterCallBks Pointer to Callback functions structure that are to be registered
        \return IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_Repeater_Init(IN uint16 unMaxRepeaterSupported, 
									IN uint16 unMaxInstancesPerRepeater,
                               IN x_IFX_DECT_SubscInfo *pxRepeaterSubscData,
							   IN x_IFX_DECT_Repeater_CallBks *pxRepeaterCallBks)
{
	e_IFX_Return eRet= IFX_FAILURE;

	/*Validate input parameters*/
	if((unMaxRepeaterSupported <= 0) || (unMaxRepeaterSupported > IFX_DECT_MAX_REPEATERS))
	{
		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR, IFX_DBG_INT, 
                 	"\nIFX_DECT_Repeater_Init:Wrong unMaxRepeaterSupported  = ",unMaxRepeaterSupported);		
	}
	else if((unMaxInstancesPerRepeater <= 0) || (unMaxInstancesPerRepeater > IFX_DECT_MAX_INSTANCES_PER_REPEATERS))
	{
		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR, IFX_DBG_INT, 
                 	"\nIFX_DECT_Repeater_Init:Wrong unMaxInstancesPerRepeater  = ",unMaxInstancesPerRepeater);
	}
	else if(pxRepeaterSubscData == NULL)
	{
		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IFX_DECT_Repeater_Init:pxRepeaterSubscData is NULL!");
	}
	else if(pxRepeaterCallBks == NULL)
	{
		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IFX_DECT_Repeater_Init:pxRepeaterCallBks is NULL!");		
	}
	else
	{	
		xRepeater.unMaxRepeaterSupported = unMaxRepeaterSupported;
		xRepeater.unMaxInstancesPerRepeater = unMaxInstancesPerRepeater;
		xRepeater.pxSubscData = 
		malloc((sizeof(x_IFX_DECT_SubscInfo))*unMaxRepeaterSupported*unMaxInstancesPerRepeater);
		if(xRepeater.pxSubscData !=NULL)
		{
			memcpy(xRepeater.pxSubscData,pxRepeaterSubscData,
			((sizeof(x_IFX_DECT_SubscInfo))*unMaxRepeaterSupported*unMaxInstancesPerRepeater));

			memcpy(&xRepeater.xRepeaterCallBks,pxRepeaterCallBks,(sizeof(x_IFX_DECT_Repeater_CallBks)));
			eRet= IFX_SUCCESS;
			
		}
		else
		{
			IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IFX_DECT_Repeater_Init:malloc failed!");			
		}
	}

	return eRet;		
	
}


EXPORT uint8 * GetRepeaterSubscriptionInfoPtr(uint8 ucRepeaterNo)
{
	/*index to access Repeater table based on repeater number
	Note -ucRepeaterNo is 224,230,236..etc. 
	*/
	int32 iIndex= (ucRepeaterNo % IFX_DECT_REPEATERS_OFFSET);

	if((ucRepeaterNo < IFX_DECT_REPEATERS_OFFSET) || 
	(ucRepeaterNo > (IFX_DECT_REPEATERS_OFFSET + (IFX_DECT_MAX_REPEATERS*IFX_DECT_MAX_INSTANCES_PER_REPEATERS))))
	{
	 	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT ,
		               "Invalid Repeater instance number !!!!!!",ucRepeaterNo);
	}
	else if(xRepeater.pxSubscData  == NULL)
	{
		IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR ,
		               "Repeater NOT INITED !!!!!!");		
	}
	else
	{
   	return ((uint8 *)&xRepeater.pxSubscData[iIndex]);
	}
	return NULL;
}

e_IFX_Return IFX_DECT_Repeater_ProcessCPlaneMsg(IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{	  		
	/*pxIpcMsg->ucPara1 is 224,230,236 etc*/
	uchar8 ucInstanceId=pxIpcMsg->ucPara1;	
	e_IFX_Return eRet=IFX_FAILURE;
	x_IFX_DECT_Repeater_NotifyEvent xNotify;

	if((ucInstanceId < IFX_DECT_REPEATERS_OFFSET) || 
	(ucInstanceId > (IFX_DECT_REPEATERS_OFFSET + (IFX_DECT_MAX_REPEATERS*IFX_DECT_MAX_INSTANCES_PER_REPEATERS))))
	{
	 	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR ,
		               "Invalid Repeater instance number !!!!!!");
		return eRet;
	}

	if(xRepeater.pxSubscData  == NULL)
	{
		IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR ,
		               "Repeater NOT INITED !!!!!!");		
		return eRet;
	}
	
	switch(pxIpcMsg->ucMsgId)
	{
		case FP_PORTABLE_REGISTERED_IN_MM:
		case FP_PORTABLE_ATTACHED_IN_MM:

		IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT ,
		               "Handling Repeater MU Messages !!!!!!",ucInstanceId);	
		
    	if(xRepeater.xRepeaterCallBks.pfnRepeaterNotify != NULL)
    	{
    		int32 iIndex= ucInstanceId;
			/* with below calculation: 224->1; 230->2;236->3 etc..*/
			iIndex= ((iIndex % IFX_DECT_REPEATERS_OFFSET)/ IFX_DECT_MAX_INSTANCES_PER_REPEATERS)+1;
			IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT ,
		               "Index =",iIndex);	
    		xNotify.eEvent= IFX_DECT_REPEATER_DEVICE_ATTACHED;
#ifdef RPT_TEST
		{
			x_IFX_DECT_SubscInfo *pxDectSubsInfo =NULL;


			pxDectSubsInfo = (x_IFX_DECT_SubscInfo*)
			                         (pxIpcMsg->acData + sizeof(struct HLI_Header));

         if (IFX_DBGA_GetStackModuleDebugID() & IFX_DECT_STACK_DEBUG_ID_MM_DATA ) {
            uchar8 i;
            printf("     HLI-Length: %02x %02x\n", sizeof(struct HLI_Header), sizeof(x_IFX_DECT_SubscInfo));
            for( i=0; i<IFX_DECT_MAX_INSTANCES_PER_REPEATERS; i++) {
               printf("     Status: %02x\n",
                                 pxDectSubsInfo[i].cstatus);
               printf("     IPUI: %02x %02x %02x %02x %02x\n",
                                  pxDectSubsInfo[i].acipui_array[0],
                                  pxDectSubsInfo[i].acipui_array[1],
                                  pxDectSubsInfo[i].acipui_array[2],
                                  pxDectSubsInfo[i].acipui_array[3],
                                  pxDectSubsInfo[i].acipui_array[4]);
               printf("     TPUI: %02x %02x %02x\n",
                                  pxDectSubsInfo[i].actpui_array[0],
                                  pxDectSubsInfo[i].actpui_array[1],
                                  pxDectSubsInfo[i].actpui_array[2]);
               printf("     UAK: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n",
                                  pxDectSubsInfo[i].acuak_array[0],
                                  pxDectSubsInfo[i].acuak_array[1],
                                  pxDectSubsInfo[i].acuak_array[2],
                                  pxDectSubsInfo[i].acuak_array[3],
                                  pxDectSubsInfo[i].acuak_array[4],
                                  pxDectSubsInfo[i].acuak_array[5],
                                  pxDectSubsInfo[i].acuak_array[6],
                                  pxDectSubsInfo[i].acuak_array[7],
                                  pxDectSubsInfo[i].acuak_array[8],
                                  pxDectSubsInfo[i].acuak_array[9],
                                  pxDectSubsInfo[i].acuak_array[10],
                                  pxDectSubsInfo[i].acuak_array[11],
                                  pxDectSubsInfo[i].acuak_array[12],
                                  pxDectSubsInfo[i].acuak_array[13],
                                  pxDectSubsInfo[i].acuak_array[14],
                                  pxDectSubsInfo[i].acuak_array[15]);
               printf("     DCK: %02x %02x %02x %02x %02x %02x %02x %02x\n",
                                  pxDectSubsInfo[i].acdck_array[0],
                                  pxDectSubsInfo[i].acdck_array[1],
                                  pxDectSubsInfo[i].acdck_array[2],
                                  pxDectSubsInfo[i].acdck_array[3],
                                  pxDectSubsInfo[i].acdck_array[4],
                                  pxDectSubsInfo[i].acdck_array[5],
                                  pxDectSubsInfo[i].acdck_array[6],
                                  pxDectSubsInfo[i].acdck_array[7]);
               printf("     Term Cap: %08x\n",
                                 pxDectSubsInfo[i].uiTermCap);
            }
         }
         #if 0
			memcpy(&(xNotify.uxNotify.xSubscInfo[0]),&pxDectSubsInfo[0],
							sizeof(x_IFX_DECT_SubscInfo));
			memcpy(&(xNotify.uxNotify.xSubscInfo[1]),&pxDectSubsInfo[1],
							sizeof(x_IFX_DECT_SubscInfo));
			memcpy(&(xNotify.uxNotify.xSubscInfo[2]),&pxDectSubsInfo[2],
							sizeof(x_IFX_DECT_SubscInfo));
			memcpy(&(xNotify.uxNotify.xSubscInfo[3]),&pxDectSubsInfo[3],
							sizeof(x_IFX_DECT_SubscInfo));
			memcpy(&(xNotify.uxNotify.xSubscInfo[4]),&pxDectSubsInfo[4],
							sizeof(x_IFX_DECT_SubscInfo));
			memcpy(&(xNotify.uxNotify.xSubscInfo[5]),&pxDectSubsInfo[5],
							sizeof(x_IFX_DECT_SubscInfo));
   		#endif

		}
#endif
			memcpy(&(xNotify.uxNotify.xSubscInfo),(unsigned char *)pxIpcMsg->acData + sizeof(struct HLI_Header),
				sizeof(x_IFX_DECT_SubscInfo)*IFX_DECT_MAX_INSTANCES_PER_REPEATERS);

			xRepeater.xRepeaterCallBks.pfnRepeaterNotify((uint8)iIndex,&xNotify);
			eRet = IFX_SUCCESS;
    	}
		
	}
	return eRet;
}

 
/******************************************************************
*  Function Name    :IFX_DECT_UnregisterRepeater
*  Description      : Unregisters Repeaters
*  Input Values     : Repeater number (1,2,3,4,5) 
*  Output Values    : 
*  Return Value     : IFX_SUCCESS/IFX_FAILURE
*  Notes            :
*********************************************************************/

e_IFX_Return IFX_DECT_UnregisterRepeater(IN uchar8 ucRepeaterNum)
{
	x_IFX_DECT_IPC_Msg xIpcMsg = {0};	
   	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
           "Received Repeater Unregister from App",ucRepeaterNum);
	if((ucRepeaterNum <= 0) || (ucRepeaterNum > IFX_DECT_MAX_REPEATERS))
	{
		return IFX_FAILURE;
	}
   xIpcMsg.ucMsgId = FP_MM_ACCESS_RIGHTS_TERMINATE_RQ;
   xIpcMsg.ucInstance = 0;
   /*with below calculation 1->224, 2->230, etc*/
   xIpcMsg.ucPara1 = ((ucRepeaterNum -1) * IFX_DECT_MAX_INSTANCES_PER_REPEATERS) + IFX_DECT_REPEATERS_OFFSET;
   	
	IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
	/*Note
	1.Application will clear it's data from flash and it's local buffer (after calling this API) as TK has all data already for this repeater.
	2. Stack has to clear the TK data base by getting appropriate pointer after de registering 
	    all repeater instances. And no feedback needed from stack to TK*/
		    		
	return IFX_SUCCESS;
}



#endif
