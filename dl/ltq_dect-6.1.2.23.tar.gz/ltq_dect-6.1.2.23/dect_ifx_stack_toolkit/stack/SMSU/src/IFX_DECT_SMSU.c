/**************************************************************************
**   FILE NAME     : IFX_DECT_SMSU.c
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_SMSU.c
    \brief This File includes all reference of the SMSU Related Stuff.
*/
#ifdef MESSAGE_SUPPORT
#include "IFX_DECT_Platform.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_StackIf.h"
#include "IFX_DECT_MsgEncoder.h"
#include "IFX_DECT_IEParser.h"
#include "MESSAGE_DEF.H"

/*! \brief xAppCallBks defined in IFX_DECT_GlobalInfo.h
*/
#define xAppCallBks vxGlobalInfo.xSMSU.xAppCallBks

/*! \brief vxSMSInfo defined in IFX_DECT_GlobalInfo.h
*/
#define vxSMSInfo vxGlobalInfo.xSMSU.vxSMSInfo

e_IFX_Return IFX_DECT_SMSU_FetchPrimitive(IN x_IFX_DECT_IPC_Msg *pxIpcMsg,
                                          OUT char8 *pcSMS_Primitive,
                                          OUT int32 *piPrimitiveSize);


/*! \brief  Register Call Backs for CC procedures.
    \param[in] pxCallBks Events from stack to application.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_SMSU_CallBksRegister(IN x_IFX_DECT_SMSU_AppCallBks *pxCallBks){

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "<SMSU_CallBksRegister>Registering Callbacks.");
  memcpy(&xAppCallBks,pxCallBks,sizeof(x_IFX_DECT_SMSU_AppCallBks));
  return IFX_SUCCESS;
}

/*! \brief Initialization.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_SMSU_Init(){

  uchar8 i;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "<SMSU_Init>SMS Module Initialized.");

  for(i = 0; i < IFX_DECT_MAX_HS; ++i){
    vxSMSInfo[i].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize = 0;
    vxSMSInfo[i].uxSMS_Data.xHeaderGroup.ucHeaderCount = 0;
    vxSMSInfo[i].eSMS_State = IFX_DECT_SMSU_IDLE;
    vxSMSInfo[i].ucInstance = 0;
    vxSMSInfo[i].ucMesgIndex = 0;
    vxSMSInfo[i].ucUnread = 0;
    vxSMSInfo[i].ucBufLen = 0;
  }
  return IFX_SUCCESS;
}

/*! \brief IFX_DECT_SMSU_ProcessStackMsg processes incoming messages from PT.
    \param[in] pxIpcMsg IPC Message.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_SMSU_ProcessStackMsg(IN x_IFX_DECT_IPC_Msg* pxIpcMsg){

  e_IFX_DECT_SMSU_Primitive ePrimitive;
  e_IFX_DECT_SMSU_SegPrimitive eSegPrimitive;
  char8 acSMS_Primitive[200] = "";
  int32 iPrimitiveSize = 0;
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "<SMSU_ProcessStackMsg>Process Stack Message Invoked.");

  switch(pxIpcMsg->ucMsgId){
    case FP_SETUP_IN_CC:

        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                 "<SMSU_ProcessStackMsg>SETUP ARRIVED FROM PT.");
        return IFX_DECT_SMSU_SetupArrived(pxIpcMsg);
        break;

    case FP_CONNECT_IN_CC:

        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                 "<SMSU_ProcessStackMsg>CONNECT ARRIVED FROM PT.");
        return IFX_DECT_SMSU_ConnectArrived(pxIpcMsg);
        break;

    case FP_RELEASE_IN_CC:

        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                 "<SMSU_ProcessStackMsg>RELEASE ARRIVED FROM PT.");
        return IFX_DECT_SMSU_ReleaseArrived(pxIpcMsg);
        break;

    case FP_INFO_IN_CC:

        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                 "<SMSU_ProcessStackMsg>CC_INFO ARRIVED FROM PT.");
        if(IFX_DECT_SMSU_FetchPrimitive(pxIpcMsg,acSMS_Primitive,&iPrimitiveSize) !=IFX_SUCCESS){
          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                   "<SMSU_ProcessStackMsg>Unable to Fetch Primitive.");
          return IFX_FAILURE;
        } 
         
        ePrimitive = acSMS_Primitive[0] & IFX_DECT_SMSU_LOWER_NIBBLE_MASK;
        eSegPrimitive = acSMS_Primitive[0] & IFX_DECT_SMSU_LOWER_TRIPLET_MASK;

        switch(ePrimitive){

            case IFX_DECT_SMSU_DATA_REQ:
               
                if(iPrimitiveSize == 2){
               
                  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                         "<SMSU_ProcessStackMsg>Primitive is DATA_REQ.");
                  return IFX_DECT_SMSU_FetchData(acSMS_Primitive,iPrimitiveSize,pxIpcMsg);
                }else{
 
                   switch(eSegPrimitive){
                 
                     case IFX_DECT_SMSU_SEGMENT:
                     
                         if(iPrimitiveSize >2){
                           
                           IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                                     "<SMSU_ProcessStackMsg>Primitive is SEGMENT.");
                           return IFX_DECT_SMSU_ComposeMessage(acSMS_Primitive,iPrimitiveSize,pxIpcMsg);
                           }
                         break;

                     default:
                         
                         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                                  "<SMSU_ProcessStackMsg>Primitive Not Understood.");
                         return IFX_FAILURE;
                         break;
                   }
                 }   
                break;
            
	    case IFX_DECT_SMSU_DELETE_REQ:
                 
                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                         "<SMSU_ProcessStackMsg>Primitive is DELETE_REQ.");
                return IFX_DECT_SMSU_DeleteMessage(acSMS_Primitive,iPrimitiveSize,pxIpcMsg);
                break;

            case IFX_DECT_SMSU_SEND_REQ:
      
                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                         "<SMSU_ProcessStackMsg>Primitive is SEND_REQ.");
                return IFX_DECT_SMSU_ComposeMessage(acSMS_Primitive,iPrimitiveSize,pxIpcMsg);
                break;

            default:

                switch(eSegPrimitive){
                                     
                  case IFX_DECT_SMSU_SEGMENT:
                      
                      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                               "<SMSU_ProcessStackMsg>Primitive is SEGMENT.");
                      return IFX_DECT_SMSU_ComposeMessage(acSMS_Primitive,iPrimitiveSize,pxIpcMsg);                 
                      break;

                  case IFX_DECT_SMSU_SEG_ACK:
                      
                      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                               "<SMSU_ProcessStackMsg>Primitive is SEG_ACK.");
                      return IFX_DECT_SMSU_FetchData(acSMS_Primitive,iPrimitiveSize,pxIpcMsg);
                      break;
   
                  default:
                
                      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                               "<SMSU_ProcessStackMsg>Primitive Not Understood.");
                      return IFX_FAILURE;
                }
                break;
        }
        break;

    default:

        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "<SMSU_ProcessStackMsg>CC Message Not Understood.");

        return IFX_FAILURE; 
        break;
  }
  return IFX_SUCCESS;
}

//*****************************************Internal APIs***********************************************

/*! \brief IFX_DECT_SMSU_SetupArrived is Internal API called when CC_SETUP message arrives.
           It acknowledges Setup and posts Connect Message to Stack.
    \param[in] pxIpcMsg IPC Message.
    \return  IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_SMSU_SetupArrived(IN x_IFX_DECT_IPC_Msg* pxIpcMsg){

  x_IFX_DECT_IPC_Msg xSetupAck = {0};
  x_IFX_DECT_IPC_Msg xConnect = {0};
  uchar8 ucHandSet = 0;

  ucHandSet = pxIpcMsg->ucPara1;
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	   "<SMSU_SetupArrived>In Internal API SetupArrived.");
  if(vxSMSInfo[ucHandSet-1].eSMS_State == IFX_DECT_SMSU_IDLE){

    if(IFX_DECT_MU_SetModuleOwner(ucHandSet,IFX_DECT_MU_ADD_OWNER,IFX_DECT_SMSU_ID)
        == IFX_SUCCESS){

     vxSMSInfo[ucHandSet-1].ucInstance = pxIpcMsg->ucInstance;
      
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
	       "<SMSU_SetupArrived>ucInstance",pxIpcMsg->ucInstance);
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
	       "<SMSU_SetupArrived>ucHandSet",ucHandSet);

      if(IFX_DECT_BlockMCEI(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance) == IFX_FAILURE){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 "<SMSU_SetupArrived>Instance Number could not be blocked."); 
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		 "<SMSU_SetupArrived>SetupArrived Failed.");

        return IFX_FAILURE;
      }
      IFX_DECT_EncodeSetupAck(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,&xSetupAck);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xSetupAck);
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	       "<SMSU_SetupArrived>SetupAck posted to stack.");

      vxSMSInfo[ucHandSet-1].eSMS_State = IFX_DECT_SMSU_TRANSIENT;
   
      IFX_DECT_EncodeConnect(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,0/*bWideband*/,&xConnect);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xConnect);
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	       "<SMSU_SetupArrived>Connect posted to stack.");
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	       "<SMSU_SetupArrived>SetupArrived Successful.");
      return IFX_SUCCESS;
    }
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_SetupArrived>SMSU not module owner.");
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_SetupArrived>SetupArrived Failed.");

    return IFX_FAILURE;
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
           "<SMSU_SetupArrived>State not IDLE.");
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	   "<SMSU_SetupArrived>SetupArrived Failed.");
  return IFX_FAILURE;

}

/*! \brief IFX_DECT_SMSU_ConnectArrived is Internal API called when CC_CONNECT message arrives.
           It acknowledges Connect Message.
    \param[in] pxIpcMsg IPC Message.
    \return  IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_SMSU_ConnectArrived(IN x_IFX_DECT_IPC_Msg* pxIpcMsg){

  x_IFX_DECT_IPC_Msg xConnectAck = {0};
  uchar8 ucHandSet = 0;

  ucHandSet=pxIpcMsg->ucPara1;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "<SMSU_ConnectArrived>In Internal API ConnectArrived.");

  if(vxSMSInfo[ucHandSet-1].eSMS_State == IFX_DECT_SMSU_TRANSIENT){
    
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
	     "<SMSU_SetupArrived>ucInstance",vxSMSInfo[ucHandSet-1].ucInstance);
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
	     "<SMSU_SetupArrived>ucHandSet",ucHandSet);

    IFX_DECT_EncodeConnectAck(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,&xConnectAck);
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xConnectAck);
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_ConnectArrived>ConnectAck posted to stack.");
    
    vxSMSInfo[ucHandSet-1].eSMS_State = IFX_DECT_SMSU_ACTIVE;

    if(vxSMSInfo[ucHandSet-1].ucUnread !=0 ){
      if(IFX_DECT_SMSU_NotifyUnread(ucHandSet,vxSMSInfo[ucHandSet-1].ucUnread) == IFX_SUCCESS){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		 "<SMSU_ConnectArrived>ConnectArrived Successful.");
        return IFX_SUCCESS;
      }
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	       "<SMSU_ConnectArrived>Api NotifyUnread Failed."); 
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	       "<SMSU_ConnectArrived>ConnectArrived Failed.");

      return IFX_FAILURE;
    }
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_ConnectArrived>ucUnread = 0.");
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_ConnectArrived>ConnectArrived Failed.");
 
    return IFX_FAILURE;
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	   "<SMSU_ConnectArrived>State not TRANSIENT.");
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	   "<SMSU_ConnectArrived>ConnectArrived Failed.");  
  return IFX_FAILURE;
}

/*! \brief Internal API used to Release Resources.
    \param[IN] ucHandSet Handset Number.
    \return IFX_SUCCESS or IFX_FAILURE;
*/

e_IFX_Return IFX_DECT_SMSU_ReleaseResources(IN uchar8 ucHandSet){

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	    "<SMSU_ReleaseResources>SMSU resources released.");

   vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize = 0;
   vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount = 0;
   vxSMSInfo[ucHandSet-1].eSMS_State = IFX_DECT_SMSU_IDLE;
   vxSMSInfo[ucHandSet-1].ucInstance = 0;
   vxSMSInfo[ucHandSet-1].ucMesgIndex = 0;
   vxSMSInfo[ucHandSet-1].ucUnread = 0;
   vxSMSInfo[ucHandSet-1].ucBufLen = 0;

   return IFX_SUCCESS;
}

/*! \brief  Internal API called when CC_RELEASE arrives.
    \param[in] pxIpcMsg IPC Message.
    \return  IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_SMSU_ReleaseArrived(IN x_IFX_DECT_IPC_Msg* pxIpcMsg){

  uchar8 ucHandSet = 0;

  ucHandSet=pxIpcMsg->ucPara1;
    
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	   "<SMSU_ReleaseArrived>In Api ReleaseArrived.");
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
	   "<SMSU_SetupArrived>ucInstance",vxSMSInfo[ucHandSet-1].ucInstance);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
	   "<SMSU_SetupArrived>ucHandSet",ucHandSet);

  if(vxSMSInfo[ucHandSet-1].eSMS_State == IFX_DECT_SMSU_ACTIVE){
    
    IFX_DECT_MU_SetModuleOwner(ucHandSet,IFX_DECT_MU_REMOVE_OWNER,IFX_DECT_SMSU_ID);
    if(IFX_DECT_FreeMCEI(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance) == IFX_FAILURE){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	       "<SMSU_ReleaseArrived>Instance number already free.");
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	       "<SMSU_ReleaseArrived>ReleaseArrived Failed.");

      return IFX_FAILURE;
    }
    IFX_DECT_SMSU_ReleaseResources(ucHandSet);     
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_ReleaseArrived>ReleaseArrived Successful.");

    return IFX_SUCCESS;
  }else{
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_ReleaseArrived>State not ACTIVE.");
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_ReleaseArrived>ReleaseArrived Failed.");

    return IFX_FAILURE;
   }
}


/*! \brief Internal API used to construct primitive DataRsp.
    \param[IN] eReqType-Headers or Message.
    \param[IN] eMesgBox-Inbox or Outbox.
    \param[IN] ucMesgIndex Index of the message.
    \param[IN] ucMesgSize Size of Message/Header block.
    \param[OUT] pxDataRsp pointer to primitive DataRsp.  
    \return IFX_SUCCESS or IFX_FAILURE;
*/

e_IFX_Return IFX_DECT_SMSU_ComposeDataRsp(IN e_IFX_DECT_SMSU_DataType eReqType,
                                          IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                                          IN uchar8 ucMesgIndex,
                                          IN uchar8 ucMesgSize,
                                          OUT x_IFX_DECT_SMSU_DataRspUpper *pxDataRsp){
 
  pxDataRsp->ucReqType = eReqType;
  pxDataRsp->ucMesgBox = eMesgBox;
  pxDataRsp->ucMesgIndex = ucMesgIndex;
  pxDataRsp->ucMesgSize = ucMesgSize;
  pxDataRsp->ucPrimitive = IFX_DECT_SMSU_DATA_RSP;
  return IFX_SUCCESS;
}

/*! \brief Internal API used to construct primitive DeleteRsp.
    \param[IN] eFailReason Reason for failure.
    \param[IN] eStatus Status-Success or Failure.
    \param[OUT] pxDeleteRsp pointer to primitive DeleteRsp.
    \return IFX_SUCCESS or IFX_FAILURE;
*/

e_IFX_Return IFX_DECT_SMSU_ComposeDeleteRsp(IN e_IFX_DECT_SMSU_ReasonCode eFailReason,
                                            IN e_IFX_Return eStatus,
                                            OUT x_IFX_DECT_SMSU_DeleteRsp *pxDeleteRsp){

  pxDeleteRsp->ucPrimitive = IFX_DECT_SMSU_DELETE_RSP;
  pxDeleteRsp->ucDeleteDeliverStatus = eStatus;
  pxDeleteRsp->ucFailureReasonCode = eFailReason;
  return IFX_SUCCESS;
}

/*! \brief Internal API used to construct primitive SendRsp.
    \param[IN] eFailReason Reason for failure.
    \param[IN] eStatus Status-Success or Failure.
    \param[OUT] pxSendRsp pointer to primitive SendRsp.
    \return IFX_SUCCESS or IFX_FAILURE;
*/

e_IFX_Return IFX_DECT_SMSU_ComposeSendRsp(IN e_IFX_DECT_SMSU_ReasonCode eFailReason,
                                          IN e_IFX_Return eStatus,
                                          OUT x_IFX_DECT_SMSU_SendRsp *pxSendRsp){

  pxSendRsp->ucPrimitive = IFX_DECT_SMSU_SEND_RSP;
  pxSendRsp->ucDeleteDeliverStatus = eStatus;
  pxSendRsp->ucFailureReasonCode = eFailReason;
  return IFX_SUCCESS;

}

/*! \brief Internal API used to construct primitive SMS_Notify.
    \param[IN] ucUnread Number of Unread Messages.
    \param[OUT] pxNotify pointer to primitive Notify.
    \return IFX_SUCCESS or IFX_FAILURE;
*/

e_IFX_Return IFX_DECT_SMSU_ComposeNotify(IN uchar8 ucUnread,
		                         OUT x_IFX_DECT_SMSU_Notify *pxNotify){

   pxNotify->ucPrimitive = IFX_DECT_SMSU_NOTIFY;
   pxNotify->ucNumUnreadMesg = ucUnread;
   return IFX_SUCCESS;
}

/*! \brief Internal API used to construct SMS Segment.
    \param[IN] ucSbit Indicates whether there are more segments or not.
    \param[IN] ucSeg_num Segment Number.
    \param[IN] ucSegmentSize Segment Size.
    \param[OUT] pxSegUpper pointer to Segment.
    \return IFX_SUCCESS or IFX_FAILURE;
*/

e_IFX_Return IFX_DECT_SMSU_ComposeSeg(IN uchar8 ucSbit,
		                      IN uchar8 ucSeg_num,
		                      IN uchar8 ucSegmentSize,
                                      OUT x_IFX_DECT_SMSU_SegmentPacketHeader *pxSegUpper){
    
   pxSegUpper->ucSms_seg = IFX_DECT_SMSU_SEGMENT;
   pxSegUpper->ucSbit = ucSbit;
   pxSegUpper->ucSeg_num = ucSeg_num;
   pxSegUpper->ucSegmentSize = ucSegmentSize;
   return IFX_SUCCESS;
}

/*! \brief Internal API used to construct SMS Segment Ack.
    \param[IN] ucReqSegNo Requested Segment Number.
    \param[IN] ucAsmStatus Assembly status of segments.
    \param[IN] ucFailReason Reason for failure.
    \param[OUT] pxSegAck pointer to Segment Ack.
    \return IFX_SUCCESS or IFX_FAILURE;
*/

e_IFX_Return IFX_DECT_SMSU_ComposeSegAck(IN uchar8 ucReqSegNo,
		                         IN uchar8 ucAsmStatus,
					 IN uchar8 ucFailReason,//ASK:Data Type for FailReason?
                                         OUT x_IFX_DECT_SMSU_SegAck *pxSegAck){
   
   pxSegAck->ucSMS_Ack=IFX_DECT_SMSU_SEG_ACK;
   pxSegAck->ucReqSegNo = ucReqSegNo;
   pxSegAck->ucAsmStatus = ucAsmStatus;
   pxSegAck->ucFailReason = ucFailReason;
   return IFX_SUCCESS;
}
/*! \brief Internal API used to Fill SMS Message Block.
    \param[IN] ucHandSet Handset Number.
    \param[OUT] pxMesg pointer to SMS Message Block.
    \return IFX_SUCCESS or IFX_FAILURE;
*/

e_IFX_Return IFX_DECT_SMSU_FillMessage(IN uchar8 ucHandSet,
		                       OUT x_IFX_DECT_SMSU_Mesg *pxMesg){

   //memcpy(pxMesg,vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock,sizeof(x_IFX_DECT_SMSU_Mesg));	
   pxMesg->ucToFromNumberSize = vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucToFromNumberSize;
   strcpy(((char8 *)pxMesg->aucToFromNumber),((char8 *)vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.aucToFromNumber));
   pxMesg->ucMesgSize = vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize;

   strcpy(((char8 *)pxMesg->aucMesgContents),((char8 *)vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents));
   
   memcpy(&pxMesg->xMesgTimeStamp,&vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.xMesgTimeStamp,
               sizeof(x_IFX_DECT_SMSU_TimeStamp));
   pxMesg->ucExtnNumber = vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.ucExtnNumber;
   pxMesg->ucChecksum = vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.ucChecksum;
   return IFX_SUCCESS;
}

/*! \brief  Internal API called when a SMS_DATA_REQ arrives in CC_INFO message.
    \param[in] pcPrimitiveMesg pointer to SMS primitive.
    \param[in] iPrimitiveLen Length of primitive.
    \param[in] pxIpcMsg IPC MEssage.
    \param[in] ucPrimitiveCode Type of primitive message.
    \return  IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_DECT_SMSU_FetchData(IN char8 *pcPrimitiveMesg, 
		                     IN int32 iPrimitiveLen,
                                     IN x_IFX_DECT_IPC_Msg *pxIpcMsg){

  uchar8 ucHandSet = 0;
  uchar8 ucSegSize = 0;
  uchar8 ucSbit = IFX_DECT_SMSU_LAST_SEGMENT;
  e_IFX_DECT_SMSU_MesgBox eMesgBox=0;
  x_IFX_DECT_IPC_Msg xIpcReply = {0};
  x_IFX_DECT_SMSU_DataRspUpper xDataRsp = {0};
  x_IFX_DECT_SMSU_SegmentPacketHeader xSegUpper = {0};
  x_IFX_DECT_SMSU_SegAck *pxSegAck = NULL;
  int32 iReplyLen = 0;
  e_IFX_Return eRet = IFX_FAILURE;
  uchar8 ucAllHeaders = 0;
  uchar8 ucMesgSize = 0;
  uchar8 ucDataRspSize = 0;
  uchar8 ucDataRspHdrSize = 0;
  uchar8 acData[300] = "";

  x_IFX_DECT_SMSU_DataReq *pxDataReq = NULL;
  e_IFX_DECT_SMSU_Primitive ePrimitive;
  e_IFX_DECT_SMSU_SegPrimitive eSegPrimitive;

  ucHandSet = pxIpcMsg->ucPara1;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
           "<SMSU_FetchData>ucInstance",vxSMSInfo[ucHandSet-1].ucInstance);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
           "<SMSU_FetchData>ucHandSet",ucHandSet);

  ePrimitive = (pcPrimitiveMesg[0] & IFX_DECT_SMSU_LOWER_NIBBLE_MASK); 
     
  switch(ePrimitive){

    case IFX_DECT_SMSU_DATA_REQ:

	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                       "<SMSU_FetchData>Primitive DATA_REQ arrived.");    
     
        pxDataReq = (x_IFX_DECT_SMSU_DataReq*)pcPrimitiveMesg;

        switch(pxDataReq->ucMesgBox){

          case IFX_DECT_SMSU_INBOX:

              eMesgBox = IFX_DECT_SMSU_INBOX;
              break;

          case IFX_DECT_SMSU_OUTBOX:

              eMesgBox = IFX_DECT_SMSU_OUTBOX;
              break;

        }
        switch(pxDataReq->ucReqType){

          case IFX_DECT_SMSU_HEADERS:

              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                       "<SMSU_FetchData>Request is for Headers.");

              eRet = xAppCallBks.pfnHdrsGet(ucHandSet,eMesgBox,
                                                 &vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[0],
                                                 &vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount);
                                                 
              switch(eRet){

                case IFX_PENDING:

                    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                             "<SMSU_FetchData>Callbck HdrsGet returned Pending Status.");
                    return IFX_SUCCESS;
                    break;

                case IFX_FAILURE:

                    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                             "<SMSU_FetchData>Callbck HdrsGet Failed.");
                    return IFX_FAILURE;//Send Release
                    break;

                default:

                    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                             "<SMSU_FetchData>Callbck HdrsGet Successful.");
                    break;
              }
              vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucChecksum = 0;

              ucAllHeaders = 
              sizeof(x_IFX_DECT_SMSU_HeaderBlock)*vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount;
              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,"<SMSU_FetchData>ucHeaderCount",
                       vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount);

              ucDataRspHdrSize = sizeof(x_IFX_DECT_SMSU_DataRspUpper)-1;
              vxSMSInfo[ucHandSet-1].ucBufLen = sizeof(uchar8/*ucHeaderCount*/)+
                                                       sizeof(uchar8/*ucChecksum*/)+
                                                       ucAllHeaders+
                                                       ucDataRspHdrSize;
              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                       "<SMSU_FetchData>HdrGrpSize",vxSMSInfo[ucHandSet-1].ucBufLen);

              if(vxSMSInfo[ucHandSet-1].ucBufLen > IFX_DECT_SMSU_MAX_SEG_DATALEN){
                 
                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                         "<SMSU_FetchData>HdrGrpSize > 127.");

                ucSegSize = IFX_DECT_SMSU_MAX_SEG_DATALEN;
                IFX_DECT_SMSU_ComposeSeg(IFX_DECT_SMSU_MORE_SEGMENTS/*Sbit*/,
                                         1/*Seg_num*/,ucSegSize,&xSegUpper);

                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                         "<SMSU_FetchData>Segment Size",xSegUpper.ucSegmentSize);
                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                         "<SMSU_FetchData>Segment Number",xSegUpper.ucSeg_num);               

                ucDataRspSize = vxSMSInfo[ucHandSet-1].ucBufLen
                                -ucDataRspHdrSize;
                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                         "<SMSU_FetchData>DataRspSize",ucDataRspSize);
                IFX_DECT_SMSU_ComposeDataRsp(IFX_DECT_SMSU_HEADERS,eMesgBox,
                                             pxDataReq->ucMesgIndex,
                                             ucDataRspSize,&xDataRsp);

                IFX_DECT_SMSU_memcat(4,vxSMSInfo[ucHandSet-1].acBuff,&iReplyLen,
                             &xDataRsp,sizeof(x_IFX_DECT_SMSU_DataRspUpper),
                             &vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount,sizeof(uchar8),
                             vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders,ucAllHeaders,
                             &vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucChecksum,sizeof(uchar8));

                *(vxSMSInfo[ucHandSet-1].acBuff+iReplyLen)='\0';
                iReplyLen = 0;

                IFX_DECT_SMSU_memcat(2,acData,&iReplyLen,
                                     &xSegUpper,sizeof(x_IFX_DECT_SMSU_SegmentPacketHeader),
                                     vxSMSInfo[ucHandSet-1].acBuff,xSegUpper.ucSegmentSize);
                *(acData+iReplyLen)='\0';
   
                if(EncodeIWU_SMS(((char8 *)acData),iReplyLen,((char8 *)xIpcReply.acData)) == IFX_FAILURE){
                  
                  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                           "<SMSU_FetchData>EncodeIWU_SMS Failed.");
                  return IFX_FAILURE;
                }

              }else if(vxSMSInfo[ucHandSet-1].ucBufLen <= IFX_DECT_SMSU_MAX_SEG_DATALEN){

                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                         "<SMSU_FetchData>HdrGrpSize <= 127.");

                ucDataRspSize = vxSMSInfo[ucHandSet-1].ucBufLen
                                -ucDataRspHdrSize;

		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                         "<SMSU_FetchData>DataRspSize",ucDataRspSize);
		
                IFX_DECT_SMSU_ComposeDataRsp(IFX_DECT_SMSU_HEADERS,eMesgBox,
                                             pxDataReq->ucMesgIndex,
                                             ucDataRspSize,&xDataRsp);

                IFX_DECT_SMSU_memcat(4,vxSMSInfo[ucHandSet-1].acBuff,&iReplyLen,
                               &xDataRsp,sizeof(x_IFX_DECT_SMSU_DataRspUpper),
                               &vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount,sizeof(uchar8),
                               vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders,ucAllHeaders,
                               &vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucChecksum,sizeof(uchar8));
                *(vxSMSInfo[ucHandSet-1].acBuff+iReplyLen)='\0';

                if(EncodeIWU_SMS(((char8 *)vxSMSInfo[ucHandSet-1].acBuff),iReplyLen,((char8 *)xIpcReply.acData)) == IFX_FAILURE){
                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                         "<SMSU_FetchData>EncodeIWU_SMS Failed.");
                return IFX_FAILURE;
                }
               }
               IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
                                      0/*ucSignal*/,&xIpcReply);

              break;

          case IFX_DECT_SMSU_MESG:

              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                       "<SMSU_FetchData>Request is for Message.");
              
              eRet = xAppCallBks.pfnMesgGet(ucHandSet,eMesgBox,
                 pxDataReq->ucMesgIndex,(x_IFX_DECT_SMSU_Mesg*)&vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock);

              switch(eRet){

                case IFX_PENDING:

                    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                             "<SMSU_FetchData>Callbck MesgGet returned Pending Status.");
                    return IFX_SUCCESS;
                    break;

                case IFX_FAILURE:

                    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "<SMSU_FetchData>Callbck MesgGet Failed.");
                    return IFX_FAILURE;//What to do...send release?
                    break;

                default:

                    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "SMSU_<FetchData>Callbck MesgGet Successful.");
              }
              ucMesgSize = vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize;
              ucDataRspHdrSize = sizeof(x_IFX_DECT_SMSU_DataRspUpper);
              vxSMSInfo[ucHandSet-1].ucBufLen = ucMesgSize+sizeof(x_IFX_DECT_SMSU_DataBlock_Lower)
                                                     +sizeof(x_IFX_DECT_SMSU_DataBlock_Upper)
                                                     +ucDataRspHdrSize;
              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                       "<SMSU_FetchData>MessageBlockSize",vxSMSInfo[ucHandSet-1].ucBufLen);
               
              if(vxSMSInfo[ucHandSet-1].ucBufLen > IFX_DECT_SMSU_MAX_SEG_DATALEN){

                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                         "<SMSU_FetchData>MesgBlkSize > 127.");
                 
                ucSegSize = IFX_DECT_SMSU_MAX_SEG_DATALEN;
                IFX_DECT_SMSU_ComposeSeg(IFX_DECT_SMSU_MORE_SEGMENTS/*Sbit*/,1/*Seg_num*/,
                                         ucSegSize,&xSegUpper);

                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                         "<SMSU_FetchData>Segment Number",xSegUpper.ucSeg_num);
                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                         "<SMSU_FetchData>Segment Size",xSegUpper.ucSegmentSize);

                ucDataRspSize= vxSMSInfo[ucHandSet-1].ucBufLen -ucDataRspHdrSize;
                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                         "<SMSU_FetchData>DataRspSize",ucDataRspSize);
                IFX_DECT_SMSU_ComposeDataRsp(IFX_DECT_SMSU_MESG,eMesgBox,
                                             pxDataReq->ucMesgIndex,
                                             ucDataRspSize,&xDataRsp);
                                 
                IFX_DECT_SMSU_memcat(4,vxSMSInfo[ucHandSet-1].acBuff,&iReplyLen,
                                     &xDataRsp,sizeof(x_IFX_DECT_SMSU_DataRspUpper),  
                                     &(vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper),
                                     sizeof(x_IFX_DECT_SMSU_DataBlock_Upper),
                                     vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents,ucMesgSize,
                                     &vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower,
                                     sizeof(x_IFX_DECT_SMSU_DataBlock_Lower));

                *(vxSMSInfo[ucHandSet-1].acBuff+iReplyLen)='\0';

                iReplyLen = 0;
                IFX_DECT_SMSU_memcat(2,acData,&iReplyLen,
                                     &xSegUpper,sizeof(x_IFX_DECT_SMSU_SegmentPacketHeader),
                                     vxSMSInfo[ucHandSet-1].acBuff,xSegUpper.ucSegmentSize);
                *(acData+iReplyLen)='\0';
                    
                if(EncodeIWU_SMS(((char8 *)acData),iReplyLen,((char8 *)xIpcReply.acData)) == IFX_FAILURE){
                  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                           "<SMSU_FetchData>EncodeIWU_SMS Failed.");
                  return IFX_FAILURE;
                }

              }else if(vxSMSInfo[ucHandSet-1].ucBufLen <= IFX_DECT_SMSU_MAX_SEG_DATALEN){

                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                         "<SMSU_FetchData>MesgBlkSize <= 128.");

                ucDataRspSize = vxSMSInfo[ucHandSet-1].ucBufLen -ucDataRspHdrSize;
                IFX_DECT_SMSU_ComposeDataRsp(IFX_DECT_SMSU_MESG,eMesgBox,
                                             pxDataReq->ucMesgIndex,
                                             ucDataRspSize,&xDataRsp);

                IFX_DECT_SMSU_memcat(4,vxSMSInfo[ucHandSet-1].acBuff,&iReplyLen,
                                     &xDataRsp,sizeof(x_IFX_DECT_SMSU_DataRspUpper),
                                     &(vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper),
                                     sizeof(x_IFX_DECT_SMSU_DataBlock_Upper),
                                     vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents,
                                     ucMesgSize,
                                     &vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower,
                                     sizeof(x_IFX_DECT_SMSU_DataBlock_Lower));

                *(vxSMSInfo[ucHandSet-1].acBuff+iReplyLen) = '\0';

                if(EncodeIWU_SMS(((char8 *)vxSMSInfo[ucHandSet-1].acBuff),iReplyLen,((char8 *)xIpcReply.acData)) == IFX_FAILURE){
                  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"<FetchData>EncodeIWU_SMS Failed.");
                  return IFX_FAILURE;
                }
               }
               IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
                                     0/*ucSignal*/,&xIpcReply);
               break;
        }          
#ifdef IFX_SMSU_STUB
        return IFX_DECT_SMSU_STUB_PostToStub(&xIpcReply);
#else
        return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
#endif

        break;

    default:
        
       eSegPrimitive = (pcPrimitiveMesg[0] & IFX_DECT_SMSU_LOWER_TRIPLET_MASK);
       switch(eSegPrimitive){
        
         case IFX_DECT_SMSU_SEG_ACK:
             
             IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                      "<SMSU_FetchData>Segment Acknowledgement."); 
             
             pxSegAck = (x_IFX_DECT_SMSU_SegAck *)pcPrimitiveMesg; 
             if(pxSegAck->ucReqSegNo == 0){
              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                       "<SMSU_FetchData>No more Segments Requested.");
              return IFX_SUCCESS;
             }
             if(pxSegAck->ucAsmStatus == 0){

               ucSegSize =
              ((vxSMSInfo[ucHandSet-1].ucBufLen -((pxSegAck->ucReqSegNo-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN))
                >= IFX_DECT_SMSU_MAX_SEG_DATALEN) ? IFX_DECT_SMSU_MAX_SEG_DATALEN :
                (vxSMSInfo[ucHandSet-1].ucBufLen - ((pxSegAck->ucReqSegNo-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN)); 

               if(ucSegSize > IFX_DECT_SMSU_MAX_SEG_DATALEN){

                 ucSbit = IFX_DECT_SMSU_MORE_SEGMENTS;
               }else{
                 ucSbit = IFX_DECT_SMSU_LAST_SEGMENT;
                }
               IFX_DECT_SMSU_ComposeSeg(ucSbit,pxSegAck->ucReqSegNo/*Seg_num*/,ucSegSize,&xSegUpper);
            
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                         "<SMSU_FetchData>Segment Size",xSegUpper.ucSegmentSize);
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                         "<SMSU_FetchData>Segment Number",xSegUpper.ucSeg_num);	       
             }else if(pxSegAck->ucAsmStatus == 1){
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                        "Assembly status is Complete.");
               return IFX_SUCCESS;//Need to check this?
              }else{
                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                         "<SMSU_FetchData>Assembly of segments at peer failed.");
                return IFX_FAILURE;
               }
             IFX_DECT_SMSU_memcat(3,acData,&iReplyLen,
                                   &xSegUpper,sizeof(x_IFX_DECT_SMSU_SegmentPacketHeader),
                                   vxSMSInfo[ucHandSet-1].acBuff+((pxSegAck->ucReqSegNo-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN),
                                   xSegUpper.ucSegmentSize);
             *(acData+iReplyLen)='\0';
             if(EncodeIWU_SMS(((char8 *)acData),iReplyLen,((char8 *)xIpcReply.acData)) == IFX_FAILURE){

               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                        "<SMSU_FetchData>EncodeIWU_SMS Failed.");
               return IFX_FAILURE;
             }
             IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
                                   0/*ucSignal*/,&xIpcReply); 
             break;
      
         default:
            
             return IFX_FAILURE;
       }
    
  }
  return IFX_FAILURE;

}

/*! \brief Internal API called when a SMS_DELETE_REQ arrives in CC_INFO.
    \param[in] pcPrimitiveMesg pointer to SMS Primitive.
    \param[in] iPrimitiveLen Length of primitive.
    \param[in] pxIpcMsg IPC Message.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_SMSU_DeleteMessage(IN char8 *pcPrimitiveMesg, IN int32 iPrimitiveLen,IN x_IFX_DECT_IPC_Msg* pxIpcMsg){

  uchar8 ucHandSet = 0;
  e_IFX_Return eRet=IFX_FAILURE;
  x_IFX_DECT_SMSU_DeleteRsp xDeleteRsp = {0};
  x_IFX_DECT_IPC_Msg xIpcReply = {0};
  e_IFX_DECT_SMSU_MesgBox eMesgBox=0;
  e_IFX_DECT_SMSU_ReasonCode eFailReason;//ASK.

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	   "<SMSU_DeleteMessage>In Api DeleteMessage.");

  x_IFX_DECT_SMSU_DeleteReq *pxDeleteReq =
    (x_IFX_DECT_SMSU_DeleteReq *)pcPrimitiveMesg;

  ucHandSet = pxIpcMsg->ucPara1;
 
  switch(pxDeleteReq->ucMesgBox){

    case IFX_DECT_SMSU_INBOX:

        eMesgBox=IFX_DECT_SMSU_INBOX;
        break;

    case IFX_DECT_SMSU_OUTBOX:

        eMesgBox=IFX_DECT_SMSU_INBOX;
        break;

  }
  switch(pxDeleteReq->ucReqType){

    case IFX_DECT_SMSU_SINGLE:

	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 "<SMSU_DeleteMessage>Request is to delete a Single message.");    

        eRet = xAppCallBks.pfnMesgDelete(ucHandSet,eMesgBox,
              pxDeleteReq->ucMesgIndex,&eFailReason);
        break;

    case IFX_DECT_SMSU_ALL:

	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 "<SMSU_DeleteMessage>Request is to delete all messages.");
       	
        eRet = xAppCallBks.pfnMesgDelete(ucHandSet,eMesgBox,
              0/*ucMesgIndex = 1 to 20 ,hence 0 for delete all*/,&eFailReason);
        break;
  }

  switch(eRet){

    case IFX_PENDING:

        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 "<SMSU_DeleteMessage>Callbck MesgDelete returned Pending Status.");
        return IFX_SUCCESS;
        break;

    case IFX_FAILURE:
 
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 "<SMSU_DeleteMessage>Callbck MesgDelete Failed.");
         IFX_DECT_SMSU_ComposeDeleteRsp(eFailReason,eRet,&xDeleteRsp);//Check fail.
 
        if(EncodeIWU_SMS((char8 *)&xDeleteRsp,sizeof(x_IFX_DECT_SMSU_DeleteRsp),
                       ((char8 *)xIpcReply.acData)) == IFX_FAILURE){
          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	           "<SMSU_DeleteMessage>EncodeIWU_SMS Failed.");
          return IFX_FAILURE;
        }
        IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
                              0/*ucSignal*/,&xIpcReply);
#ifdef IFX_SMSU_STUB
        IFX_DECT_SMSU_STUB_PostToStub(&xIpcReply);
#else
        IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
#endif

      return IFX_SUCCESS;
        break;
    
    case IFX_SUCCESS:
  
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 "<SMSU_DeleteMessage>Callbck MesgDelete Successful."); 
        IFX_DECT_SMSU_ComposeDeleteRsp(eFailReason,eRet,&xDeleteRsp);//Check fail.
 
        if(EncodeIWU_SMS((char8 *)&xDeleteRsp,sizeof(x_IFX_DECT_SMSU_DeleteRsp),
                       ((char8 *)xIpcReply.acData)) == IFX_FAILURE){
          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	           "<SMSU_DeleteMessage>EncodeIWU_SMS Failed.");
          return IFX_FAILURE;
        }
        IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
                              0/*ucSignal*/,&xIpcReply);
#ifdef IFX_SMSU_STUB
        IFX_DECT_SMSU_STUB_PostToStub(&xIpcReply);
#else
        IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
#endif

        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		 "<SMSU_DeleteMessage>DeleteMessage Successful.");
        return IFX_SUCCESS;

    default: return IFX_FAILURE;
  }
}

/*! \brief  Internal API called when a SMS_SEND_REQ arrives in CC_INFO.
    \param[in] pcPrimitiveMesg pointer to SMS Primitive.
    \param[in] iPrimitiveLen Length of primitive.
    \param[in] pxIpcMsg pointer to IPC Message.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_SMSU_ComposeMessage(IN char8 *pcPrimitiveMesg,
		                          IN int32 iPrimitiveLen,
					  IN x_IFX_DECT_IPC_Msg* pxIpcMsg)
{

  uchar8 ucHandSet = 0;
  int32 iReplyLen = 0;
  x_IFX_DECT_IPC_Msg xIpcReply = {0};
  e_IFX_Return eRet = IFX_FAILURE;//check
  x_IFX_DECT_SMSU_Mesg xMesg = {0};
  x_IFX_DECT_SMSU_SendRsp xSendRsp = {0};
  x_IFX_DECT_SMSU_SegmentPacketHeader xSegmentPacketHeader = {0};
  x_IFX_DECT_SMSU_SegAck xSegAck = {0};
  
  x_IFX_DECT_SMSU_SendReqUpper *pxSendReqUpper = NULL;
  e_IFX_DECT_SMSU_Primitive ePrimitive;
  e_IFX_DECT_SMSU_SegPrimitive eSegPrimitive;
  e_IFX_DECT_SMSU_ReasonCode eFailReason;
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "<SMSU_ComposeMessage>In Api ComposeMessage.");
  ucHandSet = pxIpcMsg->ucPara1;

  ePrimitive = (pcPrimitiveMesg[0] & IFX_DECT_SMSU_LOWER_NIBBLE_MASK);

  switch(ePrimitive){

    case IFX_DECT_SMSU_SEND_REQ:

        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		 "<SMSU_ComposeMessage>No Segments Present.");

        pxSendReqUpper = (x_IFX_DECT_SMSU_SendReqUpper*)pcPrimitiveMesg;
	pcPrimitiveMesg += sizeof(x_IFX_DECT_SMSU_SendReqUpper);

        memcpy(&vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper,
               pcPrimitiveMesg,sizeof(x_IFX_DECT_SMSU_DataBlock_Upper));
        pcPrimitiveMesg += sizeof(x_IFX_DECT_SMSU_DataBlock_Upper);

        memcpy(vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents,
               pcPrimitiveMesg,vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize);
        pcPrimitiveMesg += vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize;   
       	
        memcpy(&vxSMSInfo[ucHandSet].uxSMS_Data.xMesgBlock.xMesgLower,
               pcPrimitiveMesg,sizeof(x_IFX_DECT_SMSU_DataBlock_Lower));        

        IFX_DECT_SMSU_FillMessage(ucHandSet,&xMesg);
        eRet = xAppCallBks.pfnMesgSend(ucHandSet,xMesg,
                                            &vxSMSInfo[ucHandSet-1].ucMesgIndex,
					    &eFailReason);//shud eFailReason be global.

        switch(eRet){
         
	  case IFX_SUCCESS:

              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		                   "<SMSU_ComposeMessage>CB MesgSend Successful.");  
     
              IFX_DECT_SMSU_MesgRspSend(ucHandSet,vxSMSInfo[ucHandSet-1].ucMesgIndex,IFX_DECT_SMSU_READ,
                                       0/*eFailReason*/);
              break;

          case IFX_PENDING:

	      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		                   "<SMSU_ComposeMessage>CB MesgSend returned pending Status.");  
              return IFX_SUCCESS;
              break;

          case IFX_FAILURE://Check out wat to do.
             
              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		                   "<SMSU_ComposeMessage>CB MesgSend Failed."); 

              IFX_DECT_SMSU_MesgRspSend(ucHandSet,vxSMSInfo[ucHandSet-1].ucMesgIndex,IFX_DECT_SMSU_READ,
                                    IFX_DECT_SMSU_NETWORK_ERROR);
              return IFX_SUCCESS;
              break;

          default: return IFX_FAILURE;
        }
        break;

    default:	

	eSegPrimitive = (pcPrimitiveMesg[0] & IFX_DECT_SMSU_LOWER_TRIPLET_MASK);

	switch(eSegPrimitive){

	  case IFX_DECT_SMSU_SEGMENT:
      
	      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		       "<SMSU_ComposeMessage>Segments Present.");
      	      
	      memcpy(&xSegmentPacketHeader,pcPrimitiveMesg,
	             sizeof(x_IFX_DECT_SMSU_SegmentPacketHeader)); 
	      pcPrimitiveMesg += sizeof(x_IFX_DECT_SMSU_SegmentPacketHeader);

              if(xSegmentPacketHeader.ucSbit == IFX_DECT_SMSU_MORE_SEGMENTS){

                if(xSegmentPacketHeader.ucSeg_num == 1){

                  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
		           "<SMSU_ComposeMessage>First Segment.");

		  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
		           "<SMSU_ComposeMessage>Segment Number:",xSegmentPacketHeader.ucSeg_num);
		 
		  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
		           "<SMSU_ComposeMessage>Segment Size:",xSegmentPacketHeader.ucSegmentSize);

		  pcPrimitiveMesg += sizeof(x_IFX_DECT_SMSU_SendReqUpper);
		  xSegmentPacketHeader.ucSegmentSize -= sizeof(x_IFX_DECT_SMSU_SendReqUpper);
		  
                  memcpy(&vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper,
                         pcPrimitiveMesg,sizeof(x_IFX_DECT_SMSU_DataBlock_Upper));
                  pcPrimitiveMesg += sizeof(x_IFX_DECT_SMSU_DataBlock_Upper);
		  
                  xSegmentPacketHeader.ucSegmentSize -= sizeof(x_IFX_DECT_SMSU_DataBlock_Upper);

                  memcpy(vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents+
                         ((xSegmentPacketHeader.ucSeg_num-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN),
                         pcPrimitiveMesg,xSegmentPacketHeader.ucSegmentSize);
		  
		  IFX_DECT_SMSU_ComposeSegAck(xSegmentPacketHeader.ucSeg_num+1,
				              0/*ucAsmStatus*/,0/*ucFailReason*/,&xSegAck);
       
                  IFX_DECT_SMSU_ComposeSendRsp(eFailReason/*0*/,1/*eStatus*/,&xSendRsp); //How to obtain para1 and 2?
                  IFX_DECT_SMSU_memcat(2,vxSMSInfo[ucHandSet-1].acBuff,&iReplyLen,
                                       &xSendRsp,sizeof(x_IFX_DECT_SMSU_SendRsp),
                                       &xSegAck,sizeof(x_IFX_DECT_SMSU_SegAck));
                  *(vxSMSInfo[ucHandSet-1].acBuff+iReplyLen)= '\0';

		}else{ 

		  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
		           "<SMSU_ComposeMessage>Segment Number:",xSegmentPacketHeader.ucSeg_num);
		 
		  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
		           "<SMSU_ComposeMessage>Segment Size:",xSegmentPacketHeader.ucSegmentSize);
		  
                  memcpy(vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents+
                         ((xSegmentPacketHeader.ucSeg_num-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN
			 -sizeof(x_IFX_DECT_SMSU_DataBlock_Upper)-sizeof(x_IFX_DECT_SMSU_SendReqUpper)),
                         pcPrimitiveMesg,xSegmentPacketHeader.ucSegmentSize);
		  
		  IFX_DECT_SMSU_ComposeSegAck(xSegmentPacketHeader.ucSeg_num+1,0/*ucAsmStatus*/,0/*ucFailReason*/,&xSegAck);
       
                  memcpy(vxSMSInfo[ucHandSet-1].acBuff,&xSegAck,sizeof(x_IFX_DECT_SMSU_SegAck));
		  iReplyLen = sizeof(x_IFX_DECT_SMSU_SegAck);
                 } 
	         if(EncodeIWU_SMS(((char8 *)vxSMSInfo[ucHandSet-1].acBuff),iReplyLen,((char8 *)xIpcReply.acData)) == IFX_FAILURE){
                   
		   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		            "<SMSU_ComposeMessage>EncodeIWU_SMS Failed.");
                   return IFX_FAILURE;
                 }
                 IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
                                       0/*ucSignal*/,&xIpcReply);

#ifdef IFX_SMSU_STUB
                 IFX_DECT_SMSU_STUB_PostToStub(&xIpcReply);
#else
                 IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
#endif	
       
	      }else if(xSegmentPacketHeader.ucSbit == IFX_DECT_SMSU_LAST_SEGMENT){

                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			 "<SMSU_ComposeMessage>Last Segment.");

                IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
		           "<SMSU_ComposeMessage>Segment Number:",xSegmentPacketHeader.ucSeg_num);
		 
		  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
		           "<SMSU_ComposeMessage>Segment Size:",xSegmentPacketHeader.ucSegmentSize);
  		  
                memcpy(vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents+
                       ((xSegmentPacketHeader.ucSeg_num-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN
	               -sizeof(x_IFX_DECT_SMSU_DataBlock_Upper)-sizeof(x_IFX_DECT_SMSU_SendReqUpper)),
                       pcPrimitiveMesg,xSegmentPacketHeader.ucSegmentSize-sizeof(x_IFX_DECT_SMSU_DataBlock_Lower));

                memcpy(&vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower,
                       (pcPrimitiveMesg+xSegmentPacketHeader.ucSegmentSize-sizeof(x_IFX_DECT_SMSU_DataBlock_Lower)),
                       sizeof(x_IFX_DECT_SMSU_DataBlock_Lower));
 
                IFX_DECT_SMSU_ComposeSegAck(0,0/*ucAsmStatus*/,0/*ucFailReason*/,&xSegAck);

                IFX_DECT_SMSU_FillMessage(ucHandSet,&xMesg);//Check Fail.
		
                eRet = xAppCallBks.pfnMesgSend(ucHandSet,xMesg,&vxSMSInfo[ucHandSet-1].ucMesgIndex,
				                    &eFailReason);

		switch(eRet){
         
		  case IFX_SUCCESS:
           
                      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			                         "<SMSU_ComposeMessage>CB MesgSend Successful.");
		      
                      memcpy(vxSMSInfo[ucHandSet-1].acBuff,&xSegAck,sizeof(x_IFX_DECT_SMSU_SegAck));
                      iReplyLen = sizeof(x_IFX_DECT_SMSU_SegAck);
		      
                      if(EncodeIWU_SMS(((char8 *)vxSMSInfo[ucHandSet-1].acBuff),iReplyLen,((char8 *)xIpcReply.acData)) == IFX_FAILURE){
               
			                  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				                         "<SMSU_ComposeMessage>EncodeIWU_SMS Failed.");
                        return IFX_FAILURE;
                      } 
                      IFX_DECT_EncodeCCInfo(ucHandSet, vxSMSInfo[ucHandSet-1].ucInstance,
                                            0/*ucSignal*/,&xIpcReply);
 
#ifdef IFX_SMSU_STUB
                      IFX_DECT_SMSU_STUB_PostToStub(&xIpcReply);
#else
                      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
#endif
                      break;

                  case IFX_PENDING:

                      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			                         " <SMSU_ComposeMessage>CB MesgSend Pending.");

                      return IFX_SUCCESS;
                      break;
 
                  case IFX_FAILURE:
           
                      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
			                         "<SMSU_ComposeMessage>CB MesgSend Failed.");

                      IFX_DECT_SMSU_MesgRspSend(ucHandSet,vxSMSInfo[ucHandSet-1].ucMesgIndex,IFX_DECT_SMSU_READ,
                                               IFX_DECT_SMSU_NETWORK_ERROR);//Ask
                      return IFX_SUCCESS;
                      break;
   
                  default: return IFX_FAILURE;
		}	   
               }
       	       break;

          default:
          
              return IFX_FAILURE;	  

        }		
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "<SMSU_ComposeMessage>ComposeMessage Successful.");
  return IFX_SUCCESS;
}

//**************************************************************************************************

/*! \brief IFX_DECT_SMSU_NotifyUnread is used to Notify PT about Unread Messages.
    \param[in] ucHandSet Handset Number.
    \param[in] ucUnread Number of Unread Messages.
    \return  IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_SMSU_NotifyUnread(IN uchar8 ucHandSet,IN uchar8 ucUnread){

  x_IFX_DECT_IPC_Msg xIpcReply = {0};
  x_IFX_DECT_SMSU_Notify xNotify = {0};

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_NotifyUnread>NotifyUnread Entry."); 

  IFX_DECT_SMSU_ComposeNotify(ucUnread,&xNotify);
  if(EncodeIWU_SMS((char8*)&xNotify,sizeof(x_IFX_DECT_SMSU_Notify),((char8 *)xIpcReply.acData)) == IFX_FAILURE){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_NotifyUnread>EncodeIWU_SMS Failed."); 
    return IFX_FAILURE;  
  }

  IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
                        0/*ucSignal*/,&xIpcReply);

  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);

  if(IFX_DECT_SMSU_SendRelease(ucHandSet,0/*ucReason*/,0/*uiIEHdl*/) == IFX_FAILURE){
    return IFX_FAILURE;
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_NotifyUnread>NotifyUnread Successful."); 
  return IFX_SUCCESS;

}

/*! \brief To encode an sms primitive into an IWU-IWU message.
    \param[in] pcIWU_Data pointer to SMS primitive.
    \param[in] iIWU_DataLen Length of SMS primitive.
    \param[in] pcIWU_String pointer to IWUTOIWU IE.
    \return  IFX_SUCCESS or IFX_FAILURE.
 */

e_IFX_Return EncodeIWU_SMS(char8 *pcIWU_Data,int32 iIWU_DataLen,char8 *pcIWU_String){

  x_IFX_DECT_IE_IWUToIWU xIWU_Mesg = {0};
  int32 i = 0;
  uchar8 ucOctet4_Bit8 = 1;
  char8 ucDiscType = 1;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"<EncodeIWU_SMS>In Api EncodeIWU_SMS.");

  for(i = 0;i < iIWU_DataLen ;i ++){
     printf("\n<EncodeIWU_SMS>pcIWU_Data[%d]=%x:%c",i,pcIWU_Data[i],pcIWU_Data[i]);
  }

  xIWU_Mesg.ucSR = 1;
  xIWU_Mesg.ucPD = 0;
  xIWU_Mesg.ucDefault1 = 1;
  xIWU_Mesg.ucIWUToIWULen = iIWU_DataLen + 4;
  xIWU_Mesg.acIWUToIWU[0] = ucOctet4_Bit8;
  xIWU_Mesg.acIWUToIWU[0] <<= 7/*SEVEN*/;
  xIWU_Mesg.acIWUToIWU[0] |= ucDiscType;
  xIWU_Mesg.acIWUToIWU[1] = 0x00;//EMC HIGH.
  xIWU_Mesg.acIWUToIWU[2] = 0xC0;//EMC LOW.
  xIWU_Mesg.acIWUToIWU[3] = 1;//Proprietary Type SMS=1
  memcpy((char*)&xIWU_Mesg.acIWUToIWU[4],(char*)pcIWU_Data,iIWU_DataLen);
  
/*	for(i = 0;i < xIWU_Mesg.ucIWUToIWUInfoLen ;i ++){
     printf("\nxIWU_Mesg.acIWUToIWUInfo[%d]=%x:%c",i,xIWU_Mesg.acIWUToIWUInfo[i],xIWU_Mesg.acIWUToIWUInfo[i]);
  }*/
#ifdef IFX_SMSU_STUB
	/*  Ignore first 10 bytes of IPC msg ((struct)HLI_Header)+2 */
  if(IFX_DECT_IE_IEAdd((uint32)(pcIWU_String+10),IFX_DECT_IE_IWUTOIWU,(void *)&xIWU_Mesg) == IFX_FAILURE){
#else
  if(IFX_DECT_IE_IEAdd((uint32)pcIWU_String,IFX_DECT_IE_IWUTOIWU,(void *)&xIWU_Mesg) == IFX_FAILURE){
#endif
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_EncodeIWU_SMS>IEAdd Failed.");
    return IFX_FAILURE;
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	   "<SMSU_EncodeIWU_SMS>EncodeIWU_SMS Successful.");
  return IFX_SUCCESS;
}
/*! \brief IFX_DECT_SMSU_FetchPrimitive is used to extract SMS Primitive from IWUTOIWU IE in IPC Message.
    \param[in] pxIpcMsg pointer to IPC Message.
    \param[OUT} pcSMS_Primitive pointer to SMS Primitive.
    \param[OUT} piPrimitiveSize pointer to SMS Primitive size.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_SMSU_FetchPrimitive(IN x_IFX_DECT_IPC_Msg *pxIpcMsg,
                                          OUT char8 *pcSMS_Primitive,
                                          OUT int32 *piPrimitiveSize){
  uint32 uiIEHdl = 0;
  e_IFX_Return eRet = IFX_SUCCESS;
  x_IFX_DECT_IE_IWUToIWU xIWU_Mesg = {0};

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	   "<SMSU_FetchPrimitive>In Api FetchPrimitive."); 

  if(0 == (uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIpcMsg)) ){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
	     "<SMSU_FetchPrimitive>No IE found");
     return IFX_FAILURE;
   }

  while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_IWUTOIWU){
    if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		"<SMSU_FetchPrimitive>NextIEHandlerGet Failed.");

       eRet = IFX_FAILURE;
       break;
    }
  }
  

  if(IFX_SUCCESS == eRet){
    IFX_DECT_IE_IWUToIWUGet(uiIEHdl,&xIWU_Mesg);
		printf("xIWU_Mesg.ucIWUToIWUInfoLen=%d\n",xIWU_Mesg.ucIWUToIWULen);
    *piPrimitiveSize = xIWU_Mesg.ucIWUToIWULen-4/*4 octets of IWUTOIWU after length*/;
    /*for(i  = 4;i <*piPrimitiveSize +4; i++){
       printf("xIWU_Mesg.acIWUToIWUInfo[%d]=%x",i,xIWU_Mesg.acIWUToIWUInfo[i]);
    }*/
    memcpy(pcSMS_Primitive,xIWU_Mesg.acIWUToIWU+4/*acIWUToIWUInfo[4] onwards contains primitive*/,*piPrimitiveSize);
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_FetchPrimitive>FetchPrimitive Successful."); 
  }
  return eRet;

}


//***************************************APIs Defined Here************************************************

/*! \brief To send out a Setup request to the stack.
    \param[in] ucHandSet Handset Number.
    \param[in] uiIEHdl Information Element handle.
    \param[in] bWideband boolean value to indicate a wideband call.
    \return IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_DECT_SMSU_SendSetup(IN uchar8 ucHandSet,IN uint32 uiIEHdl,IN boolean bWideband){//Need Wideband¿

  uint32 uiDIEHdl = 0;
  x_IFX_DECT_IPC_Msg xIpcSetup={0};

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_SendSetup>Entry."); 
  
  if((ucHandSet ==0)||(ucHandSet >6)||
      (vxSMSInfo[ucHandSet-1].eSMS_State != IFX_DECT_SMSU_IDLE)||
      (IFX_DECT_MU_IsHandSetBusy(ucHandSet) == IFX_SUCCESS)){

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_SendSetup>handset number invalid or state not IDLE or handset busy."); 	  
    return IFX_FAILURE;
  }

  if(IFX_DECT_MU_IsCallExisting(ucHandSet,((uchar8 *)&vxSMSInfo[ucHandSet-1].ucInstance))== IFX_SUCCESS)//Check Para2.
  {
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_SendSetup>call already existing,state turned to ACTIVE."); 	  
    vxSMSInfo[ucHandSet-1].eSMS_State = IFX_DECT_SMSU_ACTIVE;
    if(IFX_DECT_MU_SetModuleOwner(ucHandSet,IFX_DECT_MU_ADD_OWNER,IFX_DECT_SMSU_ID) == IFX_FAILURE){
      
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_SendSetup>SMSU not made module owner."); 	    
      return IFX_FAILURE;
    } 
  }else{

    if(IFX_DECT_MU_SetModuleOwner(ucHandSet,IFX_DECT_MU_ADD_OWNER,IFX_DECT_SMSU_ID)
                                  == IFX_SUCCESS){
        
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_SendSetup>SMSU made module owner."); 
      
      vxSMSInfo[ucHandSet-1].ucInstance = IFX_DECT_GetMCEI(ucHandSet-1);//Check Block or Get.Check Success/Fail.
      vxSMSInfo[ucHandSet-1].eSMS_State = IFX_DECT_SMSU_TRANSIENT;
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_SendSetup>state turned to TRANSIENT."); 
      IFX_DECT_EncodeSetup(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
          0/*bWideband*/,IFX_DECT_SERVICE_CALL,0xFF,&xIpcSetup);

      if(uiIEHdl != 0){
         uiDIEHdl = IFX_DECT_IE_GetIEHandler(&xIpcSetup);
          if(IFX_DECT_IE_IEAppend(uiDIEHdl,uiIEHdl) == IFX_FAILURE){

	    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_SendSetup>IEAppend failed."); 	  
            return IFX_FAILURE;
          }
      }
      return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcSetup);
    }
   }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_SendSetup>SendSetup successful."); 
  return IFX_SUCCESS;
}

/*! \brief To send release message to the stack.
    \param[in] ucHandSet Handset Number.
    \param[in] ucReason Reason for release.
    \param[in] uiIEHdl Information Element Hande.
    \return  IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_SMSU_SendRelease(IN uchar8 ucHandSet,IN uchar8 ucReason,
                                       IN uint32 uiIEHdl){

  uint32 uiDIEHdl = 0;
  x_IFX_DECT_IPC_Msg xIpcRelease={0};

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_SendRelease>Entry."); 
  if((ucHandSet ==0)||(ucHandSet >6)||
      (vxSMSInfo[ucHandSet-1].eSMS_State != IFX_DECT_SMSU_ACTIVE)){
	
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_SendRelease>handset number invalid or state not ACTIVE or handset busy."); 	  
    return IFX_FAILURE;

  }else{

    if(IFX_DECT_MU_CanCallBeReleased(ucHandSet) == IFX_SUCCESS){
       
      vxSMSInfo[ucHandSet-1].eSMS_State=IFX_DECT_SMSU_IDLE;
      IFX_DECT_EncodeRelease(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
                             ucReason,&xIpcRelease);

      if(uiIEHdl != 0){
         uiDIEHdl = IFX_DECT_IE_GetIEHandler(&xIpcRelease);
          if(IFX_DECT_IE_IEAppend(uiDIEHdl,uiIEHdl) == IFX_FAILURE){
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_SendRelease>IEAppend failed."); 		  
            return IFX_FAILURE;
          }
      }
      IFX_DECT_FreeMCEI(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance);
      IFX_DECT_SMSU_ReleaseResources(ucHandSet);
      IFX_DECT_MU_SetModuleOwner(ucHandSet,IFX_DECT_MU_REMOVE_OWNER,IFX_DECT_SMSU_ID);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcRelease);
 
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_SendRelease>SendRelease Successful."); 
      return IFX_SUCCESS;
    }
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "<SMSU_SendRelease>Call cannot be released."); 
    return IFX_FAILURE;
   }
}

//#########################################################################################################

/*! \brief To concatenate two or more structures into a string(structures have all data
           members as characters).
    \param[in]
    \param[in]
    \param[in]
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_SMSU_memcat(int32 no_src,void *dest,int32 *destlen,const void *src1,int32 src1_len,
    const void* src2, int32 src2_len,...)
{

  va_list args;
  va_start(args,src2_len);
  *destlen=0;
  int32 srcn_len=0;
  void *srcn=NULL;
  void * begin=dest;

  memcpy(begin,src1,src1_len);
  begin=(char*)begin+src1_len;
  memcpy(begin,src2,src2_len);
  begin=(char*)begin+src2_len;
  *(destlen)=src1_len+src2_len;
  no_src=no_src-2;
  for(;no_src>0;--no_src)
  {

    srcn=va_arg(args,void *);
    srcn_len=va_arg(args,int);
    memcpy(begin,srcn,srcn_len);
    *destlen+=srcn_len;
    begin=(char*)begin+srcn_len;
    srcn=NULL;
    srcn_len=0;
  }
  va_end(args);
  return IFX_SUCCESS;
}

/*! \brief To get the timezone in terms of quarters(15 min. units) west of GMT.
    \param[in] pcQuarterWest Quarters west of GMT.
    \return IFX_SUCCESS or IFX_FAILURE.

 */

e_IFX_Return IFX_DECT_SMSU_GetTimeStamp(OUT x_IFX_DECT_SMSU_TimeStamp *pxMesgTimeStamp){

   time_t  theTime;
   struct tm *xt;
 
   theTime = time((time_t *) NULL);
   xt = localtime(&theTime);

   //printf("\nThe date is: %s\n",ctime(&theTime));

   pxMesgTimeStamp->ucYear = (xt->tm_year) + 1900;
   pxMesgTimeStamp->ucMonth = (xt->tm_mon)+1;/*gives 0-11*/
   pxMesgTimeStamp->ucDay = xt->tm_mday;
   pxMesgTimeStamp->ucHour = xt->tm_hour;
   pxMesgTimeStamp->ucMinute = xt->tm_min;
   pxMesgTimeStamp->ucSecond = xt->tm_sec;
   pxMesgTimeStamp->ucTimeZone = (xt->tm_gmtoff)/(60*15);/*In quarters of an hour*/
   
   return IFX_SUCCESS;
}
//*********************************************************************************************************




//..........................................ASYNC MODE FUNCTIONS...........................................

/*! \brief External API to the App called when a message is to be read.
  \param[in] ucHandset Handset Number.
  \param[in] ucMesgIndex Message Index.
  \param[in] eSendStatus Assembly status of message segments.
  \param[in] eReason Reason for failure.
  \return IFX_SUCCESS or IFX_FAILURE.
 */

e_IFX_Return IFX_DECT_SMSU_MesgRspSend(IN uchar8 ucHandSet,IN uchar8 ucMesgIndex,IN e_IFX_Return eStatus,
    IN e_IFX_DECT_SMSU_ReasonCode eReason)
{
  x_IFX_DECT_IPC_Msg xIpcReply = {0};
  x_IFX_DECT_SMSU_SendRsp xSendRsp = {0};
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"<SMSU_MesgRspSend>Entry.");
  
  IFX_DECT_SMSU_ComposeSendRsp(eReason,eStatus,&xSendRsp);//Check Fail..
  
  if(EncodeIWU_SMS((char8*)&xSendRsp,sizeof(xSendRsp),((char8 *)xIpcReply.acData)) == IFX_FAILURE){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"<SMSU_MesgRspSend>EncodeIWU_SMS Failed.");
    return IFX_FAILURE;
  }
  IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,0/*ucSignal*/,&xIpcReply);
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"<SMSU_MesgRspSend>Successful.");
  return IFX_SUCCESS;

}

/*! \brief  External API to the App called when a new message arrives for the PT.
    \param[in] ucHandset Handset Number.
    \param[in] ucUnread Number of unread messages.
    \return  IFX_SUCCESS or IFX_FAILURE

 */

e_IFX_Return IFX_DECT_SMSU_AlertSend(IN uchar8 ucHandSet,IN uchar8 ucUnread){

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"<SMSU_AlertSend>Entry.");
  
  if(IFX_DECT_SMSU_SendSetup(ucHandSet,0/*uiIEHdl*/,0/*bWideband*/) == IFX_FAILURE){
        
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "<SMSU_AlertSend>SendSetup failed.");
    return IFX_FAILURE;
  }
      
  if(vxSMSInfo[ucHandSet-1].eSMS_State == IFX_DECT_SMSU_ACTIVE){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	     "<SMSU_AlertSend>Call already established.Invoking NotifyUnread.");
    return IFX_DECT_SMSU_NotifyUnread(ucHandSet,ucUnread);
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"<SMSU_AlertSend>Successful.");
  return IFX_SUCCESS;

}

/*! \brief  External API to the App called when a message is deleted.
    \param[in] ucHandset Handset Number.
    \param[in] eMesgBox Inbox or Outbox.
    \param[in] ucMesgIndex Message Index.
    \param[in] eDeleteStatus Delete Status pending or failure.
    \param[in] eReason Reason for failure.
    \return  IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_DECT_SMSU_MesgRspDelete(IN uchar8 ucHandSet,IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                                        IN uchar8 ucMesgIndex,IN e_IFX_Return eDeleteStatus,
                                        IN e_IFX_DECT_SMSU_ReasonCode eReason){

  x_IFX_DECT_SMSU_DeleteRsp xDeleteRsp = {0};
  x_IFX_DECT_IPC_Msg xIpcReply = {0};

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"<SMSU_MesgRspDelete>Entry.");  
  xIpcReply.ucPara1 = ucHandSet;
 
  IFX_DECT_SMSU_ComposeDeleteRsp(eReason,eDeleteStatus,&xDeleteRsp);//Check Fail..

  if(EncodeIWU_SMS((char8 *)&xDeleteRsp,sizeof(xDeleteRsp),((char8 *)xIpcReply.acData)) == IFX_FAILURE){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"<SMSU_MesgRspDelete>EncodeIWU_SMS Failed.");
    return IFX_FAILURE; 
  }
  IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,0/*ucSignal*/,&xIpcReply);
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"<SMSU_MesgRspDelete>Successful.");
  return IFX_SUCCESS;
}

//########################################################################################################
e_IFX_Return IFX_DECT_SMSU_HdrsRspGet(IN uchar8 ucHandSet,IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                                       IN x_IFX_DECT_SMSU_HeaderBlock *pxHeaders,
                                       IN uchar8 ucHeaderCount){//Checksum nt a parameter?
  
  char8 acData[300] = "";
  int32 iReplyLen = 0;
  uchar8 ucDataRspSize = 0;
  uchar8 ucAllHeaders = 0;
 
  x_IFX_DECT_SMSU_DataRspUpper xDataRsp = {0};
  x_IFX_DECT_SMSU_SegmentPacketHeader xSegUpper = {0};
  x_IFX_DECT_IPC_Msg xIpcReply = {0};

  uchar8 ucDataRspHdrSize = 0;
 
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"<SMSU_HdrsRspGet>Entry.");
   vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucChecksum = 0;

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
            "<SMSU_HdrsRspGet>ucHeaderCount",ucHeaderCount);
   
   vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount = ucHeaderCount;
   memcpy(&vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[0],pxHeaders,
           sizeof(vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders));//check size..

   ucAllHeaders = sizeof(x_IFX_DECT_SMSU_HeaderBlock)*vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount;

   ucDataRspHdrSize = sizeof(x_IFX_DECT_SMSU_DataRspUpper) -1;
   vxSMSInfo[ucHandSet-1].ucBufLen = sizeof(uchar8/*ucHeaderCount*/)+sizeof(uchar8/*ucChecksum*/)+
                                            ucAllHeaders+ucDataRspHdrSize ;
   
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
            "<SMSU_HdrsRspGet>vxSMSInfo[ucHandSet-1].ucBufLen",
	    vxSMSInfo[ucHandSet-1].ucBufLen);
   
   if(vxSMSInfo[ucHandSet-1].ucBufLen > IFX_DECT_SMSU_MAX_SEG_DATALEN){

      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	       "<SMSU_HdrsRspGet>Segments Present.");	   
     IFX_DECT_SMSU_ComposeSeg(IFX_DECT_SMSU_MORE_SEGMENTS/*Sbit*/,1/*Seg_num*/,
                              IFX_DECT_SMSU_MAX_SEG_DATALEN,&xSegUpper);

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
              "<SMSU_HdrsRspGet>Segment Number",xSegUpper.ucSeg_num); 
     
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
              "<SMSU_HdrsRspGet>Segment Size",xSegUpper.ucSegmentSize);
     
     ucDataRspSize = vxSMSInfo[ucHandSet-1].ucBufLen-ucDataRspHdrSize;
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
            "<SMSU_HdrsRspGet>ucDataRspSize",ucDataRspSize);
     
     IFX_DECT_SMSU_ComposeDataRsp(IFX_DECT_SMSU_HEADERS,eMesgBox,0/*ucMesgIndex*/,
                                      ucDataRspSize,&xDataRsp);

     IFX_DECT_SMSU_memcat(4,vxSMSInfo[ucHandSet-1].acBuff,&iReplyLen,
		          &xDataRsp,sizeof(x_IFX_DECT_SMSU_DataRspUpper),
                          &vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount,sizeof(uchar8),
                          vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders,ucAllHeaders,
                          &vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucChecksum,sizeof(uchar8));

     *(vxSMSInfo[ucHandSet-1].acBuff+iReplyLen)='\0';
     iReplyLen = 0;
     IFX_DECT_SMSU_memcat(2,acData,&iReplyLen,
                           &xSegUpper,sizeof(x_IFX_DECT_SMSU_SegmentPacketHeader),
                           vxSMSInfo[ucHandSet-1].acBuff,xSegUpper.ucSegmentSize);
     *(acData+iReplyLen)='\0';
     
     if(EncodeIWU_SMS(acData,iReplyLen,((char8 *)xIpcReply.acData)) == IFX_FAILURE){
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		"<SMSU_HdrsRspGet>EncodeIWU_SMS Failed.");
       return IFX_FAILURE;
     }
     IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
                            0/*ucSignal*/,&xIpcReply);

   }else if(vxSMSInfo[ucHandSet-1].ucBufLen <= IFX_DECT_SMSU_MAX_SEG_DATALEN){

      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	       "<SMSU_HdrsRspGet>No Segments.");	   
      
      ucDataRspSize = vxSMSInfo[ucHandSet-1].ucBufLen;

      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
            "<SMSU_HdrsRspGet>ucDataRspSize",ucDataRspSize);
      
      IFX_DECT_SMSU_ComposeDataRsp(IFX_DECT_SMSU_HEADERS,eMesgBox,0/*ucMesgIndex*/,
                                      ucDataRspSize,&xDataRsp);

      IFX_DECT_SMSU_memcat(4,vxSMSInfo[ucHandSet-1].acBuff,&iReplyLen,
                               &xDataRsp,sizeof(x_IFX_DECT_SMSU_DataRspUpper),
                               &vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount,sizeof(uchar8),
                               vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders,ucAllHeaders,
                               &vxSMSInfo[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucChecksum,sizeof(uchar8));

      *(vxSMSInfo[ucHandSet-1].acBuff+iReplyLen)='\0';
      if(EncodeIWU_SMS(((char8 *)vxSMSInfo[ucHandSet-1].acBuff),iReplyLen,((char8 *)xIpcReply.acData)) == IFX_FAILURE){
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		 "<SMSU_HdrsRspGet>EncodeIWU_SMS Failed.");
      	IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
                                  0/*ucSignal*/,&xIpcReply);
    	}
		}
    return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);

}

e_IFX_Return IFX_DECT_SMSU_MesgRspGet(IN uchar8 ucHandSet,IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                                        IN uchar8 ucMesgIndex,IN x_IFX_DECT_SMSU_Mesg *pxMesg){

  int32 iReplyLen = 0;
  uchar8 ucMesgSize = 0;
  char8 acData[300] = "";
  uchar8 ucDataRspSize = 0;
  x_IFX_DECT_SMSU_SegmentPacketHeader xSegUpper = {0};
  x_IFX_DECT_SMSU_DataRspUpper xDataRsp = {0};
  x_IFX_DECT_IPC_Msg xIpcReply = {0};

  uchar8 ucDataRspHdrSize = 0;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	       "<SMSU_MesgRspGet>Entry.");
  
  memcpy(&vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock,pxMesg,sizeof(x_IFX_DECT_SMSU_Mesg));
  
  ucMesgSize = vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
	       "<SMSU_MesgRspGet>ucMesgSize",ucMesgSize);
  
  ucDataRspHdrSize = sizeof(x_IFX_DECT_SMSU_DataRspUpper);
  vxSMSInfo[ucHandSet-1].ucBufLen = ucMesgSize+sizeof(x_IFX_DECT_SMSU_DataBlock_Lower)
                         +sizeof(x_IFX_DECT_SMSU_DataBlock_Upper)+sizeof(x_IFX_DECT_SMSU_DataRspUpper) ;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
	   "<SMSU_MesgRspGet>vxSMSInfo[ucHandSet-1].ucBufLen",vxSMSInfo[ucHandSet-1].ucBufLen);
  
  if(vxSMSInfo[ucHandSet-1].ucBufLen > IFX_DECT_SMSU_MAX_SEG_DATALEN){
   
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	       "<SMSU_MesgRspGet>Segments Present.");	  
	  
    IFX_DECT_SMSU_ComposeSeg(IFX_DECT_SMSU_MORE_SEGMENTS/*Sbit*/,1/*Seg_num*/,
                             IFX_DECT_SMSU_MAX_SEG_DATALEN,&xSegUpper);

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
              "<SMSU_MesgRspGet>Segment Number",xSegUpper.ucSeg_num); 
     
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
              "<SMSU_MesgRspGet>Segment Size",xSegUpper.ucSegmentSize); 

    ucDataRspSize= vxSMSInfo[ucHandSet-1].ucBufLen -sizeof(x_IFX_DECT_SMSU_DataRspUpper) ;
    
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
	       "<SMSU_MesgRspGet>ucDataRspSize",ucDataRspSize);
    
    IFX_DECT_SMSU_ComposeDataRsp(IFX_DECT_SMSU_MESG,eMesgBox,ucMesgIndex,
                                        ucDataRspSize,&xDataRsp);

    IFX_DECT_SMSU_memcat(4,vxSMSInfo[ucHandSet-1].acBuff,&iReplyLen,
		           &xDataRsp,sizeof(x_IFX_DECT_SMSU_DataRspUpper),
                           &(vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper),
                           sizeof(x_IFX_DECT_SMSU_DataBlock_Upper),
                           vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents,ucMesgSize,
                           &vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower,
                           sizeof(x_IFX_DECT_SMSU_DataBlock_Lower));

    *(vxSMSInfo[ucHandSet-1].acBuff+iReplyLen)='\0';
    iReplyLen = 0;
    IFX_DECT_SMSU_memcat(2,acData,&iReplyLen,
                           &xSegUpper,sizeof(x_IFX_DECT_SMSU_SegmentPacketHeader),
                           vxSMSInfo[ucHandSet-1].acBuff,xSegUpper.ucSegmentSize);
    *(acData+iReplyLen)='\0';
    if(EncodeIWU_SMS(acData,iReplyLen,((char8 *)xIpcReply.acData)) == IFX_FAILURE){   
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	       "<SMSU_MesgRspGet>EncodeIWU_SMS Failed.");   
      return IFX_FAILURE;
    }
    IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,0/*ucSignal*/,&xIpcReply);

  }else if(vxSMSInfo[ucHandSet-1].ucBufLen <= IFX_DECT_SMSU_MAX_SEG_DATALEN){

	  
          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
	       "<SMSU_MesgRspGet>No Segments.");
       	  
          ucDataRspSize = vxSMSInfo[ucHandSet-1].ucBufLen;
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
	       "<SMSU_MesgRspGet>ucDataRspSize",ucDataRspSize);
	  
          IFX_DECT_SMSU_ComposeDataRsp(IFX_DECT_SMSU_MESG,eMesgBox,ucMesgIndex,ucDataRspSize,&xDataRsp);
          //vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize = ucMesgSize;

          IFX_DECT_SMSU_memcat(4,vxSMSInfo[ucHandSet-1].acBuff,&iReplyLen,
                &xDataRsp,sizeof(x_IFX_DECT_SMSU_DataRspUpper),
                &(vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper),sizeof(x_IFX_DECT_SMSU_DataBlock_Upper),
                vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents,ucMesgSize,
                &vxSMSInfo[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower,sizeof(x_IFX_DECT_SMSU_DataBlock_Lower));

            *(vxSMSInfo[ucHandSet-1].acBuff+iReplyLen)= '\0';

            if(EncodeIWU_SMS(((char8 *)vxSMSInfo[ucHandSet-1].acBuff),iReplyLen,((char8 *)xIpcReply.acData)) == IFX_FAILURE){
              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		                   "<SMSU_MesgRspGet>EncodeIWU_SMS Failed.");
              return IFX_FAILURE;
            }


            IFX_DECT_EncodeCCInfo(ucHandSet,vxSMSInfo[ucHandSet-1].ucInstance,
                                  0/*ucSignal*/,&xIpcReply);

   }
   return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcReply);
}
#endif



