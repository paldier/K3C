/**************************************************************************
**   FILE NAME     : IFX_DECT_ESU.c
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "IFX_DECT_Platform.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_ESU.h"
#include "IFX_DECT_StackIf.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_IEParser.h"
#include "IFX_DECT_MsgEncoder.h"
#define vxESUCallBks vxGlobalInfo.xESU.vxESUCallBks
#define vxESUInfo vxGlobalInfo.xESU.vxESUInfo

/*! \brief  Register Call Backs for CC procedures.
		\param[in] pxCCCallBks Incoming events from stack to application
	  \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_CallBksRegister(x_IFX_DECT_ESU_CallBks *pxCCCallBks)
{
  memcpy(&vxESUCallBks,pxCCCallBks,sizeof(x_IFX_DECT_ESU_CallBks));
  return IFX_SUCCESS;
}

/*! \brief  Send out CC_SETUP message out of dect stacks.
	  \param[in] pxCallParams Call Parameters
		\param[in] pcIE List of Optional Information Elements
      \param[in] iIELen Information Element Length
      \param[in] puiESUHdl pointer to Handle
	  \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_Setup(IN uchar8 ucHandsetNo,
                                    IN uint32 uiIEHdlr, 
                                    IN uint32 uiPrivateData)
{
    uint32 uiTmpIEHdlr =0;
	uchar8 ucBasicService,ucCallClass;
		
    if((ucHandsetNo ==0)||(ucHandsetNo >6)||
       (vxESUInfo[ucHandsetNo-1].eState != IFX_DECT_ESU_IDLE)||
	   (IFX_DECT_MU_IsHandSetBusy(ucHandsetNo) == IFX_SUCCESS)){

       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              " Handset has reached the maximum calls supported or wrong parameters");
     return IFX_FAILURE;
   }
   if( IFX_DECT_MU_IsCallExisting(ucHandsetNo,((uchar8 *)&vxESUInfo[ucHandsetNo-1].ucInstance))== IFX_SUCCESS){
     vxESUInfo[ucHandsetNo-1].eState = IFX_DECT_ESU_PENDING;
     IFX_DECT_MU_SetModuleOwner(ucHandsetNo,IFX_DECT_MU_ADD_OWNER,IFX_DECT_ESU_ID);
     if(vxESUCallBks.pfn_ESU_LinkExists != NULL){
       return vxESUCallBks.pfn_ESU_LinkExists(uiPrivateData);
     }
   }else{
     x_IFX_DECT_IPC_Msg xIPCMsg={0};
	 x_IFX_DECT_IE_BasicService xBasicServ={0};
	 x_IFX_DECT_IE_CodecList xCodecList={0};
	 uint32 uiCallType =0;
	 char8 bWideband =-1;
     if(IFX_DECT_MU_SetModuleOwner(ucHandsetNo,IFX_DECT_MU_ADD_OWNER,IFX_DECT_ESU_ID)
        == IFX_SUCCESS){
       vxESUInfo[ucHandsetNo-1].ucInstance = IFX_DECT_GetMCEI(ucHandsetNo); 
       vxESUInfo[ucHandsetNo-1].uiPrivateData = uiPrivateData;
	   uiTmpIEHdlr = uiIEHdlr;
	   while(IFX_DECT_IE_TypeGet(uiIEHdlr) != IFX_DECT_IE_BASICSERVICE ){
	     IFX_DECT_IE_NextIEHandlerGet(&uiIEHdlr);  
	   }
       if( uiIEHdlr != 0){
	     IFX_DECT_IE_BasicServiceGet(uiIEHdlr,&xBasicServ);
		 //uiCallType = *(((char8 *)&xBasicServ)+1); /*get call class and basic service*/
		 ucBasicService = xBasicServ.ucBasicService;
		 ucCallClass = xBasicServ.ucCallClass;
		 uiCallType = ((ucCallClass << 4) | ucBasicService);
		 IFX_DECT_IE_Remove(uiTmpIEHdlr,IFX_DECT_IE_BASICSERVICE);
	   }
	   uiIEHdlr = uiTmpIEHdlr;
	   while(IFX_DECT_IE_TypeGet(uiIEHdlr) != IFX_DECT_IE_CODECLIST ){
	     IFX_DECT_IE_NextIEHandlerGet(&uiIEHdlr);  
	   }
       if( uiIEHdlr != 0){
         IFX_DECT_IE_CodecListGet(uiIEHdlr, &xCodecList);
		 if(xCodecList.xCodecListSS[0].ucCIdf == 3){
		   bWideband = 1;
		 }else{
		   bWideband = 0;
		 }
		 IFX_DECT_IE_Remove(uiTmpIEHdlr,IFX_DECT_IE_CODECLIST);
       }
		
       IFX_DECT_EncodeSetup(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance,
                           bWideband,
                           uiCallType,
													 0xFF,
                           &xIPCMsg);
       uiTmpIEHdlr = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
	   IFX_DECT_IE_IEAppend(uiTmpIEHdlr,uiIEHdlr);
       vxESUInfo[ucHandsetNo-1].eState = IFX_DECT_ESU_PENDING;
       return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
     }
   }
   
   return IFX_FAILURE;
}


/*! \brief  Send out CC_SETUP_ACK message out of dect stack for Data Applications.
	  \param[in] ucHandSetNo Hand set number 
		\param[in] iRingType RING PATTERN Number(if required to send ), if not required fill with 0xFF
		\param[in] pcIE List of Optional Information Elements
	  \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_SetupAck(IN uchar8 ucHandsetNo,
                                       IN uint32 uiIEHdl)
{
    
    if((ucHandsetNo ==0)||(ucHandsetNo >6)||
		(vxESUInfo[ucHandsetNo-1].eState != IFX_DECT_ESU_PENDING)){

       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "  wrong parameters or in wrong state");
     return IFX_FAILURE;
   }else{
      x_IFX_DECT_IPC_Msg xIPCMsg={0};
      IFX_DECT_EncodeSetupAck(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance,
                              &xIPCMsg);
	  if( uiIEHdl != 0){						  
	   uint32 uiTmpIEHdlr=0;
       uiTmpIEHdlr = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
       IFX_DECT_IE_IEAppend(uiTmpIEHdlr,uiIEHdl);
	  }
      return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
   }

}
	
/*! \brief  Send out Call Alert.
	  \param[in] ucHandSetNo Hand set number
		\param[in] pcIE List of Optional Information Elements
	  \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_Alert(IN uchar8 ucHandsetNo,
                              IN uint32 uiIEHdl)
{
    if((ucHandsetNo ==0)||(ucHandsetNo >6)||
		(vxESUInfo[ucHandsetNo-1].eState != IFX_DECT_ESU_PENDING)){

       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "  wrong parameters or in wrong state");
     return IFX_FAILURE;
   }else{
      x_IFX_DECT_IPC_Msg xIPCMsg={0};
      IFX_DECT_EncodeAlert(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance,
                              &xIPCMsg);
	  if( uiIEHdl != 0){						  
	    uint32 uiTmpIEHdlr=0;
        uiTmpIEHdlr = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
        IFX_DECT_IE_IEAppend(uiTmpIEHdlr,uiIEHdl);
	  }
      return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
   }   
}

/*! \brief  Send out Call in progress
	  \param[in] ucHandSetNo Handset number
		\param[in] pcIE List of Optional Information Elements
	  \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_Proceed(IN uchar8 ucHandsetNo,
                                   IN uint32 uiIEHdl)
{
    if((ucHandsetNo ==0)||(ucHandsetNo >6)||
		(vxESUInfo[ucHandsetNo-1].eState != IFX_DECT_ESU_PENDING)){

       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "  wrong parameters or in wrong state");
     return IFX_FAILURE;
   }else{
      x_IFX_DECT_IPC_Msg xIPCMsg={0};
      IFX_DECT_EncodeCallProc(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance,
                              &xIPCMsg);
	  if( uiIEHdl != 0){						  
	    uint32 uiTmpIEHdlr=0;
        uiTmpIEHdlr = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
        IFX_DECT_IE_IEAppend(uiTmpIEHdlr,uiIEHdl);
	  }
      return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg); 
   }
}

/*! \brief  Send out Call Connect.
	  \param[in] pxCallParams Call Parameters Optional parameter
		\param[in] pcIE List of Optional Information Elements
	  \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_Connect(IN uchar8 ucHandsetNo,
                                      IN uint32 uiIEHdl)
{
   if((ucHandsetNo ==0)||(ucHandsetNo >6)||
	   (vxESUInfo[ucHandsetNo-1].eState != IFX_DECT_ESU_PENDING)){

       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "  wrong parameters or in wrong state");
     return IFX_FAILURE;
   }else{
      x_IFX_DECT_IPC_Msg xIPCMsg={0};
	  uint32 uiTmpIEHdlr=uiIEHdl;
	  x_IFX_DECT_IE_CodecList xCodecList={0};
	  char8 bWideband =-1;
	  while(IFX_DECT_IE_TypeGet(uiTmpIEHdlr) != IFX_DECT_IE_CODECLIST ){
	     IFX_DECT_IE_NextIEHandlerGet(&uiTmpIEHdlr);  
	   }
       if( uiTmpIEHdlr != 0){
         IFX_DECT_IE_CodecListGet(uiTmpIEHdlr, &xCodecList);
		 if(xCodecList.xCodecListSS[0].ucCIdf == 3){
		   bWideband = 1;
		 }else{
		   bWideband = 0;
		 }
		 IFX_DECT_IE_Remove(uiTmpIEHdlr,IFX_DECT_IE_CODECLIST);
       }

      IFX_DECT_EncodeConnect(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance,
                             bWideband,&xIPCMsg);
	  if( uiIEHdl != 0){						  
        uiTmpIEHdlr = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
        IFX_DECT_IE_IEAppend(uiTmpIEHdlr,uiIEHdl);
	  }
      return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg); 
   }
        
}


/*! \brief  Send out Call Connect Ack.
	  \param[in] ucHandSetNo Hand set number
		\param[in] pcIE List of Optional Information Elements
	  \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_ConnectAck(IN uchar8 ucHandsetNo,
                                      IN uint32 uiIEHdl)
{
   if((ucHandsetNo ==0)||(ucHandsetNo >6)||
	   (vxESUInfo[ucHandsetNo-1].eState != IFX_DECT_ESU_ACTIVE)){

       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "  wrong parameters or in wrong state");
     return IFX_FAILURE;
   }else{
      x_IFX_DECT_IPC_Msg xIPCMsg={0};
      IFX_DECT_EncodeConnectAck(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance,
                                &xIPCMsg);
	  if( uiIEHdl != 0){						  
	    uint32 uiTmpIEHdlr=0;
        uiTmpIEHdlr = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
        IFX_DECT_IE_IEAppend(uiTmpIEHdlr,uiIEHdl);
	  }
      return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
   }
}
/*! \brief  Send out Call Info
	  \param[in] ucHandSetNo Hand set number
		\param[in] iRingType RING PATTERN Number(if required to send ), if not required fill with 0xFF
		\param[in] pcIE List of Optional Information Elements
	  \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_CCInfo(IN uchar8 ucHandsetNo,
                                  IN uint32 uiIEHdl)
{
   if((ucHandsetNo ==0)||(ucHandsetNo >6)||
	   (vxESUInfo[ucHandsetNo-1].eState >= IFX_DECT_ESU_PENDING)){

       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "  wrong parameters or in wrong state");
     return IFX_FAILURE;
   }else{
      x_IFX_DECT_IPC_Msg xIPCMsg={0};
      IFX_DECT_EncodeCCInfo(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance,
                            0,&xIPCMsg);
	  if( uiIEHdl != 0){						  
	    uint32 uiTmpIEHdlr=0;
        uiTmpIEHdlr = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
        IFX_DECT_IE_IEAppend(uiTmpIEHdlr,uiIEHdl);
	  }
      return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
   }
}


/*! \brief  Send out Call Release
	  \param[in] ucHandSetNo Handset number
		\param[in] iReason Reason for Call Release
		\param[in] pcIE List of Optional Information Elements
	  \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_Release(IN uchar8 ucHandsetNo,
	                              IN uint32 uiIEHdl,
                                  IN e_IFX_DECT_RelType eReason)
{
   if((ucHandsetNo ==0)||(ucHandsetNo >6)||
	   (vxESUInfo[ucHandsetNo-1].eState != IFX_DECT_ESU_ACTIVE)){

       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "  wrong parameters or in wrong state");
     return IFX_FAILURE;
   }else{
      x_IFX_DECT_IPC_Msg xIPCMsg={0};
      IFX_DECT_EncodeRelease(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance,
                             eReason,&xIPCMsg);

	  if( uiIEHdl != 0){						  
	    uint32 uiTmpIEHdlr=0;
        uiTmpIEHdlr = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
        IFX_DECT_IE_IEAppend(uiTmpIEHdlr,uiIEHdl);
	  }
      vxESUInfo[ucHandsetNo-1].eState=IFX_DECT_ESU_IDLE;
      vxESUInfo[ucHandsetNo-1].uiPrivateData =0;
      if(IFX_DECT_MU_CanCallBeReleased(ucHandsetNo)==IFX_SUCCESS){
        IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
        IFX_DECT_FreeMCEI(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance);
      }
      IFX_DECT_MU_SetModuleOwner(ucHandsetNo,IFX_DECT_MU_REMOVE_OWNER,IFX_DECT_ESU_ID);
   }
   return IFX_SUCCESS;
}

 
/*! \brief  Send IWU Information to PT
	  \param[in] ucHandSetNo Handset number
		\param[in] pcIE List of Information Elements
	  \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_IWUInfo(IN uchar8 ucHandsetNo,
                                      IN uint32 uiIEHdl)
{
   if((ucHandsetNo ==0)||(ucHandsetNo >6)||
	   (vxESUInfo[ucHandsetNo-1].eState != IFX_DECT_ESU_ACTIVE)){

       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "  wrong parameters or in wrong state");
     return IFX_FAILURE;
   }else{
      x_IFX_DECT_IPC_Msg xIPCMsg={0};
      IFX_DECT_EncodeIWUInfo(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance,
                             &xIPCMsg);
	  if( uiIEHdl != 0){						  
	    uint32 uiTmpIEHdlr=0;
        uiTmpIEHdlr = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
        IFX_DECT_IE_IEAppend(uiTmpIEHdlr,uiIEHdl);
	  }
      return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
  }   
}

/*! \brief  Send out Facility
    \param[in] iDataLen Data Length
    \param[in] pcIE Information Element
	  \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_Facility(IN uchar8 ucHandsetNo,
                                       IN uint32 uiIEHdl)
{
   uchar8 ucInstance=0;
   if((ucHandsetNo ==0)||(ucHandsetNo >6)){
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "  wrong parameters or in wrong state");
     return IFX_FAILURE;
   }
   if( IFX_DECT_MU_IsCallExisting(ucHandsetNo,((uchar8 *)&ucInstance))== IFX_SUCCESS){
     x_IFX_DECT_IPC_Msg xIPCMsg={0};
     IFX_DECT_EncodeFacility(ucHandsetNo,ucInstance,
                             &xIPCMsg);
	 if( uiIEHdl != 0){						  
	    uint32 uiTmpIEHdlr=0;
        uiTmpIEHdlr = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
        IFX_DECT_IE_IEAppend(uiTmpIEHdlr,uiIEHdl);
	  }
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
 
   }else{
     x_IFX_DECT_IPC_Msg xIPCMsg={0};
     ucInstance = IFX_DECT_GetMCEI(ucHandsetNo); 
     IFX_DECT_EncodeFacility(ucHandsetNo,ucInstance,
                             &xIPCMsg);
	  if( uiIEHdl != 0){						  
	    uint32 uiTmpIEHdlr=0;
        uiTmpIEHdlr = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
        IFX_DECT_IE_IEAppend(uiTmpIEHdlr,uiIEHdl);
	  }
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
      IFX_DECT_FreeMCEI(ucHandsetNo,ucInstance);
  } 
  return IFX_SUCCESS;
}

e_IFX_Return IFX_DECT_ESU_ProcessStackMsg(IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
   uchar8 ucHandsetNo = pxIpcMsg->ucPara1;
   e_IFX_Return eRet=IFX_SUCCESS;
   uint32 uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
   switch(pxIpcMsg->ucMsgId){
     case FP_SETUP_IN_CC:
       if(vxESUInfo[ucHandsetNo-1].eState == IFX_DECT_ESU_IDLE){
         if((eRet
		 =IFX_DECT_MU_SetModuleOwner(ucHandsetNo,IFX_DECT_MU_ADD_OWNER,IFX_DECT_ESU_ID))
             == IFX_SUCCESS){
           vxESUInfo[ucHandsetNo-1].ucInstance = pxIpcMsg->ucInstance;
           IFX_DECT_BlockMCEI(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance);
           vxESUInfo[ucHandsetNo-1].eState = IFX_DECT_ESU_PENDING;
           if(vxESUCallBks.pfn_ESU_Setup != NULL){
             eRet =
			 vxESUCallBks.pfn_ESU_Setup(ucHandsetNo,uiIEHdl,
                         &vxESUInfo[ucHandsetNo-1].uiPrivateData);
           }else{
           eRet = IFX_FAILURE;
		   }
         }
       }else{
           eRet = IFX_FAILURE;
       }
       break;
	 case FP_FACILITY_IN_CLSS:
	     if(vxESUCallBks.pfn_ESU_Facility != NULL){
             vxESUCallBks.pfn_ESU_Facility(ucHandsetNo,uiIEHdl);
         }
		 return IFX_SUCCESS;
         break; 
     case FP_ALERT_IN_CC:
       if(vxESUInfo[ucHandsetNo-1].eState == IFX_DECT_ESU_PENDING){
         if(vxESUCallBks.pfn_ESU_Alert != NULL){
             eRet= vxESUCallBks.pfn_ESU_Alert(ucHandsetNo,uiIEHdl,
                         vxESUInfo[ucHandsetNo-1].uiPrivateData);
         }
       }
       break;
     case FP_CONNECT_IN_CC:
       if(vxESUInfo[ucHandsetNo-1].eState == IFX_DECT_ESU_PENDING){
         if(vxESUCallBks.pfn_ESU_Connect != NULL){
             vxESUInfo[ucHandsetNo-1].eState = IFX_DECT_ESU_ACTIVE;
             eRet= vxESUCallBks.pfn_ESU_Connect(ucHandsetNo,uiIEHdl,
                         vxESUInfo[ucHandsetNo-1].uiPrivateData);
         }
      }
      break;
     case FP_INFO_IN_CC:
       if(vxESUInfo[ucHandsetNo-1].eState == IFX_DECT_ESU_ACTIVE){
         if(vxESUCallBks.pfn_ESU_CCInfo != NULL){
             eRet=vxESUCallBks.pfn_ESU_CCInfo(ucHandsetNo,uiIEHdl,
                         vxESUInfo[ucHandsetNo-1].uiPrivateData);
         }
       }
       break;
     case FP_RELEASE_IN_CC:
       if(vxESUInfo[ucHandsetNo-1].eState == IFX_DECT_ESU_ACTIVE){
         if(vxESUCallBks.pfn_ESU_Release != NULL){
            IFX_DECT_MU_SetModuleOwner(ucHandsetNo,IFX_DECT_MU_REMOVE_OWNER,IFX_DECT_ESU_ID);
            IFX_DECT_FreeMCEI(ucHandsetNo,vxESUInfo[ucHandsetNo-1].ucInstance);
            vxESUInfo[ucHandsetNo-1].eState=IFX_DECT_ESU_IDLE;
            eRet= vxESUCallBks.pfn_ESU_Release(ucHandsetNo,uiIEHdl,IFX_DECT_RELEASE_NORMAL,
                         vxESUInfo[ucHandsetNo-1].uiPrivateData);
            vxESUInfo[ucHandsetNo-1].uiPrivateData =0;
         }
       }
     case FP_IWU_INFO_IN_CC:
       if(vxESUInfo[ucHandsetNo-1].eState == IFX_DECT_ESU_ACTIVE){
         if(vxESUCallBks.pfn_ESU_IWUInfo != NULL){
             eRet = vxESUCallBks.pfn_ESU_IWUInfo(ucHandsetNo,uiIEHdl,
                         vxESUInfo[ucHandsetNo-1].uiPrivateData);
         }
       }
   }/* End of Switch*/
   if(eRet==IFX_FAILURE){
     return IFX_DECT_ESU_Release(ucHandsetNo,0,IFX_DECT_RELEASE_ABNORMAL);
   }
   return IFX_SUCCESS;
}


