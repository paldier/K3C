/*
 * =====================================================================================
 *
 *       Filename:  IFX_DECT_ESU_Main.h
 *
 *    Description:  Defines local function and structures used with and across DTK modules
 *
 *        Version:  1.0
 *        Created:  Wednesday 05 November 2008 11:06:37  IST
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Voice Team
 *        Company:  IFIN
 *
 * =====================================================================================
 */

typedef enum{
IFX_DECT_ESU_IDLE,
IFX_DECT_ESU_PENDING,
IFX_DECT_ESU_ACTIVE
}e_IFX_DECT_ESU_States;

typedef struct{
e_IFX_DECT_ESU_States eState;
uchar8 ucInstance;
uint32 uiPrivateData;
}x_IFX_DECT_ESU_Info;

e_IFX_Return IFX_DECT_ESU_ProcessStackMsg(x_IFX_DECT_IPC_Msg *pxIpcMsg);


