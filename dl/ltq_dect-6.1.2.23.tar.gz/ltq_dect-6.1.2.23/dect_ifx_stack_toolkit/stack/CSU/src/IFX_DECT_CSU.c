/**************************************************************************
**   FILE NAME     : IFX_DECT_CSU.c
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "IFX_DECT_Platform.h"

#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_StackIf.h"
#include "IFX_DECT_IEParser.h"

#define printf(...)
#define avxCCInfo vxGlobalInfo.xCSU.avxCCInfo
#define vxLauCallBks vxGlobalInfo.xLAU.vxLauCallBks
#define vxCSUCallBks vxGlobalInfo.xCSU.vxCSUCallBks
#define paxActCallHdl vxGlobalInfo.xCSU.paxActCallHdl
#define ucConfReqId vxGlobalInfo.xCSU.ucConfReqId
extern e_IFX_Return
IFX_DECT_LAU_HandleReleaseMsg(x_IFX_DECT_IPC_Msg *pxIPCMsg);
static unsigned int uiSlotType=0;
static unsigned char vucPassAllDigits2App=0;
#define IFX_DECT_CSU_ReleaseBothPPAndAPP(uiCallHdl,uiPrivateData) \
{ \
  x_IFX_DECT_CSU_CallParams xCallParams = {0}; \
  vxCSUCallBks.pfnCallRelease( \
                uiCallHdl, \
	            &xCallParams, \
	            IFX_DECT_RELEASE_NORMAL, \
		        uiPrivateData); \
  IFX_DECT_CSU_CallRelease( \
	            uiCallHdl, \
                &xCallParams, \
                IFX_DECT_RELEASE_NORMAL); \
}

/* Forward declarations */
e_IFX_Return 
IFX_DECT_CSU_EncodeCallInformation(IN uchar8 ucCallId1,
								   IN uchar8 ucCallStatus,
								   IN uchar8 ucCallReason,
                                   IN uchar8 ucCallId2,
								   IN uchar8 ucLineId,
								   IN uint32 uiHdl );
e_IFX_Return 
IFX_DECT_CSU_EncodeMultiDisplay(IN char8 *szString,
								   IN uint32 uiHdl );
e_IFX_Return 
IFX_DECT_CSU_GetCallHandleOfThePeer(IN uchar8 ucPeerHandsetId,
                                 IN x_IFX_DECT_CC_Info **pxCCInfo,
                                 IN uchar8 ucCallId);
e_IFX_Return 	
IFX_DECT_CSU_Fsm(IN uchar8 ucHexCode, 
                 IN x_IFX_DECT_IPC_Msg *pxIpcMsg,
				         x_IFX_DECT_CC_Info *pxCCInfo);
e_IFX_Return
IFX_DECT_CC_HandleParallelCall(uchar8 *pcRecvDigits,x_IFX_DECT_IPC_Msg *pxIpcMsg,
                 x_IFX_DECT_CC_Info *pxActiveCCInfo);
/************************************************************************
* Function Name  :IFX_DECT_CC_Config_PassAllMultikeypadDgts 
* Description    : This function enables the TK to send all Multikeypad events to Application. 
* Input Values   : ucStatus - Enable(1) or Disable (0) 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/

e_IFX_Return
IFX_DECT_CC_Config_PassAllMultikeypadDgts(uchar8 ucStatus)
{
	if ((ucStatus !=1) || (ucStatus !=0))
		return IFX_FAILURE;

	vucPassAllDigits2App=ucStatus;

	return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_CSU_AllocCCInfo
* Description    : This function creates a new CallControl Info
* Input Values   : pxCCInfo - pointer to a pointer of x_IFX_DECT_CC_Info type
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_CSU_GetActiveCallId(uchar8 ucHandset, uchar8 *pcCallId){
	if (ucHandset<1 || ucHandset>6)
   return IFX_FAILURE;
  if(paxActCallHdl[ucHandset-1] != NULL){
     *pcCallId = paxActCallHdl[ucHandset-1]->ucCallId;
     return IFX_SUCCESS;
   }
   return IFX_FAILURE;
} 
/************************************************************************
* Function Name  : IFX_DECT_CSU_AllocCCInfo
* Description    : This function creates a new CallControl Info
* Input Values   : pxCCInfo - pointer to a pointer of x_IFX_DECT_CC_Info type
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
int32 
IFX_DECT_CSU_AllocCCInfo(IN uchar8 ucHandsetId, 
						 IN x_IFX_DECT_CC_Info **pxCCInfo)
{
  uint16 j=0;
  *pxCCInfo = NULL;

	if (ucHandsetId<1 || ucHandsetId>6)
   return IFX_FAILURE;

  for(j=0;j<IFX_DECT_MAX_CALLS_PER_HS;j++){
    if((IFX_DECT_CS_IDLE == avxCCInfo[ucHandsetId-1][j].eState)||
       (IFX_DECT_CC_NOUPLANE == avxCCInfo[ucHandsetId-1][j].eState) ||
       (IFX_DECT_CC_UPLANE == avxCCInfo[ucHandsetId-1][j].eState)){
      *pxCCInfo = &avxCCInfo[ucHandsetId-1][j];
      //(*pxCCInfo)->eState = IFX_DECT_CS_IDLE;
      (*pxCCInfo)->unHwVoiceChannel = 0xFF;
      (*pxCCInfo)->ucPeerHandsetId = 0xFF;
	  (*pxCCInfo)->ucCallId = 0xFF;
	  (*pxCCInfo)->ucLineId = 0xFF;
	  (*pxCCInfo)->uiParaCallHdl=0;
     memset((*pxCCInfo)->acCLIP,0,IFX_DECT_MAX_CLIP);
     memset((*pxCCInfo)->acCNIP,0,IFX_DECT_MAX_CNIP);
      (*pxCCInfo)->uiSignal=0xFF;
      return j;
    }
  }
  return IFX_FAILURE;
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_ValidateCCInfo
* Description    : This function validated the CallControl Info
* Input Values   : pxCCInfo - pointer to x_IFX_DECT_CC_Info type
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_ValidateCCInfo(IN x_IFX_DECT_CC_Info *pxCCInfo)
{
  uint16 i=0, j=0;
  if(!pxCCInfo)
     return IFX_FAILURE;

  for(i=0;i<IFX_DECT_MAX_HS;i++){
    for(j=0;j<IFX_DECT_MAX_CALLS_PER_HS;j++){
      if(pxCCInfo == &avxCCInfo[i][j]){
        return IFX_SUCCESS;
      }
	}
  }
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					"Validate CC Info fails");
  return IFX_FAILURE;
}
/************************************************************************
* Function Name  : IFX_DECT_CSU_FreeCCInfo
* Description    : This function free the CallControl Info
* Input Values   : pxCCInfo - pointer to x_IFX_DECT_CC_Info type
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_FreeCCInfo(IN x_IFX_DECT_CC_Info *pxCCInfo)
{
  uchar8 ucCallId=0,ucLineId=0;
  uchar8 ucPeerHandsetId=0;
  char8 acCLIP[IFX_DECT_MAX_CLIP]; /*!< CLIP */
  char8 acCNIP[IFX_DECT_MAX_CNIP];/*!< CNIP */
  x_IFX_DECT_CC_Info *pxPeerCCInfo=NULL;
  //boolean bIsPresentation = 0;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
                  "Entry" );
  
  if(IFX_DECT_MU_CanCallBeReleased(pxCCInfo->ucHandsetId) == IFX_SUCCESS) {
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "Call can be released ");
    IFX_DECT_FreeMCEI(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId);

  }else{
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Cannot free the MCEI, since other module is using this handset.");
  }
  IFX_DECT_MU_SetModuleOwner(pxCCInfo->ucHandsetId,
     IFX_DECT_MU_REMOVE_OWNER,IFX_DECT_CSU_ID);

  /* If the call was released from app and there was only one call the activcall array need to reset*/
	{		
    uint32 uiModuleOwner = IFX_DECT_MU_GetModuleOwner(pxCCInfo->ucHandsetId);
	  if((uiModuleOwner == IFX_DECT_LAU_ID)||(uiModuleOwner == 0)){
	    paxActCallHdl[pxCCInfo->ucHandsetId-1] = NULL;
		}
	}

  ucCallId = pxCCInfo->ucCallId;
  ucLineId = pxCCInfo->ucLineId;
  strcpy(acCLIP,pxCCInfo->acCLIP);
  strcpy(acCNIP,pxCCInfo->acCNIP);
  ucPeerHandsetId = pxCCInfo->ucPeerHandsetId;

  /* To make sure we free the call id when both the legs of the internal call is freed
      We check if the peerCCinfo state is in idle and if not found based on the callid,
      we free the CCInfo. otherwice do not free, but shall get freed while freeing the peerha      ndset ccInfo 
   */
  if((pxCCInfo->eState != IFX_DECT_CS_CONF_CONNECT)||(pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_INITIATED)){
    if(pxCCInfo->isInternal == IFX_TRUE){
      if(IFX_DECT_CSU_GetCallHandleOfThePeer(ucPeerHandsetId,
                                 &pxPeerCCInfo,
                                 ucCallId) == IFX_SUCCESS){
        if(pxPeerCCInfo->eState == IFX_DECT_CS_IDLE){

           IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  "Internal call, peerhandset reached idle state, CallID Freed is",ucCallId);
           IFX_DECT_MU_FreeCallID(pxCCInfo->ucCallId);
        }
        }else{
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  "Internal call but no peerccinfo with this callid, CallID Freed is",ucCallId);
         IFX_DECT_MU_FreeCallID(pxCCInfo->ucCallId);
       }
     }else{ /* For External call just go ahead and free the callid*/
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                  "External call CallID Freed is",ucCallId);
         IFX_DECT_MU_FreeCallID(pxCCInfo->ucCallId);
     }
  }
  /* updating active callHdlr pointer*/
  {
    int j;
    for(j=0;j<IFX_DECT_MAX_CALLS_PER_HS;j++)
    {
       if(avxCCInfo[pxCCInfo->ucHandsetId-1][j].uiParaCallHdl == ((uint32)pxCCInfo))
       {
         avxCCInfo[pxCCInfo->ucHandsetId-1][j].uiParaCallHdl = 0;
         paxActCallHdl[pxCCInfo->ucHandsetId-1] =((x_IFX_DECT_CC_Info*)&avxCCInfo[pxCCInfo->ucHandsetId-1][j]);
         break;
       }  
    }
    if(j==2)
   {
     paxActCallHdl[pxCCInfo->ucHandsetId-1]=((x_IFX_DECT_CC_Info*)pxCCInfo->uiParaCallHdl);
   }  

  }
  if(pxCCInfo == &avxCCInfo[pxCCInfo->ucHandsetId-1][0]){
    uint32 uiModuleOwner = IFX_DECT_MU_GetModuleOwner(pxCCInfo->ucHandsetId);
	  if(uiModuleOwner & IFX_DECT_LAU_ID){
      //memset(pxCCInfo,0,sizeof(x_IFX_DECT_CC_Info));
      pxCCInfo->eState = IFX_DECT_CC_UPLANE;
      IFX_DECT_MU_SetModuleOwner(pxCCInfo->ucHandsetId,
                                 IFX_DECT_MU_ADD_OWNER,IFX_DECT_CSU_ID);
			return IFX_SUCCESS;
    }
  }else{
      memset(pxCCInfo,0,sizeof(x_IFX_DECT_CC_Info));
  }
  memset(pxCCInfo,0,sizeof(x_IFX_DECT_CC_Info));

  pxCCInfo->ucCallId=ucCallId;
  strcpy(pxCCInfo->acCLIP,acCLIP);
  strcpy(pxCCInfo->acCNIP,acCNIP);
  pxCCInfo->ucPeerHandsetId =ucPeerHandsetId;
  pxCCInfo->ucLineId=ucLineId;

  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				  "Freed CC Info");
  return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_CSU_FreeAllCCInfoOfThisHS
* Description    : This function free the CallControl Info
* Input Values   : pxCCInfo - pointer to x_IFX_DECT_CC_Info type
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_FreeAllCCInfoOfThisHS(IN uchar8 ucHandsetId)
{
  uint32 j=0;
  if((ucHandsetId < 1) || (ucHandsetId > 6)){
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				"Invalid Handset ID");
	  return IFX_FAILURE;
  }
  for(j=0;j<IFX_DECT_MAX_CALLS_PER_HS;j++){
	  if(avxCCInfo[ucHandsetId-1][j].eState > IFX_DECT_CS_IDLE){
       IFX_DECT_CSU_FreeCCInfo(&avxCCInfo[ucHandsetId-1][j]);
	  }
  }
  paxActCallHdl[ucHandsetId - 1] = NULL; /*  Store as active Index*/ 
  avxCCInfo[ucHandsetId-1][0].eState = IFX_DECT_CS_IDLE;
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				"Freed All CC Info of the Handset");
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_GetCallHandleBasedOnState
* Description    : This function free the CallControl Info
* Input Values   : pxCCInfo - pointer to x_IFX_DECT_CC_Info type
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_GetCallHandleBasedOnState(IN uchar8 ucHandsetId,
                                 IN x_IFX_DECT_CC_Info **pxCCInfo,
                                 IN e_IFX_DECT_CC_State eState)
{
  uint32 j=0;

	if (ucHandsetId<1 || ucHandsetId>6)
   return IFX_FAILURE;

  for(j=0;j<IFX_DECT_MAX_CALLS_PER_HS;j++){
    if(eState == avxCCInfo[ucHandsetId-1][j].eState) {
      *pxCCInfo = &avxCCInfo[ucHandsetId-1][j];
      IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	    			"Active Call found");

      IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	    			"pxccinfo found at",j);
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}
/************************************************************************
* Function Name  : IFX_DECT_CSU_GetCallOfthePeer
* Description    : This function free the CallControl Info
* Input Values   : pxCCInfo - pointer to x_IFX_DECT_CC_Info type
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_GetCallHandleOfThePeer(IN uchar8 ucPeerHandsetId,
                                 IN x_IFX_DECT_CC_Info **pxCCInfo,
                                 IN uchar8 ucCallId)
{
  int32 iIndex=0;
  /*Validate peer handset ID*/
  if((ucPeerHandsetId ==0)||(ucPeerHandsetId >IFX_DECT_MAX_HS) ){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Incorrect Handset Id");
     *pxCCInfo = NULL;
     return IFX_FAILURE;
  }
  /* find the CC Info of the Dest Handset*/ 
  for(iIndex=0; iIndex<IFX_DECT_MAX_CALLS_PER_HS; iIndex++){
      if(ucPeerHandsetId>0&&ucPeerHandsetId<6){
     if(avxCCInfo[ucPeerHandsetId -1][iIndex].ucCallId == ucCallId)
      {
           *pxCCInfo =&avxCCInfo[ucPeerHandsetId -1][iIndex];
            return IFX_SUCCESS;
      }
		} 
	}
  *pxCCInfo = NULL;
  return IFX_FAILURE;
}
/************************************************************************
* Function Name  : IFX_DECT_CSU_IsHSInConfState
* Description    : This function finds whether the handset is in Conference state
* Input Values   : ucHandsetId - HandsetId
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_IsHSInConfState(IN uchar8 ucHandsetId)
{
  uint32 j=0;
  int32 iCnt =0;

	if (ucHandsetId<1 || ucHandsetId>6)
   return IFX_FAILURE;

  for(j=0;j<IFX_DECT_MAX_CALLS_PER_HS;j++){
      IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                 "Handset is in state =", avxCCInfo[ucHandsetId-1][j].eState);
		if(avxCCInfo[ucHandsetId-1][j].eState == IFX_DECT_CS_CONF_CONNECT){
    	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "Handset is in Conference State");
		 return IFX_SUCCESS;
		}else if((IFX_DECT_CS_INTERCEPTED == avxCCInfo[ucHandsetId-1][j].eState)||
						(IFX_DECT_CS_UNDER_TRANSFER == avxCCInfo[ucHandsetId-1][j].eState)){
    	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "Conference Not possible at this time ");
		 return IFX_SUCCESS;
		}else if((IFX_DECT_CS_CONNECT == avxCCInfo[ucHandsetId-1][j].eState)||
				(IFX_DECT_CS_HOLD == avxCCInfo[ucHandsetId-1][j].eState)){
      IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	    	 "Call found");
      IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                 "Index is =", j);
      iCnt++;
    }
  }
  if((iCnt == 1)||(iCnt > 2))
  {
    IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "Handset has only one call or more than two calls");
    return IFX_SUCCESS;
  }
  return IFX_FAILURE;
}
/************************************************************************
* Function Name  : IFX_DECT_CSU_GetCCMatchIndex
* Description    : Get Matching Call Control Index based on HandsetId.
* Input Values   : ucHandsetId - HandsetId
* Output Values  : none
* Return Value   : Call Control Info Index,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_GetCCMatchIndex(IN uchar8 ucHandsetId,
							 IN uchar8 ucCallId,
							 IN uchar8 ucLineId) 
{
  int32 iIndex=0;

	if (ucHandsetId<1 || ucHandsetId>6)
   return IFX_FAILURE;

  for(iIndex=0; iIndex<IFX_DECT_MAX_CALLS_PER_HS; iIndex++){
    if(avxCCInfo[ucHandsetId -1][iIndex].eState != IFX_DECT_CS_IDLE){
        if((IFX_DECT_MU_IsCAT2(ucHandsetId)) 
	      &&(avxCCInfo[ucHandsetId -1][iIndex].ucCallId == ucCallId))
        {
		  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
                     "Index is =", iIndex);
          return iIndex;
        } 
	   }
  } //for loop
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "No CC Info found");
  return IFX_FAILURE;
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_AreCallBksRegistered
* Description    : This function register Application notification call backs
* Input Values   : call backs
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
PUBLIC e_IFX_Return
IFX_DECT_CSU_AreCallBksRegistered(IN x_IFX_DECT_CSU_CallBks *pxCSUCallBks)
{
  if(pxCSUCallBks->pfnCallInitiate == NULL
     || pxCSUCallBks->pfnCallAccept == NULL
	 || pxCSUCallBks->pfnCallAnswer == NULL
	 || pxCSUCallBks->pfnCallRelease == NULL
	 || pxCSUCallBks->pfnInfoReceived == NULL
	 || pxCSUCallBks->pfnServiceChange == NULL
	 || pxCSUCallBks->pfnInterceptAccept == NULL
	 || pxCSUCallBks->pfnVoiceModify == NULL
#ifdef ENABLE_ENCRYPTION
	 || pxCSUCallBks->pfnCipherCfm == NULL
#endif
#ifdef CAT_IQ2_0
	 || pxCSUCallBks->pfnCallToggle== NULL
	 || pxCSUCallBks->pfnCallHold == NULL
	 || pxCSUCallBks->pfnCallResume == NULL
	 || pxCSUCallBks->pfnCallTransfer == NULL
	 || pxCSUCallBks->pfnCallConference == NULL
	 ||pxCSUCallBks->pfnIntrudeInfoRecv == NULL
#endif
  ){
    return IFX_FAILURE;
  }
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_RegisterCallBks
* Description    : This function register Application notification call backs
* Input Values   : call backs
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
PUBLIC e_IFX_Return
IFX_DECT_CSU_RegisterCallBks(IN x_IFX_DECT_CSU_CallBks *pxCSUCallBks)
{
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Enter Register CallBacks.");
  if(IFX_SUCCESS != IFX_DECT_CSU_AreCallBksRegistered(pxCSUCallBks)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	              "All mandatory CallBacks are not registered.");
    return IFX_FAILURE;
  }
  memcpy(&vxCSUCallBks,pxCSUCallBks,sizeof(x_IFX_DECT_CSU_CallBks));
  memset(avxCCInfo,0,sizeof(avxCCInfo));
  memset(paxActCallHdl,0,sizeof(paxActCallHdl));
  ucConfReqId = 0;
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_ValidateBasicService
* Description    : This function validates the BASIC_SERVICE IE in setup msg
* Input Values   : pxIPCMsg IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_ValidateBasicService(IN x_IFX_DECT_IPC_Msg* pxIPCMsg,
                                  IN x_IFX_DECT_IE_BasicService* pxBSInfo)
{
  uint32 uiIEHdl = 0;
  if(pxIPCMsg == NULL){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
    return IFX_FAILURE;
  }
  uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIPCMsg);
  while(uiIEHdl != 0){
	  if(IFX_DECT_IE_TypeGet(uiIEHdl) == IFX_DECT_IE_BASICSERVICE){
		  IFX_DECT_IE_BasicServiceGet(uiIEHdl,pxBSInfo);
		  return IFX_SUCCESS;
	  }else{
      IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl);
	  }
  }
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_EncodeCLIP
* Description    : This routine encodes CallingPartyNumber
* Input Values   : pxIPCMsg IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_EncodeCLIP(char8 *pcClip,int32 iClipLen,boolean bIsPresentation,uint32 uiHdl,boolean bIsInternal)
{

  x_IFX_DECT_IE_CallingPartyNumber xCallingPartyNumberInfo={0};

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Encode CLIP.");
  xCallingPartyNumberInfo.ucExtn3 = 0;
  xCallingPartyNumberInfo.ucNumberType = 3;// bIsInternal?0:3; //3; 
  xCallingPartyNumberInfo.ucNPI =9;// bIsInternal?9:0; //9
  xCallingPartyNumberInfo.ucExtn3a = 1;
  xCallingPartyNumberInfo.ucPI =0;// bIsPresentation?0:1; //0
  xCallingPartyNumberInfo.ucSpare = 0;
  xCallingPartyNumberInfo.ucSI = 1;
  strncpy((char*)&xCallingPartyNumberInfo.acCPA[0],(char*)pcClip,iClipLen);
  xCallingPartyNumberInfo.ucCPALen = iClipLen;
  //xCallingPartyNumberInfo.ucCPALen = 4;
	
  if(IFX_DECT_IE_IEAdd(uiHdl,IFX_DECT_IE_CALLINGPARTYNUMBER,
						(void *)&xCallingPartyNumberInfo) == IFX_FAILURE){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE Failed.");
    return IFX_FAILURE;
  }
    
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Successful.");
  return IFX_SUCCESS;
}

e_IFX_Return IFX_DECT_CSU_IsUTF8(char8 *pcCnip, int32 iCnipLen)
{
  int32 iCount=0;
  uint32 x=0;
  while(iCount < iCnipLen){
    x = *pcCnip;
    if(x > 128){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"UTF 8.");
      return IFX_SUCCESS;
    }
    pcCnip++;
    iCount++;
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"NON UTF 8.");
  return IFX_FAILURE;
}
/************************************************************************
* Function Name  : IFX_DECT_CSU_EncodeCNIP
* Description    : This routine encodes CallingPartyName
* Input Values   : pxIPCMsg IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_EncodeCNIP(IN char8 *pcCnip, IN int32 iCnipLen, boolean bIsPresentation,
			uint32 uiAdd_Cnip_To, uchar8 ucHandset)
{

  x_IFX_DECT_IE_CallingPartyName xCallingPartyNameInfo={0};

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Encode CNIP.");
  
  xCallingPartyNameInfo.ucDefault1 = 0;
  xCallingPartyNameInfo.ucPI = 0;//bIsPresentation?0:1;
  
	if (ucHandset<1 || ucHandset>6)
   return IFX_FAILURE;

  if(IFX_DECT_MU_IsCAT2(ucHandset)){
    xCallingPartyNameInfo.ucUA = IFX_DECT_CSU_IsUTF8(pcCnip,iCnipLen) == IFX_SUCCESS ? 1:0;
  }else{
    xCallingPartyNameInfo.ucUA = 0;
  }
  xCallingPartyNameInfo.ucSI = 1;

  strncpy((char*)&xCallingPartyNameInfo.acCPN[0],(char*)pcCnip,iCnipLen);
  xCallingPartyNameInfo.ucCPNLen = iCnipLen;
	
  if(IFX_DECT_IE_IEAdd(uiAdd_Cnip_To,IFX_DECT_IE_CALLINGPARTYNAME,
						(void *)&xCallingPartyNameInfo) == IFX_FAILURE){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE Failed.");
    return IFX_FAILURE;
  }
    
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Successful.");
  return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : HandleConnectForIntercept
* Description    : This API is called by Application when needed to send a Connect to the HPP
*						       with all the  information and handle Service change request if needed.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CSU_ExplicitConnect(IN uint32 uiCallHdl,IN x_IFX_DECT_CSU_CallParams *pxCallParams )
{

   x_IFX_DECT_IPC_Msg xIpcMsg={0};
   uint32 uiIEHdl;
   uchar8 ucCallId=0xFF;
   uchar8 ucLineId=0xFF;
   uchar8 ucSignal=0xFF;
   e_IFX_DECT_IE_CallStatus eCallStatus=0xFF;
   x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info *)uiCallHdl;
   /*Connect when there is target HsId & Intercept requested*/
   if((pxCCInfo->uiFlag&IFX_DECT_CSU_INTERCEPT_REQUESTED)&&(pxCallParams->ucPeerHandsetId > 0)
      &&(pxCallParams->ucPeerHandsetId < IFX_DECT_MAX_HS)){
      ucCallId=paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucCallId;
      ucLineId=paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucLineId;
      paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->uiFlag |= IFX_DECT_CSU_INTERCEPT_INITIATED;
      pxCCInfo->uiFlag &= ~IFX_DECT_CSU_INTERCEPT_REQUESTED;
      eCallStatus=IFX_DECT_CS_PROC;
      // JONATHAN_150211. In order to prevent LineID & CallID = 0xFF, just copy previous Handset's LineID & CallID.
      //paxActCallHdl[pxCCInfo->ucHandsetId-1]->ucCallId = paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucCallId;
      //paxActCallHdl[pxCCInfo->ucHandsetId-1]->ucLineId = paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucLineId;
   }else if((pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_REQUESTED)&&(pxCallParams->ucPeerHandsetId==0)){/*Connect for Intrude*/
      ucCallId=pxCCInfo->ucCallId;
      ucLineId=pxCCInfo->ucLineId;
      eCallStatus=IFX_DECT_CS_SETUP_ACK;
   }else if((pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_REQUESTED)&&(pxCallParams->ucPeerHandsetId > 0)
   &&(pxCallParams->ucPeerHandsetId < IFX_DECT_MAX_HS)){
      ucCallId=paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucCallId;
      ucLineId=paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucLineId;
      // JONATHAN_150211. In order to prevent LineID & CallID = 0xFF, just copy previous Handset's LineID & CallID.
      //paxActCallHdl[pxCCInfo->ucHandsetId-1]->ucCallId = paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucCallId;
      //paxActCallHdl[pxCCInfo->ucHandsetId-1]->ucLineId = paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucLineId;
   }else if(pxCallParams->ucPeerHandsetId==0){/*Connect for Normal or Intercept Req and no target HsId*/
      pxCCInfo->uiFlag &= ~IFX_DECT_CSU_INTERCEPT_REQUESTED;
      if(pxCCInfo->ucCallId==0xFF){
         IFX_DECT_MU_GetCallID(&ucCallId);
         pxCCInfo->ucCallId=ucCallId;
      }else{
         ucCallId=pxCCInfo->ucCallId;
      }
      ucLineId=pxCCInfo->ucLineId;
      if(pxCCInfo->uiFlag & IFX_DECT_CSU_PENDING_SIGNAL)
      {
         ucSignal=0x00;
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Send Explicit CC_CONNECT with signal 00");
         pxCCInfo->uiFlag &= ~IFX_DECT_CSU_PENDING_SIGNAL;
      }
      else
      {
         if(pxCCInfo->uiFlag & IFX_DECT_CSU_PENDING_ENVOICE){
            if(((uiSlotType & (1 << pxCCInfo->ucHandsetId)) && (pxCCInfo->aunCodec[0] == IFX_DECTNG_CODEC_G722_64)) ||
               (!(uiSlotType & (1 << pxCCInfo->ucHandsetId)) && (pxCCInfo->aunCodec[0] != IFX_DECTNG_CODEC_G722_64)))
            {

				pxCCInfo->uiFlag &= ~IFX_DECT_CSU_PENDING_ENVOICE;
    		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Received enable voice before connect but sending now coz tone has to be played from base");
        memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
       	IFX_DECT_EncodeEnableVoice(pxCCInfo->ucHandsetId,
                                 pxCCInfo->ucInstanceId,
                                 pxCCInfo->unHwVoiceChannel,
                                 &xIpcMsg);
               IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
            }
         }
      }
      eCallStatus=IFX_DECT_CS_SETUP_ACK;
   }
   else if((pxCallParams->ucPeerHandsetId > 0) && (pxCallParams->ucPeerHandsetId < IFX_DECT_MAX_HS)){/*Implicit Intrude Connect*/
      pxCCInfo->uiFlag |= IFX_DECT_CSU_INTRUDE_REQUESTED;
      ucCallId=paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucCallId;
      ucLineId=paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucLineId;
      // JONATHAN_150211. In order to prevent LineID & CallID = 0xFF, just copy previous Handset's LineID & CallID.
      //paxActCallHdl[pxCCInfo->ucHandsetId-1]->ucCallId = paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucCallId;
      //paxActCallHdl[pxCCInfo->ucHandsetId-1]->ucLineId = paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucLineId;
   }
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "Send Explicit CC_CONNECT");
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
            "CallID : ", ucCallId );
   /* Construct CC Connect */
   IFX_DECT_EncodeConnect(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
                        pxCCInfo->bwideband,&xIpcMsg);

   if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){
       uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);
       IFX_DECT_CSU_EncodeCallInformation(ucCallId,0xFF,0xFF,
                                      0xFF,0xFF,uiIEHdl);
   }
   IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);

   // JONATHAN_150211. In order to prevent LineID & CallID = 0xFF, just copy previous Handset's LineID & CallID.
   if((pxCallParams->ucPeerHandsetId > 0) && (pxCallParams->ucPeerHandsetId < IFX_DECT_MAX_HS)){
      paxActCallHdl[pxCCInfo->ucHandsetId-1]->ucCallId = ucCallId;
      paxActCallHdl[pxCCInfo->ucHandsetId-1]->ucLineId = ucLineId;
      //usleep(5000);
   }

   if(!((pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_REQUESTED)&&(pxCallParams->ucPeerHandsetId!=0))){

    /*   IFX_DECT_EncodeCallProc(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
                                     &xIpcMsg);*/
	     if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){
					memset(&xIpcMsg,0,sizeof(xIpcMsg));
	    		IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
			                  				ucSignal,&xIpcMsg);
          uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
          IFX_DECT_CSU_EncodeCallInformation(ucCallId,eCallStatus,0xFF,0xFF,ucLineId,uiIEHdl);
	    		IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
		  }
	}
		if(pxCallParams->ucPeerHandsetId>0&&pxCallParams->ucPeerHandsetId<7){
		if((paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->uiFlag&IFX_DECT_CSU_INTERCEPT_INITIATED)){
			x_IFX_DECT_CSU_CallParams xCallParam = {0};
  		xCallParam.uiSignal = IFX_DECT_SIGNAL_InterceptTone;
  		xCallParam.isInternal = 1; 
  		xCallParam.bIsPresentation =1;
  		xCallParam.acCLIP[0]=pxCCInfo->ucHandsetId+'0';
			IFX_DECT_CSU_Send_CallState((uint32)paxActCallHdl[pxCallParams->ucPeerHandsetId-1],&xCallParam,
																	IFX_DECT_CS_INTERCEPTED);
		}
		}
		pxCCInfo->uiFlag &= ~IFX_DECT_CSU_EXPLICIT_CONNECT;
	  pxCCInfo->eState = IFX_DECT_CS_PROC;
		return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_CSU_EncodeMultiDisplay
* Description    : This routine encodes MultiDisplay IE
* Input Values   : szString , uiIEHdl
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :    
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_EncodeMultiDisplay(IN char8 *szString,
														   IN uint32 uiHdl )
{

  x_IFX_DECT_IE_MultiDisplay xMDInfo;
	memset(&xMDInfo,0,sizeof(xMDInfo));
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Encode MultiDisplay.");
	xMDInfo.ucDisplayLen = (strlen(szString)<250)?strlen(szString):249;
	strncpy((char8 *)xMDInfo.acDisplay,szString,xMDInfo.ucDisplayLen);
   IFX_DECT_IE_IEAdd(uiHdl,IFX_DECT_IE_MULTIDISPLAY,
						  (void *)&xMDInfo);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Successful.");
  return IFX_SUCCESS;
}



/************************************************************************
* Function Name  : IFX_DECT_CSU_EncodeCallInformation
* Description    : This routine encodes CallInformation IE
* Input Values   : pxCallInfo  x_IFX_DECT_IE_CallInfo type of message
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :    First fill all the CallId's and then the LineId's
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_EncodeCallInformation(IN uchar8 ucCallId1,
								   IN uchar8 ucCallStatus,
								   IN uchar8 ucCallReason,
                   IN uchar8 ucCallId2,
								   IN uchar8 ucLineId,
								   IN uint32 uiHdl )
{

  x_IFX_DECT_IE_CallInfo xCallInfo={0};
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Encode CallInfo.");
  /* Construct the CALL-INFORMATION IE */
  xCallInfo.ucNoOfIdentifiers = 0;
  if(ucCallId1 != 0xFF) {
    xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDType = IFX_DECT_TYPE_CALL_ID;
	  xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDSubType = IFX_DECT_STYPE_CALL_ID;
	  xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueFirstByte = ucCallId1;
	  xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueExtn = 1;
	  xCallInfo.ucNoOfIdentifiers ++;
  }
  
  if(ucCallId2 != 0xFF) {
    xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDType = IFX_DECT_TYPE_CALL_ID;
	  xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDSubType = IFX_DECT_STYPE_UTDCALL_ID;
	  xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueFirstByte = ucCallId2;
	  xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueExtn = 1;
	  xCallInfo.ucNoOfIdentifiers ++;
  }
  if(ucLineId != 0xFF) {
    xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDType = IFX_DECT_TYPE_LINE_ID;
    xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDSubType = IFX_DECT_STYPE_LINE_ID_EXT;
    xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueFirstByte = ucLineId;
	  xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueExtn = 1;
    xCallInfo.ucNoOfIdentifiers ++;
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,"Encode CallInformation LINE ID is:",ucLineId);
  }
    if(ucLineId != 0xFF) {
    xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDType = IFX_DECT_TYPE_LINE_ID;
    xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDSubType = IFX_DECT_STYPE_LINE_TYPE;
    xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueFirstByte = 1;
    xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueExtn = 1;
    xCallInfo.ucNoOfIdentifiers ++;
  }
  if(ucCallStatus != 0xFF){
	   xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDType = IFX_DECT_TYPE_CALL_STATUS;
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDSubType = IFX_DECT_STYPE_CALL_STATUS;
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueFirstByte = ucCallStatus ;
	   xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueExtn = 1;
	   xCallInfo.ucNoOfIdentifiers ++;
  }
  if(ucCallReason != 0xFF){
	   xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDType = IFX_DECT_TYPE_CALL_STATUS;
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].ucIDSubType = IFX_DECT_STYPE_CALL_STATUS_REASON;
     xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueFirstByte = ucCallReason ;
	   xCallInfo.axID[xCallInfo.ucNoOfIdentifiers].axIDValue[0].ucIDValueExtn = 1;
	   xCallInfo.ucNoOfIdentifiers ++;
  }
  if(xCallInfo.ucNoOfIdentifiers){
	  IFX_DECT_IE_IEAdd(uiHdl,IFX_DECT_IE_CALLINFORMATION,
						  (void *)&xCallInfo);
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Successful.");
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_EncodeMultiKeypad
* Description    : This routine encodes Multi Keypad
* Input Values   : pxIPCMsg IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_EncodeMultiKeypad(char8 *pcKeypadInfo,int32 iKeypadLen, uint32 uiHdl)
{

  x_IFX_DECT_IE_MultiKeypad xMultiKey = {{"\0"}};

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Encode MultiKeypad.");
  strncpy((char*)&xMultiKey.acKeypad[0],(char*)pcKeypadInfo,iKeypadLen);
  xMultiKey.ucKeypadLen = iKeypadLen;
	
  if(IFX_DECT_IE_IEAdd(uiHdl,IFX_DECT_IE_MULTIKEYPAD,
						(void *)&xMultiKey) == IFX_FAILURE){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE Failed.");
    return IFX_FAILURE;
  }
    
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Successful.");
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_KeypadEvents
* Description    : This routine decodes keypad events
* Input Values   : pxIPCMsg IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 	
IFX_DECT_CSU_KeypadEvents(IN x_IFX_DECT_IPC_Msg *pxIPCMsg,
	               OUT char8* pszDigits, OUT boolean* pbHookFlash)
{

  uchar8 ucDialPos=0, ucIndex=0, ucDigit=0;
  uchar8 *pBuf=NULL;
  uint32 uiIEHdl = 0;
  x_IFX_DECT_IE_MultiKeypad xMultiKey={{"\0"}};
  //e_IFX_Return eRet = IFX_SUCCESS;
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  *pbHookFlash = IFX_FALSE;
   pszDigits[0] = '\0';

   if(0 == (uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIPCMsg)) ){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
    return IFX_FAILURE;
  }
  ucDialPos = 0;	
  while(1){
    if(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_MULTIKEYPAD){
         if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
           //eRet = IFX_FAILURE;
           break;
         }
		 continue;
	}
	memset(&xMultiKey,0,sizeof(x_IFX_DECT_IE_MultiKeypad));
  if(uiIEHdl != 0){
    printf("###########Multi keypad event found ##############\n");
  }
    if(IFX_DECT_IE_MultiKeypadGet(uiIEHdl, &xMultiKey) == IFX_SUCCESS){
	  /* Dialling received.  Put the info into the dial queue.*/
      pBuf = xMultiKey.acKeypad; // Start of first digit

	  for( ucIndex = 0; ucIndex < xMultiKey.ucKeypadLen; ucIndex++)
	  {
	    ucDigit = *pBuf++;
	    /* dial digit */
	    if( ( ucDigit >= '0'  && ucDigit <= '9' ) || 
			ucDigit == '*' || ucDigit == '#'
			|| (ucDigit == REGISTER_RECALL_REQUEST)
			|| (ucDigit == IFX_DECT_CSU_HEXCODE_PREFIX)
			|| (ucDigit == INTERNAL_CALL_REQUEST)
			|| ( ucDigit >= 0x31  && ucDigit <= 0x42 )
			||(ucDigit == 0x50)
		)
	  {
	    if(ucDigit == REGISTER_RECALL_REQUEST){
		  if(!IFX_DECT_MU_IsCAT2(pxIPCMsg->ucPara1)){
            pszDigits[0] = '\0';
	        *pbHookFlash = IFX_TRUE;
	        return IFX_SUCCESS;
		  }
		}
	    pszDigits[ucDialPos++] = ucDigit;
	  }	
	  pszDigits[ucDialPos] = '\0';
	}
   }
   if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
           //eRet = IFX_FAILURE;
           break;
   }
  }	
  return (ucDialPos > 0 ?IFX_SUCCESS:IFX_FAILURE);
}
/************************************************************************
* Function Name  : IFX_DECT_CSU_GetCallId
* Description    : This routine Gets the CallId based on SubType
* Input Values   : 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 	
IFX_DECT_CSU_GetCallId(IN_OUT x_IFX_DECT_IE_CallInfo *pxCallInfo,
                       IN uchar8 ucCallIdSubTyp,
                       OUT uchar8* pucCallId)
								   
{
  uchar8 ucIndex=0;
  *pucCallId = 0xFF; //Invalid value
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  for( ucIndex = 0; ucIndex < pxCallInfo->ucNoOfIdentifiers; ucIndex++)
  {
	  if(pxCallInfo->axID[ucIndex].ucIDType == IFX_DECT_TYPE_CALL_ID
	     && pxCallInfo->axID[ucIndex].ucIDSubType ==  ucCallIdSubTyp) {
		   *pucCallId = pxCallInfo->axID[ucIndex].axIDValue[0].ucIDValueFirstByte;

      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"CallId in list: ",
            *pucCallId);
		  return IFX_SUCCESS;
	   }		
  } //for loop
  *pucCallId = 0xFF;
  return IFX_FAILURE;	  
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_GetLineId
* Description    : This routine Gets the LineId based on SubType
* Input Values   : 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 	
IFX_DECT_CSU_GetLineId(IN_OUT x_IFX_DECT_IE_CallInfo *pxCallInfo,
                       IN uchar8 ucLineIdSubTyp,
                       OUT uchar8* pucLineId)
								   
{
  uchar8 ucIndex=0;
  (*pucLineId) = (*pucLineId==0x7F)?0x7F:0xFF; //Invalid value
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  for( ucIndex = 0; ucIndex < pxCallInfo->ucNoOfIdentifiers; ucIndex++)
  {
    if(pxCallInfo->axID[ucIndex].ucIDType == IFX_DECT_TYPE_LINE_ID
	   && pxCallInfo->axID[ucIndex].ucIDSubType ==  ucLineIdSubTyp) {
		*pucLineId = pxCallInfo->axID[ucIndex].axIDValue[0].ucIDValueFirstByte == 0x7F ?0xFF:pxCallInfo->axID[ucIndex].axIDValue[0].ucIDValueFirstByte;
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"LineId in list: ",
            *pucLineId);
		return IFX_SUCCESS;
    }
  }	
  *pucLineId = 0xFF;
  return IFX_FAILURE;	  
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_DecodeCallInformation
* Description    : This routine decodes Call Information
* Input Values   : pxIPCMsg IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 	
IFX_DECT_CSU_DecodeCallInformation(IN x_IFX_DECT_IPC_Msg *pxIPCMsg,
								   OUT uchar8* pucCallId, 
								   OUT uchar8* pucLineId)
{
  x_IFX_DECT_IE_CallInfo xCCInfo={0};
  uint32 uiIEHdl=0;
  *pucCallId=0xFF;
	*pucLineId=0xFF;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  
  uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIPCMsg);
  while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_CALLINFORMATION){
    if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
       return IFX_FAILURE;
    }
  }
  
  /* Call information included ?      */	
  IFX_DECT_IE_CallInformationGet(uiIEHdl,&xCCInfo);
  IFX_DECT_CSU_GetCallId(&xCCInfo,IFX_DECT_STYPE_CALL_ID,pucCallId);
	IFX_DECT_CSU_GetLineId(&xCCInfo,IFX_DECT_STYPE_LINE_ID_EXT,pucLineId);
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"CallId is: ",
            *pucCallId);
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"LineId is: ",
            *pucLineId);
  return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_CSU_SendAckToPP
* Description    : This routine sends the acknowledgement to the PP
* Input Values   : pxIPCMsg IPC message
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 	
IFX_DECT_CSU_SendAckToPP(IN uchar8 ucHandsetId, 
                         IN uchar8 ucInstanceId,
						 IN uchar8 ucCallId,
						 IN uchar8 ucLineId,
						 IN uchar8 ucCallStatus,
						 IN uchar8 ucCallReason,
						 IN uchar8 ucSignal)
{
  uint32 uiIEHdl;
  x_IFX_DECT_IPC_Msg xIpcMsg={0};

  /*  Send the acknowledgement  */ 
  IFX_DECT_EncodeCCInfo(ucHandsetId,ucInstanceId,
                        ucSignal,&xIpcMsg);

  uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  

  IFX_DECT_CSU_EncodeCallInformation(ucCallId,ucCallStatus,ucCallReason,0xFF,ucLineId,uiIEHdl);  

  return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
}





/************************************************************************
* Function Name  : IFX_DECT_CSU_SendMultiDisplayToPP
* Description    : This routine sends the Display to the PP
* Input Values   : *szString(Display String),ucHandsetId,ucInstanceId,ucSignal(if needed)
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 	
IFX_DECT_CSU_SendMultiDisplayToPP(IN uint32 uiCallHdl, 
						 							IN uchar8 ucSignal,
													IN x_IFX_DECT_CSU_CallParams *pxCallParams,
													IN char8 *szString)
{
  uint32 uiIEHdl;
  x_IFX_DECT_IPC_Msg xIpcMsg={0};
	x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info *)uiCallHdl;

	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Entry");
  /*  Send the acknowledgement  */ 
  IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
                        ucSignal,&xIpcMsg);

  uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  

  IFX_DECT_CSU_EncodeMultiDisplay(szString,uiIEHdl);  
	 if(strlen(pxCallParams->acCLIP) >0) {
			IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 	pxCallParams->acCLIP );
				IFX_DECT_CSU_EncodeCLIP(pxCallParams->acCLIP,strlen(pxCallParams->acCLIP),
	 				pxCallParams->bIsPresentation,uiIEHdl,pxCallParams->isInternal);
  	}
  /* Encode CNIP */
   if(strlen(pxCallParams->acCNIP) > 0) {
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 pxCallParams->acCNIP );
    //  strcpy(pxCCInfo->acCNIP , pxCallParams->acCNIP);
      IFX_DECT_CSU_EncodeCNIP(pxCallParams->acCNIP,strlen(pxCallParams->acCNIP),
      pxCallParams->bIsPresentation,uiIEHdl,pxCCInfo->ucHandsetId);
    }
  return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
}


/************************************************************************
* Function Name  : IFX_DECT_CSU_SendInterceptReqToPP
* Description    : This routine sends the Display to the PP
* Input Values   : *szString(Display String),ucHandsetId,ucInstanceId,ucSignal(if needed)
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 	
IFX_DECT_CSU_SendInterceptReqToPP(IN uint32 uiCallHdl, 
						 							IN uchar8 ucSignal,
													IN x_IFX_DECT_CSU_CallParams *pxCallParams,
													IN char8 *szString)
{
	x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info *)uiCallHdl;
	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Entry");
		pxCCInfo->uiFlag |= IFX_DECT_CSU_INTERCEPT_INITIATED;
  /*  Send the MultiDisplay  */ 
  return IFX_DECT_CSU_SendMultiDisplayToPP(uiCallHdl,ucSignal,pxCallParams,szString);
}
/************************************************************************
* Function Name  : IFX_DECT_ValidateRxCallID
* Description    : This function validates Received CallID
* Input Values   : pxCCInfo - pointer to a pointer of x_IFX_DECT_CC_Info type
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_ValidateRxCallID(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  x_IFX_DECT_CC_Info *pxCCInfo =  paxActCallHdl[pxIpcMsg->ucPara1-1];
  uchar8 ucLineId=0xFF;
  uchar8 ucCallId=0xFF;
 
  /* Check the CallInformation IE for LineId and CallId*/
  if(IFX_DECT_CSU_DecodeCallInformation(pxIpcMsg,&ucCallId, &ucLineId) == IFX_SUCCESS){
		  if(pxCCInfo->ucCallId != ucCallId){
	       IFX_DECT_CSU_SendAckToPP(pxIpcMsg->ucPara1, 
             pxIpcMsg->ucInstance,
						 ucCallId,
						 ucLineId,
						 pxCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
						 IFX_DECT_CSU_SIGNAL_NACK);
		    IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					 "Invalid Caller ID, so sent NACK");
 	      return IFX_FAILURE;
		  }
    }
  return IFX_SUCCESS;
  
}
/************************************************************************
                           CallBacks
* *************************************************************************/

/************************************************************************
* Function Name  : FP_SETUP_IN_CC
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleSetupMsg(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{  
  boolean bHookFlash;
  x_IFX_DECT_CC_Info *pxCCInfo = NULL;
	/*point the pxCCInfo to this local struct in failed case before CCInfo alloc*/
  x_IFX_DECT_CC_Info xTempCCInfo= {0};/*local struct to store Info in case setup fails before allocating CCInfo*/
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_IE_BasicService xBSInfo ={0};
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  uchar8 ucRejectReason= 0;
  e_IFX_DECT_ErrReason eRejectReason_cb; 
  uchar8 ucCallId=0xFF,ucLineId=0xFF;
  char8 acRecvDigits[IFX_DECT_MAX_DIGITS]={'\0'};
  int32 iActiveIdx=0;
	e_IFX_DECT_IE_CallReason eCallReason=0xFF;
	boolean bLineIdReceived=0;
	e_IFX_Return eRet=IFX_FAILURE;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"HandsetId is: ",
                 pxIpcMsg->ucPara1);
	
  xTempCCInfo.ucHandsetId   = pxIpcMsg->ucPara1; /*  HandsetId */
  xTempCCInfo.ucInstanceId  = pxIpcMsg->ucInstance; /*  InstanceId */
	xTempCCInfo.ucCallId = 0xFF;
	xTempCCInfo.ucLineId = 0xFF;
/*Filling with 0xFF inorder to check in setup fail whether to free the CC Info or not*/
	xTempCCInfo.eState=0xFF;
  if(IFX_DECT_MU_IsCAT2(pxIpcMsg->ucPara1)){
		xTempCCInfo.bwideband = IFX_TRUE;
	}

	memset(&xCallParams,0,sizeof(xCallParams));
	xCallParams.ucLineId = 0xFF;
  /* Check whether BASIC_SERVICE IE is present or not.
		 If Yes, then return the basic service info else Reject*/ 
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Checking Basic srevice");
  if(IFX_DECT_CSU_ValidateBasicService(pxIpcMsg,&xBSInfo) != IFX_SUCCESS){
    IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
              "Mandatory Parameters Are Missing" );
    ucRejectReason = IFX_DECT_MANDATORY_IE_MISSING;
		eCallReason=IFX_DECT_CS_BUSY;
		pxCCInfo=&xTempCCInfo;
    goto HandleSetupFailure;
  } 
  else {
    IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_NORMAL, IFX_DBG_STR,"BASIC SERVICE found" );
     if(
          (xBSInfo.ucBasicService == 0x01) || (xBSInfo.ucBasicService == 0x02) || (xBSInfo.ucBasicService == 0x03) || (xBSInfo.ucBasicService == 0x07) ||  \
          (xBSInfo.ucBasicService == 0x0b) || (xBSInfo.ucBasicService == 0x0c) || (xBSInfo.ucBasicService == 0x0d) || (xBSInfo.ucBasicService == 0x0e) ||  \
          (xBSInfo.ucCallClass == 0x00) || (xBSInfo.ucCallClass == 0x01) || (xBSInfo.ucCallClass == 0x03) || (xBSInfo.ucCallClass == 0x05) ||    \
          (xBSInfo.ucCallClass == 0x06) || (xBSInfo.ucCallClass == 0x0f)
        )
      {
        ucRejectReason = IFX_DECT_INVALID_IE_CONTENTS;
    		IFX_DECT_EncodeReject(pxIpcMsg->ucPara1,
                 pxIpcMsg->ucInstance,
                 ucRejectReason, 
                 &xIpcMsg);
    	return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      }

  } 
 //Sinus 302i & Sinus 502i workarround solution  
  if(xBSInfo.ucCallClass == 0x0B){
	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
              "Service request not supported" );
	IFX_DECT_EncodeConnect(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,
                          0,&xIpcMsg);
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
              "Sent connect" );
//    sleep(3); // wait for 3secs
    memset(&xIpcMsg,0,sizeof(xIpcMsg));
    ucRejectReason = IFX_DECT_SERVICE_NOT_IMPLEMENTED; //IFX_DECT_MANDATORY_IE_MISSING;
    IFX_DECT_EncodeRelease(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,ucRejectReason,&xIpcMsg);
		IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
              "Sent Release with service not supported" );

    return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);

  } 
  
  /* Set the Module Owner */  
  if(IFX_FAILURE == IFX_DECT_MU_SetModuleOwner(pxIpcMsg->ucPara1,
			IFX_DECT_MU_ADD_OWNER,IFX_DECT_CSU_ID)){
    IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
             "Set Module Owner Failed" );
    ucRejectReason =  IFX_DECT_UNKNOWN;
		eCallReason=IFX_DECT_CS_BUSY;
		pxCCInfo=&xTempCCInfo;
    goto HandleSetupFailure;
  }

  /*Prepare CallControl Info*/ 
  if((iActiveIdx= IFX_DECT_CSU_AllocCCInfo(pxIpcMsg->ucPara1,&pxCCInfo))== IFX_FAILURE) {
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Free CC Info");
	  ucRejectReason = IFX_DECT_UNKNOWN;
		eCallReason=IFX_DECT_CS_BUSY;
		pxCCInfo=&xTempCCInfo;
    goto HandleSetupFailure;
  }
  
  /* FILL the CC Info*/
  pxCCInfo->ucHandsetId   = pxIpcMsg->ucPara1; /*  HandsetId */
  pxCCInfo->ucInstanceId  = pxIpcMsg->ucInstance; /*  InstanceId */
  IFX_DECT_BlockMCEI(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance); /* Block MCEI */

  if((pxIpcMsg->ucPara3 == 0)||(pxIpcMsg->ucPara3 == 0xFF)){
    if(IFX_DECT_MU_IsWb(pxCCInfo->ucHandsetId)){
      pxCCInfo->aunCodec[0] = IFX_DECTNG_CODEC_G722_64;
    }
    else{
      pxCCInfo->aunCodec[0] = IFX_DECTNG_CODEC_G726_32;
    }
  }
  else{
    pxCCInfo->aunCodec[0] = pxIpcMsg->ucPara3; /*  which codec? */
  }

//	pxCCInfo->bwideband=pxIpcMsg->ucPara4;
  IFX_DECT_MU_SetCodec(pxCCInfo->ucHandsetId,pxCCInfo->aunCodec[0]);
  IFX_DECT_MU_SetRunCodec(pxCCInfo->ucHandsetId,pxCCInfo->aunCodec[0]);
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  		   	"<Setup> Running Codec  is", IFX_DECT_MU_GetRunCodec(pxIpcMsg->ucPara1));
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  		   	"<Setup> Codec  is", IFX_DECT_MU_GetCodec(pxIpcMsg->ucPara1));
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  		   	"<Setup> TKHDL", pxCCInfo);
  
  pxCCInfo->ucBasicService = ((xBSInfo.ucCallClass)<<4) | xBSInfo.ucBasicService ; 	

  IFX_DECT_MU_SetBasicService(pxCCInfo->ucHandsetId,pxCCInfo->ucBasicService);

     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
			  		"CallClass = ", xBSInfo.ucCallClass );
	
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
			  		"Service = ", xBSInfo.ucBasicService );	
	if(pxIpcMsg->ucPara4)
	{
		uiSlotType |= (1 << pxIpcMsg->ucPara1);
	}
	else
	{
		uiSlotType &= !(1 << pxIpcMsg->ucPara1);
	}
  /* Only LAU and no Voice session*/
  if(xBSInfo.ucCallClass == 0x02/*IFX_DECT_WBS_LIA_CALL*/){ 
    pxCCInfo->eState = IFX_DECT_CC_NOUPLANE;
	  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "This is a LiA WB call");
		if(IFX_DECT_ENCRYPTION_MODE == IFX_FALSE){
   		IFX_DECT_EncodeCallProc(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,
                                     &xIpcMsg);
	  	IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
		}else{
    	IFX_DECT_MU_SetCipherStatus(pxCCInfo->ucHandsetId,IFX_TRUE); 
    
    	IFX_DECT_EncodeAuthPTReq(pxCCInfo->ucHandsetId,
                           pxCCInfo->ucInstanceId, &xIpcMsg);
	  
    	IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
		}
    return IFX_SUCCESS;
  }

  /* Extract Line information for Catiq 2.0 handsets if present*/  
  if(IFX_DECT_MU_IsCAT2(pxIpcMsg->ucPara1)){
    /*  Check the CallInformation IE for LineId*/
    if(IFX_DECT_CSU_DecodeCallInformation(pxIpcMsg,&ucCallId,&ucLineId) == IFX_SUCCESS){
		 bLineIdReceived=1;
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
			  		"Line Id in Call Info", ucLineId);	
     /*  we cannot expect CallId in the Setup */
     xCallParams.ucLineId = pxCCInfo->ucLineId = ucLineId;	
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
			  		"LineId = ", pxCCInfo->ucLineId );	
     /*  This is a PT initiated call. Set the flag. */
     pxCCInfo->uiFlag =
      (0xFF==pxCCInfo->ucLineId)?IFX_DECT_CSU_UNKNOWN:IFX_DECT_CSU_PT_MGD_LINE;
    }
	else {
      /*  Collect the Multi Keypad events and check for LineId */
		if(IFX_DECT_CSU_KeypadEvents(pxIpcMsg, acRecvDigits, &bHookFlash)== IFX_SUCCESS){
          if((acRecvDigits[0] == '#')&&(acRecvDigits[1] != '\0')) {
            /*  received LineId */
            xCallParams.ucLineId = pxCCInfo->ucLineId = acRecvDigits[1] - 0x30 ;
            /*  This is a PT initiated call. Set the flag. */
            pxCCInfo->uiFlag =
            (0xFF==pxCCInfo->ucLineId)?IFX_DECT_CSU_UNKNOWN:IFX_DECT_CSU_PT_MGD_LINE;
		    strcpy(xCallParams.acRecvDigits, &acRecvDigits[2]);
	      }else{
		    strcpy(xCallParams.acRecvDigits, acRecvDigits);
	      }
		}
    }
  }/*For Catiq 1.0 handsets check if any digits were dialed along with the setup*/
  else {
	  IFX_DECT_CSU_KeypadEvents(pxIpcMsg, xCallParams.acRecvDigits, &bHookFlash);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			"Digits = ", xCallParams.acRecvDigits );

  }

  pxCCInfo->bCallDir  = IFX_DECT_CALL_DIR_OUT; /* Outgoing Call */ 
  pxCCInfo->eState = IFX_DECT_CS_SETUP; /* move to INIT state */
  strcpy(pxCCInfo->acCLIP,xCallParams.acRecvDigits);
  strcpy(pxCCInfo->acCNIP,xCallParams.acRecvDigits);
  /* The reason for generating call id for non catiq 2.0 handset is to handle parallel calls
     b/w catiq 2.0 handset and 1.0 handset*/
   IFX_DECT_MU_GetCallID(&ucCallId);
  pxCCInfo->ucCallId = ucCallId; /*  Store the CallId */
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
		  			"CallID : ", pxCCInfo->ucCallId );
/*Fill in the EcallType before checking Intrude or Intercept Req*/
  xCallParams.eCallType = pxCCInfo->ucBasicService;
	
/*Check whether the req is Intrude or Intercept*/
	if(xCallParams.acRecvDigits[0]== IFX_DECT_CSU_HEXCODE_PREFIX){
		if(xCallParams.acRecvDigits[1]==IFX_DECT_CSU_HEXCODE_INTERCEPT){
	/*check whether the Intrude/Intercept is allowed at this time*/
			if(IFX_DECT_CSU_IsIntrAllowed()!=IFX_SUCCESS){
    		ucRejectReason = IFX_DECT_USER_BUSY;
				eCallReason=IFX_DECT_CS_USR_BUSY;
				goto HandleSetupFailure;
			}
    	IFX_DECT_MU_FreeCallID(pxCCInfo->ucCallId);
			pxCCInfo->ucCallId = 0xFF;
			xCallParams.eCallType=IFX_DECT_CALL_INTERCEPT_REQ;
			xCallParams.acRecvDigits[0] = xCallParams.acRecvDigits[2];
			xCallParams.acRecvDigits[1] = '\0';
			pxCCInfo->uiFlag |= IFX_DECT_CSU_INTERCEPT_REQUESTED;
			pxCCInfo->uiFlag |= IFX_DECT_CSU_EXPLICIT_CONNECT;
		}else if(xCallParams.acRecvDigits[1]==IFX_DECT_CSU_HEXCODE_EXP_INTRU) {
	/*check whether the Intrude/Intercept is allowed at this time*/
			if(IFX_DECT_CSU_IsIntrAllowed()!=IFX_SUCCESS){
    		ucRejectReason = IFX_DECT_USER_BUSY;
				eCallReason=IFX_DECT_CS_USR_BUSY;
				goto HandleSetupFailure;
			}
    	IFX_DECT_MU_FreeCallID(pxCCInfo->ucCallId);
			pxCCInfo->ucCallId = 0xFF;
			if((bLineIdReceived)&&(xCallParams.ucLineId==0xFF)){
				xCallParams.ucLineId = 0x7F;
			}
			xCallParams.eCallType=IFX_DECT_CALL_INTRUSION_REQ;
			xCallParams.acRecvDigits[0] = xCallParams.acRecvDigits[2];
			xCallParams.acRecvDigits[1] = '\0';
			pxCCInfo->uiFlag |= IFX_DECT_CSU_INTRUDE_REQUESTED;
			pxCCInfo->uiFlag |= IFX_DECT_CSU_EXPLICIT_CONNECT;
		}
	}else{
		/*No need to do anything.Normal Call*/
	}
#if 0 //ndef SWAROOP_TEST
if(pxIpcMsg->ucPara1==3){
    //IFX_DECT_MU_FreeCallID(pxCCInfo->ucCallId);
		//pxCCInfo->ucCallId = 0xFF;
		//xCallParams.eCallType=IFX_DECT_CALL_INTERCEPT_REQ;
		//xCallParams.eCallType=IFX_DECT_CALL_INTRUSION_REQ;
		//xCallParams.acRecvDigits[0] = '*';
		xCallParams.acRecvDigits[0] = '\0';
		//pxCCInfo->uiFlag |= IFX_DECT_CSU_INTRUDE_REQUESTED;
		//pxCCInfo->uiFlag |= IFX_DECT_CSU_EXPLICIT_CONNECT;
		//pxCCInfo->uiFlag |= IFX_DECT_CSU_INTRUDE_REQUESTED;
		bLineIdReceived = 1;
		xCallParams.ucLineId = 0x7F;
	}
#endif
  paxActCallHdl[pxCCInfo->ucHandsetId - 1] = pxCCInfo; /*  Store as active call handle*/ 
  if(((pxCCInfo->ucBasicService&WIDEBAND_SPEEACH_BSERVICE) == WIDEBAND_SPEEACH_BSERVICE)
     && (pxCCInfo->aunCodec[0] == IFX_DECTNG_CODEC_G722_64)){
      pxCCInfo->bwideband = IFX_TRUE; 
  }else{
      pxCCInfo->bwideband = IFX_FALSE;
  }
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Codec Selected By PP For This Call (DECT)= ",
              pxCCInfo->aunCodec[0]);
  // JONATHAN_150312. Who modified this routine? Need verification.
   if(((pxCCInfo->bwideband == IFX_TRUE) && (pxIpcMsg->ucPara4 == 0)) || ((pxCCInfo->bwideband == IFX_FALSE) && (pxIpcMsg->ucPara4 == 1)))
   {
          IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
          "Codec  and slot does not match so Slotmodification requested!!! for HS ",pxIpcMsg->ucPara1);
    IFX_DECT_EncodeSlotModReq(pxIpcMsg->ucPara1,
	                      pxIpcMsg->ucInstance,
     	                  pxCCInfo->bwideband  == IFX_TRUE ? IFX_TRUE:IFX_FALSE, 
						  &xIpcMsg);
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
	}
  /* Invoke the callback after filling the callparams*/
  xCallParams.bwideband = pxCCInfo->bwideband;
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  pxCCInfo->uiFlag &= ~IFX_DECT_CSU_CIPHER_INITIATED;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Invoking CB" );
	if(bLineIdReceived&&!(pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_REQUESTED)&&
		!(pxCCInfo->uiFlag&IFX_DECT_CSU_INTERCEPT_REQUESTED)&&(xBSInfo.ucCallClass!=IFX_DECT_WBS_INTERNAL_CALL)&&
		(xBSInfo.ucCallClass!=IFX_DECT_INTERNAL_CALL)&&(vxCSUCallBks.pfnLineInfo!=NULL)){
		pxCCInfo->uiFlag |= IFX_DECT_CSU_PENDING_INIT;
		vxCSUCallBks.pfnLineInfo(pxCCInfo->ucHandsetId,&xCallParams);
		return IFX_SUCCESS;
	}
	else{
	
		eRet = vxCSUCallBks.pfnCallInitiate((uint32)pxCCInfo,pxCCInfo->ucHandsetId,&xCallParams,&eRejectReason_cb,
                    									(uint32*)&pxCCInfo->uiPrivateData);
	
		if(IFX_DECT_ENCRYPTION_MODE == IFX_TRUE && eRet != IFX_FAILURE){
			IFX_DECT_CSU_CipherChangeRequest((uint32)pxCCInfo);
		}
#if 0
		if(!strlen(xCallParams.acRecvDigits)&&bLineIdReceived&&eRet==IFX_PENDING&&!(pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_REQUESTED)){
    	IFX_DECT_MU_FreeCallID(pxCCInfo->ucCallId);
			pxCCInfo->ucCallId = 0xFF;
			pxCCInfo->uiFlag |= IFX_DECT_CSU_EXPLICIT_CONNECT;
			return IFX_SUCCESS;
		}else 
#endif
	if(eRet==IFX_FAILURE){
    	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Call Initiation Failed !!!!!" );
    	ucRejectReason = IFX_DECT_USER_BUSY;
			eCallReason=IFX_DECT_CS_INUSE;
    	goto HandleSetupFailure;
  	}else{/*SUCCESS*/
   	/* If Ciphering is off send connect here else initiate cipher and send connect at cipher cfm*/
    	if((IFX_DECT_ENCRYPTION_MODE == IFX_FALSE)&& (pxCCInfo->eState < IFX_DECT_CS_CONNECT)&&
					!(pxCCInfo->uiFlag&IFX_DECT_CSU_EXPLICIT_CONNECT)){
				xCallParams.ucPeerHandsetId=0;
				IFX_DECT_CSU_ExplicitConnect((uint32)pxCCInfo,&xCallParams);
			}
  		return IFX_SUCCESS;
		}

	}
HandleSetupFailure:
	IFX_DECT_CSU_SetupFailed((uint32)pxCCInfo,eCallReason,ucRejectReason);
  return IFX_FAILURE;
} 
	
/************************************************************************
* Function Name  : FP_ALERT_IN_CC
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleAlertMsg(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{  
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  int32 iIndex=(pxIpcMsg->ucPara1)-1; // always 0th index itself is used since its first call
  x_IFX_DECT_CC_Info *pxCCInfo = NULL;
#if 0
  x_IFX_DECT_CC_Info *pxPeerCCInfo = NULL;
#endif
  uint32 uiIEHdl = 0;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle Alert");
    
	if (iIndex<0 || iIndex>5)
   return IFX_FAILURE;

  pxCCInfo = &avxCCInfo[iIndex][0];
  if(IFX_DECT_CALL_DIR_IN  != pxCCInfo->bCallDir) {
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Invalid Call State");
    IFX_DECT_CSU_ReleaseBothPPAndAPP(
	         (uint32)pxCCInfo,
			  pxCCInfo->uiPrivateData);
	return IFX_SUCCESS;
  }

	if(pxIpcMsg->ucPara4)
	{
		uiSlotType |= (1 << pxIpcMsg->ucPara1);
	}
	else
	{
		uiSlotType &= !(1 << pxIpcMsg->ucPara1);
	}
  pxCCInfo->aunCodec[0] = (pxIpcMsg->ucPara3 != 255?pxIpcMsg->ucPara3:pxCCInfo->aunCodec[0]);
//  if( (pxCCInfo->bwdeband) &&  (pxCCInfo->aunCodec[0] == IFX_DECTNG_CODEC_G726_32)){
  if(((pxIpcMsg->ucPara4 == 0) && (pxCCInfo->aunCodec[0] == IFX_DECTNG_CODEC_G722_64)) ||
  ((pxIpcMsg->ucPara4 == 1) && (pxCCInfo->aunCodec[0] != IFX_DECTNG_CODEC_G722_64))){
    x_IFX_DECT_IPC_Msg xIpcMsg = {0};
#if 0
    x_IFX_DECT_CSU_CallParams xCallParams1={0};
#endif
    IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
          "Codecs differ from what was offered as the first priority, issue Slot modification request and peerhandset id is ",pxCCInfo->ucPeerHandsetId);
    IFX_DECT_EncodeSlotModReq(pxIpcMsg->ucPara1,
	                      pxIpcMsg->ucInstance,
     	                  IFX_DECTNG_CODEC_G722_64 == pxCCInfo->aunCodec[0]?IFX_TRUE:IFX_FALSE, 
						  &xIpcMsg);
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
#if 0
    if(pxCCInfo->ucPeerHandsetId != 0){
      pxPeerCCInfo = &avxCCInfo[pxCCInfo->ucPeerHandsetId-1][0];
      xCallParams1.bwideband = (IFX_DECTNG_CODEC_G722_64 == pxCCInfo->aunCodec[0]?IFX_TRUE:IFX_FALSE);
      IFX_DECT_CSU_ServiceChange((uint32)pxPeerCCInfo,&xCallParams1,IFX_DECT_CSU_SC_REQUEST);
    }
#endif
  }
  pxCCInfo->bwideband = (IFX_DECTNG_CODEC_G722_64 == pxCCInfo->aunCodec[0]?IFX_TRUE:IFX_FALSE);
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
          "Codec Selected By Pp In Alert (DECT)=", 
		  pxCCInfo->aunCodec[0]);

  xCallParams.bwideband = pxCCInfo->bwideband;
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  vxCSUCallBks.pfnCallAccept(
                (uint32)pxCCInfo,
                &xCallParams,
				pxCCInfo->uiPrivateData); 
       
	if(IFX_DECT_ENCRYPTION_MODE == IFX_TRUE){
		IFX_DECT_CSU_CipherChangeRequest((uint32)pxCCInfo);
	}
  pxCCInfo->eState = IFX_DECT_CS_ALERT;
 
  memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
  uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData); 
  
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Send CC-INFO for CallId and LineId.");
  IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
			                   0xFF,&xIpcMsg);
 
  if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){    
     IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,0xFF,
      0xFF,0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);	
  }
  /* Encode CNIP */
  if(strlen(pxCCInfo->acCNIP) >0) {
	     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			          pxCCInfo->acCNIP );
	     IFX_DECT_CSU_EncodeCNIP(pxCCInfo->acCNIP,strlen(pxCCInfo->acCNIP),
                  pxCCInfo->bIsPresentation,uiIEHdl,pxCCInfo->ucHandsetId);
   }

 
  /* Encode CLIP */
  if(strlen(pxCCInfo->acCLIP) >0) {
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					 pxCCInfo->acCLIP );
	  IFX_DECT_CSU_EncodeCLIP(pxCCInfo->acCLIP,strlen(pxCCInfo->acCLIP),
                pxCCInfo->bIsPresentation,uiIEHdl, pxCCInfo->isInternal);
  }

  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : FP_CONNECT_IN_CC
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts CONNECT_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
 Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleConnectMsg(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  int32 iIndex=(pxIpcMsg->ucPara1)-1; // always 0th index itself is used since its first call
  x_IFX_DECT_CC_Info *pxCCInfo = NULL;

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"Handle Connect");
  
	if (iIndex<0 || iIndex>5)
   return IFX_FAILURE;
  
	pxCCInfo = &avxCCInfo[iIndex][0];
  if(IFX_DECT_CALL_DIR_IN  != pxCCInfo->bCallDir){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Invalid Call State");

    IFX_DECT_CSU_ReleaseBothPPAndAPP(
	         (uint32)pxCCInfo,
			  pxCCInfo->uiPrivateData);
    return IFX_SUCCESS;
  }
  
	if(pxIpcMsg->ucPara4)
	{
		uiSlotType |= (1 << pxIpcMsg->ucPara1);
	}
	else
	{
		uiSlotType &= !(1 << pxIpcMsg->ucPara1);
	}
  pxCCInfo->aunCodec[0] = (pxIpcMsg->ucPara3 != 255?pxIpcMsg->ucPara3:pxCCInfo->aunCodec[0]);
//  if( (pxCCInfo->bwideband) &&  (pxCCInfo->aunCodec[0] == IFX_DECTNG_CODEC_G726_32)){
  if(((pxIpcMsg->ucPara4 == 0) && (pxCCInfo->aunCodec[0] == IFX_DECTNG_CODEC_G722_64)) ||
  ((pxIpcMsg->ucPara4 == 1) && (pxCCInfo->aunCodec[0] != IFX_DECTNG_CODEC_G722_64))){
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
          "Codecs differ from what was offered as the first priority, issue Slot mod request");
     IFX_DECT_EncodeSlotModReq(pxIpcMsg->ucPara1,
	                      pxIpcMsg->ucInstance,
     	                  IFX_DECTNG_CODEC_G722_64 == pxCCInfo->aunCodec[0]?IFX_TRUE:IFX_FALSE, 
						  &xIpcMsg);
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
 
  }
  pxCCInfo->bwideband = (IFX_DECTNG_CODEC_G722_64 == pxCCInfo->aunCodec[0]?IFX_TRUE:IFX_FALSE);
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
          "Codec Selected By Pp In Connect (DECT)=", 
		  pxCCInfo->aunCodec[0]);

  
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					 "Sending Connect ACK to PP");
  IFX_DECT_EncodeConnectAck(pxCCInfo->ucHandsetId, 
				                    pxCCInfo->ucInstanceId,
				                    &xIpcMsg );
  
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  
  xCallParams.bwideband = pxCCInfo->bwideband;
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);

  /* Star Dialing */
  /*This indicates the HS which answered the call. Its useful in the case of Star Dialing
    to update CNIP/CLIP of the PP that performed Star Dialing.*/
  if(pxCCInfo->isInternal == IFX_TRUE){
    xCallParams.ucPeerHandsetId = pxCCInfo->ucPeerHandsetId;
    IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
          "Peer Handset Id in Call Answer=",pxCCInfo->ucPeerHandsetId); 
    xCallParams.isInternal = IFX_TRUE;
  }

  vxCSUCallBks.pfnCallAnswer(
                (uint32)pxCCInfo,
                &xCallParams,
		        pxCCInfo->uiPrivateData);        

  pxCCInfo->eState = IFX_DECT_CS_CONNECT;

  /* need to send the status after callback, so that for external calls ack is received*/   
  if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){    
    uint32 uiIEHdl = 0;
    memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
	  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Send CC-INFO for CallId and LineId.");
	  IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
			                   0xFF,&xIpcMsg);
 
		uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData); 
	  IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_CONNECT,
		                               0xFF,0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);	
    /* Post to the Stack */

    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  }
  
  return IFX_SUCCESS;

}
/************************************************************************
* Function Name  : FP_RELEASE_IN_CC
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleReleaseMsg(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  uchar8 ucDectReleaseReason=0;
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  int32 i=0; 

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"Handle Release");
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"HandsetId is: ",
                 pxIpcMsg->ucPara1);



  ucDectReleaseReason = IFX_DECT_RELEASE_NORMAL; //Normal release
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				"Releasing All the calls");

  for(i=0;i<IFX_DECT_MAX_CALLS_PER_HS;i++) {
	  if(avxCCInfo[(pxIpcMsg->ucPara1)-1][i].eState == IFX_DECT_CS_SETUP){
		  /* If the PP hangs up before the call waiting had been accepted/rejected.
		     the FP shall send a CS Idle to PP */
      if(IFX_DECT_MU_IsCAT2(pxIpcMsg->ucPara1)){    
          IFX_DECT_CSU_SendAckToPP(pxIpcMsg->ucPara1, 
                                   pxIpcMsg->ucInstance,
                                              avxCCInfo[(pxIpcMsg->ucPara1)-1][i].ucCallId,
                                                avxCCInfo[(pxIpcMsg->ucPara1)-1][i].ucLineId,
                                                IFX_DECT_CS_IDLE,0xFF,0x8);
         }
      }
      // JONATHAN_150311. For informing Release message during LiA service,
      // "eState != IFX_DECT_CC_NOUPLANE" is not removed.
#if 0
      if((avxCCInfo[(pxIpcMsg->ucPara1)-1][i].eState != IFX_DECT_CS_IDLE) &&
         (avxCCInfo[(pxIpcMsg->ucPara1)-1][i].eState != IFX_DECT_CC_UPLANE)){
#else
      if((avxCCInfo[(pxIpcMsg->ucPara1)-1][i].eState != IFX_DECT_CS_IDLE)&&
       (avxCCInfo[(pxIpcMsg->ucPara1)-1][i].eState != IFX_DECT_CC_UPLANE)&&
       (avxCCInfo[(pxIpcMsg->ucPara1)-1][i].eState != IFX_DECT_CC_NOUPLANE)){
#endif
         if((avxCCInfo[(pxIpcMsg->ucPara1)-1][i].uiFlag&IFX_DECT_CSU_INTERCEPT_REQUESTED)){
            IFX_DECT_CSU_ClearInterceptInit(&avxCCInfo[(pxIpcMsg->ucPara1)-1][i]);
         }
         vxCSUCallBks.pfnCallRelease(
                   (uint32)&avxCCInfo[(pxIpcMsg->ucPara1)-1][i],
                   &xCallParams,
                   ucDectReleaseReason,
                   avxCCInfo[(pxIpcMsg->ucPara1)-1][i].uiPrivateData);
         //break;
      }
      #if 1
      else if(avxCCInfo[(pxIpcMsg->ucPara1)-1][i].eState == IFX_DECT_CC_NOUPLANE)
      {
         /*Release for LiA*/
         IFX_DECT_LAU_HandleReleaseMsg(pxIpcMsg);
      }
      #endif
  }
  /* Free the Call Control Info */
  IFX_DECT_CSU_FreeAllCCInfoOfThisHS(pxIpcMsg->ucPara1);
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Exit");
  return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_CC_HandleDeflection
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleDeflection(uchar8* pucRecvDigits, x_IFX_DECT_IPC_Msg *pxIpcMsg,x_IFX_DECT_CC_Info *pxCCInfo)
{
  e_IFX_DECT_ErrReason ucStatus;
  x_IFX_DECT_CSU_CallParams xCallParams={0};
	e_IFX_Return eRet=IFX_FAILURE;
  
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle Resume");

  if(IFX_DECT_CS_ALERT != pxCCInfo->eState)
  {
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Invalid Call State");
	    /* Call not in conversation state */
  	IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId, 
                         pxCCInfo->ucInstanceId,
						 pxCCInfo->ucCallId,
						 0xFF,pxCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
						 IFX_DECT_CSU_SIGNAL_NACK);

    return IFX_SUCCESS;
  }
	if (pucRecvDigits[0] == IFX_DECT_CSU_HEXCODE_PARA_CALL){
		xCallParams.isInternal = 1;
		strncpy(xCallParams.acRecvDigits,(char8*)&pucRecvDigits[1],1);
		xCallParams.acRecvDigits[1] =0;
	}else{
		xCallParams.isInternal = 0;
		strncpy(xCallParams.acRecvDigits, (char8*) &pucRecvDigits[1],strlen((char8*)pucRecvDigits) -1);
	}
  eRet = vxCSUCallBks.pfnCallDeflect(
                (uint32)pxCCInfo,
				&xCallParams, 
				&ucStatus,
				pxCCInfo->uiPrivateData);
	if (eRet == IFX_FAILURE){
		IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
							 pxCCInfo->ucInstanceId,
							 pxCCInfo->ucCallId,
							 0xFF,pxCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
							 IFX_DECT_CSU_SIGNAL_NACK);
	}
  return IFX_SUCCESS;
}

/****************Deflection Ack*********************************/
e_IFX_Return
IFX_DECT_CSU_DeflectionAck(IN uint32 uiCallHdl,
                               IN e_IFX_Return eStatus)
{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
	uchar8 ucCallId=0xFF;
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;

	memset(&xIpcMsg,0,sizeof(xIpcMsg)); 
  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo)){

    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid CallHandles");
    return IFX_FAILURE;                        
  }	

	ucCallId = pxCCInfo->ucCallId;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "CCInfo",pxCCInfo); 
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "CallID",pxCCInfo->ucCallId);  

  if(eStatus == IFX_FAILURE) {
		IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Deflection Failed sending NACK");
		IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
							 pxCCInfo->ucInstanceId, ucCallId,
							 pxCCInfo->ucLineId,IFX_DECT_CS_SETUP_ACK,IFX_DECT_CS_CODE_FAIL,
							 IFX_DECT_CSU_SIGNAL_NACK); 
      } 
  
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : FP_INFO_IN_CC
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleInfoMsg(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  x_IFX_DECT_CC_Info *pxCCInfo = NULL;
  x_IFX_DECT_CSU_CallParams xCallParams = {0};
  char8 acRecvDigits[IFX_DECT_MAX_DIGITS]={'\0'};
  boolean bHookFlash=0;
  uchar8 ucCallId=0xFF,ucLineId=0xFF;
  int32 iIndex=0; 
	//e_IFX_Return eRet=IFX_FAILURE;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"Handle INFO");
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"HandsetId is: ",
                 pxIpcMsg->ucPara1);
  if(paxActCallHdl[pxIpcMsg->ucPara1-1] == NULL){
     /*  Check the CallInformation IE for LineId*/
     pxCCInfo = &avxCCInfo[(pxIpcMsg->ucPara1)-1][0];
   }else{
     pxCCInfo = paxActCallHdl[pxIpcMsg->ucPara1-1];
   }

  /* Catiq 2.0 handset extract caller id*/
  if(IFX_DECT_MU_IsCAT2(pxIpcMsg->ucPara1)){    
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"CATIQ 2.0 handset, finding callid and lineid");
    if(IFX_DECT_CSU_DecodeCallInformation(pxIpcMsg,&ucCallId, &ucLineId) == IFX_SUCCESS){

		  if(ucCallId != 0xFF){
           iIndex = IFX_DECT_CSU_GetCCMatchIndex(pxIpcMsg->ucPara1,
						ucCallId,
						ucLineId);
           if((iIndex < 0) || (iIndex >= IFX_DECT_MAX_CALLS_PER_HS)){
              IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                  "Invalid CallID ");

	            IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
	                                 pxCCInfo->ucInstanceId,
	                                 ucCallId,
							            ucLineId,IFX_DECT_CS_IDLE,IFX_DECT_CS_CODE_FAIL,
							            IFX_DECT_CSU_SIGNAL_NACK); 
              return IFX_FAILURE;
           }
      		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Index is ",iIndex);
		  		pxCCInfo = &avxCCInfo[(pxIpcMsg->ucPara1)-1][iIndex];
      		/*  received LineId */
					if(pxCCInfo->ucLineId==0xFF||pxCCInfo->ucLineId==0||pxCCInfo->ucLineId==0x7F)
      			xCallParams.ucLineId = pxCCInfo->ucLineId = ucLineId ;
					else
						ucLineId=xCallParams.ucLineId = pxCCInfo->ucLineId;
		  }
    }
  	/*  Collect the Multi Keypad events and check for LineId */
	if(IFX_DECT_CSU_KeypadEvents(pxIpcMsg, acRecvDigits, &bHookFlash) != IFX_FAILURE){
		if(pxCCInfo->uiFlag&IFX_DECT_CSU_INTERCEPT_INITIATED){
	  	switch(acRecvDigits[0]){
	    	case IFX_DECT_CSU_HEXCODE_PREFIX:
	    	case INTERNAL_CALL_REQUEST:
	    	case REGISTER_RECALL_REQUEST:
	   		IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
	      	                      pxCCInfo->ucInstanceId,
	        	                    pxCCInfo->ucCallId,
										            pxCCInfo->ucLineId,0xFF,IFX_DECT_CS_CODE_FAIL,
										            IFX_DECT_CSU_SIGNAL_NACK); 
    		return IFX_SUCCESS;
				case '#' :
			{
		    strcpy(xCallParams.acRecvDigits, acRecvDigits);
  			vxCSUCallBks.pfnInterceptAccept((uint32)pxCCInfo,
                											&xCallParams, 
                											pxCCInfo->uiPrivateData); 
				IFX_DECT_CSU_ClearInterceptInit(pxCCInfo);
			}
			return IFX_SUCCESS;
			default:
			return IFX_SUCCESS;
			}
		}else if(pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_INITIATED){
	  	switch(acRecvDigits[0]){
	    	case IFX_DECT_CSU_HEXCODE_PREFIX:
	    	case INTERNAL_CALL_REQUEST:
	    	case REGISTER_RECALL_REQUEST:
	   		IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
	      	                      pxCCInfo->ucInstanceId,
	        	                    pxCCInfo->ucCallId,
										            pxCCInfo->ucLineId,0xFF,IFX_DECT_CS_CODE_FAIL,
										            IFX_DECT_CSU_SIGNAL_NACK); 
    		return IFX_SUCCESS;
				break;
      	default:
    		return IFX_SUCCESS;
	  	}
		}else if(pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_REQUESTED){
	  		switch(acRecvDigits[0]){
	    		case IFX_DECT_CSU_HEXCODE_PREFIX:
						strcpy(xCallParams.acRecvDigits,&acRecvDigits[1]);
						break;
					default:
						IFX_DECT_CSU_CallIntrusionAck((uint32)pxCCInfo,0,IFX_FAILURE);
						return IFX_SUCCESS;
				}
				if((strlen(xCallParams.acRecvDigits)==0)&&(xCallParams.ucLineId == 0xFF)){
					xCallParams.ucLineId = 0x7F;
				}
  		vxCSUCallBks.pfnIntrudeInfoRecv((uint32)pxCCInfo,
                											&xCallParams, 
                											pxCCInfo->uiPrivateData); 
			return IFX_SUCCESS;
		}else{
	  switch(acRecvDigits[0]){
	    case '#':
	    {
/*DECT_PASSTHRU_MULTIKEYPAD_DIGITS : This flag should be defined where Application takes care of Line ID. 
If this flag is defined then TK will pass digits to Application */
#ifndef DECT_PASSTHRU_MULTIKEYPAD_DIGITS
			if(vucPassAllDigits2App)
			{
		        strcpy(xCallParams.acRecvDigits, acRecvDigits);
			}
         else if(acRecvDigits[1] != '\0'){
            /*  received LineId */
            ucLineId = xCallParams.ucLineId = pxCCInfo->ucLineId = acRecvDigits[1]-0x30 ;
            /*  This is a PT initiated call. Set the flag. */
            pxCCInfo->uiFlag =
             ((0xFF==pxCCInfo->ucLineId) || (0x7F==pxCCInfo->ucLineId))?IFX_DECT_CSU_UNKNOWN:IFX_DECT_CSU_PT_MGD_LINE;
            /* Copy the remaining digits */
            if(acRecvDigits[2] != '\0'){    
		          strcpy(xCallParams.acRecvDigits, &acRecvDigits[2]);
            }
          }
          else
#endif
					{
		        strcpy(xCallParams.acRecvDigits, acRecvDigits);
          }
	    }
	    break;
	    case IFX_DECT_CSU_HEXCODE_PREFIX:
			    if(acRecvDigits[1] == REGISTER_RECALL_REQUEST){
            IFX_DECT_CC_HandleParallelCall((uchar8*)&acRecvDigits[1],pxIpcMsg,pxCCInfo);
					}else if(acRecvDigits[1] == IFX_DECT_CSU_HEXCODE_DEFLECT){
            IFX_DECT_CC_HandleDeflection((uchar8*)&acRecvDigits[2],pxIpcMsg,pxCCInfo);
					}else{
            IFX_DECT_CSU_Fsm(acRecvDigits[1], pxIpcMsg,pxCCInfo);
					}
          return IFX_SUCCESS;
	    case INTERNAL_CALL_REQUEST:
	    case REGISTER_RECALL_REQUEST:
          IFX_DECT_CC_HandleParallelCall((uchar8*)acRecvDigits,pxIpcMsg,pxCCInfo);
	      	return IFX_SUCCESS;
        default:
		  	strcpy(xCallParams.acRecvDigits, acRecvDigits);
	  }
	}
	}
  }
  else{ /* Not a Catiq 2.0 handset*/
    /*  Collect the Multi Keypad events */
	  if(IFX_DECT_CSU_KeypadEvents(pxIpcMsg, acRecvDigits, &xCallParams.bHookFlash) != IFX_FAILURE){
/*DECT_PASSTHRU_MULTIKEYPAD_DIGITS : This flag should be defined where Application takes care of Line ID. 
If this flag is defined then TK will pass digits to Application */
#ifndef DECT_PASSTHRU_MULTIKEYPAD_DIGITS
		if(vucPassAllDigits2App)
		{
	        strcpy(xCallParams.acRecvDigits, acRecvDigits);
		}
    else if((acRecvDigits[0]=='#')){
        if(acRecvDigits[1] != '\0'){
          /*  received LineId */
          ucLineId = xCallParams.ucLineId = pxCCInfo->ucLineId = acRecvDigits[1]-0x30 ;
          /*  This is a PT initiated call. Set the flag. */
          pxCCInfo->uiFlag =
            ((0xFF==pxCCInfo->ucLineId) || (0x7F==pxCCInfo->ucLineId))?IFX_DECT_CSU_UNKNOWN:IFX_DECT_CSU_PT_MGD_LINE;
          /* Copy the remaining digits */
          if(acRecvDigits[2] != '\0'){    
		        strcpy(xCallParams.acRecvDigits, &acRecvDigits[2]);
          }
        }
        else{
		      strcpy(xCallParams.acRecvDigits, acRecvDigits);
        }
	    }
      else
#endif
			{
		    strcpy(xCallParams.acRecvDigits, acRecvDigits);
      }
	    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			       	"Got Digits = ", xCallParams.acRecvDigits );      
    } 
  }

	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
				"pxccinfo state is = ", pxCCInfo->eState );      
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
				"IFX_DECT_CS_CONNECT = ", IFX_DECT_CS_CONNECT );      
  if(pxCCInfo->eState < IFX_DECT_CS_CONNECT){
     strcat(pxCCInfo->acCLIP,xCallParams.acRecvDigits);
     strcat(pxCCInfo->acCNIP,xCallParams.acRecvDigits);
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				"CLIP ON FT is = ", pxCCInfo->acCLIP );      
   }
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  /*eRet=*/vxCSUCallBks.pfnInfoReceived(
                (uint32)pxCCInfo,
                &xCallParams, 
                pxCCInfo->uiPrivateData);
	/* Agent/App has to handle all the cases*/ 
  return IFX_SUCCESS;   
}


uint32 uiSlotMod[IFX_DECT_MAX_HS]={0}; 
uint32 uiIWUSent[IFX_DECT_MAX_HS]={0}; 
/************************************************************************
* Function Name  : IFX_DECT_CC_HandleServiceChangeRq
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleServiceChangeRq(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  x_IFX_DECT_CC_Info *pxCCInfo = paxActCallHdl[pxIpcMsg->ucPara1-1];

  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"Handle Service Change Rq by PP");
#if 0
  if(IFX_DECT_MU_IsCAT2(pxIpcMsg->ucPara1))
  {
	  if(IFX_DECT_ValidateRxCallID(pxIpcMsg)==IFX_FAILURE){
           IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					 "Invalid Caller ID, so sent NACK");
			  return IFX_SUCCESS;
	  }
  }
#endif	
  pxCCInfo->aunCodec[0] = pxIpcMsg->ucPara3;
  xCallParams.bwideband = pxCCInfo->bwideband = (IFX_DECTNG_CODEC_G722_64 == pxIpcMsg->ucPara3)?IFX_TRUE:IFX_FALSE;
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                    "Invoking pfnServiceChange" );
  vxCSUCallBks.pfnServiceChange(
                (uint32)pxCCInfo,
                &xCallParams, 
    		    IFX_DECT_CSU_SC_REQUEST,
				pxCCInfo->uiPrivateData);        
  pxCCInfo->eState = IFX_DECT_CC_MEDIA_NEG;
  return IFX_SUCCESS;   
}

/************************************************************************
* Function Name  : IFX_DECT_CC_HandleServiceChangeAccept
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleServiceChangeAccept(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  x_IFX_DECT_IPC_Msg xIPCMsg = {0};
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  x_IFX_DECT_CC_Info *pxCCInfo = paxActCallHdl[pxIpcMsg->ucPara1-1];
  
  printf("Call Handle Is %d State %d\n",(uint32)pxCCInfo,pxCCInfo->eState);
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"Service Change Accepted by PP"); 
#if 0
  if(IFX_DECT_MU_IsCAT2(pxIpcMsg->ucPara1))
  {
	  if(IFX_DECT_ValidateRxCallID(pxIpcMsg)==IFX_FAILURE){
           IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					 "Invalid Caller ID, so sent NACK");
			  return IFX_SUCCESS;
	  }
  }
#endif
  /* Call the Callbacks to stop the Voice */ 
  xCallParams.bwideband = pxCCInfo->bwideband;
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "Invoking pfnVoiceModify");
  vxCSUCallBks.pfnVoiceModify(
                (uint32)pxCCInfo,
                &xCallParams,
				IFX_DECT_STOP_VOICE,
				pxCCInfo->uiPrivateData);
  uiSlotMod[pxIpcMsg->ucPara1-1] = 1;
  IFX_DECT_EncodeSlotModReq(pxCCInfo->ucHandsetId,
                                 pxCCInfo->ucInstanceId,
								 pxCCInfo->bwideband == IFX_TRUE?1:0, 
								 &xIPCMsg);
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"Send Change SlotMod request to stack"); 
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
  return IFX_SUCCESS;   
}

/************************************************************************
* Function Name  : IFX_DECT_CC_HandleServiceChangeReject
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleServiceChangeReject(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  x_IFX_DECT_CC_Info *pxCCInfo = paxActCallHdl[pxIpcMsg->ucPara1-1];
  
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					"Service Change Rejected by PP"); 
#if 0	
  if(IFX_DECT_MU_IsCAT2(pxIpcMsg->ucPara1))
  {
	  if(IFX_DECT_ValidateRxCallID(pxIpcMsg)==IFX_FAILURE){
           IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					 "Invalid Caller ID, so sent NACK");
			  return IFX_SUCCESS;
	  }
  }
#endif	
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                      "Invoking pfnServiceChange" );
  vxCSUCallBks.pfnServiceChange(
                (uint32)pxCCInfo,
				&xCallParams, 
				IFX_DECT_CSU_SC_REJECT,
				pxCCInfo->uiPrivateData);        
  pxCCInfo->eState = IFX_DECT_CS_CONNECT;
  return IFX_SUCCESS;

}

/************************************************************************
* Function Name  : IFX_DECT_CC_HandleSlotModification
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleSlotModification(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  x_IFX_DECT_IPC_Msg xIPCMsg={0};
  //x_IFX_DECT_CSU_CallParams xCallParams={0};
  x_IFX_DECT_CC_Info *pxCCInfo = paxActCallHdl[pxIpcMsg->ucPara1-1];
 
  if(pxCCInfo == NULL){
    return IFX_SUCCESS;
  } 

	if(pxIpcMsg->ucPara4){
		if(pxIpcMsg->ucPara3)
		{
			uiSlotType |= (1 << pxIpcMsg->ucPara1);
		}
		else
		{
			uiSlotType &= !(1 << pxIpcMsg->ucPara1);
		}
	}

  printf("Call Handle Is %d State %d\n",(uint32)pxCCInfo,pxCCInfo->eState);
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
			"Slot Mod Indication from Dect Stack received for handset",pxIpcMsg->ucPara1);


 /* xCallParams.bwideband = */pxCCInfo->bwideband = 
	  ((pxIpcMsg->ucPara3 == 1)||(pxIpcMsg->ucPara3 == 3))?IFX_TRUE:IFX_FALSE;
  /*xCallParams.uiIEHandler =*/ IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  /* Indicate the PP that codec is accepted */
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "Send IWU Info to PP");
#if 0
  vxCSUCallBks.pfnServiceChange(
                (uint32)pxCCInfo,
				&xCallParams, 
				IFX_DECT_CSU_SC_ACCEPT,
				pxCCInfo->uiPrivateData);        
#endif
  if(uiSlotMod[pxIpcMsg->ucPara1-1]==1){
    IFX_DECT_EncodeSlotIWUInfo(pxIpcMsg->ucPara1,
                         pxCCInfo->ucInstanceId,
                         pxCCInfo->bwideband,
                         &xIPCMsg);
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
    IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                "moving from MEDIA_NEG->CONNECTED state");
    uiSlotMod[pxIpcMsg->ucPara1-1]=0;
    uiIWUSent[pxIpcMsg->ucPara1-1]=1;
  }

  	if(pxCCInfo->uiFlag&IFX_DECT_CSU_PENDING_ENVOICE)
	{
		pxCCInfo->uiFlag &= ~IFX_DECT_CSU_PENDING_ENVOICE;
		memset(&xIPCMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
		IFX_DECT_EncodeEnableVoice(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,pxCCInfo->unHwVoiceChannel,&xIPCMsg);
		IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
	}
 return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CC_HandleServiceChangeIwu
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleServiceChangeIwu(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  x_IFX_DECT_IPC_Msg xIPCMsg={0};
  x_IFX_DECT_CC_Info *pxCCInfo = paxActCallHdl[pxIpcMsg->ucPara1-1];
  
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Service Change IWU from Dect Stack received");
  if(pxIpcMsg->ucPara3 ==  0xFF){
    IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			" IWU from Dect Stack received without service change request");
     return IFX_SUCCESS;
  }

  xCallParams.bwideband = pxCCInfo->bwideband=((pxIpcMsg->ucPara3 == 1)||(pxIpcMsg->ucPara3 == 3))?IFX_TRUE:IFX_FALSE;
  /* Call the Callbacks to stop the Voice */ 
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "Invoking pfnVoiceModify");
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  vxCSUCallBks.pfnVoiceModify(
               (uint32)pxCCInfo,
               &xCallParams,
               IFX_DECT_START_VOICE,
			   pxCCInfo->uiPrivateData);
  if(uiIWUSent[pxIpcMsg->ucPara1-1] == 0){
  /* IWU Should be sent irrespective, you recv slot mod or not*/
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Send IWU Info to PP");
  IFX_DECT_EncodeSlotIWUInfo(pxIpcMsg->ucPara1,
                         pxCCInfo->ucInstanceId,
                         pxCCInfo->bwideband,
                         &xIPCMsg);
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
 }
 uiIWUSent[pxIpcMsg->ucPara1-1]=0;
  pxCCInfo->eState = IFX_DECT_CS_CONNECT;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                "moving from MEDIA_NEG->CONNECTED state");
 	return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_CC_HandleCipher
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleCiphering(x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  int32 uiIEHdl=0; 
  x_IFX_DECT_CC_Info *pxCCInfo = NULL;
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};

  pxCCInfo = &avxCCInfo[(pxIpcMsg->ucPara1)-1][0]; 
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle Cipher");
  /*If LIA Call send call proc*/
  if(((pxCCInfo->ucBasicService&0x20) == 0x20)&&(pxIpcMsg->ucPara2 ==1)){
    IFX_DECT_EncodeCallProc(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,
                                     &xIpcMsg);
	  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
    return IFX_SUCCESS;
  }else if((pxCCInfo->ucBasicService&0x20) == 0x20){
      /* Send Release with reason encryption fail*/
      IFX_DECT_CSU_CallRelease((uint32)pxCCInfo,&xCallParams,IFX_DECT_RELEASE_ENCR_ACT_FAIL);
    return IFX_SUCCESS;
  }
  if( (pxCCInfo->eState == IFX_DECT_CC_UPLANE) ||(pxCCInfo->eState == IFX_DECT_CC_NOUPLANE)){
    return IFX_FAILURE;
  }
  xCallParams.bCipheringStatus = 
				(pxIpcMsg->ucPara2 ==1)?IFX_TRUE:IFX_FALSE;

  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
         "Cipher Status selected by PP (DECT)=", xCallParams.bCipheringStatus);
  
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  vxCSUCallBks.pfnCipherCfm(
                 (uint32)pxCCInfo,
	             &xCallParams, 
				 pxCCInfo->uiPrivateData);

  if( xCallParams.bCipheringStatus == IFX_FALSE){

     IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "exiting cipher function due to failure in cipher");
     return IFX_SUCCESS;
  }
       
  if(pxCCInfo->eState != IFX_DECT_CS_SETUP){
    pxCCInfo->uiFlag &= ~IFX_DECT_CSU_CIPHER_INITIATED;
    return IFX_SUCCESS;
  } 
    if (((pxCCInfo->uiFlag & IFX_DECT_CSU_CIPHER_INITIATED) == IFX_DECT_CSU_CIPHER_INITIATED)
      &&(xCallParams.bCipheringStatus == IFX_TRUE)
      &&(pxCCInfo->bCallDir  == IFX_DECT_CALL_DIR_OUT)
			&&((pxCCInfo->uiFlag & IFX_DECT_CSU_EXPLICIT_CONNECT) != IFX_DECT_CSU_EXPLICIT_CONNECT))
    {
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
          "Cipher Confirmation for the Outgoing call");
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	        "Sending Connect to PP");
			x_IFX_DECT_CSU_CallParams xCallParams={0};
			xCallParams.ucPeerHandsetId=0;
			IFX_DECT_CSU_ExplicitConnect((uint32)pxCCInfo,&xCallParams);
    
  }else if(((pxCCInfo->uiFlag & IFX_DECT_CSU_CIPHER_INITIATED) == IFX_DECT_CSU_CIPHER_INITIATED)
      &&(xCallParams.bCipheringStatus == IFX_TRUE)
      &&(pxCCInfo->bCallDir  == IFX_DECT_CALL_DIR_IN)
			&&((pxCCInfo->uiFlag & IFX_DECT_CSU_EXPLICIT_CONNECT) != IFX_DECT_CSU_EXPLICIT_CONNECT))
  {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	              "Already LiA call....... send Connect");
      /* Construct CC Connect */
	    IFX_DECT_EncodeConnect(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
			                  pxCCInfo->bwideband,&xIpcMsg);
	    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      //Send Call Waiting Indication to the PP.
	    //Encode CC-Info
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          "Send Call Waiting Indication To PP");
      IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,
	                          pxCCInfo->ucInstanceId,
                            IFX_DECT_CSU_SIGNAL_CW,
		                        &xIpcMsg);
      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);
      paxActCallHdl[pxCCInfo->ucHandsetId - 1] = pxCCInfo; /*  Store as active Index*/ 
      if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){
      /* Construct the CALL-INFORMATION IE  */      
	    IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_SETUP,0xFF,
			                         0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
      }

      /* Encode CLIP */
      if(strlen(pxCCInfo->acCLIP) >0) {
	      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					 pxCCInfo->acCLIP );
	      IFX_DECT_CSU_EncodeCLIP(pxCCInfo->acCLIP,strlen(pxCCInfo->acCLIP),
                 pxCCInfo->bIsPresentation, uiIEHdl,pxCCInfo->isInternal);
     }
     /* Encode CNIP */
     if(strlen(pxCCInfo->acCNIP) >0) {
	        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			             pxCCInfo->acCNIP );
	        IFX_DECT_CSU_EncodeCNIP(pxCCInfo->acCNIP,strlen(pxCCInfo->acCNIP),
                  pxCCInfo->bIsPresentation,uiIEHdl,pxCCInfo->ucHandsetId);
     }
    /* Post to the Stack */
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  }
  pxCCInfo->uiFlag &= ~IFX_DECT_CSU_CIPHER_INITIATED;
  return IFX_SUCCESS;
}



/************************************************************************
* Function Name  : IFX_DECT_CC_HandleParallelCall
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* **n***********************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleParallelCall(uchar8 *pcRecvDigits,x_IFX_DECT_IPC_Msg *pxIpcMsg,
							   x_IFX_DECT_CC_Info *pxActiveCCInfo)
{
  //uint32 uiIEHdl=0;
  e_IFX_DECT_ErrReason ucStatus;
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  e_IFX_DECT_ErrReason ucRejectReason;
  x_IFX_DECT_CC_Info *pxCCInfo=0;
	/*point the pxCCInfo to this local struct in failed case before CCInfo alloc*/
  #if 0 
	x_IFX_DECT_CC_Info xTempCCInfo;/*local struct to store Info in case setup fails before allocating CCInfo*/
	#endif
  //x_IFX_DECT_IPC_Msg xIpcMsg={0};
  int32 iActiveIdx=0;
  //e_IFX_DECT_CC_State ePrevState=IFX_DECT_CS_IDLE; 
	uchar8 ucLineId=0xFF,ucCallId=0xFF;
	e_IFX_Return eRet=IFX_FAILURE;
	e_IFX_DECT_IE_CallReason eCallReason=0xFF;
	//uchar8 ucIntrusion=0;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle Parallel Call");
  
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Allocate Call Info");
        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  		   	"<Parallel call Initr1> Running Codec  is", IFX_DECT_MU_GetRunCodec(pxIpcMsg->ucPara1));
        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  		   	"<Parallel call Initr2> Codec  is", IFX_DECT_MU_GetCodec(pxIpcMsg->ucPara1));
#if 0 
 xTempCCInfo.ucHandsetId   = pxIpcMsg->ucPara1; /*  HandsetId */
  xTempCCInfo.ucInstanceId  = pxIpcMsg->ucInstance; /*  InstanceId */
	xTempCCInfo.ucCallId = 0xFF;
/*Filling with 0xFF inorder to check in setup fail whether to free the CC Info or not*/
	xTempCCInfo.eState=0xFF;
#endif

  /*Prepare CallControl Info*/ 
  if((iActiveIdx= IFX_DECT_CSU_AllocCCInfo(pxIpcMsg->ucPara1,&pxCCInfo))== IFX_FAILURE) {
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Free CC Info");
      eCallReason=IFX_DECT_CS_BUSY;
		ucCallId = IFX_DECT_MAX_FT_CALLS;/*LAST CALL ID which never used*/
#if 1 /* TODO:Written by sanat but already in ParallelCallFailure */
	                //pxCCInfo=&xTempCCInfo;
	                 /* Call status disconnecting and reason*/
	        IFX_DECT_CSU_SendAckToPP(pxIpcMsg->ucPara1,
									 pxIpcMsg->ucInstance,
									 ucCallId,
									 0xFF,IFX_DECT_CS_DISCONNECT,eCallReason,
									 0x04);
	       sleep(2);
	    /* Call status idle inorder to free the callid*/
	        IFX_DECT_CSU_SendAckToPP(pxIpcMsg->ucPara1,
	                         pxIpcMsg->ucInstance,
							 ucCallId,
							 0xFF,IFX_DECT_CS_IDLE,0xFF,
							 0x3F);
  return IFX_SUCCESS;  
#endif
	//	pxCCInfo=&xTempCCInfo;
	  //goto ParallelCallFailure;
  }
  //ePrevState = pxCCInfo->eState;

	if(pcRecvDigits[0] == INTERNAL_CALL_REQUEST)
	{
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
            "Parallel INT Call Requested");
		pxCCInfo->isInternal=1;
	}
	else if(pcRecvDigits[0] == REGISTER_RECALL_REQUEST)
	{
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
            "REGISTER_RECALL_REQUEST Requested");
	}
	else
	{
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
            "!!!!!!!!!!Please check what is Requested??????????");
	}

  /* Collect the Multi Keypad events and check for LineId */
/*DECT_PASSTHRU_MULTIKEYPAD_DIGITS : This flag should be defined where Application takes care of Line ID. 
If this flag is defined then TK will pass digits to Application */
#ifndef DECT_PASSTHRU_MULTIKEYPAD_DIGITS
	if(vucPassAllDigits2App)
	{
    strcpy(pxCCInfo->acDigits, (char8*)&pcRecvDigits[1]);
	}
  else if(pcRecvDigits[1] == '#') {
    /*  received LineId */
    pxCCInfo->ucLineId = pcRecvDigits[2] - 0x30;
    /*  This is a PT initiated call. Set the flag. */
    pxCCInfo->uiFlag =
        (0xFF==pxCCInfo->ucLineId)?IFX_DECT_CSU_UNKNOWN:IFX_DECT_CSU_PT_MGD_LINE;
    strcpy(pxCCInfo->acDigits, (char8*)&pcRecvDigits[3]);
  }else
#endif
	{ /* If no line ID collect only numbers*/
    strcpy(pxCCInfo->acDigits, (char8*)&pcRecvDigits[1]);
  }
  
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				"Got Digits = ", pxCCInfo->acDigits );     
  if(IFX_DECT_CSU_DecodeCallInformation(pxIpcMsg,&ucCallId, &ucLineId) == IFX_SUCCESS){
      pxCCInfo->ucLineId = xCallParams.ucLineId = ucLineId;
	}	
 
  pxCCInfo->ucHandsetId = pxIpcMsg->ucPara1;
  pxCCInfo->ucInstanceId =pxIpcMsg->ucInstance;
  strcat(pxCCInfo->acCLIP,pxCCInfo->acDigits);
  strcat(pxCCInfo->acCNIP,pxCCInfo->acDigits);
	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				        "CLIP ON FT is = ", pxCCInfo->acCLIP );      
 
  pxCCInfo->ucBasicService = IFX_DECT_MU_GetBasicService(pxCCInfo->ucHandsetId);
  pxCCInfo->aunCodec[0] = IFX_DECT_MU_GetCodec(pxCCInfo->ucHandsetId);
  if(((pxCCInfo->ucBasicService&WIDEBAND_SPEEACH_BSERVICE) == WIDEBAND_SPEEACH_BSERVICE)
       ||(pxCCInfo->aunCodec[0] == IFX_DECTNG_CODEC_G722_64)){
        pxCCInfo->bwideband = IFX_TRUE; 
  }
	/* Get the free CallId */
  IFX_DECT_MU_GetCallID(&ucCallId);
  pxCCInfo->ucCallId = ucCallId; /* Store the CallId */
  if(pxActiveCCInfo->eState == IFX_DECT_CS_CONNECT)
  { 
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
            "Parallel Call is initiated by PP in Conv state");
    pxCCInfo->eState = IFX_DECT_CS_SETUP; /* move to INIT state */
 	  
    pxActiveCCInfo->uiFlag |= IFX_DECT_CSU_PENING_PCALL;
    /* Tell the application to hold the call so that parallel call can be started */
    xCallParams.bHookFlash = IFX_TRUE;
    vxCSUCallBks.pfnCallHold(
                (uint32)pxActiveCCInfo,
				&xCallParams, 
				&ucStatus,
				pxActiveCCInfo->uiPrivateData);

  }
  else
  {
    if(pxActiveCCInfo != pxCCInfo)
    { 
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
            "Parallel Call is initiated by PP in Hold state");
      /* Set the Module Owner */  
      IFX_DECT_MU_SetModuleOwner(pxCCInfo->ucHandsetId,
	         IFX_DECT_MU_ADD_OWNER,IFX_DECT_CSU_ID);
    }
    pxCCInfo->eState = IFX_DECT_CS_SETUP; /* move to INIT state */
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"HandsetId is: ",
              pxCCInfo->ucHandsetId);
#if 1
		xCallParams.isInternal=pxCCInfo->isInternal;
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Call type INT= ",
              pxCCInfo->isInternal);
#endif
   
    /* Invoke the callback after filling the callparams*/
    xCallParams.bwideband = pxCCInfo->bwideband;
    xCallParams.eCallType = pxCCInfo->ucBasicService;
    xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  
	  strcpy(xCallParams.acRecvDigits, pxCCInfo->acDigits);
    pxCCInfo->bCallDir  = IFX_DECT_CALL_DIR_OUT; /* Outgoing Call */ 
    
    paxActCallHdl[pxCCInfo->ucHandsetId - 1] = pxCCInfo; /*  Store as active Index*/ 
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
		  	 "CallID : ", pxCCInfo->ucCallId );
		if(xCallParams.ucLineId!=0xFF&&xCallParams.ucLineId!=0x7F&&(vxCSUCallBks.pfnLineInfo!=NULL)){
			pxCCInfo->uiFlag |= IFX_DECT_CSU_PENDING_PCALL;
			vxCSUCallBks.pfnLineInfo(pxCCInfo->ucHandsetId,&xCallParams);
			return IFX_SUCCESS;
		}else{
    eRet = vxCSUCallBks.pfnCallInitiate((uint32)pxCCInfo,
	                             pxCCInfo->ucHandsetId, 
		                         &xCallParams,
				                 &ucRejectReason,
				                 &pxCCInfo->uiPrivateData); 
   
			if(eRet==IFX_FAILURE){
   		IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "Parallel Call Init Failed !!!!!" );
				eCallReason=IFX_DECT_CS_INUSE;
   			goto ParallelCallFailure;
			}
#if 0
else if(eRet==IFX_PENDING){
			/*Nothing to do just return success then call Pcall success or pcall failure from application*/
				pxCCInfo->uiFlag |= IFX_DECT_CSU_PENDING_PCALL;
			}
#endif
			else if(eRet==IFX_SUCCESS){
			IFX_DECT_CSU_ParallelCallSuccess((uint32)pxCCInfo);
			}
		}
	    //pxCCInfo->eState = IFX_DECT_CS_CONNECT;
 	}
  return IFX_SUCCESS;
ParallelCallFailure:
	IFX_DECT_CSU_ParallelCallFailed((uint32)pxCCInfo,eCallReason);
  return IFX_SUCCESS;  
}

/************************************************************************
* Function Name  : IFX_DECT_CC_HandleHold
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleHold(x_IFX_DECT_IPC_Msg *pxIpcMsg,x_IFX_DECT_CC_Info *pxCCInfo)
{  
  e_IFX_DECT_ErrReason ucStatus;
  x_IFX_DECT_CSU_CallParams xCallParams={0};
    
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle Hold");
 
  if((IFX_DECT_CS_CONNECT != pxCCInfo->eState)||(pxCCInfo->uiFlag&IFX_DECT_CSU_INTERCEPT_INITIATED))
  {
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Invalid Call State");
    /* Call not in conversation state */
  	IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId, 
                         pxCCInfo->ucInstanceId,
						 pxCCInfo->ucCallId,
						 0xFF,pxCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
						 IFX_DECT_CSU_SIGNAL_NACK);

    return IFX_SUCCESS;
  }
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);

  vxCSUCallBks.pfnCallHold(
                (uint32)pxCCInfo,
				&xCallParams, 
				&ucStatus,
				pxCCInfo->uiPrivateData);
  
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CC_HandleResume
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleResume(x_IFX_DECT_IPC_Msg *pxIpcMsg,x_IFX_DECT_CC_Info *pxCCInfo)
{
  e_IFX_DECT_ErrReason ucStatus;
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle Resume");
  if(IFX_DECT_CS_HOLD != pxCCInfo->eState)
  {
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Invalid Call State");
	    /* Call not in conversation state */
  	IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId, 
                         pxCCInfo->ucInstanceId,
						 pxCCInfo->ucCallId,
						 0xFF,pxCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
						 IFX_DECT_CSU_SIGNAL_NACK);

    return IFX_SUCCESS;
  }
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);

  vxCSUCallBks.pfnCallResume(
                (uint32)pxCCInfo,
				&xCallParams, 
				&ucStatus,
				pxCCInfo->uiPrivateData);
   
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CC_HandleToggle
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleToggle(x_IFX_DECT_IPC_Msg *pxIpcMsg,x_IFX_DECT_CC_Info *pxHeldCCInfo)
{
  e_IFX_DECT_ErrReason ucStatus;
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle Toggle");
  if(pxHeldCCInfo->eState!= IFX_DECT_CS_HOLD){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "targeted call not on hold");
	    /* Call not in conversation state */
  	IFX_DECT_CSU_SendAckToPP(pxHeldCCInfo->ucHandsetId, 
                         pxHeldCCInfo->ucInstanceId,
						 pxHeldCCInfo->ucCallId,
						 0xFF,pxHeldCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
						 IFX_DECT_CSU_SIGNAL_NACK);

    return IFX_SUCCESS;
  }
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  vxCSUCallBks.pfnCallToggle(
                (uint32)pxHeldCCInfo,
		  (uint32)paxActCallHdl[pxIpcMsg->ucPara1-1],
				&xCallParams, 
				&ucStatus,
				pxHeldCCInfo->uiPrivateData);
   
  return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_CC_HandleCwAccept
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleCwAccept(x_IFX_DECT_IPC_Msg *pxIpcMsg,x_IFX_DECT_CC_Info *pxCCInfo)
{
  x_IFX_DECT_CSU_CallParams xCallParams={0};
//  e_IFX_DECT_ErrReason eStatus=0;
  x_IFX_DECT_CC_Info *pxActiveCCInfo=paxActCallHdl[pxIpcMsg->ucPara1-1];
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};    
  uint32 uiIEHdl=0;
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle CW Accept");


  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"Matched CCInfo is", pxCCInfo );

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"Active CCInfo is", pxActiveCCInfo );

  if(pxActiveCCInfo != pxCCInfo){
   
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "No Call present in active state");

    /* Call not in conversation state */
  	IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId, 
                         pxCCInfo->ucInstanceId,
						 pxCCInfo->ucCallId,
						 0xFF,pxCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
						 IFX_DECT_CSU_SIGNAL_NACK);

    return IFX_SUCCESS;
  }
  /* The state check was performed for the below case
     1> After call waiting the active call was release by remote party
     In that case the ParaCallHdl would have got release and if so the state shall be idle and
     there by should not set the CWA flag*/
	if((pxCCInfo->uiParaCallHdl != 0)&&(((x_IFX_DECT_CC_Info *)(pxCCInfo->uiParaCallHdl))->eState != IFX_DECT_CS_IDLE)){
    ((x_IFX_DECT_CC_Info *)(pxCCInfo->uiParaCallHdl))->uiFlag |= IFX_DECT_CSU_PENING_CWA;
	}
  //pxActiveCCInfo->uiFlag |= IFX_DECT_CSU_PENING_CWA;
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
#if 0
  vxCSUCallBks.pfnCallHold(
                (uint32)pxActiveCCInfo,
				&xCallParams, 
				&eStatus,
				(uint32)pxActiveCCInfo->uiPrivateData);
#endif
  /* Send Call accept for the call waiting */
  xCallParams.bwideband = pxCCInfo->bwideband;

  /* Star Dialing */
  /* This aids sending updating CLIP/CNIP to the HS that performs Star Dialing,
     when the call waiting is answered by one of the alerting HS*/
  xCallParams.isInternal = pxCCInfo->isInternal;
  if( xCallParams.isInternal == IFX_TRUE ){
    xCallParams.ucPeerHandsetId = pxActiveCCInfo->ucPeerHandsetId;
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"CALL WAIT Peer Handset Id is(ActCCInfo)", pxActiveCCInfo->ucPeerHandsetId);
  }

  vxCSUCallBks.pfnCallAnswer(
              (uint32)pxCCInfo,
              &xCallParams,
		        pxCCInfo->uiPrivateData); 
		
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"<CWA> bwideband is", xCallParams.bwideband );
	
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"<CWA> Running Codec  is", IFX_DECT_MU_GetRunCodec(pxCCInfo->ucHandsetId));
	if(
			 ((((xCallParams.bwideband ==0 )&& 
			 (IFX_DECT_MU_GetRunCodec(pxCCInfo->ucHandsetId) == IFX_DECTNG_CODEC_G722_64)))||
			 ((xCallParams.bwideband ==1 )&& 
			 (IFX_DECT_MU_GetRunCodec(pxCCInfo->ucHandsetId) == IFX_DECTNG_CODEC_G726_32)))
			 &&(vxGlobalInfo.xMU.vxMUInfo[pxCCInfo->ucHandsetId-1].ucCSURefCount == 0 )
			){ 
			 IFX_DECT_CSU_ServiceChange((uint32)pxCCInfo,&xCallParams,IFX_DECT_CSU_SC_REQUEST);
		}
	 /* In case of a LIA call parallel call handle will be zero and the cs_connect is sent here
	  * and not in holdAck*/
  /* The state check was performed for the below case
     1> After call waiting the active call was release by remote party
     In that case the ParaCallHdl would have got release and if so the state shall be idle and
     there by send CS_Connect from here*/
	if((pxCCInfo->uiParaCallHdl == 0)||(((x_IFX_DECT_CC_Info *)(pxCCInfo->uiParaCallHdl))->eState == IFX_DECT_CS_IDLE)){
    /* Send the CallID aswell for completness*/
    uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);

    IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_CONNECT,0xFF,
			                               0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Sending Call hold for the first call.");

    /* Send CC-INFO message */
    IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
                              0xFF,&xIpcMsg); //TODO RAD CHECK this why zero was sent

    /* Post to the Stack */
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);	
	}
    return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CC_HandleCwReject
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleCwReject(x_IFX_DECT_IPC_Msg *pxIpcMsg,x_IFX_DECT_CC_Info *pxCCInfo)
{
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  x_IFX_DECT_CC_Info *pxActiveCCInfo=paxActCallHdl[pxIpcMsg->ucPara1-1];

  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle CW Reject");

  if(pxActiveCCInfo != pxCCInfo){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "No Call present in active state");

    /* Call not in conversation state */
  	IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId, 
                         pxCCInfo->ucInstanceId,
						 pxCCInfo->ucCallId,
						 0xFF,pxCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
						 IFX_DECT_CSU_SIGNAL_NACK);

    return IFX_SUCCESS;
  }

  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  
  /* send Call Idle */
  IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId, 
                         pxCCInfo->ucInstanceId,
						 pxCCInfo->ucCallId,
						 0xFF,IFX_DECT_CS_IDLE,0xFF,
						 0xFF);
#if 0
// TODO send release only when only one handset is registered
  if(IFX_DECT_MU_GetNoOfRegHandset() == 1){
  }
#endif
     vxCSUCallBks.pfnCallRelease(
                (uint32)pxCCInfo,
	            &xCallParams, 
				IFX_DECT_RELEASE_NORMAL,
				pxCCInfo->uiPrivateData);

  IFX_DECT_CSU_FreeCCInfo(pxCCInfo);
   
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CC_HandleRelease
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleRelease(x_IFX_DECT_IPC_Msg *pxIpcMsg,x_IFX_DECT_CC_Info *pxCCInfo)
{
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle Release");
  
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  if(vxCSUCallBks.pfnCallRelease(
                  (uint32)pxCCInfo,
	              &xCallParams, IFX_DECT_RELEASE_NORMAL,
				  pxCCInfo->uiPrivateData) == IFX_SUCCESS){
 
    IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
	                         pxCCInfo->ucInstanceId,
	                         pxCCInfo->ucCallId,
							 pxCCInfo->ucLineId, IFX_DECT_CS_IDLE,0xFF,
							 0xFF); 
	  IFX_DECT_CSU_FreeCCInfo(pxCCInfo);
 }else{
   IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
	                         pxCCInfo->ucInstanceId,
	                         pxCCInfo->ucCallId,
							 pxCCInfo->ucLineId, IFX_DECT_CS_CONNECT,IFX_DECT_CS_CODE_FAIL,
							 IFX_DECT_CSU_SIGNAL_NACK); 
 }
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CC_CWAcceptActiveRel
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_CWAcceptActiveRel(x_IFX_DECT_IPC_Msg *pxIpcMsg,x_IFX_DECT_CC_Info *pxCCInfo)
{ 
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};    
  uint32 uiIEHdl=0;
  x_IFX_DECT_CC_Info *pxActiveCCInfo = paxActCallHdl[pxIpcMsg->ucPara1-1];
  x_IFX_DECT_CC_Info *pxRelCCInfo = NULL;
  
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle Active call release with replacement");

  if(vxGlobalInfo.xMU.vxMUInfo[pxIpcMsg->ucPara1-1].ucCSURefCount <1) {
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "active Call Release is not possible as there is only 1 call exists !!!!!");
	IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
	                         pxCCInfo->ucInstanceId,
	                         pxCCInfo->ucCallId,
							 pxCCInfo->ucLineId,pxCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
							 IFX_DECT_CSU_SIGNAL_NACK); 
	return IFX_SUCCESS;
  }
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  if(pxCCInfo->eState == IFX_DECT_CS_SETUP)
  {
    IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Waiting call replacement");
    pxRelCCInfo = (x_IFX_DECT_CC_Info *)(pxActiveCCInfo->uiParaCallHdl);
  } else {
    IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Held call replacement");
    pxRelCCInfo = pxActiveCCInfo;
  }
  vxCSUCallBks.pfnCallRelease(
                //(uint32)pxActiveCCInfo,
                (uint32)pxRelCCInfo,
	              &xCallParams, 
				     IFX_DECT_RELEASE_NORMAL,
				     //pxActiveCCInfo->uiPrivateData);
				     pxRelCCInfo->uiPrivateData);

  IFX_DECT_CSU_SendAckToPP(pxActiveCCInfo->ucHandsetId,
	                         pxActiveCCInfo->ucInstanceId,
	                         //pxActiveCCInfo->ucCallId,
	                         pxRelCCInfo->ucCallId,
							 //pxActiveCCInfo->ucLineId, IFX_DECT_CS_IDLE,0xFF,
							 pxRelCCInfo->ucLineId, IFX_DECT_CS_IDLE,0xFF,
							 0xFF); 

  //IFX_DECT_CSU_FreeCCInfo(pxActiveCCInfo);
  IFX_DECT_CSU_FreeCCInfo(pxRelCCInfo);

  xCallParams.bwideband = pxCCInfo->bwideband;
  xCallParams.uiIEHandler =0;
  xCallParams.uiFlag |= IFX_DECT_FLAG_ACTIVE_CALL_REPLACE;
  if(pxCCInfo->eState == IFX_DECT_CS_SETUP)
  {
    vxCSUCallBks.pfnCallAnswer(
                (uint32)pxCCInfo,
                &xCallParams,
		          pxCCInfo->uiPrivateData);
  } else {
    e_IFX_DECT_ErrReason ucStatus;
    vxCSUCallBks.pfnCallResume(
                (uint32)pxCCInfo,
                &xCallParams,
                &ucStatus,
		          pxCCInfo->uiPrivateData);
  }

  /* Send the CallID aswell for completness*/
  uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);

  IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_CONNECT,0xFF,
			                               0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);

  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Sending Call connect for the waiting call.");

  /* Send CC-INFO message */
  IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
                              0xFF,&xIpcMsg); //TODO RAD CHECK this why 0 was sent

  /* Post to the Stack */
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);	
   
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"<CWAActiveRel> bwideband is", xCallParams.bwideband );
	
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"<CWAActiveRel> Running Codec  is", IFX_DECT_MU_GetRunCodec(pxCCInfo->ucHandsetId));
 		if(
			 (((xCallParams.bwideband ==0 )&& 
			 (IFX_DECT_MU_GetRunCodec(pxCCInfo->ucHandsetId) == IFX_DECTNG_CODEC_G722_64))||
			 ((xCallParams.bwideband ==1 )&& 
			 (IFX_DECT_MU_GetRunCodec(pxCCInfo->ucHandsetId) == IFX_DECTNG_CODEC_G726_32)))
			 &&(vxGlobalInfo.xMU.vxMUInfo[pxCCInfo->ucHandsetId-1].ucCSURefCount == 0 )
			){ 
			 IFX_DECT_CSU_ServiceChange((uint32)pxCCInfo,&xCallParams,IFX_DECT_CSU_SC_REQUEST);
		} 
 
  return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_CC_HandleTransfer
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleTransfer(x_IFX_DECT_IPC_Msg *pxIpcMsg,x_IFX_DECT_CC_Info *pxHeldCCInfo)
{
  e_IFX_DECT_ErrReason ucStatus;
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle Transfer");  
  
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  vxCSUCallBks.pfnCallTransfer(
	            (uint32)pxHeldCCInfo,
		  (uint32)paxActCallHdl[pxIpcMsg->ucPara1-1],
				&xCallParams, 
				&ucStatus,
				pxHeldCCInfo->uiPrivateData);
   
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CC_HandleConf
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_CC_HandleConf(x_IFX_DECT_IPC_Msg *pxIpcMsg,x_IFX_DECT_CC_Info *pxHeldCCInfo)
{
  e_IFX_DECT_ErrReason ucStatus;
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Handle Conference");
  
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Held CCInfo",pxHeldCCInfo); 

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Active CCInfo",paxActCallHdl[pxIpcMsg->ucPara1-1]); 

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Held CallID",pxHeldCCInfo->ucCallId);  
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Active CallID",paxActCallHdl[pxIpcMsg->ucPara1-1]->ucCallId);  
  //iIndex =1;
  if(IFX_DECT_CSU_IsHSInConfState(pxIpcMsg->ucPara1)==IFX_SUCCESS) {
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Conference is not possible if there are more than 2 calls !!!!!");
	  IFX_DECT_CSU_SendAckToPP(pxHeldCCInfo->ucHandsetId,
	                         pxHeldCCInfo->ucInstanceId,
	                         pxHeldCCInfo->ucCallId,
							 pxHeldCCInfo->ucLineId, pxHeldCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
							 IFX_DECT_CSU_SIGNAL_NACK); 
	  return IFX_SUCCESS;
  }
  xCallParams.uiIEHandler = IFX_DECT_IE_GetIEHandler(pxIpcMsg);
  vxCSUCallBks.pfnCallConference(
	            (uint32)pxHeldCCInfo,(uint32)paxActCallHdl[pxIpcMsg->ucPara1-1],
				      &xCallParams, &ucStatus,
				      pxHeldCCInfo->uiPrivateData);
  return IFX_SUCCESS;
}

/************************************************************************:
* Function Name  : IFX_DECT_CSU_Fsm
* Description    : This routine sends the Busy sytem or line notificaion to the PP
* Input Values   : pxIPCMsg IPC message
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 	
IFX_DECT_CSU_Fsm(IN uchar8 ucHexCode, IN x_IFX_DECT_IPC_Msg *pxIpcMsg,
				 x_IFX_DECT_CC_Info *pxCCInfo)
{
  switch (ucHexCode){    
		case IFX_DECT_CSU_HEXCODE_TOGGLE:
		{
		  IFX_DECT_CC_HandleToggle(pxIpcMsg,pxCCInfo);
		  break;
		}
	case IFX_DECT_CSU_HEXCODE_CONF:
		{
		  IFX_DECT_CC_HandleConf(pxIpcMsg,pxCCInfo);
		  break;
		}
	case IFX_DECT_CSU_HEXCODE_TRANS:
		{
		  IFX_DECT_CC_HandleTransfer(pxIpcMsg,pxCCInfo);
		  break;
		}
#if 0
	case IFX_DECT_CSU_HEXCODE_DEFLECT:
		{
		  IFX_DECT_CC_HandleDeflection(pxIpcMsg,pxCCInfo);
		  break;
		}
	case IFX_DECT_CSU_HEXCODE_EXP_INTRU:
		{
		  IFX_DECT_CC_HandleExplicitIntru(pxIpcMsg,pxCCInfo);
		  break;
		}
#endif
    case IFX_DECT_CSU_HEXCODE_REL:
		{
		  IFX_DECT_CC_HandleRelease(pxIpcMsg,pxCCInfo);
		  break;
		}
    case IFX_DECT_CSU_HEXCODE_CWACCEPT_ACTIVEREL:
		{
		  IFX_DECT_CC_CWAcceptActiveRel(pxIpcMsg,pxCCInfo);
		  break;
		}
    case IFX_DECT_CSU_HEXCODE_CW_ACCEPT:
		{
		  IFX_DECT_CC_HandleCwAccept(pxIpcMsg,pxCCInfo);
		  break;
		}
	case IFX_DECT_CSU_HEXCODE_CW_REJECT:
		{
		  IFX_DECT_CC_HandleCwReject(pxIpcMsg,pxCCInfo);
		  break;
		}
	case IFX_DECT_CSU_HEXCODE_ONHOLD:
		{
		  IFX_DECT_CC_HandleHold(pxIpcMsg,pxCCInfo);
		  break;
		}
	case IFX_DECT_CSU_HEXCODE_RESUME:
		{
		  IFX_DECT_CC_HandleResume(pxIpcMsg,pxCCInfo);
		  break;
		}
	default:
		{
			break;
		}
  }

  return IFX_SUCCESS;

}
/************************************************************************
* Function Name  : IFX_DECT_CSU_ProcessStackMsg
* Description    : Process CSU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return IFX_DECT_CSU_ProcessStackMsg(IN x_IFX_DECT_IPC_Msg *pxIPCMsg)
{
IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"MSG is: ",
                 pxIPCMsg->ucMsgId);
IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"ucPara1 is: ",
                 pxIPCMsg->ucPara1);
IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"ucPara2 is: ",
                 pxIPCMsg->ucPara2);
IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"ucPara3 is: ",
                 pxIPCMsg->ucPara3);
IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"ucPara4 is: ",
                 pxIPCMsg->ucPara4);
  switch (pxIPCMsg->ucMsgId){
    case FP_SETUP_IN_CC:
			{
				IFX_DECT_CC_HandleSetupMsg(pxIPCMsg);
				break;
			}
		case FP_ALERT_IN_CC:
			{	
				IFX_DECT_CC_HandleAlertMsg(pxIPCMsg);			    
				break;
			}
		case FP_CONNECT_IN_CC:
			{	
				IFX_DECT_CC_HandleConnectMsg(pxIPCMsg);			    
			  break;
			}
		case FP_INFO_IN_CC:
			{	
				IFX_DECT_CC_HandleInfoMsg(pxIPCMsg);
				break;
			}
		case FP_RELEASE_IN_CC:
			{	
				IFX_DECT_CC_HandleReleaseMsg(pxIPCMsg);
				break;
			}
		case FP_SERVICE_CHANGE_IN_CC:
		{
			IFX_DECT_CC_HandleServiceChangeRq(pxIPCMsg);
			break;
		}
		case FP_SERVICE_ACCEPT_IN_CC:
		{
			IFX_DECT_CC_HandleServiceChangeAccept(pxIPCMsg);	
      break;

		}
		case FP_SERVICE_REJECT_IN_CC:
		{
			IFX_DECT_CC_HandleServiceChangeReject(pxIPCMsg);	
      break;
		}
		case FP_IWU_INFO_IN_CC:
		{
			IFX_DECT_CC_HandleServiceChangeIwu(pxIPCMsg);
			break;
		}
		case FP_SLOTTYPE_MOD_IN_MAC:
        {
		  IFX_DECT_CC_HandleSlotModification(pxIPCMsg);	
          break;
		}

		case FP_CIPHER_ON_CFM_MM:
		case FP_CIPHER_OFF_CFM_MM:
		{
			IFX_DECT_CC_HandleCiphering(pxIPCMsg);
			break;
		}
		case FP_AUTHENTICATE_PT_CFM_MM:
		{
       if(pxIPCMsg->ucPara2 ==1){
          x_IFX_DECT_IPC_Msg xIpcMsg={0};
			    IFX_DECT_EncodeEnableCipher(pxIPCMsg->ucPara1,
                                      pxIPCMsg->ucInstance, 
	                                    1,
                                      &xIpcMsg);
          IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
       }else
       {
          IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "PT Authenticate CFM Failed");
			    IFX_DECT_CC_HandleCiphering(pxIPCMsg);
       }
		   break;
		}
		default:
		{
			break;
		}
	}

  return IFX_SUCCESS;

}



/************************************************************************
                           API's
* *************************************************************************/

/************************************************************************
* Function Name  : IFX_DECT_CSU_CallInitiate
* Description    : This API is called by Application when there is incoming call 
*                  for a PP. This API posts SETUP_IN_CC message to PP after initial
*						       sanity checks.
* Input Values   : 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_CallInitiate(IN uchar8 ucHandsetId,
                          IN x_IFX_DECT_CSU_CallParams *pxCallParams, 
                          IN uint32 uiPrivateData,
	                  	    OUT uint32 *puiCallHdl)
{
  uchar8 ucInstance = 0;
  x_IFX_DECT_IPC_Msg xIPCMsg={0};
  x_IFX_DECT_CC_Info *pxCCInfo = NULL;
  uint32 uiIEHdl = 0;
  uchar8 ucCallId=0;
  int32 iActiveIdx=0;
  uchar8 ucIsCCSetup =0;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

  /*Pointer Sanity Check*/
  if(!pxCallParams || !puiCallHdl){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "NULL Handles");
    return IFX_FAILURE;
   }
  
  /*Initial Checks*/
  if((ucHandsetId ==0)||(ucHandsetId >IFX_DECT_MAX_HS) ){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Incorrect Handset Id");
     return IFX_FAILURE;
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Checking HS State");

  /* Is the handset busy???   */
  if(IFX_SUCCESS == IFX_DECT_MU_IsHandSetBusy(ucHandsetId)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Handset Busy");
    return IFX_FAILURE; 
  } 

  /* Is any other call is existing in this handset ?? */
  if(IFX_DECT_MU_IsCallExisting(ucHandsetId,((uchar8 *)&ucInstance))== IFX_SUCCESS) {
	  if(!IFX_DECT_MU_IsCAT2(ucHandsetId)){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"Call Hdl for GAP CW : ",paxActCallHdl[ucHandsetId-1]);
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Call already exists on the handset cannot initiate parallel call on GAP handset");
      *puiCallHdl = (uint32)paxActCallHdl[ucHandsetId-1];
      return IFX_FAILURE;
	  }
  }
  else{
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Get MCEI");
    ucInstance = IFX_DECT_GetMCEI(ucHandsetId); 
  }

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Module owner is set to CSU");
   
  /* Allocate Call Control Info */
  if((iActiveIdx= IFX_DECT_CSU_AllocCCInfo(ucHandsetId,&pxCCInfo))== IFX_FAILURE) {
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Free CC Info");
    return IFX_FAILURE;
  }

	if (pxCCInfo == NULL)
		return IFX_FAILURE;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"CCINFO ActiveIndex is : ",iActiveIdx);
  if(pxCCInfo->eState == IFX_DECT_CS_IDLE){ 
    if(IFX_FAILURE == IFX_DECT_MU_SetModuleOwner(ucHandsetId,
               IFX_DECT_MU_ADD_OWNER,IFX_DECT_CSU_ID)){
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "Can't set Module Owner");
      return IFX_FAILURE;
    }
  }

  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"Call bwideband : ",pxCallParams->bwideband);
  /*Prep CC Info*/
  pxCCInfo->ucInstanceId = ucInstance;
  pxCCInfo->ucHandsetId   = ucHandsetId;
  pxCCInfo->uiPrivateData = uiPrivateData;
	if(pxCCInfo->eState != IFX_DECT_CC_NOUPLANE) 
  	pxCCInfo->bwideband = pxCallParams->bwideband;

  pxCCInfo->bCallDir  = IFX_DECT_CALL_DIR_IN; /* Incoming call */  
  pxCCInfo->bIsPresentation = pxCallParams->bIsPresentation;
  *puiCallHdl = (uint32)pxCCInfo;
  if(strlen(pxCallParams->acCLIP) >0) {
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					          pxCallParams->acCLIP );
    strcpy(pxCCInfo->acCLIP,pxCallParams->acCLIP);
  }
         
  if(strlen(pxCallParams->acCNIP) >0) {
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			                pxCallParams->acCNIP );
     strcpy(pxCCInfo->acCNIP,pxCallParams->acCNIP);
  }
  if((pxCallParams->isInternal == IFX_TRUE) && (pxCallParams->ucPeerHandsetId > 0 && pxCallParams->ucPeerHandsetId <= IFX_DECT_MAX_HS)){ 
    //internal call
    pxCCInfo->isInternal = pxCallParams->isInternal;
    if(paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucPeerHandsetId == 0xFF){
      paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucPeerHandsetId =
      pxCCInfo->ucHandsetId;
      paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->isInternal = pxCallParams->isInternal;
    }
    pxCCInfo->ucPeerHandsetId = pxCallParams->ucPeerHandsetId;//SS
  }
 
  if(IFX_DECT_MU_IsCAT2(ucHandsetId)){
    /* The application must have checked its dialplan and set the isInternal flag. */
    /* For the Internal call, the same CallId has to be sent as it is for the caller. */
    pxCCInfo->isInternal = pxCallParams->isInternal;
    if((pxCallParams->isInternal == IFX_TRUE) && (pxCallParams->ucPeerHandsetId != 0xFF)){ //internal call
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "This is an Internal Call.");
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"PeerHandsetId : ",pxCallParams->ucPeerHandsetId);
      /* If peer handset is not 2.0 compliant Call ID will be FF */
      //if(IFX_DECT_MU_IsCAT2(pxCallParams->ucPeerHandsetId)){
      if(paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucCallId != 0xFF){
        ucCallId = paxActCallHdl[pxCallParams->ucPeerHandsetId-1]->ucCallId;
        pxCCInfo->ucPeerHandsetId = pxCallParams->ucPeerHandsetId;
      }
      else{
        IFX_DECT_MU_GetCallID(&ucCallId);
      }
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			   "Internal CallId = ", ucCallId );
     pxCCInfo->ucLineId = 0x7F; 
    }else{//must be a new external call
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "This is an External Call.");
      if(pxCallParams->ucLineId == 0)
        pxCCInfo->ucLineId = 0x7F; //for FXS endpoint
      else
        pxCCInfo->ucLineId = pxCallParams->ucLineId; //store the LineId
      /*  Get the free CallId from MU.  */           
	    ucCallId = 0xFF;
      IFX_DECT_MU_GetCallID(&ucCallId);
   }
   pxCCInfo->ucCallId = ucCallId; /*  Store the CallId */
   pxCCInfo->uiParaCallHdl = (uint32)paxActCallHdl[pxCCInfo->ucHandsetId - 1];
  }
  //Already Call exists?????
  if((pxCCInfo->eState == IFX_DECT_CC_UPLANE) ||
     (pxCCInfo->eState == IFX_DECT_CC_NOUPLANE)){
		  pxCCInfo->uiParaCallHdl=0;
        if(pxCCInfo->eState == IFX_DECT_CC_NOUPLANE){
          if(((IFX_DECT_ENCRYPTION_MODE == IFX_TRUE)) && (IFX_DECT_MU_GetCipherStatus(pxCCInfo->ucHandsetId) != IFX_TRUE)){
              IFX_DECT_CSU_CipherChangeRequest((uint32)pxCCInfo);
              pxCCInfo->eState = IFX_DECT_CS_SETUP; /* move to INIT state */
              paxActCallHdl[pxCCInfo->ucHandsetId - 1] = pxCCInfo; /*  Store as active Index*/
              return IFX_SUCCESS;
          }
          else{
            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	              "Already LiA call....... send Connect");
            /* Construct CC Connect */
	          IFX_DECT_EncodeConnect(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
			                  pxCCInfo->bwideband,&xIPCMsg);
	          IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
          }
        }
        //Send Call Waiting Indication to the PP.
	      //Encode CC-Info
        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	                  "Send Call Waiting Indication To PP");
        IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,
	                          pxCCInfo->ucInstanceId,
                            IFX_DECT_CSU_SIGNAL_CW, /* Since this was the first call singal should be alerting*/
		                        &xIPCMsg);
        pxCCInfo->eState = IFX_DECT_CS_PROC; 
  }
	else if(vxGlobalInfo.xMU.vxMUInfo[ucHandsetId-1].ucCSURefCount >0) {
    if(IFX_DECT_MU_IsCAT2(ucHandsetId) 
	   /*&& IFX_DECT_MU_IsCallWaitingTone(ucHandsetId)*/)
	  {
      //Send Call Waiting Indication to the PP.
	    //Encode CC-Info

      pxCCInfo->eState = IFX_DECT_CS_SETUP; /* move to INIT state */
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	        "Send Call Waiting Indication To PP");

      IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,
	                          pxCCInfo->ucInstanceId,
                            IFX_DECT_CSU_SIGNAL_CW,/*IFX_DECT_CSU_SIGNAL_CW sent from Agent*/
		                        &xIPCMsg);

	  }
	  else
	  {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
	        "Handset doesn't support Callwaiting");
      if(pxCCInfo != NULL)
        IFX_DECT_CSU_FreeCCInfo(pxCCInfo);
	    
			return IFX_FAILURE;
	  }
  }
  else 
  {
	 e_IFX_DECT_CallType eCallType;
	 uchar8 ucSignal=0xFF;
    pxCCInfo->eState = IFX_DECT_CS_SETUP; /* move to INIT state */
	if((pxCallParams->uiSignal == 0xFF) || (pxCallParams->uiSignal == 0x00))
	{
		ucSignal=(pxCallParams->isInternal)?IFX_DECT_SIGNAL_AlertPattern0:IFX_DECT_SIGNAL_AlertOnCont;
	}
	else
	{
		ucSignal=((uchar8)pxCallParams->uiSignal);
	}
	 if(IFX_DECT_MU_IsWb(ucHandsetId)){
              if(IFX_DECT_MU_IsCAT2(ucHandsetId)){
		 eCallType = ((pxCallParams->isInternal == IFX_TRUE) && (pxCallParams->ucPeerHandsetId != 0xFF))?IFX_DECT_WBS_INTERNAL_CALL:IFX_DECT_WBS_EXTERNAL_CALL;
              }else{
		 eCallType = ((pxCallParams->isInternal == IFX_TRUE) && (pxCallParams->ucPeerHandsetId != 0xFF))?IFX_DECT_WBS_EXTERNAL_CALL:IFX_DECT_WBS_EXTERNAL_CALL;
              }
	 }else
	 {
		 eCallType = ((pxCallParams->isInternal == IFX_TRUE) && (pxCallParams->ucPeerHandsetId != 0xFF))?IFX_DECT_EXTERNAL_CALL:IFX_DECT_EXTERNAL_CALL; 
	 }
   printf("Call type %d Internal %d Wideband %d\n",eCallType,pxCCInfo->isInternal,pxCCInfo->bwideband); 
 	  /* Encode the Setup Message */
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Encoding Setup");
    IFX_DECT_EncodeSetup(pxCCInfo->ucHandsetId,
	                       pxCCInfo->ucInstanceId,
                         pxCCInfo->bwideband,eCallType,ucSignal,
                         &xIPCMsg);
    
    /* Added by radvajesh */
    pxCCInfo->aunCodec[0] =
     (pxCCInfo->bwideband)?IFX_DECTNG_CODEC_G722_64:IFX_DECTNG_CODEC_G726_32; /*  which codec? */
    
   IFX_DECT_MU_SetCodec(pxCCInfo->ucHandsetId,pxCCInfo->aunCodec[0]);
   
   IFX_DECT_MU_SetRunCodec(pxCCInfo->ucHandsetId,pxCCInfo->aunCodec[0]);
  
   pxCCInfo->ucBasicService = pxCCInfo->bwideband?IFX_DECT_WBS_EXTERNAL_CALL:IFX_DECT_EXTERNAL_CALL ; 	

   IFX_DECT_MU_SetBasicService(pxCCInfo->ucHandsetId,pxCCInfo->ucBasicService); 
   ucIsCCSetup =1;
  }
  uiIEHdl = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"Prev Active CCInfo is", paxActCallHdl[pxCCInfo->ucHandsetId - 1] );

  paxActCallHdl[pxCCInfo->ucHandsetId - 1] = pxCCInfo; /*  Store as active Index*/
 
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"Current Active CCInfo is", paxActCallHdl[pxCCInfo->ucHandsetId - 1] );

  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"CallId = ", ucCallId );
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  			"LineId = ", pxCCInfo->ucLineId );
  
  if(IFX_DECT_MU_IsCAT2(ucHandsetId)) {
    /* Construct the CALL-INFORMATION IE  */      
	IFX_DECT_CSU_EncodeCallInformation(ucCallId,IFX_DECT_CS_SETUP,0xFF,
			                         0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
  }

  //if(ucIsCCSetup ==0){
   // JONATHAN_150209. In order to append Caller ID information in CC_SETUP.
   /* Encode CLIP */
   if(strlen(pxCallParams->acCLIP) >0) {
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 pxCallParams->acCLIP );
       IFX_DECT_CSU_EncodeCLIP(pxCallParams->acCLIP,strlen(pxCallParams->acCLIP),
                pxCallParams->bIsPresentation,uiIEHdl, pxCCInfo->isInternal);
   }
   if (ucIsCCSetup == 0) {
   /* Encode CNIP */
   // CNIP is skipped for CC-SETUP by DLC packet length limit
      if(strlen(pxCallParams->acCNIP) >0) {
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            pxCallParams->acCNIP );
         IFX_DECT_CSU_EncodeCNIP(pxCallParams->acCNIP,strlen(pxCallParams->acCNIP),
                  pxCallParams->bIsPresentation,uiIEHdl,pxCCInfo->ucHandsetId);
    }
 }

  /*Add User defined IE*/
  if(pxCallParams->uiIEHandler != 0){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Adding User defined IE");
    if(IFX_DECT_IE_IEAppend(uiIEHdl,pxCallParams->uiIEHandler) == 0){
			goto CallSetup_FailHandler;
    }
  } 

  /* Post to the Stack */
  return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);

CallSetup_FailHandler:      
   /*Free Call Control Info*/  
   if(pxCCInfo != NULL)
     IFX_DECT_CSU_FreeCCInfo(pxCCInfo);
   return IFX_FAILURE;
}


/************************************************************************
* Function Name  : IFX_DECT_CSU_CallAccept
* Description    : Process CSU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_CallAccept(IN uint32 uiCallHdl,
                   		  IN x_IFX_DECT_CSU_CallParams *pxCallParams)
{ 
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

  /*Pointer Sanity Check*/
  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Invalid Handles");
    return IFX_FAILURE;
  }
   
  if(IFX_DECT_CS_IDLE == pxCCInfo->eState || 
      IFX_DECT_CALL_DIR_OUT != pxCCInfo->bCallDir){
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Invalid Call State");
     return IFX_FAILURE;
  }
  
  pxCCInfo->isInternal = pxCallParams->isInternal;
  pxCCInfo->bIsPresentation = pxCallParams->bIsPresentation;
  if((pxCallParams->isInternal) && ((pxCallParams->ucPeerHandsetId > 0)&& (pxCallParams->ucPeerHandsetId < 7))){
    pxCCInfo->ucPeerHandsetId = pxCallParams->ucPeerHandsetId;
  }

  if((pxCallParams->ucLineId>0)&&(pxCallParams->ucLineId < 0x7F))
     pxCCInfo->ucLineId = pxCallParams->ucLineId;

  if((IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId))&&
		 (pxCCInfo->eState != IFX_DECT_CS_ALERT)){ 
    x_IFX_DECT_IPC_Msg xIpcMsg = {0};
    uint32 uiIEHdl;
   IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
               "Call Accepted ","Sending call status");
      IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,
                            pxCCInfo->ucInstanceId,
                            (pxCallParams->uiSignal== IFX_DECT_SIGNAL_RingBackTone)?IFX_DECT_SIGNAL_RingBackTone:0xFF,&xIpcMsg);
                            //0xFF,&xIpcMsg);

    uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);

    IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_ALERT,0xFF,
			                                0xFF,pxCCInfo->ucLineId==0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  }
  pxCCInfo->eState = IFX_DECT_CS_ALERT;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Returning Success");
  return IFX_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_DECT_CSU_CallAnswer
* Description    : Process CSU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_CallAnswer(IN uint32 uiCallHdl,
                   		  IN x_IFX_DECT_CSU_CallParams *pxCallParams)
{
  uint32 uiIEHdl;
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Entry");

  /*Pointer Sanity Check*/
  if(!pxCallParams || IFX_FAILURE == 
     			IFX_DECT_CSU_ValidateCCInfo(pxCCInfo)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Invalid Handles");
    return IFX_FAILURE;
  }
  
	/*  Check Invalid State */ 
  if(((pxCCInfo->eState != IFX_DECT_CS_ALERT  ) ||
     (pxCCInfo->eState != IFX_DECT_CS_SETUP  )) &&
       (IFX_DECT_CALL_DIR_OUT  != pxCCInfo->bCallDir)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Invalid Call State");
    
    return IFX_FAILURE;
  }  
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
         "Calling Answered for handset: ",pxCCInfo->ucHandsetId);

  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
         "Line ID received from Application: ",pxCallParams->ucLineId);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
         "PT/FT managed flag: ",pxCCInfo->uiFlag);
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
         "Is an Internal call: ",pxCallParams->isInternal);

  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
         "Peer Handset Id is: ",pxCallParams->ucPeerHandsetId);
   pxCCInfo->isInternal = pxCallParams->isInternal;
   pxCCInfo->bIsPresentation = pxCallParams->bIsPresentation;
  if((pxCallParams->isInternal) && ((pxCallParams->ucPeerHandsetId > 0)&& (pxCallParams->ucPeerHandsetId < 7))){
    pxCCInfo->ucPeerHandsetId = pxCallParams->ucPeerHandsetId;
  }
  if((pxCallParams->ucLineId>0)&&(pxCallParams->ucLineId < 0x7F))
     pxCCInfo->ucLineId = pxCallParams->ucLineId;

  if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId))
  {
		//if(pxCCInfo->uiFlag & IFX_DECT_CSU_PENDING_SIGNAL)
    {
      //pxCCInfo->uiFlag &= ~IFX_DECT_CSU_PENDING_SIGNAL;

    /*IFX_DECT_SIGNAL_TonesOff or 0xFF*/
    IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
                          (pxCallParams->uiSignal== IFX_DECT_SIGNAL_TonesOff)?IFX_DECT_SIGNAL_TonesOff:0xFF,&xIpcMsg);
                          //0xFF,&xIpcMsg);
                          uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);

    IFX_DECT_CSU_EncodeCallInformation(
                     pxCCInfo->ucCallId,IFX_DECT_CS_CONNECT,
                     0xFF, 0xFF,
					 pxCCInfo->ucLineId==0x7F?0xFF:pxCCInfo->ucLineId,
					uiIEHdl);
		printf("Call Id in Connect %d\n",pxCCInfo->ucCallId);
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
          "Sending LineId information to PP in CC-INFO msg.");

    /* Post to the Stack */
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      

    }
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "Move to CONVERSATION state");
  pxCCInfo->eState = IFX_DECT_CS_CONNECT;
  			IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
              "uiSlotType =",uiSlotType);
  			IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
              "Codec =",pxCCInfo->aunCodec[0]);

	if(pxCCInfo->uiFlag & IFX_DECT_CSU_PENDING_ENVOICE){
  			IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "IFX_DECT_CSU_PENDING_ENVOICE  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		if(((uiSlotType & (1 << pxCCInfo->ucHandsetId)) && (pxCCInfo->aunCodec[0] == IFX_DECTNG_CODEC_G722_64)) ||
				(!(uiSlotType & (1 << pxCCInfo->ucHandsetId)) && (pxCCInfo->aunCodec[0] != IFX_DECTNG_CODEC_G722_64)))
		{

			pxCCInfo->uiFlag &= ~IFX_DECT_CSU_PENDING_ENVOICE;
    		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Received enable voice before connect but sending now after connect");
    	memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
    	IFX_DECT_EncodeEnableVoice(pxCCInfo->ucHandsetId,
                                 pxCCInfo->ucInstanceId,
                                 pxCCInfo->unHwVoiceChannel,
                     			&xIpcMsg);
      		IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
		}
		else
		{
  			IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "SlotModification required!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		} 
	}
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Returning Success");
  return IFX_SUCCESS;

}



/************************************************************************
* Function Name  : IFX_DECT_CSU_CallDisconnect
* Description    : Process CSU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_CallDisconnect(IN uint32 uiCallHdl,
                   		 IN e_IFX_DECT_IE_CallReason eReason)
{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
  uint32 uiIEHdl;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  
  if(!IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)||(pxCCInfo->eState == IFX_DECT_CS_CONF_CONNECT)||
		 (pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_INITIATED)||(pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_TARGET))
		return IFX_SUCCESS; 
  /*Pointer Sanity Check*/
  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo) ||
     IFX_DECT_CS_IDLE == pxCCInfo->eState){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Invalid Handles");
    return IFX_FAILURE;
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"HandsetId is: ",
                 pxCCInfo->ucHandsetId);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"CallId is: ",
                 pxCCInfo->ucCallId);
	memset(&xIpcMsg,0,sizeof(xIpcMsg));
	uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);      
	IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
					 	                0xFF,&xIpcMsg);
	IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_DISCONNECT,eReason,
         											0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
	pxCCInfo->uiFlag |= IFX_DECT_CSU_DISCONNECT_SENT;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "Send CC-INFO");
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
	return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_CSU_CallRelease
* Description    : Process CSU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_CallRelease(IN uint32 uiCallHdl,
                         IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                   		 IN e_IFX_DECT_RelType eRelType)
{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
  x_IFX_DECT_CC_Info *pxTmpCCInfo =NULL;
  uint32 uiIEHdl;
//	uint32 uiReason=IFX_DECT_CS_INUSE;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  
  /*Pointer Sanity Check*/
  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo) ||
     IFX_DECT_CS_IDLE == pxCCInfo->eState){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
             "Invalid Handles");
    return IFX_FAILURE;
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"HandsetId is: ",
                 pxCCInfo->ucHandsetId);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"CallId is: ",
                 pxCCInfo->ucCallId);

  if((IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)) && (eRelType != IFX_DECT_RELEASE_ENCR_ACT_FAIL)) 
  {
    if(((pxCCInfo->eState != IFX_DECT_CS_CONF_CONNECT)||(pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_INITIATED))&&
			!(pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_TARGET)){
#if 0
/*To pass TC_FT_NG1.N.7_BV_202: if "IFX_DECT_CS_DISCONNECT" sent then it fails*/
    /* IFX_DECT_SIGNAL_OffHookWarn_Tone or IFX_DECT_SIGNAL_BusyTone or 0xFF */
			if(!(pxCCInfo->uiFlag&IFX_DECT_CSU_DISCONNECT_SENT)){   

				memset(&xIpcMsg,0,sizeof(xIpcMsg));
				if((pxCallParams!=NULL) && (pxCallParams->uiFlag!=0)){
					uiReason=pxCallParams->uiFlag;
				}
		  	uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);      
	    	IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
					 	                0xFF,&xIpcMsg);
				IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_DISCONNECT,//ASK:hw to sync reason with tone???
         ((pxCCInfo->eState < IFX_DECT_CS_CONNECT)&&(eRelType!=IFX_DECT_RELEASE_NORMAL))?uiReason:0xFF,
         0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "Send CC-INFO");
        IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
			}
#endif
				memset(&xIpcMsg,0,sizeof(xIpcMsg));
       IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,
                pxCCInfo->ucInstanceId,
						    IFX_DECT_SIGNAL_TonesOff,&xIpcMsg);
      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);      
      IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_IDLE,0xFF,
                                     0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
              "Send CC-INFO");
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
    }else{
       /* If in conference and remote released the call, update the call state as CS_CONNECT and do not free the callid */  
	    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
							"Send CC-INFO with state updated to connect and CLIP and CNIP");

      if((uint32)&avxCCInfo[pxCCInfo->ucHandsetId-1][0] == (uint32)pxCCInfo)
      {
         pxTmpCCInfo = &avxCCInfo[pxCCInfo->ucHandsetId-1][1];
      }
      else
      {
         pxTmpCCInfo = &avxCCInfo[pxCCInfo->ucHandsetId-1][0];
      }

       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT," The Other HandsetId is: ",
                 pxTmpCCInfo->ucHandsetId);
	        IFX_DECT_EncodeCCInfo(pxTmpCCInfo->ucHandsetId,
					                	    pxTmpCCInfo->ucInstanceId,
						                    0XFF,&xIpcMsg);
	        uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);			
	        IFX_DECT_CSU_EncodeCallInformation(pxTmpCCInfo->ucCallId,IFX_DECT_CS_CONNECT,0xFF,
	  		                             0xFF,pxTmpCCInfo->ucLineId== 0x7F?0xFF:pxTmpCCInfo->ucLineId,uiIEHdl);

	        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
							"Sent CC-INFO and changed to CONNECT STate from CONF_CONNECT State");
	        IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
					memset(&xIpcMsg,0,sizeof(xIpcMsg));
	        IFX_DECT_EncodeCCInfo(pxTmpCCInfo->ucHandsetId,
					                	    pxTmpCCInfo->ucInstanceId,
						                    0XFF,&xIpcMsg);
	        uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);			
          /* Encode CLIP */
          if(strlen(pxTmpCCInfo->acCLIP) >0) {
	          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					           pxTmpCCInfo->acCLIP );
	          IFX_DECT_CSU_EncodeCLIP(pxTmpCCInfo->acCLIP,strlen(pxTmpCCInfo->acCLIP),
                  pxTmpCCInfo->bIsPresentation,uiIEHdl,pxTmpCCInfo->isInternal);
          }
          /* Encode CNIP */
             if(strlen(pxTmpCCInfo->acCNIP) >0) {
	              IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			             pxTmpCCInfo->acCNIP );
	              IFX_DECT_CSU_EncodeCNIP(pxTmpCCInfo->acCNIP,strlen(pxTmpCCInfo->acCNIP),
                  pxTmpCCInfo->bIsPresentation,uiIEHdl,pxCCInfo->ucHandsetId);
              }
	        IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
          pxTmpCCInfo->eState = IFX_DECT_CS_CONNECT;
					paxActCallHdl[pxTmpCCInfo->ucHandsetId-1]=pxTmpCCInfo;
					if((pxCCInfo->uiFlag&IFX_DECT_CSU_INTRUDE_TARGET)){
						pxCCInfo->uiFlag &= ~(IFX_DECT_CSU_INTRUDE_TARGET|IFX_DECT_CSU_INTRUDE_INITIATED);
						return IFX_SUCCESS;
					}
    }
  }

  if(IFX_FAILURE == IFX_DECT_MU_CanCallBeReleased(pxCCInfo->ucHandsetId)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Another Transaction on-going on this handset");
			if((pxCCInfo->uiFlag&IFX_DECT_CSU_INTERCEPT_REQUESTED)){
			IFX_DECT_CSU_ClearInterceptInit(pxCCInfo);
			}

      IFX_DECT_CSU_FreeCCInfo(pxCCInfo);
	  return IFX_SUCCESS;
  }
  else{
    /* Reject */ 
    if(IFX_DECT_CS_SETUP == pxCCInfo->eState ||  
      IFX_DECT_CS_ALERT == pxCCInfo->eState){
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Reject");
			if((pxCCInfo->uiFlag&IFX_DECT_CSU_INTERCEPT_REQUESTED)){
			IFX_DECT_CSU_ClearInterceptInit(pxCCInfo);
			}
      IFX_DECT_EncodeRelease(pxCCInfo->ucHandsetId,
                            pxCCInfo->ucInstanceId,
                            eRelType,&xIpcMsg);
    
    }else{
			/* Release */
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Release");
			if((pxCCInfo->uiFlag&IFX_DECT_CSU_INTERCEPT_REQUESTED)){
			IFX_DECT_CSU_ClearInterceptInit(pxCCInfo);
			}
      IFX_DECT_EncodeRelease(pxCCInfo->ucHandsetId,
							 pxCCInfo->ucInstanceId,
                             eRelType,&xIpcMsg);
    
    }
    
    if(vxLauCallBks.pfnLinkRelease != NULL){
        vxLauCallBks.pfnLinkRelease(pxCCInfo->ucHandsetId);
    }

    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
   
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
           "*** Stop Voice ");
    /* There is only one HwVoice Channel for any handset. */
    if(pxCCInfo->unHwVoiceChannel != 0xFF){
      IFX_DECT_CSU_VoiceModify(
	               (uint32)pxCCInfo,
				    NULL,//&xCallParams,
	               IFX_DECT_STOP_VOICE,
				   pxCCInfo->unHwVoiceChannel);
    }
    if(vxGlobalInfo.xMU.vxMUInfo[(pxCCInfo->ucHandsetId)-1].ucCSURefCount > 0){
      IFX_DECT_CSU_FreeAllCCInfoOfThisHS(pxCCInfo->ucHandsetId);
	  }else{
      IFX_DECT_CSU_FreeCCInfo(pxCCInfo);
	  }
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Success");
  return IFX_SUCCESS;                        
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_InfoReceived
* Description    : Process CSU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          : In pxCallParams uiSignal must be filled in without fail
									without that it will be sending DialTone always.Fill 0xFF if no signal to be used
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_InfoReceived(IN uint32 uiCallHdl,
                   				IN x_IFX_DECT_CSU_CallParams *pxCallParams)
{
  uint32 uiIEHdl;
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo)
   	  || !pxCallParams){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid Handles");
    return IFX_FAILURE;                        
  }
  if(IFX_DECT_CS_DISCONNECT == pxCCInfo->eState || 
     IFX_DECT_CS_IDLE ==pxCCInfo->eState){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid State");
    return IFX_FAILURE;                        
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"HandsetId is: ",
                 pxCCInfo->ucHandsetId);

  pxCCInfo->uiSignal= pxCallParams->uiSignal;

	if((pxCallParams->uiSignal != 0xFF) && (pxCCInfo->eState < IFX_DECT_CS_PROC))
	{
		pxCCInfo->uiFlag |= IFX_DECT_CSU_PENDING_SIGNAL;
  	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"HandsetId is SIGNAL flg set: ",
                 pxCCInfo->ucHandsetId);
	}

  IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,
                        pxCCInfo->ucInstanceId,
                        pxCallParams->uiSignal,
						&xIpcMsg);
  uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);
  /* Encode CLIP */
  if(strlen(pxCallParams->acCLIP) >0) {
	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 pxCallParams->acCLIP );
  strcpy(pxCCInfo->acCLIP , pxCallParams->acCLIP);
	IFX_DECT_CSU_EncodeCLIP(pxCallParams->acCLIP,strlen(pxCallParams->acCLIP),
	 pxCallParams->bIsPresentation,uiIEHdl,pxCCInfo->isInternal);
  }


  /* Encode CNIP */
  if (IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){
  	if(strlen(pxCallParams->acCNIP) > 0) {
     	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 	pxCallParams->acCNIP );
     	strcpy(pxCCInfo->acCNIP , pxCallParams->acCNIP);
     	IFX_DECT_CSU_EncodeCNIP(pxCallParams->acCNIP,strlen(pxCallParams->acCNIP),
     			pxCallParams->bIsPresentation,uiIEHdl,pxCCInfo->ucHandsetId);
 	 	}

    IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,0xFF,0xFF,0xFF,
	                                 pxCCInfo->ucLineId==0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl); 
  }

  /*Add User defined IE*/                                                  
    if(pxCallParams->uiIEHandler != 0){ 
		 IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IFX_DECT_CSU_InfoReeceived :Adding User defined IE");
		 if(IFX_DECT_IE_IEAppend(uiIEHdl,pxCallParams->uiIEHandler) == 0){
		 	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Adding User defined IE failed!"); 
		 	}
    	}
		 

  

  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		         "Send CC-INFO");
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Returning Success");
  return IFX_SUCCESS;                        
                          
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_ServiceChange
* Description    : Process CSU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_ServiceChange(IN uint32 uiCallHdl,
                           IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                           IN e_IFX_DECT_CSU_CodecChangeType eType)
{
  uint32 uiIEHdl;
  x_IFX_DECT_IPC_Msg xIPCMsg = {0};
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*) uiCallHdl;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Entry Callhandle",uiCallHdl);
  
  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo)
    		 || !pxCallParams){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Invalid Handles");
    return IFX_FAILURE;                        
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"HandsetId is: ",
                 pxCCInfo->ucHandsetId);

  if(((IFX_DECT_MU_GetRunCodec(pxCCInfo->ucHandsetId) == IFX_DECTNG_CODEC_G722_64)&&(pxCallParams->bwideband))||
	  ((IFX_DECT_MU_GetRunCodec(pxCCInfo->ucHandsetId) == IFX_DECTNG_CODEC_G726_32)&&(!pxCallParams->bwideband))){
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		       "Cannot Do a service change since the running codec is same as the requested one");
	    vxCSUCallBks.pfnServiceChange(
                (uint32)pxCCInfo,
				pxCallParams, 
				IFX_DECT_CSU_SC_ACCEPT,
				pxCCInfo->uiPrivateData);        
	  return IFX_SUCCESS;
  }
				 
  switch(eType){	
  	case IFX_DECT_CSU_SC_REQUEST:
       /* Even though pxCCInfo->bwideband and pxCallParams->bwideband are
          equal the FT application is sending the request */
		  //if(pxCCInfo->bwideband != pxCallParams->bwideband)
      {
    	   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        		       "Initiating Service Change");
  	     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Codec Type: ",
                 pxCallParams->bwideband);
				/* Service change Request */
    		pxCCInfo->bwideband = pxCallParams->bwideband;
			
      	IFX_DECT_EncodeServiceChangeRq(pxCCInfo->ucInstanceId,
		    							   pxCCInfo->ucHandsetId,
										   pxCCInfo->bwideband,
										   &xIPCMsg);
        IFX_DECT_MU_SetRunCodec(pxCCInfo->ucHandsetId,pxCCInfo->bwideband?IFX_DECTNG_CODEC_G722_64:IFX_DECTNG_CODEC_G726_32);
   			pxCCInfo->eState = IFX_DECT_CC_MEDIA_NEG; 
    	}
    	break;

		case IFX_DECT_CSU_SC_ACCEPT:
			if(IFX_DECT_CC_MEDIA_NEG != pxCCInfo->eState){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         				"SC Accept Rsp Invalid");
         return IFX_FAILURE;                        
       }
		  IFX_DECT_EncodeServiceChangeAccept(pxCCInfo->ucHandsetId,
	                                         pxCCInfo->ucInstanceId,
                                             &xIPCMsg);
			break;

		case IFX_DECT_CSU_SC_REJECT:
			if(IFX_DECT_CC_MEDIA_NEG != pxCCInfo->eState){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
         				"SC Reject Rsp Invalid");
         return IFX_FAILURE;                        
        }
		  IFX_DECT_EncodeServiceChangeReject(pxCCInfo->ucHandsetId,
	                                         pxCCInfo->ucInstanceId,
                                             &xIPCMsg);
			break;

 		default:
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Invalid Request");
     return IFX_FAILURE;                        
  }

  
  if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)) 
  {
    uiIEHdl = IFX_DECT_IE_NewIECreate(xIPCMsg.acData);
    IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,0xFF,0xFF,0xFF,
		                               pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl); 
  }
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Returning Success");
  return IFX_SUCCESS;
                          
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_ModifyVoice
* Description    : Process CSU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_VoiceModify(IN uint32 uiCallHdl,
	                       IN x_IFX_DECT_CSU_CallParams *pxCallParams,
												 IN e_IFX_DECT_CSU_VoiceEventType eType,
												 IN uint16 unHwVoiceChannel)
{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*) uiCallHdl;
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                "The Voice Channel is ",unHwVoiceChannel);

  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
	            "Invalid Handles");
    return IFX_FAILURE;                        
  }
  pxCCInfo->unHwVoiceChannel = unHwVoiceChannel; 
  if(pxCCInfo->eState < IFX_DECT_CS_SETUP)
  {
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
	            "Invalid state");
    return IFX_FAILURE;                        
  }
	if(pxCCInfo->eState < IFX_DECT_CS_PROC && eType==IFX_DECT_START_VOICE)
  {
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Received enable voice before connect but taken care to send after connect");
    pxCCInfo->uiFlag |= IFX_DECT_CSU_PENDING_ENVOICE;                        
    return IFX_SUCCESS;
  }
  switch(eType){	
  	case IFX_DECT_START_VOICE:
  		IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		               "Enable Voice");
			IFX_DECT_EncodeEnableVoice(pxCCInfo->ucHandsetId,
			                           pxCCInfo->ucInstanceId,
			                           unHwVoiceChannel,
									   &xIpcMsg);
			break;
  	case IFX_DECT_STOP_VOICE:
  		  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		               "Disable Voice");
      if(pxCCInfo->unHwVoiceChannel != 0xFF){
		    IFX_DECT_EncodeDisableVoice(pxCCInfo->ucHandsetId,
		                              pxCCInfo->ucInstanceId,
                                      unHwVoiceChannel,
		                              &xIpcMsg);
        pxCCInfo->unHwVoiceChannel = 0xFF;
      }
			break;
 		default:
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Invalid Request");
     return IFX_FAILURE;                        
	}
 	IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
  return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECT_CSU_CipherChangeRequest
* Description    : Process CSU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_CipherChangeRequest(IN uint32 uiCallHdl)
{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
#if 0
  uint32 uiIEHdl =0;
#endif
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	            "Invalid Handles");
    return IFX_FAILURE;                        
  }
  if(IFX_DECT_CS_DISCONNECT == pxCCInfo->eState || 
     IFX_DECT_CS_IDLE ==pxCCInfo->eState){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid State");
    return IFX_FAILURE;                        
  }
  if(IFX_DECT_MU_GetCipherStatus(pxCCInfo->ucHandsetId) == IFX_DECT_ENCRYPTION_MODE){
     x_IFX_DECT_IPC_Msg xIpcMsg={0};
     xIpcMsg.ucPara1= pxCCInfo->ucHandsetId;
     xIpcMsg.ucInstance = pxCCInfo->ucInstanceId;
     xIpcMsg.ucPara2 = IFX_DECT_ENCRYPTION_MODE;
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Link is already ciphered/non ciphered");
     IFX_DECT_CC_HandleCiphering(&xIpcMsg);
     return IFX_SUCCESS;
  }
  
  IFX_DECT_MU_SetCipherStatus(pxCCInfo->ucHandsetId,((IFX_DECT_ENCRYPTION_MODE ==1)?IFX_TRUE:IFX_FALSE)); 
#if 0  
  if(IFX_TRUE != IFX_DECT_ENCRYPTION_MODE){
    /* D&A Hack , the case was like ciphering process was delayed and the handset tries to perform a parallel call, since ciphering status was 0
      The toolkit tries to authenticate the handset again, which results in failure at the stack level itself since the MM layer shall be in cipher_ON
      and at this state PT_ATUH_REQ is not expected*/
    IFX_DECT_EncodeEnableCipher(pxCCInfo->ucHandsetId,
                              pxCCInfo->ucInstanceId, 
	                            ((IFX_TRUE == pxCallParams->bCipheringStatus)?1:0),
                              &xIpcMsg);
  }else{
      if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){
        uint32 uiModuleOwner = IFX_DECT_MU_GetModuleOwner(pxCCInfo->ucHandsetId);
        if((IFX_DECT_CS_SETUP == pxCCInfo->eState)&&((uiModuleOwner & IFX_DECT_LAU_ID) == 0)){
          uint32 uiIEHdl =0;
          IFX_DECT_EncodeSetupAck(pxCCInfo->ucHandsetId,
                              pxCCInfo->ucInstanceId, 
                              &xIpcMsg);
          uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
          IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,0xFF,0xFF,
		                          0xFF,pxCCInfo->ucLineId==0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
          IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      }
    }

#endif
    IFX_DECT_EncodeAuthPTReq(pxCCInfo->ucHandsetId,
                           pxCCInfo->ucInstanceId, &xIpcMsg);
//  }
  pxCCInfo->uiFlag |= IFX_DECT_CSU_CIPHER_INITIATED;
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Exit");
  return IFX_SUCCESS;
}



/*! \brief  This function is used acknowledge a resume request to PT. The FT 
                    application will call this function when it wants to acknowledge a 
                    resume request and inform the result. Typically. for a VoIP, a
                    Re-invite from network shall lead to invocation of this function.
   \param[in] uiCallHdl Call Handle of the call 
   \param[in] pxCallParams Reference to Call parameters
   \param[in] eStatus SUCCESS/FAILURE of the request 
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, all fields in the CallParams are mandatory except for uiIEHandler and bHookFlash.
*/
 e_IFX_Return 
 IFX_DECT_CSU_CallResumeAck(IN uint32 uiCallHdl,
                            IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                            IN e_IFX_Return eStatus)
{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Entry Callhandle",uiCallHdl);
 

  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
	             "Invalid Handles");
    return IFX_FAILURE;                        
  }				


  /*Send the negative acknowledgement 
	 ucSignal = 09H */ 
  if(eStatus == IFX_FAILURE) {
   
    if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){
    IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
							 pxCCInfo->ucInstanceId,
							 pxCCInfo->ucCallId,
							 pxCCInfo->ucLineId,pxCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
							 IFX_DECT_CSU_SIGNAL_NACK);  
		}
  }
  else {
    uint32 uiIEHdl;
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      		     "Call Resume Success.");
      
    pxCCInfo->eState = IFX_DECT_CS_CONNECT;
    paxActCallHdl[pxCCInfo->ucHandsetId - 1] = pxCCInfo; /*  Store as active Index*/ 
      
    if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){
	    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Send CC-INFO for Call ID and Connect Status To PP");
      IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,
                            pxCCInfo->ucInstanceId,
                            0XFF,&xIpcMsg);

      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
      
	    IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_CONNECT,0xFF,
		                                 0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
      
	    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
		}
  }
  return IFX_SUCCESS;
}

// JONATHAN_150311.
/*! \brief  This function is used to send remote information(Remote Hold & Remote Connect) to PT.
                    The FT application will call this function when it receives remote party status
                    information form remote party.
   \param[in] uiCallHdl Call Handle of the call
   \param[in] pxCallParams Reference to Call parameters
   \param[in] Remote Party Status = CS_REMOTE_HOLD or CS_REMOTE_CONNECT
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, all fields in the CallParams are mandatory except for uiIEHandler and bHookFlash.
*/
 e_IFX_Return
 IFX_DECT_CSU_CallRemoteInfo(IN uint32 uiCallHdl,
                            IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                            IN e_IFX_Return eStatus)
{
   x_IFX_DECT_IPC_Msg xIpcMsg = {0};
   x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
   uint32 uiIEHdl;

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Entry Callhandle",uiCallHdl);

   if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo)){
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, "Invalid Handles");
      return IFX_FAILURE;
   }

   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Call Remote Party Information.");

   if (IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)) {
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Send CC-INFO for Call ID and Remote Party Status To PP");
      IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId, pxCCInfo->ucInstanceId, 0xFF,&xIpcMsg);

      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);
      IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId, eStatus, 0xFF, 0xFF,
                                         pxCCInfo->ucLineId == 0x7F?0xFF:pxCCInfo->ucLineId, uiIEHdl);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
   }
   return IFX_SUCCESS;
}


/*! \brief  This function is used acknowledge a hold request to PT. The FT
                    application will call this function when it wants to acknowledge a
                    hold request and inform the result. Typically. for a VoIP, a
                    re-invite from network shall lead to invocation of this function.
   \param[in] uiCallHdl Call Handle of the call 
   \param[in] pxCallParams Reference to Call parameters
   \param[in] eStatus SUCCESS/FAILURE of the request 
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, all fields in the CallParams are mandatory except for uiIEHandler and bHookFlash.
*/
e_IFX_Return 
IFX_DECT_CSU_CallHoldAck(IN uint32 uiCallHdl,
                         IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                         IN e_IFX_Return eStatus)
{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_CSU_CallParams xCallParams = {0};
  e_IFX_DECT_ErrReason ucRejectReason;
  e_IFX_Return eRet = IFX_FAILURE;
  uint32 uiIEHdl=0;
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
  x_IFX_DECT_CC_Info *pxParaCCInfo = NULL;
  
  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
	              "Invalid Handles");
    return IFX_FAILURE;                        
  }		
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Entry");
  IFX_DECT_CSU_GetCallHandleBasedOnState(pxCCInfo->ucHandsetId,&pxParaCCInfo,IFX_DECT_CS_SETUP);
  /* Send the negative acknowledgement 
	 ucSignal = 09H */ 
 /*pxParaCCInfo == NULL is removed to fix issue when call hold is initiated by HS without any digits with MKP this 
  pointer will be NULL and so always it fails*/
  if((eStatus == IFX_FAILURE) /*|| (pxParaCCInfo == NULL)*/) {
	  if((pxCCInfo->uiFlag & IFX_DECT_CSU_PENING_PCALL)||
		  (pxCCInfo->uiFlag & IFX_DECT_CSU_PENING_CWA)){		  
     	pxCCInfo->uiFlag &= ~IFX_DECT_CSU_PENING_CWA;
     	pxCCInfo->uiFlag &= ~IFX_DECT_CSU_PENING_PCALL;
		if(pxParaCCInfo != NULL){
			pxParaCCInfo->ucCallId = 0xFF?IFX_DECT_MU_GetCallID(&pxParaCCInfo->ucCallId):0xFF;
		 	IFX_DECT_CSU_FreeCCInfo(pxParaCCInfo);
			}
	  }
    pxCCInfo->eState =IFX_DECT_CS_CONNECT;
    IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
							 pxCCInfo->ucInstanceId,
							 pxCCInfo->ucCallId,
							 pxCCInfo->ucLineId,pxCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
							 IFX_DECT_CSU_SIGNAL_NACK); 

     return IFX_SUCCESS;
  }

#if 0
   xCallParams.isInternal=pxParaCCInfo->isInternal;
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Before any check Call type INT= ",
              pxParaCCInfo->isInternal);
#endif


  if(pxParaCCInfo != NULL)
  {
    xCallParams.isInternal=pxParaCCInfo->isInternal;
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Before any check Call type INT= ",
              pxParaCCInfo->isInternal);
  }
  if(pxCCInfo->uiFlag & IFX_DECT_CSU_PENING_PCALL)
  {
     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      		     "FP Initiated Hold for Parallel Call");
     pxCCInfo->uiFlag &= ~IFX_DECT_CSU_PENING_PCALL;
/* Construct the CALL-INFORMATION IE and 
	      Send the CallId CC-INFO message */  
     pxCCInfo->eState = IFX_DECT_CS_HOLD;
     IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,
	                          pxCCInfo->ucInstanceId,
                              0XFF,&xIpcMsg);

     uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
     IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,pxCCInfo->eState,0xFF,
			                               0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);  
     IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "Send the Call Hold to PP");
		printf("Call Id  %d\n",pxCCInfo->ucCallId);
     IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);

     /* Set the Module Owner */  
     IFX_DECT_MU_SetModuleOwner(pxParaCCInfo->ucHandsetId,
	         		IFX_DECT_MU_ADD_OWNER,IFX_DECT_CSU_ID);
        
	   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"HandsetId is: ",
                 pxParaCCInfo->ucHandsetId);
	   strcpy(xCallParams.acRecvDigits, pxParaCCInfo->acDigits);

     pxParaCCInfo->ucBasicService = IFX_DECT_MU_GetBasicService(pxParaCCInfo->ucHandsetId);
     pxParaCCInfo->aunCodec[0] = IFX_DECT_MU_GetCodec(pxParaCCInfo->ucHandsetId);
    if(((pxParaCCInfo->ucBasicService&WIDEBAND_SPEEACH_BSERVICE) == WIDEBAND_SPEEACH_BSERVICE)
       ||(pxParaCCInfo->aunCodec[0] == IFX_DECTNG_CODEC_G722_64)){
        pxParaCCInfo->bwideband = IFX_TRUE; 
    }

    /* Invoke the callback after filling the callparams*/
    xCallParams.bwideband = pxParaCCInfo->bwideband;
    xCallParams.eCallType = pxParaCCInfo->ucBasicService;
 
    pxParaCCInfo->eState = IFX_DECT_CS_SETUP; /* move to INIT state */
     pxParaCCInfo->bCallDir  = IFX_DECT_CALL_DIR_OUT; /* Outgoing Call */ 
		 // already got the callid in handle parallel call

	 paxActCallHdl[pxCCInfo->ucHandsetId - 1] = pxParaCCInfo; /*  Store as active Index*/ 
	   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
		  	     		"CallID : ", pxParaCCInfo->ucCallId );
      xCallParams.ucLineId = pxParaCCInfo->ucLineId;	
    /* Note: Added Check for recv digits. Case: Make internal call, without holding make another call and choose a line also */  
		if((xCallParams.ucLineId!=0xFF)&&(xCallParams.ucLineId!=0x7F)&&(vxCSUCallBks.pfnLineInfo!=NULL)){
			pxParaCCInfo->uiFlag |= IFX_DECT_CSU_PENDING_PCALL;
			vxCSUCallBks.pfnLineInfo(pxParaCCInfo->ucHandsetId,&xCallParams);
			return IFX_SUCCESS;
		}else{
	   eRet = vxCSUCallBks.pfnCallInitiate((uint32)pxParaCCInfo,
	                                       pxParaCCInfo->ucHandsetId, 
		                                   &xCallParams,
										   &ucRejectReason,
										   &pxParaCCInfo->uiPrivateData);
			if(eRet==IFX_FAILURE){
				IFX_DECT_CSU_ParallelCallFailed((uint32)pxParaCCInfo,0xFF);
			}
#if 0
else if(eRet==IFX_PENDING){
			/*Nothing to do Agent has to take decision and call appropriate API*/
			pxParaCCInfo->uiFlag |= IFX_DECT_CSU_PENDING_PCALL;
		}
#endif
		else if(eRet==IFX_SUCCESS){
			IFX_DECT_CSU_ParallelCallSuccess((uint32)pxParaCCInfo);
		}
	} 
 }
  else if(pxCCInfo->uiFlag & IFX_DECT_CSU_PENING_CWA){
    pxParaCCInfo = paxActCallHdl[pxCCInfo->ucHandsetId - 1];
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      		     "Hold success ..... answer for Call Waiting");
    pxCCInfo->uiFlag &= ~IFX_DECT_CSU_PENING_CWA;
    pxCCInfo->eState = IFX_DECT_CS_HOLD;
		uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Sending Call hold for the first call.");
		IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_HOLD,0xFF,
			                               0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);

   		IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
              		0XFF,&xIpcMsg);

    /* Post to the Stack */
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
	/* Send Call accept for the call waiting */
#if 0

    xCallParams.bwideband = pxParaCCInfo->bwideband;
    xCallParams.uiIEHandler =0;
    vxCSUCallBks.pfnCallAnswer(
                (uint32)pxParaCCInfo,
                &xCallParams,
		        pxParaCCInfo->uiPrivateData); 
#endif
		memset(&xIpcMsg,0,sizeof(xIpcMsg));
		if(pxParaCCInfo != NULL){
		  /* Send the CallID aswell for completness*/
      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);

      IFX_DECT_CSU_EncodeCallInformation(pxParaCCInfo->ucCallId,IFX_DECT_CS_CONNECT,0xFF,
			                               0xFF,pxParaCCInfo->ucLineId== 0x7F?0xFF:pxParaCCInfo->ucLineId,uiIEHdl);
    	pxParaCCInfo->eState = IFX_DECT_CS_CONNECT;

      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Sending Call Connect for the first call.");

      /* Send CC-INFO message */
      IFX_DECT_EncodeCCInfo(pxParaCCInfo->ucHandsetId,pxParaCCInfo->ucInstanceId,
                              0XFF,&xIpcMsg);

      /* Post to the Stack */
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);	
		}
  }
  else 
  {
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      		       "PP initiated Hold Successful");
    pxCCInfo->eState = IFX_DECT_CS_HOLD;
    if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){
     IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,
                            pxCCInfo->ucInstanceId,
                            0XFF,&xIpcMsg);

      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Send CC-INFO for Call ID and Hold Status To PP");
      IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,pxCCInfo->eState,0xFF,
			                               0xFF,pxCCInfo->ucLineId== 0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
		}
  }
  
  return IFX_SUCCESS;
}

/*! \brief  This function is used acknowledge a toggle request to PT. The FT 
                    application will call this function when it wants to acknowledge a 
                    call toggle request and inform the result. Typically. for a VoIP, a
                    re-invite from network shall lead to invocation of this function.
   \param[in] uiHeldCallHdl Held Call Handle of the call to be toggled
   \param[in] uiActCallHdl Active Call Handle.
   \param[in] pxCallParams Reference to Call parameters
   \param[in] eStatus SUCCESS/FAILURE of the request 
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, all fields in the CallParams are mandatory except for uiIEHandler and bHookFlash.
*/
e_IFX_Return
IFX_DECT_CSU_CallToggleAck(IN uint32 uiHeldCallHdl,
                           IN uint32 uiActiveCallHdl,
                           IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                           IN e_IFX_Return eStatus)
{
  x_IFX_DECT_CC_Info *pxHeldCCInfo = (x_IFX_DECT_CC_Info*) uiHeldCallHdl; 
  x_IFX_DECT_CC_Info *pxActiveCCInfo = (x_IFX_DECT_CC_Info*) uiActiveCallHdl;     
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  uint32 uiIEHdl;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Entry HeldCallhandle",uiHeldCallHdl);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Entry ActiveCallhandle",uiActiveCallHdl);
  if((IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxHeldCCInfo))
      || (IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxActiveCCInfo))
   	  || !pxCallParams){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid Handles");
    return IFX_FAILURE;                        
  }		
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Entry");
  
  /*  Send the negative acknowledgement 
	 ucSignal = 09H */ 
  if(eStatus == IFX_FAILURE) {
    IFX_DECT_CSU_SendAckToPP(pxHeldCCInfo->ucHandsetId,
							 pxHeldCCInfo->ucInstanceId,
							 pxHeldCCInfo->ucCallId,
							 pxHeldCCInfo->ucLineId,pxHeldCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
							 IFX_DECT_CSU_SIGNAL_NACK); 
  }
  else {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      		     "Call Toggle is successful.");
      /* Change the state of both the calls */
      pxHeldCCInfo->eState = IFX_DECT_CS_CONNECT;
	    pxActiveCCInfo->eState = IFX_DECT_CS_HOLD;
		  
			uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
	    /* Send Connect Status to the PP */
	    IFX_DECT_EncodeCCInfo(pxActiveCCInfo->ucHandsetId,
                            pxActiveCCInfo->ucInstanceId,
                            0XFF,&xIpcMsg);

      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
            
	    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Send CC-INFO for Call ID and ConnectStatus To PP");
      IFX_DECT_CSU_EncodeCallInformation(pxActiveCCInfo->ucCallId,IFX_DECT_CS_HOLD,0xFF,
		                                 0xFF,pxActiveCCInfo->ucLineId== 0x7F?0xFF:pxActiveCCInfo->ucLineId,uiIEHdl);
      paxActCallHdl[pxActiveCCInfo->ucHandsetId-1] = pxHeldCCInfo;
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  
	   memset(&xIpcMsg,0,sizeof(xIpcMsg));
	  /* Send Hold status to the PP */
      IFX_DECT_EncodeCCInfo(pxHeldCCInfo->ucHandsetId,
                            pxHeldCCInfo->ucInstanceId,
                            0XFF,&xIpcMsg);

      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
          
	  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Send CC-INFO for Call ID and Hold Status To PP");
      IFX_DECT_CSU_EncodeCallInformation(pxHeldCCInfo->ucCallId,IFX_DECT_CS_CONNECT,0xFF,
		                                 0xFF,pxHeldCCInfo->ucLineId== 0x7F?0xFF:pxHeldCCInfo->ucLineId,uiIEHdl);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      
}
  return IFX_SUCCESS;
}


 /*! \brief  This function is used acknowledge a transfer request to PT. The FT 
                    application will call this function when it wants to acknowledge a 
                    transfer request and inform the result. Typically. for a VoIP, a
                    NOTIFY from network shall lead to invocation of this function. 
 
   \param[in] uiHeldCallHdl Held Call Handle of the call to be transfered
   \param[in] uiActiveCallHdl Active Call Handle of the call 
   \param[in] pxCallParams Reference to Call parameters
   \param[in] eStatus SUCCESS/FAILURE of the request
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, all fields in the CallParams are mandatory except for uiIEHandler and bHookFlash.
*/
e_IFX_Return
IFX_DECT_CSU_CallTransferAck(IN uint32 uiHeldCallHdl, 
                             IN uint32 uiActiveCallHdl,
                             IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                             IN e_IFX_Return eStatus)
{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_CSU_CallParams xCallParams={0};
  uint32 uiIEHdl;
  x_IFX_DECT_CC_Info *pxHeldCCInfo = (x_IFX_DECT_CC_Info*)uiHeldCallHdl;
  x_IFX_DECT_CC_Info *pxActiveCCInfo = (x_IFX_DECT_CC_Info*)uiActiveCallHdl;
  x_IFX_DECT_CC_Info *pxTransCCInfo = NULL;
  static uchar8 ucRemoteExtn = 0;
 
  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxHeldCCInfo)
     	 ||IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxActiveCCInfo)){
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid CallHandles");
      return IFX_FAILURE;                        
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Entry");
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT," Held Call HDL",
           pxHeldCCInfo);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Peer Handset of Held Call ",
           pxHeldCCInfo->ucPeerHandsetId);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"call State Held Call ",
           pxHeldCCInfo->eState);

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Active Call HDL ",
           pxActiveCCInfo);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Peer Handset of Active Call ",
           pxActiveCCInfo->ucPeerHandsetId);
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Call State of Active Call ",
           pxActiveCCInfo->eState);

  /* Call Reinjection*/
  if(pxHeldCCInfo->ucPeerHandsetId){
    ucRemoteExtn = pxHeldCCInfo->ucPeerHandsetId;
  }else{
    if(pxCallParams)
     pxCallParams->ucLineId = pxHeldCCInfo->ucLineId;
   }

  if(eStatus == IFX_FAILURE) {
    /* Send the negative acknowledgement 
	 ucSignal = 09H */
    IFX_DECT_CSU_SendAckToPP(pxActiveCCInfo->ucHandsetId,
               pxActiveCCInfo->ucInstanceId,
               pxActiveCCInfo->ucCallId,
               pxActiveCCInfo->ucLineId,pxActiveCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
               IFX_DECT_CSU_SIGNAL_NACK); 
  }
  else
  {
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Transfer is successful");
    if(pxActiveCCInfo->ucPeerHandsetId)
    {
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
             "Send Update CallId to Transferred PP");

       /* Call Reinjection */
       if((pxCallParams) && (pxCallParams->uiFlag == IFX_DECT_CS_UNDER_TRANSFER)){

         //pxActiveCCInfo->ucPeerHandsetId = pxCallParams->ucPeerHandsetId;
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Send call status to Peer Handset ",
                  pxActiveCCInfo->ucPeerHandsetId);

         if(ucRemoteExtn && (ucRemoteExtn == pxCallParams->ucPeerHandsetId)){
           pxCallParams->ucPeerHandsetId = ucRemoteExtn;/*pxHeldCCInfo->ucPeerHandsetId*/
           ucRemoteExtn = 0;
           IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    "Its the remote extn, needn't send call status,return");
           return IFX_SUCCESS;
         }
       }

      /* find the CC Info of the Dest Handset*/ 
        IFX_DECT_CSU_GetCallHandleOfThePeer(pxActiveCCInfo->ucPeerHandsetId,
                                            &pxTransCCInfo,
                                            pxActiveCCInfo->ucCallId);
    
 
      if(pxTransCCInfo != NULL){
        IFX_DECT_EncodeCCInfo(pxTransCCInfo->ucHandsetId,
	                        pxTransCCInfo->ucInstanceId,
                            0XFF,&xIpcMsg);

        uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);       

        /* Encode CLIP */
        if(strlen(pxHeldCCInfo->acCLIP) > 0) {
	        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			             pxHeldCCInfo->acCLIP );
          IFX_DECT_CSU_EncodeCLIP(pxHeldCCInfo->acCLIP,strlen(pxHeldCCInfo->acCLIP),
					   pxHeldCCInfo->bIsPresentation,uiIEHdl,pxHeldCCInfo->isInternal);
        }
        /* Encode CNIP */
        /* Encode CNIP if the HS is CATIQ */
      if (IFX_DECT_MU_IsCAT2(pxTransCCInfo->ucHandsetId)){
        if(strlen(pxHeldCCInfo->acCNIP) > 0) {
	        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			             pxHeldCCInfo->acCNIP );
	        IFX_DECT_CSU_EncodeCNIP(pxHeldCCInfo->acCNIP,strlen(pxHeldCCInfo->acCNIP),
	                                pxHeldCCInfo->bIsPresentation,uiIEHdl,pxTransCCInfo->ucHandsetId);
        }

         }
        //if(pxCallParams && pxCallParams->uiFlag == IFX_DECT_CS_UNDER_TRANSFER){
        if (pxActiveCCInfo->eState < IFX_DECT_CS_CONNECT) {
             /* Construct the CALL-INFORMATION IE. We need to send the
                     * ActiveCallId + UpdatedCallId(CallId for the held call)
                     * and TransferredLineId(LineId of the held call if external)TODO call status should call under transfer */
          IFX_DECT_CSU_EncodeCallInformation(pxActiveCCInfo->ucCallId,IFX_DECT_CS_UNDER_TRANSFER,0xFF,pxHeldCCInfo->ucCallId,
		                                 pxHeldCCInfo->ucLineId== 0x7F?0xFF:pxHeldCCInfo->ucLineId,uiIEHdl);
 
        }else{
        /* Construct the CALL-INFORMATION IE. We need to send the  
                     * ActiveCallId + UpdatedCallId(CallId for the held call) 
                     * and TransferredLineId(LineId of the held call if external)TODO call status should call under transfer */
          IFX_DECT_CSU_EncodeCallInformation(pxActiveCCInfo->ucCallId,IFX_DECT_CS_CONNECT,0xFF,pxHeldCCInfo->ucCallId,
		                                 pxHeldCCInfo->ucLineId== 0x7F?0xFF:pxHeldCCInfo->ucLineId,uiIEHdl);
        }
          /* TODO Send Remote CLIP as well*/
        IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);

          /* Free the Active call Id and set the peer callid to Held call id*/
          IFX_DECT_MU_FreeCallID(pxActiveCCInfo->ucCallId);//TODO:
          pxTransCCInfo->ucCallId = pxHeldCCInfo->ucCallId;
          pxTransCCInfo->ucLineId = pxHeldCCInfo->ucLineId;
       } 
    }

   if(!pxCallParams || (pxCallParams && !pxCallParams->bIsAllCallsReleased)){
    if(pxHeldCCInfo->ucPeerHandsetId)
    {
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Update CLIP/CNIP for other HS");
      pxTransCCInfo = NULL;
      /* find the CC Info of the Dest Handset*/ 
      IFX_DECT_CSU_GetCallHandleOfThePeer(pxHeldCCInfo->ucPeerHandsetId,
                                          &pxTransCCInfo,
                                          pxHeldCCInfo->ucCallId);
      if(pxTransCCInfo != NULL){
        IFX_DECT_EncodeCCInfo(pxTransCCInfo->ucHandsetId,
	                        pxTransCCInfo->ucInstanceId,
                            0XFF,&xIpcMsg);

        uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);       
                    /* Encode CLIP */
        if(strlen(pxActiveCCInfo->acCLIP) >0) {
	        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			             pxActiveCCInfo->acCLIP );
          IFX_DECT_CSU_EncodeCLIP(pxActiveCCInfo->acCLIP,strlen(pxActiveCCInfo->acCLIP),
					   pxActiveCCInfo->bIsPresentation,uiIEHdl,pxActiveCCInfo->isInternal);
        }
        /* Encode CNIP */
        /* Encode CNIP if the HS is CATIQ */
        if(strlen(pxActiveCCInfo->acCNIP) > 0) {
	        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			             pxActiveCCInfo->acCNIP );
	        IFX_DECT_CSU_EncodeCNIP(pxActiveCCInfo->acCNIP,strlen(pxActiveCCInfo->acCNIP),
	                                pxActiveCCInfo->bIsPresentation,uiIEHdl,pxTransCCInfo->ucHandsetId);
        }
        // JONATHAN_150311.
        /* Construct the CALL-INFORMATION IE. We need to send the ActiveCallId + UpdatedCallId
           (CallId for the held call) and TransferredLineId (LineId of the held call if external)
           call status should call under transfer */
        IFX_DECT_CSU_EncodeCallInformation(pxHeldCCInfo->ucCallId,IFX_DECT_CS_CONNECT,0xFF,
        pxActiveCCInfo->ucCallId, pxActiveCCInfo->ucLineId== 0x7F?0xFF:pxActiveCCInfo->ucLineId,uiIEHdl);

        /* TODO Send Remote CLIP Aswell*/
        IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      } 
    }

    /* Call Reinjection */
    if(pxCallParams){
     pxCallParams->ucLineId = pxHeldCCInfo->ucLineId;
     pxCallParams->bIsPresentation = pxHeldCCInfo->bIsPresentation;
     pxCallParams->isInternal = pxHeldCCInfo->isInternal;
    }

    IFX_DECT_CSU_CallRelease( 
	              uiHeldCallHdl, 
                &xCallParams, 
                IFX_DECT_RELEASE_NORMAL);
  
		IFX_DECT_CSU_CallRelease( 
	              uiActiveCallHdl, 
                &xCallParams, 
                IFX_DECT_RELEASE_NORMAL); 

    /* Call Reinjection */
    if(pxCallParams){
     pxCallParams->bIsAllCallsReleased = 1;
     pxHeldCCInfo->ucLineId = pxCallParams->ucLineId;
     pxHeldCCInfo->isInternal = pxCallParams->isInternal;
     pxHeldCCInfo->bIsPresentation = pxCallParams->bIsPresentation;
    }
  }//Update Call Status
 }
 
 /* Call Reinjection */
 if(pxCallParams && pxHeldCCInfo->ucPeerHandsetId){
  /* Save the remote extn Id for the first call in pxCallParams */
  pxCallParams->ucPeerHandsetId = pxHeldCCInfo->ucPeerHandsetId;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Remote Extn for the first call ",
           pxCallParams->ucPeerHandsetId);
 }
 return IFX_SUCCESS;
}


/*! \brief  This function is used acknowledge a conference request to PT. The FT 
                    application will call this function when it wants to acknowledge a 
                    call conference request and inform the result. Typically. for a VoIP, a
                    re-invite from network shall lead to invocation of this function.
   \param[in] uiHeldCallHdl Held Call Handle of the call to be conferenced
   \param[in] uiActiveCallHdl Active Call Handle of the call that to be combined
   \param[in] pxCallParams Reference to Call parameters
   \param[in] eStatus SUCCESS/FAILURE of the request 
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, all fields in the CallParams are mandatory except for uiIEHandler and bHookFlash.
*/
e_IFX_Return
IFX_DECT_CSU_CallConferenceAck(IN uint32 uiHeldCallHdl,
                               IN uint32 uiActiveCallHdl,
                               IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                               IN e_IFX_Return eStatus)
{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  uint32 uiIEHdl=0;
  x_IFX_DECT_CC_Info *pxHeldCCInfo = (x_IFX_DECT_CC_Info*)uiHeldCallHdl;
  x_IFX_DECT_CC_Info *pxActiveCCInfo = (x_IFX_DECT_CC_Info*)uiActiveCallHdl;
  x_IFX_DECT_CC_Info *pxActivePeerCCInfo = NULL;  
  x_IFX_DECT_CC_Info *pxHeldPeerCCInfo = NULL; 

  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
 
  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxHeldCCInfo)
   	 ||IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxActiveCCInfo)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid CallHandles");
    return IFX_FAILURE;                        
  }	

	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Held CCInfo",pxHeldCCInfo); 

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Active CCInfo",pxActiveCCInfo); 

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Held CallID",pxHeldCCInfo->ucCallId);

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Active CallID",pxActiveCCInfo->ucCallId);  
  

  /*  Send the negative acknowledgement 
	 ucSignal = 09H */  
  if(eStatus == IFX_FAILURE) {
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Conference Fail sending NACK");
    IFX_DECT_CSU_SendAckToPP(pxHeldCCInfo->ucHandsetId,
							 pxHeldCCInfo->ucInstanceId,
							 pxHeldCCInfo->ucCallId,
							 pxHeldCCInfo->ucLineId,pxHeldCCInfo->eState,IFX_DECT_CS_CODE_FAIL,
							 IFX_DECT_CSU_SIGNAL_NACK); 
  } 
  else 
  {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	           "Conference is successful");
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	       "Change State for both the Calls");
      pxHeldCCInfo->eState = IFX_DECT_CS_CONF_CONNECT;
      pxActiveCCInfo->eState = IFX_DECT_CS_CONF_CONNECT;
      
      /* Send the csidle and cs_conf_connect to the conf initiated handset*/
      IFX_DECT_EncodeCCInfo(pxActiveCCInfo->ucHandsetId,
	 	                    pxActiveCCInfo->ucInstanceId,
                            0xFF,&xIpcMsg);
      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);         
	    IFX_DECT_CSU_EncodeCallInformation(pxActiveCCInfo->ucCallId,IFX_DECT_CS_IDLE,0xFF,
		                                 0xFF,pxActiveCCInfo->ucLineId== 0x7F?0xFF:pxActiveCCInfo->ucLineId,uiIEHdl);   
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  

      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	       "Send conference connect with the ConfId to the Initiator");
      memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
      IFX_DECT_EncodeCCInfo(pxActiveCCInfo->ucHandsetId,
	                        pxActiveCCInfo->ucInstanceId,
                            0XFF,&xIpcMsg);  
      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);   
      
      /* Construct the CALL-INFORMATION IE */      
      IFX_DECT_CSU_EncodeCallInformation(pxHeldCCInfo->ucCallId,IFX_DECT_CS_CONF_CONNECT,
            0xFF,0xFF,pxActiveCCInfo->ucLineId== 0x7F?0xFF:pxActiveCCInfo->ucLineId,uiIEHdl);   
      
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);

    if(pxActiveCCInfo->ucPeerHandsetId !=0xFF)
    {  
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Send Conference Connect and ");
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Update CallId and Conf Id to the Other PP");
//      callId = pxActiveCCInfo->ucCallId;
        if(IFX_DECT_MU_IsCAT2(pxActiveCCInfo->ucPeerHandsetId)) 
        {
          if(IFX_DECT_CSU_GetCallHandleOfThePeer(pxActiveCCInfo->ucPeerHandsetId,
                                            &pxActivePeerCCInfo,
                                            pxActiveCCInfo->ucCallId)==IFX_FAILURE){
           return IFX_FAILURE;
          }
	        IFX_DECT_EncodeCCInfo(pxActivePeerCCInfo->ucHandsetId,
							pxActivePeerCCInfo->ucInstanceId,
							0XFF,&xIpcMsg);

          /* Construct the CALL-INFORMATION IE */
          uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);       
        IFX_DECT_CSU_EncodeCallInformation(pxActiveCCInfo->ucCallId,IFX_DECT_CS_CONF_CONNECT,0xFF,
		                                 pxHeldCCInfo->ucCallId,pxActiveCCInfo->ucLineId== 0x7F?0xFF:pxActiveCCInfo->ucLineId,uiIEHdl);   
        IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
          IFX_DECT_MU_FreeCallID(pxActiveCCInfo->ucCallId);
        pxActivePeerCCInfo->ucCallId = pxActiveCCInfo->ucCallId = pxHeldCCInfo->ucCallId;
      }else{
           IFX_DECT_MU_FreeCallID(pxActiveCCInfo->ucCallId);
         pxActiveCCInfo->ucCallId = pxHeldCCInfo->ucCallId;
      }
    } else { //External Call
           IFX_DECT_MU_FreeCallID(pxActiveCCInfo->ucCallId);
           pxActiveCCInfo->ucCallId = pxHeldCCInfo->ucCallId;
    }

	  /* Send updated CallId to the PP which is in the Hold call */
    if(pxHeldCCInfo->ucPeerHandsetId !=0xFF)
    { 
	    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Send Conference Connect and ");
	    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Update CallId and Conf Id to the Peer PP");
   
      if(IFX_DECT_MU_IsCAT2(pxHeldCCInfo->ucPeerHandsetId)) 
      {
        if(IFX_DECT_CSU_GetCallHandleOfThePeer(pxHeldCCInfo->ucPeerHandsetId,
                                            &pxHeldPeerCCInfo,
                                            pxHeldCCInfo->ucCallId)==IFX_FAILURE){
           return IFX_FAILURE;
        }
        memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));      
	      IFX_DECT_EncodeCCInfo(pxHeldPeerCCInfo->ucHandsetId,
						    pxHeldPeerCCInfo->ucInstanceId,
						    0XFF,&xIpcMsg);
        /* Construct the CALL-INFORMATION IE */
        uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);        
        IFX_DECT_CSU_EncodeCallInformation(pxHeldCCInfo->ucCallId,IFX_DECT_CS_CONF_CONNECT,0xFF,
		                                     0xFF,pxHeldCCInfo->ucLineId== 0x7F?0xFF:pxHeldCCInfo->ucLineId,uiIEHdl); 
        IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
        pxHeldPeerCCInfo->eState = IFX_DECT_CS_CONNECT;
      }
    } 
  }
  return IFX_SUCCESS;
}


 /*! \brief  This function is used acknowledge a transfer request to PT. The FT 
                    application will call this function when it wants to acknowledge a 
                    transfer request and inform the result. Typically. for a VoIP, a
                    NOTIFY from network shall lead to invocation of this function. 
 
   \param[in] uiHeldCallHdl Held Call Handle of the call to be transfered
   \param[in] uiActiveCallHdl Active Call Handle of the call 
   \param[in] pxCallParams Reference to Call parameters
   \param[in] eStatus SUCCESS/FAILURE of the request
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, all fields in the CallParams are mandatory except for uiIEHandler and bHookFlash.
*/
e_IFX_Return
IFX_DECT_CSU_InterceptAck(IN uint32 uiOwnCallHdl, 
                          IN uint32 uiInterceptCallHdl,
                          IN e_IFX_DECT_CSU_InterceptStatus eReason)
{
	uchar8 ucCallId;
  x_IFX_DECT_CC_Info *pxOwnCCInfo = (x_IFX_DECT_CC_Info*)uiOwnCallHdl;
  x_IFX_DECT_CC_Info *pxInterceptCCInfo = NULL;
	if(uiInterceptCallHdl){
		pxInterceptCCInfo = (x_IFX_DECT_CC_Info*)uiInterceptCallHdl;
		if (pxInterceptCCInfo == NULL)
			return IFX_FAILURE;
  	if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxInterceptCCInfo)){
   		IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid Intercept Handle");
   		return IFX_FAILURE;                        
  	}
	}
  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxOwnCCInfo)){
   	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid Own Call Handle");
   	return IFX_FAILURE;                        
  }
		pxOwnCCInfo->uiFlag &= ~(IFX_DECT_CSU_INTERCEPT_REQUESTED); 
	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Entry");

  /*Failure Case*/
	if(eReason != IFX_DECT_CSU_INTERCEPT_SUCCESS){
    x_IFX_DECT_IPC_Msg xIpcMsg={0};
    memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
	printf("Handset:Instance:CallId---%d---%d----%d\n",pxOwnCCInfo->ucHandsetId,pxOwnCCInfo->ucInstanceId,ucCallId);
		switch(eReason){
		case IFX_DECT_CSU_INTERCEPT_NOCALL:
		case IFX_DECT_CSU_INTERCEPT_TOOEARLY:
  	IFX_DECT_MU_GetCallID(&ucCallId);
 
	  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Send SETUP_ACK");
    /* Call status SETUP_ACK*/
   	IFX_DECT_EncodeConnect(pxOwnCCInfo->ucHandsetId, 
                         		pxOwnCCInfo->ucInstanceId,
						 								pxOwnCCInfo->bwideband,&xIpcMsg);
	    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
 
   	IFX_DECT_CSU_SendAckToPP(pxOwnCCInfo->ucHandsetId, 
                         		pxOwnCCInfo->ucInstanceId,
						 								ucCallId,
						 								0xFF,IFX_DECT_CS_SETUP_ACK,
														0xFF,0x00);
		pxOwnCCInfo->eState=IFX_DECT_CS_PROC;
  	pxOwnCCInfo->ucCallId = ucCallId; /*  Store the CallId */
		break;
		case IFX_DECT_CSU_INTERCEPT_NOTALLOWED:
	  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Intercept Not Allowed");
  	x_IFX_DECT_CC_Info *pxInterceptCCInfo = (x_IFX_DECT_CC_Info*)uiInterceptCallHdl;
		if (pxInterceptCCInfo == NULL)
			return IFX_FAILURE;
		uint32 uiIEHdl;
    /* Call status disconnecting and reason*/
   	IFX_DECT_EncodeConnect(pxOwnCCInfo->ucHandsetId, 
                         pxOwnCCInfo->ucInstanceId,
						 						 pxOwnCCInfo->bwideband,&xIpcMsg);
          uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
    IFX_DECT_CSU_EncodeCallInformation(pxInterceptCCInfo->ucCallId,0xFF,0xFF,
		                                   0xFF,0xFF,uiIEHdl);
			
	    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  /*  	IFX_DECT_EncodeCallProc(pxOwnCCInfo->ucHandsetId,pxOwnCCInfo->ucInstanceId,
                                     &xIpcMsg);*/
   	IFX_DECT_CSU_SendAckToPP(pxOwnCCInfo->ucHandsetId, 
                         		pxOwnCCInfo->ucInstanceId,
						 								pxInterceptCCInfo->ucCallId,
						 								0xFF,IFX_DECT_CS_PROC,
														0xFF,0xFF);
    /*      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
          IFX_DECT_CSU_EncodeCallInformation(ucCallId,IFX_DECT_CS_PROC,0xFF,
		                                   0xFF,0xFF,uiIEHdl);
	    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);*/
	    pxOwnCCInfo->eState = IFX_DECT_CS_PROC;
	
   	IFX_DECT_CSU_SendAckToPP(pxOwnCCInfo->ucHandsetId, 
                         		pxOwnCCInfo->ucInstanceId,
						 								pxInterceptCCInfo->ucCallId,
						 								0xFF,IFX_DECT_CS_DISCONNECT,
														IFX_DECT_CS_CODE_FAIL,0x09);
		sleep(1);
    /* Call status idle inorder to free the callid*/
  	IFX_DECT_CSU_SendAckToPP(pxOwnCCInfo->ucHandsetId, 
                         pxOwnCCInfo->ucInstanceId,
						 							pxInterceptCCInfo->ucCallId,
						 0xFF,IFX_DECT_CS_IDLE,0xFF,
						 0x3F);

		//pxOwnCCInfo->eState=IFX_DECT_CS_IDLE;
 
		break;
		default:
		break;
	}
		
		return IFX_SUCCESS;
	}
/*Success Case*/
	else{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  uint32 uiIEHdl;
	  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Intercept successful");
	if (pxInterceptCCInfo == NULL)
			return IFX_FAILURE;
		pxOwnCCInfo->ucCallId=pxInterceptCCInfo->ucCallId;
		pxOwnCCInfo->ucLineId=pxInterceptCCInfo->ucLineId;
		pxOwnCCInfo->isInternal =  pxInterceptCCInfo->isInternal;
		memset(pxOwnCCInfo->acCLIP,0,sizeof(pxOwnCCInfo->acCLIP));
		memset(pxOwnCCInfo->acCNIP,0,sizeof(pxOwnCCInfo->acCNIP));
		strcpy(pxOwnCCInfo->acCLIP,pxInterceptCCInfo->acCLIP);
		strcpy(pxOwnCCInfo->acCNIP,pxInterceptCCInfo->acCNIP);
  	IFX_DECT_EncodeCCInfo(pxOwnCCInfo->ucHandsetId,pxOwnCCInfo->ucInstanceId,
                        0xFF,&xIpcMsg);
   	/*IFX_DECT_EncodeConnect(pxOwnCCInfo->ucHandsetId, 
                         pxOwnCCInfo->ucInstanceId,
						 						 pxOwnCCInfo->bwideband,&xIpcMsg);*/
    uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
          IFX_DECT_CSU_EncodeCallInformation(pxOwnCCInfo->ucCallId,IFX_DECT_CS_CONNECT,0xFF,
		                                   0xFF,pxOwnCCInfo->ucLineId==0x7F?0xFF:pxOwnCCInfo->ucLineId,uiIEHdl);
	    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
		sleep(1);
		memset(&xIpcMsg,0,sizeof(xIpcMsg));
      
  	IFX_DECT_EncodeCCInfo(pxOwnCCInfo->ucHandsetId,pxOwnCCInfo->ucInstanceId,
                        0xFF,&xIpcMsg);
    uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
    IFX_DECT_CSU_EncodeCallInformation(pxOwnCCInfo->ucCallId,0xFF,0xFF,
		                                   0xFF,0xFF,uiIEHdl);
    /* Encode CNIP */
     if(strlen(pxOwnCCInfo->acCNIP) >0) {
	     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			          pxOwnCCInfo->acCNIP );
	     IFX_DECT_CSU_EncodeCNIP(pxOwnCCInfo->acCNIP,strlen(pxOwnCCInfo->acCNIP),
                  pxOwnCCInfo->bIsPresentation,uiIEHdl,pxOwnCCInfo->ucHandsetId);
     }

  /* Encode CLIP */
  if(strlen(pxOwnCCInfo->acCLIP) >0) {
	  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					 pxOwnCCInfo->acCLIP );
	  IFX_DECT_CSU_EncodeCLIP(pxOwnCCInfo->acCLIP,strlen(pxOwnCCInfo->acCLIP),
                pxOwnCCInfo->bIsPresentation,uiIEHdl, pxOwnCCInfo->isInternal);
  }

	    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
	    pxOwnCCInfo->eState = IFX_DECT_CS_CONNECT;
		return IFX_SUCCESS;
	}
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_Send_CallState
* Description    : Process CSU Stack Message
* Input Values   : IPC Message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          : In pxCallParams uiSignal must be filled in without fail
									without that it will be sending DialTone always.Fill 0xFF if no signal to be used
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_Send_CallState(IN uint32 uiCallHdl,
                   				IN x_IFX_DECT_CSU_CallParams *pxCallParams,
													IN e_IFX_DECT_IE_CallStatus eState)
{
  uint32 uiIEHdl;
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
  
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxCCInfo)
   	  || !pxCallParams){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid Handles");
    return IFX_FAILURE;                        
  }
	if(eState > IFX_DECT_CC_MEDIA_NEG){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Not a Valid State to Update");
	}
  if(IFX_DECT_CS_DISCONNECT == pxCCInfo->eState || 
     IFX_DECT_CS_IDLE ==pxCCInfo->eState){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid State");
    return IFX_FAILURE;                        
  }
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"HandsetId is: ",
                 pxCCInfo->ucHandsetId);
  IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,
                        pxCCInfo->ucInstanceId,
                        (IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId))?pxCallParams->uiSignal:0xFF,
						&xIpcMsg);
  uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);
 // pxCCInfo->isInternal = pxCallParams->isInternal;
  /* Encode CLIP */
  if(strlen(pxCallParams->acCLIP) >0) {
	IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
			 pxCallParams->acCLIP );
  //strcpy(pxCCInfo->acCLIP , pxCallParams->acCLIP);
	IFX_DECT_CSU_EncodeCLIP(pxCallParams->acCLIP,strlen(pxCallParams->acCLIP),
	 pxCallParams->bIsPresentation,uiIEHdl,pxCallParams->isInternal);
  }
	if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){
  /* Encode CNIP */
   if(strlen(pxCallParams->acCNIP) > 0) {
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 pxCallParams->acCNIP );
    //  strcpy(pxCCInfo->acCNIP , pxCallParams->acCNIP);
      IFX_DECT_CSU_EncodeCNIP(pxCallParams->acCNIP,strlen(pxCallParams->acCNIP),
      pxCallParams->bIsPresentation,uiIEHdl,pxCCInfo->ucHandsetId);

    }
    IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,eState,0xFF,0xFF,
	                                 pxCCInfo->ucLineId==0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl); 
	}

  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		         "Send CC-INFO");
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
	pxCCInfo->eState = eState;
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Returning Success");
  return IFX_SUCCESS;                        
                          
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_IsIntrAllowed
* Description    : This function Checks whether Intrude/Intercept Request is allowed at this time
									returns FAILURE if any of the Intrude/Intercept is ongoing in the system.
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_IsIntrAllowed(void)
{
  uint16 i=0,j=0;
  for(i=0;i<IFX_DECT_MAX_HS;i++){
    for(j=0;j<IFX_DECT_MAX_CALLS_PER_HS;j++){
      if((avxCCInfo[i][j].uiFlag&IFX_DECT_CSU_INTRUDE_REQUESTED)||
					(avxCCInfo[i][j].uiFlag&IFX_DECT_CSU_INTERCEPT_REQUESTED)){
  				IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					"Intrude/Intercept request reject");
        	return IFX_FAILURE;
      }
		}
  }
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_CSU_ClearInterceptInit
* Description    : This function Clears all the Intercept Initiated flags and sent the CCInfo.
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return 
IFX_DECT_CSU_ClearInterceptInit(IN x_IFX_DECT_CC_Info *pxCCInfo)
{
  uint16 i=0,j=0;
  x_IFX_DECT_CSU_CallParams xCallParams={0};
	memset(&xCallParams,0,sizeof(xCallParams));
  for(i=0;i<IFX_DECT_MAX_HS;i++){
    for(j=0;j<IFX_DECT_MAX_CALLS_PER_HS;j++){
      if((avxCCInfo[i][j].uiFlag&IFX_DECT_CSU_INTERCEPT_INITIATED)){
	     xCallParams.uiSignal = (IFX_DECT_MU_IsCAT2(avxCCInfo[i][j].ucHandsetId))?0x3F:0xFF;
					IFX_DECT_CSU_InfoReceived((uint32)&avxCCInfo[i][j],&xCallParams);
  				IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,avxCCInfo[i][j].ucHandsetId,
					"Clearing Intercept Initiation");
      }
			if(avxCCInfo[i][j].ucCallId != pxCCInfo->ucCallId){
				avxCCInfo[i][j].uiFlag &= ~IFX_DECT_CSU_INTERCEPT_INITIATED;
			}
		}
  }
  return IFX_SUCCESS;
}



/****************Intrusion Ack*********************************/
 e_IFX_Return
IFX_DECT_CSU_CallIntrusionAck(IN uint32 uiOwnCallHdl,
                               IN uint32 uiIntrusionCallHdl,
                               IN e_IFX_Return eStatus)
{
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  uint32 uiIEHdl=0;
	uchar8 ucCallId=0xFF;
  x_IFX_DECT_CC_Info *pxOwnCCInfo = (x_IFX_DECT_CC_Info*)uiOwnCallHdl;
  x_IFX_DECT_CC_Info *pxIntrusionCCInfo=NULL;
  //x_IFX_DECT_CC_Info *pxIntrusionPeerCCInfo = NULL; 
	memset(&xIpcMsg,0,sizeof(xIpcMsg)); 
  if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxOwnCCInfo)){

    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid Own  CallHandles");
    return IFX_FAILURE;                        
  }	
	ucCallId = pxOwnCCInfo->ucCallId;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Own CCInfo",pxOwnCCInfo); 
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Ownn CallID",pxOwnCCInfo->ucCallId);  
	if(uiIntrusionCallHdl != 0){
		if (pxIntrusionCCInfo == NULL)
    	return IFX_FAILURE;                        
  	pxIntrusionCCInfo = (x_IFX_DECT_CC_Info*)uiIntrusionCallHdl;
  	if(IFX_FAILURE == IFX_DECT_CSU_ValidateCCInfo(pxIntrusionCCInfo)){
    	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Invalid Intrusion CallHandles");
    	return IFX_FAILURE;                        
		}
		IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Intrusion CCInfo",pxIntrusionCCInfo); 
  	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
           "Intrusion CallID",pxIntrusionCCInfo->ucCallId);
		ucCallId = (pxOwnCCInfo->ucCallId!=0xFF)?pxOwnCCInfo->ucCallId:pxIntrusionCCInfo->ucCallId;
	}
  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

  if(eStatus == IFX_FAILURE) {
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Conference Fail sending NACK");
		if(ucCallId==0xFF){
  		IFX_DECT_MU_GetCallID(&ucCallId);
			pxOwnCCInfo->ucCallId=ucCallId;
		}
		if(pxOwnCCInfo->eState<IFX_DECT_CS_PROC){
      IFX_DECT_EncodeConnect(pxOwnCCInfo->ucHandsetId,pxOwnCCInfo->ucInstanceId,
			                  pxOwnCCInfo->bwideband,&xIpcMsg);
		
		  
    uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
    IFX_DECT_CSU_EncodeCallInformation(ucCallId,0xFF,0xFF,
		                                   0xFF,pxOwnCCInfo->ucLineId,uiIEHdl);
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
	  pxOwnCCInfo->eState = IFX_DECT_CS_PROC;
		}
    IFX_DECT_CSU_SendAckToPP(pxOwnCCInfo->ucHandsetId,
							 pxOwnCCInfo->ucInstanceId,
							 ucCallId,
							 pxOwnCCInfo->ucLineId,IFX_DECT_CS_DISCONNECT,IFX_DECT_CS_CODE_FAIL,
							 IFX_DECT_CSU_SIGNAL_NACK); 
    IFX_DECT_CSU_SendAckToPP(pxOwnCCInfo->ucHandsetId,
							 pxOwnCCInfo->ucInstanceId,
							 ucCallId,
							 pxOwnCCInfo->ucLineId,IFX_DECT_CS_IDLE,0xFF,0x3F);
  } 
  else 
  {
			
		char8 acCLIP[2]={'\0'};
		if (pxIntrusionCCInfo == NULL)
    	return IFX_FAILURE;
		pxOwnCCInfo->uiFlag &= ~IFX_DECT_CSU_INTRUDE_REQUESTED;
		pxOwnCCInfo->uiFlag |= IFX_DECT_CSU_INTRUDE_INITIATED;
		pxIntrusionCCInfo->uiFlag |= IFX_DECT_CSU_INTRUDE_INITIATED;
		pxIntrusionCCInfo->uiFlag |= IFX_DECT_CSU_INTRUDE_TARGET;
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	          "Conference is successful");
      
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	       "Send conference connect with the ConfId to the Initiator");
    memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
    IFX_DECT_EncodeCCInfo(pxIntrusionCCInfo->ucHandsetId,
	                        	pxIntrusionCCInfo->ucInstanceId,
                            0X02,&xIpcMsg);  
    uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);   
      
      /* Construct the CALL-INFORMATION IE */      
    IFX_DECT_CSU_EncodeCallInformation(pxIntrusionCCInfo->ucCallId,IFX_DECT_CS_CONF_CONNECT,
            0xFF,0xFF,pxIntrusionCCInfo->ucLineId,uiIEHdl);   
		acCLIP[0]=pxOwnCCInfo->ucHandsetId+48;
		IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,acCLIP);
		IFX_DECT_CSU_EncodeCLIP(acCLIP,1,1,uiIEHdl,1);
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
	  /* Send updated CallId to the PP which is in the Hold call */
	   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
			"Update CallId and Conf Id to the Intrusion PP");
		pxOwnCCInfo->ucPeerHandsetId = pxIntrusionCCInfo->ucHandsetId;
		printf(" Own State %d\n",pxOwnCCInfo->eState);
		if(pxOwnCCInfo->eState<IFX_DECT_CS_PROC){
			printf("Sending Connect\n");
      memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));      
     	IFX_DECT_EncodeConnect(pxOwnCCInfo->ucHandsetId,pxOwnCCInfo->ucInstanceId,
			                  pxOwnCCInfo->bwideband,&xIpcMsg);
		  
      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
      IFX_DECT_CSU_EncodeCallInformation(ucCallId,0xFF,0xFF,
		                                   0xFF,pxOwnCCInfo->ucLineId,uiIEHdl);
    	IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
		}
   
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "Change State for both the Calls");
    pxOwnCCInfo->eState = IFX_DECT_CS_CONF_CONNECT;
    pxIntrusionCCInfo->eState = IFX_DECT_CS_CONF_CONNECT;
    memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));      
	  IFX_DECT_EncodeCCInfo(pxOwnCCInfo->ucHandsetId,
						    pxOwnCCInfo->ucInstanceId,
						    0X02,&xIpcMsg);
     /* Construct the CALL-INFORMATION IE */
    uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);        
    IFX_DECT_CSU_EncodeCallInformation(ucCallId,IFX_DECT_CS_CONNECT,0xFF,
																					pxOwnCCInfo->ucCallId,
																					pxIntrusionCCInfo->ucLineId,uiIEHdl); 
    IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  }
	if(pxOwnCCInfo->ucCallId!=0xFF) {
     IFX_DECT_MU_FreeCallID(pxOwnCCInfo->ucCallId);
		pxOwnCCInfo->ucCallId = 0xFF;
	} 
  return IFX_SUCCESS;
}
/**************API for breaking the Conference during Intrusion*********************/

/*e_IFX_Return IFX_DECT_CSU_IntrudeConfBreak(IN uchar8 ucHandsetId){
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  uint32 uiIEHdl=0;
  x_IFX_DECT_CC_Info *pxCCInfo;
	pxCCInfo  = paxActCallHdl[ucHandsetId-1];
	pxCCInfo->uiFlag &= ~IFX_DECT_CSU_INTRUDE_INITIATED;
  memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));      
	IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,
						    pxCCInfo->ucInstanceId,
						    0X3F,&xIpcMsg);*/
        /* Construct the CALL-INFORMATION IE */
/*  uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);        
  IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_CONNECT,0xFF,
																					pxCCInfo->ucCallId,
																					pxCCInfo->ucLineId,uiIEHdl); 
   IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	     "Intrude break sent");
	pxCCInfo->eState = IFX_DECT_CS_CONNECT;
	return IFX_SUCCESS;
}*/
/*************************SetupFailure*******************************************/
e_IFX_Return IFX_DECT_CSU_SetupFailed(IN uint32 uiCallHdl,IN uchar8 eCallReason,IN uchar8 ucRejectReason){
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
	uchar8 ucHandsetId=pxCCInfo->ucHandsetId;
	uchar8 ucInstanceId=pxCCInfo->ucInstanceId;
  uint32 uiIEHdl=0;

	if(pxCCInfo->ucCallId==0xFF)
	IFX_DECT_MU_GetCallID(&pxCCInfo->ucCallId);

	if(eCallReason==0xFF)
		eCallReason=IFX_DECT_CS_INUSE;

	if(ucRejectReason==0xFF)
		ucRejectReason=IFX_DECT_USER_BUSY;

	if (ucHandsetId<1 || ucHandsetId>6)
  	return IFX_FAILURE;

  if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){
      /* Construct CC Connect */
		if(pxCCInfo->eState<IFX_DECT_CS_PROC){
      IFX_DECT_EncodeConnect(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
			                  pxCCInfo->bwideband,&xIpcMsg);
		  
      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
      IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,0xFF,0xFF,
		                                   0xFF,pxCCInfo->ucLineId==0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
			}
      /* Construct the CALL-INFORMATION IE and Send the CC-INFO message */
      memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Send CC-INFO for CallId and LineId.");
      IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,0x04,&xIpcMsg);
      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
      IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_DISCONNECT,eCallReason,
		                           0xFF,pxCCInfo->ucLineId==0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      sleep(2); 
      /* Construct the CALL-INFORMATION IE and Send the CC-INFO message */
      memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Send CC-INFO for CallId and LineId.");
      IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,0x3F,&xIpcMsg);
      uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
      IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_IDLE,0xFF,
		                           0xFF,pxCCInfo->ucLineId==0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
    }

  /*Free Call Control Info if its allocated*/  
  if(pxCCInfo->eState != 0xFF)  {
    IFX_DECT_CSU_FreeCCInfo(pxCCInfo);
  }else{
		IFX_DECT_MU_FreeCallID(pxCCInfo->ucCallId);
	}
  if(ucRejectReason != 0){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Reject code is: ",
                 ucRejectReason);
    memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));

    if(IFX_DECT_MU_IsCAT2(ucHandsetId)){
      IFX_DECT_EncodeRelease(ucHandsetId,
	                  				ucInstanceId,
     	                  		ucRejectReason, 
			  											&xIpcMsg);
 
    }else{
      IFX_DECT_EncodeReject(ucHandsetId,
	                  				ucInstanceId,
     	                  		ucRejectReason, 
			  											&xIpcMsg);
    }
    return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  }
  return IFX_SUCCESS;
}
/************************* ParallelCall Failed**********************************/
e_IFX_Return IFX_DECT_CSU_ParallelCallFailed(IN uint32 uiCallHdl,
																						 IN uchar8 eCallReason){
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
  x_IFX_DECT_CC_Info *pxActiveCCInfo = NULL;
	uchar8 ucCallId=0xFF;
  e_IFX_Return eRet = IFX_FAILURE;
  eRet=IFX_DECT_CSU_GetCallHandleBasedOnState(pxCCInfo->ucHandsetId,&pxActiveCCInfo,IFX_DECT_CS_HOLD);
	/*if callId is generated already copy the call id else generate call Id and send fail*/
	if(pxCCInfo->ucCallId != 0xFF){
		ucCallId=pxCCInfo->ucCallId;
		pxCCInfo->ucCallId=0xFF;
	}else{
  	IFX_DECT_MU_GetCallID(&ucCallId);
	}
	if(eCallReason==0xFF)
		eCallReason=IFX_DECT_CS_INUSE;
    /* Call status disconnecting and reason*/
   	IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId, 
                         		 pxCCInfo->ucInstanceId,
						 									ucCallId,
						 0xFF,IFX_DECT_CS_DISCONNECT,eCallReason,
						 0x04);
       sleep(2);
    /* Call status idle inorder to free the callid*/
  	IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId, 
                         pxCCInfo->ucInstanceId,
						 						ucCallId,
						 0xFF,IFX_DECT_CS_IDLE,0xFF,
						 0x3F);

		/*represents pcall is Initiated when HS has already one call*/
		if(eRet != IFX_FAILURE){
  	/*Free Call Control Info*/  
  		if(pxCCInfo->eState != 0xFF)  {
    		IFX_DECT_CSU_FreeCCInfo(pxCCInfo);
  		}else{
    		IFX_DECT_MU_FreeCallID(ucCallId);
			}
		}else{/*represents pcall is initiated during LiA session*/
			pxActiveCCInfo->eState=IFX_DECT_CC_NOUPLANE;
    	IFX_DECT_MU_FreeCallID(ucCallId);
			pxActiveCCInfo->ucCallId=0xFF;
		}
    return IFX_SUCCESS;  
}
/************************* ParallelCall Success************************/
e_IFX_Return IFX_DECT_CSU_ParallelCallSuccess(IN uint32 uiCallHdl)
{
  x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
  x_IFX_DECT_CC_Info *pxActiveCCInfo = NULL;
  //x_IFX_DECT_CSU_CallParams xCallParams={0};
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
	uint32 uiIEHdl;
  e_IFX_Return eRet = IFX_FAILURE;
  eRet=IFX_DECT_CSU_GetCallHandleBasedOnState(pxCCInfo->ucHandsetId,&pxActiveCCInfo,IFX_DECT_CS_HOLD);
    if((pxCCInfo->eState < IFX_DECT_CS_CONNECT)&&(eRet==IFX_FAILURE)){
	      	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Send CC_CONNECT");
        	/* Construct CC Connect */
	      	IFX_DECT_EncodeConnect(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
			                  pxCCInfo->bwideband,&xIpcMsg);
	      	IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
    }
    /* Construct setup ack as the call information for catiq 2.0 handsets*/
		/*Dont expect Line Id for paralle call*/

    if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)/*&& ((pxCCInfo->ucLineId !=0x7F)&&(pxCCInfo->ucLineId !=0xFF))*/){
    /* Construct the CALL-INFORMATION IE and 
	     Send the CC-INFO message */
    	memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
	  	IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Send CC-INFO for CallId and LineId.");
    
    	IFX_DECT_EncodeCCInfo(pxCCInfo->ucHandsetId,pxCCInfo->ucInstanceId,
			                   0xFF,&xIpcMsg);
    	uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);  
    	IFX_DECT_CSU_EncodeCallInformation(pxCCInfo->ucCallId,IFX_DECT_CS_SETUP_ACK,0xFF,
		                                   0xFF,pxCCInfo->ucLineId==0x7F?0xFF:pxCCInfo->ucLineId,uiIEHdl);
	 		IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
  	}
		pxCCInfo->eState = IFX_DECT_CS_PROC;
#if 0
	    /* Send service change req if the codec for call to be established is different from codec for call established*/
	    if(IFX_DECT_MU_IsCAT2(pxCCInfo->ucHandsetId)){
				/* If the link now is narrowband and if the cc_setup link was wideband than
					 change the link to wideband*/
        IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  		      	"<Parallel Call Init> bwideband is", pxCCInfo->bwideband );
	
        IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
	  		   	"<Parallel call Init> Running Codec  is", IFX_DECT_MU_GetRunCodec(pxCCInfo->ucHandsetId));
		     if(
			     ((pxCCInfo->bwideband ==1 )&& 
			      (IFX_DECT_MU_GetRunCodec(pxCCInfo->ucHandsetId) == IFX_DECTNG_CODEC_G726_32))
			     ){
						xCallParams.bwideband=pxCCInfo->bwideband; 
			      IFX_DECT_CSU_ServiceChange((uint32)pxCCInfo,&xCallParams,IFX_DECT_CSU_SC_REQUEST);
		       }
	    }
#endif
	return IFX_SUCCESS; 
}
#if 1
/**************************Info received and call failed****************************/
e_IFX_Return IFX_DECT_CSU_CallOnLineFailed(IN uint32 uiCallHdl,IN uchar8 ucLineId)
{
   x_IFX_DECT_CC_Info *pxCCInfo = (x_IFX_DECT_CC_Info*)uiCallHdl;
   #if 0  // JONATHAN_150217
   x_IFX_DECT_CC_Info *pxTempCCInfo = NULL;
   #endif

   if(pxCCInfo->ucCallId==0xFF){
      IFX_DECT_MU_GetCallID(&pxCCInfo->ucCallId);
   }

    /* Call status disconnecting and reason*/
   IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
                               pxCCInfo->ucInstanceId,
                                           pxCCInfo->ucCallId,
                                           ucLineId,IFX_DECT_CS_DISCONNECT,IFX_DECT_CS_INUSE,
                                           0x04);
   #if 0  // JONATHAN_150217 : In case of Busy State, FP just send CC_INFO with CS_DISCONNECT, IFX_DECT_CS_INUSE,
           // and Busy tone generation. CC_INFO with Tones Off & CS_IDLE will be send after few seconds (just
           // before when FP send CC Release ==> will be done IFX_DECT_CSU_CallRelease( ))
   /* If its the first call from HS then only send the status Idle*/
   if(IFX_DECT_CSU_GetCallHandleBasedOnState(pxCCInfo->ucHandsetId,&pxTempCCInfo,IFX_DECT_CS_HOLD)==IFX_FAILURE){
   /* Call status idle inorder to free the callid*/
      sleep(2);
   IFX_DECT_CSU_SendAckToPP(pxCCInfo->ucHandsetId,
                      pxCCInfo->ucInstanceId,
                                  pxCCInfo->ucCallId,
                                  ucLineId,IFX_DECT_CS_IDLE,0xFF,
                                  0x3F);
   }
   #endif
   return IFX_SUCCESS;
}
#endif

/************************************************************************
* Function Name  : CallInitSuccess
* Description    : This API is called by Application when CallInit is succeded.
* Input Values   :uiCallHdl-Call Handle of the call,pxCallParams-contains the peerhandsetid 
									info in case of intrude/intercept 
* Output Values  : 
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :This API is used from agent when they return PENDING responses for CallInitiate callback.
* *************************************************************************/
e_IFX_Return
IFX_DECT_CSU_SetLineInfo(IN uchar8 ucHsId,IN x_IFX_DECT_CSU_CallParams *pxCallParams,IN x_IFX_DECT_CSU_LineInfo *pxLineInfo )
{
  e_IFX_DECT_ErrReason eRejectReason_cb; 
	e_IFX_Return eRet=IFX_FAILURE;
  x_IFX_DECT_CC_Info *pxCCInfo = NULL;
  IFX_DECT_CSU_GetCallHandleBasedOnState(ucHsId,&pxCCInfo,IFX_DECT_CS_SETUP);
	uint32 uiCallHdl=(uint32)pxCCInfo;
	if((pxCCInfo->uiFlag&IFX_DECT_CSU_PENDING_PCALL)){/*Parallel call*/
			pxCCInfo->uiFlag &= ~IFX_DECT_CSU_PENDING_PCALL;
		if((pxLineInfo->isCallPossible==0)){/*Call not possible on line*/
			IFX_DECT_CSU_ParallelCallFailed(uiCallHdl,0xFF);
		}else{/*possible on line*/
			eRet = vxCSUCallBks.pfnCallInitiate((uint32)pxCCInfo,pxCCInfo->ucHandsetId,pxCallParams,&eRejectReason_cb,
                    									(uint32*)&pxCCInfo->uiPrivateData);
			IFX_DECT_CSU_ParallelCallSuccess(uiCallHdl);
		}
	}else	if((pxCCInfo->uiFlag&IFX_DECT_CSU_PENDING_INIT)){/*Init pending*/
			pxCCInfo->uiFlag &= ~IFX_DECT_CSU_PENDING_INIT;
		if((pxLineInfo->isCallPossible==0)&&(pxLineInfo->bMode==0)&&!strlen(pxCallParams->acRecvDigits)
			&&(pxLineInfo->bIntrude==1)){/*Line in single call mode */
    	IFX_DECT_MU_FreeCallID(pxCCInfo->ucCallId);
			pxCCInfo->ucCallId = 0xFF;
			pxCCInfo->ucLineId=pxCallParams->ucLineId;
			pxCallParams->eCallType=IFX_DECT_CALL_INTRUSION_REQ;
			pxCCInfo->uiFlag |= IFX_DECT_CSU_INTRUDE_REQUESTED;
			pxCCInfo->uiFlag |= IFX_DECT_CSU_EXPLICIT_CONNECT;
			
			eRet = vxCSUCallBks.pfnCallInitiate((uint32)pxCCInfo,pxCCInfo->ucHandsetId,pxCallParams,&eRejectReason_cb,
                    									(uint32*)&pxCCInfo->uiPrivateData);
			if(IFX_DECT_ENCRYPTION_MODE == IFX_TRUE && eRet != IFX_FAILURE){
			IFX_DECT_CSU_CipherChangeRequest((uint32)pxCCInfo);
			}
		}else if((pxLineInfo->isCallPossible==0)){/*Line in use call not possible*/
			IFX_DECT_CSU_SetupFailed(uiCallHdl,0xFF,0xFF);
		}else{/*Call possible*/
			eRet = vxCSUCallBks.pfnCallInitiate((uint32)pxCCInfo,pxCCInfo->ucHandsetId,pxCallParams,&eRejectReason_cb,
                    									(uint32*)&pxCCInfo->uiPrivateData);
			if(IFX_DECT_ENCRYPTION_MODE == IFX_TRUE && eRet != IFX_FAILURE){
			IFX_DECT_CSU_CipherChangeRequest((uint32)pxCCInfo);
			}
   	/* If Ciphering is off send connect here else initiate cipher and send connect at cipher cfm*/
    	if((IFX_DECT_ENCRYPTION_MODE == IFX_FALSE)&& (pxCCInfo->eState < IFX_DECT_CS_CONNECT)){
				pxCallParams->ucPeerHandsetId=0;
				IFX_DECT_CSU_ExplicitConnect((uint32)pxCCInfo,pxCallParams);
			}
		}
	}
	return IFX_SUCCESS;
}


