/**************************************************************************
**   FILE NAME     : IFX_DECT_CC.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_CC.h
    \brief This File contains the CC Procedures,CC is the main service instance.
	 	It provides a set of procedures that allow the establishment, maintenance and release of
	  circuit switched services. It also provides support for all call related signalling.	with
    few enumerations used within all DECT API's.
*/
/** \defgroup VoIP_LIB_API VoIP Library APIs
    \brief This section describes the API provided by different modules of the 
    VoIP Library.  The Management API for Voice, Configuration API, SIP
    Toolkit API ,RTP Toolkit API  and DECT Toolkit API are described.
*/
/* @{ */
/* @} */ /* VoIP Lib API */
/*---------- First Level Grouping ---------------------*/
/** \ingroup VoIP_LIB_API
    \defgroup DECT_API DECT API 
    \defgroup CC_API CC API 
    \brief This section describes the DECT CC toolkit API
*/

/** \ingroup CC_API
	  \defgroup CC APIs for  CC procedures
    \brief CC is the main service instance. It provides a set of procedures that
	 	allow the establishment, maintenance and release of
		circuit switched services. It also provides support for all call related signalling..
*/
/* @{ */

#ifndef __IFX_DECT_CC_H__
#define __IFX_DECT_CC_H__

/*! \def IFX_DECT_MAX_CODEC
    \brief Macro that specifies the maximum number of codecs.
*/
#define IFX_DECT_MAX_CODEC 3

/*! \def IFX_DECT_MAX_IE_SIZE
    \brief Macro that specifies the maximum size of the IE element.
*/
#define IFX_DECT_MAX_IE_SIZE 250

/*! \def IFX_DECT_CSU_MAX_IDENTIFIERS
    \brief Macro that specifies the maximum number of Identifiers in Identifier List.
*/

#define IFX_DECT_CSU_MAX_IDENTIFIERS 10

/*! \def IFX_DECT_CSU_MAX_IDVALUE_SIZE
	\brief Macro that specifies the maximum number of octets in Identifier Value.
*/

#define IFX_DECT_CSU_MAX_IDVALUE_SIZE 1 


typedef e_IFX_DECT_IE_CallStatus e_IFX_DECT_CC_State;

/* possible values for bCallDir*/
#define IFX_DECT_CALL_DIR_IN 0  /*!< Incoming call to PT */
#define IFX_DECT_CALL_DIR_OUT 1  /*!< Outgoing call to PT */

/* Possible values for uiFlag*/
#define IFX_DECT_CSU_PT_MGD_LINE   0x01  /*!< PT Managed Line */
#define IFX_DECT_CSU_FT_MGD_LINE   0x02  /*!< FT Managed Line */
#define IFX_DECT_CSU_CIPHER_INITIATED  0x04 /*!< Cipher is initiated*/

/* Flags used when hold is internal generated due to call waiting accept and parallel call
   initiate*/
#define IFX_DECT_CSU_PENING_PCALL  0x08 /*!< Pending parallel call*/
#define IFX_DECT_CSU_PENING_CWA  0x10 /*!< Pending call waiting accept*/
#define IFX_DECT_CSU_INTERCEPT_INITIATED  0x20 /*!< INTERCEPT initiated*/
#define IFX_DECT_CSU_INTERCEPT_REQUESTED  0x40 /*!< INTERCEPT requested*/
#define IFX_DECT_CSU_EXPLICIT_CONNECT  0x80 /*!< Explicit connect*/
#define IFX_DECT_CSU_INTRUDE_REQUESTED  0x100 /*!< INTRUDE requested*/
#define IFX_DECT_CSU_INTRUDE_INITIATED  0x200 /*!< INTRUDE initiated*/
#define IFX_DECT_CSU_PENDING_PCALL	  0x400 /*!< Pending Pcall for pending responses*/
#define IFX_DECT_CSU_INTRUDE_TARGET	  0x800 /*!< INTRUDE request target*/
#define IFX_DECT_CSU_PENDING_INIT	  0x1000 /*!< Pending Init*/
#define IFX_DECT_CSU_PENDING_ENVOICE	  0x2000 /*!< Pending Init*/
#define IFX_DECT_CSU_PENDING_SIGNAL	  0x4000 /*!< Pending Signal*/
#define IFX_DECT_CSU_DISCONNECT_SENT   0x8000 /*!< Disconnect status sent*/

#define IFX_DECT_CSU_SUCCESSFUL_ATX  0x00010000
#define IFX_DECT_CSU_IF_REL_THEN_ATX  0x00020000

#define IFX_DECT_CSU_UNKNOWN     0x70000000  /*!< Unknown value */



#define IFX_DECT_CSU_HEXCODE_PREFIX     0x1C
#define IFX_DECT_CSU_HEXCODE_TOGGLE     0x31  /*!< Call toggle  */
#define IFX_DECT_CSU_HEXCODE_CONF       0x32  /*!< Call Conference */
#define IFX_DECT_CSU_HEXCODE_REL        0x33  /*!< Call Release*/
#define IFX_DECT_CSU_HEXCODE_TRANS      0x34  /*!< Call transfer */
#define IFX_DECT_CSU_HEXCODE_CW_ACCEPT  0x35  /*!< Call waiting Accept */
#define IFX_DECT_CSU_HEXCODE_CW_REJECT  0x36  /*!< Call waiting Reject */
#define IFX_DECT_CSU_HEXCODE_CWACCEPT_ACTIVEREL 0x38  /*!< call waiting accept and active release */

#define IFX_DECT_CSU_HEXCODE_EXP_INTRU  0x40  /*!< Explicit Call Intrusion */
#define IFX_DECT_CSU_HEXCODE_ONHOLD     0x41  /*!< pputting a call on hold */
#define IFX_DECT_CSU_HEXCODE_RESUME     0x42  /*!< Resuming a call put On Hold  */
#define IFX_DECT_CSU_HEXCODE_PARA_CALL  0x17  /*!< Parallel Call Internal  */
#define IFX_DECT_CSU_HEXCODE_INTERCEPT  0x50  /*!< Call Intercept */

#define IFX_DECT_CSU_SIGNAL_BUSY    0x04
#define IFX_DECT_CSU_SIGNAL_CW      0x07
#define IFX_DECT_CSU_SIGNAL_NACK    0x09
#define IFX_DECT_CSU_HEXCODE_DEFLECT   0x39  /*!< Call Deflect */



/*! \struct x_IFX_DECT_CC_Info
    \brief An Internal structure of CallControl Module, to maintain callrealted metadata
 */
typedef struct {
 	e_IFX_DECT_CC_State eState;			/*!< Indicates the current state of the Call*/
    uint32 uiFlag; /*!< Internal Flags*/
	boolean bwideband;						/*!< Codec being used */
 	uchar8 	ucHandsetId;						/*!< Handset Identifier*/
 	uchar8 	ucInstanceId;						/*!< Instance Identifier*/
 	uint32 	uiPrivateData;					/*!< Agent Identifier*/
 	char8 	acIE[IFX_DECT_MAX_IE_SIZE];	/*!< Information Element*/
 	char8 	acDigits[IFX_DECT_MAX_DIGITS];/*!< Recived Digits*/
	boolean bCallDir;							/*!< Indicates call Direction */
	uint16 	aunCodec[IFX_DECT_MAX_CODEC];
  char8 acCLIP[IFX_DECT_MAX_CLIP]; /*!< CLIP */
  char8 acCNIP[IFX_DECT_MAX_CNIP];/*!< CNIP */
  boolean bIsPresentation; /*!< Clip and CNIP  is Presentation*/
	uchar8 	ucBasicService;
	uint16  unHwVoiceChannel;
	uchar8 	ucCallId;  	/*!< Call Identification  unique for each call*/ 
	uchar8  ucLineId;  /*!< Line identification */  
    boolean bLineMode; /*!< TRUE - Single call line, FALSE - Multi call line */	
	boolean isInternal; /*!< Whether it is a internal call[TRUE], external call [FALSE] */
    uchar8  ucPeerHandsetId; /*!< Used in case of internal calls, contains peer Handset Id */
    uint32 uiParaCallHdl;  /*!< Handle for Parallel Call */
    uint32 uiSignal; /*!< To store the signal value if CC_info was sent before CC_Connect*/

}x_IFX_DECT_CC_Info;

/*! \brief  This API is used to process Incoming IPC Message.
		\param[in] pxIPCMsg received from the stack
		\param[OUT] 
	  \return IFX_SUCCESS / IFX_FAILURE /IFX_PENDING
*/

/*e_IFX_Return 
IFX_DECT_CSU_ProcessStackMsg(IN x_IFX_IPC_Msg *pxIPCMsg);*/

e_IFX_Return
IFX_DECT_CSU_GetActiveCallId(IN uchar8 ucHandsetId,
                             OUT uchar8 *pucCallId);
e_IFX_Return IFX_DECT_CSU_ClearInterceptInit(IN x_IFX_DECT_CC_Info *pxCCInfo);
/*! \brief  This function is used to inform the PT about the information
                   received from the remote/local party.  The information typically is Call stae Update
						with CLIP,CNIP and UcSignal to be sent.
                     \param[in] uiCallHdl Call Handle of the call
          \param[in] pxCallParams Reference to call parameters
					\param[in] eState state to be updated with
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
*/
e_IFX_Return 
IFX_DECT_CSU_Send_CallState(IN uint32 uiCallHdl,
                   				IN x_IFX_DECT_CSU_CallParams *pxCallParams,
													IN e_IFX_DECT_IE_CallStatus eState);
/*! \brief  This function is used to send connect from the PP.  
 
   \param[in] uiCallHdl CallHdl of the  PP
   \param[in] pxCallParams fill in ucPeerHandsetId=0 for sending normal connect else fill in the target HSId which we
							are Intruding/Intercepting in case of sending connect for Intrude/Intercept
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
*/

e_IFX_Return
IFX_DECT_CSU_ExplicitConnect(IN uint32 uiCallHdl,IN x_IFX_DECT_CSU_CallParams *pxCallParams);


/*! \brief  This function is used to restrict only one Intrude/Intercept request in the system from Toolkit  
 
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
*/
e_IFX_Return IFX_DECT_CSU_IsIntrAllowed(void);

/*! \brief  This function is used to send multidisplay to the PP.  
 
   \param[in] uiCallHdl CallHdl of the  PP
   \param[in] ucSignal any signal to be sent 
   \param[in] pxCallParams fill in CLIP/CNIP to send the CLIP/CNIP to the PP
   \param[in] szString pointer to the string to be sent to PP.
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
*/
e_IFX_Return
IFX_DECT_CSU_SendMultiDisplayToPP(IN uint32 uiCallHdl,IN uchar8 ucSignal,IN x_IFX_DECT_CSU_CallParams *pxCallParams,
																	IN char8 *szString);

/*! \brief  This function is used to inform the PT that the remote/local party
                  wishes to initiate a cipher change procedure.   
   \param[in] uiCallHdl Call Handle of the call
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
*/
e_IFX_Return IFX_DECT_CSU_CipherChangeRequest(IN uint32 uiCallHdl);
e_IFX_Return IFX_DECT_CSU_ParallelCallFailed(IN uint32 uiCallHdl,
																						 IN uchar8 ucCallReason);
e_IFX_Return IFX_DECT_CSU_SetupFailed(IN uint32 uiCallHdl,IN uchar8 ucCallReason,IN uchar8 ucRejectReason);
e_IFX_Return IFX_DECT_CSU_ParallelCallSuccess(IN uint32 uiCallHdl);
/*! \brief  This function is used to send Nack to the PP in case of outgoing call on a single callmode line
						when the line is already in use.\n
    \param[in] uiCallHdl -call Handle of the PP
		\param[in] ucLineId- LineId on which the call is failed.\n
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_CSU_CallOnLineFailed(IN uint32 uiCallHdl,IN uchar8 ucLineId);


#endif /* __IFX_DECT_CC_H__*/
							 
