/*
 * =====================================================================================
 *
 *       Filename:  IFX_DECT_MSGROUTER.h
 *
 *    Description:  API of the message router
 *
 *        Version:  1.0
 *        Created:  Wednesday 15 October 2008 11:03:04  IST
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Voice Team
 *        Company:  IFIN
 *
 * =====================================================================================
 */
/*! \file IFX_DECT_MsgRouter.h
    \brief This File interfaces DECT Stack and the toolkit. Contains API's 
           to Comunicate to and from the STACK and toolkit.
*/

#ifndef __IFX_DECT_MSGROUTER_H__
#define __IFX_DECT_MSGROUTER_H__

#include "ifx_common_defs.h"

/*! \def IFX_IPC_DECT_MAX_MSG_SIZE
    \brief maximum Cplane Message size.
 */
#define IFX_IPC_DECT_MAX_MSG_SIZE 256

/*! \def IFX_IPC_DECT_MAX_DATA_SIZE
    \brief Maximum Cplane accumlated IE Size.
 */
#define IFX_IPC_DECT_MAX_DATA_SIZE 250

/*! \def IFX_IPC_DECT_MAX_DATA_SIZE_U
    \brief Maximum Uplane accumlated data Size.
 */
#if 1  // JONATHAN_SUOTA_TEST
#define IFX_IPC_DECT_MAX_DATA_SIZE_U 620
#else
#define IFX_IPC_DECT_MAX_DATA_SIZE_U 513
#endif

/*! \def IFX_IPC_DECT_C_PLANE
    \brief Cplane message.
 */
#define IFX_IPC_DECT_C_PLANE 0x1

/*! \def IFX_IPC_DECT_U_PLANE
    \brief U plane message.
 */
#define IFX_IPC_DECT_U_PLANE 0x2

/**  This structure defines all the DECT Stack C plane Interface message 
 */
typedef struct
{
	uchar8 ucMsgId;/*!< Message Identifier*/
	uchar8 ucInstance;/*!< MCEI Number*/
	uchar8 ucPara1;/*!< Parameter 1*/
	uchar8 ucPara2;/*!< Parameter 2*/
	uchar8 ucPara3;/*!< Parameter 3*/
	uchar8 ucPara4;/*!< Parameter 4*/ 
	uchar8 acData[IFX_IPC_DECT_MAX_DATA_SIZE];/*!< User defined IE buffer*/
}x_IFX_DECT_IPC_Msg;

/**  This structure defines all the DECT Stack U plane Interface message 
 */
typedef struct
{
	uchar8 ucMsgId;/*!< Message Identifier*/
	uchar8 ucInstance;/*!< MCEI Number*/
	uchar8 ucPara1;/*!< Parameter 1*/
	uchar8 ucPara2;/*!< Parameter 2*/
	uchar8 ucPara3;/*!< Parameter 3*/
	uchar8 ucPara4;/*!< Parameter 4*/ 
	uchar8 acData[IFX_IPC_DECT_MAX_DATA_SIZE_U];/*!< data buffer*/	
}x_IFX_DECT_IPC_Msg_u;

extern int32 iDectCplaneFifoFd;
extern int32 iDectUplaneFifoFd;
extern x_IFX_DECT_IPC_Msg vxApp2StackMsg;
extern  x_IFX_DECT_IPC_Msg vxStack2AppMsg;
//extern x_IFX_DECT_IPC_Msg_u uplaneMsgBuf; 
#ifdef SUPERTASK


#define MAX_NO_OF_MSG 20
extern x_IFX_DECT_IPC_Msg from_agent_read_buf;
extern x_IFX_DECT_IPC_Msg to_agent_write_buf;
extern x_IFX_DECT_IPC_Msg axfrom_agent_read_buf[MAX_NO_OF_MSG];
extern int viStackMBId;
void lock_preempt();
void unlock_preempt();
int DectAgentIf_Init(void);
int DectAgentIf_StackMBRead(unsigned char *pcBuf,int iSize);
int DectAgentIf_StackMBWrite(unsigned char *pcBuf,int iSize);
int DectAgentIf_IsStackMBEmpty();
#endif

/*! \brief  Initilizes Interface between DECT stack and Toolkit
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_MsgRt_Init(void);

/*! \brief  Post a message to DECT Stack
    \param[in] iPlane set 1 to post to Cplane and 2 to post to Uplane
    \param[in] pxMsg reference to Message based on the plane
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_MsgRt_PostToStack(IN int32 iPlane,
                                        IN void * pxMsg);

/*! \brief  Read message posted by toolkit to DECT Stack 
    \param[in] iPlane set 1 to post to Cplane and 2 to post to Uplane
    \param[in] pcBuf reference to buffer to hold the message
    \param[in] iSize Size of the message read.
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_MsgRt_ReadAppMsg(IN int32 iPlane,
                                       IN uchar8 *pcBuf,
                                       IN int32 iSize);

/*! \brief  Process message posted by DECT Stack to Toolkit
    \param[in] iPlane set 1 to post to Cplane and 2 to post to Uplane
    \param[in] pxMsg reference to Message based on the plane
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_MsgRt_ProcessStackMessage(IN int32 iPlane,
                                                IN void* pxMsg);
#ifdef CATIQ_UPLANE
/*! \brief  Process message posted by DECT toolkit to DPSU Uplane
    \param[in] pxMsg reference to Message based on the plane
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DPSU_ProcessUPlaneMsg(IN x_IFX_DECT_IPC_Msg_u *pxUPlaneIpcMsg);

/*! \brief  Process message posted by DECT  Toolkit to DPSU Cplane
    \param[in] pxMsg reference to Message based on the plane
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DPSU_ProcessCPlaneMsg(IN x_IFX_DECT_IPC_Msg *pxIpcMsg);
#endif

/*! \brief  Process message posted by DECT  Toolkit to CSU Cplane
    \param[in] pxMsg reference to Message based on the plane
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_CSU_ProcessStackMsg(IN x_IFX_DECT_IPC_Msg *pxIPCMsg);

#endif /*__IFX_DECT_MSGROUTER_H__*/

