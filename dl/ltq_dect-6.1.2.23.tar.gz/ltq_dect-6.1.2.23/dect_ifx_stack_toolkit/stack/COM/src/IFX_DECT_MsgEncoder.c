/*
 * =====================================================================================
 *
 *       Filename:  IFX_DECT_MsgEncoder.c
 *
 *    Description:  Contains function defintion for Construction S format messages
 *
 *        Version:  1.0
 *        Created:  Wednesday 29 October 2008 04:23:12  IST
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Voice Team.
 *        Company:  IFIN
 *
 * =====================================================================================
 */
#include "IFX_DECT_Platform.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_StackIf.h"
#include "IFX_DECT_MsgEncoder.h"
#include "IFX_DECT_IEParser.h"
/******************************************************************
*  Function Name    :IFX_DECT_EncodeSetup
*  Description      : Encode CC-Setup Request 
*  Input Values     : handset , instance, iswideband and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
*********************************************************************/
e_IFX_Return IFX_DECT_EncodeSetup(IN uchar8 ucHandset,
                          IN uchar8 ucPPInstance,
                          IN char8 bWidebandCall,
                          IN e_IFX_DECT_CallType eCallType,
													IN uchar8 ucSignal,
                          OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  pxIpcMsg->ucMsgId = FP_CC_SETUP_RQ;
  pxIpcMsg->ucInstance = ucPPInstance;
  pxIpcMsg->ucPara1 = ucHandset;
  switch(eCallType){
    case IFX_DECT_DATA_CALL:
      pxIpcMsg->ucPara2 = eCallType;
      pxIpcMsg->ucPara3 = DUMMY_FILL;
      pxIpcMsg->ucPara4 = DUMMY_FILL;
      break;
    case IFX_DECT_SERVICE_CALL:
	case IFX_DECT_WBS_SERVICE_CALL: 
      pxIpcMsg->ucPara2 = eCallType;
      pxIpcMsg->ucPara3 = DUMMY_FILL;
      pxIpcMsg->ucPara4 = DUMMY_FILL;
      break;
	default:
		//pxIpcMsg->ucPara2 = ALERTING_ON_CONTINUOUS;
		pxIpcMsg->ucPara2 = (ucSignal!=0xFF)?ucSignal:ALERTING_ON_CONTINUOUS;
		if(bWidebandCall == 0){
			if((eCallType ==  IFX_DECT_WBS_EXTERNAL_CALL)||( eCallType ==  IFX_DECT_WBS_INTERNAL_CALL)){
				 pxIpcMsg->ucPara3 = 1;
			}else{
				 pxIpcMsg->ucPara3 = IFX_DECTNG_CODEC_G726_32;
			}
		}else{
		  pxIpcMsg->ucPara3 = 0;
		}
		pxIpcMsg->ucPara4 = eCallType;
	    break;
   }
   return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    :IFX_DECT_EncodeSetupAck
*  Description      : Encode CC-SetupAck Request 
*  Input Values     : handset , instance and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeSetupAck(IN uchar8 ucHandset,
	                                   IN uchar8 ucPPInstance,
                                     OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_CC_SETUP_ACK_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	
	return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    :IFX_DECT_EncodeInfoSuggest
*  Description      : Encode FP_MM_INFO_SUGGEST Request 
*  Input Values     : handset , instance and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeInfoSuggest(IN uchar8 ucHandset,
	                                   IN uchar8 ucPPInstance,
                                     OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_MM_INFO_SUGGEST_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	
	return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    :IFX_DECT_EncodeReject
*  Description      : Encode CC-Reject Request 
*  Input Values     : handset , instance, ucReason and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeReject(IN uchar8 ucHandset,
	                                 IN uchar8 ucPPInstance,
                                   IN uchar8 ucReason,
                                   OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	
	pxIpcMsg->ucMsgId = FP_CC_REJECT_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = ucReason;
	return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeAlert
*  Description      : Encode CC-Alert Request 
*  Input Values     : handset , instance and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeAlert(IN uchar8 ucHandset,
	                                IN uchar8 ucPPInstance,
                                  OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	
	pxIpcMsg->ucMsgId = FP_CC_ALERT_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeSlotRequest
*  Description      : Encode CC-Alert Request 
*  Input Values     : handset , instance and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return  IFX_DECT_EncodeSlotModReq(IN uchar8 ucHandset,
				                            IN uchar8 ucPPInstance,
								                IN boolean bWidebandCall,
                                     OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	
	pxIpcMsg->ucMsgId =  FP_MAC_SLOTTYPE_MOD_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = bWidebandCall;
	return IFX_SUCCESS;
}	
/******************************************************************
*  Function Name    : IFX_DECT_EncodeCallProc
*  Description      : Encode CC-CALL_PROC Request 
*  Input Values     : handset , instance IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeCallProc(IN uchar8 ucHandset,
	                                   IN uchar8 ucPPInstance,
                                     OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	
	pxIpcMsg->ucMsgId = FP_CC_CALL_PROC_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeConnect
*  Description      : Encode CC-Connect Request 
*  Input Values     : handset , instance, iswideband and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeConnect(IN uchar8 ucHandset,
	                                IN uchar8 ucPPInstance,
								    IN boolean bWidebandCall,
                                    OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_CC_CONNECT_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = DUMMY_FILL;

	if (bWidebandCall==1)
		pxIpcMsg->ucPara3 = 3;
	else if( bWidebandCall == 0)
		pxIpcMsg->ucPara3 = 2;
	else
		pxIpcMsg->ucPara3 = DUMMY_FILL;
	   

  return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeConnectAck
*  Description      : Encode CC-ConnectAck Request 
*  Input Values     : handset , instance  and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeConnectAck(IN uchar8 ucHandset,
	                                     IN uchar8 ucPPInstance,
                                       OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_CC_CONNECT_ACK_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = DUMMY_FILL;
	return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeCCInfo
*  Description      : Encode CC-Info Request 
*  Input Values     : handset , instance, isSignal and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeCCInfo(IN uchar8 ucHandset,
	                                 IN uchar8 ucPPInstance,
	                                 IN uchar8 ucSignal,
                                   OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_CC_INFO_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = ucSignal;
	pxIpcMsg->ucPara3 = DUMMY_FILL;
	pxIpcMsg->ucPara4 = DUMMY_FILL;
	return IFX_SUCCESS;
}

/******************************************************************
*  Function Name    : IFX_DECT_EncodeSlotIWUInfo
*  Description      : Encode IWU_Info Request 
*  Input Values     : handset , instance and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeSlotIWUInfo(IN uchar8 ucHandset,
                                        IN uchar8 ucPPInstance,
                                        IN boolean bWidebandCall,
                                        OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{

  pxIpcMsg->ucMsgId = FP_CC_IWU_INFO_RQ;
  pxIpcMsg->ucInstance = ucPPInstance;
  pxIpcMsg->ucPara1 = ucHandset;
  pxIpcMsg->ucPara2 = DUMMY_FILL;

  if (bWidebandCall)
    pxIpcMsg->ucPara3 = 3;
  else
    pxIpcMsg->ucPara3 = 2;
  return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeIWUInfo
*  Description      : Encode IWU_Info Request 
*  Input Values     : handset , instance and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeIWUInfo(IN uchar8 ucHandset,
 	                                  IN uchar8 ucPPInstance,
                                    OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	
	pxIpcMsg->ucMsgId = FP_CC_IWU_INFO_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = DUMMY_FILL;
   return IFX_SUCCESS;

}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeRelease
*  Description      : Encode CC-Release Request 
*  Input Values     : handset , instance,ucReason and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeRelease(IN uchar8 ucHandset,
                                    IN uchar8 ucPPInstance,
				      						          IN uchar8 ucReason,
                                    OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_CC_RELEASE_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = ucReason;
	return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeServiceChangeRq
*  Description      : Encode Service Change Request 
*  Input Values     : handset , instance, iswideband and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeServiceChangeRq(IN uchar8 ucPPInstance,
                                            IN uchar8 ucHandset,
	                                          IN boolean bChangeToWideband,
                                            OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_CC_SERVICE_CHANGE_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara3 = 
					bChangeToWideband?IFX_DECTNG_CODEC_G722_64:IFX_DECTNG_CODEC_G726_32;
	return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeServiceChangeAccept
*  Description      : Encode Service Change Accept Request 
*  Input Values     : handset , instance and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeServiceChangeAccept(IN uchar8 ucHandset,
	                                              IN uchar8 ucPPInstance,
                                                IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_CC_SERVICE_ACCEPT_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeServiceChangeReject
*  Description      : Encode Service change Reject
*  Input Values     : handset , instance and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeServiceChangeReject(IN uchar8 ucHandset,
	                                              IN uchar8 ucPPInstance,
                                                IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_CC_SERVICE_REJECT_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	return IFX_SUCCESS;
}
#if 0
/******************************************************************
*  Function Name    :
*  Description      : Encode CC-Setup Request 
*  Input Values     : handset , instance, islongSlot and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeChngSlotModeReq(IN uchar8 ucHandset,
                                            IN uchar8 ucPPInstance,
												                    IN boolean bLongSlot,
                                            IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  pxIpcMsg->ucMsgId = FP_MAC_SLOTTYPE_MOD_RQ;
  pxIpcMsg->ucInstance = ucPPInstance;
  pxIpcMsg->ucPara1 = ucHandset;
  pxIpcMsg->ucPara2 = (bLongSlot)?1:0;

  return IFX_SUCCESS;
}
#endif
/******************************************************************
*  Function Name    : IFX_DECT_EncodeEnableVoice
*  Description      : Encode Enable Voice
*  Input Values     : handset , instance and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeEnableVoice(IN uchar8 ucHandset,
           	                            IN uchar8 ucPPInstance,
			                                  IN int32 iChannelNo,
                                        OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_MAC_ENABLE_VOICE_EXTERNAL_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = (uchar8)(iChannelNo);
	return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeDisbaleVoice
*  Description      : Encode disable Voice Request 
*  Input Values     : handset , instance  and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeDisableVoice(IN uchar8 ucHandset,
	                                       IN uchar8 ucPPInstance,
	                                       IN int32 iChannelNo,
                                         OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_MAC_DISABLE_VOICE_EXTERNAL_RQ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = (uchar8)(iChannelNo);
	return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    :IFX_DECT_EncodeEnableCipher
*  Description      : Encode Enable Cipher Request 
*  Input Values     : handset , instance, iswideband and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
#ifdef ENABLE_ENCRYPTION
e_IFX_Return IFX_DECT_EncodeEnableCipher(IN uchar8 ucHandset,
                                         IN uchar8 ucPPInstance, 
	                                       IN boolean bCipherOn ,
                                         IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  pxIpcMsg->ucMsgId = FP_MM_CIPHER_ON_RQ;	
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = (1 == bCipherOn)?1:0;
	pxIpcMsg->ucPara3 = pxIpcMsg->ucPara4 = 1;
	return IFX_SUCCESS;
}
#endif
/******************************************************************
*  Function Name    :IFX_DECT_EncodeAuthPTReq
*  Description      : Encode Authentication of PT request
*  Input Values     : handset , instance and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeAuthPTReq(IN uchar8 ucHandset,
                                      IN uchar8 ucPPInstance, 
	                                  IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
    pxIpcMsg->ucMsgId = FP_MM_AUTH_PT_RQ;	
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = DUMMY_FILL;
	pxIpcMsg->ucPara3 = pxIpcMsg->ucPara4 = DUMMY_FILL;
	return IFX_SUCCESS;
}
#ifdef CATIQ_UPLANE 
/******************************************************************
*  Function Name    : IFX_DECT_EncodeDataToStack
*  Description      : Encode Data to DECT Stack
*  Input Values     : iLen , instance and IpcMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeDataToStack(IN int32 iLen,
                                        IN uchar8 ucPPInstance,
                                        IN x_IFX_DECT_IPC_Msg_u *pxUPlaneIpcMsg)
{
   pxUPlaneIpcMsg->ucMsgId = FP_MEDIA_SDU_SND_RQ;
   pxUPlaneIpcMsg->ucInstance = ucPPInstance;
   pxUPlaneIpcMsg->ucPara1 = iLen >> 8;
   pxUPlaneIpcMsg->ucPara2 = iLen & 0xFF;
   return IFX_SUCCESS;
}

/******************************************************************
*  Function Name    : IFX_DECT_EncodeEnableData
*  Description      : This function send the FP_MAC_ENABLE_DATA_RQ to the stack.
*  Input Values     : ucPPInstance - Instance number
                      ucHandsetId - Handset Id
*  Output Values    : none
*  Return Value     : If message is processed IFX_SUCCESS is returned, else
                      IFX_FAILURE is returned.

*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeEnableData(IN uchar8 ucPPInstance,
                                       IN uchar8 ucHandsetId,
                                       OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
   pxIpcMsg->ucMsgId = FP_MAC_ENABLE_DATA_RQ;
   pxIpcMsg->ucInstance = ucPPInstance;
   pxIpcMsg->ucPara1 = ucHandsetId;
   pxIpcMsg->ucPara2 = 0;
   pxIpcMsg->ucPara3 = 0;
   pxIpcMsg->ucPara4 = 0;
   return IFX_SUCCESS;
}
#endif
/***************************************************************************
  * Description       :  A function used to fetch Handler (address) to the
                         first IE in the message.
  * Input Value       :  Pointer to the message structure
  * Output Value      :  Handler to the first IE in the S Format message
  * Return Value      :  enum value of I
  * Notes             :  The message(structure) pointer is taken as input and  
                         the address of "acData"(structure member) is returned
  ****************************************************************************/

uint32 IFX_DECT_IE_GetIEHandler(x_IFX_DECT_IPC_Msg *pxIPCMsg) 
{
    if(pxIPCMsg!=0)
    {
      return ((uint32)&pxIPCMsg->acData[0]) + sizeof( struct HLI_Header ) + 2;      // return msghdl
    }
    else
    {
      return IFX_FAILURE;
    }
}
/***************************************************************************
  * Description       :  A function used to fetch Handler (address) to the
                         first IE in the message.
  * Input Value       :  Pointer to the message structure
  * Output Value      :  Handler to the first IE in the S Format message
  * Return Value      :  enum value of I
  * Notes             :  The message(structure) pointer is taken as input and  
                         the address of "acData"(structure member) is returned
  ****************************************************************************/

e_IFX_Return IFX_DECT_IE_Remove(uint32 uiIEHdl,e_IFX_DECT_IE eIEType) 
{
  return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    : IFX_DECT_EncodeFacility
*  Description      : Encode Facility Message
*  Input Values     : handset , instance and IPCMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeFacility(IN uchar8 ucHandset,
           	                         IN uchar8 ucPPInstance,
                                     OUT x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
	pxIpcMsg->ucMsgId = FP_CLSS_FACILITY_RQ ;
	pxIpcMsg->ucInstance = ucPPInstance;
	pxIpcMsg->ucPara1 = ucHandset;
	pxIpcMsg->ucPara2 = DUMMY_FILL;
	return IFX_SUCCESS;
}

/******************************************************************
*  Function Name    : IFX_DECT_EncodeQTMsg
*  Description      : Encode QT Message
*  Input Values     : acCap, IPCMsg
*  Output Values    : IpcMesg
*  Return Value     : none
*  Notes            : none
********************************************************************/
e_IFX_Return IFX_DECT_EncodeQTMsg(IN e_IFX_DECT_QT_MESSAGE_ID eQtId,
                                  IN uchar8 *pcBuff,
								  IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
  pxIpcMsg->ucMsgId = FP_ME_QT_SET_RQ;
  pxIpcMsg->ucPara2 = eQtId;
  pxIpcMsg->acData[0]=5;
  memcpy(&pxIpcMsg->acData[1],pcBuff,5);
	return IFX_SUCCESS;
}
