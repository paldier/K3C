/**************************************************************************

**   FILE NAME     : IFX_DECT_MsgRouter.c
**   PROJECT       : DECT
**   MODULES       : DECT Team
**   SRC VERSION   : V2.0 
**   DATE          : 15-10-2008
**   AUTHOR        : Voice Team
**   DESCRIPTION   : This file contains DECT Init functions. 
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines for VSS ,  DIS of Transaction User.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "IFX_DECT_Platform.h"
#include "IFX_DECT_StackIf.h"
//#include "IFX_DECT_LAU_Info.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_MsgEncoder.h"
#include "IFX_DECT_MsgRouter.h"
#include "IFX_DECT_Repeater.h"
#include "IFX_DECT_RU.h"



#ifdef ULE_SUPPORT
#include "IFX_DECT_ULE_Global.h"
#endif

#define FIFO_PERM 0644

#define DECT_STACK_FIFO "/tmp/DectStackFifo"

#ifdef CATIQ_UPLANE
#define DECT_STACK_FIFO_U "/tmp/DectStackFifo_u"
#endif 

int iDectCplaneFifoFd;

#ifdef CATIQ_UPLANE
int iDectUplaneFifoFd;
#endif

#define veNemoState vxGlobalInfo.xMU.veNemoState 
#define vuiNemoTimer vxGlobalInfo.xMU.vuiNemoTimer

x_IFX_DECT_IPC_Msg vxApp2StackMsg;
x_IFX_DECT_IPC_Msg vxStack2AppMsg;
x_IFX_DECT_IPC_Msg_u uplaneMsgBuf; 
/******************************************************************
 *  Function Name    : IFX_DECT_MsgRt_Init
 *  Description      : This function initilizes Message router
 *                     
 *                     
 *  Input Values     : 
 *                   : 
 *                   : 
 *  Output Values    : None
 *  Return Value     : 
 *                   : 
 *  Notes            :
 ******************************************************************/
e_IFX_Return IFX_DECT_MsgRt_Init(void)
{
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entered IFX_DECT_MsgRt_Init");
  if(vxGlobalInfo.viDECTStackMode == IFX_DECT_ASYNC_MODE){
     int iRet = 0;
    if (access(DECT_STACK_FIFO, F_OK) == -1)
    {
      iRet = mkfifo(DECT_STACK_FIFO, FIFO_PERM);
      if (iRet < 0)
      {
        IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR ,
           "make DECT_STACK_FIFO failed!!");
        return IFX_FAILURE;
      }
    }
    iDectCplaneFifoFd = open(DECT_STACK_FIFO,O_RDWR);
    if(iDectCplaneFifoFd < 0)
    {
        IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR ,
                "open DECT_STACK_FIFO failed!!\n");
      return IFX_FAILURE;
    }
#ifdef CATIQ_UPLANE
    if (access(DECT_STACK_FIFO_U, F_OK) == -1)
    {
      iRet = mkfifo(DECT_STACK_FIFO_U, FIFO_PERM);
      if (iRet < 0)
      {
        IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR ,
                "make DECT_STACK_FIFO U failed!!\n");
        return IFX_FAILURE;
      }
    }
    iDectUplaneFifoFd = open(DECT_STACK_FIFO_U,O_RDWR);
    if(iDectUplaneFifoFd < 0)
    {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR ,
                "open DECT_STACK_FIFO U failed!!\n");
      return IFX_FAILURE;
    
    }
#endif
  }
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
          " Returning from MsgRouter Init");
  return IFX_SUCCESS;
}
/******************************************************************
 *  Function Name    : IFX_DECT_MsgRt_PostToStack
 *  Description      : This function writes to the Stack Fifo in 
 *                     Async mode and in sync mode calls the api
 *                     
 *  Input Values     : 
 *                   : data buffer to be written
 *                   : size of data to be written
 *  Output Values    : None
 *  Return Value     : Size of the actual data written, -1 if error
 *                   : 
 *  Notes            :
 ******************************************************************/
extern int IFX_DECT_ProcessPendingQTasks();
extern void Serve_Mail_CP(x_IFX_DECT_IPC_Msg*);

e_IFX_Return IFX_DECT_MsgRt_PostToStack(IN int32 iPlane,
                                        IN void *pxMsg)
{
#if 0
   if(veNemoState == IFX_DECT_MU_NEMO_ACTIVE){
	  	veNemoState = IFX_DECT_MU_NEMO_PENDING;
      IFX_DECT_MU_NemoStop();
	  	veNemoState = IFX_DECT_MU_NEMO_IDLE;
      IFX_DECT_StartTimer(IFX_DECT_MU_NEMO_IDLE_TIME,NULL,0,
			                    IFX_DECT_MU_NemoIdleTimerFunc,
								&vuiNemoTimer);
   }
#endif

   if((veNemoState == IFX_DECT_MU_NEMO_ACTIVE) || (veNemoState == IFX_DECT_MU_NEMO_PENDING)){
	  veNemoState = IFX_DECT_MU_NEMO_STOP_PENDING;
      IFX_DECT_MU_NemoStop();
	  veNemoState = IFX_DECT_MU_NEMO_IDLE;
	  if(vuiNemoTimer == 0)
	  {
      	IFX_DECT_StartTimer(IFX_DECT_MU_NEMO_IDLE_TIME,NULL,0,IFX_DECT_MU_NemoIdleTimerFunc,&vuiNemoTimer);
	  }
   }

  if(iPlane == IFX_IPC_DECT_C_PLANE){
    x_IFX_DECT_IPC_Msg *pxIpcMsg = (x_IFX_DECT_IPC_Msg *)pxMsg;

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT, 
                  "\nMessage ID= ",pxIpcMsg->ucMsgId);
    if(vxGlobalInfo.viDECTStackMode == IFX_DECT_ASYNC_MODE){
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
               "Posting to DECT Stack Fifo");
   	  write(iDectCplaneFifoFd, (char *)pxIpcMsg,
                  sizeof(x_IFX_DECT_IPC_Msg));
	  if((pxIpcMsg->ucMsgId == FP_CC_SETUP_RQ) || (pxIpcMsg->ucMsgId == FP_CC_RELEASE_RQ) || (pxIpcMsg->ucMsgId ==FP_CC_REJECT_RQ)){
            IFX_DECT_MU_SetCipherStatus(pxIpcMsg->ucPara1,0); 
      }
		 memset(pxIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
      return IFX_SUCCESS;
    }else{
      IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
               "Calling Serve_Mail_CP");
      Serve_Mail_CP(pxIpcMsg);
      IFX_DECT_ProcessPendingQTasks();
      return IFX_SUCCESS;
    }
  }else{
#if defined(CATIQ_UPLANE) || defined(ULE_SUPPORT)
     x_IFX_DECT_IPC_Msg_u *pxIpcMsg = (x_IFX_DECT_IPC_Msg_u *)pxMsg;
     if(vxGlobalInfo.viDECTStackMode == IFX_DECT_ASYNC_MODE){
   	    write(iDectUplaneFifoFd, (char *)pxIpcMsg,
                  sizeof(x_IFX_DECT_IPC_Msg_u));
        return IFX_SUCCESS;
    }else{
        #ifdef CATIQ_UPLANE
        if(pxIpcMsg->ucMsgId== FP_MEDIA_SDU_SND_RQ)
        {     
          static FPTR fptr=0;
          uint16 len=(pxIpcMsg->ucPara1<<8)+pxIpcMsg->ucPara2;
          int rc;        
          IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                   "MEDIA_SDU_SND_RQ, len",len);
          if(len >0)
          {
            // call with len 0 to get current ptr
            rc=LU10SduTxGetPtr (pxIpcMsg->ucInstance,&fptr);
            if(rc>=0)
            {
              // Should add len check here...
              memcpy(fptr,pxIpcMsg->acData,len);
          
              rc=LU10SduTx (pxIpcMsg->ucInstance, len,&fptr);
              if(rc < 0)
              {
                 // Error: failed to send data
                 IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT,
                          "SDUTx failed:",rc);
              }
              else
              {
                IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                         "SDUTx OK");
              }
            }
            else
            {
              // failed to get a tx buffer
              IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT,
                       "failed to get SDU TX buffer, rc=",rc);
            }
          }
        }
        #endif
        #ifdef ULE_SUPPORT
        #ifdef CATIQ_UPLANE
        else
        #endif
        if(pxIpcMsg->ucMsgId == FP_ULE_MEDIA_SDU_SND_RQ)
        {     
          uint16 len = (pxIpcMsg->ucPara1 << 8) + pxIpcMsg->ucPara2;

          IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                   "ULE_MEDIA_SDU_SND_RQ, len",len);
          
          if (ULE_LU10SduTx(pxIpcMsg->ucPara4, len, pxIpcMsg->acData, 1)) {
             IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                      "ULE SDU TX OK");
          } else {
             IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                      "ULE SDU TX Failed");
          }
        } else if (pxIpcMsg->ucMsgId == FP_ULE_MEDIA_SDU_STOP_RQ) {
          IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "ULE_MEDIA_SDU_STOP_RQ");
          ULE_LU10SduTxStop(pxIpcMsg->ucPara4);
        }
        #endif
        else
        {
          // Dont know this message yet
           IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT,
                    "Unknown message 0x%02x\n",pxIpcMsg->ucMsgId);
        }

      return IFX_SUCCESS;
    }  
#endif 
  }
  return IFX_SUCCESS;
}
/******************************************************************
 *  Function Name    : IFX_DECT_MsgRt_ReadAppMsg
 *  Description      : This function reads the contents from the 
 *  				      : Stack fifo -- shuld be called by the stack
 *                     is called only in async mode
 *  Input Values     : 
 *                   : buffer to be read in
 *                   : size of data to be read
 *  Output Values    : None
 *  Return Value     : Size of the actual data read,-1 if error,
 *                   : 0 if there is no furthur data to be read .
 *  Notes            :
 ******************************************************************/
e_IFX_Return IFX_DECT_MsgRt_ReadAppMsg(IN int32 iPlane,
                              IN uchar8 *pcBuf,int32 iSize)
{
   if(iPlane == IFX_IPC_DECT_C_PLANE){
   	return read(iDectCplaneFifoFd, pcBuf, iSize);
   }else{
#ifdef CATIQ_UPLANE
   	return read(iDectUplaneFifoFd, pcBuf, iSize);
#endif
   }
  return IFX_SUCCESS;
}
/*******************************************************************************
 *  Function Name   : IFX_DECT_MsgRt_ProcessStackMessage 
 *  Description     : This function processes messages received from DECT stack. 
 *	                  DECT messages are identified as two types in this function.
 *	                  Messages releated to PP (handset) rights and messages 
 *	                  related call control. PP rights (mainly access rights) 
 *	                  messages are processed in this function and related info is 
 *                    updated in this function itself. Call control messages 
 *	                  passed to DECT FSM and depending on result, messages are 
 *	                  sent back to DECT stack.
 *  Input Values    : pxIpcMsg - Pointer to DECT IPC message struct 
 *  Output Values	  : none 
 *  Return Value    : If message is processed IFX_SUCCESS is returned, else 
 *	                  IFX_FAILURE is returned.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_DECT_MsgRt_ProcessStackMessage(IN int32 iPlane,
                                                IN void* pxMsg)
{
   e_IFX_Return eRet = IFX_SUCCESS;
   uint32 uiModuleOwner=0;
   IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           " Hello,Message Received from Stack");
 
   if(iPlane == IFX_IPC_DECT_U_PLANE){
    x_IFX_DECT_IPC_Msg_u *pxIpcMsg = (x_IFX_DECT_IPC_Msg_u *)pxMsg;

#ifdef ULE_SUPPORT
	if((pxIpcMsg->ucPara4 >= IFX_DECT_ULE_OFFSET) && (pxIpcMsg->ucPara4 < (IFX_DECT_ULE_OFFSET + IFX_DECT_MAX_ULE_DEVICES)))
	{
   	 	eRet = IFX_DECT_ULE_ProcessUPlaneMsg(pxIpcMsg);
		return eRet;
 	}
#endif

#ifdef CATIQ_UPLANE
     eRet = IFX_DECT_DPSU_ProcessUPlaneMsg(pxIpcMsg);
#endif
   }else{
    x_IFX_DECT_IPC_Msg *pxIpcMsg = (x_IFX_DECT_IPC_Msg *)pxMsg;
     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT, 
                  "\nMessage ID= ",pxIpcMsg->ucMsgId);
	 
#ifdef CONFIG_REPEATER_SUPPORT

if((pxIpcMsg->ucPara1 >= IFX_DECT_REPEATERS_OFFSET) && 
	(pxIpcMsg->ucPara1 < (IFX_DECT_REPEATERS_OFFSET + (IFX_DECT_MAX_REPEATERS*IFX_DECT_MAX_INSTANCES_PER_REPEATERS))))
{
	 eRet = IFX_DECT_Repeater_ProcessCPlaneMsg(pxIpcMsg);
	return eRet;
}

#endif

#ifdef ULE_SUPPORT
	if((pxIpcMsg->ucPara1 >= IFX_DECT_ULE_OFFSET) && (pxIpcMsg->ucPara1 < (IFX_DECT_ULE_OFFSET + IFX_DECT_MAX_ULE_DEVICES)))
	{
    	 eRet = IFX_DECT_ULE_ProcessCPlaneMsg(pxIpcMsg);
		return eRet;
 	}
#endif
     if((pxIpcMsg->ucPara1 < 1 )|| (pxIpcMsg->ucPara1 > 6 )){
        
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT, 
                  "\nIn valid Handset ID= ",pxIpcMsg->ucPara1);
        return IFX_FAILURE;
     }
     switch(pxIpcMsg->ucMsgId){
     case FP_PORTABLE_REGISTERED_IN_MM:
     case FP_PORTABLE_ATTACHED_IN_MM:
     case FP_ACCESS_RIGHTS_TERMINATE_CFM_MM:
     case FP_PROP_INFO_IN_MM:
     case FP_MODEM_BOOT_IND:  
	 case FP_MAC_NOEMO_IN_ME:
         IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  " Calling MU Process Stack Message");
         eRet = IFX_DECT_MU_ProcessStackMsg(pxIpcMsg);
           
         break;
         
     case FP_SETUP_IN_CC:
            IFX_DECT_MU_SetCipherStatus(pxIpcMsg->ucPara1,0); 
	    vxGlobalInfo.xMU.vxMUInfo[pxIpcMsg->ucPara1-1].uiModuleOwner = 0;
#ifdef CATIQ_UPLANE
         if(pxIpcMsg->ucPara2 == BS_DATA_CALL) { //137){
            eRet = IFX_DECT_DPSU_ProcessCPlaneMsg(pxIpcMsg);
            break;
         }else
#endif
         {
           eRet = IFX_DECT_CSU_ProcessStackMsg(pxIpcMsg);
         }
         if( eRet == IFX_FAILURE){
           eRet = IFX_DECT_ESU_ProcessStackMsg(pxIpcMsg);
         }
         break;
         
      case FP_IWU_INFO_IN_CC:
 #ifdef CAT_IQ2_0
             /* TODO: Move IFX_DECT_LAU_CheckPD function to MU */

         uiModuleOwner = IFX_DECT_MU_GetModuleOwner(pxIpcMsg->ucPara1);
#if 1 /*BASIC SERVICE changes for LIST_ACCESS*/
			 if(pxIpcMsg->ucMsgId==FP_IWU_INFO_IN_CC){
			   if(IFX_DECT_LAU_CheckPD(pxIpcMsg)==IFX_SUCCESS){
				   IFX_DECT_MU_SetModuleOwner(pxIpcMsg->ucPara1,
				                            IFX_DECT_MU_ADD_OWNER,
										    IFX_DECT_LAU_ID);
           eRet = IFX_DECT_LAU_ProcessStackMsg(pxIpcMsg);
				 return IFX_SUCCESS;
			   }
			 }
#else
			 if(uiModuleOwner & IFX_DECT_LAU_ID){
			   eRet = IFX_DECT_LAU_ProcessStackMsg(pxIpcMsg);
         break;
       }
#endif
#endif
      case FP_ALERT_IN_CC:
      case FP_CONNECT_IN_CC:
      case FP_INFO_IN_CC:
      case FP_RELEASE_IN_CC:
           if(pxIpcMsg->ucMsgId == FP_RELEASE_IN_CC){
            IFX_DECT_MU_SetCipherStatus(pxIpcMsg->ucPara1,0); 
           }
           uiModuleOwner = IFX_DECT_MU_GetModuleOwner(pxIpcMsg->ucPara1);
		   
           IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                    "ModuleOwner is\n",uiModuleOwner);
 #ifdef CAT_IQ2_0  
             if((pxIpcMsg->ucMsgId==FP_RELEASE_IN_CC)&&
			    (uiModuleOwner & IFX_DECT_LAU_ID)){
			   eRet = IFX_DECT_LAU_ProcessStackMsg(pxIpcMsg);
			   IFX_DECT_MU_SetModuleOwner(pxIpcMsg->ucPara1,
			            IFX_DECT_MU_REMOVE_OWNER,IFX_DECT_LAU_ID);
			 }
#endif
#ifdef CATIQ_UPLANE
             if(uiModuleOwner & IFX_DECT_DPSU_ID){
               eRet = IFX_DECT_DPSU_ProcessCPlaneMsg(pxIpcMsg);
               break;
             } 
#endif
#ifdef HCU
			 if((pxIpcMsg->ucMsgId==FP_INFO_IN_CC)&&(uiModuleOwner & IFX_DECT_HCU_ID)){
				 return IFX_DECT_HCU_HandleKeyCode(pxIpcMsg);
			 }
#endif
             if(uiModuleOwner & IFX_DECT_CSU_ID){
               eRet = IFX_DECT_CSU_ProcessStackMsg(pxIpcMsg);
             }
			       if( uiModuleOwner & IFX_DECT_MU_ID){
				         eRet = IFX_DECT_MU_ProcessStackMsg(pxIpcMsg);
				     }
#ifdef MESSAGE_SUPPORT
			       if( uiModuleOwner & IFX_DECT_SMSU_ID){
               eRet = IFX_DECT_SMSU_ProcessStackMsg(pxIpcMsg);
             }
#endif
			      if( uiModuleOwner & IFX_DECT_ESU_ID){
			 
               eRet = IFX_DECT_ESU_ProcessStackMsg(pxIpcMsg);
             }
         break;
            
      case FP_SLOTTYPE_MOD_IN_MAC:
      case FP_SERVICE_CHANGE_IN_CC:
      case FP_SERVICE_ACCEPT_IN_CC:
      case FP_SERVICE_REJECT_IN_CC:
      case FP_CIPHER_ON_CFM_MM:
      case FP_CIPHER_OFF_CFM_MM:
      case FP_AUTHENTICATE_PT_CFM_MM:
         uiModuleOwner = IFX_DECT_MU_GetModuleOwner(pxIpcMsg->ucPara1);
         if((pxIpcMsg->ucMsgId == FP_CIPHER_ON_CFM_MM) ||(pxIpcMsg->ucMsgId==FP_CIPHER_OFF_CFM_MM)){
           IFX_DECT_MU_SetCipherStatus(pxIpcMsg->ucPara1,((pxIpcMsg->ucPara2 ==1)?IFX_TRUE:IFX_FALSE)); 
           IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Cipher confirm arrived");
         }
//#ifndef SBB
         if( uiModuleOwner & IFX_DECT_MU_ID){
         	eRet = IFX_DECT_MU_ProcessStackMsg(pxIpcMsg);
         }
//endif
         if( uiModuleOwner & IFX_DECT_CSU_ID){
           eRet = IFX_DECT_CSU_ProcessStackMsg(pxIpcMsg);
         }
         if( uiModuleOwner & IFX_DECT_DPSU_ID){
           eRet = IFX_DECT_DPSU_ProcessCPlaneMsg(pxIpcMsg);
         }
			   if((eRet == IFX_FAILURE) && (uiModuleOwner & IFX_DECT_LAU_ID)){
		        eRet = IFX_DECT_USU_ProcessStkMesg(pxIpcMsg);
          }
         break;
         
	  case FP_FACILITY_IN_CLSS:
     case FP_DEBUG_INFO_IND:
#ifndef LTQ_RAW_DPSU
       if(pxIpcMsg->ucMsgId==FP_FACILITY_IN_CLSS){
         if(IFX_DECT_DPSU_CheckPD(pxIpcMsg)==IFX_SUCCESS){
#if 0	
           IFX_DECT_MU_SetModuleOwner(pxIpcMsg->ucPara1,
                                    IFX_DECT_MU_ADD_OWNER,
                        IFX_DECT_DPSU_ID);
#endif
           eRet = IFX_DECT_DPSU_ProcessCPlaneMsg(pxIpcMsg);
           return IFX_SUCCESS;
         }
       }
#endif
		  eRet = IFX_DECT_USU_ProcessStkMesg(pxIpcMsg);
		  break;
        
      default:
        IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Does not belong to any of the Toolkit modules");
        //eRet = IFX_DECT_ProcessStackMessage((unsigned char*)pxIpcMsg,sizeof(x_IFX_DECT_IPC_Msg));
        break;
     } 
   }

   IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "Returning from MsgRt ProcessStack Message");
   return IFX_SUCCESS;
}
