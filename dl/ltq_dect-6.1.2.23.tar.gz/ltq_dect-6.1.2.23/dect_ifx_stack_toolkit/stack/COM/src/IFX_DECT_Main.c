/**************************************************************************
**   FILE NAME     : IFX_DECT_Main.c
**   PROJECT       : DECT
**   MODULES       : DECT Team
**   SRC VERSION   : V2.0 
**   DATE          : 15-10-2008
**   AUTHOR        : Voice Team
**   DESCRIPTION   : This file contains DECT Init functions. 
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines for VSS ,  DIS of Transaction User.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "IFX_DECT_Platform.h"
#include "IFX_DECT_StackIf.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_MsgEncoder.h"
#include "IFX_DECT_MU_Fsm.h"
#include "IFX_DECT_MsgRouter.h"
#include "IFX_DECT_Stack.h"

#define IFX_DECT_NORMAL_ENCRYPTION 0x00000001
#define IFX_DECT_EARLY_ENCRYPTION  0x00000002
#define IFX_DECT_REKEYING  0x00000004
#define IFX_DECT_ULE_ENABLE   0x00000008
#define IFX_DECT_REPEATER_SUPPORT_ENABLE  0x00000010
#define IFX_DECT_JAPAN_SUPPORT 0x00000020
#define IFX_DECT_USE_REAL_CN 0x00000040

/* Global variables*/
x_IFX_DECT_GlobalInfo vxGlobalInfo;
uchar8 vcDECTTKModId;
char8 vcMaxHandset;
uint32 uiDECTEnhancedFeatures;

#ifdef xxULE_SUPPORT
extern void IFX_DECT_ULE_Init1(void);
#endif
extern int dect_drv_fd;
extern int timer_fd;
extern void IFX_CloseTimerDriver(void);
extern int DectDrvIfShut(void);
uint32 vuiDectThreadExit;
extern e_IFX_Return IFX_DECT_DIAG_RfCtrl();
uint32 IFX_DECT_GetUserFeatures(void);
extern void TestAppWriteToHmac(BYTE procid, BYTE msgnr
                  ,BYTE param1, BYTE param2, BYTE param3, BYTE param4
                  ,BYTE param5, BYTE param6, FPTR pdata, BYTE inc);

int32 IFX_DBGA_STACK_String(char8 *pcString,int32 iLevel)
{
	IFX_DBGA(vcDECTTKModId,iLevel,IFX_DBG_STR,pcString);
	return 0;
}

int32 IFX_DBGA_STACK(char8 *pcString,int32 iValue,int32 iLevel)
{
	IFX_DBGA(vcDECTTKModId,iLevel,IFX_DBG_INT,pcString,iValue);
	return 0;
}

void IFX_DBG_Printf(const char8 *format, ...)
{
	va_list ap;
	
	va_start(ap, format);
	#ifdef LINUX
	vprintf(format, ap);
	#endif
	#ifdef SUPERTASK
	vprintf(format, ap);
	#endif
	va_end(ap);	  
}

uint32 vuiStackDbgFlag;
e_IFX_Return IFX_DBGA_SetStackModuleDebugID(uint32 uiDebugFlag)
{
	/*
		Eg. get the value from user and set flag accordingly
	*/
	vuiStackDbgFlag = uiDebugFlag;
	return IFX_SUCCESS;

}
uint32 IFX_DBGA_GetStackModuleDebugID(void)
{
	/*
		If set function is not provided then for debug purpose hardcode as below for required module debug
	*/

	/*Thse are done in function IFX_DECT_DbgInit() based on DBG level*/
	#if 0
	// vuiStackDbgFlag = 0;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_CP_PRIMITIVE;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_APP_PRIMITIVE;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_CC_PRIMITIVE;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_MM_PRIMITIVE;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_LCE_PRIMITIVE;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_LAP_PRIMITIVE;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_LC_PRIMITIVE;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_LB_PRIMITIVE;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_ULE_PRIMITIVE;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_ME_PRIMITIVE;

	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_CP_DATA;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_MM_DATA;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_MM_AC;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_MM_KEY;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_LC_DATA;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_ULE_RX_TX_DATA;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_ME_DATA;

	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_UPLANE;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_REPEATER;
	// vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_USER;
	#endif

	return vuiStackDbgFlag;
}

/******************************************************************
*  Function Name  :  IFX_DECT_CreateAllMutex
*  Description    :  this function is responsible for creating all
*                    the mutex used to achive thread safe.
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes          : 
*********************************************************************/
int32 IFX_DECT_CreateAllMutex(IN x_IFX_DECT_GlobalInfo *pxGlobalInfo)
{
  static char8 cOneTimeFlag =1;
  if(cOneTimeFlag){
    cOneTimeFlag =0;        
    
    if( IFX_DECT_LockCreate(&vxGlobalInfo.xCCApiLock) != IFX_SUCCESS){
       IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Creating CSU Mutex Fail ");
	    return IFX_FAILURE;
    }
   
   if( IFX_DECT_LockCreate(&vxGlobalInfo.xSockDescLock) != IFX_SUCCESS){
        IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Creating Fd Set Mutex Fail ");
	     return IFX_FAILURE;
    }
   
   if( IFX_DECT_LockCreate(&vxGlobalInfo.xSMSApiLock) != IFX_SUCCESS){
       IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Creating SMSU Mutex Fail ");
	   return IFX_FAILURE;
    }
    
    if( IFX_DECT_LockCreate(&vxGlobalInfo.xDPSApiLock) != IFX_SUCCESS){
       IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Creating DPSU Mutex Fail ");
	   return IFX_FAILURE;
    }
    
    if( IFX_DECT_LockCreate(&vxGlobalInfo.xESUApiLock) != IFX_SUCCESS){
       IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Creating ESU Mutex Fail ");
	   return IFX_FAILURE;
    } 

    if( IFX_DECT_LockCreate(&vxGlobalInfo.xMUApiLock) != IFX_SUCCESS){
       IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Creating MU Mutex Fail ");
	   return IFX_FAILURE;
    }

    if( IFX_DECT_LockCreate(&vxGlobalInfo.xDIAGApiLock) != IFX_SUCCESS){
       IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Creating DIAG Mutex Fail ");
	   return IFX_FAILURE;
    }
  }
  return IFX_SUCCESS;
}
/******************************************************************
*  Function Name  :  IFX_DECT_DbgInit
*  Description    :  this function is responsible for initializing
*                    the debug module
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes          : 
*********************************************************************/
void
IFX_DECT_DbgInit(int8 iDbgType, int8 iDbgLvl)
{
  static uchar8 cFlag=1;
   char8 cRet=0;
  if(cFlag){ 
    IFX_DBG_Init(IFX_IPC_APP_NAME_DECT_TK,iDbgType,
		          iDbgLvl,&vcDECTTKModId, &cRet);
     cFlag =0;
  }else {
    IFX_DBG_Set(IFX_IPC_APP_NAME_DECT_TK,vcDECTTKModId,
                iDbgType,iDbgLvl);
  }



  	/*
		If set function is not provided then for debug purpose hardcode as below for required module debug
	*/
	#if 1
	switch (iDbgLvl)
	{

		case IFX_DBG_LVL_NONE :
			vuiStackDbgFlag = 0;
			break;
			
		case IFX_DBG_LVL_HIGH :
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_UPLANE;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_USER;
			
		case IFX_DBG_LVL_NORMAL :
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_CP_DATA;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_MM_DATA;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_MM_AC;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_MM_KEY;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_LC_DATA;
	 		vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_ULE_RX_TX_DATA;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_ME_DATA;
	
		case IFX_DBG_LVL_LOW :
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_CP_PRIMITIVE;
	 		vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_APP_PRIMITIVE;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_CC_PRIMITIVE;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_MM_PRIMITIVE;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_LCE_PRIMITIVE;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_LAP_PRIMITIVE;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_LC_PRIMITIVE;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_LB_PRIMITIVE;
	 		vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_ULE_PRIMITIVE;
			vuiStackDbgFlag |= IFX_DECT_STACK_DEBUG_ID_ME_PRIMITIVE;
			break;					
			
	}/*End of switch*/
		 			
	#endif
}
extern e_IFX_Return IFX_DECT_StackEntry(
                            IN uchar8 *paucRfpi,
                            IN x_IFX_DECT_TransmitPowerParam *pxTpcPrams,
                            IN x_IFX_DECT_BMCRegParams *pxBMCPrams,
                            IN x_IFX_DECT_OscTrimVal *pxOscTrimVal,
                            IN uint16 *punGaussianVal,
                            IN x_IFX_DECT_FTRegList* pxPPSubInfo,
                            IN uchar8 ucNoOfSubscribedPPs,
                            IN uchar8 ucCodec_Pri1,
                            IN uchar8 ucCodec_Pri2,
                            IN uchar8 ucNoEmo_State,
#ifdef __PIN_CODE__
                            IN char* pszPinCode
#endif
                            );
/******************************************************************
*  Function Name    :  IFX_DECT_GetDeafultFTCap
*  Description      :  This is the function Sets default FT capabilities
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  void
*  Notes            :
*********************************************************************/
e_IFX_Return IFX_DECT_GetDeafultFTCap(x_IFX_DECT_FTCap *pxFTCap)
{
   /*
      Get Qt messages - Q3, Q4, Q12
      Ref: ETS 300175-3 V2.5.1:7.2.3 / ETS 300175-5 V2.5.1:Annex F
    */

   /*
      Q3: Fixed part capabilities

      [0]: 0011 x000b
      	  a08..a11: 3 : QH
      	  a12 	 : x : Extended fixed part capabilities part 1 available
      	  a13 	 : 0 : Double duplex bearer connections
      	  a14 	 : 0 : Reserved
      	  a15 	 : 0 : Double slot
      [1]: 0101 0001b
      	  a16 	 : 0 : Half slot
      	  a17 	 : 1 : Full slot
      	  a18 	 : 0 : Frequency control
      	  a19 	 : 1 : Page repetition
      	  a20 	 : 0 : C/O setup on dummy allowed
      	  a21 	 : 0 : C/L uplink
      	  a22 	 : 0 : C/L downlink
      	  a23 	 : 1 : Basic A-field setup
      [2]: x001 0000b
      	  a24 	 : x : Advanced A-field setup
      	  a25 	 : 0 : B-field setup
      	  a26 	 : 0 : CF messages
      	  a27 	 : 1 : IN_minimum_delay
      	  a28 	 : 0 : IN_normal_delay
      	  a29 	 : 0 : IP_error_detection
      	  a30 	 : 0 : IP_error_correction
      	  a31 	 : 0 : Multibearer connections
      [3]: 1100 1110b
      	  a32 	 : 1 : ADPCM/G.726 voice service
      	  a33 	 : 1 : GAP basic speech
      	  a34 	 : 0 : Non-voice circuit switched service
      	  a35 	 : 0 : Non-voice packet switched service
      	  a36 	 : 1 : Standard authentication required
      	  a37 	 : 1 : Standard ciphering supported
      	  a38 	 : 1 : Location registration supported
      	  a39 	 : 0 : SIM service available
      [4]: 0000 0000b
      	  a40 	 : 0 : Non-static Fixed Part
      	  a41 	 : 0 : CISS services available
      	  a42 	 : 0 : CLMS services available
      	  a43 	 : 0 : COMS services available
      	  a44 	 : 0 : Access right requests supported
      	  a45 	 : 0 : External handover supported
      	  a46 	 : 0 : Connection handover supported
      	  a47 	 : 0 : Reserved

      a30: This bit is set to 1 by ULE feature setting
    */
   pxFTCap->aucFixedPartCap[0] = 0x30
                                 #if defined(DECT_NG)
                                 | 0x08 // a12
                                 #endif
                                 ;

   pxFTCap->aucFixedPartCap[1] = 0x51;

   pxFTCap->aucFixedPartCap[2] = 0x10
                                 #ifdef DECT_NG_AS
                                 | 0x80 // a24
                                 #endif
                                 ;

   #ifdef NO_CIPHER
   #error
   pxFTCap->aucFixedPartCap[3] = 0xCA; 
   #else
   pxFTCap->aucFixedPartCap[3] = 0xCE;
   #endif

   pxFTCap->aucFixedPartCap[4] = 0x00;

   /*
      Q4: Extended fixed part capabilities

      [0]: 0100 1100b
           a08..a11: 4 : QH
           a12..a13: 3 : Number of CRFP (00: 1 CRFP allowed, 01:2 CRFP, 10: 3 CRFP, 11:NO CRFP)
           a14     : 0 : CRFP encryption support
           a15     : 0 : Number of REP
      [1]: 0001 0001b
           a16     : 0 : Number of REP (a15.a16 = 00: NO REP, 01:1 REP, 10:2 REP, 11:3 REP)
           a17     : 0 : REP interlacing support
           a18..a19: 1 : Synchronization field option
           a20     : 0 : Reserved
           a21     : 0 : MAC suspend and resume
           a22     : 0 : MAC service Ipq support
           a23     : 1 : Extended fixed part capabilities part 2 available
      [2]: 000x 0000b
           a24     : 0 : Reserved
           a25     : 0 : F-MMS interworking profile supported
           a26     : 0 : Basic ODAP supported
           a27     : x : Generic Media Encapsulation transport (DPRS) supported
           a28     : 0 : IP roaming unrestricted supported
           a29     : 0 : Ethernet
           a30     : 0 : Token Ring
           a31     : 0 : IP
      [3]: 0000 0000b
           a32     : 0 : PPP
           a33     : 0 : V.24
           a34     : 0 : Reserved
           a35     : 0 : Reserved
           a36     : 0 : RAP part 1 profile
           a37     : 0 : ISDN intermediate system
           a38     : 0 : Synchronization to GPS achived
           a39     : 0 : Location registration with TPUI allowed
      [4]: 0000 0x00b
           a40     : 0 : Emergency call supported
           a41     : 0 : Asymmetric bearers supported
           a42     : 0 : Reserved
           a43     : 0 : LRMS
           a44     : 0 : Data Service Profile D
           a45     : x : DPRS Class 3 or Class 4 management and A-field procedures supported
           a46     : 0 : DPRS Class 2 management and B-field procedures supported
           a47     : 0 : ISDN Data Services

       a22: This bit is set to 1 by ULE feature setting
    */
   #if defined(DECT_NG)
   #if CONFIG_REPEATER_SUPPORT  // JONATHAN_TEST for Repeater
   pxFTCap->aucExtendedFixedCap[0] = 0x42;
   #else
   pxFTCap->aucExtendedFixedCap[0] = 0x4C;
   #endif

   pxFTCap->aucExtendedFixedCap[1] = 0x11;

   pxFTCap->aucExtendedFixedCap[2] = 0x00
                                     #ifdef CATIQ_UPLANE
                                     | 0x10 // a27
                                     #endif
                                     ;

   pxFTCap->aucExtendedFixedCap[3] = 0x00;

   pxFTCap->aucExtendedFixedCap[4] = 0x00
                                     #ifdef CATIQ_UPLANE
                                     | 0x04 // a45
                                     #endif
                                     ;
   #endif

   /*
      QC: Extended fixed part capabilities (part 2)

      [0]: 1100 x000b
           a08..a11: C : QH
           a12     : x : Long slot supported (j=640)
           a13     : 0 : Long slot supported (j=672)
           a14     : 0 : E+U-type mux and channel Ipf basic procedures supported
           a15     : 0 : Channel Ipf advanced procedures supported
      [1]: 0000 0000b
           a16     : 0 : Channel SIpf supported
           a17     : 0 : Channel Gf supported
           a18..a22: 0 : Reserved
           a23     : 0 : "No-emission" mode; preferred carrier number mode (CN)
      [2]: x000 0xxxb
           a24     : x : NG-DECT wideband voice supported
           a25..a28: 0 : DPRS/NG-DECT Packet Data Category
           a29     : x : NG-DECT extended wideband voice supported
           a30     : x : NG-DECT extended wideband voice supported sets of services, Permanent CLIR
           a31     : x : NG-DECT extended wideband voice supported sets of services, Third party conference call (external or internal)
      [3]: xxxx x000b
           a32     : x : NG-DECT extended wideband voice supported sets of services, Intrusion call
           a33     : x : NG-DECT extended wideband voice supported sets of services, Call deflection
           a34     : x : NG-DECT extended wideband voice supported sets of services, Multiple lines
           a35     : x : "No-emission" mode supported
           a36     : x : Support of NG-DECT 5 (Additional feature set nr.1 for extended wideband voice, TS 102 527-5)
           a37..a38: 0 : Reserved
           a39     : 0 : Support for DECT ULE
      [4]: 1000 0100b
           a40..a41: 2 : 00 - ULE Phase 1 (v1.1.1), 10 - ULE Phase 1 (v1.2.1 or later), 01 - ULE Phase 2, 11 - ULE Phase 3 (reserved)
           a42     : 0 : Support of "Re-keying" and "Early encryption"
           a43     : 0 : DSAA2 supported
           a44     : 0 : DSC2 supported
           a45     : 1 : Ligth data services supported
           a46..a47: 0 : Reserved

       a39: This bit is set to 1 by ULE feature setting
       a42: This bit is set to 1 by Early Encryption feature setting
       a43: This bit is set to 1 by ULE feature setting
    */
   #ifdef DECT_NG
   pxFTCap->aucExtended2FixedCap[0] = 0xC0
                                      #ifdef DECT_NG_WBS
                                      | 0x08 // a12
                                      #endif
                                      ;

   pxFTCap->aucExtended2FixedCap[1] = 0x00;

   pxFTCap->aucExtended2FixedCap[2] = 0x00
                                      #ifdef DECT_NG_WBS
                                      | 0x87 // a24 a29 a30 a31
                                      #endif
                                      ;

   pxFTCap->aucExtended2FixedCap[3] = 0x00
                                      #ifdef DECT_NG_WBS
                                      | 0xE8 // a32 a33 a34 a36 
                                      #endif
                                      #ifdef CATIQ_NOEMO
                                      | 0x10 // a35
                                      #endif
                                      ;

   pxFTCap->aucExtended2FixedCap[4] = 0x84; // a40 a45
   #endif

   return IFX_SUCCESS;
}
/******************************************************************
*  Function Name    :  IFX_DECT_SetFTCap
*  Description      :  This is the function Sets FT capabilities
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  void
*  Notes            :
*********************************************************************/
e_IFX_Return IFX_DECT_SetFTCap(x_IFX_DECT_FTCap *pxFTCapabilities)
{
  x_IFX_DECT_IPC_Msg xIPCMsg={0};
  x_IFX_DECT_FTCap xFTCap={{0}};
  if(memcmp(pxFTCapabilities,&xFTCap,sizeof(x_IFX_DECT_FTCap)) == 0){
    IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "<DECT-TUMain> Getting Default FT Cap");
     IFX_DECT_GetDeafultFTCap(pxFTCapabilities);
  }
  memcpy(&vxGlobalInfo.xStackCfg.xFTCapabilities,pxFTCapabilities,sizeof(x_IFX_DECT_FTCap)); 

  /* Send Fixed Part Cap*/
  IFX_DECT_EncodeQTMsg(IFX_DECT_Q3_MESSAGE,
                       pxFTCapabilities->aucFixedPartCap,&xIPCMsg);
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
  
  /* Send Extended Fixed Part Cap*/
  IFX_DECT_EncodeQTMsg(IFX_DECT_Q4_MESSAGE,
                       pxFTCapabilities->aucExtendedFixedCap,&xIPCMsg);
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
  /* Send Extended Fixed Part Cap Part 2*/
  IFX_DECT_EncodeQTMsg(IFX_DECT_QC_MESSAGE,
                       pxFTCapabilities->aucExtended2FixedCap,&xIPCMsg);
  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIPCMsg);
	/*Indicate the Application that fw has downloaded successfully*/
 	if(vxGlobalInfo.viDECTStackMode != IFX_DECT_ASYNC_MODE){
    if(vxGlobalInfo.xUSU.vxUSUCallBks.pfn_USU_FirmwareDownloadStatus != NULL){
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "<DECT-TUMain> Calling FW download status with success");
      vxGlobalInfo.xUSU.vxUSUCallBks.pfn_USU_FirmwareDownloadStatus(IFX_FW_DOWNLOAD_SUCCESS);
    }
  }
  else{
    /*Indicate the Application that fw has downloaded successfully*/
    if(vxGlobalInfo.vpfnInitStatus != NULL){
      vxGlobalInfo.vpfnInitStatus(IFX_FW_DOWNLOAD_SUCCESS);
    }
  }
  return IFX_SUCCESS;  
}

#if 1 // #ifdef CONFIG_UPDATE_QT_HANDLIING
/******************************************************************
*  Function Name  :  IFX_DECT_GetFTCap
*  Description    :  This is the function to get FT capabilities
*  Input Values   :  pFTCapability
*  Output Values  :  void
*  Return Value   :  void
*  Notes          :
*********************************************************************/
void IFX_DECT_GetFTCap(void * pFTCapability)
{
   x_IFX_DECT_FTCap xFTCap={{0}};

   if (memcmp(&vxGlobalInfo.xStackCfg.xFTCapabilities, &xFTCap, sizeof(x_IFX_DECT_FTCap)) == 0) {
     IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
              "<DECT-TUMain> Getting Default FT Cap");
     IFX_DECT_GetDeafultFTCap(&vxGlobalInfo.xStackCfg.xFTCapabilities);
   }
   memcpy(pFTCapability, &vxGlobalInfo.xStackCfg.xFTCapabilities, sizeof(x_IFX_DECT_FTCap)); 
}
#endif

/******************************************************************
*  Function Name  :  IFX_DECT_CosicModuleInitilized
*  Description    :  this function is called after cosic modem is initilized
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes          :   used only for backward compatability
*********************************************************************/
#if 0 // #ifndef CONFIG_UPDATE_QT_HANDLIING
void IFX_DECT_CosicModuleInitilized(void)
{
  sleep(2);
  IFX_DECT_SetFTCap(&vxGlobalInfo.xStackCfg.xFTCapabilities);
  //vxGlobalInfo.vpfnInitStatus(IFX_SUCCESS);
  return;
  
}
#else
void IFX_DECT_CosicModuleInitilized(void)
{
  sleep(2);
  
  /*Indicate the Application that fw has downloaded successfully*/
  if (vxGlobalInfo.viDECTStackMode != IFX_DECT_ASYNC_MODE) {
    if (vxGlobalInfo.xUSU.vxUSUCallBks.pfn_USU_FirmwareDownloadStatus != NULL) {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
               "<DECT-TUMain> Calling FW download status with success");
      vxGlobalInfo.xUSU.vxUSUCallBks.pfn_USU_FirmwareDownloadStatus(IFX_FW_DOWNLOAD_SUCCESS);
    }
  } else {
    /*Indicate the Application that fw has downloaded successfully*/
    if (vxGlobalInfo.vpfnInitStatus != NULL) {
      vxGlobalInfo.vpfnInitStatus(IFX_FW_DOWNLOAD_SUCCESS);
    }
  }
}
#endif

/******************************************************************
*  Function Name  :  IFX_DECT_Configure
*  Description    :  this function is responsible for initializing all
*                    the modules and reception of all the messages from all
*                    the interfaces.
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes          :   used only for backward compatability
*********************************************************************/
PUBLIC int32 IFX_DECT_Configure(IN e_IFX_DECT_CfgType eCfgOption,
                               IN x_IFX_DECT_StackCfg *pxStackCfg)
{
  
  switch(eCfgOption){
   case IFX_DECT_CONFIG_DBG:
     IFX_DECT_DbgInit(pxStackCfg->iDbgType,pxStackCfg->iDbgLvl);
     break;
   case IFX_DECT_CONFIG_PIN:
#ifdef __PIN_CODE__
        IFX_DECT_MU_ChangeBasePin(pxStackCfg->acBasePin);
#endif
     break;
	 case IFX_DECT_CONFIG_FTCAP:
	    IFX_DECT_SetFTCap(&pxStackCfg->xFTCapabilities);
	    break;
   case IFX_DECT_CONFIG_ENCRYPT:
      vxGlobalInfo.xStackCfg.bEncryption = pxStackCfg->bEncryption;
      break;
	 case IFX_DECT_CONFIG_RF:
      		vxGlobalInfo.xStackCfg.bRfEnable = pxStackCfg->bRfEnable;
		  		IFX_DECT_DIAG_RfCtrl();
			break;
   case IFX_DECT_CONFIG_ALL:
#ifdef __PIN_CODE__
      IFX_DECT_MU_ChangeBasePin(pxStackCfg->acBasePin);
#endif
      vxGlobalInfo.xStackCfg.bEncryption = pxStackCfg->bEncryption;
      IFX_DECT_DbgInit(pxStackCfg->iDbgType,pxStackCfg->iDbgLvl);
	    IFX_DECT_SetFTCap(&pxStackCfg->xFTCapabilities);
   }
   return IFX_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_DECT_UpdateEnhancedFeatures
*  Description    :  This function is responsible for  
*                    changing in run time enhanced configuration of TK/Stack
*  Input Values   :  enable (1)/Disable (0)
*  Output Values  :  void
*  Return Value   :  IFX_SUCCESS/IFX_FAILURE
*  Notes          :   
*********************************************************************/
PUBLIC int32 IFX_DECT_UpdateEnhancedFeatures(IN x_IFX_DECT_EnhancedStackCfg *pxDECTEnhancedStackCfg)

{
	IFX_DECT_InitEnhancedFeatures(pxDECTEnhancedStackCfg);
	TestAppWriteToHmac(HMAC, MAC_SOFT_RESET_RQ_LMAC
         ,0, 0, 0, 0
         ,0, 0, 0, 0);
	return IFX_SUCCESS;
}


/******************************************************************
*  Function Name  :  IFX_DECT_InitEnhancedFeatures
*  Description    :  This function is responsible for initializing 
*                     enhanced configuration of TK/Stack
*  Input Values   :  enhanced feature settings for the DECT toolkit
*  Output Values  :  void
*  Return Value   :  IFX_SUCCESS/IFX_FAILURE
*  Notes          :   
*********************************************************************/
PUBLIC int32 IFX_DECT_InitEnhancedFeatures(IN x_IFX_DECT_EnhancedStackCfg *pxDECTEnhancedStackCfg)
{
	if(pxDECTEnhancedStackCfg->bEarlyEncryption)
		uiDECTEnhancedFeatures|= IFX_DECT_EARLY_ENCRYPTION;
	else
		uiDECTEnhancedFeatures&= ~IFX_DECT_EARLY_ENCRYPTION;
	
	if(pxDECTEnhancedStackCfg->bReKeying)
		uiDECTEnhancedFeatures|= IFX_DECT_REKEYING;
	else
		uiDECTEnhancedFeatures&= ~IFX_DECT_REKEYING;
		
	if(pxDECTEnhancedStackCfg->bULESupport)
		uiDECTEnhancedFeatures|= IFX_DECT_ULE_ENABLE;
	else
		uiDECTEnhancedFeatures&= ~IFX_DECT_ULE_ENABLE;
	
	if(pxDECTEnhancedStackCfg->bRepeaterSupport)
		uiDECTEnhancedFeatures|= IFX_DECT_REPEATER_SUPPORT_ENABLE;
	else
		uiDECTEnhancedFeatures&= ~IFX_DECT_REPEATER_SUPPORT_ENABLE;
	
	if(pxDECTEnhancedStackCfg->bJapanDECTSupport)
		uiDECTEnhancedFeatures|= IFX_DECT_JAPAN_SUPPORT;
	else
		uiDECTEnhancedFeatures&= ~IFX_DECT_JAPAN_SUPPORT;
	
	if(pxDECTEnhancedStackCfg->bUseRealCN)
		uiDECTEnhancedFeatures|= IFX_DECT_USE_REAL_CN;
	else
		uiDECTEnhancedFeatures&= ~IFX_DECT_USE_REAL_CN;

	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT,
           "IFX_DECT_InitEnhancedFeatures:",uiDECTEnhancedFeatures);
	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT,
           "The Base pin is 123456789:",vxGlobalInfo.xStackCfg.acBasePin);
 
   //return IFX_SUCCESS;
   return (int) uiDECTEnhancedFeatures;
}



/******************************************************************
*  Function Name    :  IFX_DECT_Init
*  Description      :  This is the function which forks the DECT process
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  void
*  Notes            :
*********************************************************************/
#if 0
void IFX_DECT_PopulateMU(x_IFX_DECT_SubscInfo *pxSubscInfo,uchar8 ucNoOfReg)
{
  uchar8 ucIndex =0;
  while(ucNoOfReg>0){
	if(pxSubscInfo->cstatus){
		vxGlobalInfo.xMU.vxMUInfo[ucIndex].eState = IFX_DECT_MU_HS_REGISTERD;
		vxGlobalInfo.xMU.vxMUInfo[ucIndex].uiTermCap = pxSubscInfo->uiTermCap;
		vxGlobalInfo.xStackCfg.auiTermCap[ucIndex] = pxSubscInfo->uiTermCap;
    ucNoOfReg--;
	}
	pxSubscInfo++;
  ucIndex++;
  }
}

#endif

void IFX_DECT_PopulateMU(x_IFX_DECT_SubscInfo *pxSubscInfo,uchar8 ucNoOfReg)
{
  uchar8 ucIndex =0;
  for(ucIndex=0;ucIndex<ucNoOfReg;ucIndex++){
	if(pxSubscInfo->cstatus){
		//vxGlobalInfo.xMU.vxMUInfo[ucIndex].eState = IFX_DECT_MU_HS_REGISTERD;
		vxGlobalInfo.xMU.vxMUInfo[ucIndex].eState = IFX_DECT_MU_HS_ATTACHED;
		vxGlobalInfo.xMU.vxMUInfo[ucIndex].uiTermCap = pxSubscInfo->uiTermCap;
		vxGlobalInfo.xStackCfg.auiTermCap[ucIndex] = pxSubscInfo->uiTermCap;
  	IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT,
           "The termCap is:",vxGlobalInfo.xMU.vxMUInfo[ucIndex].uiTermCap);
	}
	else
	{
		vxGlobalInfo.xMU.vxMUInfo[ucIndex].eState = IFX_DECT_MU_HS_IDLE;
  		IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT,
           		" HS Not registered ",ucIndex);
	}

	pxSubscInfo++;
  }
}
/******************************************************************
*  Function Name    :  IFX_DECT_Init
*  Description      :  This is the function which forks the DECT process
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  void
*  Notes            :
*********************************************************************/
int32
IFX_DECT_Main(void *pxParam){
  uchar8 ucNoEmoState;

  IFX_DECT_DbgInit(vxGlobalInfo.xStackCfg.iDbgType,vxGlobalInfo.xStackCfg.iDbgLvl);
  //IFX_DECT_DbgInit(IFX_DBG_TYPE_CONSOLE,IFX_DBG_LVL_HIGH);
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT,
           "The total number of registration is:",vxGlobalInfo.xStackCfg.ucNoOfReg);
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT,
           "The Base pin is from IFX_DECT_Main:",vxGlobalInfo.xStackCfg.acBasePin);
 
  IFX_DECT_PopulateMU(vxGlobalInfo.xStackCfg.xRegList,vxGlobalInfo.xStackCfg.ucNoOfReg);
  
  /* Configure the Stack*/
  ucNoEmoState = 0x00;
  #ifdef ULE_SUPPORT
  if (/* isNoEmoFeatureActivated() && */ !(IFX_DECT_GetUserFeatures() & 0x08u))
  #else
  /* if (isNoEmoFeatureActivated()) */
  #endif
  {
     ucNoEmoState = 0x58;
  }
  IFX_DECT_StackEntry(vxGlobalInfo.xStackCfg.aucRfpi,&vxGlobalInfo.xStackCfg.xTPCPrams,
                      &vxGlobalInfo.xStackCfg.xBMCPrams,
                     &vxGlobalInfo.xStackCfg.xOscTrimVal,&vxGlobalInfo.xStackCfg.unGaussianVal,
                      vxGlobalInfo.xStackCfg.xRegList,vxGlobalInfo.xStackCfg.ucNoOfReg,
                      0/*CODEC_G726*/, 1/*CODEC_G722*/
                      , ucNoEmoState /* NoEmo Status */
#ifdef __PIN_CODE__
                      ,vxGlobalInfo.xStackCfg.acBasePin
#endif
                      );
 return IFX_SUCCESS;

}
/******************************************************************
*  Function Name    :  IFX_DECT_Init
*  Description      :  This is the function which forks the DECT process
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  void
*  Notes            :
*********************************************************************/
int32
IFX_DECT_Async_Init(IN x_IFX_DECT_StackInitCfg *pxInitCfg,
                    IN pfn_IFX_DECT_InitStatus pfnInit)
{
  uint32 uiRetVal;
  vxGlobalInfo.vpfnInitStatus = pfnInit;
  vxGlobalInfo.viDECTStackMode = IFX_DECT_ASYNC_MODE;
  vucDownloadBmcOnBootInd =1;
  vcMaxHandset = pxInitCfg->ucMaxHandsets;
#if 0  
  if(IFX_DECT_CreateAllMutex(&vxGlobalInfo) == IFX_FAILURE){
    IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
             "<DECT-TUMain> Mutex Creation Failed");
    if(pfnInit != NULL){ 
      pfnInit(IFX_FAILURE);
    }
    return IFX_FAILURE;
  }
#endif
  memcpy(&vxGlobalInfo.xStackCfg,pxInitCfg,
         sizeof(x_IFX_DECT_StackInitCfg));

#ifdef xxULE_SUPPORT
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_INT,
           "The ULE Base pin is:",vxGlobalInfo.xStackCfg.acBasePin);
IFX_DECT_ULE_Init1();
#endif
  uiRetVal =IFX_DECT_CreateThread((void *)IFX_DECT_Main,NULL);	  
  if(uiRetVal == 0){
    IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "DECT stack Thread Creation Error");
    if(pfnInit != NULL){ 
      pfnInit(IFX_FAILURE);
    }
    return IFX_FAILURE;
  }
	vuiDectThreadExit=uiRetVal;
#ifdef FW_DOWNLOAD
  if(vxGlobalInfo.vpfnInitStatus != NULL){
    vxGlobalInfo.vpfnInitStatus(IFX_SUCCESS);
  }else{
    printf("Init function is NULL\n");
  }
#else
#error "NO FW_DOWNLOAD"					  
  printf("NO FW_DOWNLOAD\n");
 
#endif
  return IFX_SUCCESS;
}

/******************************************************************
*  Function Name    :  IFX_DECT_Init_Sync
*  Description      :  This is the function which initializes the 
*  									:  the DECT stack in Sync mode.
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  void
*  Notes            :
*********************************************************************/
PUBLIC int32 IFX_DECT_Sync_Init(
	        IN  x_IFX_DECT_StackInitCfg *pxInitCfg,
                IN x_IFX_DECT_SyncCallBks *pxSyncCallBks)
{
  uchar8 ucNoEmoState;

  vxGlobalInfo.viDECTStackMode = IFX_DECT_SYNC_MODE;
  vucDownloadBmcOnBootInd =1;
  vcMaxHandset = pxInitCfg->ucMaxHandsets;
  memcpy(&vxGlobalInfo.vxDECTSyncCallBks,
         pxSyncCallBks,sizeof(x_IFX_DECT_SyncCallBks));

  //IFX_DECT_DbgInit(pxStackCfg->iDbgType,pxStackCfg->iDbgLvl);
  IFX_DECT_DbgInit(IFX_DBG_TYPE_CONSOLE,IFX_DBG_LVL_HIGH);
  vxGlobalInfo.xStackCfg.bEncryption = pxInitCfg->bEncryption;

  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "DECT stack Inititated  in SYNC Mode");

  IFX_DECT_PopulateMU(vxGlobalInfo.xStackCfg.xRegList,vxGlobalInfo.xStackCfg.ucNoOfReg);

  /* Configure the Stack*/
  ucNoEmoState = 0x00;
  #ifdef ULE_SUPPORT
  if (/* isNoEmoFeatureActivated() && */ !(IFX_DECT_GetUserFeatures() & 0x08u))
  #else
  /* if (isNoEmoFeatureActivated()) */
  #endif
  {
     ucNoEmoState = 0x58;
  }
  IFX_DECT_StackEntry(pxInitCfg->aucRfpi,&pxInitCfg->xTPCPrams, &pxInitCfg->xBMCPrams,
                     &pxInitCfg->xOscTrimVal,&pxInitCfg->unGaussianVal,
                      pxInitCfg->xRegList,pxInitCfg->ucNoOfReg,
                      0/*CODEC_G726*/, 1/*CODEC_G722*/
                      , ucNoEmoState /* NoEmo Status */
#ifdef __PIN_CODE__
                      ,pxInitCfg->acBasePin
#endif
                      );
  return IFX_SUCCESS;
}
 
/******************************************************************
*  Function Name    :  IFX_DECT_Shut
*  Description      :  This is the function which destorys DECT thread
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  IFX_SUCCESS/IFX_FAILURE
*  Notes            :
*********************************************************************/
extern e_IFX_Return IFX_DECT_DPSU_ShutDectDataApp (void *Discard);
int32 IFX_DECT_Shut()
{
  if(vxGlobalInfo.viDECTStackMode == IFX_DECT_ASYNC_MODE)
	{
		x_IFX_DECT_IPC_Msg xIpcMsg={0};
		xIpcMsg.ucMsgId = IFX_DECT_SHUTDOWN ;
		xIpcMsg.ucInstance = 0;
		xIpcMsg.ucPara1 = 1;
		xIpcMsg.ucPara2 = DUMMY_FILL;
		IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
		IFX_DECT_ThreadJoin(vuiDectThreadExit);
	}
	else
	{
    vxGlobalInfo.vxDECTSyncCallBks.pfnRemoveFDToSelect(dect_drv_fd, IFX_DECT_WRITE_FDSET);
    vxGlobalInfo.vxDECTSyncCallBks.pfnRemoveFDToSelect(dect_drv_fd, IFX_DECT_READ_FDSET);
    vxGlobalInfo.vxDECTSyncCallBks.pfnRemoveFDToSelect(timer_fd, IFX_DECT_READ_FDSET);
    vxGlobalInfo.vxDECTSyncCallBks.pfnRemoveFDToSelect(timer_fd, IFX_DECT_WRITE_FDSET);
		IFX_CloseTimerDriver();
		DectDrvIfShut();
	}
  if(vxGlobalInfo.vpfnInitStatus != NULL){
  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Sending DECT Shutdown success to App By CB fn");
	vxGlobalInfo.vpfnInitStatus(IFX_DECT_SHUTDOWN_SUCCESS);
	}
	memset(&vxGlobalInfo,0,sizeof(vxGlobalInfo));
  return IFX_SUCCESS;
     
}
#if 0
/******************************************************************
*  Function Name    :  IFX_DECT_PopulateTermCap
*  Description      :  This is the function will populate the Terminal Cap
*  Input Values     :  void
*  Output Values    :  void
*  Return Value     :  IFX_SUCCESS/IFX_FAILURE
*  Notes            :
*********************************************************************/

int32 IFX_DECT_PopulateTermCap(int *piTermCap)
{
   char8 iCount=0;
   for( iCount = 0; iCount < 6; iCount++ )
   {
	   vxGlobalInfo.xMU.vxMUInfo[iCount].uiTermCap = *piTermCap;
	   if(*piTermCap&IFX_DECT_MU_HS_WB){
			Terminal_Cap[ iCount ] = 1;
			First_Codec[ iCount ] = 3;
			Second_Codec[ iCount ] = 2;	
			Third_Codec[ iCount ] = 0;
	   }else {
   			Terminal_Cap[ iCount ] = 0;
			First_Codec[ iCount ] = 2;
			Second_Codec[ iCount ] = 0;	
			Third_Codec[ iCount ] = 0;
	   }
       piTermCap++;
  }
  return IFX_SUCCESS;
     
}
#endif

uint32 IFX_DECT_GetUserFeatures(void)
{
   
	if (vxGlobalInfo.xStackCfg.bEncryption == IFX_TRUE) {
		uiDECTEnhancedFeatures|= IFX_DECT_NORMAL_ENCRYPTION;
	}
	else{
		uiDECTEnhancedFeatures&= ~IFX_DECT_NORMAL_ENCRYPTION;
	}
	/*required other features bits configured in function IFX_DECT_InitEnhancedFeatures*/
	 return uiDECTEnhancedFeatures; 

#if 0
	uint32 feature;

	feature = 0;
	if (vxGlobalInfo.xStackCfg.bEncryption == IFX_TRUE) {
		feature |= 0x01;
	}
	// TODO: "if" statement should be completed. Rekeying and Early encryption is not supported as default value.
	// if (early encryption supported) {
	//	feature |= 0x02;
	// }
	// if (rekeying supported) {
	//	feature |= 0x04;
	// }
	#ifdef ULE_SUPPORT
	// TODO: "if" statement should be completed. ULE is supported as default value.
	// if (ULE supported) {
		feature |= 0x08;
	// }
	#endif

        #ifdef ULE_SUPPORT
	// TODO: "if" statement should be completed. It is not supported as default value.
	// if (DCK CCM use for MAC encryption) {
	//	feature |= 0x80000000;
	// }
	#endif

        #ifdef CONFIG_REPEATER_SUPPORT
	// TODO: "if" statement should be completed. It is not supported as default value.
	// if (Repeater support) {
	//	feature |= 0x00000010;
	// }
        #endif

        #ifdef JDECT_SUPPORT
	// TODO: "if" statement should be completed. It is not supported as default value.
	// if (JDECT support) {
	//	feature |= 0x00000020;
	// }
        #endif

        #ifdef REAL_CN_SUPPORT
	// TODO: "if" statement should be completed. It is not supported as default value.
	// if (REAL CN support) {
	//	feature |= 0x00000040;
	// }
        #endif
	
	return feature;
#endif
}
