/**************************************************************************
**   FILE NAME     : IFX_DECT_Plaftorm.c
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "IFX_DECT_Platform.h"
#ifdef __LINUX__
unsigned int value_ptr=0, *ValuePtr=NULL;
void IFX_OS_ThreadJoin(pthread_t thread)
{
	ValuePtr=&value_ptr;
	pthread_join(thread, ((void **) &ValuePtr));
}
e_IFX_Return IFX_TIM_TimerStart(
			  IN uint32 uiTimeOut,
			  IN void* pvPrivateData,
			  IN uint16 unPrivateDataLen,
			  IN  pfn_IFX_DECT_TimerCallBack pfnTimerCallBack,
			  OUT uint32* puiTimerId
			 );

e_IFX_Return  IFX_TIM_TimerStop(uint32 uiTimerId);  
#endif
e_IFX_Return IFX_DECT_StartTimer(
			  IN uint32 uiTimeOut,
			  IN void* pvPrivateData,
			  IN uint16 unPrivateDataLen,
			  IN pfn_IFX_DECT_TimerCallBack pfnTimerCallBack,
			  OUT uint32* puiTimerId)
{
#ifdef __LINUX__
  return  IFX_TIM_TimerStart(
			   uiTimeOut,
			   pvPrivateData,
			   unPrivateDataLen,
			   pfnTimerCallBack,
			   puiTimerId
			 ); 
#endif
#ifdef SUPERTASK
      //if( *puiTimerId ==0){
			if (SYS_TIMER_Create("RegTimer",(SYS_TIMER_ID_T *)puiTimerId)!=SYS_TIMER_SUCCESS) {
				cosic_printf("RegTimer create timer failed\n");
			}
       //}
	   if (SYS_TIMER_Start((SYS_TIMER_ID_T)*puiTimerId, uiTimeOut,pfnTimerCallBack, *puiTimerId, SYS_TIMER_ONESHOT) != SYS_TIMER_SUCCESS)
	   {
				cosic_printf("Could Not Start Timer. Registration Of PPs Will Not Be Stopped\n");
		}

#endif
}
			  
e_IFX_Return IFX_DECT_StopTimer(IN uint32 uiTimerId)
{
#ifdef __LINUX__
  return IFX_TIM_TimerStop(uiTimerId);  
#endif
#ifdef SUPERTASK
  SYS_TIMER_Stop(uiTimerId); 
  SYS_TIMER_Destroy(uiTimerId); 

#endif
}

#ifdef SUPERTASK

char8 * vacMsgTbl[] =
{
   /* Common Informative Debugs */
   [IFX_DBG_STR] = "<DECT_TK %s >%s\n", /* Print Any String */
   [IFX_DBG_INT] = "<DECT_TK %s > %s :%d\n", /* Print Any integer */
   [IFX_DBG_ATA_STRING_INFO] = "<DECT_TK $s > %s : %s\n",/*Shweta*/
   [IFX_DBG_ATA_INT_INFO] = "<DECT_TK %s > %s : %d\n",/*Shweta*/
};
#endif /* SUPERTASK*/

