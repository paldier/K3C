/**************************************************************************
**   FILE NAME     : IFX_DECT_IEParser.c
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
 #include "IFX_DECT_Platform.h"
 #include "IFX_DECT_StackIf.h"
 #include "IFX_DECT_MsgRouter.h"
 #include "IFX_DECT_IEParser.h"
 #define  TOTALIESIZE 249

 uchar8 vucRI = 0;
 e_IFX_DECT_IE veIE = IFX_DECT_IE_NOTIE;
 
 /*****************************************************************************
  * Function Name     :  IFX_D ECT_IE_IETypeGet
  * Description       :  A function used to fetch the enum value of IE pointed 
                         by the IE Handler
  * Input Value       :  Handler to the IE to be identified
  * Output Value      :  None
  * Return Value      :  enum value of IE
  * Notes             :  Function checks whether it is a valid enum and returns 
                         the enum value
  ****************************************************************************/
         
  e_IFX_DECT_IE IFX_DECT_IE_TypeGet(uint32 uiIEHdl)
  {
  	e_IFX_DECT_IE eTemp;
    if(uiIEHdl!=0)
    {
      uchar8 ucTemp = *((uchar8 *)uiIEHdl);
      if( ((ucTemp & 0X80) == 0X80) && ((ucTemp & 0XA0 )!= 0XA0) && ((ucTemp & 0XE0)!=0XE0) )
      { //single octet IE and first nibble not equal to 0XA
        ucTemp = ucTemp & 0XF0;    //lower nibble set to zero
      }
	  eTemp = ucTemp;
      switch(eTemp)
      {
        case IFX_DECT_IE_BASICSERVICE:
                                 return IFX_DECT_IE_BASICSERVICE;
        case IFX_DECT_IE_SIGNAL:
                                 return IFX_DECT_IE_SIGNAL;
        case IFX_DECT_IE_SINGLEKEYPAD:
                                 return IFX_DECT_IE_SINGLEKEYPAD;
        case IFX_DECT_IE_CALLATTRIBUTES:
                                 return IFX_DECT_IE_CALLATTRIBUTES;
        case IFX_DECT_IE_CALLEDPARTYNUMBER:
                                 return IFX_DECT_IE_CALLEDPARTYNUMBER;
        case IFX_DECT_IE_CALLINGPARTYNAME:
                                 return IFX_DECT_IE_CALLINGPARTYNAME;
        case IFX_DECT_IE_CONNECTIONATTRIBUTES:
                                 return IFX_DECT_IE_CONNECTIONATTRIBUTES;
        case IFX_DECT_IE_CONNECTIONIDENTITY:
                                 return IFX_DECT_IE_CONNECTIONIDENTITY;
        case IFX_DECT_IE_FACILITY:
                                 return IFX_DECT_IE_FACILITY;
        case IFX_DECT_IE_IWUATTRIBUTES:
                                 return IFX_DECT_IE_IWUATTRIBUTES;
        case IFX_DECT_IE_IWUTOIWU:
                                 return IFX_DECT_IE_IWUTOIWU;
        case IFX_DECT_IE_MULTIKEYPAD:
                                 return IFX_DECT_IE_MULTIKEYPAD;
        case IFX_DECT_IE_MULTIDISPLAY:
                                 return IFX_DECT_IE_MULTIDISPLAY;
        case IFX_DECT_IE_ESCAPETOPROPRIETARY:
                                 return IFX_DECT_IE_ESCAPETOPROPRIETARY;
        case IFX_DECT_IE_TIMEDATE:
                                 return IFX_DECT_IE_TIMEDATE;
        case IFX_DECT_IE_PORTABLEIDENTITY:
                                 return IFX_DECT_IE_PORTABLEIDENTITY;
        case IFX_DECT_IE_FIXEDIDENTITY:
                                 return IFX_DECT_IE_FIXEDIDENTITY;
        case IFX_DECT_IE_CALLINGPARTYNUMBER:
                                 return IFX_DECT_IE_CALLINGPARTYNUMBER;
        case IFX_DECT_IE_IWUPACKET:
                                 return IFX_DECT_IE_IWUPACKET;
        case IFX_DECT_IE_CODECLIST:
                                 return IFX_DECT_IE_CODECLIST;
        case IFX_DECT_IE_WINDOWSIZE:
                                 return IFX_DECT_IE_WINDOWSIZE;
        case IFX_DECT_IE_SINGLEDISPLAY:
                                 return IFX_DECT_IE_SINGLEDISPLAY;
        case IFX_DECT_IE_REPEATINDICATOR:
                                 return IFX_DECT_IE_REPEATINDICATOR;
        case IFX_DECT_IE_PROGRESSINDICATOR:
                                 return IFX_DECT_IE_PROGRESSINDICATOR;
        case IFX_DECT_IE_SERVICECHANGEINFO:
                                 return IFX_DECT_IE_SERVICECHANGEINFO;
        case IFX_DECT_IE_LOCATIONAREA:
                                 return IFX_DECT_IE_LOCATIONAREA;
        case IFX_DECT_IE_AUTHTYPE:
                                 return IFX_DECT_IE_AUTHTYPE;
        case IFX_DECT_IE_CIPHERINFO:
                                 return IFX_DECT_IE_CIPHERINFO;
        case IFX_DECT_IE_SERVICECLASS:
                                 return IFX_DECT_IE_SERVICECLASS;
        case IFX_DECT_IE_SETUPCAPABILITY:
                                 return IFX_DECT_IE_SETUPCAPABILITY;
        case IFX_DECT_IE_MODELIDENTIFIER:
                                 return IFX_DECT_IE_MODELIDENTIFIER;
        case IFX_DECT_IE_REJECTREASON:
                                 return IFX_DECT_IE_REJECTREASON;
        case IFX_DECT_IE_DURATION:
                                 return IFX_DECT_IE_DURATION;
        case IFX_DECT_IE_RAND:
                                 return IFX_DECT_IE_RAND;
        case IFX_DECT_IE_RES:
                                 return IFX_DECT_IE_RES;
        case IFX_DECT_IE_RS:
                                 return IFX_DECT_IE_RS;
        case IFX_DECT_IE_USETPUI:
                                 return IFX_DECT_IE_USETPUI;
        case IFX_DECT_IE_TIMERRESTART:
                                 return IFX_DECT_IE_TIMERRESTART;
	    case IFX_DECT_IE_EVENTNOTIFY:
		                         return IFX_DECT_IE_EVENTNOTIFY;
		case IFX_DECT_IE_CALLINFORMATION:
		                         return IFX_DECT_IE_CALLINFORMATION;
		case IFX_DECT_IE_TERMCAPABILITY:
		                         return IFX_DECT_IE_TERMCAPABILITY;
        case IFX_DECT_IE_NOTIE:
                                 return IFX_DECT_IE_NOTIE;
        default:
                                 return IFX_DECT_IE_GENERICIE;
      }
    }
    return IFX_DECT_IE_NOTIE;
 }
  
/*****************************************************************************
  * Function Name     :  IFX_DECT_IE_NextIEHandlerGet
  * Description       :  A function used to fetch Handler (address) to the
                         succeeding IE in the message
  * Input/Output Value:  Pointer to IE Handler 
  * Return Value      :  boolean value to denote success of failure of operation
  * Notes             :  The current IE is checked to be a single octet, 
                         double octet or variable octet IE( content length in 
                         second octet) and address of next IE is determined  
                         Null value denotes operation failure
 ****************************************************************************/
 
 e_IFX_Return IFX_DECT_IE_NextIEHandlerGet(uint32 *puiIEHdl)
 {
   uchar8 *pucTemp;//char pointer to traverse IE octets 
   if(puiIEHdl!=0 && *puiIEHdl!=0)
   {
     pucTemp = (uchar8 *)(*puiIEHdl);
     if(*pucTemp == 0)// no IE present
     {
       return IFX_FAILURE;
     }
     if( ((*pucTemp) & 0X80) == 0X80)       
     { //fixed IE 
       if( ((*pucTemp) & 0XE0 )== 0XE0)
       { //double octet
         pucTemp+=2; 
       }                                            
       else
       { // single octet
         pucTemp++;
       }
     }
     else
     {//variable IE                
       pucTemp++;                                     
       pucTemp+= (uchar8)(*pucTemp) + 1;
     }
     *puiIEHdl= (uint32)(pucTemp);
     return IFX_SUCCESS;
   }
	 if (puiIEHdl)
   	 *puiIEHdl= 0;
   return IFX_FAILURE;
 }

//-----------------------------------------------------------------------------
// Get IE functions

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_BasicServiceGet
  * Description       :  A function used to fetch the contents of the Basic
                         Service IE 
  * Input Value       :  IE Handler to Basic Service IE
  * Output Value      :  Pointer to the filled Basic Service content structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE  
                         Handler and filled in the Basic Service IE content
                         structure
 ****************************************************************************/
          
 e_IFX_Return IFX_DECT_IE_BasicServiceGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_BasicService *pxBSInfo)
 {
   if((uiIEHdl!=0) && (pxBSInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_BASICSERVICE)
     // check whether BS IE
     {
       pucTemp++;
       pxBSInfo->ucBasicService=(*pucTemp)& 0X0F;
       pxBSInfo->ucCallClass = (*pucTemp)>>4;
       return IFX_SUCCESS;
     }
   }
   return IFX_FAILURE;
 }


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SingleKeypadGet
  * Description       :  A function used to fetch the contents of the Single
                         Keypad IE 
  * Input Value       :  IE Handler to Single Keypad IE
  * Output Value      :  Pointer to the filled Single Keypad variable
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE  
                         Handler and filled in the Single Keypad IE content
                         variable
 ****************************************************************************/
 
 e_IFX_Return IFX_DECT_IE_SingleKeypadGet(uint32 uiIEHdl, uchar8 *pucSKPInfo)
 {
   if((uiIEHdl!=0) && (pucSKPInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_SINGLEKEYPAD)
     {
       *pucSKPInfo=*(++pucTemp);
       return IFX_SUCCESS;
     }
   } 
   return IFX_FAILURE;
 }


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SingleDisplayGet
  * Description       :  A function used to fetch the contents of the Single
                         Display IE 
  * Input Value       :  IE Handler to Single Display IE
  * Output Value      :  Pointer to the filled Single Display content variable
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE  
                         Handler and filled in the Single Display IE content
                         variable
 ****************************************************************************/
 
 e_IFX_Return IFX_DECT_IE_SingleDisplayGet(uint32 uiIEHdl, uchar8 *pucSDInfo)
 {
   if((uiIEHdl!=0) && (pucSDInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_SINGLEDISPLAY)
     {
       *pucSDInfo=*(++pucTemp);
       return IFX_SUCCESS;
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SignalGet
  * Description       :  A function used to fetch the contents of the Signal IE
  * Input Value       :  IE Handler to Signal IE
  * Output Value      :  Pointer to the filled Signal content variable
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE  
                         Handler and filled in the Signal IE content
                         variable
 ****************************************************************************/
 
 e_IFX_Return IFX_DECT_IE_SignalGet(uint32 uiIEHdl, uchar8 *pucSignalInfo)
 {
   if((uiIEHdl!=0) && (pucSignalInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_SIGNAL)
     {
       *pucSignalInfo=*(++pucTemp);
       return IFX_SUCCESS;
     }
   }
   return IFX_FAILURE;
 }

                 
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_PortableIdentityGet
  * Description       :  A function used to fetch the contents of the
                         Portable Identity IE
  * Input Value       :  IE Handler to Portable Identity IE
  * Output Value      :  Pointer to the filled Portable Identity content structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Portable Identity IE content
                         structure
 ****************************************************************************/
 
       
 e_IFX_Return IFX_DECT_IE_PortableIdentityGet(uint32 uiIEHdl,
                          x_IFX_DECT_IE_PortableIdentity *pxPIDInfo)
 {
   if((uiIEHdl!=0) && (pxPIDInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_PORTABLEIDENTITY)
     {
       uchar8 *pucTemp1 = (uchar8 *)pxPIDInfo;
       uchar8 ucIELen = *(++pucTemp);//content length 
       if((ucIELen!=0) && (ucIELen<=sizeof(x_IFX_DECT_IE_PortableIdentity)))
       {
         const uchar8 *pucTemp2 = ++pucTemp;
         memcpy(pucTemp1,pucTemp2,ucIELen);//memcpy
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_FixedIdentityGet
  * Description       :  A function used to fetch the contents of the
                         Fixed Identity IE
  * Input Value       :  IE Handler to Fixed Identity IE
  * Output Value      :  Pointer to the filled Fixed Identity content structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Fixed Identity IE content
                         structure
 ****************************************************************************/
                
          
 e_IFX_Return IFX_DECT_IE_FixedIdentityGet(uint32 uiIEHdl,
                           x_IFX_DECT_IE_FixedIdentity *pxFIDInfo)
 {
   if((uiIEHdl!=0) && (pxFIDInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_FIXEDIDENTITY)
     {
       uchar8 *pucTemp1 = (uchar8 *)pxFIDInfo;
       uchar8 ucIELen = *(++pucTemp);
       if((ucIELen!=0) && (ucIELen <= sizeof(x_IFX_DECT_IE_FixedIdentity)))
       {
         const uchar8 *pucTemp2 = ++pucTemp; 
         memcpy(pucTemp1,pucTemp2,ucIELen);//memcpy
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_CallingPartyNumberGet
  * Description       :  A function used to fetch the contents of the
                         Calling Party Number IE
  * Input Value       :  IE Handler to Calling Party Number IE
  * Output Value      :  Pointer to the filled Calling Party Number content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Calling Party Number IE
                         content structure
 ****************************************************************************/
     

 e_IFX_Return IFX_DECT_IE_CallingPartyNumberGet(uint32 uiIEHdl,
                           x_IFX_DECT_IE_CallingPartyNumber *pxCgPNumInfo)
 {
   if((uiIEHdl!=0) && (pxCgPNumInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_CALLINGPARTYNUMBER)
     {
       uchar8 ucIELen = *(++pucTemp); //length byte
       if(ucIELen!=0)
       {
         uchar8 *pucTemp1 = (uchar8 *)pxCgPNumInfo;
         pucTemp++;//3rd byte
         if(((*pucTemp) & 0X80) == 0X80)//true => 3a is absent
         {//get 3rd byte
           const uchar8 *pucTemp2 =NULL;
           pxCgPNumInfo->ucNPI= (*pucTemp) & 0X0F;
           pxCgPNumInfo->ucNumberType = ((*pucTemp) & 0X70)>>4;
           pxCgPNumInfo->ucExtn3=1;
           pxCgPNumInfo->ucCPALen  = ucIELen-1;
           pucTemp2 = ++pucTemp;//CPA 1st byte
           pucTemp1=pucTemp1+2;
           if(pxCgPNumInfo->ucCPALen <= (sizeof(x_IFX_DECT_IE_CallingPartyNumber)-2))
           {
             memcpy(pucTemp1,pucTemp2,(pxCgPNumInfo->ucCPALen));
             return IFX_SUCCESS;
           }
           return IFX_FAILURE;
         }
         else//3a present
         {
           const uchar8 *pucTemp2= pucTemp;
           pxCgPNumInfo->ucCPALen = ucIELen - 2;
           if(ucIELen <= (sizeof(x_IFX_DECT_IE_CallingPartyNumber)))
           {
             memcpy(pucTemp1,pucTemp2,ucIELen);//memcpy from octet 3
             return IFX_SUCCESS;
           }
         }
       }
     }
   }
   return IFX_FAILURE;
 }

    



 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_CalledPartyNumberGet
  * Description       :  A function used to fetch the contents of the
                         Called Party Number IE
  * Input Value       :  IE Handler to Called Party Number IE
  * Output Value      :  Pointer to the filled Called Party Number content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Called Party Number IE
                         content structure
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_CalledPartyNumberGet(uint32 uiIEHdl,
                           x_IFX_DECT_IE_CalledPartyNumber *pxCdPNumInfo)
 {
   if((uiIEHdl!=0) && (pxCdPNumInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_CALLEDPARTYNUMBER)
     {
       uchar8 *pucTemp1= (uchar8 *)pxCdPNumInfo;
       pucTemp++;//octet 2
       pxCdPNumInfo->ucCPALen  = (*pucTemp)-1;
       if((*pucTemp)!=0) //check for content length
       { 
	     const uchar8 *pucTemp2=NULL; 
         pucTemp++;//octet 3
         pucTemp2 = pucTemp;
         if(pxCdPNumInfo->ucCPALen < sizeof(x_IFX_DECT_IE_CalledPartyNumber) ) 
         {
           memcpy(pucTemp1,pucTemp2,pxCdPNumInfo->ucCPALen + 1);
           return IFX_SUCCESS;
         }
       }
     }     
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_IWUToIWUGet
  * Description       :  A function used to fetch the contents of the
                         IWU To IWU IE
  * Input Value       :  IE Handler to IWU To IWU IE
  * Output Value      :  Pointer to the filled IWU To IWU content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the IWU To IWU IE
                         content structure
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_IWUToIWUGet(uint32 uiIEHdl,
                           x_IFX_DECT_IE_IWUToIWU *pxIWUToIWUInfo)
 {
   if((uiIEHdl!=0) && (pxIWUToIWUInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_IWUTOIWU)
     {
       pucTemp++; //length byte
       pxIWUToIWUInfo->ucIWUToIWULen  = (*pucTemp)-1;
       if((*pucTemp!=0) && (*pucTemp<=sizeof(x_IFX_DECT_IE_IWUToIWU))) //check for content length
       {
         uchar8 *pucTemp1 = (uchar8 *)pxIWUToIWUInfo;
         const uchar8 *pucTemp2= ++pucTemp; //1st content byte
         memcpy(pucTemp1,pucTemp2,(pxIWUToIWUInfo->ucIWUToIWULen) + 1);
         return IFX_SUCCESS;
       }
     }     
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_CodecListGet
  * Description       :  A function used to fetch the contents of the
                         Codec List IE
  * Input Value       :  IE Handler to Codec List IE
  * Output Value      :  Pointer to the filled Codec List content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Codec List IE
                         content structure
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_CodecListGet(uint32 uiIEHdl,
                           x_IFX_DECT_IE_CodecList *pxCLInfo)
 {
   if((uiIEHdl!=0) && (pxCLInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_CODECLIST)
     {
       uchar8 ucTemp1=0;
       pucTemp++; //length byte
       //Number of Codecs
       pxCLInfo->ucNumCodecs  = ((*pucTemp)-1)/3; 
       if(pxCLInfo->ucNumCodecs>IFX_DECT_IE_MAXCODEC)
       {//number of codecs out of specified range
         return IFX_FAILURE;
       }       
       if((*pucTemp)!=0) //check for content length
       {
         pucTemp++; //octet 3
         pxCLInfo->ucReserved1 = *pucTemp & 0X0F; 
         pxCLInfo->ucNI = (*pucTemp & 0X70)>>4;
         pxCLInfo->ucDefault1=*pucTemp >>7; 
         while((pxCLInfo->ucNumCodecs > 0) && (ucTemp1< (pxCLInfo->ucNumCodecs)))
         {
           pucTemp++;//octet k
           (pxCLInfo->xCodecListSS[ucTemp1]).ucCIdf = (*pucTemp) & 0X7F;
           (pxCLInfo->xCodecListSS[ucTemp1]).ucExtn = *pucTemp >> 7;
           pucTemp++; //octet ka
           (pxCLInfo->xCodecListSS[ucTemp1]).ucMDS = (*pucTemp) & 0X0F;
           (pxCLInfo->xCodecListSS[ucTemp1]).ucReserved2 =(*pucTemp & 0X70) >> 4;
           (pxCLInfo->xCodecListSS[ucTemp1]).ucExtna= *pucTemp >> 7;
           pucTemp++;//octet kb
           (pxCLInfo->xCodecListSS[ucTemp1]).ucSS = (*pucTemp) & 0X0F;
           (pxCLInfo->xCodecListSS[ucTemp1]).ucCPR = (*pucTemp & 0X70) >> 4;
           (pxCLInfo->xCodecListSS[ucTemp1]).ucExtnb=*pucTemp >> 7;
           ucTemp1++;
         };
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_IWUPacketGet
  * Description       :  A function used to fetch the contents of the
                         IWU Packet IE
  * Input Value       :  IE Handler to IWU Packet IE
  * Output Value      :  Pointer to the filled IWU Packet content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the IWU Packet IE
                         content structure
 ****************************************************************************/

  e_IFX_Return IFX_DECT_IE_IWUPacketGet(uint32 uiIEHdl,
                           x_IFX_DECT_IE_IWUPacket *pxIWUPInfo)
 {
   if((uiIEHdl!=0) && (pxIWUPInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)((*pucTemp) & 0XFF) == IFX_DECT_IE_IWUPACKET)
     {
       uchar8 ucIELen = *(++pucTemp); //length byte
       if(ucIELen!=0)
       {
         uchar8 *pucTemp1 = (uchar8 *)pxIWUPInfo;
         pucTemp++;//3rd byte
         if(((*pucTemp) & 0X80) == 0X80)//true => 3a is absent
         { 
		   const uchar8 *pucTemp2=NULL; 
           pxIWUPInfo->ucL2PID= (*pucTemp) & 0X1F;
           pxIWUPInfo->ucDefault1 = ((*pucTemp) & 0X20)>>5;
           pxIWUPInfo->ucSR=((*pucTemp) & 0X40)>>6;
           pxIWUPInfo->ucExtn3 = ((*pucTemp) & 0X80)>>7;
           pxIWUPInfo->ucIWUPLen  = ucIELen-1;
           pucTemp2 = ++pucTemp;
           pucTemp1+=2;//to IWUP Info location
           if( pxIWUPInfo->ucIWUPLen <= sizeof( x_IFX_DECT_IE_IWUPacket)-2)
           {
             memcpy(pucTemp1,pucTemp2,(pxIWUPInfo->ucIWUPLen));
             return IFX_SUCCESS;
           }
           return IFX_FAILURE;
         }
         else//3a present
         {
           const uchar8 *pucTemp2= pucTemp;
           pxIWUPInfo->ucIWUPLen = ucIELen - 2;
           if( ucIELen <= sizeof( x_IFX_DECT_IE_IWUPacket))
           {
             memcpy(pucTemp1,pucTemp2,ucIELen);
             return IFX_SUCCESS;
           }
         }
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_EscapeToProprietaryGet
  * Description       :  A function used to fetch the contents of the
                         Escape To Proprietary IE
  * Input Value       :  IE Handler to Escape To Proprietary IE
  * Output Value      :  Pointer to the filled Escape To Proprietary content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Escape To Proprietary IE
                         content structure
 ****************************************************************************/


 e_IFX_Return IFX_DECT_IE_EscapeToProprietaryGet(uint32 uiIEHdl,
                           x_IFX_DECT_IE_EscapeToProprietary *pxETPInfo)
 {
   if((uiIEHdl!=0) && (pxETPInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_ESCAPETOPROPRIETARY)
     {
       pucTemp++; //length byte
       pxETPInfo->ucUSCLen  = (*pucTemp)-1;
       if((*pucTemp!=0) && ( *pucTemp <= sizeof(x_IFX_DECT_IE_EscapeToProprietary))) //check for content length
       {
         uchar8 *pucTemp1 = (uchar8 *)pxETPInfo;
         const uchar8 *pucTemp2= ++pucTemp; //1st content byte
         memcpy(pucTemp1,pucTemp2,pxETPInfo->ucUSCLen + 1);
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_CallingPartyNameGet
  * Description       :  A function used to fetch the contents of the
                         Calling Party Name IE
  * Input Value       :  IE Handler to Calling Party Name IE
  * Output Value      :  Pointer to the filled Calling Party Name content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Calling Party Name IE
                         content structure
 ****************************************************************************/
            

              
           
 e_IFX_Return IFX_DECT_IE_CallingPartyNameGet(uint32 uiIEHdl,
                           x_IFX_DECT_IE_CallingPartyName *pxCgPNameInfo)
 {
   if((uiIEHdl!=0) && (pxCgPNameInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_CALLINGPARTYNAME)
     {
       pucTemp++; //length byte
       pxCgPNameInfo->ucCPNLen  = (*pucTemp)-1;
       if((*pucTemp!=0) && (*pucTemp <= sizeof(x_IFX_DECT_IE_CallingPartyName))) //check for content length
       {
         uchar8 *pucTemp1 = (uchar8 *)pxCgPNameInfo;
	 const uchar8 *pucTemp2= ++pucTemp; //1st content byte
         memcpy(pucTemp1,pucTemp2,(pxCgPNameInfo->ucCPNLen) + 1);
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_WindowSizeGet
  * Description       :  A function used to fetch the contents of the
                         Window Size IE
  * Input Value       :  IE Handler to Window Size IE
  * Output Value      :  Pointer to the filled Window Size content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Window Size IE
                         content structure
 ****************************************************************************/
           
                

 e_IFX_Return IFX_DECT_IE_WindowSizeGet(uint32 uiIEHdl,
                           x_IFX_DECT_IE_WindowSize *pxWSInfo)
 {
   if((uiIEHdl!=0) && (pxWSInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_WINDOWSIZE)
     {
       uchar8 ucLen;
       uchar8 ucLen1=0;
       pucTemp++; //length byte
       ucLen= *pucTemp;
       if((*pucTemp)!=0) //check for content length
       {
         pucTemp++; // byte 3
         pxWSInfo->ucWSVF = *pucTemp & 0X7F;
         pxWSInfo->ucExtn3= (*pucTemp)>>7;
         ucLen1++;
         if(((*pucTemp) & 0X80)==0) //check if 3a present 
         {//fill 3a
           pucTemp++;
           pxWSInfo->ucWSVC = *pucTemp & 0X7F; 
           pxWSInfo->ucExtn3a= (*pucTemp)>>7;
           ucLen1++;
           if(((*pucTemp) & 0X80)==0) //check if 3b present 
           {//fill 3b
             pucTemp++;
             pxWSInfo->ucMPDULF=(*pucTemp) & 0X7F;
             pxWSInfo->ucExtn3b= (*pucTemp)>>7;
             ucLen1++;
             if(((*pucTemp) & 0X80)==0) //check if 3c present 
             {//fill 3c
               pucTemp++;
               pxWSInfo->ucSDULAPUTF= (*pucTemp) & 0X7F;
               pxWSInfo->ucExtn3c=  (*pucTemp)>>7;
               ucLen1++;
             }
           }
         }
         if(ucLen>ucLen1)//octet group 4 present 
         {
           pxWSInfo->ucOctet4=1;
           pucTemp++;//octet 4
           pxWSInfo->ucWSVB = (*pucTemp) & 0X7F;
           pxWSInfo->ucExtn4 = (*pucTemp)>>7; 
           if(((*pucTemp)>>7)==0) //check if 4a present
           {//fill 4a
             pucTemp++;
             pxWSInfo->ucWSVCB = (*pucTemp) & 0X7F; 
             pxWSInfo->ucExtn4a= (*pucTemp)>> 7;
             if(((*pucTemp)>>7)==0) //check if 4b present
             {//fill 4b
               pucTemp++;
               pxWSInfo->ucMPDULB=(*pucTemp) & 0X7F;
               pxWSInfo->ucExtn4b= (*pucTemp)>>7;
               if(((*pucTemp)>>7)==0) //check if 4c present
               {//fill 4c
                 pucTemp++;
                 pxWSInfo->ucSDULAPUTB= (*pucTemp) & 0X7F;
                 pxWSInfo->ucExtn4c= (*pucTemp)>>7;
               }
             }
           }
         }
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_CallAttributesGet
  * Description       :  A function used to fetch the contents of the
                         Call Attributes IE
  * Input Value       :  IE Handler to Call Attributes IE
  * Output Value      :  Pointer to the filled Call Attributes content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Call Attributes IE
                         content structure
 ****************************************************************************/
 
          e_IFX_Return IFX_DECT_IE_CallAttributesGet(uint32 uiIEHdl,
                           x_IFX_DECT_IE_CallAttributes *pxCallAInfo)
 {
   if((uiIEHdl!=0) && (pxCallAInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_CALLATTRIBUTES)
     {
       pucTemp++; //length byte
       if((*pucTemp)!=0) //check for content length
       {
         pucTemp++; //octet 3
         pxCallAInfo->ucNWKLA = (*pucTemp) & 0X3F;
         pxCallAInfo->ucCS    = (*pucTemp & 0X60) >> 5;
         pxCallAInfo->ucDefault1=(*pucTemp) >> 7;
         pucTemp++; //octet 4
         pxCallAInfo->ucCPR = *pucTemp & 0X0F;
         pxCallAInfo->ucCPC = (*pucTemp & 0X70) >> 4;
         pxCallAInfo->ucDefault2= (*pucTemp) >> 7;
         pucTemp++; //octet 5
         pxCallAInfo->ucLUID= (*pucTemp) & 0X1F;
         pxCallAInfo->ucUPS= (*pucTemp & 0X60) >> 5;
         pxCallAInfo->ucExtn5= *pucTemp >>7;
         if(pxCallAInfo->ucUPS == 0) //Symmetric
         {
           pxCallAInfo->ucLUIDFTP= pxCallAInfo->ucLUID;
           pucTemp++;
           pxCallAInfo->ucUPFT= *pucTemp & 0X0F;
           pxCallAInfo->ucUPC=  (*pucTemp & 0X70) >> 4;
           pxCallAInfo->ucExtn6= *pucTemp >> 7;
           pxCallAInfo->ucUPFTFTP= pxCallAInfo->ucUPFT;
           pxCallAInfo->ucUPCFTP=  pxCallAInfo->ucUPC;
           pucTemp--;
         }
         else if(pxCallAInfo->ucUPS == 2)//not symmetric
  {
           pucTemp++;
           pxCallAInfo->ucLUIDFTP = (*pucTemp) & 0X1F;
           pxCallAInfo->ucS = (*pucTemp & 0X60) >> 5;
           pxCallAInfo->ucExtn5a= (*pucTemp) >> 7;
           pucTemp++;
           pxCallAInfo->ucUPFT = (*pucTemp) & 0X0F;
           pxCallAInfo->ucUPC = (*pucTemp & 0X70) >> 4;
           pxCallAInfo->ucExtn6= (*pucTemp) >> 7;
           pucTemp++;
           pxCallAInfo->ucUPFTFTP= (*pucTemp) & 0X0F;
           pxCallAInfo->ucUPCFTP=  (*pucTemp & 0X70) >> 4;
           pxCallAInfo->ucExtn6a=(*pucTemp)>>7;
         }
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }


  


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_ConnectionAttributesGet
  * Description       :  A function used to fetch the contents of the
                         Connection Attributes IE
  * Input Value       :  IE Handler to Connection Attributes IE
  * Output Value      :  Pointer to the filled Connection Attributes content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Connection Attributes IE
                         content structure
 ****************************************************************************/
 
          e_IFX_Return IFX_DECT_IE_ConnectionAttributesGet(uint32 uiIEHdl,
                           x_IFX_DECT_IE_ConnectionAttributes *pxConAInfo)
 {
   if((uiIEHdl!=0) && (pxConAInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)((*pucTemp) & 0XFF) == IFX_DECT_IE_CONNECTIONATTRIBUTES)
     {
       pucTemp++; //length byte
       if((*pucTemp)!=0) //check for content length
       { pucTemp++;//octet 3
         pxConAInfo->ucCID= (*pucTemp) & 0X0F;
         pxConAInfo->ucSymmetry = ((*pucTemp) & 0X70) >> 4;
         pxConAInfo->ucDefault1 = (*pucTemp)>>7;
         pucTemp++;//octet 4
         pxConAInfo->ucTBPFD = (*pucTemp) & 0X1F;
         pxConAInfo->ucDefault2 = ((*pucTemp) & 0X60) >> 5;
         pxConAInfo->ucExtn4 = (*pucTemp) >> 7;
         if(pxConAInfo->ucExtn4 == 0)
         {//octet 4a
           pucTemp++;
           pxConAInfo->ucMBPFD = (*pucTemp) & 0X1F;
           pxConAInfo->ucDefault3 = ((*pucTemp) & 0X60) >> 5;
           pxConAInfo->ucExtn4a = (*pucTemp) >> 7;
           if(pxConAInfo->ucExtn4a == 0)
           {//octet 4b
             pucTemp++;
             pxConAInfo->ucTBFPD = (*pucTemp) & 0X1F;
             pxConAInfo->ucDefault4 = ((*pucTemp) & 0X60) >> 5;
             pxConAInfo->ucExtn4b = (*pucTemp) >> 7;
             if(pxConAInfo->ucExtn4b == 0)
             {//octet 4c
               pucTemp++;
               pxConAInfo->ucMBFPD = (*pucTemp) & 0X1F;
               pxConAInfo->ucDefault5 = ((*pucTemp) & 0X60) >> 5;
               pxConAInfo->ucExtn4c = (*pucTemp) >> 7;
             }
           }
         }
 pucTemp++;//octet 5
         pxConAInfo->ucMACS=*pucTemp & 0X0F;
         pxConAInfo->ucSS = ((*pucTemp) & 0X70)>>4;
         pxConAInfo->ucExtn5 = *pucTemp >> 7;
         if(pxConAInfo->ucExtn5 == 0)
         {//5a present
           pucTemp++;
           pxConAInfo->ucMACSFP = *pucTemp & 0X0F;
           pxConAInfo->ucDefault6 = ((*pucTemp) & 0X70)>>4;
           pxConAInfo->ucExtn5a = *pucTemp >> 7;
         }
         pucTemp++;//octet 6
         pxConAInfo->ucMACPL = *pucTemp & 0X0F;
         pxConAInfo->ucCFCA = ((*pucTemp) & 0X70)>>4;
         pxConAInfo->ucExtn6 = (*pucTemp) >>7;
         if(pxConAInfo->ucExtn6 == 0)
         {//6a present
           pucTemp++;
           pxConAInfo->ucMACPLFP = *pucTemp & 0X0F;
           pxConAInfo->ucCFCAFP = ((*pucTemp) & 0X70)>>4;
           pxConAInfo->ucExtn6a = *pucTemp >> 7;
         }
         pucTemp++;//octet 7
         pxConAInfo->ucBA = *pucTemp & 0X07;
         pxConAInfo->ucSpare = (*pucTemp & 0X08)>>3;
         pxConAInfo->ucAA = (*pucTemp & 0X70)>> 4;
         pxConAInfo->ucExtn7 = *pucTemp >> 7;
         return IFX_SUCCESS;
       }
       else//no IE
       {
         return IFX_FAILURE;
       }
     }
     else// not Connection Attributes IE
     {
       return IFX_FAILURE;
     }
   }
   else// null pointer or handle
 {
     return IFX_FAILURE;
   }
}

     
         



 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_FacilityGet
  * Description       :  A function used to fetch the contents of the
                         Facility IE
  * Input Value       :  IE Handler to Facility IE
  * Output Value      :  Pointer to the filled Facility content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Facility IE
                         content structure
 ****************************************************************************/


 e_IFX_Return IFX_DECT_IE_FacilityGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_Facility *pxFacilityInfo)
 {
   if((uiIEHdl!=0) && (pxFacilityInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_FACILITY)
     {
       pucTemp++;//length byte
       if(*pucTemp==2)
       {
         uchar8 *pucTemp1 = (uchar8 *)pxFacilityInfo;
         const uchar8 *pucTemp2 = ++pucTemp;
         memcpy(pucTemp1,pucTemp2,2);
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }
 
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_MultiDisplayGet
  * Description       :  A function used to fetch the contents of the
                         Multi Display IE
  * Input Value       :  IE Handler to Multi Display IE
  * Output Value      :  Pointer to the filled Multi Display content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Multi Display IE
                         content structure
 ****************************************************************************/


 e_IFX_Return IFX_DECT_IE_MultiDisplayGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_MultiDisplay *pxMDInfo)
 {
   if((uiIEHdl!=0) && (pxMDInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_MULTIDISPLAY)
     {
       pucTemp++;//length byte
       pxMDInfo->ucDisplayLen = *pucTemp;
       if((*pucTemp!=0) && (*pucTemp<sizeof(x_IFX_DECT_IE_MultiDisplay) ))
       {
         uchar8 *pucTemp1= (uchar8 *)pxMDInfo;
         const uchar8 *pucTemp2 = ++pucTemp;
         memcpy(pucTemp1,pucTemp2,pxMDInfo->ucDisplayLen);
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }
  
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_MultiKeypadGet
  * Description       :  A function used to fetch the contents of the
                         Multi Keypad IE
  * Input Value       :  IE Handler to Multi Keypad IE
  * Output Value      :  Pointer to the filled Multi Keypad content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Multi Keypad IE
                         content structure
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_MultiKeypadGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_MultiKeypad *pxMKPInfo)
 {
   if((uiIEHdl!=0) && (pxMKPInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_MULTIKEYPAD)
     {
       pucTemp++;// skip messgid and move to length byte
       pxMKPInfo->ucKeypadLen = *pucTemp;
       if((*pucTemp!=0) && (*pucTemp<sizeof(x_IFX_DECT_IE_MultiKeypad)))
       {
         uchar8 *pucTemp1= (uchar8 *)pxMKPInfo->acKeypad;
         const uchar8 *pucTemp2 = ++pucTemp; // moved to data
         memcpy(pucTemp1,pucTemp2,pxMKPInfo->ucKeypadLen);
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_ConnectionIdentityGet
  * Description       :  A function used to fetch the contents of the
                         Connection Identity IE
  * Input Value       :  IE Handler to Connection Identity IE
  * Output Value      :  Pointer to the filled Connection Identity content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Connection Identity IE
                         content structure
 ****************************************************************************/
   
    e_IFX_Return IFX_DECT_IE_ConnectionIdentityGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_ConnectionIdentity *pxCIDInfo)
 {
   if((uiIEHdl!=0)&& (pxCIDInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)((*pucTemp)) == IFX_DECT_IE_CONNECTIONIDENTITY)
     {
       pucTemp++;// length byte
       if(((*pucTemp) != 0) && ((*pucTemp)<= 2))
       {
         pucTemp++;//octet 3
         pxCIDInfo->ucUPLID = *pucTemp & 0X0F;
         pxCIDInfo->ucCID = (*pucTemp & 0XF0) >> 4;
         if((*(pucTemp-1)) == 2)//octet 3a
         {
           pucTemp++;
           pxCIDInfo->ucLCA = *pucTemp;
         }
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }
         
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_ProgressIndicatorGet
  * Description       :  A function used to fetch the contents of the
                         Progress Indicator IE
  * Input Value       :  IE Handler to Progress Indicator IE
  * Output Value      :  Pointer to the filled Progress Indicator content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Progress Indicator IE
                         content structure
 ****************************************************************************/

 
            

 e_IFX_Return IFX_DECT_IE_ProgressIndicatorGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_ProgressIndicator *pxPIInfo)
 {
   if((uiIEHdl!=0) && (pxPIInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_PROGRESSINDICATOR)
     {
       pucTemp++;// length byte
       if(*pucTemp==2)
       {
         uchar8 *pucTemp1 = (uchar8 *)pxPIInfo;
         const uchar8 *pucTemp2 = ++pucTemp;
         memcpy(pucTemp1,pucTemp2,2);
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_ServiceChangeGet
  * Description       :  A function used to fetch the contents of the
                         Service Change IE
  * Input Value       :  IE Handler to Service Change IE
  * Output Value      :  Pointer to the filled Service Change content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Service Change IE
                         content structure
 ****************************************************************************/

           e_IFX_Return IFX_DECT_IE_ServiceChangeGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_ServiceChange *pxSCIInfo)
 {
   if((uiIEHdl!=0) && (pxSCIInfo!=0))
   {
   uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_SERVICECHANGEINFO)
     {
       pucTemp++;// length byte
       if((*(pucTemp) != 0) && (((*pucTemp) <= 3)))
       {
         pucTemp++;//octet 3
         pxSCIInfo->ucChangeMode = *pucTemp & 0X0F;
         pxSCIInfo->ucM = (*pucTemp & 0X10) >> 4;
         pxSCIInfo->ucCS = (*pucTemp & 0X60) >> 5;
         pxSCIInfo->ucExtn3 = (*pucTemp) >> 7;
         if((pxSCIInfo->ucChangeMode == 0XE || pxSCIInfo->ucChangeMode == 0XF) && (pxSCIInfo->ucExtn3==0) )
         {//octet 3a present
           pucTemp++;
           pxSCIInfo->ucECM = *pucTemp & 0X7F;
           pxSCIInfo->ucExtn3a = (*pucTemp)>>7;
         }
         if(pxSCIInfo->ucChangeMode == 8  || pxSCIInfo->ucChangeMode == 9 )
         {//octet 4 present
           pucTemp++;
           pxSCIInfo->ucBA = *pucTemp & 0X07;
           pxSCIInfo->ucR  = (*pucTemp & 0X08) >> 3;
           pxSCIInfo->ucAA = (*pucTemp & 0X70) >> 4;
           pxSCIInfo->ucDefault1=*pucTemp >> 7;
         }
         return IFX_SUCCESS;
       }
     }
   }
     return IFX_FAILURE;
 }
       
          
               
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_TimeDateGet
  * Description       :  A function used to fetch the contents of the
                         Time Date IE
  * Input Value       :  IE Handler to Time Date IE
  * Output Value      :  Pointer to the filled Time Date IE content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Time Date IE
                         content structure
 ****************************************************************************/
 
 e_IFX_Return IFX_DECT_IE_TimeDateGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_TimeDate *pxTDInfo)
 {
   if((uiIEHdl!=0) && (pxTDInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_TIMEDATE)
     {
       pucTemp++;// length byte
       pxTDInfo->ucTimeDateLen = (*pucTemp) - 1;
       if((*pucTemp !=0) && ( *pucTemp < sizeof(x_IFX_DECT_IE_TimeDate)))
       {
         uchar8 *pucTemp1 = (uchar8 *)pxTDInfo;
         const uchar8 *pucTemp2 = ++pucTemp;
         memcpy(pucTemp1,pucTemp2,(pxTDInfo->ucTimeDateLen) + 1);
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_LocationAreaGet
  * Description       :  A function used to fetch the contents of the
                         Location Area IE
  * Input Value       :  IE Handler to Location Area IE
  * Output Value      :  Pointer to the filled Location Area IE content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Location Area IE
                         content structure
 ****************************************************************************/
    
     e_IFX_Return IFX_DECT_IE_LocationAreaGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_LocationArea *pxLAInfo)
 {
   if((uiIEHdl!=0) && (pxLAInfo!=0))
   {
   uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)((*pucTemp) & 0XFF) == IFX_DECT_IE_LOCATIONAREA)
     {
       pucTemp++;// length byte
       if(*pucTemp !=0)
       {
         pucTemp++; // octet 3
         pxLAInfo->ucLAL = *pucTemp & 0X3F;
         pxLAInfo->ucLIType  = (*pucTemp & 0XC0) >> 6;
         if((pxLAInfo->ucLIType != 1) && (*(pucTemp-1)!=1))
         { //3a and rest of octets present
           uchar8 *pucTemp1 = (uchar8 *)pxLAInfo;
           const uchar8 *pucTemp2= (++pucTemp);
           if( *(pucTemp-2) <= sizeof( x_IFX_DECT_IE_LocationArea))
           {
             memcpy(pucTemp1+1,pucTemp2,(*(pucTemp-2)-1));
             return IFX_SUCCESS;
           }
           else
           {
             return IFX_FAILURE;
           }
         }
         return IFX_SUCCESS;
       }
     }
   }
     return IFX_FAILURE;
 }

           
    
               
        
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_AuthTypeGet
  * Description       :  A function used to fetch the contents of the
                         Auth Type IE
  * Input Value       :  IE Handler to Auth Type IE
  * Output Value      :  Pointer to the filled Auth Type IE content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Auth Type IE
                         content structure
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_AuthTypeGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_AuthType *pxATInfo)
 {
   if((uiIEHdl!=0) && (pxATInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_AUTHTYPE)
     {
       pucTemp++;// length byte
       if(*pucTemp !=0)
       {
         pucTemp++; // 1st content byte
         pxATInfo->ucAAI = *pucTemp;
         if(pxATInfo->ucAAI == 0X7F)
         {//octet 3a present
           pucTemp++;
           pxATInfo->ucPAI = *pucTemp;
         }
         pucTemp++;
         pxATInfo->ucAKN  = (*pucTemp) & 0X0F;
         pxATInfo->ucAKT  = ((*pucTemp) & 0XF0) >> 4;
         pucTemp++;
         pxATInfo->ucCKN  = (*pucTemp) & 0X0F;
         pxATInfo->ucUPC  = ((*pucTemp) & 0X10) >> 4;
         pxATInfo->ucTXC  = ((*pucTemp) & 0X20) >> 5;
         pxATInfo->ucDefault1 = ((*pucTemp) & 0X40)>>6;
         pxATInfo->ucINC  = (*pucTemp) >> 7;
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_CipherGet
  * Description       :  A function used to fetch the contents of the
                         Cipher  IE
  * Input Value       :  IE Handler to Cipher  IE
  * Output Value      :  Pointer to the filled Cipher  IE content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Cipher  IE
                         content structure
 ****************************************************************************/

            e_IFX_Return IFX_DECT_IE_CipherGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_Cipher *pxCipherInfo)
 {
   if((uiIEHdl!=0) && (pxCipherInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_CIPHERINFO)
     {
       pucTemp++;// length byte
       if(((*pucTemp) !=0) && ((*pucTemp)==3 || ((*pucTemp) == 2)))
       {//length field correct
         pucTemp++; // octet 3
         pxCipherInfo->ucCAI = *pucTemp & 0X7F;
         pxCipherInfo->ucYN  = *pucTemp >> 7;
         if((pxCipherInfo->ucCAI == 0X7F) && (*(pucTemp-1)==2))
         {//bits not filled properly
           return IFX_FAILURE;
         }
         if((pxCipherInfo->ucCAI == 0X7F) && (*(pucTemp-1)!=2))
         {//octet 3a present
           pucTemp++;
           pxCipherInfo->ucPAI = *pucTemp;
         }
         pucTemp++;
         pxCipherInfo->ucCKN  = *pucTemp & 0X0F;
         pxCipherInfo->ucCKT  = (*pucTemp & 0XF0) >> 4;
         return IFX_SUCCESS;
       }
     }
   }
     return IFX_FAILURE;
 }
    
           
          
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetupCapabilityGet
  * Description       :  A function used to fetch the contents of the
                         Setup Capability  IE
  * Input Value       :  IE Handler to Setup Capability  IE
  * Output Value      :  Pointer to the filled Setup Capability IE content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Setup Capability IE
                         content structure
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_SetupCapabilityGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_SetupCapability *pxSCInfo)
 {
   if((uiIEHdl!=0) && (pxSCInfo!=0))
   {
   uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_SETUPCAPABILITY)
     {
       uchar8 ucLen=0;
       pucTemp++;// octet 2
       ucLen=*pucTemp;
       if(*pucTemp !=0)
       {
         pucTemp++;//octet 3
         pxSCInfo->ucPage= *pucTemp & 0X03;
         pxSCInfo->ucSetup= (*pucTemp & 0X0C)>>2;
         pxSCInfo->ucPD= (*pucTemp & 0X70)>>4;
         pxSCInfo->ucExtn3=*pucTemp >> 7;
         if(pxSCInfo->ucExtn3==0)
         {
           pucTemp++;//octet 3a
           pxSCInfo->ucDefault1 = *pucTemp;
           pxSCInfo->ucSpareLen = ucLen-2;
         }
         else
         {
           pxSCInfo->ucSpareLen = ucLen-1;
         }
         if((pxSCInfo->ucSpareLen>0) && (pxSCInfo->ucSpareLen <= 250))//spare bits present
         {
           const uchar8 *pucTemp2;//octet 4
           uchar8 *pucTemp1;
           pucTemp++;//octet 4
           pucTemp1= (uchar8 *)(pxSCInfo->acSpare);
           pucTemp2=pucTemp;//octet 4
	   memcpy( pucTemp1, pucTemp2, pxSCInfo->ucSpareLen);
         }
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }
   
           


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_ModelIdentifierGet
  * Description       :  A function used to fetch the contents of the
                         Model Identifier IE
  * Input Value       :  IE Handler to Model Identifier IE
  * Output Value      :  Pointer to the filled Model Identifier IE content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Model Identifier IE
                         content structure
 ****************************************************************************/


 e_IFX_Return IFX_DECT_IE_ModelIdentifierGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_ModelIdentifier *pxMIInfo)
 {
   if((uiIEHdl!=0) && (pxMIInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_MODELIDENTIFIER)
     {
       pucTemp++;// length byte
       pxMIInfo->ucModelValueLen = *pucTemp;
       if((*pucTemp!=0) && (*pucTemp < sizeof(x_IFX_DECT_IE_ModelIdentifier)))
       {
         uchar8 *pucTemp1 = (uchar8 *)pxMIInfo;
         const uchar8 *pucTemp2 = ++pucTemp;
         memcpy(pucTemp1,pucTemp2,pxMIInfo->ucModelValueLen);
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_DurationGet
  * Description       :  A function used to fetch the contents of the
                         Duration IE
  * Input Value       :  IE Handler to Duration IE
  * Output Value      :  Pointer to the filled Duration IE content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Duration IE
                         content structure
 ****************************************************************************/
              
 e_IFX_Return IFX_DECT_IE_DurationGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_Duration *pxDInfo)
 {
   if((uiIEHdl!=0) && (pxDInfo!=0))
   {
   uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_DURATION)
     {
       pucTemp++;// length byte
       if(*pucTemp != 0)
       {
         pucTemp++;
         pxDInfo->ucTimeLimits=*pucTemp & 0X0F;
         pxDInfo->ucLockLimits=(*pucTemp & 0X70) >> 4;
         pxDInfo->ucExtn3 = *pucTemp >>7;
         if(pxDInfo->ucTimeLimits == 1 || pxDInfo->ucTimeLimits == 2 ||  pxDInfo->ucExtn3==0)
         {
           pucTemp++;
           pxDInfo->ucTimeDuration = *pucTemp;
         }
         return IFX_SUCCESS;
       }
     }
   }
     return IFX_FAILURE;
 }

           

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_RANDGet
  * Description       :  A function used to fetch the contents of the
                         RAND IE
  * Input Value       :  IE Handler to RAND IE
  * Output Value      :  Pointer to the filled RAND IE content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the RAND IE
                         content structure
 ****************************************************************************/


 e_IFX_Return IFX_DECT_IE_RANDGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_RAND *pxRANDInfo)
 {
   if((uiIEHdl!=0) && (pxRANDInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp)  == IFX_DECT_IE_RAND)
     {
       pucTemp++;// length byte
       pxRANDInfo->ucRANDFieldLen = *pucTemp;
       if((*pucTemp!=0) && (*pucTemp < sizeof(x_IFX_DECT_IE_RAND) ) )
       {
         uchar8 *pucTemp1 = (uchar8 *)pxRANDInfo;
         const uchar8 *pucTemp2 = ++pucTemp;
         memcpy(pucTemp1,pucTemp2,pxRANDInfo->ucRANDFieldLen);
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_RESGet
  * Description       :  A function used to fetch the contents of the
                         RES IE
  * Input Value       :  IE Handler to RES IE
  * Output Value      :  Pointer to the filled RES IE content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the RES IE
                         content structure
 ****************************************************************************/

 
 e_IFX_Return IFX_DECT_IE_RESGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_RES *pxRESInfo)
 {
   if((uiIEHdl!=0) && (pxRESInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_RES)
     {
       pucTemp++;// length byte
       pxRESInfo->ucRESFieldLen = *pucTemp;
       if((*pucTemp!=0) && ( *pucTemp < sizeof(x_IFX_DECT_IE_RES)))
       {
         uchar8 *pucTemp1 = (uchar8 *)pxRESInfo;
         const uchar8 *pucTemp2 = ++pucTemp;
         memcpy(pucTemp1,pucTemp2,pxRESInfo->ucRESFieldLen);
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_RSGet
  * Description       :  A function used to fetch the contents of the
                         RS IE
  * Input Value       :  IE Handler to RS IE
  * Output Value      :  Pointer to the filled RS IE content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the RS IE
                         content structure
 ****************************************************************************/


 e_IFX_Return IFX_DECT_IE_RSGet(uint32 uiIEHdl,
                                     x_IFX_DECT_IE_RS *pxRSInfo)
 {
   if((uiIEHdl!=0) && (pxRSInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp)  == IFX_DECT_IE_RS)
     {
       pucTemp++;// length byte
       pxRSInfo->ucRSFieldLen = *pucTemp;
       if((*pucTemp!=0) && (*pucTemp<sizeof(x_IFX_DECT_IE_RS) ))
       {
         uchar8 *pucTemp1 = (uchar8 *)pxRSInfo;
         const uchar8 *pucTemp2 = ++pucTemp;
         memcpy(pucTemp1,pucTemp2,pxRSInfo->ucRSFieldLen);
         return IFX_SUCCESS;
       }
     }
   }
   return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_IWUAttributesGet
  * Description       :  A function used to fetch the contents of the
                         IWU Attributes IE
  * Input Value       :  IE Handler to IWU Attributes IE
  * Output Value      :  Pointer to the filled IWU Attributes IE content
                         structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the IWU Attributes IE
                         content structure
 ****************************************************************************/

            
 e_IFX_Return IFX_DECT_IE_IWUAttributesGet(uint32 uiIEHdl,
                     x_IFX_DECT_IE_IWUAttributes *pxIWUAInfo)
 {
   if((uiIEHdl!=0) && (pxIWUAInfo!=0))
   {
     uchar8 *pucTemp=(uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)((*pucTemp) & 0XFF) == IFX_DECT_IE_IWUATTRIBUTES)
     {
       uchar8 ucIELen;//IE content length
       pucTemp++;//octet 2
       ucIELen = *pucTemp;//IE content length
       if(*pucTemp!=0)
       { pucTemp++;//octet 3
         pxIWUAInfo->ucProfileOrITC = (*pucTemp) & 0X1F;
         pxIWUAInfo->ucCodeStd=(*pucTemp & 0X60)>>5;
         pxIWUAInfo->ucDefault1= (*pucTemp)>>7;
         pucTemp++;//octet 4
         if(pxIWUAInfo->ucCodeStd == 0)//DECT Coding
         {
           pxIWUAInfo->uxDectOrProf.xDectSS.ucECT = *pucTemp & 0X0F;
           pxIWUAInfo->uxDectOrProf.xDectSS.ucNI = (*pucTemp & 0X70) >> 4;
           pxIWUAInfo->uxDectOrProf.xDectSS.ucDefault2 = (*pucTemp) >> 7;
           pucTemp++;//octet 5
           pxIWUAInfo->uxDectOrProf.xDectSS.ucITR = *pucTemp & 0X1F;
           pxIWUAInfo->uxDectOrProf.xDectSS.ucTM = (*pucTemp & 0X60) >> 5;
           pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5 = (*pucTemp) >> 7;
           if((pxIWUAInfo->uxDectOrProf.xDectSS.ucITR == 0X1F) ||(pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5 == 0))
           //if ITR is 1F then 5a shall follow
           {//octet 5a present
             pucTemp++;
             pxIWUAInfo->uxDectOrProf.xDectSS.ucRM = *pucTemp & 0X1F;
             pxIWUAInfo->uxDectOrProf.xDectSS.ucUR = (*pucTemp & 0X60) >> 5;
             pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5a = (*pucTemp) >> 7;
             if((pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5a == 0))
             {//octet 5b present
               pucTemp++;
               pxIWUAInfo->uxDectOrProf.xDectSS.ucEstab = *pucTemp & 0X03;
               pxIWUAInfo->uxDectOrProf.xDectSS.ucConfig = (*pucTemp & 0X0C) >> 2;
               pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure = (*pucTemp & 0X70) >> 4;
               pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5b = (*pucTemp) >> 7;
               if((pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5b == 0))
                 {//octet 5c present
                 pucTemp++;
                 pxIWUAInfo->uxDectOrProf.xDectSS.ucITRDO = *pucTemp & 0X1F;
                 pxIWUAInfo->uxDectOrProf.xDectSS.ucSymmetry = (*pucTemp & 0X60) >> 5;
                 pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5c = (*pucTemp) >> 7;
                 pucTemp++; //octet 5d present as 5c is present
                 pxIWUAInfo->uxDectOrProf.xDectSS.ucRMDO = *pucTemp & 0X1F;
                 pxIWUAInfo->uxDectOrProf.xDectSS.ucURDO = (*pucTemp & 0X60) >> 5;
                 pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5d = (*pucTemp) >> 7;
               }
             }
             if((pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5a == 0) ||
                        pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure == 0)
             {//Default Table
               if(((pxIWUAInfo->uxDectOrProf.xDectSS.ucTM) == 0) &&
                  ((pxIWUAInfo->ucProfileOrITC==0) ||
                   (pxIWUAInfo->ucProfileOrITC==9) ||
                   (pxIWUAInfo->ucProfileOrITC==0X10)||
                   (pxIWUAInfo->ucProfileOrITC==0X11)||
                   (pxIWUAInfo->ucProfileOrITC==0X14)||
                   (pxIWUAInfo->ucProfileOrITC==0X18)))
               {
                 (pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure)= 1;
                 *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure)) << 4);
               }
               if(((pxIWUAInfo->uxDectOrProf.xDectSS.ucTM) == 2) &&
                  (pxIWUAInfo->ucProfileOrITC==0X08))
               {
                 (pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure)= 4;
                 *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure)) << 4);
               }
             }
           }
           pucTemp++;//octet 6
           pxIWUAInfo->uxDectOrProf.xDectSS.ucUPID = *pucTemp & 0X1F;
           pxIWUAInfo->uxDectOrProf.xDectSS.ucDefault3 = (*pucTemp & 0X60) >> 5;
           pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn6 = (*pucTemp) >> 7;
           if(pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn6 == 0)
           {//octet 6a present
             pucTemp++;
             pxIWUAInfo->uxDectOrProf.xDectSS.ucL3PID = *pucTemp & 0X1F;
             pxIWUAInfo->uxDectOrProf.xDectSS.ucDefault4 = (*pucTemp & 0X60) >> 5;
             pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn6a = (*pucTemp) >> 7;
             if(pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn6a == 0)
             {//octet 6b present
               pucTemp++;
               pxIWUAInfo->uxDectOrProf.xDectSS.ucL2PID = *pucTemp & 0X1F;
               pxIWUAInfo->uxDectOrProf.xDectSS.ucDefault5 = (*pucTemp & 0X60) >> 5;
               pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn6b = (*pucTemp) >> 7;
             }
           }
           return IFX_SUCCESS;
         }
         else if(pxIWUAInfo->ucCodeStd == 1)//Profile Defined Coding
         {//octet 4
           pxIWUAInfo->uxDectOrProf.xProfileSS.ucPST = *pucTemp & 0X0F;
           pxIWUAInfo->uxDectOrProf.xProfileSS.ucNI = (*pucTemp & 0X70) >> 4;
           pxIWUAInfo->uxDectOrProf.xProfileSS.ucDefault2 = (*pucTemp) >> 7;
           pucTemp++;//octet 5
           pxIWUAInfo->uxDectOrProf.xProfileSS.ucMaxSDUSizeM = *pucTemp & 0X7F;
           pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5 = (*pucTemp) >> 7;
           #if 0 // #ifndef CONFIG_UPDATE_SUOTA
           if(pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5 == 0)
           #endif
           {
             pucTemp++; // octet 5a
             pxIWUAInfo->uxDectOrProf.xProfileSS.ucMaxSDUSizeL = *pucTemp & 0X7F;
             pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5a = (*pucTemp) >> 7;
           }
           #if 1 // #ifdef CONFIG_UPDATE_SUOTA
           if (pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5a == 0)
           {
              pucTemp++;//octet 5b
              pxIWUAInfo->uxDectOrProf.xProfileSS.ucMaxSDUSizeM2 = *pucTemp & 0X7F;
              pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5b = (*pucTemp) >> 7;
              pucTemp++;//octet 5c
              pxIWUAInfo->uxDectOrProf.xProfileSS.ucMaxSDUSizeL2 = *pucTemp & 0X7F;
              pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5c = (*pucTemp) >> 7;
           }

           pxIWUAInfo->uxDectOrProf.xProfileSS.ucDefault3 = 0;
           pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSA = 0;
           pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSAa =0;
           pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSAb =0;
           pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSAc =0;
           if(pxIWUAInfo->ucCodeStd == 0x01 && // IFX_DECT_DPSU_PROFILE_DEFINED_CODING
              pxIWUAInfo->ucProfileOrITC == 0x00 && // IFX_DECT_DPSU_DPRS
              pxIWUAInfo->uxDectOrProf.xProfileSS.ucPST == 0x08 /* IFX_DECT_DPSU_DGMEP_PROFILE_SUBTYPE */) {
              if((ucIELen >= 10) || ((ucIELen >= 8)  && (pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5a == 1))) {
                 pucTemp++; //octet 6
                 pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSA = *pucTemp & 0X7F;
                 pxIWUAInfo->uxDectOrProf.xProfileSS.ucDefault3 = 1;
                 pucTemp++; //octet 6a
                 pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSAa = *pucTemp;
                 pucTemp++; //octet 6b
                 pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSAb = *pucTemp;
                 pucTemp++; //octet 6c
                 pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSAc = *pucTemp;
              }
           }
           #else
           if(ucIELen==5 || (ucIELen==4 && (pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5 == 1)))
           {//octet 6 present
             pucTemp++;
             pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSA = *pucTemp & 0X7F;
             pxIWUAInfo->uxDectOrProf.xProfileSS.ucDefault3 = (*pucTemp) >> 7;
             pxIWUAInfo->uxDectOrProf.xProfileSS.ucOctet6 =1;

           }
           else
           {
             pxIWUAInfo->uxDectOrProf.xProfileSS.ucOctet6 =0;
           }
           #endif
         return IFX_SUCCESS;
         }
       }
     }
   }
   return IFX_FAILURE;
 }



 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_TimerRestartGet
  * Description       :  A function used to fetch the contents of the
                         Timer Restart IE
  * Input Value       :  IE Handler to Timer Restart IE
  * Output Value      :  Pointer to the filled Timer Restart IE content
                         variable
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Timer Restart IE
                         content variable
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_TimerRestartGet(uint32 uiIEHdl, uchar8 *pucTRInfo)
 {
   if((uiIEHdl!=0) && (pucTRInfo!=0))
   {
     uchar8 *pucTemp = (uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_TIMERRESTART)
     {
       pucTemp++;
       *pucTRInfo = *pucTemp;
       return IFX_SUCCESS;
     }
   }
     return IFX_FAILURE;
 }
        
        
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_UserTPUIGet
  * Description       :  A function used to fetch the contents of the
                         User TPUI IE
  * Input Value       :  IE Handler to User TPUI IE
  * Output Value      :  Pointer to the filled User TPUI IE content
                         variable
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the User TPUI IE
                         content variable
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_UserTPUIGet(uint32 uiIEHdl, uchar8 *pucUTInfo)
 {
   if((uiIEHdl!=0) && (pucUTInfo!=0))
   {
     uchar8 *pucTemp = (uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_USETPUI)
     // check whether Use TPUI
     {
       *pucUTInfo = *pucTemp;
       return IFX_SUCCESS;
     }
   }
     return IFX_FAILURE;
 }

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_RepeatIndicatorGet
  * Description       :  A function used to fetch the contents of the
                         Repeat Indicator IE
  * Input Value       :  IE Handler to Repeat Indicator IE
  * Output Value      :  Pointer to the filled Repeat Indicator IE content
                         variable
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Repeat Indicator IE
                         content variable
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_RepeatIndicatorGet(uint32 uiIEHdl, uchar8 *pucRIInfo)
 {
   if((uiIEHdl!=0) && (pucRIInfo!=0))
   {
     uchar8 *pucTemp = (uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)((*pucTemp) & 0XF0) == IFX_DECT_IE_REPEATINDICATOR)
     // check whether repeat indicator
     {
       *pucRIInfo = (*pucTemp);//Check 1) *pucRIInfo = (*pucTemp) | 0X0F
       return IFX_SUCCESS;
     }
   }
     return IFX_FAILURE;
 }
  
     
          
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_RejectReasonGet
  * Description       :  A function used to fetch the contents of the
                         Reject Reason IE
  * Input Value       :  IE Handler to Reject Reason IE
  * Output Value      :  Pointer to the filled Reject Reason IE content
                         variable
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Reject Reason IE
                         content variable
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_RejectReasonGet(uint32 uiIEHdl, uchar8 *pucRejRsnInfo)
 {
   if((uiIEHdl!=0) && (pucRejRsnInfo!=0))
   {
     uchar8 *pucTemp = (uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp) == IFX_DECT_IE_REJECTREASON)
     // check whether Reject Reason
     {
       pucTemp++;//octet 2
       if(*pucTemp != 0) //content present
       {
         pucTemp++;//octet 3
         *pucRejRsnInfo = *pucTemp;
         return IFX_SUCCESS;
       }
     }
   }
     return IFX_FAILURE;
 }
      
          
         
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_ServiceClassGet
  * Description       :  A function used to fetch the contents of the
                         Service Class IE
  * Input Value       :  IE Handler to Service Class IE
  * Output Value      :  Pointer to the filled Service Class IE content
                         variable
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Service Class IE
                         content variable
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_ServiceClassGet(uint32 uiIEHdl, uchar8 *pucSCInfo)
 {
   if((uiIEHdl!=0) && (pucSCInfo!=0))
   {
     uchar8 *pucTemp = (uchar8 *)uiIEHdl;
     if((e_IFX_DECT_IE)(*pucTemp)== IFX_DECT_IE_SERVICECLASS)
     // check whether Service Class
     {
       pucTemp++;
       if(*pucTemp != 0) //check whether content present
       {
         pucTemp++;
         *pucSCInfo = *pucTemp;
         return IFX_SUCCESS;
       }
     }
   }
     return IFX_FAILURE;
 }

/*****************************************************************************
  * Function Name     :  IFX_DECT_IE_EventNotifyGet
  * Description       :  A function used to fetch the contents of the
	                     Events Notification IE
  * Input Value       :  IE Handler to Events Notification IE
  * Output Value      :  Pointer to the filled Events Notification content
	                     structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
	                     Handler and filled in the Events Notification IE
					     content structure
****************************************************************************/
													   
e_IFX_Return IFX_DECT_IE_EventNotifyGet(uint32 uiIEHdl,x_IFX_DECT_IE_EventNotify *pxENInfo){

  int32 i = 0;
  uchar8 ucIELen = 0;
  uchar8 ucEventCount = 0;
  if((uiIEHdl != 0) && (pxENInfo != NULL)){
           
    uchar8 *pucTemp = (uchar8*)uiIEHdl;
	if((e_IFX_DECT_IE)((*pucTemp) & 0X7F) == IFX_DECT_IE_EVENTNOTIFY){
	 
	  pucTemp++;	   
	  if(*pucTemp != 0){
	   
	    ucIELen = *pucTemp;
  
        while(i < ucIELen){//Check. 		
		
		  pucTemp++;
		  pxENInfo->axEvent[ucEventCount].ucEventType = *pucTemp & 0X7F;
		  pxENInfo->axEvent[ucEventCount].ucIsEventSubType = (*pucTemp) >> 7;
		  i++;
		  if(pxENInfo->axEvent[ucEventCount].ucIsEventSubType == 0){
		 
		    pucTemp++;
		    pxENInfo->axEvent[ucEventCount].ucEventSubType = *pucTemp & 0X7F;
		    pxENInfo->axEvent[ucEventCount].ucDefault1 = 1;
			i++;
		  }  
	  	  pucTemp++;
		  pxENInfo->axEvent[ucEventCount].ucEventMultiFirstByte = *pucTemp & 0X7F;
		  pxENInfo->axEvent[ucEventCount].ucEventMultiExtn = (*pucTemp) >> 7;
		  i++;
		  if(pxENInfo->axEvent[ucEventCount].ucEventMultiExtn == 0){
		   
		    pucTemp++;
	        pxENInfo->axEvent[ucEventCount].ucEventMultiSecondByte = *pucTemp & 0X7F;
			i++;
		
		  }else{

			pxENInfo->axEvent[ucEventCount].ucEventMultiSecondByte = 0;
		   }
		  if(i > ucIELen){
		    return IFX_FAILURE;
		  }	
		  ucEventCount++;
		}  
		pxENInfo->ucNoOfEvents = ucEventCount;
	    return IFX_SUCCESS;	
	  }
    }
  }
  return IFX_FAILURE;
}


/*****************************************************************************
  * Function Name     :  IFX_DECT_IE_CallInformationGet
  * Description       :  A function used to fetch the contents of the
	                     Call Information IE
  * Input Value       :  IE Handler to Call Information IE
  * Output Value      :  Pointer to the filled Call Information content
	                     structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
	                     Handler and filled in the Call Information IE
					     content structure
****************************************************************************/
													  
e_IFX_Return IFX_DECT_IE_CallInformationGet(uint32 uiIEHdl,x_IFX_DECT_IE_CallInfo *pxCallInfo){

  int32 i = 0;
  int32 iIndex = 0;
  uchar8 ucIDCount = 0;
  uchar8 ucIELen = 0;
  if((uiIEHdl != 0) && (pxCallInfo != NULL)){

    uchar8 *pucTemp = (uchar8*)uiIEHdl;
	if((e_IFX_DECT_IE)((*pucTemp) & 0X7F) == IFX_DECT_IE_CALLINFORMATION){

	  pucTemp++;
	  if(*pucTemp != 0){

        ucIELen = *pucTemp;
		while(iIndex < ucIELen){//Check.Alternative?
		
		  i = 0;
	      pucTemp++;
		  pxCallInfo->axID[ucIDCount].ucIDType = *pucTemp;
		  iIndex++;
		  pucTemp++;
		  pxCallInfo->axID[ucIDCount].ucIDSubType = *pucTemp;
		  iIndex++;
          pucTemp++;
		  pxCallInfo->axID[ucIDCount].axIDValue[i].ucIDValueFirstByte = *pucTemp & 0X7F;
		  pxCallInfo->axID[ucIDCount].axIDValue[i].ucIDValueExtn = (*pucTemp) >> 7;
		  iIndex++;
		  
		  while(i < IFX_DECT_IE_MAX_IDVALUE_SIZE){
		  
		    if(pxCallInfo->axID[ucIDCount].axIDValue[i].ucIDValueExtn == 0){
	     
		      pucTemp++;
		      
		      pxCallInfo->axID[ucIDCount].axIDValue[i].ucIDValueFirstByte = *pucTemp & 0X7F;
		      pxCallInfo->axID[ucIDCount].axIDValue[i].ucIDValueExtn = (*pucTemp) >> 7;
			  i++;
			  iIndex++;
            }else{
		   
		      break;
		     } 
		  }
		  if(iIndex > ucIELen){
		     return IFX_FAILURE;
		  }
								
		  ucIDCount++;
		} 
    pxCallInfo->ucNoOfIdentifiers=ucIDCount;
        return IFX_SUCCESS;
      }		
    }
  }
  return IFX_FAILURE;
}


#if 1
/*****************************************************************************
  * Function Name     :  IFX_DECT_IE_TermCapGet
  * Description       :  A function used to fetch the contents of the
	                     Terminal Capability IE
  * Input Value       :  IE Handler to Terminal Capability IE
  * Output Value      :  Pointer to the filled Terminal Capability content
	                     structure
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Contents of the IE are fetched from the given IE
                         Handler and filled in the Terminal Capability IE
						 content structure
****************************************************************************/
e_IFX_Return IFX_DECT_IE_TermCapGet(IN uint32 uiIEHdl,
                                    OUT x_IFX_DECT_IE_Term_Capability *pxTermCap){

   if((uiIEHdl != 0) && (pxTermCap != 0/*NULL*/)){//Check NULL or 0.

	 uchar8 *pucTemp = (uchar8*)uiIEHdl;
     if((e_IFX_DECT_IE)((*pucTemp) & 0X7F) == IFX_DECT_IE_TERMCAPABILITY){

	    pucTemp++;
	    if(*pucTemp != 0){
				   
         pucTemp++;
		 pxTermCap->ucDispCap = (*pucTemp) & 0X0F;
		 pxTermCap->ucToneCap = ((*pucTemp) >> 4) & 0X07;
		 pxTermCap->ucExtn3 = (*pucTemp) >> 7;
		 if(pxTermCap->ucExtn3 == 0){
		
           pucTemp++;
		   pxTermCap->ucAVOL = (*pucTemp) & 0X03;
		   pxTermCap->ucNREJ = ((*pucTemp) >> 2) & 0X03;
		   pxTermCap->ucEchoParam = ((*pucTemp) >> 4) & 0X07;
		   pxTermCap->ucExtn3b = (*pucTemp) >> 7;
		   if(pxTermCap->ucExtn3b == 0){
																  
             pucTemp++;
			 pxTermCap->ucSlotTypeCap = (*pucTemp) & 0X7F;
			 pxTermCap->ucExtn3c = (*pucTemp) >> 7;
			 if(pxTermCap->ucExtn3c == 0){
			
               pucTemp++;
			   pxTermCap->ucMSNoOfStrdDispChr = (*pucTemp) & 0X7F;
			   pxTermCap->ucExtn3d = (*pucTemp) >> 7;
			   if(pxTermCap->ucExtn3d == 0){
			
                  pucTemp++;
				  pxTermCap->ucLSNoOfStrdDispChr = (*pucTemp) & 0X7F;
				  pxTermCap->ucExtn3e = (*pucTemp) >> 7;
		          if(pxTermCap->ucExtn3e == 0){

                    pucTemp++;
					pxTermCap->ucNoOfLinesPhyDisp = (*pucTemp) & 0X7F;
					pxTermCap->ucExtn3f = (*pucTemp) >> 7;
					if(pxTermCap->ucExtn3f == 0){
					
                      pucTemp++;
					  pxTermCap->ucNoOfChrInLine = (*pucTemp) & 0X7F;
					  pxTermCap->ucExtn3g = (*pucTemp) >> 7;
				      if(pxTermCap->ucExtn3g == 0){

                        pucTemp++;
						pxTermCap->ucScrollBehavior = (*pucTemp) & 0X7F;
						pxTermCap->ucExtn3h = (*pucTemp) >> 7/*1*/;
						
                      }
				    }
				  }
               }
		  	 }
		   }
	     }											
         pucTemp++;
		 pxTermCap->ucProfInd1 = (*pucTemp) & 0X7F;
	     pxTermCap->ucExtn4 = (*pucTemp) >> 7;
		 if(pxTermCap->ucExtn4 == 0){

           pucTemp++;
		   pxTermCap->ucProfInd2 = (*pucTemp) & 0X7F;
		   pxTermCap->ucExtn4a = (*pucTemp) >> 7;
		   if(pxTermCap->ucExtn4a == 0){
											
             pucTemp++;
			 pxTermCap->ucProfInd3 = (*pucTemp) & 0X7F;
			 pxTermCap->ucExtn4b = (*pucTemp) >> 7;
	         if(pxTermCap->ucExtn4b == 0){
			
               pucTemp++;
			   pxTermCap->ucProfInd4 = (*pucTemp) & 0X7F;
			   pxTermCap->ucExtn4c = (*pucTemp) >> 7;
			   if(pxTermCap->ucExtn4c == 0){
			
                 pucTemp++;
				 pxTermCap->ucProfInd5 = (*pucTemp) & 0X7F;
				 pxTermCap->ucExtn4d = (*pucTemp) >> 7;
				 if(pxTermCap->ucExtn4d == 0){
				
                   pucTemp++;
				   pxTermCap->ucProfInd6 = (*pucTemp) & 0X7F;
				   pxTermCap->ucExtn4e = (*pucTemp) >> 7;
				   if(pxTermCap->ucExtn4e == 0){
																			
                     pucTemp++;
					 pxTermCap->ucProfInd7 = (*pucTemp) & 0X7F;
					 pxTermCap->ucExtn4f = (*pucTemp) >> 7;
					 if(pxTermCap->ucExtn4f == 0){
					
                       pucTemp++;
					   pxTermCap->ucProfInd8 = (*pucTemp) & 0X7F;
					   pxTermCap->ucExtn4g = (*pucTemp) >> 7;
					
                     }
				   }
				 }
			   }
			 }
		   }
		 }
         pucTemp++;
		 pxTermCap->ucCtrlCode = (*pucTemp) & 0X07;
	     pxTermCap->ucRsvd5 = 0;
	     pxTermCap->ucExtn4g = (*pucTemp) >> 7;
	     if(pxTermCap->ucExtn5 == 0){
		
           pucTemp++;
		   pxTermCap->ucSpare = 0;
		   pucTemp++;
		   pxTermCap->ucEscTo8ChrSets = (*pucTemp) & 0X07;
		   pxTermCap->ucExtn5a = (*pucTemp) >> 7;
		 }
         pucTemp++;
		 pxTermCap->ucSp4 = (*pucTemp) & 0X01;
	     pxTermCap->ucSp3 = (((*pucTemp) >> 1) & 0X01);
		 pxTermCap->ucSp2 = (((*pucTemp) >> 2) & 0X01);
		 pxTermCap->ucSp1 = (((*pucTemp) >> 3) & 0X01);
         pxTermCap->ucSp0 = (((*pucTemp) >> 4) & 0X01);
		 pxTermCap->ucBlindSlotInd = (((*pucTemp) >> 5) & 0X03);
		 pxTermCap->ucExtn6 = (*pucTemp) >> 7;
		 if(pxTermCap->ucExtn6 == 0){
		
           pucTemp++;
		   pxTermCap->ucSp11 = (*pucTemp) & 0X01;
		   pxTermCap->ucSp10 = (((*pucTemp) >> 1) & 0X01);
           pxTermCap->ucSp9 = (((*pucTemp) >> 2) & 0X01);
		   pxTermCap->ucSp8 = (((*pucTemp) >> 3) & 0X01);
           pxTermCap->ucSp7 = (((*pucTemp) >> 4) & 0X01);
		   pxTermCap->ucSp6 = (((*pucTemp) >> 5) & 0X01);
		   pxTermCap->ucSp5 = (((*pucTemp) >> 6) & 0X01);
           pxTermCap->ucExtn6a = 1;
         }
		 return IFX_SUCCESS;
	    }
     }     
   }
   return IFX_FAILURE;
}
									
		

		

#endif												  

// Set Functions for AddIE 
// Set functions implemented only for variable octet IEs
// All Set functions are internal functions




 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_EventsNotificationSet
  * Description       :  A function used to set the contents of the
                         Events Notification IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Events Notification IE 
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Events Notification content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler   
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_EventsNotificationSet(uint32 uiCIEHdl,
                                               x_IFX_DECT_IE_EventNotify *pxENInfo){

  uchar8 ucEventCount = 0;
  if((uiCIEHdl != 0) && (pxENInfo != NULL)){

    uchar8 *pucTemp = (uchar8*)uiCIEHdl;
	*pucTemp = (uchar8)IFX_DECT_IE_EVENTNOTIFY;
	if(*(uchar8*)pxENInfo){
   
      uchar8 ucLen = 0;
	  uchar8 *pucLen = NULL;
	  pucTemp++;
	  pucLen = pucTemp;
	  while(ucEventCount < pxENInfo->ucNoOfEvents){
	 
	    pucTemp++;
	    *pucTemp = (uchar8)pxENInfo->axEvent[ucEventCount].ucEventType;
		*pucTemp = (*pucTemp) | (((uchar8)pxENInfo->axEvent[ucEventCount].ucIsEventSubType) << 7);
	    ucLen++;
	    if(pxENInfo->axEvent[ucEventCount].ucIsEventSubType == 0){
 
    	  pucTemp++;
		  *pucTemp = (uchar8)pxENInfo->axEvent[ucEventCount].ucEventSubType;
		  *pucTemp = (*pucTemp) | (((uchar8)pxENInfo->axEvent[ucEventCount].ucDefault1) << 7);
		  ucLen++;
        }  
        pucTemp++;
	    *pucTemp = (uchar8)pxENInfo->axEvent[ucEventCount].ucEventMultiFirstByte;
	    *pucTemp = (*pucTemp) | (((uchar8)pxENInfo->axEvent[ucEventCount].ucEventMultiExtn) << 7);
        ucLen++;
	    if(pxENInfo->axEvent[ucEventCount].ucEventMultiExtn == 0){
		
		  pucTemp++;
		  *pucTemp = (uchar8)pxENInfo->axEvent[ucEventCount].ucEventMultiSecondByte;
		  *pucTemp = (*pucTemp) | 0X80;
		  ucLen++;
	    }
		ucEventCount++;
	  }
	  pucTemp++;
	  *pucTemp = '\0';
	  *pucLen = ucLen;
	  return IFX_SUCCESS;
    }	
  }
  return IFX_FAILURE;
}


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_CallInformationSet
  * Description       :  A function used to set the contents of the
                         Call Information IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Call Information IE 
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Call Informationcontent structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler   
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_CallInformationSet(uint32 uiCIEHdl,
                                            x_IFX_DECT_IE_CallInfo *pxCallInfo){

  uchar8 ucIDCount = 0;
  if((uiCIEHdl != 0) && (pxCallInfo != NULL)){

    uchar8 *pucTemp = (uchar8*)uiCIEHdl;
	  *pucTemp = (uchar8)IFX_DECT_IE_CALLINFORMATION;
    if(*(uchar8*)pxCallInfo){
      
	  int32 i = 0;
	  uchar8 ucLen = 0;
      uchar8 *pucLen = NULL;
	  pucTemp++;
	  pucLen = pucTemp;
	  while(ucIDCount < pxCallInfo->ucNoOfIdentifiers){
	  
	     pucTemp++;
	     *pucTemp = (uchar8)pxCallInfo->axID[ucIDCount].ucIDType;
	     ucLen++;
	     pucTemp++;
	     *pucTemp = (uchar8)pxCallInfo->axID[ucIDCount].ucIDSubType;
	     ucLen++;
	     pucTemp++;
	     *pucTemp = (uchar8)pxCallInfo->axID[ucIDCount].axIDValue[i].ucIDValueFirstByte;
	     *pucTemp = (*pucTemp) | (((uchar8)pxCallInfo->axID[ucIDCount].axIDValue[i].ucIDValueExtn) << 7);
	     ucLen++;
						   
	     while(i < IFX_DECT_IE_MAX_IDVALUE_SIZE){
	  
	       if(pxCallInfo->axID[ucIDCount].axIDValue[i].ucIDValueExtn == 0){
	    
		     pucTemp++;
		     
		     *pucTemp = (uchar8)pxCallInfo->axID[ucIDCount].axIDValue[i].ucIDValueFirstByte;
		     *pucTemp = (*pucTemp) | (((uchar8)pxCallInfo->axID[ucIDCount].axIDValue[i].ucIDValueExtn) << 7);
			 i++;
		     ucLen++;
	       }else{
	         break;
		    }
	   	
	     } 
		 ucIDCount++;
	  }	 
	  pucTemp++;
	  *pucTemp = '\0';
      *pucLen = ucLen;
	  return IFX_SUCCESS;
	}  
  }
  return IFX_FAILURE; 
}


/******************************************************************************
  * Function Name     :  IFX_DECT_IE_SetCalledPartyNumber
  * Description       :  A function used to set the contents of the
                         Called Party Number IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Called Party Number IE 
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Called Party Number content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler   
 ****************************************************************************/


e_IFX_Return IFX_DECT_IE_SetCalledPartyNumber(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_CalledPartyNumber *pxCdPNumInfo)
{
  if((uiCIEHdl != 0) && (pxCdPNumInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_CALLEDPARTYNUMBER;//octet 1
    if(*((uchar8 *)pxCdPNumInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxCdPNumInfo->ucCPALen)+1;//octet 2
      pucTemp++;
      *pucTemp = *((uchar8 *)pxCdPNumInfo);//octet 3
      pucTemp1= pxCdPNumInfo->acCPA;
      pucTemp++;//octet 4
      if (pxCdPNumInfo->ucCPALen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxCdPNumInfo->ucCPALen);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetCallingPartyName
  * Description       :  A function used to set the contents of the
                         Calling Party Name IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Calling Party Name IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Calling Party Name content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetCallingPartyName(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_CallingPartyName *pxCgPNameInfo)
{
  if((uiCIEHdl != 0) && (pxCgPNameInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_CALLINGPARTYNAME;//octet 1
    //if(*((uchar8 *)pxCgPNameInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxCgPNameInfo->ucCPNLen)+1;//octet 2
      pucTemp++;
      *pucTemp = *((uchar8 *)pxCgPNameInfo);//octet 3
      pucTemp1= pxCgPNameInfo->acCPN;
      pucTemp++;//octet 4
      if(pxCgPNameInfo->ucCPNLen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxCgPNameInfo->ucCPNLen);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetConnectionIdentity
  * Description       :  A function used to set the contents of the
                         Connection Identity IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Connection Identity IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Connection Identity content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetConnectionIdentity(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_ConnectionIdentity *pxCIDInfo)
{
  if((uiCIEHdl != 0) && (pxCIDInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_CONNECTIONIDENTITY;//octet 1
    if(*((uchar8 *)pxCIDInfo))
    {//content present
      pucTemp+=2;//octet 3
      *pucTemp= *((uchar8 *)pxCIDInfo);
      if(pxCIDInfo->ucUPLID == 7)
      {//octet 3a present
        pucTemp++;//octet 3a
        *pucTemp=pxCIDInfo->ucLCA;
        pucTemp=pucTemp-2;//octet 2
        *pucTemp=2;
        pucTemp+=2;
      }
      else
      {
        pucTemp--;//octet 2
        *pucTemp=1;
        pucTemp++;
      }
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetIWUToIWU
  * Description       :  A function used to set the contents of the
                         IWU To IWU IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           IWU To IWU IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The IWU To IWU content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetIWUToIWU(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_IWUToIWU *pxITIInfo)
{
  if((uiCIEHdl != 0) && (pxITIInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_IWUTOIWU;//octet 1
    if(*((uchar8 *)pxITIInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxITIInfo->ucIWUToIWULen)+1;//octet 2
      pucTemp++;
      *pucTemp = *((uchar8 *)pxITIInfo);//octet 3
      pucTemp1= pxITIInfo->acIWUToIWU;
      pucTemp++;//octet 4
      if (pxITIInfo->ucIWUToIWULen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxITIInfo->ucIWUToIWULen);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetFacility
  * Description       :  A function used to set the contents of the
                         Facility IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Facility IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Facility content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetFacility(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_Facility *pxFInfo)
{
  if((uiCIEHdl != 0) && (pxFInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_FACILITY;//octet 1
    if(*((uchar8 *)pxFInfo))
    {//content present
      pucTemp++;
      *pucTemp=2;//octet 2
      pucTemp++;
      *pucTemp = *((uchar8 *)pxFInfo);//octet 3
      pucTemp++;//octet 4
      *pucTemp = pxFInfo->ucComponents;
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetMultiKeypad
  * Description       :  A function used to set the contents of the
                         Multi Keypad IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                            IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Multi Keypad content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetMultiKeypad(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_MultiKeypad *pxMKPInfo)
{
  if((uiCIEHdl != 0) && (pxMKPInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_MULTIKEYPAD;//octet 1
    if(*((uchar8 *)pxMKPInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxMKPInfo->ucKeypadLen);//octet 2
      pucTemp1= pxMKPInfo->acKeypad;
      pucTemp++;//octet 3
      if (pxMKPInfo->ucKeypadLen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxMKPInfo->ucKeypadLen);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetMultiDisplay
  * Description       :  A function used to set the contents of the
                         Multi Display IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                            IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Multi Display content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetMultiDisplay(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_MultiDisplay *pxMDInfo)
{
  if((uiCIEHdl != 0) && (pxMDInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_MULTIDISPLAY;//octet 1
    if(*((uchar8 *)pxMDInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxMDInfo->ucDisplayLen);//octet 2
      pucTemp1= pxMDInfo->acDisplay;
      pucTemp++;//octet 3
      if (pxMDInfo->ucDisplayLen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxMDInfo->ucDisplayLen);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetEscapeToProprietary
  * Description       :  A function used to set the contents of the
                         Escape To Proprietary IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                            Escape To Proprietary IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Escape To Proprietary content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetEscapeToProprietary(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_EscapeToProprietary *pxETPInfo)
{
  if((uiCIEHdl != 0) && (pxETPInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_ESCAPETOPROPRIETARY;//octet 1
    if(*((uchar8 *)pxETPInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxETPInfo->ucUSCLen)+1;//octet 2
      pucTemp++;
      *pucTemp = *((uchar8 *)pxETPInfo);//octet 3
      pucTemp1= pxETPInfo->acUSC;
      pucTemp++;//octet 4
      if (pxETPInfo->ucUSCLen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxETPInfo->ucUSCLen);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetTimeDate
  * Description       :  A function used to set the contents of the
                         Time Date IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Time Date IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Time Date content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/


e_IFX_Return IFX_DECT_IE_SetTimeDate(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_TimeDate *pxTDInfo)
{
  if((uiCIEHdl != 0) && (pxTDInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_TIMEDATE;//octet 1
    if(*((uchar8 *)pxTDInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxTDInfo->ucTimeDateLen)+1;//octet 2
      pucTemp++;
      *pucTemp = *((uchar8 *)pxTDInfo);//octet 3
      pucTemp1= pxTDInfo->acTimeDate;
      pucTemp++;//octet 4
      if(pxTDInfo->ucTimeDateLen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxTDInfo->ucTimeDateLen);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetFixedIdentity
  * Description       :  A function used to set the contents of the
                         Fixed Identity IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                            Fixed Identity  IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Fixed Identity content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/


e_IFX_Return IFX_DECT_IE_SetFixedIdentity(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_FixedIdentity *pxFIDInfo)
{
  if((uiCIEHdl != 0) && (pxFIDInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_FIXEDIDENTITY;//octet 1
    if(*((uchar8 *)pxFIDInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxFIDInfo->ucIDValLen)+ 2;//octet 2
      pucTemp++;
      *pucTemp = *((uchar8 *)pxFIDInfo);//octet 3
      pucTemp++;
      *pucTemp = (uchar8)(pxFIDInfo->ucIDValLen);//octet 4
      *pucTemp = (*pucTemp) | (((uchar8)(pxFIDInfo->ucDefault2))<<7);
      pucTemp++;
      *pucTemp = (uchar8)(pxFIDInfo->ucARD);//octet 5
      *pucTemp = (*pucTemp) | (((uchar8)(pxFIDInfo->ucARC))<<4);
      *pucTemp = (*pucTemp) | (((uchar8)(pxFIDInfo->ucDefault3))<<7);
      pucTemp1= pxFIDInfo->acARD_RPN;
      pucTemp++;//octet 6
      if (pxFIDInfo->ucIDValLen <= 250)
      { 
        memcpy(pucTemp,pucTemp1,pxFIDInfo->ucIDValLen - 1);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetPortableIdentity
  * Description       :  A function used to set the contents of the
                         Portable Identity IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Portable Identity IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Portable Identity content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/


e_IFX_Return IFX_DECT_IE_SetPortableIdentity(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_PortableIdentity *pxPIDInfo)
{
  if((uiCIEHdl != 0) && (pxPIDInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_PORTABLEIDENTITY;//octet 1
    if(*((uchar8 *)pxPIDInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxPIDInfo->ucIDValLen)+ 1;//octet 2
      pucTemp++;
      *pucTemp = *((uchar8 *)pxPIDInfo);//octet 3
      pucTemp++;
      *pucTemp = (uchar8)(pxPIDInfo->ucIDValLen);//octet 4
      *pucTemp = (*pucTemp) | (((uchar8)(pxPIDInfo->ucDefault2))<<7);
      pucTemp1= pxPIDInfo->acIDVal;
      pucTemp++;//octet 5
      if(pxPIDInfo->ucIDValLen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxPIDInfo->ucIDValLen);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetCallingPartyNumber
  * Description       :  A function used to set the contents of the
                         Calling Party Number IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                            Calling Party Number IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Calling Party Number content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

                
e_IFX_Return IFX_DECT_IE_SetCallingPartyNumber(uint32 uiCIEHdl,
                         x_IFX_DECT_IE_CallingPartyNumber *pxCgPNumInfo)
{
  const uchar8 *pucTemp1;
  if((uiCIEHdl != 0) && (pxCgPNumInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_CALLINGPARTYNUMBER;//octet 1
    //if(*((uchar8 *)pxCgPNumInfo))
    {//content present
      pucTemp = pucTemp+2;
      *pucTemp = *((uchar8 *)pxCgPNumInfo);//octet 3
      if(((*pucTemp) & 0X80) != 0X80)
      {//octet 3a present
        pucTemp--;
        *pucTemp=(pxCgPNumInfo->ucCPALen)+2;//octet 2
        pucTemp=pucTemp+2;//octet 3a
        *pucTemp = (uchar8)(pxCgPNumInfo->ucSI);
        *pucTemp = (*pucTemp) | (((uchar8)(pxCgPNumInfo->ucSpare))<<2);
        *pucTemp = (*pucTemp) | (((uchar8)(pxCgPNumInfo->ucPI))<<5);
        *pucTemp = (*pucTemp) | (((uchar8)(pxCgPNumInfo->ucExtn3a))<<7);
      }
      else
      {
        pucTemp--;
        *pucTemp=(pxCgPNumInfo->ucCPALen)+1;//octet 2
        pucTemp++;
      }
      pucTemp1= &(pxCgPNumInfo->acCPA[0]);
      pucTemp++;//octet 4
			if (pxCgPNumInfo->ucCPALen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxCgPNumInfo->ucCPALen);
        return IFX_SUCCESS;
      }
    }
  }
  return IFX_FAILURE;
}


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetIWUPacket
  * Description       :  A function used to set the contents of the
                         IWU Packet IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           IWU Packet IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The IWU Packet content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/
                       
                


        
e_IFX_Return IFX_DECT_IE_SetIWUPacket(uint32 uiCIEHdl,
                         x_IFX_DECT_IE_IWUPacket *pxIWUPInfo)
{
  const uchar8 *pucTemp1;
  if((uiCIEHdl != 0) && (pxIWUPInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_IWUPACKET;//octet 1
    if(*((uchar8 *)pxIWUPInfo))
    {//content present
      pucTemp = pucTemp+2;
      *pucTemp = *((uchar8 *)pxIWUPInfo);//octet 3
      if(((*pucTemp) & 0X80) != 0X80)
      {//octet 3a present
        pucTemp--;
        *pucTemp=(pxIWUPInfo->ucIWUPLen)+2;//octet 2
        pucTemp=pucTemp+2;//octet 3a
        *pucTemp = (uchar8)(pxIWUPInfo->ucL3PID);
        *pucTemp = (*pucTemp) | (((uchar8)(pxIWUPInfo->ucDefault2))<<5);
        *pucTemp = (*pucTemp) | (((uchar8)(pxIWUPInfo->ucExtn3a))<<7);
      }
      else
      {
        pucTemp--;
        *pucTemp=(pxIWUPInfo->ucIWUPLen)+1;//octet 2
        pucTemp++;
      }
      pucTemp1= &(pxIWUPInfo->acIWUP[0]);
      pucTemp++;//octet 4
      if(pxIWUPInfo->ucIWUPLen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxIWUPInfo->ucIWUPLen);
        return IFX_SUCCESS;
      }
    }
  }
    return IFX_FAILURE;
}

#if 0      
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetRepeatIndicator
  * Description       :  A function used to set the contents of the
                         Repeat Indicator IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Pointer variable containing the contents of
                           Progress Indicator IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Progress Indicator content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/
                   
 e_IFX_Return IFX_DECT_IE_SetRepeatIndicator(uint32 uiCIEHdl,
                                             uchar8 *pucRIInfo)
{

 if((uiCIEHdl != 0) && (pxPIInfo !=0))
 {
   uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
   *pucTemp = (uchar8)IFX_DECT_IE_REPEATINDICATOR;
   if(*((uchar8 *)pucRIInfo))
   { 
	 *pucTemp = (*pucTemp) | (*((uchar8 *)pucRIInfo) & 0X0F);
     return IFX_SUCCESS;
   }
 }
 return IFX_FAILURE;
}
#endif
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetProgressIndicator
  * Description       :  A function used to set the contents of the
                         Progress Indicator IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Progress Indicator IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Progress Indicator content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/
                 
              

e_IFX_Return IFX_DECT_IE_SetProgressIndicator(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_ProgressIndicator *pxPIInfo)
{
  if((uiCIEHdl != 0) && (pxPIInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_PROGRESSINDICATOR;//octet 1
    if(*((uchar8 *)pxPIInfo))
    {//content present
      pucTemp++;
      *pucTemp=2;//octet 2
      pucTemp++;
      *pucTemp = *((uchar8 *)pxPIInfo);//octet 3
      pucTemp++;//octet 4
      *pucTemp = (uchar8)(pxPIInfo->ucPD);
      *pucTemp = (*pucTemp) | ((uchar8)(pxPIInfo->ucDefault3)<<7);
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}

//Service Change Info content length is 0, 1 or 2
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetServiceChange
  * Description       :  A function used to set the contents of the
                         Service Change  IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Service Change  IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Service Change  content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/
             
e_IFX_Return IFX_DECT_IE_SetServiceChange(uint32 uiCIEHdl,
                         x_IFX_DECT_IE_ServiceChange *pxSCIInfo)
{
  if((uiCIEHdl != 0) && (pxSCIInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_SERVICECHANGEINFO;//octet 1
    if(*((uchar8 *)pxSCIInfo))
    {//content present
      pucTemp+=2;
      *pucTemp = *((uchar8 *)pxSCIInfo);//octet 3
      if(((((*pucTemp) & 0X8E) == 0X0E) ||(((*pucTemp) & 0X8F) == 0X0F)))
      {//octet 3a present
        pucTemp--;
        *pucTemp=2;//octet 2
        pucTemp=pucTemp+2;//octet 3a
        *pucTemp = (uchar8)(pxSCIInfo->ucECM);
        *pucTemp = (*pucTemp) | (((uchar8)(pxSCIInfo->ucExtn3a))<<7);
        pucTemp--;//octet 3
      }
      else if((((*pucTemp) & 0X08) == 0X08) ||(((*pucTemp) & 0X09) == 0X09) )
      {//octet 4 present
        pucTemp--;
        *pucTemp=2;//octet 2
        pucTemp+=2;//octet 4
      *pucTemp = (uchar8)(pxSCIInfo->ucBA);
      *pucTemp = (*pucTemp) | ((uchar8)(pxSCIInfo->ucR)<<3);
      *pucTemp = (*pucTemp) | ((uchar8)(pxSCIInfo->ucAA)<<4);
      *pucTemp = (*pucTemp) | (((uchar8)(pxSCIInfo->ucDefault1))<<7);
      }
      else
      {
        pucTemp--;//octet 2
        *pucTemp=1;
        pucTemp++;//octet 3
      }
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}
            
               
         
                     
                 
//AuthType content length 0,3 or 4
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetAuthTypeInfo
  * Description       :  A function used to set the contents of the
                         Auth Type IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Auth Type IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Auth Type IE content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetAuthType(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_AuthType *pxATInfo)
{
  if((uiCIEHdl != 0) && (pxATInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_AUTHTYPE;//octet 1
    if(*((uchar8 *)pxATInfo))
    {//content present
      pucTemp+=2;
      *pucTemp = *((uchar8 *)pxATInfo);//octet 3
      if((*pucTemp) == 0X7F)
      {//octet 3a present 
        pucTemp--;
        *pucTemp=4;//octet 2        
        pucTemp=pucTemp+2;//octet 3a
        *pucTemp = (uchar8)(pxATInfo->ucPAI);
      }
      else
      {
        pucTemp--;
        *pucTemp=3;//octet 2        
        pucTemp++;
      } 
      pucTemp++;//octet 4
      *pucTemp = (uchar8)(pxATInfo->ucAKN);
      *pucTemp = (*pucTemp) | ((uchar8)(pxATInfo->ucAKT)<<4);
      pucTemp++;//octet 5
      *pucTemp = (uchar8)(pxATInfo->ucCKN);
      *pucTemp = (*pucTemp) | ((uchar8)(pxATInfo->ucUPC)<<4);
      *pucTemp = (*pucTemp) | ((uchar8)(pxATInfo->ucTXC)<<5);
      *pucTemp = (*pucTemp) | ((uchar8)(pxATInfo->ucDefault1)<<6);
      *pucTemp = (*pucTemp) | ((uchar8)(pxATInfo->ucINC)<<7);      
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}
   

//Cipher Info -  content length is 0, 2 or 3
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetCipher
  * Description       :  A function used to set the contents of the
                         Cipher Info IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Cipher Info IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Cipher Info IE content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetCipher(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_Cipher *pxCIInfo)
{
  if((uiCIEHdl != 0) && (pxCIInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_CIPHERINFO;//octet 1
    if(*((uchar8 *)pxCIInfo))
    {//content present
      pucTemp+=2;
      *pucTemp = *((uchar8 *)pxCIInfo);//octet 3
      if(((pxCIInfo->ucCAI) & 0X7F) == 0X7F)
      {//octet 3a present 
        pucTemp--;
        *pucTemp=3;//octet 2        
        pucTemp=pucTemp+2;//octet 3a
        *pucTemp = (uchar8)(pxCIInfo->ucPAI);
      }
      else
      {
        pucTemp--;
        *pucTemp=2;//octet 2        
        pucTemp++;
      } 
      pucTemp++;//octet 4
      *pucTemp = (uchar8)(pxCIInfo->ucCKN);
      *pucTemp = (*pucTemp) | ((uchar8)(pxCIInfo->ucCKT)<<4);
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}
   
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetServiceClass
  * Description       :  A function used to set the contents of the
                         Service Class IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Service Class IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Service Class IE content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetServiceClass(uint32 uiCIEHdl,uchar8 *pucSCInfo)
{
  if((uiCIEHdl != 0) && (pucSCInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_SERVICECLASS;//octet 1
    if(*pucSCInfo)
    {//content present
      pucTemp++;
      *pucTemp=1;//octet 2
      pucTemp++;
      *pucTemp = *pucSCInfo;//octet 3
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}

//Setup Capability Info -  content length is 0, 2 or 3
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetSetupCapability
  * Description       :  A function used to set the contents of the
                         Setup Capability IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Setup Capability IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Setup Capability IE content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetSetupCapability(uint32 uiCIEHdl,
                         x_IFX_DECT_IE_SetupCapability *pxSCInfo)
{
  if((uiCIEHdl != 0) && (pxSCInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_SETUPCAPABILITY;//octet 1
    if(*((uchar8 *)pxSCInfo))
    {//content present
      pucTemp+=2;
      *pucTemp = *((uchar8 *)pxSCInfo);//octet 3
      if(((*pucTemp) & 0X80) != 0X80)
      {//octet 3a present
        pucTemp--;
        *pucTemp=pxSCInfo->ucSpareLen+2;//octet 2
        pucTemp=pucTemp+2;//octet 3a
        *pucTemp = (uchar8)(pxSCInfo->ucDefault1);
      }
      else
      {
        pucTemp--;
        *pucTemp=pxSCInfo->ucSpareLen+1;//octet 2
        pucTemp++;
      }
      pucTemp++;//octet 4
      if (pxSCInfo->ucSpareLen<=250 ) 
      {
        const uchar8 *pucTemp1 = (uchar8 *)(pxSCInfo->acSpare);
        memcpy(pucTemp,pucTemp1,pxSCInfo->ucSpareLen);
      }
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}
    
          
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetModelIdentifier
  * Description       :  A function used to set the contents of the
                         Model Identifier IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Structure pointer containing the contents of
                           Model Identifier IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Model Identifier IE content structure is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetModelIdentifier(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_ModelIdentifier *pxMIInfo)
{
  if((uiCIEHdl != 0) && (pxMIInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_MODELIDENTIFIER;//octet 1
    if(*((uchar8 *)pxMIInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxMIInfo->ucModelValueLen);//octet 2
      pucTemp1= pxMIInfo->acModelValue;
      pucTemp++;//octet 3
      if((pxMIInfo->ucModelValueLen > 0) && (pxMIInfo->ucModelValueLen <= 250))
      {
        memcpy(pucTemp,pucTemp1,pxMIInfo->ucModelValueLen);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetRejectReason
  * Description       :  A function used to set the contents of the
                         Reject Reason IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Character pointer containing the contents of
                           Reject Reason IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Reject Reason IE content variable is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/
 
e_IFX_Return IFX_DECT_IE_SetRejectReason(uint32 uiCIEHdl, uchar8 *pucRRInfo)
{
  if((uiCIEHdl != 0) && (pucRRInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_REJECTREASON;//octet 1
    if(*pucRRInfo)
    {//content present
      pucTemp++;
      *pucTemp=1;//octet 2
      pucTemp++;
      *pucTemp = *pucRRInfo;//octet 3
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetDuration
  * Description       :  A function used to set the contents of the
                         Duration IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Character pointer containing the contents of
                           Duration IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Duration IE content variable is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetDuration(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_Duration *pxDInfo)
{
  if((uiCIEHdl != 0) && (pxDInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_DURATION;//octet 1
    if(*((uchar8 *)pxDInfo))
    {//content present
      pucTemp+=2;
      *pucTemp = *((uchar8 *)pxDInfo);//octet 3
      if(((*pucTemp) & 0X80) != 0X80)
      {//octet 3a present 
        pucTemp--;
        *pucTemp=2;//octet 2        
        pucTemp=pucTemp+2;//octet 3a
        *pucTemp = (uchar8)(pxDInfo->ucTimeDuration);
      }
      else
      {
        pucTemp--;
        *pucTemp=1;//octet 2        
        pucTemp++;
      } 
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetRAND
  * Description       :  A function used to set the contents of the
                         RAND IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Character pointer containing the contents of
                           RAND IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The RAND IE content variable is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/


e_IFX_Return IFX_DECT_IE_SetRAND(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_RAND *pxRANDInfo)
{
  if((uiCIEHdl != 0) && (pxRANDInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_RAND;//octet 1
    if(*((uchar8 *)pxRANDInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxRANDInfo->ucRANDFieldLen);//octet 2
      pucTemp1= pxRANDInfo->acRANDField;
      pucTemp++;//octet 3
      if(pxRANDInfo->ucRANDFieldLen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxRANDInfo->ucRANDFieldLen);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}


 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetRESInfo
  * Description       :  A function used to set the contents of the
                         RES IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Character pointer containing the contents of
                           RES IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The RES IE content variable is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetRES(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_RES *pxRESInfo)
{
  if((uiCIEHdl != 0) && (pxRESInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_RES;//octet 1
    if(*((uchar8 *)pxRESInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxRESInfo->ucRESFieldLen);//octet 2
      pucTemp1= pxRESInfo->acRESField;
      pucTemp++;//octet 3
      if (pxRESInfo->ucRESFieldLen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxRESInfo->ucRESFieldLen);
        return IFX_SUCCESS;
      }        
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetRS
  * Description       :  A function used to set the contents of the
                         RS IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Character pointer containing the contents of
                           RS IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The RS IE content variable is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetRS(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_RS *pxRSInfo)
{
  if((uiCIEHdl != 0) && (pxRSInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_RS;//octet 1
    if(*((uchar8 *)pxRSInfo))
    {//content present
      const uchar8 *pucTemp1;
      pucTemp++;
      *pucTemp=(pxRSInfo->ucRSFieldLen);//octet 2
      pucTemp1= pxRSInfo->acRSField;
      pucTemp++;//octet 3
      if (pxRSInfo->ucRSFieldLen <= 250)
      {
        memcpy(pucTemp,pucTemp1,pxRSInfo->ucRSFieldLen);
        return IFX_SUCCESS;
      }        
    }
  }
   return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetCallAttributes
  * Description       :  A function used to set the contents of the
                         Call Attributes IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Character pointer containing the contents of
                           Call Attributes IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Call Attributes IE content variable is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/


e_IFX_Return IFX_DECT_IE_SetCallAttributes(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_CallAttributes *pxCAInfo)
{
  if((uiCIEHdl != 0) && (pxCAInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_CALLATTRIBUTES;//octet 1
    if(*((uchar8 *)pxCAInfo))
    {//content present
      uchar8 ucLen=4;
      uchar8 *pucLen;
      pucTemp++;
      pucLen = pucTemp;
      pucTemp++;
      *pucTemp = *((uchar8 *)pxCAInfo);//octet 3
      pucTemp++;//octet 4
      *pucTemp = (uchar8)(pxCAInfo->ucCPR);
      *pucTemp = (*pucTemp) | ((uchar8)(pxCAInfo->ucCPC)<<4);
      *pucTemp = (*pucTemp) | ((uchar8)(pxCAInfo->ucDefault2)<<7);
      pucTemp++;//octet 5
      *pucTemp = (uchar8)(pxCAInfo->ucLUID);
      *pucTemp = (*pucTemp) | ((uchar8)(pxCAInfo->ucUPS)<<5);
      *pucTemp = (*pucTemp) | ((uchar8)(pxCAInfo->ucExtn5)<<7);
      if((pxCAInfo->ucUPS == 2) && (pxCAInfo->ucExtn5 == 0) )
      {//octet 5a present
        pucTemp++;
        *pucTemp = (uchar8)(pxCAInfo->ucLUIDFTP);
        *pucTemp = (*pucTemp) | ((uchar8)(pxCAInfo->ucS)<<5);
        *pucTemp = (*pucTemp) | ((uchar8)(pxCAInfo->ucExtn5a)<<7);
        ucLen++;
      }
      pucTemp++;//octet 6
      *pucTemp = (uchar8)(pxCAInfo->ucUPFT);
      *pucTemp = (*pucTemp) | ((uchar8)(pxCAInfo->ucUPC)<<4);
      *pucTemp = (*pucTemp) | ((uchar8)(pxCAInfo->ucExtn6)<<7);
      if((pxCAInfo->ucUPS == 2) && (pxCAInfo->ucExtn6 == 0))
      {//octet 6a present
        pucTemp++;
        *pucTemp = (uchar8)(pxCAInfo->ucUPFTFTP);
        *pucTemp = (*pucTemp) | ((uchar8)(pxCAInfo->ucUPCFTP)<<4);
        *pucTemp = (*pucTemp) | ((uchar8)(pxCAInfo->ucExtn6a)<<7);
        ucLen++;
      }
      *pucLen= ucLen;//octet 2   
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetConnectionAttributes
  * Description       :  A function used to set the contents of the
                         Connection Attributes IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Character pointer containing the contents of
                           Connection Attributes IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Connection Attributes IE content variable is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/


e_IFX_Return IFX_DECT_IE_SetConnectionAttributes(uint32 uiCIEHdl,
                         x_IFX_DECT_IE_ConnectionAttributes *pxConAtt1Info)
{
  if((uiCIEHdl != 0) && (pxConAtt1Info !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_CONNECTIONATTRIBUTES;//octet 1
    if(*((uchar8 *)pxConAtt1Info))
    {//content present
      uchar8 ucLen=5;
      uchar8 *pucLen;
      pucTemp++;
      pucLen = pucTemp;
      pucTemp++;
      *pucTemp = *((uchar8 *)pxConAtt1Info);//octet 3
      pucTemp++;//octet 4
      *pucTemp = (uchar8)(pxConAtt1Info->ucTBPFD);
      *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucDefault2)<<5);
      *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucExtn4)<<7);
      if(((*pucTemp) & 0X80) == 0)
      {//octet 4a present
        pucTemp++;
        *pucTemp = (uchar8)(pxConAtt1Info->ucMBPFD);
        *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucDefault3)<<5);
        *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucExtn4a)<<7);
        ucLen++;
        if(pxConAtt1Info->ucSymmetry != 1)
        {//octet 4b and 4c
          pucTemp++;
          *pucTemp = (uchar8)(pxConAtt1Info->ucTBFPD);
          *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucDefault4)<<5);
          *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucExtn4b)<<7);
          ucLen++;
          if(((*pucTemp) & 0X80) == 0)
          {//4c present
 pucTemp++;
            *pucTemp = (uchar8)(pxConAtt1Info->ucMBFPD);
            *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucDefault5)<<5);
            *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucExtn4c)<<7);
            ucLen++;
          }
        }
      }
      pucTemp++;//octet 5
      *pucTemp = (uchar8)(pxConAtt1Info->ucMACS);
      *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucSS)<<4);
      *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucExtn5)<<7);
      if((pxConAtt1Info->ucSymmetry != 1) && (((*pucTemp) & 0X80) == 0) )
      {//octet 5a present
        pucTemp++;
        *pucTemp = (uchar8)(pxConAtt1Info->ucMACSFP);
        *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucDefault6)<<4);
        *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucExtn5a)<<7);
        ucLen++;
      }
      pucTemp++;//octet 6
      *pucTemp = (uchar8)(pxConAtt1Info->ucMACPL);
      *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucCFCA)<<4);
      *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucExtn6)<<7);
      if((pxConAtt1Info->ucSymmetry != 1) && (((*pucTemp) & 0X80) == 0) )
      {//octet 6a present
        pucTemp++;
        *pucTemp = (uchar8)(pxConAtt1Info->ucMACPLFP);
        *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucCFCAFP)<<4);
        *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucExtn6a)<<7);
        ucLen++;
      }
      pucTemp++;//octet 7
      *pucTemp = (uchar8)(pxConAtt1Info->ucBA);
      *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucSpare)<<3);
      *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucAA)<<4);
      *pucTemp = (*pucTemp) | ((uchar8)(pxConAtt1Info->ucExtn7)<<7);
      *pucLen= ucLen;//octet 2
  return IFX_SUCCESS;
    }

  }
    return IFX_FAILURE;
}

              
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetCodecList
  * Description       :  A function used to set the contents of the
                         Codec List IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Character pointer containing the contents of
                           Codec List IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Codec List IE content variable is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/
   
e_IFX_Return IFX_DECT_IE_SetCodecList(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_CodecList *pxCLInfo)
{

  if((uiCIEHdl != 0) && (pxCLInfo !=0) && (pxCLInfo->ucNumCodecs<=IFX_DECT_IE_MAXCODEC))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_CODECLIST;//octet 1
    if(*((uchar8 *)pxCLInfo))
    {//content present
      const uchar8 *pucTemp1;
       x_IFX_DECT_IE_CodecList_SS *pxCLSS = NULL;
      pucTemp++;
      *pucTemp=((pxCLInfo->ucNumCodecs)*3)+1;//octet 2
      pxCLSS = &(pxCLInfo->xCodecListSS[0]);
      pucTemp++;//octet 3
      *pucTemp= *(uchar8 *) pxCLInfo;
      pucTemp++;//octet 4
      pucTemp1 = (uchar8 *)pxCLSS;      
      memcpy(pucTemp,pucTemp1,(*(pucTemp-1))-1);
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetLocationAreaInfo
  * Description       :  A function used to set the contents of the
                         Location Area IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Character pointer containing the contents of
                           Location Area IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Location Area IE content variable is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

e_IFX_Return IFX_DECT_IE_SetLocationArea(uint32 uiCIEHdl, 
                         x_IFX_DECT_IE_LocationArea *pxLAInfo)
{
  if((uiCIEHdl != 0) && (pxLAInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_LOCATIONAREA;//octet 1
    if(*((uchar8 *)pxLAInfo))
    {//content present
      pucTemp+=2;
      *pucTemp=*((uchar8 *)pxLAInfo);//octet 3
      if((pxLAInfo->ucLIType == 2) || (pxLAInfo->ucLIType == 3))
      {//next octets present
        pucTemp--;//2nd octet
        *pucTemp=9;
        pucTemp+=2;//octet 3a
        *pucTemp = (uchar8)(pxLAInfo->ucELI1);
        *pucTemp = (*pucTemp) | (((uchar8)(pxLAInfo->ucELIType))<<4);
        pucTemp++;//octet 4
        *pucTemp = (uchar8)(pxLAInfo->ucMCCDigit1);
        *pucTemp = (*pucTemp) | (((uchar8)(pxLAInfo->ucMCCDigit2))<<4);
        pucTemp++;//octet 5
        *pucTemp = (uchar8)(pxLAInfo->ucMCCDigit3);
        *pucTemp = (*pucTemp) | (((uchar8)(pxLAInfo->ucDefault1))<<4);
        pucTemp++;//octet 6
        *pucTemp = (uchar8)(pxLAInfo->ucMNCDigit1);
        *pucTemp = (*pucTemp) | (((uchar8)(pxLAInfo->ucMNCDigit2))<<4);
        pucTemp++;//octet 7
        *pucTemp=pxLAInfo->ucLAC;
        pucTemp++;//octet 8
        *pucTemp=pxLAInfo->ucLACCont;
        pucTemp++;//octet 9
        *pucTemp=pxLAInfo->ucCI;
        pucTemp++;//octet 10
        *pucTemp=pxLAInfo->ucCICont;
      }
      else
      {
        pucTemp--;
       *pucTemp=1;//octet 2
      }
      return IFX_SUCCESS;
    }
  }
  return IFX_FAILURE;
}

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetWindowSize
  * Description       :  A function used to set the contents of the
                         Window Size IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Character pointer containing the contents of
                           Window Size IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The Window Size IE content variable is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_SetWindowSize(uint32 uiCIEHdl,
                         x_IFX_DECT_IE_WindowSize *pxWSInfo)
{
  if((uiCIEHdl != 0) && (pxWSInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_WINDOWSIZE;//octet 1
    if(*((uchar8 *)pxWSInfo))
    {//content present
      uchar8 ucLen= 2;//octets 3, 3a
      uchar8 *pucLen = ++pucTemp;
      pucTemp++;//octet 3
      *pucTemp= (uchar8)(pxWSInfo->ucWSVF);
      *pucTemp= (*pucTemp) | ((uchar8)(pxWSInfo->ucExtn3)<<7);
      pucTemp++; //octet 3a
      *pucTemp= (uchar8)(pxWSInfo->ucWSVC);
      *pucTemp= (*pucTemp) | ((uchar8)(pxWSInfo->ucExtn3a)<<7);
      if(pxWSInfo->ucExtn3a == 0)
      {//octet 3b present
        pucTemp++;//octet 3b
        *pucTemp= (uchar8)(pxWSInfo->ucMPDULF);
        *pucTemp= (*pucTemp) | ((uchar8)(pxWSInfo->ucExtn3b)<<7);
        ucLen++;
        if(pxWSInfo->ucExtn3b == 0)
        {//octet 3c present
          pucTemp++;//octet 3c
          *pucTemp= (uchar8)(pxWSInfo->ucSDULAPUTF);
          *pucTemp= (*pucTemp) | ((uchar8)(pxWSInfo->ucExtn3c)<<7);
          ucLen++;
        }
      }
      if(pxWSInfo->ucOctet4 == 1)
      {//octet 4 present
         pucTemp++;//octet 4
        *pucTemp= (uchar8)(pxWSInfo->ucWSVB);
        *pucTemp= (*pucTemp) | ((uchar8)(pxWSInfo->ucExtn4)<<7);
        ucLen++;
        pucTemp++; //octet 4a
 *pucTemp= (uchar8)(pxWSInfo->ucWSVCB);
        *pucTemp= (*pucTemp) | ((uchar8)(pxWSInfo->ucExtn4a)<<7);
        ucLen++;
        if(pxWSInfo->ucExtn4a == 0)
        {//octet 4b present
          pucTemp++;//octet 4b
          *pucTemp= (uchar8)(pxWSInfo->ucMPDULB);
          *pucTemp= (*pucTemp) | ((uchar8)(pxWSInfo->ucExtn4b)<<7);
          ucLen++;
          if(pxWSInfo->ucExtn3b == 0)
          {//octet 4c present
            pucTemp++;//octet 4c
            *pucTemp= (uchar8)(pxWSInfo->ucSDULAPUTB);
            *pucTemp= (*pucTemp) | ((uchar8)(pxWSInfo->ucExtn4c)<<7);
            ucLen++;
          }
        }
      }
      *pucLen= ucLen;
      return IFX_SUCCESS;
    }
  }
    return IFX_FAILURE;
}
        
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_SetIWUAttributesInfo
  * Description       :  A function used to set the contents of the
                         IWU Attributes IE
  * Input Values      : 1. Handler to the memory location where the IE is to be
                           formed
                        2. Character pointer containing the contents of
                           IWU Attributes IE
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The IWU Atributes IE content variable is used to
                         form the complete IE at the memory location
                         pointed by the IE Handler
 ****************************************************************************/
           

e_IFX_Return IFX_DECT_IE_SetIWUAttributes(uint32 uiCIEHdl,
                         x_IFX_DECT_IE_IWUAttributes *pxIWUAInfo)
{
  if((uiCIEHdl != 0) && (pxIWUAInfo !=0))
  {
    uchar8 *pucTemp = (uchar8 *)uiCIEHdl;
    *pucTemp = (uchar8)IFX_DECT_IE_IWUATTRIBUTES;//octet 1
    if(*((uchar8 *)pxIWUAInfo))
    {//content present
      uchar8 ucLen= 0;
      uchar8 *pucLen = pucTemp;//pucLen points to octet 2
      pucTemp++;//octet 2
      pucLen = pucTemp;//pucLen points to octet 2
      pucTemp++;//octet 3
      *pucTemp= *((uchar8 *)(pxIWUAInfo));
      ucLen++;
      if(pxIWUAInfo->ucCodeStd == 0)
      {//DECT Coding
        pucTemp++; //octet 4
        *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucECT);
        *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucNI)) << 4);
        *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucDefault2)) << 7);
        ucLen++;
        pucTemp++;//octet 5
        *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucITR);
        *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucTM)) << 5);
        *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5)) << 7);
        ucLen++;
        if(((pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5) == 0) && (pxIWUAInfo->uxDectOrProf.xDectSS.ucITR==0X1F) )
        {//octet 5a present
          pucTemp++;//octet 5a
          *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucRM);
          *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucUR)) << 5);
          *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5a)) << 7);
          ucLen++;
          if(((pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5a) == 0) )
          {//octet 5b present
            pucTemp++;//octet 5b
            *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucEstab);
            *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucConfig)) << 2);
            *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure)) << 4);
            *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5b)) << 7);
            ucLen++;
          }
          if((pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure==0))
          {//5b omitted or structure field is default then table
            if(((pxIWUAInfo->uxDectOrProf.xDectSS.ucTM) == 0) &&
               ((pxIWUAInfo->ucProfileOrITC==0) ||
                (pxIWUAInfo->ucProfileOrITC==9) ||
                (pxIWUAInfo->ucProfileOrITC==0X10)||
                (pxIWUAInfo->ucProfileOrITC==0X11)||
                (pxIWUAInfo->ucProfileOrITC==0X14)||
                (pxIWUAInfo->ucProfileOrITC==0X18)))
            {
              (pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure)= 1;
              *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure)) << 4);
            }
            if(((pxIWUAInfo->uxDectOrProf.xDectSS.ucTM) == 2) &&
               (pxIWUAInfo->ucProfileOrITC==0X08))
            {
              (pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure)= 4;
              *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucStructure)) << 4);
            }
          }
          if((pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5b==0))
          {//5c present
            pucTemp++;//octet 5c
            *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucITRDO);
            *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucSymmetry)) << 5);
            *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5c)) << 7);
            ucLen++;
          }
          pucTemp++;//octet 5d
          *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucRMDO);
          *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucURDO)) << 5);
          *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn5d)) << 7);
          ucLen++;
        }
        pucTemp++;//octet 6
        *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucUPID);
        *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucDefault3)) << 5);
        *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn6)) << 7);
        ucLen++;
        if((pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn6==0))
        {//octet 6a present
          pucTemp++;//octet 6a
          *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucL3PID);
          *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucDefault4)) << 5);
          *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn6a)) << 7);
          ucLen++;
        }
        if((pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn6a==0))
        {//octet 6b present
          pucTemp++;//octet 6b
          *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucL2PID);
          *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucDefault5)) << 5);
          *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xDectSS.ucExtn6b)) << 7);
          ucLen++;
        }
        *pucLen=ucLen;//octet 2
      }
      if(pxIWUAInfo->ucCodeStd == 1)
      {//Profile Coding
        pucTemp++; //octet 4
        *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucPST);
        *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucNI)) << 4);
        *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucDefault2)) << 7);
        ucLen++;
        pucTemp++;//octet 5
        *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucMaxSDUSizeM);
        *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5)) << 7);
        ucLen++;
        #if 0 // #ifndef CONFIG_UPDATE_SUOTA
        if((pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5==0))
        #endif
        {
          pucTemp++;//octet 5a
          *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucMaxSDUSizeL);
          *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5a)) << 7);
          ucLen++;
        }
        #if 1 // #ifdef CONFIG_UPDATE_SUOTA
        if((pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5a==0))
        {
           pucTemp++;//octet 5b
           *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucMaxSDUSizeM2);
           *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5b)) << 7);
           ucLen++;
           pucTemp++;//octet 5c
           *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucMaxSDUSizeL2);
           *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucExtn5c)) << 7);
           ucLen++;
        }
        if ((pxIWUAInfo->uxDectOrProf.xProfileSS.ucDefault3==1)) { // if one D-GMEP control set
           pucTemp++;//octet 6
           *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSA);
           *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucDefault3)) << 7);
           ucLen++;
           pucTemp++;//octet 6a
           *pucTemp= pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSAa;
           ucLen++;
           pucTemp++;//octet 6b
           *pucTemp= pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSAb;
           ucLen++;
           pucTemp++;//octet 6c
           *pucTemp= pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSAc;
           ucLen++;
        }
        #else
        if((pxIWUAInfo->uxDectOrProf.xProfileSS.ucOctet6==1))
        {//octet 6 present
          pucTemp++;//octet 6
          *pucTemp= (uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucPSA);
          *pucTemp= (*pucTemp) | (((uchar8)(pxIWUAInfo->uxDectOrProf.xProfileSS.ucDefault3)) << 7);
          ucLen++;
        }
        #endif
        *pucLen=ucLen;//octet 2
      }
      else
      {//neither Dect nor Profile
        *pucLen=ucLen;
      }
      return IFX_SUCCESS;
    }
  }
    return IFX_FAILURE;
}
         
               
         

            
           
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_NewIECreate
  * Description       :  A function used to create memory space for new IE
  * Return Value      :  Handler to the created IE space is returned
                         Null value denotes unsuccessful operation
  * Notes             :  250 bytes of memory space is allocated and handle to 
                         it is returned 
 ****************************************************************************/

  uint32 IFX_DECT_IE_NewIECreate(uchar8 *pucBuff)
  {
    if(pucBuff!=0)
    {
      DATA_FRAME* pxDataFr = (DATA_FRAME *)(pucBuff);   
      memset(pucBuff,0,250);
      pxDataFr->length =0;

			return (uint32)pxDataFr->dat;
    }
    else
    {
      printf("Buffer is NULL\n");
      return IFX_FAILURE;
    }
  }

//FormIE is an internal function

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_FormIE
  * Description       :  A function used to create new IE
  * Input Values      :  1. enum of IE to be constructed
                         2. IE content structure
  * Output Value      :  Length of the newly created IE 
  * Return Value      :  Handler to the created new IE space is returned
                         Null value denotes unsuccessful operation
  * Notes             :  memory space is allocated and the IE is formed using
                         the IE enum and IE content structure
 ****************************************************************************/


e_IFX_Return IFX_DECT_IE_FormIE( e_IFX_DECT_IE eIE, void *pxIEStruct, uchar8 *pucIELen, uint32 uiCIEHdl)
{
  uchar8 *pucTemp = (uchar8 *)(uiCIEHdl);
  if(uiCIEHdl!=0)
  {
    switch(eIE)
    {
	case IFX_DECT_IE_CODECLIST:
	{
	  DATA_FRAME *source_ptr =(DATA_FRAME *) pxIEStruct;
      *pucTemp= (uchar8)IFX_DECT_IE_CODECLIST;
	  pucTemp++;
      *pucTemp= ((DATA_FRAME *) source_ptr)->length;
      pucTemp++;
	  memcpy(pucTemp,((DATA_FRAME *) source_ptr)->dat,((DATA_FRAME *) source_ptr)->length);
      *pucIELen = ((DATA_FRAME *) source_ptr)->length + 2;
	}
	break;
	case IFX_DECT_IE_EVENTNOTIFY:
	  
	  {
       x_IFX_DECT_IE_EventNotify *pxENInfo = (x_IFX_DECT_IE_EventNotify*)pxIEStruct;
	   if(IFX_DECT_IE_EventsNotificationSet(uiCIEHdl,pxENInfo)==IFX_SUCCESS){
			           
		  *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
		  break;
	   }else{

	     return IFX_FAILURE;
		} 
	   break;	 
	
	  }
    case IFX_DECT_IE_CALLINFORMATION:

       {
	    x_IFX_DECT_IE_CallInfo *pxCallInfo = (x_IFX_DECT_IE_CallInfo*)pxIEStruct;
		if(IFX_DECT_IE_CallInformationSet(uiCIEHdl,pxCallInfo)==IFX_SUCCESS){
				                         
		  *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
		  break;
	    }else{

		  return IFX_FAILURE;
		 }
		break;
	   
	   }
#if 0	
	case IFX_DECT_IE_TERMCAPABILITY:

	    {
         x_IFX_DECT_IE_Term_Capability *pxTermCapInfo = (x_IFX_DECT_IE_Term_Capability*)pxIEStruct;  
         if(IFX_DECT_IE_TermCapabilitySet(uiCIEHdl,pxTermCapInfo)==IFX_SUCCESS){

           *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         }else{

		   return IFX_FAILURE;
		  }
		break;  
		}
#endif		
    case IFX_DECT_IE_BASICSERVICE:
       *pucTemp= (uchar8)IFX_DECT_IE_BASICSERVICE;//octet 1
       pucTemp++;
       *pucTemp= *((uchar8 *)pxIEStruct);//octet 2 
       if((pucTemp==0) || (*pucTemp == 0))
       //no content or null pointer return null
       {
         return IFX_FAILURE;
       }
       *pucIELen = 2;
       break;
       
    case IFX_DECT_IE_SIGNAL:
       *pucTemp= (uchar8)IFX_DECT_IE_SIGNAL;//octet 1
       pucTemp++;
       *pucTemp = *((uchar8 *)pxIEStruct);//octet 2
       if((pucTemp==0) || (*pucTemp == 0))
       //no content or null pointer return null
       {
         return IFX_FAILURE;
       }
       *pucIELen = 2;
       break;

    case IFX_DECT_IE_SINGLEKEYPAD:
       *pucTemp= (uchar8)IFX_DECT_IE_SINGLEKEYPAD;//octet 1
       pucTemp++;
       *pucTemp = *((uchar8 *)pxIEStruct);//octet 2
       if((pucTemp==0) || (*pucTemp == 0))
       //no content or null pointer return null
       {
         return IFX_FAILURE;
       }
       *pucIELen = 2;
       break;

    case IFX_DECT_IE_SINGLEDISPLAY:
       *pucTemp= (uchar8)IFX_DECT_IE_SINGLEDISPLAY;//octet 1
       pucTemp++;
       *pucTemp = *((uchar8 *)pxIEStruct);//octet 2
       if((pucTemp==0) || (*pucTemp == 0))
       //no content or null pointer return null
       {
         return IFX_FAILURE;
       }
       *pucIELen = 2;
       break;

    case IFX_DECT_IE_REPEATINDICATOR:
       *pucTemp =*((uchar8 *)pxIEStruct);//octet 1 
       if((pucTemp==0) || (*pucTemp == 0))
       //no content or null pointer return null
       {
         return IFX_FAILURE;
       }
       *pucIELen = 1;
       break;

    case IFX_DECT_IE_USETPUI:
       *pucTemp =*((uchar8 *)pxIEStruct);//octet 1 
       if((pucTemp==0) || (*pucTemp == 0))
       //no content or null pointer return null
       {
         return IFX_FAILURE;
       }
       *pucIELen = 1;
       break;

    case IFX_DECT_IE_TIMERRESTART:
      *pucTemp =*((uchar8 *)pxIEStruct);//octet 1 
       if((pucTemp==0) || (*pucTemp == 0))
       //no content or null pointer return null
       {
         return IFX_FAILURE;
       }
       *pucIELen = 1;
       break;

    case IFX_DECT_IE_CALLATTRIBUTES:
     {
       x_IFX_DECT_IE_CallAttributes *pxCAInfo
             = (x_IFX_DECT_IE_CallAttributes *)pxIEStruct; 
       if(IFX_DECT_IE_SetCallAttributes(uiCIEHdl,pxCAInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }  
    case IFX_DECT_IE_CALLEDPARTYNUMBER:
     {
       x_IFX_DECT_IE_CalledPartyNumber *pxCdPNumInfo =
               (x_IFX_DECT_IE_CalledPartyNumber *)pxIEStruct; 
       if(IFX_DECT_IE_SetCalledPartyNumber(uiCIEHdl,pxCdPNumInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_CALLINGPARTYNAME:
     { 
       x_IFX_DECT_IE_CallingPartyName *pxCgPNameInfo =
                          (x_IFX_DECT_IE_CallingPartyName *)pxIEStruct; 
       if(IFX_DECT_IE_SetCallingPartyName(uiCIEHdl,pxCgPNameInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_CONNECTIONATTRIBUTES:
      {  
        x_IFX_DECT_IE_ConnectionAttributes *pxCAInfo =
                          (x_IFX_DECT_IE_ConnectionAttributes *)pxIEStruct; 
       if(IFX_DECT_IE_SetConnectionAttributes(uiCIEHdl,pxCAInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_CONNECTIONIDENTITY:
     {
       x_IFX_DECT_IE_ConnectionIdentity *pxCIDInfo =
                           (x_IFX_DECT_IE_ConnectionIdentity *)pxIEStruct; 
       if(IFX_DECT_IE_SetConnectionIdentity(uiCIEHdl,pxCIDInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_FACILITY:
     {
       x_IFX_DECT_IE_Facility *pxFacility =
                           (x_IFX_DECT_IE_Facility *)pxIEStruct; 
       if(IFX_DECT_IE_SetFacility(uiCIEHdl,pxFacility)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_IWUATTRIBUTES:
     {
       x_IFX_DECT_IE_IWUAttributes *pxIWUAInfo =
                           (x_IFX_DECT_IE_IWUAttributes *)pxIEStruct; 
       if(IFX_DECT_IE_SetIWUAttributes(uiCIEHdl,pxIWUAInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_IWUTOIWU:
     {
       x_IFX_DECT_IE_IWUToIWU *pxITIInfo =
                           (x_IFX_DECT_IE_IWUToIWU *)pxIEStruct; 
       if(IFX_DECT_IE_SetIWUToIWU(uiCIEHdl,pxITIInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_MULTIKEYPAD:
     {
       x_IFX_DECT_IE_MultiKeypad *pxMKPInfo =
                           (x_IFX_DECT_IE_MultiKeypad *)pxIEStruct; 
       if(IFX_DECT_IE_SetMultiKeypad(uiCIEHdl,pxMKPInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_MULTIDISPLAY:
     {
       x_IFX_DECT_IE_MultiDisplay *pxMDInfo =
                           (x_IFX_DECT_IE_MultiDisplay *)pxIEStruct; 
       if(IFX_DECT_IE_SetMultiDisplay(uiCIEHdl,pxMDInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_ESCAPETOPROPRIETARY:
     {
       x_IFX_DECT_IE_EscapeToProprietary *pxETPInfo =
                           (x_IFX_DECT_IE_EscapeToProprietary *)pxIEStruct; 
       if(IFX_DECT_IE_SetEscapeToProprietary(uiCIEHdl,pxETPInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_TIMEDATE:
     {
       x_IFX_DECT_IE_TimeDate *pxTDInfo =
                           (x_IFX_DECT_IE_TimeDate *)pxIEStruct; 
       if(IFX_DECT_IE_SetTimeDate(uiCIEHdl,pxTDInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_PORTABLEIDENTITY:
     {
       x_IFX_DECT_IE_PortableIdentity *pxPIDInfo =
                           (x_IFX_DECT_IE_PortableIdentity *)pxIEStruct; 
       if(IFX_DECT_IE_SetPortableIdentity(uiCIEHdl,pxPIDInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_FIXEDIDENTITY:
     {
       x_IFX_DECT_IE_FixedIdentity *pxFIDInfo =
                           (x_IFX_DECT_IE_FixedIdentity *)pxIEStruct; 
       if(IFX_DECT_IE_SetFixedIdentity(uiCIEHdl,pxFIDInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_CALLINGPARTYNUMBER:
     {
       x_IFX_DECT_IE_CallingPartyNumber *pxCgPNumInfo =
                           (x_IFX_DECT_IE_CallingPartyNumber *)pxIEStruct; 
       if(IFX_DECT_IE_SetCallingPartyNumber(uiCIEHdl,pxCgPNumInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_IWUPACKET:
     {
       x_IFX_DECT_IE_IWUPacket *pxIWUPInfo =
                           (x_IFX_DECT_IE_IWUPacket *)pxIEStruct; 
       if(IFX_DECT_IE_SetIWUPacket(uiCIEHdl,pxIWUPInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
#if 0
    case IFX_DECT_IE_CODECLIST:
     {
       x_IFX_DECT_IE_CodecList *pxCLInfo =
                           (x_IFX_DECT_IE_CodecList *)pxIEStruct; 
       if(IFX_DECT_IE_SetCodecList(uiCIEHdl,pxCLInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
#endif
    case IFX_DECT_IE_WINDOWSIZE:
     {
       x_IFX_DECT_IE_WindowSize *pxWSInfo =
                           (x_IFX_DECT_IE_WindowSize *)pxIEStruct; 
       if(IFX_DECT_IE_SetWindowSize(uiCIEHdl,pxWSInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_PROGRESSINDICATOR:
     {
       x_IFX_DECT_IE_ProgressIndicator *pxPIInfo =
                           (x_IFX_DECT_IE_ProgressIndicator *)pxIEStruct; 
       if(IFX_DECT_IE_SetProgressIndicator(uiCIEHdl,pxPIInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_SERVICECHANGEINFO:
     {
       x_IFX_DECT_IE_ServiceChange *pxSChangeInfo =
                           (x_IFX_DECT_IE_ServiceChange *)pxIEStruct; 
       if(IFX_DECT_IE_SetServiceChange(uiCIEHdl,pxSChangeInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_LOCATIONAREA:
     {
       x_IFX_DECT_IE_LocationArea *pxLAInfo =
                           (x_IFX_DECT_IE_LocationArea *)pxIEStruct; 
       if(IFX_DECT_IE_SetLocationArea(uiCIEHdl,pxLAInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_AUTHTYPE:
     {
       x_IFX_DECT_IE_AuthType *pxATInfo =
                           (x_IFX_DECT_IE_AuthType *)pxIEStruct; 
       if(IFX_DECT_IE_SetAuthType(uiCIEHdl,pxATInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_CIPHERINFO:
     {
       x_IFX_DECT_IE_Cipher *pxCIInfo =
                           (x_IFX_DECT_IE_Cipher *)pxIEStruct; 
       if(IFX_DECT_IE_SetCipher(uiCIEHdl,pxCIInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_SERVICECLASS:
    {
       uchar8 *pucSClass = (uchar8 *)pxIEStruct;
       if(IFX_DECT_IE_SetServiceClass(uiCIEHdl,pucSClass)==IFX_SUCCESS)
       {
        *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_SETUPCAPABILITY:
     {
       x_IFX_DECT_IE_SetupCapability *pxSCapInfo =
                           (x_IFX_DECT_IE_SetupCapability *)pxIEStruct; 
       if(IFX_DECT_IE_SetSetupCapability(uiCIEHdl,pxSCapInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_MODELIDENTIFIER:
     {
       x_IFX_DECT_IE_ModelIdentifier *pxMIInfo =
                           (x_IFX_DECT_IE_ModelIdentifier *)pxIEStruct; 
       if(IFX_DECT_IE_SetModelIdentifier(uiCIEHdl,pxMIInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_REJECTREASON:
     {
       uchar8 *pucRejRsnInfo = (uchar8 *)pxIEStruct; 
       if(IFX_DECT_IE_SetRejectReason(uiCIEHdl,pucRejRsnInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
     
    case IFX_DECT_IE_RELEASE_REASON:
       *pucTemp= (uchar8)IFX_DECT_IE_RELEASE_REASON;//octet 1
       pucTemp++;
       *pucTemp= *((uchar8 *)pxIEStruct);//octet 2 
       *pucIELen = 2;
       break;
       
    case IFX_DECT_IE_DURATION:
     {
       x_IFX_DECT_IE_Duration *pxDurationInfo =
                           (x_IFX_DECT_IE_Duration *)pxIEStruct; 
       if(IFX_DECT_IE_SetDuration(uiCIEHdl,pxDurationInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_RAND:
     {
       x_IFX_DECT_IE_RAND *pxRANDInfo =
                           (x_IFX_DECT_IE_RAND *)pxIEStruct; 
       if(IFX_DECT_IE_SetRAND(uiCIEHdl,pxRANDInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_RES:
     {
       x_IFX_DECT_IE_RES *pxRESInfo =
                           (x_IFX_DECT_IE_RES *)pxIEStruct; 
       if(IFX_DECT_IE_SetRES(uiCIEHdl,pxRESInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_RS:
     {
       x_IFX_DECT_IE_RS *pxRSInfo =
                           (x_IFX_DECT_IE_RS *)pxIEStruct; 
       if(IFX_DECT_IE_SetRS(uiCIEHdl,pxRSInfo)==IFX_SUCCESS)
       {
         *pucIELen = *((uchar8 *)(uiCIEHdl+1))+2;
         break;
       }
       else
       {
         return IFX_FAILURE;
       }
     }
    case IFX_DECT_IE_NOTIE:
       return IFX_FAILURE;
    case IFX_DECT_IE_GENERICIE:
       return IFX_FAILURE;
    default:
       return IFX_FAILURE;
    }
    return IFX_SUCCESS;
  }
    return IFX_FAILURE;
}



 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_IEAdd
  * Description       :  A function used to add an IE to already existing 
                         message structure.                          
  * Input Values      :  enum of the new IE to be added (eIE)
                         Pointer to the content to be added into the new IE           
  * Input Value       :  Handler to the first IE(uiMsgHdl) of the message
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The location where the new IE is to be added in the IPC
                         message is determined and the new IE formed is 
                         filled in that location. The function ensures that
                         the IEs added to the message are arranged in ascending
                         order of their enums
*******************************************************************************/
     
 e_IFX_Return IFX_DECT_IE_IEAdd(uint32 uiMsgHdl, e_IFX_DECT_IE eIE, void *pxIEStruct)
{
  uchar8 ucIELen=0;
  uint32 uiCIEHdl=0;
  uchar8 acTempBuff[250]={0};
  uchar8 ucFlag = 0;
  uchar8 ucRIInfo = 0;
  e_IFX_Return eRet = IFX_FAILURE;
 
  uiCIEHdl = IFX_DECT_IE_NewIECreate(acTempBuff);
  if((uiMsgHdl != 0) && (eIE!=0) && (eIE!=0XFF) && (pxIEStruct!=0))
  {
      
    if(IFX_DECT_IE_FormIE(eIE,pxIEStruct,&ucIELen,uiCIEHdl)==IFX_SUCCESS)
    {
      uchar8 *pucTemp= (uchar8 *)uiMsgHdl;
      uchar8 *pucTempRI= pucTemp;
      const uchar8 *pucTemp2 = (uchar8 *)uiCIEHdl;
	  
      if(((TOTALIESIZE-(*((uchar8 *)(uiMsgHdl-1)))) > ucIELen) && (uiCIEHdl!=0) )
      //check whether enough space is present for new IE and uiCIEHdl is not a null value
      { //to get the position where the new IE is to be inserted
        uint32 uiIEHdl=0;
	   if(vucRI == 0)
	   {
        while(((((e_IFX_DECT_IE) ((*pucTemp) & 0XF0)) == IFX_DECT_IE_REPEATINDICATOR) 
		        || (eIE >= (e_IFX_DECT_IE) (*pucTemp))) &&
                (pucTemp <= (uchar8 *)(uiMsgHdl+TOTALIESIZE-1)) && (*pucTemp!=0))
        {
          uiIEHdl = (uint32)pucTemp;
		  ucFlag = 0;
             
		  if(((e_IFX_DECT_IE) ((*pucTemp) & 0XF0)) == IFX_DECT_IE_REPEATINDICATOR)
		  {
            pucTempRI = pucTemp;
			ucFlag = 1;
		  }
		  
		  if(eIE == (e_IFX_DECT_IE) (*pucTemp))
		  {
            //Checking if RI for this IE already exists.
			pucTempRI = pucTemp;
			if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl )==IFX_SUCCESS)
			{
                pucTemp=(uchar8 *)uiIEHdl;

			}else{
              return IFX_FAILURE;
			 }
            if(((e_IFX_DECT_IE) (*pucTemp)) == eIE) 
			{
				  vucRI = 0;
				  veIE = IFX_DECT_IE_NOTIE;
           
			}else{
		      vucRI = 1;
			  veIE = eIE;
			  if((eIE == IFX_DECT_IE_CALLATTRIBUTES) || (eIE == IFX_DECT_IE_AUTHTYPE) || (eIE == IFX_DECT_IE_CIPHERINFO))
			  {
                ucRIInfo = 0XD2;//Prioritized List   
			  }else
			   {
                ucRIInfo = 0XD1;//Non-Prioritized List
			   }
			   
			 } 
		     pucTemp = pucTempRI;
			 break;
		  }
		  
          if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl )==IFX_SUCCESS)
          {
            pucTemp=(uchar8 *)uiIEHdl;
            continue;// goes back to while loop for condition check
          }

          return IFX_FAILURE;
        };
	   }else
        {
          vucRI = 0;	
		  pucTemp = (uchar8 *)uiMsgHdl;
		  
		  while((((e_IFX_DECT_IE) (*pucTemp)) != veIE) && (pucTemp <= (uchar8 *)(uiMsgHdl+TOTALIESIZE-1)) 
		          && (*pucTemp!=0 ))
		  {
		    uiIEHdl = (uint32)pucTemp;
		    if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl )==IFX_SUCCESS)
			{
		      pucTemp=(uchar8 *)uiIEHdl;
			  continue;// goes back to while loop for condition check
			}
		    veIE = IFX_DECT_IE_NOTIE;
			return IFX_FAILURE;
                     
		  }
		  veIE = IFX_DECT_IE_NOTIE;
		}
	   
		if(ucFlag == 1)
		{
          pucTemp = pucTempRI;  

		}
        pucTemp2 = (uchar8 *)uiCIEHdl;
        if(*pucTemp == 0)
        {//first IE or new IE is being filled at the end of IE list

          if(ucIELen<=TOTALIESIZE)
          {//to check for sufficient space for memcpy
            memcpy(pucTemp,pucTemp2,ucIELen);
            // to store IE length in 1st byte
            *(uchar8 *)(uiMsgHdl-1) += ucIELen;
            eRet = IFX_SUCCESS;
          }
          //eRet =  IFX_FAILURE;
        }
        else if( (eIE <= (e_IFX_DECT_IE) (*pucTemp)) || (eIE == IFX_DECT_IE_REPEATINDICATOR) || (ucFlag == 1) )
        {//pucTemp denotes the location where new IE has to be filled
          uint32 uiIEHdl1= (uint32)pucTemp;
          uchar8 ucTemp2= *(uchar8 *)(uiMsgHdl-1) - (uchar8)(uiIEHdl1-uiMsgHdl);
          //total number of bytes to be moved == bytes present below pucTemp
          const uchar8 *pucTemp1 = pucTemp;
          //move bytes to facilitate new IE insertion
          memmove(pucTemp+ ucIELen,pucTemp1,ucTemp2);
          //memmove(((uchar8 *)((uint32)(pucTemp)+ (uint32)(ucIELen))),pucTemp1,ucTemp2);
          //memcpy new IE
          memcpy(pucTemp,pucTemp2,ucIELen);
          // to store IE length in 1st byte
          (*(uchar8 *)(uiMsgHdl-1)) += ucIELen;
		  eRet = IFX_SUCCESS;
		 } 
		  if(vucRI == 1)
		  {
            if(IFX_DECT_IE_IEAdd(uiMsgHdl,IFX_DECT_IE_REPEATINDICATOR,(void*)&ucRIInfo) == IFX_SUCCESS)
			  {
			    
			    return IFX_SUCCESS;
			  }else
			   {
                return IFX_FAILURE;
			   }
		  }
          return eRet;
      }
    }
  }

  return IFX_FAILURE;
}

          
          
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_AppendIE
  * Description       :  A function used to append a set of IEs to the existing   
                         message structure 
  * Input Values      :  Handler to the first IE of the message structure
                         Handler to the IE to be appended
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  The message structure is checked for sufficient memory
                         space and IE is then appended 
 ****************************************************************************/
  e_IFX_Return IFX_DECT_IE_IEAppend(uint32 uiDMsgHdl, uint32 uiSMsgHdl)
  {
    if(uiDMsgHdl!=0 && uiSMsgHdl!=0)//check whether handles are null values
    {
      const uchar8 *pucSTemp = (uchar8 *) uiSMsgHdl;
      uchar8 *pucDTemp= (uchar8 *)uiDMsgHdl;
      if(*(pucSTemp-1) <= (TOTALIESIZE -  *(pucDTemp-1)) )
      //sufficient memory space in destination message structure
      {
        memcpy((pucDTemp+ (*(pucDTemp-1))),pucSTemp , *(pucSTemp-1));
      //modify acData[TOTALIESIZE]
        (*(pucDTemp-1))+=*(pucSTemp-1);
        return IFX_SUCCESS;
      }
    }
    return IFX_FAILURE;
  }


                                     
 
 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_GenericIEAdd
  * Description       :  A function used to append an IE to the existing   
                         message structure 
  * Input Values      :  Handler to the first IE of the message structure
                         Handler to the IE to be appended
  * Return Value      :  Handler to the appended IE in the message structure
                         Null value denotes unsuccessful operation
  * Notes             :  The message structure is checked for sufficient memory
                         space and IE is then appended 
 ****************************************************************************/
  e_IFX_Return IFX_DECT_IE_GenericIEAdd(uint32 uiDMsgHdl, uchar8 *pucBuff, uchar8 ucIELen)
  {
    if(uiDMsgHdl!=0 && pucBuff!=0 && *pucBuff!=0 && ucIELen!=0)//check whether handles are null values
    {
      const uchar8 *pucSTemp = pucBuff;
      uchar8 *pucDTemp= (uchar8 *)uiDMsgHdl;
      if(ucIELen <= (TOTALIESIZE -  *(pucDTemp-1)) )
      //sufficient memory space in destination message structure
      {
        memcpy((pucDTemp+ (*(pucDTemp-1))),pucSTemp ,ucIELen );
        (*(pucDTemp-1))+=ucIELen;
        return IFX_SUCCESS;
      }
    }
    return IFX_FAILURE;
  }

 

 /*****************************************************************************
  * Function Name     :  IFX_DECT_IE_GenericIEGet
  * Description       :  A function used to fetch the pointer to the IE in the 
                         imessage structure and its length  
  * Input Value       :  IE Handler to the Generic IE
  * Output Values     :  Pointer to IE 
                         Pointer to IE length
  * Return Value      :  boolean to denote success or failure of operation
  * Notes             :  Given IE Handle is converted into a char pointer and
                         IE length is determined and filled using the pucIELen
                         pointer
 ****************************************************************************/

 e_IFX_Return IFX_DECT_IE_GenericIEGet(uint32 uiIEHdl,uchar8 *pucIEHdl, uchar8 *pucIELen)
  {
    pucIEHdl= (uchar8 *)uiIEHdl;
    if(uiIEHdl!=0 && pucIEHdl!=0 && pucIELen!=0)
    {
      uchar8 *pucTemp=(uchar8 *)uiIEHdl;
      if( ((*pucTemp) & 0X80) == 0X80)       
      { //fixed IE 
        if( ((*pucTemp) & 0XE0 )== 0XE0)
        { //double octet
          *pucIELen=2; 
        }                                            
        else
        { // single octet
           *pucIELen=1;
        }
      }
      else
      {//variable IE                
        *pucIELen = *(pucIEHdl+1) + 2;
      }
      return IFX_SUCCESS;
    }
    return IFX_FAILURE;
  }
                                         

