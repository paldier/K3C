/**************************************************************************
**   FILE NAME     : IFX_DECT_ULE_Global.h 
**   PROJECT       : DECT^M
**   MODULES       : DECT Tool kit^M
**   SRC VERSION   : V1.0 ^M
**   DATE          : 11-05-2013^M
**   AUTHOR        : ^M
**   DESCRIPTION   : Structure definition for DECT ULE 
**   COMPILER      : gcc^M
**   REFERENCE     : Coding guide lines^M
**   COPYRIGHT     : Copyright (c) 2004^M
**                   Infineon Technologies AG, st. Martin Strasse 53;^M
**                   81669 Munchen, Germany^M
**^M
**   Any use of this software is subject to the conclusion of a respective^M
**   License agreement. Without such a License agreement no rights to the^M
**   software is granted^M
^M
**  Version Control Section  **        ^M
**   $Author$    ^M
**   $Date$      ^M
**   $Revisions$ ^M
**   $Log$       Revision history^M
***********************************************************************/

#ifndef __IFX_DECT_ULE_GLOBAL_H__
#define __IFX_DECT_ULE_GLOBAL_H__

#ifdef ULE_SUPPORT

/* This has to be used to deduct from the PP number  and used as an index to
access the ULE Global array by both stack and TK */
#define IFX_DECT_ULE_OFFSET 32
//#define SMART_HOME_DEMO 1
#define IFX_DECT_MAX_ULE_SDUSIZE 500 
#define IFX_DECT_MAX_ULE_WINDOWSIZE IFX_DECT_MAX_ULE_SDUSIZE*2 
#define IFX_DECT_ULE_RESUME 0x09
#define IFX_DECT_ULE_SUSPEND 0x08
#define IFX_DECT_ULE_OTHER 0x00
#define IFX_DECT_ULE_DATASEND_TIMEOUT 30000 //in mS

e_IFX_Return IFX_DECT_ULE_ProcessUPlaneMsg( x_IFX_DECT_IPC_Msg_u *pxUPlaneIpcMsg);
e_IFX_Return IFX_DECT_ULE_ProcessCPlaneMsg( x_IFX_DECT_IPC_Msg *pxCPlaneIpcMsg);
e_IFX_Return IFX_DECT_MU_ULE_UnregisterPP(IN uchar8 ucInstance,IN uchar8 ucHandset);
e_IFX_Return IFX_DECT_MU_ULE_UNRegister(IN uchar8 isAll,IN uchar8 ucHandset);

typedef enum{
	IFX_DECT_ULE_LU10,
	IFX_DECT_ULE_LU13,
	IFX_DECT_ULE_LU14,
}e_IFX_DECT_ULE_DATA_Packets;

typedef enum{
	IFX_DECT_ULE_CALL_IDLE,
	IFX_DECT_ULE_SETUP,
	IFX_DECT_ULE_CPLANE_CONNECTED,
}e_IFX_DECT_ULE_CallStates;

typedef enum{
	IFX_DECT_ULE_EXP_IDLE,
	IFX_DECT_ULE_EXP_CONNECTED,
}e_IFX_DECT_ULE_ExpConStates;



typedef enum{
	IFX_DECT_ULE_IDLE,
	IFX_DECT_ULE_REGISTERED,
	IFX_DECT_ULE_ATTACHED,
}e_IFX_DECT_ULE_MUStates;


typedef enum{
	IFX_DECT_ULE_DATA_IDLE,
	IFX_DECT_ULE_DATA_INPROGRESS,
	IFX_DECT_ULE_CLOSE_INPROGRESS,
	IFX_DECT_ULE_BPAGING_INPROGRESS,
	IFX_DECT_ULE_SETUP_AFTER_N_FRAMES,
}e_IFX_DECT_ULE_DataStates;

typedef enum{
	IFX_DECT_ULE_CCM_IDLE,
	IFX_DECT_ULE_CCM_INPROGRESS,
	IFX_DECT_ULE_CCM_GENERATED,
}e_IFX_DECT_ULE_CCMStates;


typedef enum{
	IFX_DECT_ULE_NWK_SUSPEND,
	IFX_DECT_ULE_NWK_RESUME,
	IFX_DECT_ULE_NWK_RESUME_RQOUT,
	IFX_DECT_ULE_NWK_RESUME_RQIN,
	IFX_DECT_ULE_NWK_SUSPEND_RQOUT,
	IFX_DECT_ULE_NWK_SUSPEND_RQIN,
	IFX_DECT_ULE_NWK_OTHER_RQOUT,
	IFX_DECT_ULE_NWK_OTHER_RQIN,
}e_IFX_DECT_ULE_NWKStates;

typedef enum{
	IFX_DECT_ULE_SERVICE_CALL=1,
	IFX_DECT_ULE_DPSU_CALL=2,	
}e_IFX_DECT_ULE_CallTypes;


typedef struct{
	e_IFX_DECT_ULE_MUStates eMuState;
	e_IFX_DECT_ULE_CallStates eCallState;  /*!<State of a PP */
	e_IFX_DECT_ULE_DataStates eDataSendState;  /*!<State of a PP */
	e_IFX_DECT_ULE_DataStates eDataRecvState;  /*!<State of a PP */
	e_IFX_DECT_ULE_CCMStates eCCMState;  /*!<State of a PP */
	e_IFX_DECT_ULE_NWKStates  eNWKState;
	e_IFX_DECT_ULE_ExpConStates eExpConState;
	//uchar8 ucWindowSize;
	//uint32 uiSDUSize;
	//uint32 uiRSN;
	//uint32 uiSSN;
	char8 *pcSendBuf;
	char8 *pcRecvBuf;
	uint32 uiDataSendTimerId;
	uchar8 ucServiceCallOwner;
	uchar8 ucNeedPVCResync;
	uchar8 ucCallType;
}x_IFX_DECT_ULE_CallInfo;
typedef struct{
	uchar8 ucProtoID;
	uchar8 ucProtoVer;
	uchar8 ucCoreVer;
	uchar8 ucProfVer;
	uchar8 ucInterfaceVer;
	uint32 uiEMC;
}x_IFX_DECT_ULE_HF_Version;

typedef struct{
	uint16 unMaxULEDevSupported;
	x_IFX_DECT_ULE_Config xULEConfig;
	x_IFX_DECT_ULE_SubscData xULESubscData;
	x_IFX_DECT_ULE_CallBks xULECallBks;
	x_IFX_DECT_ULE_CallInfo *pxULECallInfo;
//	x_IFX_DECT_ULE_HF_Version xHFVersion;	
	x_IFX_DECT_ULE_HF_Attributes xHFAttr;	
}IFX_DECT_ULE_GlobalData;

#endif /* ULE_SUPPORT*/

#endif /*__IFX_DECT_ULE_GLOBAL_H__*/
