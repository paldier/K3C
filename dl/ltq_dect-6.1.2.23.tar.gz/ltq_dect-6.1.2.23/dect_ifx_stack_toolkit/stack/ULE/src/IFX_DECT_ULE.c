#ifdef ULE_SUPPORT

#include <stdio.h>
#include "IFX_DECT_Platform.h"

#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_ULE_Global.h"
#include "IFX_DECT_StackIf.h"
#include "IFX_DECT_IEParser.h"

// #define CONFIG_TEST_SUOTA_PAGING

#define IFX_DECT_ULE_MAX_SENSORS 88
#define IFX_DECT_ULE_MAX_SLOWACT 88
#define IFX_DECT_ULE_MAX_FASTACT 88

#ifdef SMART_HOME_DEMO
static uint32 auiULEDeviceNum[200];
static uint16 vauiEMC[200];/*!< EMC Holding array */
#endif

int32 IFX_DECT_ULE_AllocDeviceNum(e_IFX_DECT_ULE_Type eDeviceType);
extern e_IFX_Return IFX_DECT_MU_DenyRegistration(void);
IFX_DECT_ULE_GlobalData xULE_Data;
int32 IFX_DECT_ULE_ErrNo;

static uchar8 aucSensorDeviceNum[10];
static uchar8 aucSlowActNum[10];
static uchar8 aucFastActNum[10];
static uchar8 ucSensorCount;
static uchar8 ucSlowActCount;
static uchar8 ucFastActCount;


#ifdef SMART_HOME_DEMO
#define IFX_DECT_ULE_LIGHTON_TIMEOUT 60000
uint32 vuiLightON=0;
uint32 vuiDeviceState=0;
void IFX_DECT_ULE_GetReg(uchar8* pucReg,uchar8* pn,uchar8 ucInstance)
{
   int i,n,j,k=0;
   *pn=0;
   if(ucInstance)
   {
     j=ucInstance -IFX_DECT_ULE_OFFSET;
     n=j+1;
   }
   else
   {
     n=10;
     j=0;
   }
   for(i=j;i<n;i++)
   {
     if(xULE_Data.xULESubscData.xRegList[i].cstatus){
      if(xULE_Data.xULESubscData.xRegList[i].ucDeviceNo == 50)
      {
         *(pucReg+(k*4)+0)=0x01;//REG Cmd
         *(pucReg+(k*4)+1)=i+IFX_DECT_ULE_OFFSET;
         *(pucReg+(k*4)+2)=0x01; //Manufactur DSPG
         *(pucReg+(k*4)+3)=0x02; //Smoke
         //*pn++;
         *pn=*pn+1;
         k++;
      }
      else if(xULE_Data.xULESubscData.xRegList[i].ucDeviceNo == 51)
      {
         *(pucReg+(k*4)+0)=0x01;//REG Cmd
         *(pucReg+(k*4)+1)=i+IFX_DECT_ULE_OFFSET;
         *(pucReg+(k*4)+2)=0x01; //Manufactur DSPG
         *(pucReg+(k*4)+3)=0x01; //Motion
         //*pn++;
         *pn=*pn+1;
         k++;
      }
      else if(xULE_Data.xULESubscData.xRegList[i].ucDeviceNo == 52)
      {
         *(pucReg+(k*4)+0)=0x01;//REG Cmd
         *(pucReg+(k*4)+1)=i+IFX_DECT_ULE_OFFSET;
         *(pucReg+(k*4)+2)=0x01; //Manufactur DSPG
         *(pucReg+(k*4)+3)=0x03; //Smart Plug
         //*pn++;
         *pn=*pn+1;
         k++;
      }
      else if(xULE_Data.xULESubscData.xRegList[i].eULEType == IFX_DECT_ULE_FASTACTUATOR)
      {
         *(pucReg+(k*4)+0)=0x01;//REG Cmd
         *(pucReg+(k*4)+1)=i+IFX_DECT_ULE_OFFSET;
         *(pucReg+(k*4)+2)=0x02; //Manufactur Dialog
         *(pucReg+(k*4)+3)=0x03; //Smart Plug
         //*pn++;
         *pn=*pn+1;
         k++;
      }
      else
      {
         *(pucReg+(k*4)+0)=0x01;//REG Cmd
         *(pucReg+(k*4)+1)=i+IFX_DECT_ULE_OFFSET;
         *(pucReg+(k*4)+2)=0x03; //Manufactur Gigaset
         *(pucReg+(k*4)+3)=0x01; //Motion
         //*pn++;
         *pn=*pn+1;
         k++;
      }
     }
   }
}
void IFX_DECT_ULE_LightONTimerExpFunc(IN uint32 uiTimerId,
                                           IN void* pvPrivateData)
{
uchar8 aucBuffOFF[]={0x31,0x45,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
uchar8 ucInstanceId = *((uchar8*)pvPrivateData);

vuiLightON=0;
IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "\nEntering IFX_DECT_ULE_LightONTimerExpFunc PP Num: = ",ucInstanceId);

if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
{
IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                "Invalid ULE instance number !!!!!!");
IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
return;
}
if(xULE_Data.pxULECallInfo == NULL)
{
IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                "ULE NOT INITED !!!!!!");
IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
return;
}

IFX_DECT_ULE_DataSend(ucInstanceId,((uint16)sizeof(aucBuffOFF)),(void *)aucBuffOFF);

}

void IFX_DECT_ULE_Handle_HANFUN_Alert(void)
{
int i;
x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
uchar8 aucBuffON[]={0x31,0x45,0x00,0x01,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "Entering IFX_DECT_ULE_Handle_HANFUN_Alert");
for(i=0;i<IFX_DECT_MAX_ULE_DEVICES;i++)
{
uchar8 ucInstanceId=i+IFX_DECT_ULE_OFFSET;
if(xULE_Data.xULESubscData.xRegList[i].eULEType == IFX_DECT_ULE_FASTACTUATOR)
{
   pxCallInfo=&xULE_Data.pxULECallInfo[i];
   if( pxCallInfo-> eNWKState == IFX_DECT_ULE_NWK_RESUME )
   {
      if(vuiLightON)
      {
         IFX_DECT_StopTimer(vuiLightON);
         vuiLightON=0;

         if(IFX_DECT_StartTimer(IFX_DECT_ULE_LIGHTON_TIMEOUT,&ucInstanceId,sizeof(uchar8),IFX_DECT_ULE_LightONTimerExpFunc,&vuiLightON) == IFX_FAILURE)
         {
               IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "IFX_DECT_ULE_Handle_HANFUN_Alert- Timet start failed2");
         }
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
           "IFX_DECT_ULE_Handle_HANFUN_Alert- LightON Timer ON",vuiLightON);
      }
      else
      {
      //    if(!vuiDeviceState)
            {
                  IFX_DECT_ULE_DataSend(i+IFX_DECT_ULE_OFFSET,((uint16)sizeof(aucBuffON)),(void *)aucBuffON);
                  if(IFX_DECT_StartTimer(IFX_DECT_ULE_LIGHTON_TIMEOUT,&ucInstanceId,sizeof(uchar8),IFX_DECT_ULE_LightONTimerExpFunc,&vuiLightON) == IFX_FAILURE)
                  {
                     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                        "IFX_DECT_ULE_Handle_HANFUN_Alert- Timet start failed1");
                  }
                  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                        "IFX_DECT_ULE_Handle_HANFUN_Alert- Device state OFF TimerID=",vuiLightON);
            }
#if 0
            else
            {
                  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                        "IFX_DECT_ULE_Handle_HANFUN_Alert- Device state ON TimerID=",vuiLightON);
            }
#endif
      }
      break;
}
}
}
}

#endif
extern x_IFX_DECT_GlobalInfo vxGlobalInfo;
void IFX_DECT_GetRFPI(uchar8 *pucRfpi)
{
   if(pucRfpi != NULL)
   {
      memcpy(pucRfpi,vxGlobalInfo.xStackCfg.aucRfpi,IFX_DECT_MAX_RFPI_LEN);
   }
   return;
}

void IFX_DECT_ULE_GetPVCConnectedDevices(uchar8 *pucNumDevices, x_IFX_DECT_ULE_Device_IPUI *paxDevices)
{
   int i;
   *pucNumDevices =0;
   if(xULE_Data.pxULECallInfo == NULL)
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     " ULE_INIT has not been done!!!!!!");
      return;
   }

   for(i=0;i<xULE_Data.unMaxULEDevSupported;i++)
   {
      if(xULE_Data.pxULECallInfo[i].eNWKState == IFX_DECT_ULE_NWK_RESUME)
      {
         paxDevices[*pucNumDevices].ucDeviceId = (uchar8)(i+IFX_DECT_ULE_OFFSET);

         memcpy(paxDevices[*pucNumDevices].acipui_array,
            xULE_Data.xULESubscData.xRegList[i].acipui_array,IFX_DECT_IPUI_SIZE);
         (*pucNumDevices)++;
      }
   }
   return;
}


e_IFX_Return IFX_DECT_ULE_ResetPVC(IN uchar8 ucInstanceId)
{
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
   if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Invalid ULE instance number !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
      return IFX_FAILURE;
   }
   if(xULE_Data.pxULECallInfo == NULL)
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE NOT INITED !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
      return IFX_FAILURE;
   }
   pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];
   pxCallInfo->ucNeedPVCResync =1;/*PVC Resync needed*/

    return IFX_SUCCESS;
}

e_IFX_Return IFX_DECT_ULE_ConfigureHF_Attributes(x_IFX_DECT_ULE_HF_Attributes *pxHFAttr)
{
   memcpy(&xULE_Data.xHFAttr,pxHFAttr,sizeof(x_IFX_DECT_ULE_HF_Attributes));
    return IFX_SUCCESS;
}
#if 0
e_IFX_Return IFX_DECT_ULE_ConfigureHF_Version(uchar8 ucProtoID,uchar8 ucProtoVer, uchar8 ucCoreVer,
            uchar8 ucProfVer, uchar8 ucInterfaceVer, uint32 uiEMC)
{

   xULE_Data.xHFVersion.ucProtoID = ucProtoID;
   xULE_Data.xHFVersion.ucProtoVer = ucProtoVer;
   xULE_Data.xHFVersion.ucCoreVer = ucCoreVer;
   xULE_Data.xHFVersion.ucProfVer = ucProfVer;
   xULE_Data.xHFVersion.ucInterfaceVer = ucInterfaceVer;
   xULE_Data.xHFVersion.uiEMC = uiEMC;
}
e_IFX_Return IFX_DECT_ULE_SendHFVersion(IN uchar8 ucInstanceId)
{

   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
   x_IFX_DECT_IPC_Msg xIpcMsg={0};
   if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Invalid ULE instance number !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
      return IFX_FAILURE;
   }
   if(xULE_Data.pxULECallInfo == NULL)
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE NOT INITED !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
      return IFX_FAILURE;
   }

   pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];

  return IFX_SUCCESS;
}
#endif

void IFX_DECT_ULE_NotifyPVCState(uchar8 ucInstanceId, int32 iPVCState)
{
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "\nEntering IFX_DECT_ULE_NotifyPVCState PP Num: = ",ucInstanceId);
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "\nEntering IFX_DECT_ULE_NotifyPVCState PVC state: = ",iPVCState);
   if(xULE_Data.xULECallBks.pfnULENotify != NULL)
   {
      x_IFX_DECT_ULE_NotifyEvent xNotifyEvent;

      if(iPVCState == IFX_DECT_ULE_NWK_RESUME)
      {
         xNotifyEvent.eEvent=IFX_DECT_ULE_DEVICE_PVC_CONNECTED;
         memcpy(xNotifyEvent.uxNotify.acipui_array,
            xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].acipui_array,IFX_DECT_IPUI_SIZE);
         IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                "Notify IFX_DECT_ULE_DEVICE_PVC_CONNECTED !!!!!!");
      }
      else
      {
         xNotifyEvent.eEvent=IFX_DECT_ULE_DEVICE_PVC_DISCONNECTED;
         IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                "Notify IFX_DECT_ULE_DEVICE_PVC_DISCONNECTED !!!!!!");
      }
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                "calling pfnULENotify !!!!!!");
      xULE_Data.xULECallBks.pfnULENotify(ucInstanceId,&xNotifyEvent);
   }

   return;
}
e_IFX_Return IFX_DECT_ULE_Free_Init_DeviceNum(uchar8 ucDeviceNum, e_IFX_DECT_ULE_Type eDeviceType,uchar8 ucFreeInitFlg);


void IFX_DECT_ULE_DataSendTimerExpFunc (IN uint32 uiTimerId,
                                           IN void* pvPrivateData)
{
x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
x_IFX_DECT_ULE_NotifyEvent xULENotify;
uchar8 ucInstanceId = *((uchar8*)pvPrivateData);
IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "\nEntering IFX_DECT_ULE_DataSendTimerFunc expiry PP Num: = ",ucInstanceId);

if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
{
IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                "Invalid ULE instance number !!!!!!");
IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
return;
}
if(xULE_Data.pxULECallInfo == NULL)
{
IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                "ULE NOT INITED !!!!!!");
IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
return;
}

pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];
pxCallInfo->uiDataSendTimerId=0;

#ifdef SMART_HOME_DEMO
   if(vuiLightON)
   {
       IFX_DECT_StopTimer(vuiLightON);
       vuiLightON=0;
   }
#endif

   {
         x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};


         xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_PAGE_STOP_RQ;
         #ifdef CONFIG_TEST_SUOTA_PAGING
         if (pxCallInfo->eDataSendState == IFX_DECT_ULE_BPAGING_INPROGRESS) {
            xUPlaneIpcMsg.ucPara3 = 3;
         } else {
            xUPlaneIpcMsg.ucPara3 = 0;
         }
         #else
         xUPlaneIpcMsg.ucPara3 = 0;
         #endif
         xUPlaneIpcMsg.ucPara4 = ucInstanceId;
         if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
         {
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  " ULE Data send failed due to PostToStack failure");
            IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
         }

         if(pxCallInfo->eDataSendState == IFX_DECT_ULE_DATA_INPROGRESS)
         {
            xULENotify.eEvent =IFX_DECT_ULE_DATA_SENT_FAIL_TIMEOUT;
            xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_SDU_STOP_RQ;
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "\nULE Data Send fail for PP - time OUT = ",ucInstanceId);

            if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
            {
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  " ULE Data send failed due to PostToStack failure");
               IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
            }
            pxCallInfo->eDataSendState = IFX_DECT_ULE_CLOSE_INPROGRESS;

         }
         else if(pxCallInfo->eDataSendState == IFX_DECT_ULE_BPAGING_INPROGRESS)
         {
            xULENotify.eEvent =IFX_DECT_ULE_BPAGE_FAIL_TIMEOUT;
            pxCallInfo->eDataSendState = IFX_DECT_ULE_DATA_IDLE;
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                     "\nULE B-Field FAIL for PP- time OUT = ",ucInstanceId);
            if(xULE_Data.xULECallBks.pfnULENotify != NULL)
            {
               xULE_Data.xULECallBks.pfnULENotify(ucInstanceId,&xULENotify);
            }
         }
   }
   return;
}
/************************************************************************
* Function Name  : IFX_DECT_ULE_ValidateBasicService
* Description    : This function validates the BASIC_SERVICE IE in setup msg
* Input Values   : pxIPCMsg IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_ULE_ValidateBasicService(IN x_IFX_DECT_IPC_Msg* pxIPCMsg,
                                  IN x_IFX_DECT_IE_BasicService* pxBSInfo)
{
  uint32 uiIEHdl = 0;
  if(pxIPCMsg == NULL){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
    return IFX_FAILURE;
  }
  uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIPCMsg);
  while(uiIEHdl != 0){
    if(IFX_DECT_IE_TypeGet(uiIEHdl) == IFX_DECT_IE_BASICSERVICE){
      IFX_DECT_IE_BasicServiceGet(uiIEHdl,pxBSInfo);
      return IFX_SUCCESS;
    }else{
      IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl);
    }
  }
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_ULE_ValidateServiceChangeInfo
* Description    : This function validates the BASIC_SERVICE IE in setup msg
* Input Values   : pxIPCMsg IPC message
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/
e_IFX_Return
IFX_DECT_ULE_ValidateBasicServiceChangeInfo(IN x_IFX_DECT_IPC_Msg* pxIPCMsg,
                                  IN x_IFX_DECT_IE_ServiceChange* pxSCIInfo)
{
  uint32 uiIEHdl = 0;
  if(pxIPCMsg == NULL){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
    return IFX_FAILURE;
  }
  uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIPCMsg);
  while(uiIEHdl != 0){
    if(IFX_DECT_IE_TypeGet(uiIEHdl) == IFX_DECT_IE_SERVICECHANGEINFO){
         IFX_DECT_IE_ServiceChangeGet(uiIEHdl,pxSCIInfo);
      return IFX_SUCCESS;
    }else{
      IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl);
    }
  }
  return IFX_SUCCESS;
}
int32 IFX_DECT_ULE_GetLastError(const char8 *pcErrorDescription)
{
   switch (IFX_DECT_ULE_ErrNo)
   {
      case IFX_DECT_ULE_INVALID_INSTANCE : pcErrorDescription = "Invalid ULE Device instance";
      break;
      case IFX_DECT_ULE_PP_NOT_ATTACHED : pcErrorDescription = "ULE Device not attached";
      break;
      case IFX_DECT_ULE_DATASEND_PENDING : pcErrorDescription = "Previous Data send is still pending";
      break;
      case IFX_DECT_ULE_CB_NOT_REGISTERED : pcErrorDescription = "ULE Call Back functions (all or may be some) not registered";
      break;
      case IFX_DECT_ULE_VC_DISCONNECTED : pcErrorDescription = "ULE Virtual connection is disconnected";
      break;
      case IFX_DECT_ULE_SUBSCR_DATA_NOT_PASSED : pcErrorDescription = "ULE subsiscription data is not passed";
      break;
      case IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED : pcErrorDescription = "ULE FIFO write failed while posting message to stack";
      break;
      case IFX_DECT_ULE_SYSTEM_MALLOC_FAILED : pcErrorDescription = "MALLOC system call failed";
      break;
      case IFX_DECT_ULE_PP_NOT_NWK_RESUME : pcErrorDescription = "Device not in IFX_DECT_ULE_NWK_RESUME";
      break;
   }

   return IFX_DECT_ULE_ErrNo;
}

void IFX_DECT_ULE_InitDefaultConfig(void)
{

   /* All are in milli secs */

   // every 64 multiframe; frame - 0
   xULE_Data.xULEConfig.uiSensorPageCycle = 10; // power of 2: 2^10 = 1024 frames = 64 multi-frames
   xULE_Data.xULEConfig.uiStart_MFN_Sensor = 0;
   xULE_Data.xULEConfig.ucStart_FCNT_Sensor = 0;
   xULE_Data.xULEConfig.ucActiveChnlSensor = 0x01;// bit mask value: 0001b

   // every 1 multiframe; frame - 2
   xULE_Data.xULEConfig.uiSlowActuatorPageCycle = 4; // power of 2: 2^4 = 16 frames = 1 multi-frames
   xULE_Data.xULEConfig.uiStart_MFN_SlowAct = 0;
   xULE_Data.xULEConfig.ucStart_FCNT_SlowAct = 2;
   xULE_Data.xULEConfig.ucActiveChnlSlowAct = 0x02; // bit mask value: 0010b

   // every 4 frame; frame - 1, 5, 9, 13, ...
   xULE_Data.xULEConfig.uiFastActuatorPageCycle = 2; // power of 2: 2^2 = 4 frames
   xULE_Data.xULEConfig.uiStart_MFN_FastAct = 0;
   xULE_Data.xULEConfig.ucStart_FCNT_FastAct = 0;
   xULE_Data.xULEConfig.ucActiveChnlFastAct = 0x04; // bit mask value: 0100b

   xULE_Data.xULEConfig.uiStayAliveCycle = 10240;
   xULE_Data.xULEConfig.uiSDUSize = 500;
   xULE_Data.xULEConfig.ucWindowSize = 16;

   return;
}

void IFX_DECT_ULE_HandleInitFailure(void)
{
   int i;
   for(i=0;i<xULE_Data.unMaxULEDevSupported;i++)
   {
      if(xULE_Data.pxULECallInfo[i].pcSendBuf > 0)
      {
         free(xULE_Data.pxULECallInfo[i].pcSendBuf);
      }
      if(xULE_Data.pxULECallInfo[i].pcRecvBuf > 0)
      {
         free(xULE_Data.pxULECallInfo[i].pcRecvBuf);
      }
   }
   return;
}


/*! \brief  This function is used to initialize the ULE Transport Unit of the
               DECT Toolkit.  This function shall be invoked by the FT
               application after it has received the confirmation from the
               Toolkit that the Toolkit and the Stack initialization has been
               successful.
        \param[in] unMaxULEDevSupported Max ULE devices supported
        \param[in] pxULEConfig Pointer to ULE config data structure
        \param[in] pxULESubscData pointer to Subscription Data of registered ULE Devices
        \param[in] pxULECallBks) Pointer to Callback functions structure that are to be registered
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ULE_Init(IN uint16 unMaxULEDevSupported,
                        IN x_IFX_DECT_ULE_Config *pxULEConfig,
                               IN x_IFX_DECT_ULE_SubscData *pxULESubscData,
                        IN x_IFX_DECT_ULE_CallBks *pxULECallBks)
{
   //x_IFX_DECT_IPC_Msg xIpcMsg = {0};
   xULE_Data.unMaxULEDevSupported = unMaxULEDevSupported;

   if(pxULEConfig != NULL)
   {
      memcpy(&xULE_Data.xULEConfig,pxULEConfig,sizeof(x_IFX_DECT_ULE_Config));
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IFX_DECT_ULE_Init: copied ULE Config data");
   }
   else
   {
      IFX_DECT_ULE_InitDefaultConfig();
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IFX_DECT_ULE_Init: IFX_DECT_ULE_InitDefaultConfig");
   }

   if(pxULESubscData != NULL)
   {
      memcpy(&xULE_Data.xULESubscData,pxULESubscData,sizeof(x_IFX_DECT_ULE_SubscData));
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IFX_DECT_ULE_Init: copied Subscription data");
   }
   else
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE_INIT Failed becuase no Subscription Buffer passed!!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_SUBSCR_DATA_NOT_PASSED;
      return IFX_FAILURE;
   }

   if(pxULECallBks != NULL)
   {
      if((pxULECallBks->pfnULENotify == NULL ) || (pxULECallBks->pfnULEDataRecv == NULL )
#ifdef SWAROOP_TEST
      || (pxULECallBks->pfnULEMsgRecv == NULL ) || (pxULECallBks->pfnULEInfoStore == NULL )
#endif
      )
      {
         IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE_INIT Failed becuase some Call Back functions missing!!!!!!");
         IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_CB_NOT_REGISTERED;
         return IFX_FAILURE;

      }
      memcpy(&xULE_Data.xULECallBks,pxULECallBks,sizeof(x_IFX_DECT_ULE_CallBks));
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IFX_DECT_ULE_Init: copied ULE CB functions");
   }
   else
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE_INIT Failed becuase no Call Back fun,ctions for ULE passed!!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_CB_NOT_REGISTERED;
      return IFX_FAILURE;
   }
#if 0
   xIpcMsg.ucMsgId = IFX_DECT_ULE_INIT;
   if (IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg) == IFX_SUCCESS)
   {
      return IFX_SUCCESS;
   }
   else
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Posting to DECT Stack Fifo failed ULE_INIT !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
      return IFX_FAILURE;
   }
#endif
   if((xULE_Data.pxULECallInfo = malloc(sizeof(x_IFX_DECT_ULE_CallInfo) * unMaxULEDevSupported)) == NULL)
   {
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_SYSTEM_MALLOC_FAILED;
      return IFX_FAILURE;
   }
   {
      int i;
      memset(xULE_Data.pxULECallInfo,0,(sizeof(x_IFX_DECT_ULE_CallInfo) * unMaxULEDevSupported));
      for(i=0;i<unMaxULEDevSupported;i++)
      {
         if((xULE_Data.pxULECallInfo[i].pcSendBuf = malloc(IFX_DECT_MAX_ULE_SDUSIZE)) < 0)
         {
            IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_SYSTEM_MALLOC_FAILED;
            IFX_DECT_ULE_HandleInitFailure();
            return IFX_FAILURE;
         }
         if((xULE_Data.pxULECallInfo[i].pcRecvBuf = malloc(IFX_DECT_MAX_ULE_SDUSIZE)) < 0)
         {
            IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_SYSTEM_MALLOC_FAILED;
            IFX_DECT_ULE_HandleInitFailure();
            return IFX_FAILURE;
         }
         if(pxULESubscData->xRegList[i].cstatus)
         {
            xULE_Data.pxULECallInfo[i].eMuState = IFX_DECT_ULE_REGISTERED;
            IFX_DECT_ULE_Free_Init_DeviceNum(xULE_Data.xULESubscData.xRegList[i].ucDeviceNo, \
                     xULE_Data.xULESubscData.xRegList[i].eULEType,1);
            xULE_Data.pxULECallInfo[i].eNWKState = pxULESubscData->xRegList[i].eNWKState;

#ifdef SMART_HOME_DEMO
             xULE_Data.pxULECallInfo[i].eCCMState = IFX_DECT_ULE_CCM_GENERATED;
#endif
         }



      }
   }
#if 0 /*Not needed as every time DCK is generated whenever SRQ is sent out or after Service call*/
   {/*Update DCK status*/
      uchar8  acdck_array[IFX_ULE_CIPHER_KEY_SIZE];
      int32 i;
      memset(acdck_array,0,sizeof(acdck_array));
      for(i=0;i<IFX_DECT_MAX_ULE_DEVICES; i++)
      {
         if(memcmp(acdck_array,&xULE_Data.xULESubscData.xRegList[i].acdck_array,sizeof(acdck_array)))
         {
            xULE_Data.pxULECallInfo[i].eCCMState = IFX_DECT_ULE_CCM_GENERATED;
         }
      }
   }
#endif

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IFX_DECT_ULE_Init: All is well!!!!");
   return IFX_SUCCESS;
}

/*! \brief  This function is used to Configure parameters within the ULE TL or the stack.
                   This function shall be invoked by the FT application as and when
               user configures any ULE related parameters such as paging cycles
               for various ULE devices etc.The configured parameters will be used
               by underlying DECT stack.
        \param[in] pxULEConfig Pointer to the  x_IFX_DECT_ULE_Config structure
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ULE_InfoConfigure(IN x_IFX_DECT_ULE_Config *pxULEConfig)
{
   if(pxULEConfig != NULL)
   {
      memcpy(&xULE_Data.xULEConfig,pxULEConfig,sizeof(x_IFX_DECT_ULE_Config));
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IFX_DECT_ULE_InfoConfigure: Copied ULE Config");
   }
   else
   {
      IFX_DECT_ULE_InitDefaultConfig();
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"IFX_DECT_ULE_InfoConfigure: IFX_DECT_ULE_InitDefaultConfig");
   }

   return IFX_SUCCESS;
}


/*! \brief  This function is used by the application to release the expediated ULE connection
            which is setup by ULE PP to send ULE application data. The application after decoding/analyzing
            the data can decide to close if does not have to send any response back to PP. Or even application
            can request PP to set-up connection after certain timeout if required by setting up a valid reason
            in the eReason parameter.
        \param[in] ucInstanceId ULE Instance Identifier
        \param[in] eReason Reason to release the expediated connection
        \param[in] ucInfofield Info related to Reason
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ULE_ReleaseExpConnection(IN uchar8 ucInstanceId,
               IN   e_IFX_DECT_ULE_Release_Reason eReason, IN uchar8 ucInfofield)
{
   x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;

   if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Invalid ULE instance number !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
      return IFX_FAILURE;
   }

   if(xULE_Data.pxULECallInfo == NULL)
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE NOT INITED !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
      return IFX_FAILURE;
   }
   pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];
   pxCallInfo->eExpConState = IFX_DECT_ULE_EXP_IDLE;

   if(eReason == IFX_DECT_ULE_SETUP_AGAIN)
   {
      pxCallInfo->eDataRecvState = IFX_DECT_ULE_SETUP_AFTER_N_FRAMES;
   }
   else
   {
      pxCallInfo->eDataRecvState = IFX_DECT_ULE_DATA_IDLE;
   }
   xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_SDU_RCV_RESPONSE_RQ;
   xUPlaneIpcMsg.ucPara1 = 0;
   xUPlaneIpcMsg.ucPara2 = eReason;
   xUPlaneIpcMsg.ucPara3 = ucInfofield;/*it covers bits a16 to a21 and stack has to take care this*/
   //xUPlaneIpcMsg.ucPara4 = ucInstanceId-IFX_DECT_ULE_OFFSET;
   xUPlaneIpcMsg.ucPara4 = ucInstanceId;
   if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
   {
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " ULE IFX_DECT_ULE_ReleaseExpConnection failed due to PostToStack failure");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
       return IFX_FAILURE;
   }
   return IFX_SUCCESS;
}


/*! \brief  This function is used to send the application data to the ULE device.  pxULENotify
                   This function shall be invoked by the FT application as it prepares
                   to pass the data received from the HAN application to the ULE device.
                   The data is handled in a transparent manner within this function.
               The data is sent to the ULE device over the bearer channel (B-Channel).
               This API has to be used only for those ULE devices which are in attached
               state and this is informed to application using registered call back function
               pfn_IFX_DECT_ULE_Notify and event IFX_DECT_ULE_DEVICE_ATTACHED.
        \param[in] ucInstanceId ULE Instance Identifier
        \param[in] ucSize Size of the data
        \param[in] pData Pointer to the data buffer
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ULE_DataSend(IN uchar8 ucInstanceId,
                                   IN uint16 unSize,
                           IN void* pData)
{
   x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;

   if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Invalid ULE instance number !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
      return IFX_FAILURE;
   }

   if(unSize > IFX_DECT_MAX_ULE_SDUSIZE)
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Currently Data send more than 500 bytes not supported !!!!!!");
      return IFX_FAILURE;
   }
   if(xULE_Data.pxULECallInfo == NULL)
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE NOT INITED !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
      return IFX_FAILURE;
   }
   pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];

      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT ,
                     " IFX_DECT_ULE_DataSend for PP !!!!!!",ucInstanceId);

      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT ,
                     " IFX_DECT_ULE_DataSend SendState =",pxCallInfo->eDataSendState);


      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT ,
                     " IFX_DECT_ULE_DataSend Size =",unSize);
   if( pxCallInfo-> eNWKState != IFX_DECT_ULE_NWK_RESUME )
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Device not in IFX_DECT_ULE_NWK_RESUME !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_PP_NOT_NWK_RESUME;
      return IFX_FAILURE;
   }

   if( pxCallInfo->eDataSendState > IFX_DECT_ULE_DATA_IDLE )
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT ,
                     " Previous data send not yet completed. Currently buffering not implemented !!!!!!",ucInstanceId);
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_DATASEND_PENDING;
      return IFX_FAILURE;
   }
   pxCallInfo->eDataSendState = IFX_DECT_ULE_DATA_INPROGRESS;
   xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_SDU_SND_RQ;
   xUPlaneIpcMsg.ucPara1 = unSize >> 8;
   xUPlaneIpcMsg.ucPara2 = unSize & 0xFF;
   xUPlaneIpcMsg.ucPara3 = IFX_DECT_ULE_LU14;

#if 0
   if((pxCallInfo->eDataRecvState == IFX_DECT_ULE_DATA_INPROGRESS) || (pxCallInfo->eDataRecvState == IFX_DECT_ULE_SETUP_AFTER_N_FRAMES))
   {
      /*Paging Not Required*/
      xUPlaneIpcMsg.ucPara3 = IFX_DECT_ULE_LU14;
   }
   else
   {
      /*Paging  Required*/
      xUPlaneIpcMsg.ucPara3 = ((0x01 << 7) | IFX_DECT_ULE_LU14);
   }
#endif
   //xUPlaneIpcMsg.ucPara4 = ucInstanceId-IFX_DECT_ULE_OFFSET;
   xUPlaneIpcMsg.ucPara4 = ucInstanceId;
   memcpy(xUPlaneIpcMsg.acData,(uchar8*)pData,unSize);

   if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
   {
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " ULE Data send failed due to PostToStack failure");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
       return IFX_FAILURE;
   }

   //if(pxCallInfo->eExpConState == IFX_DECT_ULE_EXP_IDLE)
   if((pxCallInfo->eDataRecvState != IFX_DECT_ULE_DATA_INPROGRESS) && (pxCallInfo->eDataRecvState != IFX_DECT_ULE_SETUP_AFTER_N_FRAMES)
      && (xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].ucDeviceNo))
   {
      xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_PAGE_RQ;
      xUPlaneIpcMsg.ucPara1 = 0;
      xUPlaneIpcMsg.ucPara2 = 0;
      xUPlaneIpcMsg.ucPara3 = 0;
      xUPlaneIpcMsg.ucPara4 = ucInstanceId;

      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " ULE Paging Required to send data out");

      if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
      {
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " ULE Data send failed due to PostToStack failure");
         IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
         return IFX_FAILURE;
      }
      IFX_DECT_StartTimer(IFX_DECT_ULE_DATASEND_TIMEOUT,&ucInstanceId,sizeof(uchar8),
                             IFX_DECT_ULE_DataSendTimerExpFunc, &pxCallInfo->uiDataSendTimerId);
   }

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " ULE Data send Initiated");
   return IFX_SUCCESS;

}

e_IFX_Return IFX_DECT_ULE_ProcessUPlaneMsg(IN x_IFX_DECT_IPC_Msg_u *pxUPlaneIpcMsg)
{
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
   uchar8 ucInstanceId = pxUPlaneIpcMsg->ucPara4;

   if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Invalid ULE instance number !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
      return IFX_FAILURE;
   }
    pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n  IFX_DECT_ULE_ProcessUPlaneMsg Msg = ",pxUPlaneIpcMsg->ucMsgId);
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n  IFX_DECT_ULE_ProcessUPlaneMsg P1 = ",pxUPlaneIpcMsg->ucPara1);
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n  IFX_DECT_ULE_ProcessUPlaneMsg P2 = ",pxUPlaneIpcMsg->ucPara2);
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n  IFX_DECT_ULE_ProcessUPlaneMsg P3 = ",pxUPlaneIpcMsg->ucPara3);
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n  IFX_DECT_ULE_ProcessUPlaneMsg P4 = ",pxUPlaneIpcMsg->ucPara4);
#if 0
/*Not sure whether during ULE SUOTA the ULE device still send ULE messages? 
  So better to differentiate using Message type!!!? in Switch case below*/
  
	if(pxCallInfo->ucCallType == IFX_DECT_ULE_DPSU_CALL)
	{
		return IFX_DECT_DPSU_ProcessUPlaneMsg(pxUPlaneIpcMsg);
	}
#endif

   switch(pxUPlaneIpcMsg->ucMsgId){
      case FP_MEDIA_SDU_RCV_IN:
      case FP_MEDIA_SDU_FLOW_IN:
         return IFX_DECT_DPSU_ProcessUPlaneMsg(pxUPlaneIpcMsg);
         //break;
			
      case FP_ULE_MEDIA_SDU_RCV_IN:
      {
            uint16 unSize =((pxUPlaneIpcMsg->ucPara1 << 8) | pxUPlaneIpcMsg->ucPara2);
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n Received ULE Data Length = ",unSize);
            pxCallInfo->eDataRecvState = IFX_DECT_ULE_DATA_INPROGRESS;
            pxCallInfo->eExpConState = IFX_DECT_ULE_EXP_CONNECTED;

            if(pxCallInfo->uiDataSendTimerId)
            {
               x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};

               IFX_DECT_StopTimer(pxCallInfo->uiDataSendTimerId);
               pxCallInfo->uiDataSendTimerId = 0;

               xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_PAGE_STOP_RQ;
               xUPlaneIpcMsg.ucPara1 = 0;
               xUPlaneIpcMsg.ucPara2 = 0;
               xUPlaneIpcMsg.ucPara3 = 0;
               xUPlaneIpcMsg.ucPara4 = ucInstanceId;
               if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
               {
                     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                           "  case FP_ULE_MEDIA_SDU_RCV_IN: PostToStack failure");
                     IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
                     return IFX_FAILURE;
               }

            }
            if(pxCallInfo->eDataSendState == IFX_DECT_ULE_BPAGING_INPROGRESS)
            {
               x_IFX_DECT_ULE_NotifyEvent xULENotify;
               //x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};


               xULENotify.eEvent =IFX_DECT_ULE_BPAGE_SUCCESS;
               pxCallInfo->eDataSendState = IFX_DECT_ULE_DATA_IDLE;
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                        "\nULE B-Field Success for PP = ",ucInstanceId);
               if(xULE_Data.xULECallBks.pfnULENotify != NULL)
               {
                  xULE_Data.xULECallBks.pfnULENotify(pxUPlaneIpcMsg->ucPara4,&xULENotify);
               }
            }


#ifdef SMART_HOME_DEMO
         { /*Begining of SMART HOME*/
            uchar8 aucGigaSnsrMotion[]={0x65,0x76,0x3D,0x6D,0x6F,0x76,0x65,0x6D,0x65,0x6E,0x74};
            static int flg1=0;
            if(flg1==0)
            {
               uchar8 aucGigaSnsr[]={0x64,0x65,0x76,0x3D,0x70,0x73,0x30,0x31};
               if(!(memcmp(aucGigaSnsr,pxUPlaneIpcMsg->acData,sizeof(aucGigaSnsr))))
               {
                  flg1=1;
                  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                   "Gigaset Sensor sent device type as Motion detector !!!!!!");
                  IFX_DECT_ULE_SetDeviceType(ucInstanceId,IFX_DECT_ULE_SENSOR);
               }
            }

            if((xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].ucDeviceNo == 50) && (unSize == 21))
            {
               if((pxUPlaneIpcMsg->acData[12] == 0x01) && (pxUPlaneIpcMsg->acData[15] == 0x02)  &&
                  ( pxUPlaneIpcMsg->acData[16] == 0x04) &&(pxUPlaneIpcMsg->acData[20] == 0x01))
               {
                     IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "DSPG SMOKE Detector ALERT!!!!!!!!");
                     {
                        uchar8 DspgON[]= {0x00, 0x00, 0x02, 0x00, 0x34, 0x01, 0x00, 0x00, 0x00, 0x01, 0x82, 0x00, 0x01, 0x00, 0x00 };
                        uchar8 DspgOFF[]={0x00, 0x00, 0x02, 0x00, 0x34, 0x01, 0x00, 0x00, 0x00, 0x01, 0x82, 0x00, 0x02, 0x00, 0x00 };
                        uchar8 *Pbuf=NULL;
                        static uchar8 flg=0;
                        static uchar8 config=0;
                        int i;
                        x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;

                        for(i=0;i<IFX_DECT_MAX_ULE_DEVICES;i++)
                        {
                           if(xULE_Data.xULESubscData.xRegList[i].ucDeviceNo == 52)
                           {
                              pxCallInfo=&xULE_Data.pxULECallInfo[i];
                              if( pxCallInfo-> eNWKState == IFX_DECT_ULE_NWK_RESUME )
                              {
                                if(config==0)
                                 {
                                    uchar8 Configure[]= {0x00,0x00,0x02,0x00,0x34,0x01,0x00,0x00,0x00,0x06,0x8F,0x00,0x01,0x00,0x04,0x00,0x00,0x0B,0xB8};
                                    IFX_DECT_ULE_DataSend(i+IFX_DECT_ULE_OFFSET,((uint16)sizeof(Configure)),(void *)Configure);
                                    config=1;
                                 }
                                 else
                                 {
                                    if(flg==0)
                                    {
                                       flg=1;
                                       Pbuf=DspgON;
                                       IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                                                         "Sending ON to DSPG Smart Plug!!!!!!!!");
                                    }
                                    else
                                    {
                                       flg=0;
                                       Pbuf=DspgOFF;
                                       IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                                                         "Sending OFF to DSPG Smart Plug!!!!!!!!");
                                    }
                                    IFX_DECT_ULE_DataSend(i+IFX_DECT_ULE_OFFSET,((uint16)sizeof(DspgON)),(void *)Pbuf);
                                 }
                              }
                              break;
                           }
                        }
                     }
#if 0
                  if(pxUPlaneIpcMsg->acData[11])
                  {
                     IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "DSPG SMOKE TAPMER!!!!!!!!");
                  }
                  else
                  {
                     IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "DSPG SMOKE Detector ALERT!!!!!!!!");


                  // IFX_DECT_ULE_Handle_HANFUN_Alert();
                  }
#endif
               }
            }
            else if((xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].ucDeviceNo == 51) && (unSize == 21))
            {
               if((pxUPlaneIpcMsg->acData[12] == 0x01) && (pxUPlaneIpcMsg->acData[15] == 0x02)  &&
                  ( pxUPlaneIpcMsg->acData[16] == 0x03) &&(pxUPlaneIpcMsg->acData[20] == 0x01))
               {
                     IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "DSPG Motion Detector ALERT!!!!!!!!");
#if 0
                  if(pxUPlaneIpcMsg->acData[11])
                  {
                     IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "DSPG Motion TAPMER!!!!!!!!");
                  }
                  else
                  {
                     IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "DSPG Motion Detector ALERT!!!!!!!!");
                  // IFX_DECT_ULE_Handle_HANFUN_Alert();
                  }
#endif
               }
            }
            else if((xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].ucDeviceNo == 52) && (unSize == 21))
            {
                     IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "DSPG Smart Plug Metering Info??? !!!!!!!!");
            }
            else if(xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].eULEType == IFX_DECT_ULE_FASTACTUATOR)
            {
               if((pxUPlaneIpcMsg->acData[0] == 0x31) && (pxUPlaneIpcMsg->acData[1] == 0x45))
               {
                     if(pxUPlaneIpcMsg->acData[3])
                     {
                        vuiDeviceState=1;
                        IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                   "SMART Plug device state ON !!!!!!");
                     }
                     else
                     {
                        IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                   "SMART Plug device state OFF !!!!!!");
#if 0
                        if((vuiLightON) && (vuiDeviceState))
                        {
                           IFX_DECT_StopTimer(vuiLightON);
                           vuiLightON=0;
                        }
#endif
                        vuiDeviceState=0;
                     }
               }
            }
            else if(!(memcmp(aucGigaSnsrMotion,pxUPlaneIpcMsg->acData,sizeof(aucGigaSnsrMotion))))
            {
                  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                   "Gigaset Sensor  Motion detected !!!!!!");

                  //IFX_DECT_ULE_Handle_HANFUN_Alert();
            }/*end of GigasetMotion if*/
         }/*End of SMART Home */
#endif
         if(pxCallInfo->ucNeedPVCResync)
         {
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n  PVC Resync is set So TK is releasing this with switch to ckt mode = ",pxCallInfo->ucNeedPVCResync);
               IFX_DECT_ULE_ReleaseExpConnection(ucInstanceId,IFX_DECT_ULE_SWITCH_TO_CIRCUIT_MODE,01);
               pxCallInfo->ucServiceCallOwner =1;
               break;
         }
         else
         {
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n  PVC Resync is not set app will Rels connection = ",pxCallInfo->ucNeedPVCResync);
         }
#if 0
         if(unSize == 0)
         {
            x_IFX_DECT_ULE_NotifyEvent xULENotify;
            xULENotify.eEvent = IFX_DECT_ULE_EXP_DATACON_CONNECTED;

            if(xULE_Data.xULECallBks.pfnULENotify != NULL)
            {
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "\nULE Notify DATA CON Connected for PP = ",ucInstanceId);
               xULE_Data.xULECallBks.pfnULENotify(ucInstanceId,&xULENotify);
            }
         }
         else
#endif
         if(xULE_Data.xULECallBks.pfnULEDataRecv != NULL)
         {
#if 0
            if(unSize == 0)
            {
               IFX_DECT_ULE_ReleaseExpConnection(ucInstanceId,IFX_DECT_ULE_NORMAL,0);
            }
            else
#endif
            {
               xULE_Data.xULECallBks.pfnULEDataRecv( ucInstanceId,unSize,((void *)pxUPlaneIpcMsg->acData));
            }
         }
         break;
      }
      case FP_ULE_MEDIA_DLC_ERROR_IN:
      {
         if((pxCallInfo->eDataSendState == IFX_DECT_ULE_BPAGING_INPROGRESS) || (pxCallInfo->eDataSendState == IFX_DECT_ULE_DATA_INPROGRESS))
         {
            x_IFX_DECT_ULE_NotifyEvent xULENotify;
            x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};

            if(pxCallInfo->uiDataSendTimerId)
            {
               IFX_DECT_StopTimer(pxCallInfo->uiDataSendTimerId);
               pxCallInfo->uiDataSendTimerId = 0;
               xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_PAGE_STOP_RQ;
               xUPlaneIpcMsg.ucPara3 = 0;
               xUPlaneIpcMsg.ucPara4 = ucInstanceId;
               if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
               {
                  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                        " ULE Page Stop request failed due to PostToStack failure");
                  IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
               }

            }

            if(pxCallInfo->eDataSendState == IFX_DECT_ULE_BPAGING_INPROGRESS)
               xULENotify.eEvent =IFX_DECT_ULE_BPAGE_FAIL;
            else
               xULENotify.eEvent =IFX_DECT_ULE_DATA_SENT_FAIL;

            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                     "\nULE B-Field FAIL for PP = ",ucInstanceId);

            pxCallInfo->eDataSendState = IFX_DECT_ULE_DATA_IDLE;

            if(xULE_Data.xULECallBks.pfnULENotify != NULL)
            {
               xULE_Data.xULECallBks.pfnULENotify(pxUPlaneIpcMsg->ucPara4,&xULENotify);
            }
         }
         if(pxUPlaneIpcMsg->ucPara1 == IFX_DECT_ULE_SWITCH_TO_CIRCUIT_MODE)
         {
            /* means Needs a PVC RESET*/
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n  Stack is asking for PVC Reset bcoz of DLC error P1 = ",pxUPlaneIpcMsg->ucPara1);
            pxCallInfo->ucNeedPVCResync =1;/*PVC Resync needed*/
            pxCallInfo->ucServiceCallOwner =1; /*Owner will be FP for next Service call and FP has to release after RESUME*/
         }
         else
         {
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n  Stack is asking for PVC Reset bcoz of DLC error but P1 not set for that? = ",pxUPlaneIpcMsg->ucPara1);
         }
         break;
      }
#if 0 //it is handled in timer exp function directly
      case FP_ULE_MEDIA_SDU_SEND_TIMEOUT:
      {
         x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};
         if(pxCallInfo->eDataSendState == IFX_DECT_ULE_DATA_INPROGRESS)
         {
            xULENotify.eEvent =IFX_DECT_ULE_DATA_SENT_FAIL_TIMEOUT;
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "\nULE Data Send fail for PP - time OUT = ",ucInstanceId);
            pxCallInfo->ucNeedPVCResync=1;
         }
         else if(pxCallInfo->eDataSendState == IFX_DECT_ULE_BPAGING_INPROGRESS)
         {
            xULENotify.eEvent =IFX_DECT_ULE_BPAGE_FAIL_TIMEOUT;
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                     "\nULE B-Field FAIL for PP- time OUT = ",ucInstanceId);
         }

         //pxCallInfo->eDataSendState = IFX_DECT_ULE_CLOSE_INPROGRESS;
         pxCallInfo->eDataSendState = IFX_DECT_ULE_DATA_IDLE;

         xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_SDU_STOP_RQ;
         xUPlaneIpcMsg.ucPara4 = ucInstanceId;
         if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
         {
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  " ULE Data send failed due to PostToStack failure");
            IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
         }
         if(xULE_Data.xULECallBks.pfnULENotify != NULL)
         {
            xULE_Data.xULECallBks.pfnULENotify(pxUPlaneIpcMsg->ucPara4,&xULENotify);
         }
         break;
      }
#endif

      case FP_ULE_MEDIA_SDU_STOP_CFM:
      {
         x_IFX_DECT_ULE_NotifyEvent xULENotify;
         pxCallInfo->eDataSendState = IFX_DECT_ULE_DATA_IDLE;
         xULENotify.eEvent =IFX_DECT_ULE_DATA_SENT_FAIL;
         if(xULE_Data.xULECallBks.pfnULENotify != NULL)
         {
            xULE_Data.xULECallBks.pfnULENotify(pxUPlaneIpcMsg->ucPara4,&xULENotify);
         }

         break;
      }
      case FP_ULE_MEDIA_SDU_FLOW_IN:
      {
         x_IFX_DECT_ULE_NotifyEvent xULENotify;
         //x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};
         if(pxCallInfo->uiDataSendTimerId)
         {
            x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};
            IFX_DECT_StopTimer(pxCallInfo->uiDataSendTimerId);
            pxCallInfo->uiDataSendTimerId = 0;
            xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_PAGE_STOP_RQ;
            xUPlaneIpcMsg.ucPara3 = 0;
            xUPlaneIpcMsg.ucPara4 = ucInstanceId;
            if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
            {
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                        " ULE Page Stop request failed due to PostToStack failure");
               IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
            }
         }

         if(pxUPlaneIpcMsg->ucPara1)
         {
            if(pxCallInfo->eDataSendState == IFX_DECT_ULE_DATA_INPROGRESS)
            {
               xULENotify.eEvent =IFX_DECT_ULE_DATA_SENT_SUCCESS;
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                        "\nULE Data Send Success for PP = ",ucInstanceId);
            }
#if 0
            else if(pxCallInfo->eDataSendState == IFX_DECT_ULE_BPAGING_INPROGRESS)
            {
               xULENotify.eEvent =IFX_DECT_ULE_BPAGE_SUCCESS;
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                        "\nULE B-Field Success for PP = ",ucInstanceId);
            }
#endif
            else
            {
               break;
            }


         }
         else
         {
            if(pxCallInfo->eDataSendState == IFX_DECT_ULE_DATA_INPROGRESS)
            {
               xULENotify.eEvent =IFX_DECT_ULE_DATA_SENT_FAIL;
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                     "\nULE Data Send fail for PP = ",ucInstanceId);
            }
#if 0
            else if(pxCallInfo->eDataSendState == IFX_DECT_ULE_BPAGING_INPROGRESS)
            {
               xULENotify.eEvent =IFX_DECT_ULE_BPAGE_FAIL;
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                        "\nULE B-Field FAIL for PP = ",ucInstanceId);
            }
#endif
            else
            {
               break;
            }

         }
         pxCallInfo->eDataSendState = IFX_DECT_ULE_DATA_IDLE;
#if 0
         {
            x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};
            /*Not needed since TK decided to close and also this state will not be chkd by TK when CLOSE_CFM msg rcvd from stack*/
            //pxCallInfo->eDataSendState = IFX_DECT_ULE_CLOSE_INPROGRESS;

            xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_SDU_STOP_RQ;
            xUPlaneIpcMsg.ucPara4 = ucInstanceId;
            if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
            {
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                     " ULE Data send failed due to PostToStack failure");
               IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
            }
         }
#endif
         if(xULE_Data.xULECallBks.pfnULENotify != NULL)
         {
            xULE_Data.xULECallBks.pfnULENotify(pxUPlaneIpcMsg->ucPara4,&xULENotify);
         }

         break;
      } /*FP_MEDIA_SDU_FLOW_IN*/

   }
      return IFX_SUCCESS;
}
e_IFX_Return IFX_DECT_ULE_MU_ProcessStackMsg(IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
   switch (pxIpcMsg->ucMsgId)
   {
      case FP_PORTABLE_REGISTERED_IN_MM:
      {
         //IFX_DECT_STOP_REGISTRATION();
         if(vxGlobalInfo.xMU.vuiRegistrationTimerId)
         {
            IFX_DECT_StopTimer(vxGlobalInfo.xMU.vuiRegistrationTimerId);
         }
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eMuState = IFX_DECT_ULE_IDLE;
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eCallState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eDataSendState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eDataRecvState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eCCMState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eNWKState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eExpConState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].uiDataSendTimerId =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].ucServiceCallOwner =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].ucNeedPVCResync = 0;
#ifdef SMART_HOME_DEMO
         vauiEMC[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET] = (pxIpcMsg->ucPara3 << 8);
         vauiEMC[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET] |= (pxIpcMsg->ucPara4 );
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                           " EMC of ULE device",vauiEMC[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET] );
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                           " ModelID  ULE device",pxIpcMsg->ucPara2 );
#endif
         break;
      }
      case FP_PORTABLE_ATTACHED_IN_MM:
      {
         if(   xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eMuState == IFX_DECT_ULE_IDLE)
         {
            x_IFX_DECT_ULE_SubscInfo *pxDectSubsInfo;
#ifdef SMART_HOME_DEMO
            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                           " Handset not yet registered before and this is the first time",
            vauiEMC[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET]);
#endif
            xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eMuState = IFX_DECT_ULE_ATTACHED;
            IFX_DECT_MU_DenyRegistration();
            if(vxGlobalInfo.xMU.vuiRegistrationTimerId)
            {
               IFX_DECT_StopTimer(vxGlobalInfo.xMU.vuiRegistrationTimerId);
            }

            pxDectSubsInfo = (x_IFX_DECT_ULE_SubscInfo*)(pxIpcMsg->acData + sizeof(struct HLI_Header));
            memcpy(&xULE_Data.xULESubscData.xRegList[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET],
                  pxDectSubsInfo,sizeof(x_IFX_DECT_ULE_SubscInfo));
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "Calling Callback to store data in to flash if not null");
#ifdef SMART_HOME_DEMO
            //if(pxDectSubsInfo->eULEType == IFX_DECT_ULE_NONE)
            if((vauiEMC[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET] != 0x0FEB) &&
            (vauiEMC[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET] != 0x00))
            /*Dialog Device- 0x213E
              DSPG- 0x0FEB*/
            {
                  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                           "NON DSPG Device attached first time so set to RESUME" );
               xULE_Data.xULESubscData.xRegList[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eNWKState = IFX_DECT_ULE_NWK_RESUME;
               pxDectSubsInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
               xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eNWKState = IFX_DECT_ULE_NWK_RESUME;
               xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eCCMState = IFX_DECT_ULE_CCM_GENERATED;
               if(vauiEMC[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET] == 0xCD00)
               {
                  int iDeviceNum=0;
                  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                           "Gigaset  Device attached first time so set device type to Sensors" );
               IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                   "Gigaset Sensor sent device type as Motion detector !!!!!!");
                  xULE_Data.xULESubscData.xRegList[pxIpcMsg->ucPara1-IFX_DECT_ULE_OFFSET].eULEType = IFX_DECT_ULE_SENSOR;
                  pxDectSubsInfo->eULEType =IFX_DECT_ULE_SENSOR;

               if((iDeviceNum = IFX_DECT_ULE_AllocDeviceNum(IFX_DECT_ULE_SENSOR)) < 0 )
               {
                     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "ULE device number allocation failed.... Chk did it exceed the limit (88) of particular type??" );
                     return IFX_FAILURE;
               }
               else
               {
                  xULE_Data.xULESubscData.xRegList[pxIpcMsg->ucPara1-IFX_DECT_ULE_OFFSET].ucDeviceNo = ((uchar8)iDeviceNum);
                     pxDectSubsInfo->ucDeviceNo = ((uchar8)iDeviceNum);
                     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "\nAllocated ULE device Number= ",iDeviceNum);

               }

            //IFX_DECT_ULE_SetDeviceType(pxIpcMsg->ucPara1,IFX_DECT_ULE_SENSOR);

               }
               else
               {
                  int iDeviceNum=0;
                  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                           "Dialog  Device attached first time so set device type to FastActuators" );
                  xULE_Data.xULESubscData.xRegList[pxIpcMsg->ucPara1-IFX_DECT_ULE_OFFSET].eULEType = IFX_DECT_ULE_FASTACTUATOR;
                  pxDectSubsInfo->eULEType =IFX_DECT_ULE_FASTACTUATOR;

               if((iDeviceNum = IFX_DECT_ULE_AllocDeviceNum(IFX_DECT_ULE_FASTACTUATOR)) < 0 )
               {
                     IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "ULE device number allocation failed.... Chk did it exceed the limit (88) of particular type??" );
                     return IFX_FAILURE;
               }
               else
               {
                  xULE_Data.xULESubscData.xRegList[pxIpcMsg->ucPara1-IFX_DECT_ULE_OFFSET].ucDeviceNo = ((uchar8)iDeviceNum);
                     pxDectSubsInfo->ucDeviceNo = ((uchar8)iDeviceNum);
                     IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "\nAllocated ULE device Number= ",iDeviceNum);

               }
            //IFX_DECT_ULE_SetDeviceType(pxIpcMsg->ucPara1,IFX_DECT_ULE_FASTACTUATOR);

               }
            }
#endif


#if 0
            if(xULE_Data.xULECallBks.pfnULEInfoStore != NULL)
            {
               xULE_Data.xULECallBks.pfnULEInfoStore(&xULE_Data.xULESubscData);
            }
#endif
            if(xULE_Data.xULECallBks.pfnULENotify != NULL)
            {
               x_IFX_DECT_ULE_NotifyEvent xNotifyEvent;
               xNotifyEvent.eEvent=IFX_DECT_ULE_UPDATE_SUBS_INFO;
               memcpy(&xNotifyEvent.uxNotify.xSubscInfo, pxDectSubsInfo,
                                 sizeof(x_IFX_DECT_ULE_SubscInfo));
               xULE_Data.xULECallBks.pfnULENotify(pxIpcMsg->ucPara1,&xNotifyEvent);
            }
            return IFX_SUCCESS;
         }
         else
         {
            xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eMuState = IFX_DECT_ULE_ATTACHED;
            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                           " PP is Re-Attached!!!!!!!!!",pxIpcMsg->ucPara1);

         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eCCMState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eNWKState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eCallState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eDataSendState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eDataRecvState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eExpConState =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].uiDataSendTimerId =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].ucServiceCallOwner =
         xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].ucNeedPVCResync = 0;

#ifdef SMART_HOME_DEMO
            //if(vauiEMC[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET] != 0x0FEB)
            if(xULE_Data.xULESubscData.xRegList[pxIpcMsg->ucPara1-IFX_DECT_ULE_OFFSET].ucDeviceNo < 50)
            {
                  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
                           "Resetting SSN & RSN for Non DSPG devices;Better reboot PP also!!!!!!!!!",pxIpcMsg->ucPara1);
               memset(xULE_Data.xULESubscData.xRegList[pxIpcMsg->ucPara1-IFX_DECT_ULE_OFFSET].Last_SSN,0,6);
               memset(xULE_Data.xULESubscData.xRegList[pxIpcMsg->ucPara1-IFX_DECT_ULE_OFFSET].Last_RSN,0,6);
            }
#endif
         }
         break;
      }
      case FP_ACCESS_RIGHTS_TERMINATE_CFM_MM:
      {
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "IFX_DECT_ULE_MU_ProcessStackMsg() :FP_ACCESS_RIGHTS_TERMINATE_CFM_MM-> Nothing To Do");
         break;
      }
      case  FP_PROP_INFO_IN_MM:
      {
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "IFX_DECT_ULE_MU_ProcessStackMsg() :FP_PROP_INFO_IN_MM -> Chk what To Do?");
         break;
      }
      case  FP_MODEM_BOOT_IND:
      {
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "IFX_DECT_ULE_MU_ProcessStackMsg() :FP_MODEM_BOOT_IND-> Chk What To Do?");
         break;
      }
      case FP_MAC_NOEMO_IN_ME:
      {
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "IFX_DECT_ULE_MU_ProcessStackMsg() :FP_MAC_NOEMO_IN_ME-> Chk What To Do?");
         break;
      }
   }
   return IFX_SUCCESS;
}

e_IFX_Return IFX_DECT_ULE_GenerateCCM(uchar8 ucInstanceId)
{
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
   x_IFX_DECT_IPC_Msg xIpcMsg={0};

   if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Invalid ULE instance number !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
      return IFX_FAILURE;
   }
   if(xULE_Data.pxULECallInfo == NULL)
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE NOT INITED !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
      return IFX_FAILURE;
   }

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                 "\nULE CCM In Progress PPNo = ", ucInstanceId);

   pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];

   pxCallInfo->eCCMState= IFX_DECT_ULE_CCM_INPROGRESS;
   IFX_DECT_EncodeAuthPTReq(ucInstanceId,0,&xIpcMsg);
   xIpcMsg.ucPara4 =1; //Generate CCM Key indication

      return IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
}


e_IFX_Return IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(uchar8 ucInstanceId, uchar8 ucMsgId, uchar8 ucChangeMode)
{
   uint32 uiIEHdl = 0;
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
   x_IFX_DECT_ULE_SubscInfo *pxSubInfo=NULL;
   x_IFX_DECT_IE_ServiceChange xSCIInfo={0};
   x_IFX_DECT_IE_ConnectionIdentity xCIDInfo={0};
   x_IFX_DECT_IPC_Msg xIpcMsg={0};
   pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];
   pxSubInfo=&xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET];

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send: ucInstanceId= ",ucInstanceId);
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send: ucMsgId= ",ucMsgId);
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\n IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send: ucChangeMode= ",ucChangeMode);
   uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData);

   if(ucMsgId == FP_CC_SERVICE_REJECT_RQ)
   {
      uchar8 ucRejReason = ucChangeMode;
      IFX_DECT_EncodeServiceChangeReject(ucInstanceId,0, &xIpcMsg);
      if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_RELEASE_REASON,
               (void *)&ucRejReason) == IFX_FAILURE){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE IFX_DECT_IE_REJECTREASON Failed.");
         return IFX_FAILURE;
      }
      /* Post to the Stack */
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      //pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
      //pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
      return IFX_SUCCESS;
   }

   xSCIInfo.ucExtn3 = 1;
   xSCIInfo.ucCS = 0;
   xSCIInfo.ucM = 0;
   xSCIInfo.ucChangeMode = ucChangeMode;
   xSCIInfo.ucDefault1 = 1;
   xSCIInfo.ucAA = 0;
   xSCIInfo.ucR = 0;
   xSCIInfo.ucBA = 0;

   xCIDInfo.ucUPLID = 0;
   xCIDInfo.ucCID = 7;

   if( /*FP_SERVICE_CHANGE_IN_CC*/FP_CC_SERVICE_CHANGE_RQ == ucMsgId)
   {
      IFX_DECT_EncodeServiceChangeRq(0,ucInstanceId,0,&xIpcMsg);

   if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_SERVICECHANGEINFO,
         (void *)&xSCIInfo) == IFX_FAILURE){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE IFX_DECT_IE_SERVICECHANGEINFO Failed.");
         return IFX_FAILURE;
   }

   if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_CONNECTIONIDENTITY,
         (void *)&xCIDInfo) == IFX_FAILURE){
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE IFX_DECT_IE_CONNECTIONIDENTITY Failed.");
      return IFX_FAILURE;
   }


   }
   else if(/*FP_SERVICE_ACCEPT_IN_CC*/ FP_CC_SERVICE_ACCEPT_RQ == ucMsgId )
   {
      IFX_DECT_EncodeServiceChangeAccept(ucInstanceId,
                   0 /*stack instance needed?*/,&xIpcMsg);

      if(ucChangeMode == IFX_DECT_ULE_OTHER)
      {
         uchar8 *pucTemp=(uchar8 *)(uiIEHdl);//char pointer to traverse IE octets
#if 0
         x_IFX_DECT_IE_IWUAttributes xIWUAtr = {0};

         if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUATTRIBUTES,
            (void *)&xIWUAtr) == IFX_FAILURE){
            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE IFX_DECT_IE_IWUATTRIBUTES Failed.");
         return IFX_FAILURE;
         }
#endif
         while(*pucTemp != 0)
         {
            if( ((*pucTemp) & 0X80) == 0X80)
               { //fixed IE
                     if( ((*pucTemp) & 0XE0 )== 0XE0)
                     { //double octet
                        pucTemp+=2;
                     }
                     else
                     { // single octet
                        pucTemp++;
                     }
               }
               else
               {//variable IE
                  pucTemp++;
                  pucTemp+= (uchar8)(*pucTemp) + 1;
               }
         }

         *pucTemp++ = IFX_DECT_IE_IWUATTRIBUTES;
         *pucTemp++ = 0x9;
         *pucTemp++ = 0xB0;
         *pucTemp++ = 0x80;
         *pucTemp++ = 0x81;
         *pucTemp++ = 0x00;
         *pucTemp++ = 0x88;
         *pucTemp++ = 0x00;
         *pucTemp++ = 0x88;
         *pucTemp++ = 0x01;
         *pucTemp++ = 0x81;

         *(uchar8 *)(uiIEHdl-1) += (9 + 2); // Update the data packet length
      }

      if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_CONNECTIONIDENTITY,
            (void *)&xCIDInfo) == IFX_FAILURE){
            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE IFX_DECT_IE_CONNECTIONIDENTITY Failed.");
         return IFX_FAILURE;
      }

#ifdef SMART_HOME_DEMO

/*sending some junk (so used CIDInfo strcuture) IWU attributes since DSPG device needs*/
      if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUATTRIBUTES,
            (void *)&xCIDInfo) == IFX_FAILURE){
            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"AddIE IFX_DECT_IE_IWUATTRIBUTES Failed.");
         return IFX_FAILURE;
      }
#endif

   }

   /* Post to the Stack */
   IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "\nAfter MsgPost IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send PP Num: = ",ucInstanceId);

   if( FP_CC_SERVICE_ACCEPT_RQ == ucMsgId)
   {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "\nAfter MsgPost FP_CC_SERVICE_ACCEPT_RQ PP Num: = ",ucInstanceId);
      if(ucChangeMode == IFX_DECT_ULE_RESUME)
      {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "\n  ucChangeMode == IFX_DECT_ULE_RESUME PP Num: = ",ucInstanceId);
         pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
         pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
         xIpcMsg.ucMsgId = FP_ULE_SERVICE_RESUME_RQ;
         xIpcMsg.ucPara1 = ucInstanceId;

         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "\n  Calling IFX_DECT_ULE_NotifyPVCState PP Num: = ",ucInstanceId);
         IFX_DECT_ULE_NotifyPVCState(ucInstanceId,IFX_DECT_ULE_NWK_RESUME);

         IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      }
      else if(ucChangeMode == IFX_DECT_ULE_SUSPEND)
      {
         pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
         pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
         xIpcMsg.ucMsgId = FP_ULE_SERVICE_SUSPEND_RQ;
         xIpcMsg.ucPara1 = ucInstanceId;
         IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
         IFX_DECT_ULE_NotifyPVCState(ucInstanceId,IFX_DECT_ULE_NWK_SUSPEND);
      }
   }
   else if (FP_CC_SERVICE_CHANGE_RQ == ucMsgId)
   {
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "\nAfter MsgPost FP_CC_SERVICE_CHANGE_RQ PP Num: = ",ucInstanceId);
      if(ucChangeMode == IFX_DECT_ULE_RESUME)
      {
         pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME_RQOUT;
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "\n set pxCallInfo->eNWKState = ",IFX_DECT_ULE_NWK_RESUME_RQOUT);
      }
      else if(ucChangeMode == IFX_DECT_ULE_SUSPEND)
      {
         pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND_RQOUT;
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
               "\n set pxCallInfo->eNWKState = ",IFX_DECT_ULE_NWK_SUSPEND_RQOUT);
      }
   }

   return IFX_SUCCESS;
}

e_IFX_Return IFX_DECT_ULE_Handle_ServiceChange(IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
   uint32 uiIEHdl = 0;
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
   x_IFX_DECT_ULE_SubscInfo *pxSubInfo=NULL;
   x_IFX_DECT_IE_ServiceChange xSCIInfo;
#ifdef NONEED
   x_IFX_DECT_IE_ConnectionIdentity xCIDInfo;
#endif
   x_IFX_DECT_IPC_Msg xIpcMsg={0};
   uchar8 ucInstanceId=pxIpcMsg->ucPara1;
   //e_IFX_Return eRet=IFX_FAILURE;

   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                "\nIFX_DECT_ULE_Handle_ServiceChange Message ID= ",pxIpcMsg->ucMsgId);

   pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];
   pxSubInfo=&xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET];
   switch(pxIpcMsg->ucMsgId)
   {
      case FP_AUTHENTICATE_PT_CFM_MM:
      {
         //if(pxSubInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME_RQIN)
         if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME_RQIN)
         {
            if(pxCallInfo->eCCMState == IFX_DECT_ULE_CCM_GENERATED)
            {
               IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
                     /*FP_SERVICE_ACCEPT_IN_CC*/FP_CC_SERVICE_ACCEPT_RQ,IFX_DECT_ULE_RESUME);
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                            "\nFP_CC_SERVICE_ACCEPT_RQ,IFX_DECT_ULE_RESUME Message ID= ",pxIpcMsg->ucPara1);
            }
            else
            {
               IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
                     FP_CC_SERVICE_REJECT_RQ,IFX_DECT_AUTHENTICATION_FAILED);
               pxCallInfo->eCCMState = IFX_DECT_ULE_NWK_SUSPEND;
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                            "\nFP_CC_SERVICE_REJECT_RQ,IFX_DECT_AUTHENTICATION_FAILED Message ID= ",pxIpcMsg->ucPara1);
            }
            /*Since CCM key is used so set it to IDLE so that on next transaction again it has to be generated*/
            pxCallInfo->eCCMState = IFX_DECT_ULE_CCM_IDLE;
         }
#ifndef SMART_HOME_DEMO
         //else if(pxSubInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND)
         else if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND)
         {
            if(pxCallInfo->eCCMState == IFX_DECT_ULE_CCM_GENERATED)
            {
               IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
                     /*FP_SERVICE_CHANGE_IN_CC*/FP_CC_SERVICE_CHANGE_RQ,IFX_DECT_ULE_RESUME);
               //pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME_RQOUT;
               pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME_RQOUT;
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                            "\nFP_CC_SERVICE_CHANGE_RQ,IFX_DECT_ULE_RESUME Message ID= ",pxIpcMsg->ucPara1);
            }
            /*Since CCM key is used so set it to IDLE so that on next transaction again it has to be generated*/
            pxCallInfo->eCCMState = IFX_DECT_ULE_CCM_IDLE;
         }
#endif

         break;
      }

      case FP_SERVICE_CHANGE_IN_CC:
      {
         /*Decode IFX_DECT_IE_SERVICECHANGEINFO Start */
          if(0 == (uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIpcMsg)) ){
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");

               IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
                     FP_CC_SERVICE_REJECT_RQ,IFX_DECT_MANDATORY_IE_MISSING);
                   return IFX_SUCCESS;
          }

          while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_SERVICECHANGEINFO){
            if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
                  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"NO IFX_DECT_IE_SERVICECHANGEINFO IE");
               IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
                     FP_CC_SERVICE_REJECT_RQ,IFX_DECT_MANDATORY_IE_MISSING);
                   return IFX_SUCCESS;
            }

         }
         if(IFX_DECT_IE_ServiceChangeGet(uiIEHdl,&xSCIInfo) != IFX_SUCCESS){
               IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Get IFX_DECT_IE_SERVICECHANGEINFO IE fail");
               return IFX_FAILURE;
         }
         /*Decode IFX_DECT_IE_SERVICECHANGEINFO END */

#ifdef NONEED
         /*Decode IFX_DECT_IE_CONNECTIONIDENTITY Start */
         if(0 == (uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIpcMsg)) ){
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
               IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
                     FP_CC_SERVICE_REJECT_RQ,IFX_DECT_MANDATORY_IE_MISSING);
                   return IFX_SUCCESS;
          }


          while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_CONNECTIONIDENTITY){
            if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
                  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"NO IFX_DECT_IE_CONNECTIONIDENTITY IE");
               IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
                     FP_CC_SERVICE_REJECT_RQ,IFX_DECT_MANDATORY_IE_MISSING);
                   return IFX_SUCCESS;
            }

         }
         if(IFX_DECT_IE_ConnectionIdentityGet(uiIEHdl,&xCIDInfo) != IFX_SUCCESS){
               IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Get IFX_DECT_IE_CONNECTIONIDENTITY IE fail");
               return IFX_FAILURE;
         }
         /*Decode IFX_DECT_IE_CONNECTIONIDENTITY END */
#endif
         //if(  (pxSubInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME_RQOUT) ||
         //     (pxSubInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND_RQOUT) )
         if(  (pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME_RQOUT) ||
                (pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND_RQOUT) )
         {
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Collision case!!!!!! PP= ",ucInstanceId);
            IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
            FP_CC_SERVICE_REJECT_RQ,0x0C /*collision*/);
            pxCallInfo->ucServiceCallOwner = 1;
            return IFX_SUCCESS;
         }

         if(xSCIInfo.ucChangeMode == IFX_DECT_ULE_RESUME)
         {
            //if(pxSubInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME)
            if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME)
            {
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,"Unexpected Message Case!!!!!! PP= ",ucInstanceId);
               IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
               FP_CC_SERVICE_REJECT_RQ,0x01 /*unexpected message*/);
               return IFX_SUCCESS;
            }


            if(pxCallInfo->eCCMState == IFX_DECT_ULE_CCM_GENERATED)
            {
               /* send Accept*/

               IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
                  /*FP_SERVICE_ACCEPT_IN_CC*/FP_CC_SERVICE_ACCEPT_RQ,IFX_DECT_ULE_RESUME);
#if 0
/*This is handled in function IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send()*/
               pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
               pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
               xIpcMsg.ucMsgId = FP_ULE_SERVICE_RESUME_RQ;
               xIpcMsg.ucPara1 = ucInstanceId;
               IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);

               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                        "S.C. In CC: FP_ULE_SERVICE_RESUME_RQ");
#endif
               /*Since CCM key is used so set it to IDLE so that on next transaction again it has to be generated*/
               pxCallInfo->eCCMState = IFX_DECT_ULE_CCM_IDLE;
            }
            else if(pxCallInfo->eCCMState == IFX_DECT_ULE_CCM_INPROGRESS)
            {
                  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "  CCM IN Progress and SRVC CHNG ACPT WILL be sent after complete");
               //pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME_RQIN;
               pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME_RQIN;
            }
            else
            {
                  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "DCK not generated so first CCM Genaration and then Accept RESUME mode");
               //pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME_RQIN;
               pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME_RQIN;
               IFX_DECT_ULE_GenerateCCM(pxIpcMsg->ucPara1);
            }
         }
         else if(xSCIInfo.ucChangeMode == IFX_DECT_ULE_SUSPEND)
         {
            /* send Accept*/
            IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
               /*FP_SERVICE_ACCEPT_IN_CC*/FP_CC_SERVICE_ACCEPT_RQ,IFX_DECT_ULE_SUSPEND);

            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                     "FP_CC_SERVICE_ACCEPT_RQ: IFX_DECT_ULE_NWK_SUSPEND");

#if 0
/*This is handled in function IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send()*/
            pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
            pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
            xIpcMsg.ucMsgId = FP_ULE_SERVICE_SUSPEND_RQ;
            xIpcMsg.ucPara1 = ucInstanceId;
            IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
#endif
         }
         else if(xSCIInfo.ucChangeMode == IFX_DECT_ULE_OTHER)
         {
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " Received SRQ OTHER Message sending back same in SRQ Accept");
            /*send SR Accept*/
            IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
                  /*FP_SERVICE_ACCEPT_IN_CC*/FP_CC_SERVICE_ACCEPT_RQ,IFX_DECT_ULE_OTHER);

         }
         break;
      }

      case FP_SERVICE_ACCEPT_IN_CC:
      {
#ifdef NONEED

         /*Decode IFX_DECT_IE_CONNECTIONIDENTITY Start */
         if(0 == (uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIpcMsg)) ){
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
            IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
            FP_CC_SERVICE_REJECT_RQ,IFX_DECT_MANDATORY_IE_MISSING);
            if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME_RQOUT)
            {
               pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
            }
            else if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND_RQOUT)
            {
               pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
            }

               return IFX_SUCCESS;
         }
         while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_CONNECTIONIDENTITY){
            if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
                  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"NO IFX_DECT_IE_CONNECTIONIDENTITY IE");
               IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
               FP_CC_SERVICE_REJECT_RQ,IFX_DECT_MANDATORY_IE_MISSING);
               if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME_RQOUT)
               {
                  pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
               }
               else if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND_RQOUT)
               {
                  pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
               }
                  return IFX_SUCCESS;
            }
         }
         if(IFX_DECT_IE_ConnectionIdentityGet(uiIEHdl,&xCIDInfo) != IFX_SUCCESS){
               IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Get IFX_DECT_IE_CONNECTIONIDENTITY IE fail");
               return IFX_FAILURE;
         }
         /*Decode IFX_DECT_IE_CONNECTIONIDENTITY END */
#endif
         //if(pxSubInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME_RQOUT)
         if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME_RQOUT)
         {
            pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
            pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
            xIpcMsg.ucMsgId = FP_ULE_SERVICE_RESUME_RQ;
            /*Since CCM key is used so set it to IDLE so that on next transaction again it has to be generated*/
            pxCallInfo->eCCMState = IFX_DECT_ULE_CCM_IDLE;
         }

         //if(pxSubInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND_RQOUT)
         else if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND_RQOUT)
         {
            pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
            pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
            xIpcMsg.ucMsgId = FP_ULE_SERVICE_SUSPEND_RQ;
         }
         else
         {
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                              " Received SRQ Accept MSG for other??");
            break;
         }

         xIpcMsg.ucPara1 = ucInstanceId;
         IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);

         IFX_DECT_ULE_NotifyPVCState(ucInstanceId,pxCallInfo->eNWKState);

         if(pxCallInfo->ucNeedPVCResync)
         {
            if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND)
            {
               IFX_DECT_ULE_GenerateCCM(ucInstanceId);
            }
            else if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME)
            {
               pxCallInfo->ucNeedPVCResync =0;
            }
            else
            {
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                              " Check what could be the case here!!!!??");
               break;
            }
         }


#if 0 /*As these IEs are not sent in SR Accept by latest spec*/
         if(xSCIInfo.ucChangeMode == IFX_DECT_ULE_RESUME)
         {
            pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
            xIpcMsg.ucMsgId = FP_ULE_SERVICE_RESUME_RQ;
            xIpcMsg.ucPara1 = ucInstanceId;
            IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);

         }
         else if(xSCIInfo.ucChangeMode == IFX_DECT_ULE_SUSPEND)
         {
            pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
            xIpcMsg.ucMsgId = FP_ULE_SERVICE_SUSPEND_RQ;
            xIpcMsg.ucPara1 = ucInstanceId;
            IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);

         }
#endif
         break;
      }
      case FP_SERVICE_REJECT_IN_CC:
      {
            x_IFX_DECT_IPC_Msg xIpcMsg={0};
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                              " Received SRQ REJECT MSG");
         //if(pxSubInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME_RQOUT)
         if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME_RQOUT)
         {
            pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
            pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
            xIpcMsg.ucMsgId = FP_ULE_SERVICE_SUSPEND_RQ;
         }
         //if(pxSubInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND_RQOUT)
         else if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND_RQOUT)
         {
            pxSubInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
            pxCallInfo->eNWKState = IFX_DECT_ULE_NWK_RESUME;
            xIpcMsg.ucMsgId = FP_ULE_SERVICE_RESUME_RQ;
         }
         else
         {
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                              " Received SRQ REJECT MSG for other??");
            break;
         }
         xIpcMsg.ucPara1 = ucInstanceId;
            IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);

         break;
      }
   }

   if((pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_RESUME) && (pxCallInfo->ucServiceCallOwner))
   {
      x_IFX_DECT_IPC_Msg xIpcMsg={0};
      pxCallInfo->ucServiceCallOwner =0;
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "Releasing ULE Service call since FP is master now");
      IFX_DECT_EncodeRelease(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,
                              IFX_DECT_RELEASE_NORMAL,&xIpcMsg);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      pxCallInfo->eCallState=IFX_DECT_ULE_CALL_IDLE;
      if(xULE_Data.xULECallBks.pfnULENotify != NULL)
      {
         x_IFX_DECT_ULE_NotifyEvent xNotifyEvent;
         xNotifyEvent.eEvent=IFX_DECT_ULE_DEVICE_CPLANE_DISCONNECTED;
         xULE_Data.xULECallBks.pfnULENotify(pxIpcMsg->ucPara1,&xNotifyEvent);
      }
   }

   return IFX_SUCCESS;
}
e_IFX_Return IFX_DECT_ULE_HandleIWUInfo(IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
   x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
   uint32 uiIEHdl = 0;
   uint32 uiPagingRespTime=0;
   uint32 RangeFA=0,RangeSA=0,RangeSNSR=0;
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entering Handle ULE IWU Info");
  if(0 == (uiIEHdl = IFX_DECT_IE_GetIEHandler(pxIpcMsg)) ){
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No IE found");
    return IFX_FAILURE;
  }

  while(IFX_DECT_IE_TypeGet(uiIEHdl) != IFX_DECT_IE_IWUTOIWU){
    if(IFX_DECT_IE_NextIEHandlerGet(&uiIEHdl) == IFX_FAILURE){
       IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"NO IWU TO IWU IE");
       return IFX_FAILURE;
    }
  }
  if(IFX_DECT_IE_IWUToIWUGet(uiIEHdl,&xIWUToIWUInfo) != IFX_SUCCESS){
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"NO IWU TO IWU IE");
      return IFX_FAILURE;
  }

  //xIWUToIWUInfo.ucPD,xIWUToIWUInfo.ucSR,xIWUToIWUInfo.ucDefault1,xIWUToIWUInfo.ucIWUToIWULen
  if((xIWUToIWUInfo.ucPD != 0x05)||(xIWUToIWUInfo.ucIWUToIWULen<=0)){
    IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"NoT For ULE !!!!!!!!??");
    return IFX_FAILURE;
  }
   if(xIWUToIWUInfo.acIWUToIWU[0] == 1)
   {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"PD for HANFUN APP");
   }
   if(xIWUToIWUInfo.acIWUToIWU[1] == 1)
   {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"FUN Class=REG");
   }
   if(xIWUToIWUInfo.acIWUToIWU[2] == 1)
   {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"FUN CMD=Paging Required");
   }

   uiPagingRespTime = (xIWUToIWUInfo.acIWUToIWU[3] << 8) | xIWUToIWUInfo.acIWUToIWU[4];
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT," Paging Response Time",uiPagingRespTime);

   RangeFA=(0x01 << xULE_Data.xULEConfig.uiFastActuatorPageCycle);
   RangeSA=(0x01 << xULE_Data.xULEConfig.uiSlowActuatorPageCycle);
   RangeSNSR=(0x01 << xULE_Data.xULEConfig.uiSensorPageCycle);

   if(RangeFA >= uiPagingRespTime)
   {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Configure as FastActuator");
      IFX_DECT_ULE_SetDeviceType(pxIpcMsg->ucPara1,IFX_DECT_ULE_FASTACTUATOR);
   }
   else if(RangeSA >= uiPagingRespTime)
   {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Configure as SlowActuator");
      IFX_DECT_ULE_SetDeviceType(pxIpcMsg->ucPara1,IFX_DECT_ULE_SLOWACTUATOR);
   }
   else if(RangeSNSR >= uiPagingRespTime)
   {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Configure as Sensor");
      IFX_DECT_ULE_SetDeviceType(pxIpcMsg->ucPara1,IFX_DECT_ULE_SENSOR);
   }
   else
   {
      IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Configure as NONE?????????");
   }
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Return from Handle ULE IWU Info");
   return IFX_SUCCESS;
}

e_IFX_Return IFX_DECT_ULE_ResetDPSUCallType(uchar8 ucInstanceId)
{
	x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;

	if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
	{
		IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
		               "Invalid ULE instance number !!!!!!");
		IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
		return IFX_FAILURE;
	}
	if(xULE_Data.pxULECallInfo == NULL)
	{
		IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
		               "ULE NOT INITED !!!!!!");
		IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
		return IFX_FAILURE;
	}

	pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];
	pxCallInfo->ucCallType = 0;	
	
	return IFX_SUCCESS;
	
}

e_IFX_Return IFX_DECT_ULE_ProcessCPlaneMsg(IN x_IFX_DECT_IPC_Msg *pxIpcMsg)
{
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
  x_IFX_DECT_IPC_Msg xIpcMsg={0};
   x_IFX_DECT_IE_BasicService xBSInfo;
   uchar8 ucInstanceId=pxIpcMsg->ucPara1;
   e_IFX_Return eRet=IFX_FAILURE;

   if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Invalid ULE instance number !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
      return IFX_FAILURE;
   }
   if(xULE_Data.pxULECallInfo == NULL)
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE NOT INITED !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
      return IFX_FAILURE;
   }

   pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];

	if((pxIpcMsg->ucMsgId == FP_SETUP_IN_CC) && (pxIpcMsg->ucPara2 == BS_DATA_CALL)) 
	{ //137

		pxCallInfo->ucCallType = IFX_DECT_ULE_DPSU_CALL;

		return IFX_DECT_DPSU_ProcessCPlaneMsg(pxIpcMsg);		
	}	
	else if(pxIpcMsg->ucMsgId == FP_FACILITY_IN_CLSS){
         if(IFX_DECT_DPSU_CheckPD(pxIpcMsg)==IFX_SUCCESS){

           return IFX_DECT_DPSU_ProcessCPlaneMsg(pxIpcMsg);
           
         }
    }
	else if(pxCallInfo->ucCallType == IFX_DECT_ULE_DPSU_CALL)
	{
		eRet = IFX_DECT_DPSU_ProcessCPlaneMsg(pxIpcMsg);
		if(pxIpcMsg->ucMsgId == FP_RELEASE_IN_CC)
		{
			pxCallInfo->ucCallType = 0;
		}
		return eRet;
	}
	
   switch(pxIpcMsg->ucMsgId)
   {
      case FP_PORTABLE_REGISTERED_IN_MM:
      case FP_PORTABLE_ATTACHED_IN_MM:
      case FP_ACCESS_RIGHTS_TERMINATE_CFM_MM:
      case FP_PROP_INFO_IN_MM:
      case FP_MODEM_BOOT_IND:
      case FP_MAC_NOEMO_IN_ME:


      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " Calling ULE MU Process Stack Message");
      eRet = IFX_DECT_ULE_MU_ProcessStackMsg(pxIpcMsg);
      break;
    case FP_SETUP_IN_CC:
    {
   uint32 uiFlag;
   uchar8 ucRejectReason;
   memset(&xBSInfo,0,sizeof(x_IFX_DECT_IE_BasicService));
   uiFlag=0;
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "This is a ULE service call");
   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Checking Basic srevice");
   if(IFX_DECT_ULE_ValidateBasicService(pxIpcMsg,&xBSInfo) != IFX_SUCCESS){
         IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "Mandatory Parameters Are Missing" );
      uiFlag=1;
      ucRejectReason=IFX_DECT_MANDATORY_IE_MISSING;
   }else if(xBSInfo.ucCallClass!=0x03){
         IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "CC-Setup does not have ULE Service callClass" );
      uiFlag=1;
      ucRejectReason=IFX_DECT_INVALID_IE_CONTENTS;
   }
   if(uiFlag==1){
      IFX_DECT_EncodeRelease(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,
                              ucRejectReason,&xIpcMsg);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
   }
   else{
      pxCallInfo->eCallState=IFX_DECT_ULE_SETUP;

#ifdef SMART_HOME_DEMO
   pxCallInfo->eCCMState=IFX_DECT_ULE_CCM_IDLE;
#endif

      if(vxGlobalInfo.xStackCfg.bEncryption == IFX_TRUE)
      {
         IFX_DECT_EncodeAuthPTReq(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,&xIpcMsg);
         IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      }
      else
      {
               IFX_DECT_EncodeCallProc(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,
                                     &xIpcMsg);
               IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
         pxCallInfo->eCallState=IFX_DECT_ULE_CPLANE_CONNECTED;

         if(xULE_Data.xULECallBks.pfnULENotify != NULL)
         {
            x_IFX_DECT_ULE_NotifyEvent xNotifyEvent;
            xNotifyEvent.eEvent=IFX_DECT_ULE_DEVICE_CPLANE_CONNECTED;
            xULE_Data.xULECallBks.pfnULENotify(pxIpcMsg->ucPara1,&xNotifyEvent);
         }

         if(pxCallInfo->ucNeedPVCResync)
         {
            IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(pxIpcMsg->ucPara1,FP_CC_SERVICE_CHANGE_RQ,IFX_DECT_ULE_SUSPEND);
         }
#if 0
         else if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND)
         {
            IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(pxIpcMsg->ucInstance,FP_CC_SERVICE_CHANGE_RQ,IFX_DECT_ULE_OTHER);
         }
#endif

#if 0
/*FP expects that PP should do Service Change Req RESUME as per HF-ULE Interworking Spec*/
#ifndef SMART_HOME_DEMO
         {
            /*Testing purpose to send IWU-TO-IWU START*/
            x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
            uint32 uiIEHdl=0;

            memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
            xIWUToIWUInfo.ucDefault1 = 1; /* Dont care */
            xIWUToIWUInfo.ucSR = 1;/* Transmission Msg */
            xIWUToIWUInfo.ucPD = 0x05; /*ULE Config & control*/
            xIWUToIWUInfo.ucIWUToIWULen = strlen("LANTIQ ULE FP"); /*Junk Data*/
            strcpy((char *)&xIWUToIWUInfo.acIWUToIWU,"LANTIQ ULE FP");

            if((uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData))!=IFX_FAILURE){
               if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUTOIWU,(void *)&xIWUToIWUInfo)
                           != IFX_SUCCESS){
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IE add failed : ULE IWU-TO-IWU");
               return IFX_FAILURE;
               }
            }
            else{
                  IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Create NEW IE failed");
               return IFX_FAILURE;
            }

            IFX_DECT_EncodeIWUInfo(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,&xIpcMsg);
            IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
            /*Testing purpose to send IWU-TO-IWU  END*/
         }
         /*Ideally we can check here the CCM state and decide to generate CCM. But it is
           nothing harm if every time a new CCM is generated after this service call. Infact it
           is good for ULE PPs which do not mainatin CCM key across reboot and if FP maintains it*/
         IFX_DECT_ULE_GenerateCCM(pxIpcMsg->ucPara1);
#endif
#endif

      }/*Endof encryption flag else part*/
   }/*end of if uiFlag==1 else part*/
   eRet=IFX_SUCCESS;
         break;
    }
    case FP_RELEASE_IN_CC:
      {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "ULE service call released");
         pxCallInfo->eCallState=IFX_DECT_ULE_CALL_IDLE;

         if(xULE_Data.xULECallBks.pfnULENotify != NULL)
         {
            x_IFX_DECT_ULE_NotifyEvent xNotifyEvent;
            xNotifyEvent.eEvent=IFX_DECT_ULE_DEVICE_CPLANE_DISCONNECTED;
            xULE_Data.xULECallBks.pfnULENotify(pxIpcMsg->ucPara1,&xNotifyEvent);
         }

         eRet=IFX_SUCCESS;
      break;
      }
    case FP_CIPHER_ON_CFM_MM:
      {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "Cipher cfm arrived for ULE service call");
      IFX_DECT_EncodeCallProc(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,
                                     &xIpcMsg);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
         pxCallInfo->eCallState=IFX_DECT_ULE_CPLANE_CONNECTED;

         if(xULE_Data.xULECallBks.pfnULENotify != NULL)
         {
            x_IFX_DECT_ULE_NotifyEvent xNotifyEvent;
            xNotifyEvent.eEvent=IFX_DECT_ULE_DEVICE_CPLANE_CONNECTED;
            xULE_Data.xULECallBks.pfnULENotify(pxIpcMsg->ucPara1,&xNotifyEvent);
         }
         if(pxCallInfo->ucNeedPVCResync)
         {
            IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(pxIpcMsg->ucPara1,FP_CC_SERVICE_CHANGE_RQ,IFX_DECT_ULE_SUSPEND);
         }
#if 0
         else if(pxCallInfo->eNWKState == IFX_DECT_ULE_NWK_SUSPEND)
         {
            IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(pxIpcMsg->ucInstance,FP_CC_SERVICE_CHANGE_RQ,IFX_DECT_ULE_OTHER);
         }
#endif

#if 0
#ifndef SMART_HOME_DEMO
         {
            /*Testing purpose to send IWU-TO-IWU START*/
            x_IFX_DECT_IE_IWUToIWU xIWUToIWUInfo={0};
            uint32 uiIEHdl=0;

            memset(&xIpcMsg,0,sizeof(x_IFX_DECT_IPC_Msg));
            xIWUToIWUInfo.ucDefault1 = 1; /* Dont care */
            xIWUToIWUInfo.ucSR = 1;/* Transmission Msg */
            xIWUToIWUInfo.ucPD = 0x05; /*ULE Config & control*/
            xIWUToIWUInfo.ucIWUToIWULen = strlen("LANTIQ ULE FP"); /*Junk Data*/
            strcpy((char *)&xIWUToIWUInfo.acIWUToIWU,"LANTIQ ULE FP");

            if((uiIEHdl = IFX_DECT_IE_NewIECreate(xIpcMsg.acData))!=IFX_FAILURE){
               if(IFX_DECT_IE_IEAdd(uiIEHdl,IFX_DECT_IE_IWUTOIWU,(void *)&xIWUToIWUInfo)
                           != IFX_SUCCESS){
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"IE add failed : ULE IWU-TO-IWU");
               return IFX_FAILURE;
               }
            }
            else{
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Create NEW IE failed");
               return IFX_FAILURE;
            }

            IFX_DECT_EncodeIWUInfo(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,&xIpcMsg);
            IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
            /*Testing purpose to send IWU-TO-IWU  END*/
         }
         /*Ideally we can check here the CCM state and decide to generate CCM. But it is
           nothing harm if every time a new CCM is generated after this service call. Infact it
           is good for ULE PPs which do not mainatin CCM key across reboot and if FP maintains it*/
         IFX_DECT_ULE_GenerateCCM(pxIpcMsg->ucPara1);
#endif
#endif
         eRet=IFX_SUCCESS;
         break;
      }
    case FP_CIPHER_OFF_CFM_MM:
    {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "ULE Cipher CFM Failed");
         IFX_DECT_EncodeRelease(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,
                              IFX_DECT_RELEASE_ENCR_ACT_FAIL,&xIpcMsg);
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
         pxCallInfo->eCallState=IFX_DECT_ULE_CALL_IDLE;
         eRet=IFX_SUCCESS;
      break;
    }
    case FP_AUTHENTICATE_PT_CFM_MM:
    {
      IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                    "\nFP_AUTHENTICATE_PT_CFM_MM PPNo = ", ucInstanceId);

      if(pxCallInfo->eCCMState == IFX_DECT_ULE_CCM_INPROGRESS)
       //   if(pxIpcMsg->ucPara4 ==1)
      {
               if(pxIpcMsg->ucPara2 ==1){
            IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                        "ULE  AUTH PT CNFM SUCCESS for CCM Process");
            pxCallInfo->eCCMState = IFX_DECT_ULE_CCM_GENERATED;
         }
         else
         {
                  IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                           "ULE  AUTH PT Fail for CCM Process");
               pxCallInfo->eCCMState = IFX_DECT_ULE_CCM_IDLE;
         }
         /*Check if this Auth Confirm is any relevance to Service Change FSM?*/
         IFX_DECT_ULE_Handle_ServiceChange(pxIpcMsg);
      }
      else
      {
               if(pxIpcMsg->ucPara2 ==1){
            IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                        "ULE  AUTH PT CNFM SUCCESS for normal Auth Process");
                  IFX_DECT_EncodeEnableCipher(pxIpcMsg->ucPara1,
                                    pxIpcMsg->ucInstance,
                                      1,
                                      &xIpcMsg);
                  IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
         }
         else
         {
            IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                      "ULE Authenticate CFM for normal Auth process Failed");

            IFX_DECT_EncodeRelease(pxIpcMsg->ucPara1,pxIpcMsg->ucInstance,
                              IFX_DECT_RELEASE_ENCR_ACT_FAIL,&xIpcMsg);
               IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
            pxCallInfo->eCallState=IFX_DECT_ULE_CALL_IDLE;

         }

      }
      eRet=IFX_SUCCESS;
       break;
    }

      case FP_SERVICE_CHANGE_IN_CC:
      case FP_SERVICE_ACCEPT_IN_CC:
      case FP_SERVICE_REJECT_IN_CC:
      {
			eRet = IFX_DECT_ULE_Handle_ServiceChange(pxIpcMsg);
         break;
      } /*FP_SERVICE_CHANGE_IN_CC*/



      case FP_SUBSCRIPTION_INFO_UPDATED_MM:
      {
         if(xULE_Data.xULECallBks.pfnULENotify != NULL)
         {
            x_IFX_DECT_ULE_NotifyEvent xNotifyEvent;
            x_IFX_DECT_ULE_SubscInfo *pxDectSubsInfo;
            xNotifyEvent.eEvent=IFX_DECT_ULE_UPDATE_SUBS_INFO;

            pxDectSubsInfo = (x_IFX_DECT_ULE_SubscInfo*)
                         (pxIpcMsg->acData + sizeof(struct HLI_Header));

            memcpy(&xNotifyEvent.uxNotify.xSubscInfo, pxDectSubsInfo,
                                 sizeof(x_IFX_DECT_ULE_SubscInfo));

#if 0
            memcpy(&(xULE_Data.xULESubscData.xRegList[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET]),
                  pxDectSubsInfo,sizeof(x_IFX_DECT_ULE_SubscInfo));

            {/*Update DCK status*/
               uchar8  acdck_array[IFX_ULE_CIPHER_KEY_SIZE];
               memset(acdck_array,0,sizeof(acdck_array));
               if(memcmp(acdck_array,&xULE_Data.xULESubscData.xRegList[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].acdck_array,sizeof(acdck_array)))
               {
                  xULE_Data.pxULECallInfo[pxIpcMsg->ucPara1 - IFX_DECT_ULE_OFFSET].eCCMState = IFX_DECT_ULE_CCM_GENERATED;
               }
            }
            #endif

            eRet = xULE_Data.xULECallBks.pfnULENotify(pxIpcMsg->ucPara1,&xNotifyEvent);
         }

         break;
      } /*FP_SUBSCRIPTION_INFO_UPDATED_MM*/

      case FP_IWU_INFO_IN_CC:
      {

         eRet = IFX_DECT_ULE_HandleIWUInfo(pxIpcMsg);
         break;
      }

   }
   return eRet;
}
e_IFX_Return IFX_DECT_ULE_UpdateSubscInfo(IN uchar8 ucInstanceId,
                                          IN x_IFX_DECT_ULE_SubscInfo *pxSubscInfo)
{
   x_IFX_DECT_IPC_Msg xIpcMsg={0};
   uchar8 ucTmp=0;
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;

   if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Invalid ULE instance number !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
      return IFX_FAILURE;
   }
   if(xULE_Data.pxULECallInfo == NULL)
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE NOT INITED !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
      return IFX_FAILURE;
   }

   pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];


   /*This for IOP where WEB page configuring some infos like below and
     ATTENTION!!!!!!!!!stack has to use only these values to update its Database not other.
      uchar8  Last_SSN[6];
      uchar8  Last_RSN[6];
      uint32  eULEType;
      uint32 uiSDUSize;
      uchar8 ucWindowSize;
    */
   if(memcmp(pxSubscInfo->Last_SSN,xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].Last_SSN,6))
   {
      ucTmp |= 1;
      memcpy(xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].Last_SSN,pxSubscInfo->Last_SSN,6);
   // memcpy(vxGlobalInfo.xMU.vxMUInfo[ucInstanceId-1].xSubscInfo.Last_SSN,pxSubscInfo->Last_SSN,6);
   }
   if(memcmp(pxSubscInfo->Last_RSN,xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].Last_RSN,6))
   {
      ucTmp |= 2;
      memcpy(xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].Last_RSN,pxSubscInfo->Last_RSN,6);
      //memcpy(vxGlobalInfo.xMU.vxMUInfo[ucInstanceId-1].xSubscInfo.Last_RSN,pxSubscInfo->Last_RSN,6);
   }
   if(pxSubscInfo->uiSDUSize != xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].uiSDUSize)
   {
      ucTmp |= 8;
      xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].uiSDUSize = pxSubscInfo->uiSDUSize;
      //vxGlobalInfo.xMU.vxMUInfo[ucInstanceId-1].xSubscInfo.uiSDUSize = pxSubscInfo->uiSDUSize;
   }
   if(pxSubscInfo->ucWindowSize != xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].ucWindowSize)
   {
      ucTmp |= 16;
      xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].ucWindowSize = pxSubscInfo->ucWindowSize;
      //vxGlobalInfo.xMU.vxMUInfo[ucInstanceId-1].xSubscInfo.ucWindowSize = pxSubscInfo->ucWindowSize;
   }
   if(ucTmp)
   {
      xIpcMsg.ucMsgId = FP_ULE_TEMP_SUB_UPDATE_RQ;
      xIpcMsg.ucPara1 = ucInstanceId;
      xIpcMsg.ucPara2 = ucTmp;
      ((DATA_FRAME *)xIpcMsg.acData)->length = sizeof(x_IFX_DECT_ULE_SubscInfo);
      memcpy(((DATA_FRAME *)xIpcMsg.acData)->dat,pxSubscInfo,sizeof(x_IFX_DECT_ULE_SubscInfo));
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
   }
   if(pxSubscInfo->eULEType != xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].eULEType)
   {
      //ucTmp |= 4;
   // xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].eULEType = pxSubscInfo->eULEType;
   // vxGlobalInfo.xMU.vxMUInfo[ucInstanceId-1].xSubscInfo.eULEType = pxSubscInfo->eULEType;
      IFX_DECT_ULE_SetDeviceType(ucInstanceId,pxSubscInfo->eULEType);
   }


   if(pxSubscInfo->eNWKState != xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].eNWKState)
   {
       x_IFX_DECT_IPC_Msg xIpcMsg={0};
       int32 iPVCState=0;
       if(pxCallInfo->eCallState != IFX_DECT_ULE_CPLANE_CONNECTED)
       {
          IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               "ULE service call Not established so assuming it is just local update at FP side!!!!!!!!!!");
         if(pxSubscInfo->eNWKState)
         {
             xIpcMsg.ucMsgId = FP_ULE_SERVICE_RESUME_RQ;
            iPVCState = IFX_DECT_ULE_NWK_RESUME;
         }
         else
         {
           xIpcMsg.ucMsgId = FP_ULE_SERVICE_SUSPEND_RQ;
            iPVCState = IFX_DECT_ULE_NWK_SUSPEND;
         }
          xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].eNWKState = pxSubscInfo->eNWKState;
          xULE_Data.pxULECallInfo[ucInstanceId - IFX_DECT_ULE_OFFSET].eNWKState = pxSubscInfo->eNWKState;
         xIpcMsg.ucPara1 = ucInstanceId;
         IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
         IFX_DECT_ULE_NotifyPVCState(ucInstanceId,iPVCState);
         return IFX_SUCCESS;
      }
       if(pxSubscInfo->eNWKState)
       {
         //xIpcMsg.ucMsgId = FP_ULE_SERVICE_RESUME_RQ;

          /*Request is to move the state to RESUME, so set it to SUSPEND and Generate CCM and response to CCM will
           send SRQ-RESUME*/
         xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
         xULE_Data.pxULECallInfo[ucInstanceId - IFX_DECT_ULE_OFFSET].eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
         IFX_DECT_ULE_GenerateCCM(ucInstanceId);
       }
       else
       {
         //xIpcMsg.ucMsgId = FP_ULE_SERVICE_SUSPEND_RQ;
         IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
            /*FP_SERVICE_CHANGE_IN_CC*/FP_CC_SERVICE_CHANGE_RQ,IFX_DECT_ULE_SUSPEND);
         //xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].eNWKState = IFX_DECT_ULE_NWK_SUSPEND_RQOUT;
         xULE_Data.pxULECallInfo[ucInstanceId - IFX_DECT_ULE_OFFSET].eNWKState = IFX_DECT_ULE_NWK_SUSPEND_RQOUT;
       }
       //xIpcMsg.ucPara1 = ucInstanceId;
      //IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
   }
   /*Unreg event */
   if((pxSubscInfo->cstatus==0)&&(pxSubscInfo->cstatus!=xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET].cstatus)){
      /*Need to handle this event*/
         IFX_DECT_MU_ULE_UnregisterPP(ucInstanceId-1,ucInstanceId);
   }
   //memcpy(&(vxGlobalInfo.xMU.vxMUInfo[ucInstanceId-1].xSubscInfo),pxSubscInfo,sizeof(x_IFX_DECT_ULE_SubscInfo));
   //memcpy(&(xULE_Data.xULESubscData.xRegList[ucInstanceId - IFX_DECT_ULE_OFFSET]),pxSubscInfo,sizeof(x_IFX_DECT_ULE_SubscInfo));
   return IFX_SUCCESS;
}

e_IFX_Return  IFX_DECT_MU_ULE_BPagePP_Stop(IN uchar8 ucInstanceId)
{
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
   x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};
   if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Invalid ULE instance number !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
      return IFX_FAILURE;
   }
   if(xULE_Data.pxULECallInfo == NULL)
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE NOT INITED !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
      return IFX_FAILURE;
   }

   pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];

   if(pxCallInfo->uiDataSendTimerId)
   {
      IFX_DECT_StopTimer(pxCallInfo->uiDataSendTimerId);
      pxCallInfo->uiDataSendTimerId = 0;
   }
    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " ULE B Paging Stop from App !!!!!!!!!!");
   //pxCallInfo->eDataSendState = IFX_DECT_ULE_CLOSE_INPROGRESS;
   pxCallInfo->eDataSendState = IFX_DECT_ULE_DATA_IDLE;

   //xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_SDU_STOP_RQ;
   xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_PAGE_STOP_RQ;
   #ifdef CONFIG_TEST_SUOTA_PAGING
   xUPlaneIpcMsg.ucPara3 = 3;
   #else
   xUPlaneIpcMsg.ucPara3 = 0;
   #endif
   xUPlaneIpcMsg.ucPara4 = ucInstanceId;
   if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
   {
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            " ULE Stop Page failed due to PostToStack failure");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
   }

   return IFX_SUCCESS;
}
e_IFX_Return  IFX_DECT_MU_ULE_BPagePP(IN uchar8 ucInstanceId,IN uchar8 *pcCnip,IN uchar8 *pcClip)
{
   x_IFX_DECT_IPC_Msg_u xUPlaneIpcMsg = {0};
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;

   if((ucInstanceId < IFX_DECT_ULE_OFFSET ) || (ucInstanceId > IFX_DECT_MAX_ULE_DEVICES+IFX_DECT_ULE_OFFSET-1))
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Invalid ULE instance number !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_INVALID_INSTANCE;
      return IFX_FAILURE;
   }

   if(xULE_Data.pxULECallInfo == NULL)
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "ULE NOT INITED !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_NOT_INITED;
      return IFX_FAILURE;
   }
   pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];

#if 0 /*We can check after stabilization of code as not sure the device will reattach if FT reboots. So may be the state will
      be just in REGISTER state?*/
   if( pxCallInfo->eMuState < IFX_DECT_ULE_ATTACHED )
   {
      IFX_DBGC(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
                     "Device not attached !!!!!!");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_PP_NOT_ATTACHED;
      return IFX_FAILURE;
   }
#endif

   pxCallInfo->eDataSendState = IFX_DECT_ULE_BPAGING_INPROGRESS;

   xUPlaneIpcMsg.ucMsgId = FP_ULE_MEDIA_PAGE_RQ;
   xUPlaneIpcMsg.ucPara1 = 0;
   xUPlaneIpcMsg.ucPara2 = 0;
   #ifdef CONFIG_TEST_SUOTA_PAGING
   xUPlaneIpcMsg.ucPara2 = 1;
   xUPlaneIpcMsg.ucPara3 =  3;
   #else
   xUPlaneIpcMsg.ucPara3 =  0;
   #endif
   xUPlaneIpcMsg.ucPara4 = ucInstanceId;
   if(IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_U_PLANE,&xUPlaneIpcMsg) != IFX_SUCCESS)
   {
       IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " ULE B Paging failed due to PostToStack failure");
      IFX_DECT_ULE_ErrNo = IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED;
       return IFX_FAILURE;
   }
   IFX_DECT_StartTimer(IFX_DECT_ULE_DATASEND_TIMEOUT,&ucInstanceId,sizeof(uchar8),
                             IFX_DECT_ULE_DataSendTimerExpFunc, &pxCallInfo->uiDataSendTimerId);

    IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
               " ULE B Paging Initiated");
   return IFX_SUCCESS;

}

e_IFX_Return IFX_DECT_MU_ULE_UnregisterPP(
                         IN uchar8 ucInstance,
                         IN uchar8 ucHandset)
{
   x_IFX_DECT_IPC_Msg xIpcMsg = {0};
   IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received ULE Unregister for single PP from App" );
   xIpcMsg.ucMsgId = FP_MM_ACCESS_RIGHTS_TERMINATE_RQ;
   xIpcMsg.ucInstance = ucInstance;
   xIpcMsg.ucPara1 = ucHandset;

   if((ucHandset >= IFX_DECT_ULE_OFFSET) && (ucHandset < (IFX_DECT_ULE_OFFSET + IFX_DECT_MAX_ULE_DEVICES)))
   {
      IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
      xULE_Data.pxULECallInfo[ucHandset - IFX_DECT_ULE_OFFSET].eMuState = IFX_DECT_ULE_IDLE;

      /*Check with JN whether it is Ok to reset this info to zero after freeing*/
      IFX_DECT_ULE_Free_Init_DeviceNum(xULE_Data.xULESubscData.xRegList[ucHandset - IFX_DECT_ULE_OFFSET].ucDeviceNo, \
            xULE_Data.xULESubscData.xRegList[ucHandset - IFX_DECT_ULE_OFFSET].eULEType,0);

      xULE_Data.xULESubscData.xRegList[ucHandset - IFX_DECT_ULE_OFFSET].ucDeviceNo = 0;
      xULE_Data.xULESubscData.xRegList[ucHandset - IFX_DECT_ULE_OFFSET].eULEType = IFX_DECT_ULE_NONE;
      xULE_Data.pxULECallInfo[ucHandset - IFX_DECT_ULE_OFFSET].eCallState = IFX_DECT_ULE_CALL_IDLE;
      xULE_Data.pxULECallInfo[ucHandset - IFX_DECT_ULE_OFFSET].eDataSendState = IFX_DECT_ULE_DATA_IDLE;
      xULE_Data.pxULECallInfo[ucHandset - IFX_DECT_ULE_OFFSET].eDataRecvState = IFX_DECT_ULE_DATA_IDLE;
      xULE_Data.pxULECallInfo[ucHandset - IFX_DECT_ULE_OFFSET].eCCMState = IFX_DECT_ULE_CCM_IDLE;
      xULE_Data.pxULECallInfo[ucHandset - IFX_DECT_ULE_OFFSET].eNWKState = IFX_DECT_ULE_NWK_SUSPEND;
      xULE_Data.pxULECallInfo[ucHandset - IFX_DECT_ULE_OFFSET].uiDataSendTimerId = 0;

      if(xULE_Data.xULECallBks.pfnULENotify != NULL)
      {
         x_IFX_DECT_ULE_NotifyEvent xNotifyEvent;
         x_IFX_DECT_ULE_SubscInfo xDectSubsInfo;

         memset(&xDectSubsInfo,0,sizeof(x_IFX_DECT_ULE_SubscInfo));
         xNotifyEvent.eEvent=IFX_DECT_ULE_UPDATE_SUBS_INFO;
         memcpy(&xNotifyEvent.uxNotify.xSubscInfo, &xDectSubsInfo,
                        sizeof(x_IFX_DECT_ULE_SubscInfo));
         xULE_Data.xULECallBks.pfnULENotify(ucHandset,&xNotifyEvent);
      }

      IFX_DECT_ULE_NotifyPVCState(ucHandset,IFX_DECT_ULE_NWK_SUSPEND);
      return IFX_SUCCESS;
   }
      return IFX_SUCCESS;
}

PUBLIC e_IFX_Return IFX_DECT_MU_ULE_UNRegister(IN uchar8 isAll,
                                           IN uchar8 ucHandset)
{
  uchar8 ucIndex;
  IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
           "Received ULE Unregister from App" );
  if(isAll){
    for ( ucIndex=IFX_DECT_ULE_OFFSET;ucIndex < (IFX_DECT_ULE_OFFSET + IFX_DECT_MAX_ULE_DEVICES) ;ucIndex++){
         if(xULE_Data.pxULECallInfo[ucHandset - IFX_DECT_ULE_OFFSET].eMuState >= IFX_DECT_ULE_REGISTERED){/*Unregister HS if registered irrespective of any other state*/
               IFX_DECT_MU_ULE_UnregisterPP(ucIndex,ucIndex+1);
            }
    }
  }else{
      if(ucHandset >= IFX_DECT_ULE_OFFSET && ucHandset < (IFX_DECT_ULE_OFFSET + IFX_DECT_MAX_ULE_DEVICES) \
           && (xULE_Data.pxULECallInfo[ucHandset - IFX_DECT_ULE_OFFSET].eMuState >= IFX_DECT_ULE_REGISTERED)){/*Unregister HS if registered irrespective of any other state*/
         IFX_DECT_MU_ULE_UnregisterPP(ucHandset-1,ucHandset);
    }
  }
  return IFX_SUCCESS;
}
int32 IFX_DECT_ULE_AllocDeviceNum(e_IFX_DECT_ULE_Type eDeviceType)
{
   uchar8 *pucDevicecount, ucMaxDeviceCount;
   uchar8 *pucDeviceArrayptr = NULL;
   int i,index=0,iPos=0;
   IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entering IFX_DECT_ULE_AllocDeviceNum");
#ifdef SMART_HOME_DEMO
   for(i=0;i<=200;i++)
   {
      if(auiULEDeviceNum[i] == 0)
      {
         auiULEDeviceNum[i] = 1;
         return i+1;
      }
   }
  return IFX_FAILURE;
#endif

   switch(eDeviceType)
   {
      case IFX_DECT_ULE_SENSOR:
      {
         pucDevicecount=&ucSensorCount;
         ucMaxDeviceCount=IFX_DECT_ULE_MAX_SENSORS;
         pucDeviceArrayptr = aucSensorDeviceNum;
         break;
      }
      case IFX_DECT_ULE_SLOWACTUATOR:
      {
         pucDevicecount=&ucSlowActCount;
         ucMaxDeviceCount=IFX_DECT_ULE_MAX_SLOWACT;
         pucDeviceArrayptr = aucSlowActNum;
         break;
      }
      case IFX_DECT_ULE_FASTACTUATOR:
      {
         pucDevicecount=&ucFastActCount;
         ucMaxDeviceCount=IFX_DECT_ULE_MAX_FASTACT;
         pucDeviceArrayptr = aucFastActNum;
         break;
      }
      default:
      {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "Please chk something wrong;Device number cannot exist without Device type" );
         return IFX_FAILURE;
      }

      if((*pucDevicecount+1) > ucMaxDeviceCount)
      {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "Cannot allocate device number as exceeding Limit!!!!!" );
         return IFX_FAILURE;
      }
   }
   //*pucDevicecount++;
   *pucDevicecount= *pucDevicecount+1;
   for(i=0;i<10;i++)
   {
      if(pucDeviceArrayptr[i] < 0xff)
      {
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "\nULE Index for Device array= ",i);
         index=i;
         break;
      }
   }

   for(i=0;i<8;i++)
   {
      if((pucDeviceArrayptr[index] & (0x01 << i)) == 0)
      {
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "\nULE Index Position for Device array= ",i);
         iPos=i;
         pucDeviceArrayptr[index] |= (0x01 << iPos);
         break;
      }
   }

   return ((index*8)+iPos+1);

}
e_IFX_Return IFX_DECT_ULE_Free_Init_DeviceNum(uchar8 ucDeviceNum, e_IFX_DECT_ULE_Type eDeviceType,uchar8 ucFreeInitFlg)
{
   uchar8 *pucDeviceArrayptr = NULL;
   uchar8 *pucDevicecount =NULL;
   int iIndex,iPos;
   uchar8 ucMask=0x01;
   if(ucDeviceNum == 0)
   {
      return IFX_SUCCESS;
   }
#ifdef SMART_HOME_DEMO
   if(ucFreeInitFlg)/*Init time so set flag that this is used*/
   {
      auiULEDeviceNum[ucDeviceNum-1]=1;
   }
   else
   {
      auiULEDeviceNum[ucDeviceNum-1]=0;
   }
  return IFX_SUCCESS;
#endif

   switch(eDeviceType)
   {
      case IFX_DECT_ULE_SENSOR:
      {
         pucDevicecount=&ucSensorCount;
         pucDeviceArrayptr = aucSensorDeviceNum;
         break;
      }
      case IFX_DECT_ULE_SLOWACTUATOR:
      {
         pucDevicecount=&ucSlowActCount;
         pucDeviceArrayptr = aucSlowActNum;
         break;
      }
      case IFX_DECT_ULE_FASTACTUATOR:
      {
         pucDevicecount=&ucFastActCount;
         pucDeviceArrayptr = aucFastActNum;
         break;
      }
      default:
      {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "Please chk something wrong;Device number cannot exist without Device type" );
         return IFX_SUCCESS;
      }
   }
   if(ucDeviceNum == 1)
   {
      iIndex = 0;
      iPos=1;
   }
   else
   {
      iIndex = (ucDeviceNum -1)/8;
      if((ucDeviceNum % 8) == 0)
      {
         iPos=8;
      }
      else
      {
         iPos= (ucDeviceNum % 8);
      }
   }

   if(ucFreeInitFlg) /*Set flag because it is during Init*/
   {
      ucMask = (ucMask << (iPos-1));
      pucDeviceArrayptr[iIndex]=(pucDeviceArrayptr[iIndex] | (ucMask));
      *pucDevicecount+=1;
   }
   else /*Free the device number*/
   {
      ucMask =~ (ucMask << (iPos-1));
      pucDeviceArrayptr[iIndex]=(pucDeviceArrayptr[iIndex] & (ucMask));
      *pucDevicecount-=1;
   }

  return IFX_SUCCESS;
}
e_IFX_Return IFX_DECT_ULE_SetDeviceType(IN uchar8 ucInstanceId, IN e_IFX_DECT_ULE_Type eDeviceType)
{
   x_IFX_DECT_IPC_Msg xIpcMsg={0};
   //x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
      if(ucInstanceId >= IFX_DECT_ULE_OFFSET && ucInstanceId < (IFX_DECT_ULE_OFFSET + IFX_DECT_MAX_ULE_DEVICES))
     {
        int iDeviceNum=0;
        //pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];

        if((xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].ucDeviceNo) /* &&  \
           (xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].eULEType != IFX_DECT_ULE_NONE)*/)
        {
           IFX_DECT_ULE_Free_Init_DeviceNum(xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].ucDeviceNo, \
                xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].eULEType,0);
        }
        xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].eULEType = eDeviceType;

        if((iDeviceNum = IFX_DECT_ULE_AllocDeviceNum(eDeviceType)) < 0 )
        {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "ULE device number allocation failed.... Chk did it exceed the limit (88) of particular type??" );
               return IFX_FAILURE;
        }
        else
        {
           xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].ucDeviceNo = ((uchar8)iDeviceNum);
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "\nAllocated ULE device Number= ",iDeviceNum);

            xIpcMsg.ucMsgId = FP_ULE_DEVICE_TYPE_UPDATE_RQ; //FP_ULE_TEMP_SUB_UPDATE_RQ
            xIpcMsg.ucPara1 = ucInstanceId;
            xIpcMsg.ucPara2 = eDeviceType;
            xIpcMsg.ucPara3 = (uchar8)iDeviceNum;
            IFX_DECT_MsgRt_PostToStack(IFX_IPC_DECT_C_PLANE,&xIpcMsg);
#if 0
/*This is not required as per New HF Interworking document*/
            /*Now the device type and Device number is available so send SRQ-Other msg and stack has to include
             paging descr information in this msg. SBB TBD: Accept or Reject for this other msg is not handled as not required */
            if(pxCallInfo->eCallState == IFX_DECT_ULE_CPLANE_CONNECTED)
            {
               IFX_DECT_ULE_Encode_SRQ_SRA_SRJ_Send(ucInstanceId,
               /*FP_SERVICE_CHANGE_IN_CC*/FP_CC_SERVICE_CHANGE_RQ,IFX_DECT_ULE_OTHER);
            }
#endif

        }
     }

  return IFX_SUCCESS;
}

EXPORT uint8 * GetULESubscriptionInfoPtr(uint8 portableNo)
{
   #ifdef KLOCWORK
   return ((uint8 *)&xULE_Data.xULESubscData.xRegList[portableNo]);
   #else
   return ((uint8 *)&xULE_Data.xULESubscData.xRegList[portableNo-IFX_DECT_ULE_OFFSET]);
   #endif
}

EXPORT uint8 * GetULEConfigPtr(void)
{
   return ((uint8 *)&xULE_Data.xULEConfig);
}

#ifdef SMART_HOME_DEMO

e_IFX_Return IFX_DECT_ULE_Check_HAN_FUN_Reg(IN uchar8 ucInstanceId, IN uchar8 *pucRegMsg, OUT uchar8 *pucRegRsp)
{
   x_IFX_DECT_ULE_CallInfo *pxCallInfo=NULL;
#if 0
   uchar8 aucSmokeReg[]= {0x7f,0xff,0x00,0x00,0x00,0x00,/*0-5=6 bytes Network:*/
                          0x00,0x00,/*6-7=2 bytes Transport*/
                          0x00,0x02,0x80,0x01,0x00,0x01,0x00,0x05,/*8-15=8bytes App*/
                          0x01,0x03,0x01,0x02,0x04 /*Data payload last 2 bytes device type*/};


   uchar8 aucMotionReg[]= {0x7f,0xff,0x00,0x00,0x00,0x00,/*0-5=6 bytes Network:*/
                           0x00,0x00,/*6-7=2 bytes Transport*/
                           0x00,0x02,0x80,0x01,0x00,0x01,0x00,0x05,/*8-15=8bytes App, last byte length of data=5*/
                           0x01,0x03,0x01,0x02,0x03 /* 5 bytes Data payload last 2 bytes device type*/};
/*For Smart Plug:7f ff 00 00 00 00 00 00 00 02 80 01 01 00 0e 81 05 22 22 22 22 22 0f eb 01 03 01 01 06*/

   uchar8 aucRegRsp[]= {0x00,0x00,0x00,0x00,0x00,0x00,/*0-5=6 bytes Network:index 3,4 device address*/
                        0x00,0x00,/*6-7=2 bytes Transport*/
                        0x00,0x03,0x80,0x01,0x00,0x01,0x00,0x03,/*8-15=8bytes App,last byte length of data=3*/
                        0x00,0x00,0x00 /*3 bytes Data payload last 2 bytes(index 17,18) device address by FP*/};

#endif
/*
   Registration MSG
7F FF 00 00 00 00 00 00 00 02 80 01 01 00 0E 81 05 00 23 43 55 00 0F EB 01 03 01 02 04
(0,1)-Src Device (2 bytes)0x7FFF
(2)Src Unit(1Byte): 0x00
(3,4)Dst Device (2 bytes): 0x0000
(5)Dst Unit (1 Byte):0x00
(6,7)Transport(2 Bytes):0x0000
(8)Application Reference(1Byte):0x00
(9)Message Type (1 Byte):0x02                                  <-Command
(10,11)IF Type (1Bit)+IF ID (15Bits): 0x8001                       <-Server Device Management Interface
(12)IF Member (1Byte): 0x01                                     <-Register command
(13,14)Reserved (7Bits)+Data Len (9Bits): 0x000E                   <-14 Bytes payload
(15)Discriminator (1Bit)+Device Unique ID Type(7Bits): 0x81     <-DSPG sending EMC and the Device Unique ID Type is IPUI
(16)Device Unique ID Length (1Byte): 0x05                       <-IPUI Length is 5
(17-21)Device Unique ID(5Bytes): 0x0023435500                      <-IPUI (This changes per device)
(22,23)Discriminator (2Bytes):0x0FEB                               <-DSPG EMC
(24)Number of Unit Entries (1Byte): 0x01                        <-supporting 1 Unit Entry
(25)Unit #1 Entry Length (1Byte):0x03                           <-3 Bytes length (1 Byte for Unit 1+ 2bytes for Unit type are following)
(26)Unit #1 Unit Id(1Byte): 0x01                                <-Unit Id is 1
(27,28)Unit #1 Unit Type(2Bytes): 0x0204                            <-Smoke Detector (This changes per device Type)

   */
#if 0
   uchar8 aucSmokeReg[]= {0x7F, 0xFF, 0x00, 0x00, 0x00, 0x00, /*0 to 5:6 Bytes->NWK*/
                     0x00, 0x00, /*6 to 7: 2 Bytes Transport*/
                     0x00, 0x02, 0x80, 0x01, 0x01, 0x00, 0x0E, /*8 to 14 : 7 bytes App Hdr*/
                     0x81, 0x05, 0x00, 0x23, 0x43, 0x55, 0x00, 0x0F, 0xEB, 0x01, 0x03, 0x01, 0x02, 0x04}; /*15 to 28 : 14 Bytes App Data;Last 2 bytes >Device Type:Smoke Detctor*/

   uchar8 aucMotionReg[]= {0x7F, 0xFF, 0x00, 0x00, 0x00, 0x00, /*0 to 5:6 Bytes->NWK*/
                     0x00, 0x00, /*6 to 7: 2 Bytes Transport*/
                     0x00, 0x02, 0x80, 0x01, 0x01, 0x00, 0x0E, /*8 to 14 : 7 bytes App Hdr*/
                     0x81, 0x05, 0x00, 0x23, 0x43, 0x66, 0x00, 0x0F, 0xEB, 0x01, 0x03, 0x01, 0x02, 0x03}; /*15 to 28 : 14 Bytes App Data;Last 2 bytes >Device Type:Motion Detctor*/
#endif
/*
   REG RESPONSE MSG
00 00 00 00 01 00 00 00 00 03 80 01 01 00 03 00 00 01
(0,1)Src Device (2 bytes)0x0000
(2)Src Unit(1Byte): 0x00
(3,4)Dst Device (2 bytes): 0x0001                        <-This changes per device (Array index 3 and 4)
(5)Dst Unit (1 Byte):0x00
(6,7)Transport(2 Bytes):0x0000
(8)Application Reference(1Byte):0x00
(9)Message Type (1 Byte):0x03                           <-Command Response
(10,11)IF Type (1Bit)+IF ID (15Bits): 0x8001                <-Server Device Management Interface
(12)IF Member (1Byte): 0x01                              <-Register command
(13,14)Reserved (7Bits)+Data Len (9Bits): 0x0003            <-3 Bytes payload
(15)Response (1Byte): 0x00                               <-OK
(16,17)Discriminator (1Bit)+Device Address(15Bits):0x0001   <-not sending EMC and the Device Address is 1 (This changes per device; Array index 16 and 17)

*/

   uchar8 aucRegRsp[]= {0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x03, 0x80, 0x01, 0x01, 0x00, 0x03, 0x00, 0x00, 0x01 };


   IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                            "\nIFX_DECT_ULE_Check_HAN_FUN_Reg for PP= ",ucInstanceId);

   if(ucInstanceId >= IFX_DECT_ULE_OFFSET && ucInstanceId < (IFX_DECT_ULE_OFFSET + IFX_DECT_MAX_ULE_DEVICES))
     {
        int iDeviceNum=0;
        pxCallInfo=&xULE_Data.pxULECallInfo[ucInstanceId-IFX_DECT_ULE_OFFSET];
#if 0
            if(((memcmp(pucRegMsg,aucSmokeReg,sizeof(aucSmokeReg))) && (memcmp(pucRegMsg,aucMotionReg,sizeof(aucMotionReg)))))
#endif
            if(!(((pucRegMsg[28] == 0x04) && (pucRegMsg[12] == 0x01) && (pucRegMsg[22] == 0x0F) && (pucRegMsg[23] == 0xEB)) ||
                 ((pucRegMsg[28] == 0x03) && (pucRegMsg[12] == 0x01) && (pucRegMsg[22] == 0x0F) && (pucRegMsg[23] == 0xEB)) ||
                 ((pucRegMsg[28] == 0x06) && (pucRegMsg[12] == 0x01) && (pucRegMsg[22] == 0x0F) && (pucRegMsg[23] == 0xEB))
               ))
            {
               IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                            "\nIFX_DECT_ULE_Check_HAN_FUN_Reg returning failure for PP= ",ucInstanceId);
                  return IFX_FAILURE;
            }
            else
        {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "ULE HAN-FUN Registration Msg and Type is Sensor Smoke/Motion" );
         if(pucRegMsg[28] == 0x04)
         {
            xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].eULEType = IFX_DECT_ULE_SENSOR;
            iDeviceNum = 50; //IFX_DECT_ULE_AllocDeviceNum(IFX_DECT_ULE_SENSOR);
            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "ULE HAN-FUN Registration Msg and Type is DSPG Sensor Smoke" );
         }
         else if(pucRegMsg[28] == 0x03)
         {
            xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].eULEType = IFX_DECT_ULE_SENSOR;
            iDeviceNum = 51;//IFX_DECT_ULE_AllocDeviceNum(IFX_DECT_ULE_SENSOR);
            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "ULE HAN-FUN Registration Msg and Type is DSPG Sensor Motion" );
         }
         else if(pucRegMsg[28] == 0x06)
         {
            xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].eULEType = IFX_DECT_ULE_FASTACTUATOR;
            iDeviceNum = 52;//IFX_DECT_ULE_AllocDeviceNum(IFX_DECT_ULE_FASTACTUATOR);
            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "ULE HAN-FUN Registration Msg and Type is DSPG Smart Plug" );
         }
         else
         {
            IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "ULE HAN-FUN Registration Msg ?? UNKNOWN" );
                  return IFX_FAILURE;
         }
        }
#if 0
         if(xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].ucDeviceNo)
         {
            iDeviceNum = ((int) xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].ucDeviceNo);
         }
         else
         {
            if(!(memcmp(pucRegMsg,aucSmokeReg,sizeof(aucSmokeReg))))
            {
            iDeviceNum = 50;//IFX_DECT_ULE_AllocDeviceNum(IFX_DECT_ULE_SENSOR);
            }
            else /*Motion sensor*/
            {
            iDeviceNum = 51;//IFX_DECT_ULE_AllocDeviceNum(IFX_DECT_ULE_SENSOR);
            }

         }
#endif
        if(iDeviceNum < 0 )
        {
         IFX_DBGC(vcDECTTKModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                  "ULE device number allocation failed.... Chk did it exceed the limit (88) of particular type??" );
            return IFX_FAILURE;
        }
        else
        {
           xULE_Data.xULESubscData.xRegList[ucInstanceId-IFX_DECT_ULE_OFFSET].ucDeviceNo = ((uchar8)iDeviceNum);
            IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "\nAllocated ULE device Number= ",iDeviceNum);

        }
            if(pucRegRsp != NULL)
            {
               memcpy(pucRegRsp,aucRegRsp,sizeof(aucRegRsp));
               pucRegRsp[3]= ((iDeviceNum & 0xff00 ) >> 8);
               pucRegRsp[4]= (iDeviceNum & 0x00ff ) ;
               pucRegRsp[16]= ((iDeviceNum & 0xff00 ) >> 8);
               pucRegRsp[17]= (iDeviceNum & 0x00ff ) ;
            }
     }
     else
     {
         IFX_DBGA(vcDECTTKModId,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                            "\nIFX_DECT_ULE_Check_HAN_FUN_Reg did nothing for PP= ",ucInstanceId);
      }

  return IFX_SUCCESS;
}

#endif /*SMART_HOME_DEMO*/

#endif /*ULE_SUPPORT*/
