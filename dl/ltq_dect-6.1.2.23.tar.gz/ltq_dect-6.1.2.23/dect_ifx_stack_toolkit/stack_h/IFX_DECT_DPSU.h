/**************************************************************************
**   FILE NAME     : IFX_DECT_DPSU.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-11-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Data Service Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/

/*! \file IFX_DECT_DPSU.h
    \brief This file contains the Data Packet Service Unit (DPSU)  procedures.
                DPSU contains procedures for providing a framework to plug-in a variety 
                of IP protocols to provide DECT packet radio service. 
*/
/** \ingroup DECT_TOOLKIT_MODULES
    \defgroup DPSU_MODULE Data Packet Service Unit 
    \brief The Data Packet Service Unit manages all the call control needs
       with respect to data calls.  The DPSU implements the capability
       information from the handsets and uses this information to set
       up data calls.  The DPSU is  CAT iq 3.0 compliant.  
       The interface provided by the DPSU is 
       listed in the chapter on Toolkit API.  The examples chapter
       provides source code examples illustrating the usage of the DPSU
       interfaces.
*/
/* @{ */
/* @} */

#ifndef __IFX_DECT_DPSU_H__
#define __IFX_DECT_DPSU_H__

/** \ingroup DECT_TOOLKIT_API
    \defgroup DPSU_API Data Packet Service Unit 
    \brief This group contains the Data Packet Service Unit (DPSU) functions of
                 the DECT Toolkit.  It provides a set of procedures that can be
                 categorized as:\n
	       1> Signaling Procedure -- For establishment and release of data call\n
	       2> Data Transfer Procedure -- Content download such as wallpaper,
		     ring tones download etc. Protocols supported are HTTP, Full_HTTP,
                          SMTP, ODAP, POP3, RTP and SIP. A unique session is maintained 
                          for each protocol and six connections are supported per session.\n
                   3> SUOTA -- Software Update over the Air\n
                   The following terminologies are relevant for this group:\n
                   Session - A session is defined for a protocol.  For e.g a HTTP session
                                    includes all the applications that use the HTTP transport.\n
                   Call - A Call is an entity within a session.  For e.g a call within a HTTP
                                    session is setup by an application that uses the HTTP
                                    transport.\n
                   E.g A content download application uses a single HTTP session and call.
*/
/*@{*/
/*! \brief Enum for different protocol types. */

typedef enum{
  IFX_DECT_DPSU_HTTP = 0x01,/*!< HTTP Protocol*/
  IFX_DECT_DPSU_FULL_HTTP = 0x02,/*!< FULL HTTP */
  IFX_DECT_DPSU_SMTP = 0x04,/*!< SMTP */
  IFX_DECT_DPSU_ODAP = 0x08,/*!< ODAP */
  IFX_DECT_DPSU_POP3 = 0x10,/*!< Post Office Protocol 3 */
  IFX_DECT_DPSU_RTP = 0x20,/*!< Real Time Protocl*/
  IFX_DECT_DPSU_SIP = 0x40,/*!< Session Initiation Protocol*/
}e_IFX_DECT_DPSU_Protocol;

/* ****************************************************************************
 * Callback Functions
 * ****************************************************************************/

/*! \brief This callback function is used to inform the FT application of an 
                  outgoing data call request from the PT.  This callback function is 
                  invoked by the DECT TK when it receives a CC_SETUP request
                  from the DECT Protocol Stack indicating an outgoing data call
                  request from the PT.
                  The DECT TK fills the IE buffer with the IE's in the message
                   and sends the handle of the IE buffer to the FT application.
                   The FT application can use the parsing functions to decode the
                   IE buffer. 
	\param[in] uiCallHdl Call Handle of the call.  This is the handle used to 
                              uniquely identify a call within a session. There 
                              can be a maximum of six calls per session.
           \param[in] ucHandsetId Handset Identifier of call initiating PT.                  
	\param[in] uiIEHdl Information Element handle to the IE buffer.
           \param[out] pucRejectReason Reason if the call is rejected
	\param[out] puiPrivateData Reference to the private data area of the FT 
                                  application. DPSU shall maintain this handle and 
                                  pass it to the FT Application in all callback(s).
                                  The FT application shall fill in the address of the Private
                                  Data area.
    \return IFX_SUCCESS or IFX_FAILURE.
    \note    
    If IFX_FAILURE is returned, all the internal structures pertaining to the 
    Call Handle shall be freed and PT would be intimated about failure in setting 
    up an outgoing call. No further requests shall be valid on the call handle.\n
       
   If IFX_SUCCESS is returned, then the DECT TK assumes that request is successful. 
   However no data path will be established. FT application needs to call 
   IFX_DECT_DPSU_CallAccept to complete the call setup.
 */

typedef e_IFX_Return (*pfn_IFX_DECT_DPSU_CallInitiate)(IN uint32 uiCallHdl,
                                               IN uchar8 ucHandsetId,
                                               IN uint32 uiIEHdl,
                                               OUT uchar8 *pucRejectReason,
                                               OUT uint32 *puiPrivateData); 
                                                 


/*! \brief This callback function is used to inform the FT application that the data
                   from the PT is available to be sent to the IP network.  For e.g., the data
                   from the PT may be a GET request asking for some content to be 
                   downloaded.  
           \param[in] uiCallHdl Call Handle of the call.  This is the handle used to 
                              uniquely identify a call within a session.
	\param[in] pcData Pointer to the data sent by the PT 
	\param[in] iLen Length of data pointed by pcData.
	\param[in] uiPrivateData Reference to the private data handle of the
		FT application.
    \return IFX_SUCCESS or IFX_FAILURE.

    \note
	Return value of IFX_SUCCESS means that the data was successfully sent to 
          the IP network.  \n
                     
	Return value of IFX_FAILURE means that the data was not successfully sent
           to the IP network.  The DECT TK in this case, posts a release message to the 
           PT and terminates the call. 
*/

typedef e_IFX_Return (*pfn_IFX_DECT_DPSU_DataSendToIP)(IN uint32 uiCallHdl,
                                               IN char8 *pcData,
                                               IN int32 iLen,
                                               IN uint32 uiPrivateData);


/*! \brief This callback function is used to inform the FT application that the
                   call has been released at the PT.  The PT may release an answered 
                   call or reject an incoming call.  The DECT TK invokes this callback 
                   function when it receives a CC_RELEASE message from the 
                   DECT Protocol Stack. Upon return of the function, the call is
                   terminated.
    \param[in] uiCallHdl Call Handle of the call.  This is the handle used to 
                              uniquely identify a call within a session.
     \param[in] uiIEHdl Information Element handle to the IE buffer.
     \param[in] eReason Reason for the Call Release
    \param[in] uiPrivateData Reference to the private data handle of the
		FT application.
	\return IFX_SUCCESS or IFX_FAILURE.

*/
typedef e_IFX_Return (*pfn_IFX_DECT_DPSU_CallRelease)(IN uint32 uiCallHdl,
                                              IN uint32 uiIEHdl,
                                              IN e_IFX_DECT_RelType eReason,
                                              IN uint32 uiPrivateData);


/*! \brief Structure containing pointers to the various callback functions to the application. 
                The callback functions listed in the structure need to be implemented within 
                the FT application and registered with the DECT TK.
*/
typedef struct
{
    pfn_IFX_DECT_DPSU_CallInitiate      pfnCallInitiate; /*!< Callback for notifying an incoming data call from the PT */
    pfn_IFX_DECT_DPSU_DataSendToIP      pfnDataSendToIP; /*!< Callback for notifying the availability of the data to be sent to the IP network */
    pfn_IFX_DECT_DPSU_CallRelease       pfnCallRelease;  /*!< Callback for notifying the call being released by the PT */
                                            
}x_IFX_DECT_DPSU_CallBks;



/*! \brief This function is used to inform the PT that an outgoing data call
           initiated by the PT has been accepted by the FT application.
           The FT application responds to the CC_SETUP request issued
           by the PT by invoking this function.  This function helps to send 
           a CC_CONNECT message to the PT.
    \param[in] uiCallHdl Call Handle of the call.  This is the handle used to 
                              uniquely identify a call within a session.
    \param[in] uiIEHdl Information Element handle to the IE buffer.
    \return IFX_SUCCESS or IFX_FAILURE.
    \note
	If IFX_SUCCESS is returned, the CC_CONNECT message is posted successfully to
	DECT stack and data channel is established between FT and PT and the data 
	transfer can happen.\n

    If IFX_FAILURE is returned, failure is returned to FT application and
	data call between FT and PT is terminated.\n
		
*/    

e_IFX_Return IFX_DECT_DPSU_CallAccept(IN uint32 uiCallHdl,
                                      IN uint32 uiIEHdl);
                                                


/*! \brief This function is used to inform the PT  that the data
                   from the IP server is available to be sent to it.  For e.g., the data
                   from the IP server may be a  response to an earlier GET request
                   asking for some content to be downloaded.  
           \param[in] uiCallHdl Call Handle of the call.  This is the handle used to 
                              uniquely identify a call within a session.
	\param[in] pcData Pointer to the data sent by the PT 
	\param[in] iLen Length of data pointed by pcData.
    \return IFX_SUCCESS or IFX_FAILURE.
    \note
	If IFX_SUCCESS is returned, the data transfer to the DECT domain is 
	successful and it is subsequently encoded and posted to DECT
	stack to be sent to PT.\n

    If IFX_FAILURE is returned, the data could not be transferred and the
	data call between FT and PT is terminated. No data is transmitted in this 
	case.\n
		
*/
#ifndef LTQ_RAW_DPSU
e_IFX_Return IFX_DECT_DPSU_DataSendToDECT(IN uint32 uiCallHdl, 
                                             IN char8 *pcData, 
                                             IN int32 iLen, IN int32 iAppDataLen);
#else
e_IFX_Return IFX_DECT_DPSU_DataSendToDECT(IN uint32 uiCallHdl, 
                                             IN char8 *pcData, 
                                             IN int32 iLen);
#endif
                                             
                                           

                                                  
/*! \brief This function is used to close data call from the FT application.
                   The FT application may choose to release the call upon detection of
                   a failure.
           \param[in] uiCallHdl Call Handle of the call.  This is the handle used to 
                              uniquely identify a call within a session.       
            \param[in] uiIEHdl Information Element handle to the IE buffer.
            \param[in] eReason Reason for the Call Release
    \return IFX_SUCCESS or IFX_FAILURE.
    \note
	If IFX_SUCCESS is returned, data call between FT and PT is successfully
	terminated.

	If IFX_FAILURE is returned, failure is returned to FT application and
	data call could not be terminated. It is upto the PT to terminate the call.
*/

e_IFX_Return IFX_DECT_DPSU_CallRelease(IN uint32 uiCallHdl,
                                       IN uint32 uiIEHdl,
                                       IN e_IFX_DECT_RelType eReason);


/*! \brief Registers the Protocol and Call back functions.
    \param[in] ucProtocolID is the protocol Identifier.
    \param[in] pxCallBks are the call control call back functions.
    \note Functions that are not being registered should be set to NULL.
    This API should be usually called for creating the instance.
    Subsequent calls to this API would result in overwriting the previously
    registered functions with the new functions.
*/

e_IFX_Return IFX_DECT_DPSU_RegisterDataApp(IN uchar8 ucProtocolID,
                                           IN x_IFX_DECT_DPSU_CallBks *pxCallBks);

/*! \brief This function is used to cleanup the connection information of a handset.
    \param[in] ucHandsetId  Handset Id
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return
IFX_DECT_DPSU_CleanUpConnectionResources(IN uchar8 ucHandsetId);

/*! \brief This function is used to check whether the handset has any data call running.
    \param[in] ucHandSetId  Handset Id
	    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return
IFX_DECT_DPSU_IsCallExisting(IN uchar8 ucHandSetId);

/* @} */
#endif /*__IFX_DECT_DPSU_H__*/


