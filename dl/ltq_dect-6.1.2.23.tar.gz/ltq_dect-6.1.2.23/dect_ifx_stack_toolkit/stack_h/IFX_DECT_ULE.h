/**************************************************************************
**   FILE NAME     : IFX_DECT_ULE.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 03-04-2013
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT ULE Transport Layer
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_ULE.h
    \brief This file contains the DECT ULE Transport  Unit (ULE) 
				Procedures.  The ULE Transport Unit is a collection of 
				procedures that provide support registration and exchange of
				data transparently between the FT application and the ULE
				device.  
*/

/** \ingroup DECT_TOOLKIT_MODULES
       \defgroup ULE_MODULE ULE Transport Unit
       \brief The ULE Transport Unit is a collection of procedures that 
				provide support registration and exchange of data 
				transparently between the FT application and the ULE device.  
				The procedures implemented within the ULE transport are 
				complaint to ETSI TS 102 939-1.
*/
/* @{ */
/* @} */

#ifndef __IFX_DECT_ULE_H__
#define __IFX_DECT_ULE_H__
#include "IFX_DECT_Stack.h"
#ifdef ULE_SUPPORT

/** \ingroup DECT_TOOLKIT_API
    \defgroup ULE_API ULE Transport Unit
    \brief This group contains the ULE Transport Unit (ULE) functions 
            of the DECT Toolkit.  It provides a set of procedures:\n
     1> For registration of the ULE clients with the FP \n
     2> For exchange of application data over the Control channel\n
     3> For exchange of application data over the Bearer channel \n
   */
/* @{ */


/*! \def IFX_DECT_MAX_ULE_DEVICES
    \brief Macro that specifies the maximum number of ULE Devices that Base/FP supports.
*/
#ifdef CONFIG_REPEATER_SUPPORT
#define IFX_DECT_MAX_ULE_DEVICES 192
#else
#define IFX_DECT_MAX_ULE_DEVICES 200
#endif

/*! \def IFX_ULE_CIPHER_KEY_SIZE
    \brief Macro that specifies the Cipher Key Size
*/
#define IFX_ULE_CIPHER_KEY_SIZE 16

/*! \def IFX_DECT_MU_PageAll 
    \brief Macro that makes reuse of CAT-iq TK API to Page ALL Attached devices.
*/
#define IFX_DECT_MU_PageAll IFX_DECT_MU_PageAllHandsets


/*! \def IFX_DECT_MU_PagePP 
    \brief Macro that makes reuse of CAT-iq TK API to Page a particular Attached device.
*/
#define IFX_DECT_MU_PagePP IFX_DECT_MU_PageHandset


/*! \def IFX_DECT_MU_StopPagingPP 
    \brief Macro that makes reuse of CAT-iq TK API to stop Paging a particular Attached device.
*/
#define IFX_DECT_MU_StopPagingPP IFX_DECT_MU_StopPagingHandset

/*! \def IFX_DECT_ULE_HF_MAX_NUM_PROTO 
    \brief Macro that defines max number of HF prtocol supported
*/
#define IFX_DECT_ULE_HF_MAX_NUM_PROTO 1



/*! \enum e_IFX_DECT_ULE_Type
    \brief Enum describing the run time configuration parameters.
 */
typedef enum {
 IFX_DECT_ULE_NONE=0,/*!< No Device type*/
 IFX_DECT_ULE_SENSOR=1, /*!< SENSOR ULE Device type*/
 IFX_DECT_ULE_SLOWACTUATOR=2, /*!< Slow Actuator ULE Device type*/
 IFX_DECT_ULE_FASTACTUATOR=3 /*!< Fast Actuator ULE Device type*/
} e_IFX_DECT_ULE_Type;


/*! \enum e_IFX_DECT_ULE_NWK_States
    \brief Enum describing the Network state of Registered PPs.
 */
typedef enum {
 IFX_DECT_ULE_NWKSUSPEND=0,/*!< Network state is SUSPEND*/
 IFX_DECT_ULE_NWKRESUME=1, /*!< Network state is RESUME*/
} e_IFX_DECT_ULE_NWK_States;



/*! \enum e_IFX_DECT_ULE_Release_Reason 
    \brief Enum describing ULE data connection release reason.
 */
typedef enum {
 IFX_DECT_ULE_NORMAL=1,/*!< Normal Release*/
 IFX_DECT_ULE_FP_BUSY=0x0A,/*!< Base station is busy*/	
 IFX_DECT_ULE_WRONG_PMID=0x0D,/*!< Unacceptible/unregistered PMID*/	
 IFX_DECT_ULE_LCE_PAGE_MODE=0x0F,/*!< Stay in LCE Paging detection mode*/	
 IFX_DECT_ULE_SWITCH_TO_CIRCUIT_MODE=0x10,/*!< Switch to circuit mode*/	
 IFX_DECT_ULE_HIGHER_PAGE_MODE=0x11,/*!< Switch to circuit mode*/	
 IFX_DECT_ULE_SETUP_AGAIN=0x12, /*!< Setup again after n frames*/
 IFX_DECT_ULE_NO_CONNECTION=0x14, /*!< No such connection/Virtual circuit */
} e_IFX_DECT_ULE_Release_Reason;



/*! \enum e_IFX_DECT_ULE_EVENTS
    \brief Enum describing the ULE Events that are notified to Application.
 */
typedef enum {
 IFX_DECT_ULE_DEVICE_ATTACHED=1, /*!< ULE Device is attached */
 IFX_DECT_ULE_DEVICE_CPLANE_CONNECTED=2, /*!< ULE Device  has established  C-Plane*/
 IFX_DECT_ULE_DEVICE_CPLANE_DISCONNECTED=3, /*!< ULE Device has disconnected  C-Plane */
 IFX_DECT_ULE_DATA_SENT_SUCCESS=4, /*!< ULE SDU DATA sent successfully */
 IFX_DECT_ULE_DATA_SENT_FAIL=5, /*!< ULE SDU DATA sent failed */
 IFX_DECT_ULE_UPDATE_SUBS_INFO=6, /*!< ULE subscription info update*/
 IFX_DECT_ULE_BPAGE_SUCCESS=7,/*!< ULE Paging using B-Field success*/
 IFX_DECT_ULE_BPAGE_FAIL=8,/*!< ULE Paging using B-Field failed*/
 IFX_DECT_ULE_DATA_SENT_FAIL_TIMEOUT=9, /*!< ULE SDU DATA sent failed due to time out*/
 IFX_DECT_ULE_BPAGE_FAIL_TIMEOUT=10,/*!< ULE Paging using B-Field failed due to time out*/
 IFX_DECT_ULE_EXP_DATACON_CONNECTED=11,/*!< ULE Expedited connection established notification*/
 IFX_DECT_ULE_DEVICE_PVC_CONNECTED=12, /*!< ULE Device  has RESUMED PVC and Application can send and recieve Data*/
 IFX_DECT_ULE_DEVICE_PVC_DISCONNECTED=13, /*!< ULE Device  has SUSPENDED PVC  or NO PVC and Application cannot send and recieve Data*/
 IFX_DECT_ULE_HF_ATTRIBUTES=14, /*!< Event to indicate the HF Attributes details*/
} e_IFX_DECT_ULE_EVENTS;


/*! \enum e_IFX_DECT_ULE_ERRORS
    \brief Enum describing the ULE Errors that are notified to Application when Application
	\ calls function IFX_DECT_ULE_GetLastError().
 */
typedef enum {
 IFX_DECT_ULE_INVALID_INSTANCE=1, /*!< Invalid ULE Device instance */
 IFX_DECT_ULE_PP_NOT_ATTACHED=2, /*!< ULE Device not attached */
 IFX_DECT_ULE_DATASEND_PENDING=3, /*!< Previous Data send is still pending */
 IFX_DECT_ULE_CB_NOT_REGISTERED=4, /*!< ULE Call Back functions (all or may be some) not registered */
 IFX_DECT_ULE_VC_DISCONNECTED=5, /*!< ULE Virtual connection is disconnected */
 IFX_DECT_ULE_SUBSCR_DATA_NOT_PASSED=6, /*!< ULE subsiscription data is not passed */
 IFX_DECT_ULE_POSTTOSTACK_FIFO_FAILED=7, /*!< ULE FIFO write failed while posting message to stack */
 IFX_DECT_ULE_SYSTEM_MALLOC_FAILED=8, /*!< MALLOC system call failed */
 IFX_DECT_ULE_NOT_INITED=9, /*!< ULE NOT Initialized */
 IFX_DECT_ULE_PP_NOT_NWK_RESUME=10, /*!< ULE Device not in IFX_DECT_ULE_NWK_RESUME */ 
} e_IFX_DECT_ULE_ERRORS;



/*!
    \brief Structure describing the ULE configuration data for various ULE devices.
*/
typedef struct
{
    uint32 uiSensorPageCycle; /*!< Paging cycles for Sensors type devices */
    uint32 uiStart_MFN_Sensor; /*!< MFN for Sensors type devices */
    uint8 ucStart_FCNT_Sensor;/*!< FCNT for Sensors type devices */
    uint8 ucActiveChnlSensor;/*!< Active Channel used for paging Sensors type devices */

    uint32 uiSlowActuatorPageCycle; /*!< Paging cycles for Slow Actuators type devices */
 	uint32 uiStart_MFN_SlowAct;/*!< MFN for Slow Actuators type devices */
  	uint8 ucStart_FCNT_SlowAct;/*!< FCNT for Slow Actuators type devices */
   	uint8 ucActiveChnlSlowAct;/*!< Active Channel used for paging Slow Actuators type devices */

    uint32 uiFastActuatorPageCycle; /*!< Paging cycles for Fast Actuators type devices */
	uint32 uiStart_MFN_FastAct;/*!< MFN for  Fast Actuators type devices */
    uint8 ucStart_FCNT_FastAct;/*!< FCNT for Fast Actuators type devices */
    uint8 ucActiveChnlFastAct;/*!< Active Channel used for paging Fast Actuators type devices */

    uint32 uiStayAliveCycle; /*!< Stay Alive cycles for all ULE devices */
    uint32 uiSDUSize; /*!< Max SDU size supported by FP */
    uchar8 ucWindowSize; /*!< Max Window size supported by FP for LU14/LU13 Data packets*/
} x_IFX_DECT_ULE_Config; 


/*!
    \brief Structure containing previous Subscription/Registration Information.	  
 */

typedef struct
{

  uchar8  cstatus;              /*!< ULE client registration  status */
  uchar8  acipui_array[IFX_DECT_IPUI_SIZE]; /*!< ULE client IPUI number */ 
  uchar8  actpui_array[IFX_DECT_TPUI_SIZE]; /*!< ULE client TPUI number */
  uchar8  acuak_array[IFX_DECT_AUTH_KEY_SIZE];    /*!< ULE client authentication key*/
  uchar8  acdck_array[IFX_ULE_CIPHER_KEY_SIZE];/*!< ULE client Cipher key */
  uchar8  cservice_class;/*!< Service class */
  uchar8  cmodel_id;/*!< ULE client model ID */
  uint32  uiTermCap; /*!< Terminal Capabilities */
  uchar8  Last_SSN[6]; /*!< Last ULE sent packet sequence number */ 
  uchar8  Last_RSN[6]; /*!< Last ULE received packet sequence number */ 
	e_IFX_DECT_ULE_Type	  eULEType;              /*!< ULE device type */
	uint32 uiSDUSize; /*!< Max SDU size supported by FP which is negotiated if negotiation is supported*/
	uchar8 ucWindowSize; /*!< Max Window size supported by FP for LU14/LU13 Data packets which is negotiated if negotiation is supported */
	e_IFX_DECT_ULE_NWK_States  eNWKState;/*!< ULE Network state; Either RESUME (1) or SUSPEND (0) */
	uchar8 ucDeviceNo;/*!< Unique Device number allocated within each Device Type */
	uint16 uiEMC; /*!< EMC value of the PT*/
}x_IFX_DECT_ULE_SubscInfo;

/*!
    \brief Structure describing the subscription details of ULE devices.
*/
typedef struct
{
	uint16 unNoOfReg; /*!< Count of previously registered ULE devices*/
	x_IFX_DECT_ULE_SubscInfo xRegList[IFX_DECT_MAX_ULE_DEVICES]; /*!< Previously registered ULE device information*/
} x_IFX_DECT_ULE_SubscData; 

/*!
    \brief Structure to hold ULE device ID and IPUI which is needed for the API IFX_DECT_ULE_GetPVCConnectedDevices().
*/
typedef struct
{
	uchar8  ucDeviceId;/*!< ULE device ID which is used to send and receive*/
	uchar8  acipui_array[IFX_DECT_IPUI_SIZE]; /*!< ULE client IPUI number */	
} x_IFX_DECT_ULE_Device_IPUI;


/*!
    \brief Structure describing the DECT ULE HF Version Info.
*/

typedef	struct
{
	uchar8 ucProtoID; /*!< HF Protocol Identifier*/
	uchar8 ucProtoVer; /*!< HF Protocol Version*/
	uchar8 ucCoreVer; /*!< HF Protocol CORE Version*/
	uchar8 ucProfVer; /*!< HF Protocol Profile Version*/
	uchar8 ucInterfaceVer; /*!< HF Protocol Interface Version*/
	uint32 uiEMC;/*!< HF Protocol EMC if proprietery information is used*/
}x_IFX_DECT_ULE_HF_Ver;


/*!
    \brief Structure describing the HF Attributes Information.
*/
typedef struct
{
	uint32 uiMaxSDU_P2F;/*!< Max SDU size from PP to FP*/
	uint32 uiMaxSDU_F2P;/*!< Max SDU size from FP to PP*/
	uchar8 ucNumOfProtoInfo;/*!< Number of Protocol Information supported*/
	x_IFX_DECT_ULE_HF_Ver  axHFVer[IFX_DECT_ULE_HF_MAX_NUM_PROTO];/*!< Structure describing the DECT ULE HF Version Info*/
} x_IFX_DECT_ULE_HF_Attributes; 


/*!
    \brief union describing the ULE Notify data for various ULE devices.
*/

typedef union{
	x_IFX_DECT_ULE_SubscInfo xSubscInfo;/*!< Subscription Info*/
	x_IFX_DECT_ULE_HF_Attributes xHFAttr;/*!< HF Attributes*/
	uchar8  acipui_array[IFX_DECT_IPUI_SIZE]; /*!< ULE client IPUI number */
}ux_IFX_ULE_Notify;

/*!
    \brief Structure describing ULE notification Events to Application.
*/
typedef struct
{
    e_IFX_DECT_ULE_EVENTS eEvent; /*!< Event Type */
		ux_IFX_ULE_Notify uxNotify;		/*!< ULE Notify data */
} x_IFX_DECT_ULE_NotifyEvent; 

/* ****************************************************************************
 * Functions
 * ****************************************************************************/

/*! \brief  This function is used to Reset ULE PVC if incase the Application 
				relaizes that data received is corrupted.
				The application will get notification when PVC again CONNECTED
				using registered call back function pfn_IFX_DECT_ULE_Notify and event 
				IFX_DECT_ULE_DEVICE_PVC_CONNECTED. Only after this application can again
				send/recieve any ULE data			
        \param[in] ucInstanceId ULE Instance Identifier
        \return IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_ULE_ResetPVC(IN uchar8 ucInstanceId);

/*! \brief  This function is used to get the RFPI of the DECT base
        \param[out] pucRfpi Pointer to array of size (5 bytes) IFX_DECT_MAX_RFPI_LEN 
        \return VOID 
*/

void IFX_DECT_GetRFPI(OUT uchar8 *pucRfpi);

/*! \brief  This function is used to get the list of ULE devices that are in PVC CONNECTED 
				state. 
        \param[out] pucNumDevices Pointer to a unsigned char byte where total number of devices 
							that are in CONNECTED state are updated.
        \param[out] paxDevices Pointer to an array of structure x_IFX_DECT_ULE_Device_IPUI where
							DeviecId and IPUI of ULE devices that are in connected state are updated. 
        \return VOID
*/

void IFX_DECT_ULE_GetPVCConnectedDevices(OUT uchar8 *pucNumDevices, OUT x_IFX_DECT_ULE_Device_IPUI *paxDevices);

/*! \brief  This function is used to configure HANFUN protocol attributes
        \param[in] pxHFAttr pointer to the Attribute structure 
        \return IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_ULE_ConfigureHF_Attributes(x_IFX_DECT_ULE_HF_Attributes *pxHFAttr);


/*! \brief  This function is used to send the application data to the ULE device.  
                   This function shall be invoked by the FT application as it prepares
                   to pass the data received from the HAN application to the ULE device. 
                   The data is handled in a transparent manner within this function.
				   The data is sent to the ULE device over the bearer channel (B-Channel).
				   This API has to be used only for those ULE devices which are in attached 
					& PVC CONNECTED state and this is informed to application using registered call 
				   back function pfn_IFX_DECT_ULE_Notify and event IFX_DECT_ULE_DEVICE_PVC_CONNECTED.
					Eventhough the function returns Success the application should wait for send 
					status event like IFX_DECT_ULE_DATA_SENT_SUCCESS/IFX_DECT_ULE_DATA_SENT_FAIL/
					IFX_DECT_ULE_DATA_SENT_FAIL_TIMEOUT etc via pfn_IFX_DECT_ULE_Notify before
					sending next data.
        \param[in] ucInstanceId ULE Instance Identifier
        \param[in] unSize Size of the data
        \param[in] pData Pointer to the data buffer
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ULE_DataSend(IN uchar8 ucInstanceId,
                                   IN uint16 unSize, 
								   IN void* pData);



/*! \brief  This function is used to set ULE Device type after parsing HANFUN protocol
        \param[in] ucInstanceId ULE Instance Identifier
        \param[in] eDeviceType ULE device type 
        \return IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_ULE_SetDeviceType(IN uchar8 ucInstanceId, IN e_IFX_DECT_ULE_Type eDeviceType);

/*! \brief  This function is used to get  error number and error description whenever
	\ a particular ULE API fails.
        \param[out] pcErrorDescription Pointer to Error description buffer 
        \return Error number One of the values from e_IFX_DECT_ULE_ERRORS
*/

int32 IFX_DECT_ULE_GetLastError(OUT const char8 *pcErrorDescription);

/*! \brief  This function is used by the application to release the expediated ULE connection
				which is setup by ULE PP to send ULE application data. The application after decoding/analyzing
				the data can decide to close if does not have to send any response back to PP. Or even application 
				can request PP to set-up connection after certain timeout if required by setting up a valid reason
				in the eReason parameter.
        \param[in] ucInstanceId ULE Instance Identifier
        \param[in] eReason Reason to release the expediated connection 
        \param[in] ucInfofield Info related to Reason 
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ULE_ReleaseExpConnection(IN uchar8 ucInstanceId,
				   IN   e_IFX_DECT_ULE_Release_Reason eReason, IN uchar8 ucInfofield);


/*! \brief  This function is used to send the application data to the ULE device.  
                   This function shall be invoked by the FT application as it prepares
                   to pass the data received from the HAN application to the ULE device. 
                   The data is handled in a transparent manner within this function.
				   The data is sent to the ULE device over the signaling channel (Cs channel).
				   This API has to be used only for those ULE devices which have already established 
				   C-Plane virtual connection and this is informed to application using registered 
				   call back function pfn_IFX_DECT_ULE_Notify and event IFX_DECT_ULE_DEVICE_CPLANE_CONNECTED.
        \param[in] ucInstanceId ULE Instance Identifier
        \param[in] unSize Size of the data
        \param[in] pData Pointer to the data buffer
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ULE_MsgSend(IN uchar8 ucInstanceId,
                                   IN uint16 unSize, 
								   IN void* pData);


/*! \brief  This function is used to Configure parameters within the ULE TL or the stack. 
                   This function shall be invoked by the FT application as and when
				   user configures any ULE related parameters such as paging cycles
				   for various ULE devices etc.The configured parameters will be used
				   by underlying DECT stack.
        \param[in] pxULEConfig Pointer to the  x_IFX_DECT_ULE_Config structure
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ULE_InfoConfigure(IN x_IFX_DECT_ULE_Config *pxULEConfig);
	

/* ****************************************************************************
 * Callback Functions
 * ****************************************************************************/

/*! \brief 
		This Callback function is used by the ULE transport unit to provide 
		   notifications to the FT Application.  The events may pertain to the ULE 
		   devices or occurences within the stack/toolkit at the FT.  The FT
		   Application shall use the received notifications to initiate further
		   actions either with the HAN application or with the DECT toolkit.
		   
    \param[in] ucInstanceId ULE Instance Identifier
	\param[in] pxULENotify Pointer to the Event Notification Structure
    \return IFX_SUCCESS / IFX_FAILURE.
*/
typedef e_IFX_Return (*pfn_IFX_DECT_ULE_Notify)(IN uchar8 ucInstanceId,
                                                IN x_IFX_DECT_ULE_NotifyEvent *pxULENotify);
													  
 
/*! \brief 
		This Callback function is used by the ULE transport unit to pass the data
		   received from the ULE device to the FT Application.  Upon receiving 
		   the data, the FT application may pass the data to the HAN application.
		   The data is handled in a transparent manner within this function.
		   The data is received from the ULE device over the Bearer channel.
			Some times depedning on special cases the Expedited connection 
			is established without any data from PP. In this case this CB
			function is called with unSize=0. 
			Whenever this call back function 
			is called application has to close this connection using API
			IFX_DECT_ULE_ReleaseExpConnection and also need to handle
			the data if present.
	
		   
    \param[in] ucInstanceId ULE Instance Identifier
	\param[in] unSize Size of the data
    \param[in] pData Pointer to the data buffer
	\return IFX_SUCCESS / IFX_FAILURE.
*/
typedef e_IFX_Return (*pfn_IFX_DECT_ULE_DataRecv)(IN uchar8 ucInstanceId,
                                                  IN uint16 unSize,
												  IN void* pData);


/*! \brief 
		This Callback function is used by the ULE transport unit to pass the data
		   received from the ULE device to the FT Application.  Upon receiving 
		   the data, the FT application may pass the data to the HAN application.
		   The data is handled in a transparent manner within this function.
		   The data is received from the ULE device over the Signaling channel.
		   
    \param[in] ucInstanceId ULE Instance Identifier
	\param[in] unSize Size of the data
    \param[in] pData Pointer to the data buffer
	\return IFX_SUCCESS / IFX_FAILURE.
*/
typedef e_IFX_Return (*pfn_IFX_DECT_ULE_MsgRecv)(IN uchar8 ucInstanceId,
                                                  IN uint16 unSize,
												  IN void* pData);												  

/*!
    \brief Structure containing callback functions for ULE related procedures.
The callback functions listed in the structure need to be implemented within 
the FT application and registered with the DECT TK.
*/
typedef struct {
 pfn_IFX_DECT_ULE_Notify 		pfnULENotify; /*!< Callback for notifying events from the TL to the ULE Agent*/
 pfn_IFX_DECT_ULE_DataRecv 		pfnULEDataRecv; /*!< Callback to Provide B-field data from client, to the ULE Agent*/
 pfn_IFX_DECT_ULE_MsgRecv  		pfnULEMsgRecv;/*!< Callback to Provide C-field data from client, to the ULE Agent*/
} x_IFX_DECT_ULE_CallBks;


											  

/*! \brief  This function is used to initialize the ULE Transport Unit of the
				   DECT Toolkit.  This function shall be invoked by the FT 
				   application after it has received the confirmation from the 
				   Toolkit that the Toolkit and the Stack initialization has been
				   successful.  
        \param[in] unMaxULEDevSupported Max ULE devices supported
        \param[in] pxULEConfig Pointer to ULE config data structure
        \param[in] pxULESubscData Pointer to Subscription Data of registered ULE Devices
        \param[in] pxULECallBks) Pointer to Callback functions structure that are to be registered
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ULE_Init(IN uint16 unMaxULEDevSupported, 
							   IN x_IFX_DECT_ULE_Config *pxULEConfig,
                               IN x_IFX_DECT_ULE_SubscData *pxULESubscData, 
							   IN x_IFX_DECT_ULE_CallBks *pxULECallBks); 
 

/* @} */
#endif /*ULE_SUPPORT*/
#endif /* __IFX_DECT_ULE_H__*/
                      

