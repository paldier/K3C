/**************************************************************************
**   FILE NAME     : IFX_DECT_DIAG.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 15-05-2009
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_DIAG.h
    \brief This file contains the Modem Diagnostic Procedures.  
                The diagnostic procedures for the cosic modem include the following:\n
                1> Soft Reset of the modem\n
                2> Setting and Getting of BMC parameters on the fly\n
                3> Setting and Getting of Oscillator Trimming, GFSK parameters on the fly\n
                4> DECT Country setting on the fly\n
                5> Access to XRAM areas on the fly\n
                6> RF Mode setting on the fly\n
				7> TBR06 Test execution\n
				8> Temperature Power Compensation
*/

/** \ingroup DECT_TOOLKIT_MODULES
       \defgroup DIAG_MODULE Modem Diagnostics
       \brief The Diagnostics Unit is a collection of procedures that provide
                modem diagnostic functions to the FT application.  The diagnostic 
                procedures for the cosic modem include the following:\n
                1> Soft Reset of the modem\n
                2> Setting and Getting of BMC parameters on the fly\n
                3> Setting and Getting of Oscillator Trimming, GFSK parameters on the fly\n
                4> DECT Country setting on the fly\n
                5> Access to XRAM areas on the fly\n
                6> RF Mode setting on the fly\n
				7> TBR06 Test execution\n
				8> Temperature Power Compensation
*/
/* @{ */
/* @} */

#ifndef __IFX_DECT_DIAG_H__
#define __IFX_DECT_DIAG_H__

/** \ingroup DECT_TOOLKIT_API
    \defgroup DIAG_API Modem Diagnostics 
    \brief This group contains the Modem Diagnostics (DIAG) functions 
            of the DECT Toolkit.  It provides a set of procedures:\n
                1> Soft Reset of the modem\n
                2> Setting and Getting of BMC parameters on the fly\n
                3> Setting and Getting of Oscillator Trimming, GFSK parameters on the fly\n
                4> DECT Country setting on the fly\n
                5> Access to XRAM areas on the fly\n
                6> RF Mode setting on the fly\n
				7> TBR06 Test execution\n
				8> Temperature Power Compensation
   */
/* @{ */


/*! \def IFX_DECT_DIAG_ENABLE
    \brief Macro that specifies the enable value for the diagnostic mode.
 */
#define IFX_DECT_DIAG_ENABLE     1 /*!< Enable value for the diagnostic mode */

/*! \def IFX_DECT_DIAG_DISABLE
    \brief Macro that specifies the disable value for the diagnostic mode.
 */
#define IFX_DECT_DIAG_DISABLE     0 /*!< Disable value for the diagnostic mode */

/*! \def IFX_DECT_DIAG_P10_ON
    \brief Macro that specifies the ON value for the P1.0 GPIO PIN.
 */
#define IFX_DECT_DIAG_P10_ON     0x01 /*!< P1.0 PIN On */

/*! \def IFX_DECT_DIAG_P10_OFF
    \brief Macro that specifies the OFF value for the P1.0 GPIO PIN.
 */
#define IFX_DECT_DIAG_P10_OFF     0x11 /*!< P1.0 PIN Off */

/*! \def IFX_DECT_DIAG_TBR06_ACTIVATE
    \brief Macro that specifies the value to activate the TBR06 Mode.
 */
#define IFX_DECT_DIAG_TBR06_ACTIVATE     1 /*!< Activate value for the TBR06 mode */

/*! \def IFX_DECT_DIAG_TBR06_DEACTIVATE
    \brief Macro that specifies the value to deactivate the TBR06 Mode.
 */
#define IFX_DECT_DIAG_TBR06_DEACTIVATE     1 /*!< Deactivate value for the TBR06 mode */



/* ****************************************************************************
 * Diagnostic Functions
 * ****************************************************************************/
 
/*! \brief  This function is used to put the modem in the diagnostic operation mode.
                    This function needs to be called by the FT application before other
                    diagnostics functions are invoked.  This diagnostic mode is more relevant
                    for the DECT TK than the modem.  In the diagnostic mode, the DECT TK 
                    disables operations involving other service units.  The function needs to
                    called with a disable value to put the DECT TK in the normal operation
                    mode.
        \param[in] ucFlag Flag to enable/disable diagnostic mode.  
                           One of IFX_DECT_DIAG_DISABLE/IFX_DECT_DIAG_ENABLE
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_ModemDiagnostics(IN uchar8 ucFlag); 
 
/*! \brief  This function is used to reset the cosic modem and download the BMC, RFPI
                    TBR6 Mode, Oscillator trimming and DECT country settings when the modem
                    restarts.  Often this is the first step in the modem diagnostic procedure.
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_ModemRestart(void);

/* ****************************************************************************
 * Set Functions
 * ****************************************************************************/

/*! \brief  This function is used to set the RFPI value at the modem.  The supplied
                   value is cached within the DECT TK and applied when the modem restarts.
                   The IFX_DECT_DIAG_ModemRestart function needs to be called 
                   subsequently by the FT application to apply the values.
        \param[in] pcRFPI RFPI string of 5 bytes.  
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_RFPISet(IN char8 * pcRFPI);

/*! \brief  This function is used to set the Frequency Offset values at the modem.  
                   The frequency offset values determine the DECT Country settings.
                   The supplied values are cached within the DECT TK and 
                   applied when the modem restarts. The IFX_DECT_DIAG_ModemRestart 
                   function needs to be called subsequently by the FT application to apply
                   the values.
        \param[in] ucFreqTx Frequency Offset 1
        \param[in] ucFreqRx Frequency Offset 2
        \param[in] ucFreqRange Frequency Offset 3
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_FreqOffSet(IN uchar8 ucFreqTx,
                                      IN uchar8 ucFreqRx,
                                      IN uchar8 ucFreqRange);

/*! \brief  This function is used to set the BMC values at the modem.  
                   The supplied value is cached within the DECT TK and 
                   applied when the modem restarts. The IFX_DECT_DIAG_ModemRestart 
                   function needs to be called subsequently by the FT application to apply
                   the values.
        \param[in] pxBMC BMC Parameters
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_BmcSet(IN x_IFX_DECT_BMCRegParams * pxBMC);
          
/*! \brief  This function is used to put the modem in the TBR06 testing mode.
                    This function sets the activation/deactivation value within the toolkit.
                    The IFX_DECT_DIAG_ModemRestart function needs to be called
                    subsequently by the FT application is put the modem in the TBR 06 test
                    mode.
        \param[in] ucFlag Flag to activate/deactivate TBR 06 Test mode.  
                           One of IFX_DECT_DIAG_TBR06_ACTIVATE/IFX_DECT_DIAG_TBR06_DEACTIVATE
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_TBR06Mode(IN uchar8 ucFlag); 

/*! \def IFX_DECT_DIAG_XRAMSet
    \brief Macro that sets the XRAM values at the modem.
 */
#define IFX_DECT_DIAG_XRAMSet(a,b,c) IFX_DECT_DIAG_MEMSet(1,a,b,c)

/*! \brief  This function is used to set the XRAM values at the modem.  The
                   XRAM values are sent to the modem immediately.  
        \param[in] ucMemType Type of memory
		\param[in] uiAddr XRAM Address
        \param[in] pcBuffer Buffer of max 40 bytes
        \param[in] ucLength_Maccess Length of bytes to be written
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_MEMSet( IN uchar8 ucMemType,
                                   IN uint16 uiAddr,
                                   IN char8 *pcBuffer,
								   IN uchar8 ucLength_Maccess);
                                         
/*! \brief  This function is used to set the Oscillator Trimming values at the modem.  
                   In addition this function is also used to turn on/off the oscillator trimming
                   mode at the modem.  The Oscillator trimming values are sent to the modem
                   immediately.
        \param[in] uiOscTrimValue Oscillator Trimming Value containing both Hi and Low Bytes
        \param[in] ucP10Status Status of the P1.0 GPIO PIN.
                           One of IFX_DECT_DIAG_P10_OFF / IFX_DECT_DIAG_P10_ON
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_OscTrimSet(IN uint16 uiOscTrimValue,
                                      IN uchar8 ucP10Status);



/*! \brief  This function is used to set the GFSK values at the modem.  The GFSK
                    values are sent to the modem immediately.
        \param[in] unGfskValue GFSK Value containing both Hi and Low Bytes
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_GfskSet(IN uint16 unGfskValue);


                   
/*! \brief  This function is used to set the RF Test Mode values at the modem.  
                    The RF Test Mode values are sent to the modem immediately.
        \param[in] ucRFMode RF Test Mode
        \param[in] ucChannelNumber Channel Number
        \param[in] ucSlotNumber Slot Number
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_RfTestModeSet(IN uchar8 ucRFMode,
                                         IN uchar8 ucChannelNumber,
                                         IN uchar8 ucSlotNumber);  

										 
/*! \brief  This function is used to set the TPC  values at the modem.  
            The TPC Test Mode values are applied when the modem restarts.The IFX_DECT_DIAG_ModemRestart 
            function needs to be called subsequently by the FT application to apply the values.
        \param[in] *pxTCPParams Transmit power parameters.
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_TPCSet(IN x_IFX_DECT_TransmitPowerParam *pxTCPParams);
/* ****************************************************************************
 * Get Functions
 * ****************************************************************************/

/*! \brief  This function is used to get the BMC values from the modem.  This is a blocking
                   function.  This function blocks till the BMC register values are obtained from
                   the modem over the SPI interface.
        \param[out] pxBMC BMC Parameters
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_BmcGet(OUT x_IFX_DECT_BMCRegParams * pxBMC);

/*! \brief  This function is used to get the XRAM values from the modem.  This is a blocking
                   function.  This function blocks till the XRAM values are obtained from
                   the modem over the SPI interface.
        \param[in] ucMemType Type of memory
        \param[in] uiAddr XRAM Address
        \param[out] pcBuffer Buffer of 40 bytes
        \param[in] ucLength_Maccess Length of bytes to be read
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_MEMGet(IN uchar8 ucMemType,
                                  IN uint16 uiAddr,
                                   OUT char8 * pcBuffer,
								   IN uchar8 ucLength_Maccess);
/*! \def IFX_DECT_DIAG_XRAMGet
    \brief Macro that gets the XRAM values from the modem.
 */
#define IFX_DECT_DIAG_XRAMGet(a,b,c) IFX_DECT_DIAG_MEMGet(1,a,b,c)

/*! \brief  This function is used to get the TPC values from the modem.  
                    This is a blocking function.  This function blocks till the TPC
                    values are obtained from the modem over the SPI interface.
        \param[out] pxTCPParams Transmit power parameters.
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_TPCGet(OUT x_IFX_DECT_TransmitPowerParam *pxTCPParams);

/*! \brief  This function is used to get the Country Settings values from the modem. This is
          a blocking function. This function blocks till the Country Settings values are
          obtained from the modem over the SPI interface.
    \param[out] pucFreqTx Transmit Frequency
	\param[out] pucFreqRx Receive Frequency
	\param[out] pucFreqRan Frequency Range
    \return IFX_SUCCESS / IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_DIAG_FreqOffGet(OUT uchar8 *pucFreqTx,
                                      OUT uchar8 *pucFreqRx,
                                      OUT uchar8 *pucFreqRan);

/*! \brief  This function is used to get the RF Test Mode values from the modem.  
                    This is a blocking function.  This function blocks till the RF Mode
                    values are obtained from the modem over the SPI interface.
        \param[out] pucRFMode RF Test Mode
        \param[out] pucChannelNumber Channel Number
        \param[out] pucSlotNumber Slot Number
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_RfTestModeGet(OUT uchar8 *pucRFMode,
                                         OUT uchar8 *pucChannelNumber,
                                         OUT uchar8 *pucSlotNumber);

 /*! \brief  This function is used to get the GFSK values from the modem. This is
            a blocking function. This function blocks till the GFSK values are 
			obtained from the modem over the SPI interface.
    \param[out] punGfskValue GFSK Value containing both Hi and Low Bytes.
    \return IFX_SUCCESS / IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_DIAG_GfskGet(OUT uint16 *punGfskValue);

/*! \brief  This function is used to get the Osc Trim values from the modem. This is
            a blocking function. This function blocks till the Osc Trim values are 
			obtained from the modem over the SPI interface.
    \param[out] punOscTrimValue GFSK Value containing both Hi and Low Bytes.
    \return IFX_SUCCESS / IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_DIAG_OscTrimGet(OUT uint16 *punOscTrimValue);


/*! \brief  This function is used to turn the Rf on/off.
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_DIAG_RfCtrl(void);

/* @} */
#endif /* __IFX_DECT_DIAG_H__*/
                      

