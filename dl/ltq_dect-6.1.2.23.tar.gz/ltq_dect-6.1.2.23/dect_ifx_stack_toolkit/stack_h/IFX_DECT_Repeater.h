/**************************************************************************
**   FILE NAME     : IFX_DECT_Repeater.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 21-03-2016
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Repeater support
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Intel;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_Repeater.h
    \brief This file contains the DECT Repeater  Unit (RU) 
				Procedures.  The RU is a collection of 
				procedures that provide support registration and exchange of
				subscription data between the FT application and the Repeater
				device.  
*/

/** \ingroup DECT_TOOLKIT_MODULES
       \defgroup REPEATER_MODULE Unit
       \brief The Repeater Unit is a collection of procedures that 
				provide support registration and exchange of subscription data 
			       between the FT application and the Repeater device.  
				
*/
/* @{ */
/* @} */


#ifndef __IFX_DECT_REPEATER_H__
#define __IFX_DECT_REPEATER_H__
//#define  CONFIG_REPEATER_SUPPORT
#ifdef CONFIG_REPEATER_SUPPORT

#include "IFX_DECT_Stack.h"


/*! \def IFX_DECT_MAX_REPEATERS
    \brief Macro that specifies the maximum number of Repeater Devices that Base/FP supports.
*/
#define IFX_DECT_MAX_REPEATERS 5


/*! \def IFX_DECT_MAX_INSTANCES_PER_REPEATERS
    \brief Macro that specifies the maximum number of Instances per Repeater Device that Base/FP supports.
*/
#define IFX_DECT_MAX_INSTANCES_PER_REPEATERS 6



/*! \enum e_IFX_DECT_REPEATER_EVENTS
    \brief Enum describing the Repeater Events that are notified to Application.
 */
typedef enum {
 IFX_DECT_REPEATER_DEVICE_ATTACHED=1, /*!< Repeater Device registered and attached */
 IFX_DECT_REPEATER_DEVICE_UNREGISTERED=2, /*!< Repeater Device unregistered */ 
} e_IFX_DECT_REPEATER_EVENTS;



/*!
    \brief union describing the Repeater Notify data for various Repeater devices.
*/

typedef union{
	x_IFX_DECT_SubscInfo xSubscInfo[IFX_DECT_MAX_INSTANCES_PER_REPEATERS];/*!< Subscription Info of 6 instances of one Repeater*/
}ux_IFX_Repeater_Notify;

/*!
    \brief Structure describing Repeater notification Events to Application.
*/
typedef struct
{
    e_IFX_DECT_REPEATER_EVENTS eEvent; /*!<Repeater Event Type */
	ux_IFX_Repeater_Notify uxNotify;		/*!< Repeater Notify data */
} x_IFX_DECT_Repeater_NotifyEvent; 


/* ****************************************************************************
 * Callback Functions
 * ****************************************************************************/

/*! \brief 
		This Callback function is used by the DECT Repeater unit to provide 
		   notifications to the FT Application.  The events pertain to the Repeater 
		   devices or occurences within the stack/toolkit at the FT.  The FT
		   Application shall use the received notifications to initiate further
		   actions.
		   
    \param[in] ucInstanceId Repeater Instance Identifier
	\param[in] pxRepeaterNotify Pointer to the Event Notification Structure
    \return IFX_SUCCESS / IFX_FAILURE.
*/
typedef e_IFX_Return (*pfn_IFX_DECT_Repeater_Notify)(IN uchar8 ucInstanceId,
                                                IN x_IFX_DECT_Repeater_NotifyEvent *pxRepeaterNotify);


/*!
    \brief Structure containing callback functions for Repeater related procedures.
The callback functions listed in the structure need to be implemented within 
the FT application and registered with the DECT TK.
*/
typedef struct {
 pfn_IFX_DECT_Repeater_Notify 		pfnRepeaterNotify; /*!< Callback for notifying events from the TK to the FT Agent*/ 
} x_IFX_DECT_Repeater_CallBks;

/*! \brief  This function is used to initialize the Repeater Unit of the
				   DECT Toolkit.  This function shall be invoked by the FT 
				   application after it has received the confirmation from the 
				   Toolkit that the Toolkit and the Stack initialization has been
				   successful.  
        \param[in] unMaxRepeaterSupported  Max repeater devices supported
         \param[in] unMaxInstancesPerRepeater Max instances per repeater device    
        \param[in] pxRepeaterSubscData Pointer to Subscription Data of all registered Repeaters 
        \param[in] pxRepeaterCallBks Pointer to Callback functions structure that are to be registered
        \return IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_Repeater_Init(IN uint16 unMaxRepeaterSupported, 
									IN uint16 unMaxInstancesPerRepeater,
                               IN x_IFX_DECT_SubscInfo *pxRepeaterSubscData,
							   IN x_IFX_DECT_Repeater_CallBks *pxRepeaterCallBks);

#endif
#endif




