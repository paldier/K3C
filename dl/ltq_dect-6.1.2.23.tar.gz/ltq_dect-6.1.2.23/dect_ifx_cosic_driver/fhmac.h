/******************************************************************************

                              Copyright (c) 2009
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/
/*
 * Interface file for DECT Stack and TK
 */

#ifndef _INC_FHMAC
#define _INC_FHMAC

/* =======================================================================
 * Include Files
 * ======================================================================= */

/* =======================================================================
 * External Reference
 * ======================================================================= */

/* =======================================================================
 * Definitions
 * ======================================================================= */
// Maximum number of logical links
#define MAX_LINK 6
   
// Maximum number of MAC connections
#define MAX_MCEI MAX_LINK

// Messages definitions
/*   Process   */
#define LMAC  0
/*   Messages  */
#define LMAC_DUMMY_SEND_REQ        (0x80 + 0)
#define LMAC_MCEI_REQUEST_RES      (0x80 + 1)
#define LMAC_TB_RELEASE_REQ        (0x80 + 2)
#define LMAC_CO_DATA_REQ           (0x80 + 3)
#define LMAC_HO_SWITCH_TO_TB_REQ   (0x80 + 4)
#define LMAC_PAGE_REQ              (0x80 + 5)
#define LMAC_PAGE_CANCEL_REQ       (0x80 + 6)
#define LMAC_PAGE_DONE_REQ         (0x80 + 7)
#define LMAC_ULE_PAGE_REQ          (0x80 + 8) 
#define LMAC_VOICE_EXTERNAL_REQ    (0x80 + 9)
#define LMAC_VOICE_INTERNAL_REQ    (0x80 + 10)
#define LMAC_VOICE_CONFERENCE_REQ  (0x80 + 11)
#define LMAC_ENC_KEY_REQ           (0x80 + 12)
#define LMAC_DEFAULT_CK_SET_REQ    (0x80 + 13)
#define LMAC_MOD_REQ               (0x80 + 14)
#define LMAC_A44_SET_REQ           (0x80 + 15)
#define LMAC_TBR6_MODE_REQ         (0x80 + 16)
#define LMAC_BOOT_REQ              (0x80 + 17)
#define LMAC_PARAMETER_PRELOAD_REQ (0x80 + 18)
#define LMAC_OSC_SET_REQ           (0x80 + 19)
#define LMAC_GFSK_SET_REQ          (0x80 + 20)
#define LMAC_OSC_GET_REQ           (0x80 + 21)
#define LMAC_GFSK_GET_REQ          (0x80 + 22)
#define LMAC_FW_VERSION_REQ        (0x80 + 23)
#define LMAC_QT_SET_REQ            (0x80 + 24)
#define LMAC_ULE_FU10_GFA_REQ      (0x80 + 25)
#define LMAC_ULE_FU10_REL_REQ      (0x80 + 26)
#define LMAC_ULE_FU10_RDY_REL_REQ  (0x80 + 27)
#define LMAC_ULE_FU10_DATA_REQ     (0x80 + 28)
#define LMAC_SET_MODE_ON_REQ       (0x80 + 29)
#define LMAC_MODULE_RESET_REQ      (0x80 + 30)
#define LMAC_RF_TEST_MODE_SET_REQ  (0x80 + 31)
#define LMAC_NOEMO_REQ             (0x80 + 32)
//#ifdef CONFIG_REPEATER_SUPPORT
#define LMAC_REP_ACCESS_REQ        (0x80 + 33)
#define LMAC_REP_CO_DATA_REQ       (0x80 + 34)
//#endif

/*   Process   */
#define HMAC  1
/*   States    */
#define HMAC_IDLE  0
/*   Messages  */
#define MAC_SEND_DUMMY_RQ_ME  0
#define LMAC_MCEI_REQUEST_IND  1
#define MAC_DIS_RQ_LC  2
#define MAC_CO_DATA_RQ_LC  3
#define LMAC_TB_RELEASE_IND  4
#define LMAC_TB_ESTABLISHE_IND  5
#define LMAC_CO_DATA_IND  6
#define LMAC_CO_DTR_IND  7
#define MAC_PAGE_RQ_LB  8
#define LMAC_BS_INFO_SEND_IND  9
#define MAC_PAGE_CANCEL_LB  10
#define MAC_ENABLE_VOICE_EXTERNAL_SWI  11
#define MAC_DISABLE_VOICE_EXTERNAL_SWI  12
#define MAC_ENABLE_VOICE_INTERNAL_SWI  13
#define MAC_DISABLE_VOICE_INTERNAL_SWI  14
#define MAC_ENABLE_VOICE_CONFERENCE_SWI  15
#define MAC_DISABLE_VOICE_CONFERENCE_SWI  16
#define MAC_ENC_KEY_RQ_LC  17
#define LMAC_ENC_EKS_IND_SUCCEED  18
#define LMAC_ENC_EKS_IND_FAIL  19
#define MAC_SLOTTYPE_MOD_RQ_SWI  20
#define LMAC_MOD_CFM  21
#define MAC_A44_SET_RQ_ME  22
#define MAC_TBR6_MODE_RQ_ME  23
#define MAC_BOOT_RQ_ME  24
#define MAC_PARAMETER_PRELOAD_RQ_ME  25
#define MAC_OSC_SET_RQ_ME  26
#define MAC_GFSK_SET_RQ_ME  27
#define LMAC_OSC_GET_CFM  28
#define LMAC_GFSK_GET_CFM  29
#define MAC_FW_VERSION_IND_LMAC  30
#define LMAC_BOOT_IND  31		// insert initial command for dect stack
#define MAC_STATUS_CHECK  32		// hiryu_20070911 check to stack status 
#define MAC_INIT_CMD	 33
#define MAC_SOFT_RESET_RQ_LMAC  34
#define MAC_HARD_RESET_RQ_LMAC  35
#define LMAC_DEBUG_MESSAGE_IND  36
#define LMAC_MOD_IND  37
#define MAC_FU10_DATA_RQ  38    // LU10 -> HMAC -> LMAC(SSC) -> Cosic
#define MAC_FU10_DATA_IN  39    // Cosic -> LMAC(SSC) -> HMAC -> LU10
#define MAC_NOEMO_RQ_ME  40
#define LMAC_NOEMO_IND  41
#define MAC_QT_SET_RQ_ME  42
#define MAC_DEFAULT_CK_SET_REQ  43
#define LMAC_DEBUGMSG_IND  50
#define HMAC_ULE_FU10_ACC_IND  51
#define HMAC_ULE_FU10_ACC_RDY_REL_IND  52
#define HMAC_ULE_FU10_RDY_REL_REQ  53
#define HMAC_ULE_FU10_RDY_REL_IND  54
#define HMAC_ULE_FU10_DATA_REQ  55
#define HMAC_ULE_FU10_DATA_IND  56
#define HMAC_ULE_FU10_GFA_REQ  57
#define HMAC_ULE_FU10_GFA_IND  58
#define HMAC_ULE_FU10_REL_REQ  59
#define HMAC_ULE_FU10_REL_IND  60
#define HMAC_ULE_FU10_DTR_IND  61
#define HMAC_ULE_FU10_LINK_REL_IND  62
#define HMAC_ULE_FU10_OTHER_IND  63
#define MAC_ULE_PAGE_LB  64
#define MAC_ULE_PAGE_STOP_LB  65
//#ifdef CONFIG_REPEATER_SUPPORT
#define MAC_REP_ACCESS_REQ    66
//#endif

#define LMAC_ULE_FU10_ACC_IND          0x52  // LMAC(SSC) -> HMAC
#define LMAC_ULE_FU10_ACC_RDY_REL_IND  0x53  // LMAC(SSC) -> HMAC
#define LMAC_ULE_FU10_GFA_IND          0x54  // LMAC(SSC) -> HMAC
#define LMAC_ULE_FU10_RDY_REL_IND      0x55  // LMAC(SSC) -> HMAC
#define MAC_ULE_FU10_RDY_REL2_IN_LMAC  0x56  // LMAC(SSC) -> HMAC
#define LMAC_ULE_FU10_REL_IND          0x57  // LMAC(SSC) -> HMAC
#define LMAC_ULE_FU10_DATA_IND         0x58  // LMAC(SSC) -> HMAC
#define LMAC_ULE_FU10_DTR_IND          0x59  // LMAC(SSC) -> HMAC
#define LMAC_ULE_FU10_BE_REL_IND       0x5A  // LMAC(SSC) -> HMAC
#define LMAC_ULE_FU10_OTHER_IND        0x5B  // LMAC(SSC) -> HMAC

//#ifdef CONFIG_REPEATER_SUPPORT
#define  LMAC_REP_ACCESS_CFM           0x60
#define  LMAC_REP_CO_DATA_IND          0x61
#define  LMAC_REP_CO_DTR_IND           0x62
#define  MAC_REP_CO_DATA_RQ_LC         0x63
#define  MAC_CIPHER_CFM_ON             0x64
//#endif

/*   Process   */
#define ME  2
/*   States    */
#define DUMMY_STATE  0
/*   Messages  */
#define ME_SET_TO_DEFAULT_RQ_MEM  0
#define ME_RFP_PRELOAD_DIS  1
#define ME_A44_SET_RQ_DIS  2
#define ME_A44_CLEAR_RQ_DIS  3
#define ME_RANDOM_TIMER_EXPIRY  4
#define ME_SYSTEM_RESET  5
#define ME_MAC_NOEMO_RQ  6
#define ME_NOEMO_IN_MAC  7

/*   Process   */
#define LC  4
/*   States    */
#define CLOSED  0
#define OPEN  1
#define FREE  2
/*   Messages  */
#define LC_REL_RQ_NORMAL_LAP  0
#define LC_REL_RQ_ABNORMAL_LAP  1
#define LC_DIS_IN_MAC  2
#define LC_DIS_CFM_MAC  3
#define LC_CON_IN_MAC  4
#define LC_CO_DATA_DTR_MAC  5
#define LC_CO_DATA_IN_MAC  6
#define LC_CO_DATA_RQ_LAP  7
#define LC_DL_ENC_KEY_RQ_LAP  8
#define LC_ENC_EKS_IND_MAC  9
//#ifdef CONFIG_REPEATER_SUPPORT
#define LC_REP_ACCESS_REQ 10
#define LC_REP_ACCESS_CFM 11
#define LC_REP_CIPHER_CFM_ON 12
#define LC_REP_CIPHER_RQ 13
//#endif

//#ifdef CONFIG_REPEATER_SUPPORT
# define LAP_REP  10
# define LC_REP   11

// All messages are same as LAP or LC Processes
//#endif


/* Maximum Processes Number */
#define PROCMAX  12

/* The direct messages between APP and HMAC */
#define FP_DEBUG_MSG_IN_MAC_TO_APP  0xFC     // FOR DEBUG  MESSAGE TO APPLICATION 
#define FP_SLOTTYPE_MOD_IN_MAC_TO_APP  0xFD	// hiryu_20071220 insert command    hmac --> app direct send command 
#define STACK_INITAL_CMD  0xFE

// Maximum Size of G_PTR of HMAC Message
#ifdef ULE_SUPPORT
#define G_PTR_MAX_ULE_COUNT 38
#endif
#ifdef CATIQ_UPLANE
#define G_PTR_MAX_COUNT 64
#elif defined(ULE_SUPPORT)
#define G_PTR_MAX_COUNT (1 + G_PTR_MAX_ULE_COUNT)
#else
#define G_PTR_MAX_COUNT 10
#endif

// Maximum Size of G_PTR of Debug Information
#define G_PTR_MAX_DEBUG_COUNT	43 // 'ram indicator 1byte' + 'address 2byte' + 'data 40byte'

// DECT Driver Commands
#define DECT_DRV_TO_HMAC_MSG            0x01 // to HMBC
#define DECT_DRV_FROM_HMAC_MSG          0x02 // from HMBC
#define DECT_DRV_GET_PMID               0x03 // from HMBC
//#ifdef CONFIG_REPEATER_SUPPORT
#define DECT_DRV_GET_REP_PMID           0x20 // from HMBC
#define DECT_DRV_GET_REP_NUM            0x21 // from HMBC
//#endif
#define DECT_DRV_GET_ENC_STATE          0x04 // from HMBC
#define DECT_DRV_SET_KNL_STATE          0x05 // to HMBC
#define DECT_DRV_DEBUG_INFO             0x06 // To Cosic Modem debug infomation
#define DECT_DRV_DEBUG_INFO_FROM_MODULE 0x07 // To Cosic Modem debug infomation
#define DECT_DRV_TRIGGER_COSIC_DRV      0x08 // Activate cosic driver
#define DECT_DRV_SET_LOADER_MODE        0x09 // To Loader Mode
#define DECT_DRV_SET_APP_MODE           0x0A // To Normal working mode
#define DECT_DRV_SET_APP_MODE_CoC_RQ    0x0D // To Normal working CoC requeted by Modem mode
#define DECT_DRV_SET_APP_MODE_CoC_CNF   0x0E // To Normal working CoC confirmed by GW mode
#define DECT_DRV_FW_WRITE               0x0B // To write firmware
#define DECT_DRV_FW_READ                0x0C // To Read write confirmation
#define DECT_DRV_IRQ_CTRL               0x0F // To control IRQ
#define DECT_DRV_ENABLE                 0x10
#define DECT_DRV_SHUTDOWN               0x11 // to HMBC

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */
// Debug Information IDs
typedef enum {
   BMC_REGISTER_READ_REQ = 0x01,
   BMC_BEARER_READ_REQ,
   MEMORY_INFOMATION,
   PATCH_RAM_INFORMATION,
   DEBUG_MSSAGE_INFORMATION
} DEBUG_INFO_ID;

// BMC Register Packet Types
typedef enum {
   BMC_REGISTER = 0x10,
   OSC_TRIMMING_VAL,
   GFSK_VALUE,
   RF_TEST_MODE_SET,
   SPI_SETUP_PACKET,
   DEBUG_MESSAGE_ONOFF
} BMC_REGISTER_PACKET_TYPE;

typedef struct hmac_queues {
  unsigned char PROCID;
  unsigned char MSG;
  unsigned char Parameter1;
  unsigned char Parameter2;
  unsigned char Parameter3;
  unsigned char Parameter4;
  unsigned char G_PTR_buf[G_PTR_MAX_COUNT];
  unsigned char CurrentInc;
} HMAC_QUEUES;

typedef struct dect_module_debug_info {
  unsigned char debug_info_id;
  unsigned char rw_indicator;		// read write indicator
  unsigned char CurrentInc;			
  unsigned char G_PTR_buf[G_PTR_MAX_DEBUG_COUNT];
} DECT_MODULE_DEBUG_INFO;

/* =======================================================================
 * Global Variables
 * ======================================================================= */

/* =======================================================================
 * Global Function Prototypes
 * ======================================================================= */

#endif
