/******************************************************************************

                              Copyright (c) 2009
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/
/*****************************************************************************
*                                                                           *
*     Workfile   :  FMAC.PSL                                                *
*     Date       :  18 Nov, 2005                                       *
*     Contents   :  MAC.PSL - MEDIUM ACCESS LAYER FT SIDE                   *
*     Hardware   :  IFX 87xx                                               *
*                                                                           *
*****************************************************************************
*/

/* =======================================================================
 * Include Files
 * ======================================================================= */
#ifdef LINUX
#include <linux/string.h>
#include <linux/delay.h>
#include <linux/kernel.h>
#include <lantiq_irq.h> 
#include <linux/gpio.h>
#include <linux/of.h>
#include <linux/of_irq.h>
#include <linux/of_gpio.h>
#include <linux/platform_device.h>
#include <linux/of.h>
#include <linux/of_platform.h>
#include <linux/of_address.h>
#include <asm/cpu-info.h>
#endif
#ifdef CONFIG_SMP 
#include <asm/spinlock.h>
#endif

#include "fmbc.h"
#include "drv_dect.h"
#include "fdebug.h"


#ifdef CONFIG_SMP
extern spinlock_t IntEdgFlgLock;
#define CONFIG_SMP4
#ifdef CONFIG_SMP4
extern spinlock_t DECT_TAPI_Lock;
#endif
#endif
/* =======================================================================
 * External Reference
 * ======================================================================= */
#ifdef SUPERTASK
extern int iModemRestartCount;
#endif

/* =======================================================================
 * Definitions
 * ======================================================================= */
#ifdef ULE_SUPPORT
// For ULE Bu Channel
#define BU_A_DATA_SIZE 4
#define BU_B_DATA_SIZE 7
#define BU_DATA_SIZE (BU_A_DATA_SIZE + BU_B_DATA_SIZE)
#define BU_CHANNEL_DATA_COUNT 5
#endif

// Mt Attributes Slot Type
#define MT_ATTRIBUTES_SLOT_TYPE_FULL   0x00
#define MT_ATTRIBUTES_SLOT_TYPE_HALF   0x01
#define MT_ATTRIBUTES_SLOT_TYPE_DOUBLE 0x02
#define MT_ATTRIBUTES_SLOT_TYPE_LONG   0x03

// Advanced Connection 2 Release Reason
#define ADV2_REL_REASON_BS_BUSY 0x0A // base station busy

#define REP_DECT_TPUI_TYPE       0x33

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */
typedef enum {
   DUMMY_BEARER = 0,
   DUMMY_BEARER_2,
   TRAFFIC_BEARER,
   HANDOVER_BEARER,
   CO_HANDOVER_BEARER,
} BEARER_TYPE;

#ifdef ULE_SUPPORT
typedef struct {
   BYTE subfieldAInfo; // 7..6: SFa, 3..0: Index flags from X1 to X4
   BYTE subfieldBInfo; // 7..6: SFb, 5..0: Index flags from X5 to X10
   BYTE channelPeriodicity;
   WORD startFrameNumber;
   BYTE BuData[BU_DATA_SIZE];
} BuChannelData_t;
#endif

/* =======================================================================
 * Local Variables
 * ======================================================================= */
/* -----------------------------------------------------------------------
 * Name: LocalVar
 * Description:
 * ----------------------------------------------------------------------- */
/* tapi channel array */  
unsigned char Tapi_Channel_array[MAX_MCEI];
extern x_IFX_Mcei_Buffer xMceiBuffer[MAX_MCEI];
extern unsigned char KNL_STATE_OF_STACK[MAX_LINK];		/* check for mac layer     hiryu_20070911 */
extern unsigned int Max_spi_data_len_val;
extern int valid_voice_pkt[MAX_MCEI];
extern int iDriverStatus;
extern gw_dbg_stats gw_stats; 
unsigned char ucDECT_CoCMode=0;

#if 1  // LOW_DUTY_SUPPORT
unsigned char     LowDuty_Support = FALSE;
#endif
#ifdef ULE_SUPPORT
// Index : Channel Active
// [0]   : 0000b
// [1]   : 0001b
// [2]   : 0010b
// [3]   : 0100b
// [4]   : 1000b
static BuChannelData_t BuChannelDataArray[BU_CHANNEL_DATA_COUNT];
#endif

/* =======================================================================
 * Global Variables
 * ======================================================================= */

/* =======================================================================
 * Local Function Prototypes
 * ======================================================================= */

/* =======================================================================
 * Function Definitions
 * ======================================================================= */

void HMAC_INIT(void)
{
  #ifdef CONFIG_SMP4
      unsigned long flags4;
   #endif
   unsigned char i;
   Init_MBC();
   #ifdef ULE_SUPPORT
   ULE_Init_MBC();
   #endif
   Init_BsCh_Queue();
   
   /* mcei array initial */
   #if 0
   for(i=0;i<MAX_MCEI;i++)
     Tapi_Channel_array[i] = 0xff;
   #else

   #ifdef CONFIG_SMP4
      spin_lock_irqsave(&DECT_TAPI_Lock,flags4);
   #endif
   for(i=0;i<MAX_MCEI;i++)
    xMceiBuffer[i].iKpiChan = 0xff;

   #ifdef CONFIG_SMP4
      spin_unlock_irqrestore(&DECT_TAPI_Lock,flags4);
   #endif
   #endif
}

/*
**************************************************************************
*                                                                        *
*     Function :  MBC_Release_TBC                                        *
*                                                                        *
**************************************************************************
*                                                                        *
*     Purpose  :  Routine performs all necessary actions which have to   *
*                 be done when a TB of an MBC has been released.         *
*     Parms    :  mcei: identifies the MBC of the released TB            *
*                 lbn: identifies the TB which has been released         *
*     Returns  :  none                                                   *
*     Remarks  :                                                         *
*                                                                        *
**************************************************************************
*/
static void MBC_Release_TBC (BYTE mcei, BYTE lbn, BYTE b_type)
{
   #ifdef CONFIG_REPEATER_SUPPORT
   BYTE i, idx, rep_flag;
   #endif
   BYTE other_lbn;
   HMAC_QUEUES buffer;
   memset(&buffer, 0x00, sizeof(buffer));

   /* The actions to be performed      */
   /* depend on the MBC state.         */
   switch (Mcei_Table[mcei].Mbc_State)
   {
      /* The link was not established.    */
      case MBC_ST_CON_RQ:
         Init_Mcei_Table_Element(mcei);
         break;

      /* The link was established. Inform */
      /* the DLC.                         */
      #ifdef DECT_NG
      case MBC_ST_SM_INVOKING:
      #endif
      case MBC_ST_EST:
      Init_Mcei_Table_Element(mcei);
      buffer.PROCID = LC;
      buffer.MSG = LC_DIS_IN_MAC;
      buffer.CurrentInc= mcei;
      Dect_SendtoStack(&buffer);
      break;

      /* HO: one of the two TB's has been */
      /* released.                        */
      #ifdef DECT_NG
      case MBC_ST_CM_HO:
      {
         /* Confirm Slottype modification  */
         /* ---------------------------------*/
         /* P1: Logical Connection No (LCN)  */
         /* P2: MCEI                    */
         /* P3: Slot_type  ( 0x03: MT_ATTRIBUTES_SLOT_TYPE_LONG, 0x00:MT_ATTRIBUTES_SLOT_TYPE_FULL)                   */
         /* P4: success(1)/failure(0)             */
         // TODO: change plz....
         #if 0
         Send_Message_To_APP( FP_SLOTTYPE_MOD_IN_MAC, NULL, mcei , lbn, 0, Mcei_Table[mcei].wbs_req, TRUE  );
         #endif

         /* it is  special interface */
         /* hmac --> app    derect send command */
         buffer.PROCID = PROCMAX;
         buffer.MSG = FP_SLOTTYPE_MOD_IN_MAC_TO_APP;
         buffer.Parameter1 = mcei;
         buffer.Parameter3 = Mcei_Table[mcei].wbs_req; // slot type
         if (b_type == HANDOVER_BEARER) {
            buffer.Parameter4 = FALSE; // fail
         } else { 
            buffer.Parameter4 = TRUE; // success
         }

         buffer.CurrentInc= mcei;
         Dect_SendtoStack(&buffer);
         /* break; */
      }
      #endif
      case MBC_ST_HO:
         Detach_TBC_from_MBC(mcei, lbn);
         Mcei_Table[mcei].Mbc_State = MBC_ST_EST;
         /* Note: The remaining TB's type is */
         /* changed to TRAFFIC_BEARER and    */
         /* Ref_Lbn is cleared.              */
         /* This has to be protected since   */
         /* on ISR level a TB can be         */
         /* converted to a DB anytime.       */
         other_lbn = Get_Lbn_of_only_TB(mcei);

         #ifdef CONFIG_REPEATER_SUPPORT
         if (b_type == TRAFFIC_BEARER) {
            if (Mcei_Table[mcei].EncLbn == lbn) {
               Mcei_Table[mcei].EncLbn = other_lbn;
               #ifdef KLOCWORK
               if((other_lbn < MAX_LINK) && (lbn < MAX_LINK))
               #endif
               {
                  if (Rep_Table[other_lbn].Rep_Cntr < Rep_Table[lbn].Rep_Cntr) {
                     rep_flag = FALSE;
                     idx = Rep_Table[other_lbn].Rep_Cntr;
                     if ((Rep_Table[other_lbn].Pmid[idx-1][0] != 0x00) || (Rep_Table[other_lbn].Pmid[idx-1][1] != REP_DECT_TPUI_TYPE)) {
                        rep_flag = TRUE;
                     }
                     for (i = 0;  i < idx;  i++) {
                        if ((Rep_Table[lbn].Pmid[i][0] != Rep_Table[other_lbn].Pmid[i][0]) ||
                            (Rep_Table[lbn].Pmid[i][1] != Rep_Table[other_lbn].Pmid[i][1]) ||
                            (Rep_Table[lbn].Pmid[i][2] != Rep_Table[other_lbn].Pmid[i][2])) {
                           rep_flag = TRUE;
                        }
                     }

                     if (rep_flag == FALSE) {
                        memcpy(&Rep_Table[other_lbn], &Rep_Table[lbn], 3*MAX_REPEATERS_CASDADED+1);
                     }
                  }
               }
            }
            }

         if (b_type == HANDOVER_BEARER) {
            #ifdef KLOCWORK
            if(mcei < MAX_MCEI)
            #endif
            {
               if (Mcei_Table[mcei].EncLbn == lbn) {
                  Mcei_Table[mcei].EncLbn = NO_LBN;
                  buffer.PROCID = LC_REP;
                  buffer.MSG = LC_DIS_IN_MAC;
                  buffer.CurrentInc= mcei;
                  Dect_SendtoStack(&buffer);
               }
            }
         }
         #endif

         buffer.PROCID = LMAC;
         buffer.MSG = LMAC_HO_SWITCH_TO_TB_REQ;
         buffer.Parameter1 = other_lbn;
         buffer.Parameter2 = mcei;
         Dect_SendtoLMAC(&buffer);
         break;

      /* Local Release Request            */
      case MBC_ST_RELEASE_RQ:
         Detach_TBC_from_MBC (mcei, lbn);
         /* if the MBC has no LBN any more   */
         /* the MBC's release is complete    */
         if ( (Mcei_Table[mcei].lbn_1 == NO_LBN) && (Mcei_Table[mcei].lbn_2 == NO_LBN) )
         {
            Init_Mcei_Table_Element(mcei);
            buffer.PROCID = LC;
            buffer.MSG = LC_DIS_CFM_MAC;
            buffer.CurrentInc= mcei;
            Dect_SendtoStack(&buffer);
         }
         else
         {
           /* just wait for the other TB to be released */
         }
         break;

      #ifdef xxxULE_SUPPORT
      case MBC_ST_RESUME:
      case MBC_ST_SUSPEND:
         Init_Mcei_Table_Element(mcei);
         break;
      #endif

      default:
         break;
   }
}

#ifdef ULE_SUPPORT
BOOL isUsingPagingID(WORD pagingID, BuChannelData_t * channelDataPtr, BYTE * indexPtr)
{
   BYTE i;
   BYTE temp;
   WORD tempPagingID;

   // scan index type for subfield A
   if ((channelDataPtr->subfieldAInfo & 0xC0) == 0x80) { // if current SFa is index type
      if (pagingID < 127) { // if less than 127
         for (i = 0; i <= 2; i++) {
            if (channelDataPtr->subfieldAInfo & (0x08 >> i)) { // 1000b >> i; X1 -> X3
               /*
                  switch (i) {
                     case 0:
                        // tempPagingID = (WORD)(channelDataPtr->BuData[-1] & ~0xFF) << 8; // x = 0xFF << i, ~x
                        tempPagingID = 0;
                        // tempPagingID |= (channelDataPtr->BuData[0] & 0xFE); // x << 1
                        tempPagingID |= channelDataPtr->BuData[0];
                        tempPagingID >>= 1; // (i + 1)
                        break;
   
                     case 1:
                        tempPagingID = (WORD)(channelDataPtr->BuData[0] & ~0xFE) << 8; // x = 0xFF << i, ~x
                        // tempPagingID |= (channelDataPtr->BuData[1] & 0xFC); // x << 1
                        tempPagingID |= channelDataPtr->BuData[1];
                        tempPagingID >>= 2; // (i + 1)
                        break;
   
                     case 2:
                        tempPagingID = (WORD)(channelDataPtr->BuData[1] & ~0xFC) << 8; // x = 0xFF << i, ~x
                        // tempPagingID |= (channelDataPtr->BuData[2] & 0xF8); // x << 1
                        tempPagingID |= channelDataPtr->BuData[2];
                        tempPagingID >>= 3; // (i + 1)
                        break;
                  }
                */
               temp = 0xFF << i;
               if (i == 0) {
                  tempPagingID = 0;
               } else {
                  tempPagingID = (WORD)(channelDataPtr->BuData[i - 1] & ~temp) << 8;
               }
               tempPagingID |= channelDataPtr->BuData[i];
               tempPagingID >>= (i + 1);
   
               if (pagingID == tempPagingID) {
                  *indexPtr = i + 1; // return value for X1 ~ X3; 1 ~ 3
                  return YES;
               }
            }
         }
      }
   
      if (channelDataPtr->subfieldAInfo & 0x01) { // if not found and X4 is used
         tempPagingID = (WORD)(channelDataPtr->BuData[2] & ~0xF8) << 8;
         tempPagingID |= channelDataPtr->BuData[3];
         tempPagingID >>= 2;
   
         if (pagingID == tempPagingID) {
            *indexPtr = 4; // return value for X4; 4
            return YES;
         }
      }
   }
   
   // scan index type for subfield B
   if ((channelDataPtr->subfieldBInfo & 0xC0) == 0x80) { // if current SFb is index type
      for (i = 0; i <= 5; i++) {
         if (channelDataPtr->subfieldBInfo & (0x20 >> i)) { // 100000b >> i; X5 -> X10
            /*
               switch (i) {
                  case 0:
                     tempPagingID = (WORD)(channelDataPtr->BuData[4] & 0xFF) << 8; // x = 0xFF >> i
                     // tempPagingID |= (channelDataPtr->BuData[5] & ~0x7F); // x >>= 1, ~x
                     tempPagingID |= channelDataPtr->BuData[5];
                     tempPagingID >>= 7; // (7 - i)
                     break;
   
                  case 1:
                     tempPagingID = (WORD)(channelDataPtr->BuData[5] & 0x7F) << 8; // x = 0xFF >> i
                     // tempPagingID |= (channelDataPtr->BuData[6] & ~0x3F); // x >>= 1, ~x
                     tempPagingID |= channelDataPtr->BuData[6];
                     tempPagingID >>= 6; // (7 - i)
                     break;
   
                  case 2:
                     tempPagingID = (WORD)(channelDataPtr->BuData[6] & 0x3F) << 8; // x = 0xFF >> i
                     // tempPagingID |= (channelDataPtr->BuData[7] & ~0x1F); // x >>= 1, ~x
                     tempPagingID |= channelDataPtr->BuData[7];
                     tempPagingID >>= 5; // (7 - i)
                     break;
   
                  case 3:
                     tempPagingID = (WORD)(channelDataPtr->BuData[7] & 0x1F) << 8; // x = 0xFF >> i
                     // tempPagingID |= (channelDataPtr->BuData[8] & ~0x0F); // x >>= 1, ~x
                     tempPagingID |= channelDataPtr->BuData[8];
                     tempPagingID >>= 4; // (7 - i)
                     break;
   
                  case 4:
                     tempPagingID = (WORD)(channelDataPtr->BuData[8] & 0x0F) << 8; // x = 0xFF >> i
                     // tempPagingID |= (channelDataPtr->BuData[9] & ~0x07); // x >>= 1, ~x
                     tempPagingID |= channelDataPtr->BuData[9];
                     tempPagingID >>= 3; // (7 - i)
                     break;
   
                  case 5:
                     tempPagingID = (WORD)(channelDataPtr->BuData[9] & 0x07) << 8; // x = 0xFF >> i
                     // tempPagingID |= (channelDataPtr->BuData[10] & ~0x03); // x >>= 1, ~x
                     tempPagingID |= channelDataPtr->BuData[10];
                     tempPagingID >>= 2; // (7 - i)
                     break;
               }
             */
            temp = 0xFF >> i;
            tempPagingID = (WORD)(channelDataPtr->BuData[4 + i] & temp) << 8;
            tempPagingID |= channelDataPtr->BuData[5 + i];
            tempPagingID >>= (7 - i);
   
            if (pagingID == tempPagingID) {
               *indexPtr = i + 5; // return value for X5 ~ X10; 5 ~ 10
               return YES;
            }
         }
      }
   }
   
   // scan bit-map type
   if (pagingID <= 31) {
      if ((channelDataPtr->subfieldAInfo & 0xC0) == 0x40) { // if current SFa is bit-map type
         if (channelDataPtr->BuData[pagingID / 8] & (0x80 >> (pagingID % 8))) {
            *indexPtr = 0; // return value for bit-map; 0
            return YES;
         }
      }
   } else if (pagingID <= 87) {
      if ((channelDataPtr->subfieldBInfo & 0xC0) == 0x40) { // if current SFb is bit-map type
         if (channelDataPtr->BuData[pagingID / 8] & (0x80 >> (pagingID % 8))) {
            *indexPtr = 0; // return value for bit-map; 0
            return YES;
         }
      }
   }

   return NO;
}
#endif

void DECODE_HMAC(HMAC_QUEUES *value)
{
   HMAC_QUEUES buffer; 
   #ifdef ULE_SUPPORT
   BYTE mcei, lbn;
   #endif

   DECT_DEBUG_HIGH_HMAC_PRIMITIVE_NUMBER("%02x, %02x, %02x %02x %02x %02x\n", value->MSG, value->CurrentInc, value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);

   memset(&buffer, 0x00, sizeof(buffer));
   switch (value->MSG) 
   {
      #ifdef CATIQ_UPLANE
      case MAC_FU10_DATA_IN:
         // We received a packet from LMAC and need to hand it upwards
         //printk("\xd\xa***Post FU10 2DectStack\xd\xa");
         #ifdef DEBUG_GPIO
         ssc_dect_haredware_reset(0);
         #endif
         #ifndef LTQ_RAW_DPSU
         {
            int  i; 
            unsigned char CRC = 0;

            for( i = 0;  i < 64;  i++ )
            {
               CRC += value->G_PTR_buf[i];
            }

            if( value->Parameter1 != CRC )
            {
               value->Parameter3 &= ~0x10;      // Clear IP Data OK Flag for discarding PDU Data in FU10 Layer
               value->G_PTR_buf[0] = 0x00;      // Clear 1st 3 Bytes in PDU for discarding PDU Data in FU10 Layer
               value->G_PTR_buf[1] = 0x00;
               value->G_PTR_buf[2] = 0x00;
            }

            value->Parameter1 = 0;
            Dect_SendtoStack(value);
         }
         #else
         //printk("MAC_FU10_DATA_IN\n");
         Dect_SendtoStack(value);
         #endif
         #ifdef DEBUG_GPIO
         ssc_dect_haredware_reset(1);
         #endif
         //printk("\xd\xa***Post OK\xd\xa");
         break;

      case MAC_FU10_DATA_RQ:
         // TODO send buffer via SPI
         // ???: Kann das gehen? Antwort: JA!
         //printk("\xd\xa***Post FU10 2 LMAC\xd\xa");
         #ifdef DEBUG_GPIO
         ssc_dect_haredware_reset(0);
         #endif
         //printk("MAC_FU10_DATA_RQ\n");
         Dect_SendtoLMAC(value);
         #ifdef DEBUG_GPIO
         ssc_dect_haredware_reset(1);
         #endif
         //printk("\xd\xa***Post OK\xd\xa");
         break;
      #endif

      #ifdef ULE_SUPPORT
      // From LMAC
      // ---------
      case LMAC_ULE_FU10_ACC_IND:
      case LMAC_ULE_FU10_ACC_RDY_REL_IND:
         /*
            Parameter1        : LBN
            Parameter2        : PMID[0]
            Parameter3        : PMID[1]
            Parameter4        : PMID[2]
            G_PTR_buf[0]      : Length of Data
            G_PTR_buf[1]..[38]: Data
          */

         if (value->MSG == LMAC_ULE_FU10_ACC_IND) {
            DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("LMAC_ULE_FU10_ACC_IND,, %02x %02x %02x %02x, %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4, value->G_PTR_buf[0], value->G_PTR_buf[1]);
         } else {
            DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("LMAC_ULE_FU10_ACC_RDY_REL_IND,, %02x %02x %02x %02x, %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4, value->G_PTR_buf[0], value->G_PTR_buf[1]);
         }
         #if 0
         {
            int  i; 

            if (value->G_PTR_buf[0] == 0) {
               printk("> Data:No Data!\n");
            } else {
               printk("> Data:\n");
               for (i = 0; i < value->G_PTR_buf[0]; i++) {
                  if (i != 0 && ((i % 16) == 0)) {
                     printk("\n");
                  }
                  printk("%02x ", value->G_PTR_buf[1 + i]);
               }
               printk("\n");
            }
         }
         #endif

         lbn = value->Parameter1;
         if ((mcei = ULE_New_Mcei(&value->Parameter2)) != NO_MCEI) {
            Mcei_Table[mcei].Mbc_State = MBC_ST_RESUME;
            Attach_TBC_to_MBC (mcei, lbn);
         
            buffer.PROCID = HMAC;
            if (value->MSG == LMAC_ULE_FU10_ACC_IND) {
               buffer.MSG = HMAC_ULE_FU10_ACC_IND;
            } else {
               buffer.MSG = HMAC_ULE_FU10_ACC_RDY_REL_IND;
            }
            buffer.Parameter1 = value->Parameter2;
            buffer.Parameter2 = value->Parameter3;
            buffer.Parameter3 = value->Parameter4;
            memcpy(&buffer.G_PTR_buf[0], &value->G_PTR_buf[0], sizeof(((ULE_HMAC_QUEUES *)0)->G_PTR_buf));
            buffer.CurrentInc = mcei;
            Dect_SendtoStack(&buffer);
         } else {
            // It should not be happend. Just for safety!
            // NO_MCEI can't assign, Release imediately!
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_ULE_FU10_REL_REQ;
            buffer.Parameter1 = lbn;
            buffer.Parameter2 = ADV2_REL_REASON_BS_BUSY; // Reason
            buffer.Parameter3 = 0; // Info
            buffer.Parameter4 = 0; // RSN checkpoint
            Dect_SendtoLMAC(&buffer);
         }
         break;
      
      case LMAC_ULE_FU10_DATA_IND:
         {        
            /*
               Parameter1        : LBN
               Parameter2        : -
               Parameter3        : -
               Parameter4        : -
               G_PTR_buf[0]      : Length of Data
               G_PTR_buf[1]..[38]: Data
             */

            DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("LMAC_ULE_FU10_DATA_IND,, %02x, %02x %02x\n", value->Parameter1, value->G_PTR_buf[0], value->G_PTR_buf[1]);
            #if 0
            {
               int  i; 
               
               if (value->G_PTR_buf[0] == 0) {
                  printk("> Data:No Data!\n");
               } else {
                  printk("> Data:\n");
                  for (i = 0; i < value->G_PTR_buf[0]; i++) {
                     if (i != 0 && ((i % 16) == 0)) {
                        printk("\n");
                     }
                     printk("%02x ", value->G_PTR_buf[1 + i]);
                  }
                  printk("\n");
               }
            }
            #endif
            
            if ((mcei = Get_Mcei_of_only_TB(value->Parameter1)) != NO_MCEI) {
               buffer.PROCID = HMAC;
               buffer.MSG = HMAC_ULE_FU10_DATA_IND;
               memcpy(&buffer.G_PTR_buf[0], &value->G_PTR_buf[0], sizeof(((ULE_HMAC_QUEUES *)0)->G_PTR_buf));
               buffer.CurrentInc = mcei;
               Dect_SendtoStack(&buffer);
            }
            break;
         }
         
      case LMAC_ULE_FU10_RDY_REL_IND:
         /*
            Parameter1        : LBN
            Parameter2        : Reason
            Parameter3        : Info
            Parameter4        : RSN
            G_PTR_buf[0]      : Length of Data
            G_PTR_buf[1]..[38]: Data
          */

         DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("LMAC_ULE_FU10_RDY_REL_IND,, %02x %02x %02x %02x, %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4, value->G_PTR_buf[0], value->G_PTR_buf[1]);
         #if 0
         {
            int  i; 
            
            if (value->G_PTR_buf[0] == 0) {
               printk("> Data:No Data!\n");
            } else {
               printk("> Data:\n");
               for (i = 0; i < value->G_PTR_buf[0]; i++) {
                  if (i != 0 && ((i % 16) == 0)) {
                     printk("\n");
                  }
                  printk("%02x ", value->G_PTR_buf[1 + i]);
               }
               printk("\n");
            }
         }
         #endif
      
         if ((mcei = Get_Mcei_of_only_TB(value->Parameter1)) != NO_MCEI) {
            buffer.PROCID = HMAC;
            buffer.MSG = HMAC_ULE_FU10_RDY_REL_IND;
            buffer.Parameter1 = value->Parameter2;
            buffer.Parameter2 = value->Parameter3;
            buffer.Parameter3 = value->Parameter4;
            memcpy(&buffer.G_PTR_buf[0], &value->G_PTR_buf[0], sizeof(((ULE_HMAC_QUEUES *)0)->G_PTR_buf));
            buffer.CurrentInc = mcei;
            Dect_SendtoStack(&buffer);
         }
         break;

      case LMAC_ULE_FU10_GFA_IND:
         /*
            Parameter1        : LBN
            Parameter2        : RSN
            Parameter3        : -
            Parameter4        : -
          */

         DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("LMAC_ULE_FU10_GFA_IND,, %02x %02x\n", value->Parameter1, value->Parameter2);

         if ((mcei = Get_Mcei_of_only_TB(value->Parameter1)) != NO_MCEI) {
            buffer.PROCID = HMAC;
            buffer.MSG = HMAC_ULE_FU10_GFA_IND;
            buffer.Parameter1 = value->Parameter2;
            buffer.CurrentInc = mcei;
            Dect_SendtoStack(&buffer);
         }
         break;
         
      case LMAC_ULE_FU10_DTR_IND:
         DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("LMAC_ULE_FU10_DTR_IND,, %02x\n", value->Parameter1);

         if ((mcei = Get_Mcei_of_only_TB(value->Parameter1)) != NO_MCEI) {
            buffer.PROCID = HMAC;
            buffer.MSG = HMAC_ULE_FU10_DTR_IND;
            buffer.CurrentInc = mcei;
            Dect_SendtoStack(&buffer);
         }
         break;
            
      case LMAC_ULE_FU10_OTHER_IND:
         DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("LMAC_ULE_FU10_OTHER_IND,, %02x\n", value->Parameter1);

         if ((mcei = Get_Mcei_of_only_TB(value->Parameter1)) != NO_MCEI) {
            buffer.PROCID = HMAC;
            buffer.MSG = HMAC_ULE_FU10_OTHER_IND;
            buffer.CurrentInc = mcei;
            Dect_SendtoStack(&buffer);
         }
         break;
            
      case LMAC_ULE_FU10_REL_IND:
         DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("LMAC_ULE_FU10_REL_IND,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
         
         if ((mcei = Get_Mcei_of_only_TB(value->Parameter1)) != NO_MCEI) {
            buffer.PROCID = HMAC;
            buffer.MSG = HMAC_ULE_FU10_REL_IND;
            buffer.Parameter1 = value->Parameter2;
            buffer.Parameter2 = value->Parameter3;
            buffer.Parameter3 = value->Parameter4;
            buffer.CurrentInc = mcei;
            Dect_SendtoStack(&buffer);
         }
         break;
         
      case LMAC_ULE_FU10_BE_REL_IND:
         DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("LMAC_ULE_FU10_BE_REL_IND,, %02x\n", value->Parameter1);

         lbn = value->Parameter1;
         if ((mcei = Get_Mcei_of_only_TB(lbn)) != NO_MCEI) {
            DECT_DEBUG_HIGH_HMAC_INFO(printk("\n[HMAC] Detach TBC: %02x MCEI: %02x\n", lbn,  mcei));

            Mcei_Table[mcei].Mbc_State = MBC_ST_SUSPEND;
            Detach_TBC_from_MBC(mcei, lbn);

            buffer.PROCID = HMAC;
            buffer.MSG = HMAC_ULE_FU10_LINK_REL_IND;
            buffer.CurrentInc = mcei;
            Dect_SendtoStack(&buffer);
         }
         break;

      // From LU10
      // ---------
      case HMAC_ULE_FU10_RDY_REL_REQ:
         DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("HMAC_ULE_FU10_RDY_REL_REQ, %02x, %02x %02x %02x, %02x %02x\n", value->CurrentInc, value->Parameter1, value->Parameter2, value->Parameter3, value->G_PTR_buf[0], value->G_PTR_buf[1]);
         #if 0
         {
            int  i; 
            
            if (value->G_PTR_buf[0] == 0) {
               printk("> Data:No Data!\n");
            } else {
               printk("> Data:\n");
               for (i = 0; i < value->G_PTR_buf[0]; i++) {
                  if (i != 0 && ((i % 16) == 0)) {
                     printk("\n");
                  }
                  printk("%02x ", value->G_PTR_buf[1 + i]);
               }
               printk("\n");
            }
         }
         #endif

         mcei = value->CurrentInc;
         if ((lbn = Get_Lbn_of_only_TB(mcei)) != NO_LBN) {
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_ULE_FU10_RDY_REL_REQ;
            buffer.Parameter1 = lbn;
            buffer.Parameter2 = value->Parameter1;
            buffer.Parameter3 = value->Parameter2;
            buffer.Parameter4 = value->Parameter3;
            memcpy(&buffer.G_PTR_buf[0], &value->G_PTR_buf[0], sizeof(((ULE_HMAC_QUEUES *)0)->G_PTR_buf));
            ((ULE_HMAC_QUEUES *)&buffer)->CurrentInc = mcei;
            Dect_SendtoLMAC(&buffer);
            DECT_DEBUG_HIGH_HMAC_INFO(printk("\n[HMAC] Pass To LMAC: %02x\n", lbn));
         }
         break;

      case HMAC_ULE_FU10_DATA_REQ:
         DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("HMAC_ULE_FU10_DATA_REQ, %02x,, %02x %02x\n", value->CurrentInc, value->G_PTR_buf[0], value->G_PTR_buf[1]);
         #if 0
         {
            int  i; 
            
            if (value->G_PTR_buf[0] == 0) {
               printk("> Data:No Data!\n");
            } else {
               printk("> Data:\n");
               for (i = 0; i < value->G_PTR_buf[0]; i++) {
                  if (i != 0 && ((i % 16) == 0)) {
                     printk("\n");
                  }
                  printk("%02x ", value->G_PTR_buf[1 + i]);
               }
               printk("\n");
            }
         }
         #endif

         mcei = value->CurrentInc;
         if ((lbn = Get_Lbn_of_only_TB(mcei)) != NO_LBN) {
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_ULE_FU10_DATA_REQ;
            buffer.Parameter1 = lbn;
            memcpy(&buffer.G_PTR_buf[0], &value->G_PTR_buf[0], sizeof(((ULE_HMAC_QUEUES *)0)->G_PTR_buf));
            ((ULE_HMAC_QUEUES *)&buffer)->CurrentInc = mcei;
            Dect_SendtoLMAC(&buffer);
            DECT_DEBUG_HIGH_HMAC_INFO(printk("\n[HMAC] Pass To LMAC: %02x\n", lbn));
         }
         break;

      case HMAC_ULE_FU10_GFA_REQ:
         DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("HMAC_ULE_FU10_GFA_REQ, %02x, %02x\n", value->CurrentInc, value->Parameter1);

         mcei = value->CurrentInc;
         if ((lbn = Get_Lbn_of_only_TB(mcei)) != NO_LBN) {
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_ULE_FU10_GFA_REQ;
            buffer.Parameter1 = lbn;
            buffer.Parameter2 = value->Parameter1;
            Dect_SendtoLMAC(&buffer);
            DECT_DEBUG_HIGH_HMAC_INFO(printk("\n[HMAC] Pass To LMAC: %02x\n", lbn));
         }
         break;

      case HMAC_ULE_FU10_REL_REQ:
         DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("HMAC_ULE_FU10_REL_REQ, %02x, %02x %02x %02x\n", value->CurrentInc, value->Parameter1, value->Parameter2, value->Parameter3);

         mcei = value->CurrentInc;
         if ((lbn = Get_Lbn_of_only_TB(mcei)) != NO_LBN) {
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_ULE_FU10_REL_REQ;
            buffer.Parameter1 = lbn;
            buffer.Parameter2 = value->Parameter1;
            buffer.Parameter3 = value->Parameter2;
            buffer.Parameter4 = value->Parameter3;
            Dect_SendtoLMAC(&buffer);
            DECT_DEBUG_HIGH_HMAC_INFO(printk("\n[HMAC] Pass To LMAC: %02x\n", lbn));
         }
         break;  

      case MAC_ULE_PAGE_LB:
         {
            /*
               Parameter1: Channel Active
               Parameter2: Channel Periodicity
               Parameter3: Start MFM4
               Parameter4: Start MFM + Start FCNT
               G_PTR_buf[0]: MSB of Paging ID
               G_PTR_buf[1]: LSB of Paging ID
               G_PTR_buf[2]: Paging Type
             */

            BuChannelData_t *channelDataPtr; 
            BYTE active;
            BYTE i;
            BYTE temp;
            BYTE found;
            WORD pagingID;

            DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("MAC_ULE_PAGE_LB,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);

            channelDataPtr = &BuChannelDataArray[0];
            active = value->Parameter1;
            if (active != 0) {
               channelDataPtr++;
               while ((active & 0x01) == 0) {
                  channelDataPtr++;
                  active >>= 1;
               }
            }

            /*
               if paging ID is not used
                  if index
                     if current SFa is not bit-map paging type
                        if current SFa is no paging type
                           init subfield A for index paging type and set SFa to index paging type
                        if paging ID < 127
                           find unused field for x1 ~ x3
                              if unused field is found
                                 set paging ID and mark paging ID and set FOUND to 1
                        if not found and X4 is not used
                           set paging ID and mark paging ID and set FOUND to 1

                     if not found and current SFb is not bit-map paging type
                        if current SFb is no paging type
                           init subfield b for index paging type and set SFb to index paging type
                        find unused field for x5 ~ x10
                           if unused field is found
                              set paging ID and mark paging ID and set FOUND to 1
                  else // bit-map
                     if paging id <= 31
                        if current SFa is not index paging type
                           set SFa to bit-map paging type and set FOUND to 1
                     else if paging id <= 87
                        if current SFb is not index paging type
                           set SFb to bit-map paging type and set FOUND to 1
                     if FOUND
                        set paging id

               if not FOUND
                  return
             */

            pagingID = ((WORD)value->G_PTR_buf[0] << 8) | value->G_PTR_buf[1];
            found = NO;
            if (isUsingPagingID(pagingID, channelDataPtr, &i) == NO) {
               if (value->G_PTR_buf[2]) { // if index
                  if ((channelDataPtr->subfieldAInfo & 0xC0) != 0x40) { // if current SFa is not bit-map type
                     if ((channelDataPtr->subfieldAInfo & 0xC0) == 0x00) { // if current SFa is no paging type
                        /*
                           Initialize subfield A for index paging type.
                           - X1 ~ X4: fill them with 0xFF
                           - pdb = 0
                           - pdc = 0
                         */
                        memset(&channelDataPtr->BuData[0], 0xFF, 3);
                        channelDataPtr->BuData[3] = 0xFC;
                        channelDataPtr->subfieldAInfo |= 0x80; // set SFa to index type
                     }

                     if (pagingID < 127) { // if less than 127
                        for (i = 0; i <= 2; i++) {
                           if (!(channelDataPtr->subfieldAInfo & (0x08 >> i))) { // 1000b >> i; X1 -> X3
                              /*
                                 switch (i) {
                                    case 0:
                                       pagingID <<= 1; // (i + 1)
                                       // channelDataPtr->BuData[-1] &= 0xFF; // x = 0xFF << i
                                       // channelDataPtr->BuData[-1] |= (pagingID >> 8);
                                       channelDataPtr->BuData[0] &= ~0xFE; // ~(x << 1)
                                       channelDataPtr->BuData[0] |= pagingID;
                                       break;

                                    case 1:
                                       pagingID <<= 2; // (i + 1)
                                       channelDataPtr->BuData[0] &= 0xFE; // x = 0xFF << i
                                       channelDataPtr->BuData[0] |= (pagingID >> 8);
                                       channelDataPtr->BuData[1] &= ~0xFC; // ~(x << 1)
                                       channelDataPtr->BuData[1] |= pagingID;
                                       break;

                                    case 2:
                                       pagingID <<= 3; // (i + 1)
                                       channelDataPtr->BuData[1] &= 0xFC; // x = 0xFF << i
                                       channelDataPtr->BuData[1] |= (pagingID >> 8);
                                       channelDataPtr->BuData[2] &= ~0xF8; // ~(x << 1)
                                       channelDataPtr->BuData[2] |= pagingID;
                                       break;
                                 }
                               */
                              pagingID <<= (i + 1);
                              temp = 0xFF << i;
                              if (i != 0) {
                                 channelDataPtr->BuData[i - 1] &= temp;
                                 channelDataPtr->BuData[i - 1] |= (pagingID >> 8);
                              }
                              channelDataPtr->BuData[i] &= ~(temp << 1);
                              channelDataPtr->BuData[i] |= pagingID;

                              channelDataPtr->subfieldAInfo |= (0x08 >> i); // mark the used index
                              found = YES;
                              break; // exit for loop
                           }
                        }
                     }

                     if (!found && !(channelDataPtr->subfieldAInfo & 0x01)) { // if not found and X4 is not used
                        pagingID <<= 2;
                        channelDataPtr->BuData[2] &= 0xF8;
                        channelDataPtr->BuData[2] |= (pagingID >> 8);
                        channelDataPtr->BuData[3] &= 0x03;
                        channelDataPtr->BuData[3] |= pagingID;

                        channelDataPtr->subfieldAInfo |= 0x01;
                        found = YES;
                     }
                  }

                  if (!found && ((channelDataPtr->subfieldBInfo & 0xC0) != 0x40)) { // if current SFb is not bit-map type
                     if ((channelDataPtr->subfieldBInfo & 0xC0) == 0x00) { // if current SFb is no paging type
                        /*
                           Initialize subfield B for index paging type.
                           - X5 ~ X10: fill them with 0xFF
                           - pdb = 0
                           - pdc = 0
                         */
                        memset(&channelDataPtr->BuData[4], 0xFF, 6);
                        channelDataPtr->BuData[10] = 0xFC;
                        channelDataPtr->subfieldBInfo |= 0x80; // set SFb to index type
                     }

                     for (i = 0; i <= 5; i++) {
                        if (!(channelDataPtr->subfieldBInfo & (0x20 >> i))) { // 100000b >> i; X5 -> X10
                           /*
                              switch (i) {
                                 case 0:
                                    pagingID <<= 7; // (7 - i)
                                    channelDataPtr->BuData[4] &= ~0xFF; // x = 0xFF >> i, ~x
                                    channelDataPtr->BuData[4] |= (pagingID >> 8)
                                    channelDataPtr->BuData[5] &= 0x7F; // x >> 1
                                    channelDataPtr->BuData[5] |= pagingID;
                                    break;

                                 case 1:
                                    pagingID <<= 6; // (7 - i)
                                    channelDataPtr->BuData[5] &= ~0x7F; // x = 0xFF >> i, ~x
                                    channelDataPtr->BuData[5] |= (pagingID >> 8);
                                    channelDataPtr->BuData[6] &= 0x3F; // x >> 1
                                    channelDataPtr->BuData[6] |= pagingID;
                                    break;

                                 case 2:
                                    pagingID <<= 5; // (7 - i)
                                    channelDataPtr->BuData[6] &= ~0x3F; // x = 0xFF >> i, ~x
                                    channelDataPtr->BuData[6] |= (pagingID >> 8);
                                    channelDataPtr->BuData[7] &= 0x1F; // x >> 1
                                    channelDataPtr->BuData[7] |= pagingID;
                                    break;

                                 case 3:
                                    pagingID <<= 4; // (7 - i)
                                    channelDataPtr->BuData[7] &= ~0x1F; // x = 0xFF >> i, ~x
                                    channelDataPtr->BuData[7] |= (pagingID >> 8);
                                    channelDataPtr->BuData[8] &= 0x0F; // x >> 1
                                    channelDataPtr->BuData[8] |= pagingID;
                                    break;

                                 case 4:
                                    pagingID <<= 3; // (7 - i)
                                    channelDataPtr->BuData[8] &= ~0x0F; // x = 0xFF >> i, ~x
                                    channelDataPtr->BuData[8] |= (pagingID >> 8);
                                    channelDataPtr->BuData[9] &= 0x07; // x >> 1
                                    channelDataPtr->BuData[9] |= pagingID;
                                    break;

                                 case 5:
                                    pagingID <<= 2; // (7 - i)
                                    channelDataPtr->BuData[9] &= ~0x07; // x = 0xFF >> i, ~x
                                    channelDataPtr->BuData[9] |= (pagingID >> 8);
                                    channelDataPtr->BuData[10] &= 0x03; // x >> 1
                                    channelDataPtr->BuData[10] |= pagingID;
                                    break;
                              }
                            */
                           pagingID <<= (7 - i);
                           temp = 0xFF >> i;
                           channelDataPtr->BuData[4 + i] &= ~temp;
                           channelDataPtr->BuData[4 + i] |= (pagingID >> 8);
                           channelDataPtr->BuData[5 + i] &= (temp >> 1);
                           channelDataPtr->BuData[5 + i] |= pagingID;

                           channelDataPtr->subfieldBInfo |= (0x20 >> i);
                           found = YES;
                           break; // exit for loop
                        }
                     }
                  }
               } else {
                  if (pagingID <= 31) {
                     if ((channelDataPtr->subfieldAInfo & 0xC0) != 0x80) { // if current SFa is not index type
                        channelDataPtr->subfieldAInfo |= 0x40; // set SFa to bit-map type
                        found = YES;
                     }
                  } else if (pagingID <= 87) {
                     if ((channelDataPtr->subfieldBInfo & 0xC0) != 0x80) { // if current SFb is not index type
                        channelDataPtr->subfieldBInfo |= 0x40; // set SFb to bit-map type
                        found = YES;
                     }
                  }

                  if (found) {
                     channelDataPtr->BuData[pagingID / 8] |= (0x80 >> (pagingID % 8)); // if offset == 0 then BuData[0] |= 0x80, if offset == 1 then BuData[0] |= 0x40
                  }
               }
            } else {
               // Error: The paging ID is being used
            }

            if (!found) {
               break; // exit swtich
            }

            channelDataPtr->channelPeriodicity = value->Parameter2;
            channelDataPtr->startFrameNumber = ((WORD)value->Parameter3 << 8) | value->Parameter4;

            /*
               Parameter1: Channel Active (4) | Channel Periodicity (4)
               Parameter2: Start MFM4
               Parameter3: Start MFM (4) | Start FCNT (4)
               Parameter4: SFa (2) | SFb (2)
               Buffer: Data length, Bu data[0] ~ Bu data[10]
             */
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_ULE_PAGE_REQ;
            buffer.Parameter1 = (value->Parameter1 << 4) | channelDataPtr->channelPeriodicity; // Channel Active | Channel Periodicity
            buffer.Parameter2 = (BYTE)(channelDataPtr->startFrameNumber >> 8); // Start MFM4
            buffer.Parameter3 = (BYTE)channelDataPtr->startFrameNumber; // Start MFM + Start FCNT
            buffer.Parameter4 = ((channelDataPtr->subfieldAInfo & 0xC0) >> 4) | ((channelDataPtr->subfieldBInfo & 0xC0) >> 6);
            buffer.G_PTR_buf[0] = BU_DATA_SIZE;
            memcpy(&buffer.G_PTR_buf[1], &channelDataPtr->BuData[0], BU_DATA_SIZE);
            Dect_SendtoLMAC(&buffer);
         }
         break;

      case MAC_ULE_PAGE_STOP_LB:
         {
            /*
               Parameter1: Channel Active
               G_PTR_buf[0]: MSB of Paging ID
               G_PTR_buf[1]: LSB of Paging ID
               G_PTR_buf[2]: Paging Type
             */

            BuChannelData_t *channelDataPtr; 
            BYTE active;
            WORD pagingID;
            BYTE i;
            BYTE temp;
            
            DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE("MAC_ULE_PAGE_STOP_LB,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
            
            channelDataPtr = &BuChannelDataArray[0];
            active = value->Parameter1;
            if (active != 0) {
               channelDataPtr++;
               while ((active & 0x01) == 0) {
                  channelDataPtr++;
                  active >>= 1;
               }
            }

            pagingID = ((WORD)value->G_PTR_buf[0] << 8) | value->G_PTR_buf[1];
            if (isUsingPagingID(pagingID, channelDataPtr, &i)) {
               if (i == 0) { // bit-map
                  channelDataPtr->BuData[pagingID / 8] &= ~(0x80 >> (pagingID % 8)); // if offset == 0 then BuData[0] &= ~0x80, if offset == 1 then BuData[0] &= ~0x40
               } else if (i <= 3) { // X1 ~ X3; 1 ~ 3
                  i -= 1; // 0 ~ 2
                  // fill with 1 (7 bits)
                  pagingID = 0x7F << (i + 1);
                  if (i != 0) {
                     channelDataPtr->BuData[i - 1] |= (pagingID >> 8);
                  }
                  channelDataPtr->BuData[i] |= pagingID;
                  channelDataPtr->subfieldAInfo &= ~(0x08 >> i);
               } else if (i <= 4) { // X4; 4
                  // fill with 1 (9 bits)
                  pagingID = 0x01FF << 2;
                  channelDataPtr->BuData[2] |= (pagingID >> 8);
                  channelDataPtr->BuData[3] |= pagingID;
                  channelDataPtr->subfieldAInfo &= ~0x01;
               } else if (i <= 10) { // X5 ~ X10; 5 ~ 10
                  i -= 5; // 0 ~ 5
                  // fill with 1 (9 bits)
                  pagingID = 0x01FF << (7 - i);
                  channelDataPtr->BuData[4 + i] |= (pagingID >> 8);
                  channelDataPtr->BuData[5 + i] |= pagingID;
                  channelDataPtr->subfieldBInfo &= ~(0x20 >> i);
               }
            } else {
               break;
            }

            // if subfield A or B is not used then initialize the current BuChannelData
            /*
               if current SFa is index paging type
                  if no the marked paging IDs any more
                     clear SFa and clear the current BuData for subfield A
               else if current SFa is bit-map paging type
                  if subfield A is empty
                      clear the current BuChannelData
               if current SFb is index paging type
                  if no the marked paging IDs any more
                     clear SFb and clear the current BuData for subfield B
               else if current SFb is bit-map paging type
                  if subfield A is empty
                      clear the current BuChannelData
             */

            if ((channelDataPtr->subfieldAInfo & 0xC0) == 0x80) { // if current SFa is index type
               if ((channelDataPtr->subfieldAInfo & 0x0F) == 0) { // if no more paging
                  channelDataPtr->subfieldAInfo &= ~0xC0; // clear SFa
                  memset(&channelDataPtr->BuData[0], 0x00, 4); // clear subfield A
               }
            } else if ((channelDataPtr->subfieldAInfo & 0xC0) == 0x40) { // if current SFa is bit-map type
               temp = 0;
               for (i = 0; i < 4; i++) {
                  temp |= channelDataPtr->BuData[i];
               }
               if (temp == 0) {
                  channelDataPtr->subfieldAInfo &= ~0xC0; // clear SFa
               }
            }

            if ((channelDataPtr->subfieldBInfo & 0xC0) == 0x80) { // if current SFb is index type
               if ((channelDataPtr->subfieldBInfo & 0x3F) == 0) { // if no more paging
                  channelDataPtr->subfieldBInfo &= ~0xC0; // clear SFb
                  memset(&channelDataPtr->BuData[4], 0x00, 7); // clear subfield B
               }
            } else if ((channelDataPtr->subfieldBInfo & 0xC0) == 0x40) { // if current SFb is bit-map type
               temp = 0;
               for (i = 4; i < BU_DATA_SIZE; i++) {
                  temp |= channelDataPtr->BuData[i];
               }
               if (temp == 0) {
                  channelDataPtr->subfieldBInfo &= ~0xC0; // clear SFb
               }
            }

            if (((channelDataPtr->subfieldAInfo & 0xC0) == 0) &&  ((channelDataPtr->subfieldBInfo & 0xC0) == 0)) {
               channelDataPtr->channelPeriodicity = 0;
               channelDataPtr->startFrameNumber = 0;
            }

            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_ULE_PAGE_REQ;
            buffer.Parameter1 = (value->Parameter1 << 4) | channelDataPtr->channelPeriodicity; // Channel Active | Channel Periodicity
            buffer.Parameter2 = (BYTE)(channelDataPtr->startFrameNumber >> 8); // Start MFM4
            buffer.Parameter3 = (BYTE)channelDataPtr->startFrameNumber; // Start MFM + Start FCNT
            buffer.Parameter4 = ((channelDataPtr->subfieldAInfo & 0xC0) >> 4) | ((channelDataPtr->subfieldBInfo & 0xC0) >> 6);
            buffer.G_PTR_buf[0] = BU_DATA_SIZE;
            memcpy(&buffer.G_PTR_buf[1], &channelDataPtr->BuData[0], BU_DATA_SIZE);
            Dect_SendtoLMAC(&buffer);
         }
         break;
      #endif //#ifdef ULE_SUPPORT

      case LMAC_DEBUGMSG_IND:
         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_DEBUGMSG_IND,, %02x %02x %02x %02x, %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n",
         value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4,
         value->G_PTR_buf[0], value->G_PTR_buf[1], value->G_PTR_buf[2], value->G_PTR_buf[3],
         value->G_PTR_buf[4], value->G_PTR_buf[5], value->G_PTR_buf[6], value->G_PTR_buf[7],
         value->G_PTR_buf[8], value->G_PTR_buf[9]);
         break;

      case MAC_SEND_DUMMY_RQ_ME:  /*  IN LINE CODE T0011    */
         /* TRANSITION:      T0011                                                */
         /* EVENT:           MAC_SEND_DUMMY_RQ_ME                                 */
         /* DESCRIPTION:     create new dummy bearer                              */
         /* STARTING STATE:  AI_ATAD_AT                                           */
         /* END STATE:       AI_ATAD_AT                                           */
         /* ----------------------------------------------------------------------*/
         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_SEND_DUMMY_RQ_ME,, %02x %02x\n", value->Parameter1, value->Parameter2);

         buffer.PROCID = LMAC;
         buffer.MSG = LMAC_DUMMY_SEND_REQ;
         buffer.Parameter1 = value->Parameter1;
         buffer.Parameter2 = value->Parameter2;
         buffer.Parameter3 = value->Parameter3;
         buffer.Parameter4 = value->Parameter4;
         memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
         Dect_SendtoLMAC(&buffer);
         break;

      case LMAC_MCEI_REQUEST_IND:  /*  IN LINE CODE T0100    */
         {
            /* TRANSITION:      T100                                                 */
            /* EVENT:           LMAC_MCEI_REQUEST_IND                                 */
            /* DESCRIPTION:     A portable has made either a 'basic access rq' or a  */
            /*                  'basic handover rq'. The process level must process  */
            /*                  this request.                                        */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* REMARK:          meanwhile on ISR level 'wait messages' are exchanged.*/
            /* ----------------------------------------------------------------------*/
            BYTE lbn, b_type,  temp_lbn=NO_LBN;
            BYTE mcei;
            BYTE i;
            #ifdef CONFIG_REPEATER_SUPPORT
            BYTE repFlag, slotType, temp_mcei;
            #endif

            //printk("MCEI_REQ:%02x %02x %02x %02x[%02x%02x%02x]\n",
            //value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4,
            DECT_DEBUG_HIGH_HMAC_MCEI_PRIMITIVE("LMAC_MCEI_REQUEST_IND,, %02x %02x %02x %02x[%02x%02x%02x]\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4,
            value->G_PTR_buf[0], value->G_PTR_buf[1], value->G_PTR_buf[2]);

            /* Traffic Bearer Part              */
            /* ================================ */
            lbn = value->Parameter1;
            b_type = value->Parameter2;

         #ifdef CONFIG_REPEATER_SUPPORT
         repFlag = (value->Parameter3 >> 7) & 0x01;
         slotType = value->Parameter3 & 0x7F;
         if (value->Parameter4 == 0) {
            //Rep_Table[lbn].Rep_Cntr = 0;
            memset(&Rep_Table[lbn], 0x00, 3*MAX_REPEATERS_CASDADED+1);
         }
         
         temp_lbn = Rep_Table[lbn].Rep_Cntr;
         Rep_Table[lbn].Rep_Cntr++;
         for ( i = 0;  i < 3;  i++) {
            Rep_Table[lbn].Pmid[temp_lbn][i] = value->G_PTR_buf[i];
         }

         #if 0
         if (repFlag == 1) {
            if (value->Parameter4 == 0) {
               buffer.PROCID = LMAC;
               buffer.MSG = LMAC_MCEI_REQUEST_RES;
               buffer.Parameter1 = lbn;
               buffer.Parameter2 = NO_MCEI;
               buffer.Parameter3 = 1;
               buffer.Parameter4 = NO_LBN;
               Dect_SendtoLMAC(&buffer);
               DECT_DEBUG_HIGH_LMAC_PRIMITIVE("LMAC_MCEI_REQUEST_RES(Repeater):%02x\n", buffer.Parameter1);
            }
            return;
         }
         #endif
         #endif

            if( b_type == TRAFFIC_BEARER)
            {
               /* it is a basic access request;    */
               /* a new MBC is needed              */
               /* -------------------------------- */
            #ifdef CONFIG_REPEATER_SUPPORT
            if (value->Parameter4 != 0) {
               mcei = Get_Mcei_of_only_TB(lbn);
               if (mcei != NO_MCEI) {
                  // copy PMID into MBC data element : Latest PMID is actual PT's PMID
                  for (i = 0; i < 3; i++)
                     Mcei_Table[mcei].pmid[i] = value->G_PTR_buf[i];

                  /* inform the DLC */
                  buffer.PROCID = LC;
                  buffer.MSG = LC_CON_IN_MAC;
                  buffer.Parameter1 = 0xFF;
                  buffer.CurrentInc = mcei;
                  Dect_SendtoStack(&buffer);
                  
                  buffer.MSG = LC_CO_DATA_DTR_MAC;
                  Dect_SendtoStack(&buffer);
               }
               break;
            }
            #endif
            
               mcei = New_Mcei();
               if (mcei != NO_MCEI)
               {
                  Mcei_Table[mcei].Mbc_State = MBC_ST_CON_RQ;
                  Attach_TBC_to_MBC (mcei, lbn);
                  /* copy PMID into MBC data element  */
                  for (i = 0; i < 3; i++)
                     Mcei_Table[mcei].pmid[i] = value->G_PTR_buf[i];
               }
            }
            else if ( b_type == HANDOVER_BEARER )
            {
               /* it is a handover request; get    */
               /* the MBC of the other TB          */
               /* ----------------------------------- */
               mcei = Get_Mcei(lbn, value->G_PTR_buf);

            #ifdef CONFIG_REPEATER_SUPPORT
            repFlag = (mcei >> 7) & 0x01;
            mcei    = (mcei & 0x7F);
            if (value->Parameter4 != 0) {
               temp_mcei = Get_Mcei_of_only_TB(lbn);
               if (mcei != temp_mcei) {
                  // This bearer is handover bearer. So, release assigned mcei of this bearer.
                  Init_Mcei_Table_Element(temp_mcei);
                  buffer.PROCID = LC;
                  buffer.MSG = LC_DIS_IN_MAC;
                  buffer.CurrentInc = temp_mcei;
                  Dect_SendtoStack(&buffer);
               }
            }
            #endif
            
               /* proceed only if a MBC is found   */
               /* and the MBC is in the right state*/
               if ( mcei != NO_MCEI )
               {
                  if(( Mcei_Table[mcei].Mbc_State == MBC_ST_EST ) || ( Mcei_Table[mcei].Mbc_State == MBC_ST_SM_INVOKING ))
                  {
                     if( Mcei_Table[mcei].Mbc_State == MBC_ST_SM_INVOKING )
                        Mcei_Table[mcei].Mbc_State = MBC_ST_CM_HO;
                     else if( Get_no_of_mcei_assigned( ) )
                     //                  else if( (Get_CC_State( mcei ) == 0) || Get_no_of_mcei_assigned( ) )
                     {
                        buffer.PROCID = LMAC;
                        buffer.MSG = LMAC_MCEI_REQUEST_RES;
                        buffer.Parameter1 = lbn;
                        buffer.Parameter2 = NO_MCEI;
                        buffer.Parameter3 = 0;
                        buffer.Parameter4 = 0;
                        Dect_SendtoLMAC(&buffer);
                        DECT_DEBUG_HIGH_HMAC_MCEI_PRIMITIVE("LMAC_MCEI_REQUEST_RES, %02x %02x %02x %02x\n", buffer.Parameter1, buffer.Parameter2, buffer.Parameter3, buffer.Parameter4);
                        return;
                     }
                     else
                        Mcei_Table[mcei].Mbc_State = MBC_ST_HO;

                  temp_lbn = Get_Lbn_of_only_TB (mcei);
                  Attach_TBC_to_MBC (mcei, lbn);
                  #ifdef CONFIG_REPEATER_SUPPORT
                  // Handover of Repeater itself
                  if ((Rep_Table[lbn].Rep_Cntr == 1) && (repFlag == 1))
                  {
                     buffer.PROCID = LMAC;
                     buffer.MSG = LMAC_MCEI_REQUEST_RES;
                     buffer.Parameter1 = lbn;
                     buffer.Parameter2 = mcei;
                     buffer.Parameter3 = 0;
                     buffer.Parameter4 = temp_lbn;
                     Dect_SendtoLMAC(&buffer);
                     DECT_DEBUG_HIGH_HMAC_MCEI_PRIMITIVE("Repeater HO\n");
                     break;
                  }

                  if ((Rep_Table[lbn].Rep_Cntr > 1) || (Rep_Table[temp_lbn].Rep_Cntr > 1))
                  {
                     //printk("MCEI:%02x %02x %02x\n", mcei, lbn, temp_lbn );
                     DECT_DEBUG_HIGH_HMAC_MCEI_PRIMITIVE("MCEI:%02x %02x %02x\n", mcei, lbn, temp_lbn );
                     if (Mcei_Table[mcei].Enc_State != FALSE) {
                        buffer.PROCID = LC_REP;
                        buffer.MSG = LC_REP_CIPHER_RQ;
                        buffer.Parameter1 = mcei;
                        buffer.Parameter2 = lbn;
                        buffer.CurrentInc = mcei;
                        Dect_SendtoStack(&buffer);
                        Mcei_Table[mcei].EncLbn = lbn;
                        DECT_DEBUG_HIGH_HMAC_MCEI_PRIMITIVE("Need MM process:%02x %02x\n", buffer.PROCID, buffer.MSG );
                        break;
                     }
                  }
                  #endif
                  }
                  else
                  {
                     mcei = NO_MCEI;
                  }
               }
            }
            else  // No bearer type -- For safety!!!
            {
               mcei = NO_MCEI;
            }
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_MCEI_REQUEST_RES;
            buffer.Parameter1 = lbn;
            buffer.Parameter2 = mcei;
            buffer.Parameter3 = 0;
            buffer.Parameter4 = temp_lbn;
            Dect_SendtoLMAC(&buffer);
         DECT_DEBUG_HIGH_HMAC_MCEI_PRIMITIVE("Normal LMAC_MCEI_REQUEST_RES, %02x %02x %02x %02x %02x\n", mcei, buffer.Parameter1, buffer.Parameter2, buffer.Parameter3, buffer.Parameter4);
         //printk("Normal LMAC_MCEI_REQUEST_RES, %02x %02x %02x %02x\n", buffer.Parameter1, buffer.Parameter2, buffer.Parameter3, buffer.Parameter4);
      }
      break;

      #ifdef CONFIG_REPEATER_SUPPORT
      case MAC_REP_ACCESS_REQ:
      {
         BYTE mcei, lbn, ridx, temp_lbn;

         mcei = value->Parameter1;
         lbn  = value->Parameter2;
         ridx = value->Parameter3;
         #if 1
         if (value->Parameter4 == 1) {
            if (Mcei_Table[mcei].Mbc_State == MBC_ST_HO) {
               if ( (Mcei_Table[mcei].lbn_1 != NO_LBN) && (Mcei_Table[mcei].lbn_2 != NO_LBN) ) {
                  if (Mcei_Table[mcei].lbn_1 == lbn) {
                     temp_lbn = Mcei_Table[mcei].lbn_2;
                  } else {
                     temp_lbn = Mcei_Table[mcei].lbn_1;
                  }

                 Mcei_Table[mcei].Mbc_State = MBC_ST_EST;
                 Detach_TBC_from_MBC(mcei, lbn);

                 buffer.PROCID = LMAC;
                 buffer.MSG = LMAC_TB_RELEASE_REQ;
                 buffer.Parameter1 = temp_lbn;
                 buffer.Parameter2 = mcei;
                 buffer.Parameter3 = 0;
                 buffer.Parameter4 = 0;
                 Dect_SendtoLMAC(&buffer);
               }
            }
         }
         #endif

         if (Get_Mcei_of_only_TB(lbn) == mcei) {
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_REP_ACCESS_REQ;
            buffer.Parameter1 = mcei;
            buffer.Parameter2 = lbn;
            buffer.Parameter3 = value->Parameter4;
            memcpy(buffer.G_PTR_buf, Rep_Table[lbn].Pmid[ridx], 3);
            Dect_SendtoLMAC(&buffer);
         }
      }
      break;

      case LMAC_REP_ACCESS_CFM:
      {
         BYTE mcei, lbn;

         mcei = value->Parameter1;
         lbn  = value->Parameter2;
         if (Get_Mcei_of_only_TB(lbn) == mcei) {
            buffer.PROCID = LC_REP;
            buffer.MSG = LC_REP_ACCESS_CFM;
            buffer.Parameter1 = mcei;
            buffer.Parameter2 = lbn;
            buffer.Parameter3 = value->Parameter3;
            buffer.CurrentInc = mcei;
            Dect_SendtoStack(&buffer);
         }
      }
      break;

      case MAC_CIPHER_CFM_ON:
      {
         BYTE mcei, lbn;

         mcei = value->Parameter1;
         lbn = Mcei_Table[mcei].EncLbn;
         if ((value->Parameter2 == FALSE) && (lbn < MAX_LINK)) {
            MBC_Release_TBC (mcei, lbn, HANDOVER_BEARER);
            Detach_TBC_from_MBC(mcei, lbn);
            
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_MCEI_REQUEST_RES;
            buffer.Parameter1 = lbn;
            buffer.Parameter2 = NO_MCEI;
            buffer.Parameter3 = 0;
            buffer.Parameter4 = NO_LBN;
            Dect_SendtoLMAC(&buffer);
         } else if (value->Parameter2 == TRUE) {
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_MCEI_REQUEST_RES;
            buffer.Parameter1 = lbn;
            buffer.Parameter2 = mcei;
            buffer.Parameter3 = 1;
            if (Mcei_Table[mcei].lbn_1 == lbn) {
               buffer.Parameter4 = Mcei_Table[mcei].lbn_2;
            } else {
               buffer.Parameter4 = Mcei_Table[mcei].lbn_1;
            }
            Dect_SendtoLMAC(&buffer);
         }
         }
         break;
      #endif

      case MAC_DIS_RQ_LC:  /*  IN LINE CODE T0202    */
         {
           /* TRANSITION:      T202                                                 */
           /* EVENT:           MAC_DIS_RQ_LC / MAC_DIS_RQ_MAC                       */
           /* DESCRIPTION:     LC Layer requires Release                            */
           /* STARTING STATE:  AI_ATAD_AT                                           */
           /* END STATE:       AI_ATAD_AT                                           */
           /* ----------------------------------------------------------------------*/
           BYTE mcei, lbn;

           DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_DIS_RQ_LC,, %02x MBCState: %02x\n", value->Parameter1, Mcei_Table[mcei].Mbc_State);

           mcei = value->Parameter1;
           if ( mcei < MAX_MCEI )
           {
             switch (Mcei_Table[mcei].Mbc_State)
             {
               #ifdef DECT_NG
               case MBC_ST_SM_INVOKING:
               #endif
               case MBC_ST_EST:
                 Mcei_Table[mcei].Mbc_State = MBC_ST_RELEASE_RQ;
                 lbn = Get_Lbn_of_only_TB(mcei);

                 buffer.PROCID = LMAC;
                 buffer.MSG = LMAC_TB_RELEASE_REQ;
                 buffer.Parameter1 = lbn;
                 buffer.Parameter2 = mcei;
                 buffer.Parameter3 = 0;
                 buffer.Parameter4 = 0;
                 Dect_SendtoLMAC(&buffer);
                 DECT_DEBUG_HIGH_LMAC_PRIMITIVE("LMAC_TB_RELEASE_REQ, %02x %02x\n", buffer.Parameter1, buffer.Parameter2);
                 break;

               #ifdef DECT_NG
               case MBC_ST_CM_HO:
               #endif
               case MBC_ST_HO:
                 Mcei_Table[mcei].Mbc_State = MBC_ST_RELEASE_RQ;

                 buffer.PROCID = LMAC;
                 buffer.MSG = LMAC_TB_RELEASE_REQ;
                 buffer.Parameter1 = Mcei_Table[mcei].lbn_1;
                 buffer.Parameter2 = mcei;
                 buffer.Parameter3 = 0;
                 buffer.Parameter4 = 0;
                 Dect_SendtoLMAC(&buffer);
                 DECT_DEBUG_HIGH_LMAC_PRIMITIVE("LMAC_TB_RELEASE_REQ, %02x %02x\n", buffer.Parameter1, buffer.Parameter2);

                 buffer.Parameter1 = Mcei_Table[mcei].lbn_2;
                 Dect_SendtoLMAC(&buffer);
                 DECT_DEBUG_HIGH_LMAC_PRIMITIVE("LMAC_TB_RELEASE_REQ, %02x %02x\n", buffer.Parameter1, buffer.Parameter2);
                 break;

               default:
                 break;
             }
           }
         }
         break;

      case MAC_CO_DATA_RQ_LC:  /*  IN LINE CODE T0400    */
         {
            /* TRANSITION:      T400                                                 */
            /* EVENT:           MAC_CO_DATA_RQ_LC                                    */
            /* DESCRIPTION:     Data request via CS Channel                          */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            BYTE mcei;

            mcei = value->Parameter1;
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_CO_DATA_RQ_LC,, %02x MBCState: %02x\n", value->Parameter1, Mcei_Table[mcei].Mbc_State);
            if (mcei < MAX_MCEI)
            {
               if ((Mcei_Table[mcei].Mbc_State == MBC_ST_EST) || 
                   #ifdef DECT_NG
                   (Mcei_Table[mcei].Mbc_State == MBC_ST_SM_INVOKING)  ||
                   (Mcei_Table[mcei].Mbc_State == MBC_ST_CM_HO)  ||
                   #endif
                   (Mcei_Table[mcei].Mbc_State == MBC_ST_HO))
               {
                  buffer.PROCID = LMAC;
                  buffer.MSG = LMAC_CO_DATA_REQ;
                  buffer.Parameter1 = mcei;
                  memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
                  Dect_SendtoLMAC(&buffer);
               }
            }
         }
      break;
         
   #ifdef CONFIG_REPEATER_SUPPORT
      case MAC_REP_CO_DATA_RQ_LC:  /*  IN LINE CODE T0400    */
      {
         /* TRANSITION:      T400                                                 */
         /* EVENT:           MAC_REP_CO_DATA_RQ_LC                                */
         /* DESCRIPTION:     Data request via CS Channel                          */
         /* STARTING STATE:  AI_ATAD_AT                                           */
         /* END STATE:       AI_ATAD_AT                                           */
         /* ----------------------------------------------------------------------*/
         BYTE mcei;
         
         mcei = value->Parameter1;
         DECT_DEBUG_HIGH_HMAC_REP_PRIMITIVE("MAC_REP_CO_DATA_RQ_LC,, %02x MBCState: %02x\n", value->Parameter1, Mcei_Table[mcei].Mbc_State);
         if (mcei < MAX_MCEI)
         {
            if ((Mcei_Table[mcei].Mbc_State == MBC_ST_EST) || 
                #ifdef DECT_NG
                (Mcei_Table[mcei].Mbc_State == MBC_ST_SM_INVOKING)  ||
                (Mcei_Table[mcei].Mbc_State == MBC_ST_CM_HO)  ||
                #endif
                (Mcei_Table[mcei].Mbc_State == MBC_ST_HO))
            {
               buffer.PROCID = LMAC;
               buffer.MSG = LMAC_REP_CO_DATA_REQ;
               buffer.Parameter1 = mcei;
               buffer.Parameter2 = value->Parameter2;
               memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
               Dect_SendtoLMAC(&buffer);
            }
         }
      }
         break;
   #endif

      case LMAC_TB_RELEASE_IND:  /*  IN LINE CODE T0600    */
         {
            /* TRANSITION:      T0600                                                */
            /* EVENT:           LMAC_TB_RELEASE_IND                             */
            /* DESCRIPTION:     A traffic bearer has been released on LMAC      */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            BYTE lbn, b_type;
            BYTE mcei;

         //printk("TB_RELEASE:%02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3);
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_TB_RELEASE_IND,, %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3);

            lbn = value->Parameter1;
            b_type = value->Parameter2;
            mcei = value->Parameter3;

            /* Note: if access was not granted  */
            /* an MBC has not been allocated.   */
            if ( mcei != NO_MCEI )
            {
               MBC_Release_TBC (mcei, lbn, b_type);
            }
            else
            {
               /* Note: if released just before assigned MCEI reached */
               /* => The MCEI table should be cleared.   */
               mcei = Get_Mcei_of_only_TB(lbn);

               if( mcei != NO_MCEI )
                  MBC_Release_TBC (mcei, lbn, b_type);
            }

            /* Reset the valid voice packet condition so that for next
               session PLC is not played before a valid voice pkt */
            if(mcei != NO_MCEI)
               valid_voice_pkt[mcei] = 0;
         }
         break;

      case LMAC_TB_ESTABLISHE_IND:  /*  IN LINE CODE T0611    */
         {
            /* TRANSITION:      T0611                                                */
            /* EVENT:           LMAC_TB_ESTABLISHE_IND                          */
            /* DESCRIPTION:     A traffic bearer has been established on LMACl.  */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            BYTE lbn;
            BYTE mcei;
            // BYTE i;
            #ifdef DECT_NG
            BYTE s_type = value->Parameter4;
            #endif

            lbn = value->Parameter1;
            mcei = value->Parameter3;
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_TB_ESTABLISHE_IND,, %02x %02x %02x MBCState: %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, Mcei_Table[mcei].Mbc_State);
            switch ( Mcei_Table[mcei].Mbc_State )
            {
               case MBC_ST_CON_RQ:
               if (mcei != NO_MCEI) {
                  Mcei_Table[mcei].Mbc_State = MBC_ST_EST;
                  
                  /* inform the DLC                   */
                  buffer.PROCID = LC;
                  buffer.MSG = LC_CON_IN_MAC;
                  #ifdef DECT_NG
                  buffer.Parameter1 = s_type;
                  #endif
                  buffer.CurrentInc= mcei;
                  Dect_SendtoStack(&buffer);
                  
                  buffer.MSG = LC_CO_DATA_DTR_MAC;
                  Dect_SendtoStack(&buffer);
               #ifdef CONFIG_REPEATER_SUPPORT
                  Mcei_Table[mcei].EncLbn = lbn;
               #endif
               }
                  break;

               case MBC_ST_EST:
                  Mcei_Table[mcei].Mbc_State = MBC_ST_HO;
                  break;

               #ifdef DECT_NG
               case MBC_ST_SM_INVOKING:
                  Mcei_Table[mcei].Mbc_State = MBC_ST_CM_HO;
                  break;
               #endif

               case MBC_ST_RELEASE_RQ:
               default:
                  /* nothing has to be done; the release has already been initiated */
                  break;
            }
         }
         break;

      case LMAC_CO_DATA_IND:  /*  IN LINE CODE T0700    */
         {
            /* TRANSITION:      T0700                                                */
            /* EVENT:           LMAC_CO_DATA_IND                                   */
            /* DESCRIPTION:     BMC ISR Level indicates the reception of a Ct        */
            /*                  fragment.                                            */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            BYTE mcei = value->Parameter1;
           
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_CO_DATA_IND,, %02x\n", value->Parameter1);

         if (mcei != NO_MCEI) {
            buffer.PROCID = LC;
            buffer.MSG = LC_CO_DATA_IN_MAC;
            memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
            buffer.CurrentInc= mcei;
            Dect_SendtoStack(&buffer);
         }
      }
         break;

      case LMAC_CO_DTR_IND:  /*  IN LINE CODE T0701    */
         /* TRANSITION:      T0701                                                */
         /* EVENT:           LMAC_CO_DTR_IND                                  */
         /* DESCRIPTION:     BMC ISR Level indicates that a Ct fragment has been  */
         /*                  sent and acknowledged by the PT.                     */
         /* STARTING STATE:  AI_ATAD_AT                                           */
         /* END STATE:       AI_ATAD_AT                                           */
         /* ----------------------------------------------------------------------*/
         /* the message is passed on to the  */
         /* LC(PARAMETER1=mcei)              */
         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_CO_DTR_IND,, %02x\n", value->Parameter1);

         if (mcei != NO_MCEI) {
         buffer.PROCID = LC;
         buffer.MSG = LC_CO_DATA_DTR_MAC;
         buffer.CurrentInc= value->Parameter1;
         Dect_SendtoStack(&buffer);
         }
         break;

   #ifdef CONFIG_REPEATER_SUPPORT
      case LMAC_REP_CO_DATA_IND:
      {
         /* TRANSITION:      T0700                                                */
         /* EVENT:           LMAC_REP_CO_DATA_IND                                 */
         /* DESCRIPTION:     BMC ISR Level indicates the reception of a Ct        */
         /*                  fragment.                                            */
         /* STARTING STATE:  AI_ATAD_AT                                           */
         /* END STATE:       AI_ATAD_AT                                           */
         /* ----------------------------------------------------------------------*/
         BYTE mcei = value->Parameter1;
        
         DECT_DEBUG_HIGH_HMAC_REP_PRIMITIVE("LMAC_REP_CO_DATA_IND,, %02x\n", value->Parameter1);

         buffer.PROCID = LC_REP;
         buffer.MSG = LC_CO_DATA_IN_MAC;
         memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
         buffer.CurrentInc = mcei;
         buffer.Parameter2 = value->Parameter2;
         Dect_SendtoStack(&buffer);
      }
         break;

      case LMAC_REP_CO_DTR_IND:  /*  IN LINE CODE T0701    */
         /* TRANSITION:      T0701                                                */
         /* EVENT:           LMAC_REP_CO_DTR_IND                                  */
         /* DESCRIPTION:     BMC ISR Level indicates that a Ct fragment has been  */
         /*                  sent and acknowledged by the PT.                     */
         /* STARTING STATE:  AI_ATAD_AT                                           */
         /* END STATE:       AI_ATAD_AT                                           */
         /* ----------------------------------------------------------------------*/
         /* the message is passed on to the  */
         /* LC(PARAMETER1=mcei)              */
         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_REP_CO_DTR_IND,, %02x\n", value->Parameter1);

         buffer.PROCID = LC_REP;
         buffer.MSG = LC_CO_DATA_DTR_MAC;
         buffer.CurrentInc = value->Parameter1;
         buffer.Parameter2 = value->Parameter2;
         Dect_SendtoStack(&buffer);
         break;
   #endif

       case MAC_PAGE_RQ_LB:  /*  IN LINE CODE T0401    */
         /* TRANSITION:      T401                                                 */
         /* EVENT:           MAC_PAGE_RQ_LB                                       */
         /* DESCRIPTION:     Bs channel data request via Pt paging                */
         /* STARTING STATE:  AI_ATAD_AT                                           */
         /* END STATE:       AI_ATAD_AT                                           */
         /* ----------------------------------------------------------------------*/
         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_PAGE_RQ_LB,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
         #ifdef FT_CLMS
         // For CLMS, we need length of paging buffer message. So, Parameter4 will be assigned for length.
         BsCh_Paging_Request(value->G_PTR_buf, value->Parameter4 );
         #else
         #if 1  // LOW_DUTY_SUPPORT
         if( LowDuty_Support == FALSE )
         {
            BsCh_Paging_Request( value->G_PTR_buf, value->Parameter1 );
            break;
         }

         buffer.PROCID = LMAC;
         buffer.MSG = LMAC_PAGE_REQ;
         buffer.Parameter1 = value->Parameter1;
         buffer.Parameter2 = value->Parameter2;
         buffer.Parameter3 = value->Parameter3;
         buffer.Parameter4 = value->Parameter4;
         memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
         Dect_SendtoLMAC(&buffer);
         #else
         BsCh_Paging_Request(value->G_PTR_buf, value->Parameter1 );
         #endif
         #endif
         break;

      case LMAC_BS_INFO_SEND_IND:  /*  IN LINE CODE T0404    */
         /* TRANSITION:      T404                                                 */
         /* EVENT:           LMAC_BS_INFO_SEND_IND                                 */
         /* DESCRIPTION:     ISR level reports 'Bs channel data sent'             */
         /* STARTING STATE:  AI_ATAD_AT                                           */
         /* END STATE:       AI_ATAD_AT                                           */
         /* ----------------------------------------------------------------------*/
         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_BS_INFO_SEND_IND\n");
         BsCh_Paging_Response();
         break;

      case MAC_PAGE_CANCEL_LB:  /*  IN LINE CODE T0405    */
         /* TRANSITION:      T405                                                 */
         /* EVENT:           MAC_PAGE_CANCEL_LB                                       */
         /* DESCRIPTION:     Bs channel data request via Pt paging                */
         /* STARTING STATE:  AI_ATAD_AT                                           */
         /* END STATE:       AI_ATAD_AT                                           */
         /* ----------------------------------------------------------------------*/
         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_PAGE_CANCEL_LB\n");
         Discard_BsCh_Queue(TRUE);
         break;

      case MAC_ENABLE_VOICE_EXTERNAL_SWI:  /*  IN LINE CODE T0500    */
         {
            /* TRANSITION:      T500                                                 */
            /* EVENT:           MAC_ENABLE_VOICE_EXTERNAL_SWI                        */
            /* DESCRIPTION:     voice connection for external voice path             */
            /* PARAMETER:       P1: MCEI of the external connection                  */
            /*                  P2...P4: not used                                    */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            BYTE mcei;

            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_ENABLE_VOICE_EXTERNAL_SWI,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);

            mcei = value->Parameter1;
            if ( mcei < MAX_MCEI )
            {
               if ((Mcei_Table[mcei].Mbc_State == MBC_ST_EST) || 
                   #ifdef DECT_NG
                   (Mcei_Table[mcei].Mbc_State == MBC_ST_SM_INVOKING)  ||
                   (Mcei_Table[mcei].Mbc_State == MBC_ST_CM_HO)  ||
                   #endif
                   (Mcei_Table[mcei].Mbc_State == MBC_ST_HO))
               {
                  buffer.PROCID = LMAC;
                  buffer.MSG = LMAC_VOICE_EXTERNAL_REQ;
                  buffer.Parameter1 = mcei;
                  buffer.Parameter2 = NO_MCEI;
                  buffer.Parameter3 = value->Parameter3;
                  buffer.Parameter4 = ON;
                  Dect_SendtoLMAC(&buffer);
						{
						  #ifdef CONFIG_SMP4
      						unsigned long flags4;
								spin_lock_irqsave(&DECT_TAPI_Lock,flags4);
   					  #endif
                  	if( value->Parameter3 == 0 )  // JONATHAN : No need KPI Channel assignment for Data Call
                  	xMceiBuffer[mcei].iKpiChan = value->Parameter2;	/* Tapi channel setting  */
	
						   #ifdef CONFIG_SMP4
      						spin_unlock_irqrestore(&DECT_TAPI_Lock,flags4);
   						#endif
						}
                  
                  DECT_DEBUG_LOW_HMAC("EV %d %d %d\n", mcei, Mcei_Table[mcei].Mbc_State,xMceiBuffer[mcei].iKpiChan);
                  DECT_DEBUG_LOW_HMAC("%d %d %d %d %d %d\n", xMceiBuffer[0].iKpiChan, xMceiBuffer[1].iKpiChan, xMceiBuffer[2].iKpiChan, xMceiBuffer[3].iKpiChan, xMceiBuffer[4].iKpiChan, xMceiBuffer[5].iKpiChan);
               }
            }
         }
         break;

      case MAC_DISABLE_VOICE_EXTERNAL_SWI:  /*  IN LINE CODE T0501    */
         {
            /* TRANSITION:      T501                                                 */
            /* EVENT:           MAC_DISABLE_VOICE_EXTERNAL_SWI                       */
            /* DESCRIPTION:     voice disconnection for external voice path          */
            /* PARAMETER:       P1: MCEI of the external connection                  */
            /*                  P2...P4: not used                                    */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            BYTE mcei;
 
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_DISABLE_VOICE_EXTERNAL_SWI,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);

            mcei = value->Parameter1;
            if ( mcei < MAX_MCEI )
            {
               #if 0
               DECT_DEBUG_LOW_HMAC("DV %d %d\n", mcei, Tapi_Channel_array[mcei]);
               Tapi_Channel_array[mcei] = 0xFF;	/* Tapi channel clear  */
               #else
               DECT_DEBUG_LOW_HMAC("DV %d %d\n", mcei, xMceiBuffer[mcei].iKpiChan);
					{		
   					#ifdef CONFIG_SMP4
      					unsigned long flags4;
							spin_lock_irqsave(&DECT_TAPI_Lock,flags4);
   					#endif

               	xMceiBuffer[mcei].iKpiChan = 0xFF;	/* Tapi channel clear  */

   					#ifdef CONFIG_SMP4
      					spin_unlock_irqrestore(&DECT_TAPI_Lock,flags4);
   					#endif

					}
               #endif
               buffer.PROCID = LMAC;
               buffer.MSG = LMAC_VOICE_EXTERNAL_REQ;
               buffer.Parameter1 = mcei;
               buffer.Parameter2 = NO_MCEI;
               buffer.Parameter3 = value->Parameter3;
               buffer.Parameter4 = OFF;
               Dect_SendtoLMAC(&buffer);
              /*printk("%d %d %d %d %d %d\n", xMceiBuffer[0].iKpiChan, xMceiBuffer[1].iKpiChan, xMceiBuffer[2].iKpiChan, xMceiBuffer[3].iKpiChan, xMceiBuffer[4].iKpiChan, xMceiBuffer[5].iKpiChan);*/
            }
         }
         break;

      case MAC_ENABLE_VOICE_INTERNAL_SWI:  /*  IN LINE CODE T0502    */
         {
            /* TRANSITION:      T502                                                 */
            /* EVENT:           MAC_ENABLE_VOICE_INTERNAL_SWI                        */
            /* DESCRIPTION:     voice connection for internal voice path             */
            /* PARAMETER:       P1: MCEI of the one connection                       */
            /*                  P2: MCEI of the other connection                     */
            /*                  P3,P4: not used                                      */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            BYTE mcei_1, mcei_2;
 
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_ENABLE_VOICE_INTERNAL_SWI,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
 
            mcei_1 = value->Parameter1;
            mcei_2 = value->Parameter2;
            if ( (mcei_1<MAX_MCEI) && (mcei_2<MAX_MCEI) )
            {
              /* both MBC's must be established !  */
               if (((Mcei_Table[mcei_1].Mbc_State == MBC_ST_EST)||
                    #ifdef DECT_NG
                    (Mcei_Table[mcei_1].Mbc_State == MBC_ST_SM_INVOKING)  ||
                    (Mcei_Table[mcei_1].Mbc_State == MBC_ST_CM_HO)  ||
                    #endif
                    (Mcei_Table[mcei_1].Mbc_State == MBC_ST_HO)) &&
                   ((Mcei_Table[mcei_2].Mbc_State == MBC_ST_EST)||
                    #ifdef DECT_NG
                    (Mcei_Table[mcei_2].Mbc_State == MBC_ST_SM_INVOKING)  ||
                    (Mcei_Table[mcei_2].Mbc_State == MBC_ST_CM_HO)  ||
                    #endif
                    (Mcei_Table[mcei_2].Mbc_State == MBC_ST_HO)))
               {
                  /* Note: be aware of the internal    */
                  /* B field buffer selection !        */
                  buffer.PROCID = LMAC;
                  buffer.MSG = LMAC_VOICE_INTERNAL_REQ;
                  buffer.Parameter1 = mcei_1;
                  buffer.Parameter2 = mcei_2;
                  buffer.Parameter3 = NO_MCEI;
                  buffer.Parameter4 = ON;
                  Dect_SendtoLMAC(&buffer);
                  DECT_DEBUG_HIGH_LMAC_PRIMITIVE("LMAC_VOICE_INTERNAL_REQ, %02x %02x %02x %02x\n", buffer.Parameter1, buffer.Parameter2, buffer.Parameter3, buffer.Parameter4);
               }
            }
         }
         break;

      case MAC_DISABLE_VOICE_INTERNAL_SWI:  /*  IN LINE CODE T0503    */
         {
            /* TRANSITION:      T503                                                 */
            /* EVENT:           MAC_DISABLE_VOICE_INTERNAL_SWI                       */
            /* DESCRIPTION:     voice disconnection for internal voice path          */
            /* PARAMETER:       P1: MCEI of the connection to be disconnected voice  */
            /*                  P2,P3,P4: not used                                   */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            BYTE mcei_1;
 
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_DISABLE_VOICE_INTERNAL_SWI,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
 
            mcei_1 = value->Parameter1;
            if ( mcei_1 < MAX_MCEI )
            {
               if ((Mcei_Table[mcei_1].Mbc_State == MBC_ST_EST) || 
                   #ifdef DECT_NG
                   (Mcei_Table[mcei_1].Mbc_State == MBC_ST_SM_INVOKING)  ||
                   (Mcei_Table[mcei_1].Mbc_State == MBC_ST_CM_HO)  ||
                   #endif
                   (Mcei_Table[mcei_1].Mbc_State == MBC_ST_HO))
               {
                  buffer.PROCID = LMAC;
                  buffer.MSG = LMAC_VOICE_INTERNAL_REQ;
                  buffer.Parameter1 = mcei_1;
                  buffer.Parameter2 = NO_MCEI;
                  buffer.Parameter3 = NO_MCEI;
                  buffer.Parameter4 = OFF;
                  Dect_SendtoLMAC(&buffer);
               }
            }
         }
         break;

      case MAC_ENABLE_VOICE_CONFERENCE_SWI:  /*  IN LINE CODE T0504    */
         {
            /* TRANSITION:      T504                                                 */
            /* EVENT:           MAC_ENABLE_VOICE_CONFERENCE_SWI                       */
            /* DESCRIPTION:     voice connection for external voice path             */
            /* PARAMETER:       P1: MCEI of the external connection                  */
            /*                  P2...P4: not used                                    */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            BYTE mcei_1, mcei_2;
 
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_ENABLE_VOICE_CONFERENCE_SWI,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
 
            mcei_1 = value->Parameter1;
            mcei_2 = value->Parameter2;
            if ( (mcei_1<MAX_MCEI) && (mcei_2<MAX_MCEI) )
            {
               /* both MBC's must be established !  */
               if (((Mcei_Table[mcei_1].Mbc_State == MBC_ST_EST) ||
                    #ifdef DECT_NG
                    (Mcei_Table[mcei_1].Mbc_State == MBC_ST_SM_INVOKING)  ||
                    (Mcei_Table[mcei_1].Mbc_State == MBC_ST_CM_HO)  ||
                    #endif
                    (Mcei_Table[mcei_1].Mbc_State == MBC_ST_HO))  &&
                   ((Mcei_Table[mcei_2].Mbc_State == MBC_ST_EST) ||
                    #ifdef DECT_NG
                    (Mcei_Table[mcei_2].Mbc_State == MBC_ST_SM_INVOKING)  ||
                    (Mcei_Table[mcei_2].Mbc_State == MBC_ST_CM_HO)  ||
                    #endif
                    (Mcei_Table[mcei_2].Mbc_State == MBC_ST_HO)))
               {
                  /* Note: be aware of the internal    */
                  /* B field buffer selection !        */
                  buffer.PROCID = LMAC;
                  buffer.MSG = LMAC_VOICE_CONFERENCE_REQ;
                  buffer.Parameter1 = mcei_1;
                  buffer.Parameter2 = mcei_2;
                  buffer.Parameter3 = NO_MCEI;
                  buffer.Parameter4 = ON;
                  Dect_SendtoLMAC(&buffer);
               }
            }
         }
         break;

      case MAC_DISABLE_VOICE_CONFERENCE_SWI:  /*  IN LINE CODE T0505    */
         {
            /* TRANSITION:      T505                                                 */
            /* EVENT:           MAC_DISABLE_VOICE_CONFERENCE_SWI                      */
            /* DESCRIPTION:     voice disconnection for conference voice path        */
            /* PARAMETER:       P1: MCEI of the one connection                       */
            /*                  P2: MCEI of the other connection                     */
            /*                  P3,P4: not used                                      */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            BYTE mcei_1, mcei_2;

            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_DISABLE_VOICE_CONFERENCE_SWI,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);

            mcei_1 = value->Parameter1;
            mcei_2 = value->Parameter2;

            /* related MBC's must be established !  */
            if ((Mcei_Table[mcei_1].Mbc_State == MBC_ST_EST) ||
                #ifdef DECT_NG
                (Mcei_Table[mcei_1].Mbc_State == MBC_ST_SM_INVOKING)  ||
                (Mcei_Table[mcei_1].Mbc_State == MBC_ST_CM_HO)  ||
                #endif
                (Mcei_Table[mcei_1].Mbc_State == MBC_ST_HO) )
            {
               mcei_1 = NO_MCEI;
            }
            
            if ((Mcei_Table[mcei_2].Mbc_State == MBC_ST_EST) ||
                #ifdef DECT_NG
                (Mcei_Table[mcei_2].Mbc_State == MBC_ST_SM_INVOKING)  ||
                (Mcei_Table[mcei_2].Mbc_State == MBC_ST_CM_HO)  ||
                #endif
                (Mcei_Table[mcei_2].Mbc_State == MBC_ST_HO) )
            {
               mcei_2 = NO_MCEI;
            }
            
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_VOICE_CONFERENCE_REQ;
            buffer.Parameter1 = mcei_1;
            buffer.Parameter2 = mcei_2;
            buffer.Parameter3 = NO_MCEI;
            buffer.Parameter4 = OFF;
            Dect_SendtoLMAC(&buffer);
         }
         break;

      case MAC_ENC_KEY_RQ_LC:  /*  IN LINE CODE T6000    */
         {
            /* TRANSITION:      T6000                                                 */
            /* EVENT:           MAC_ENC_KEY_RQ_LC                                    */
            /* DESCRIPTION:     Encryption key provision                             */
            /* REFERENCE:       ETS 300 175-3:1996                                   */
            /* STARTING STATE:  LINK_ESTABLISHED                                     */
            /* END STATE:       LINK_ESTABLISHED                                     */
            /* ----------------------------------------------------------------------*/
            /* MCEI is transferred in           */
            /* Parameter1                       */
            BYTE mcei;

            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_ENC_KEY_RQ_LC,, %02x\n", value->Parameter1);

            mcei = value->Parameter1;
            if ( mcei < MAX_MCEI )
            {
         #ifdef CONFIG_REPEATER_SUPPORT
            if (Mcei_Table[mcei].Mbc_State == MBC_ST_EST) {
               Load_Encryption_Key(value->G_PTR_buf, mcei);
               // Transfer to LMAC to be used for further encryption!!!
               buffer.PROCID = LMAC;
               buffer.MSG = LMAC_ENC_KEY_REQ;
               buffer.Parameter1 = mcei;
               buffer.Parameter2 = Mcei_Table[mcei].lbn_1;
               buffer.Parameter3 = Mcei_Table[mcei].lbn_2;
               buffer.Parameter4 = 0;
               memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
               Dect_SendtoLMAC(&buffer);
            }
            else if (
                     #ifdef DECT_NG
                     (Mcei_Table[mcei].Mbc_State == MBC_ST_SM_INVOKING) ||
                     (Mcei_Table[mcei].Mbc_State == MBC_ST_CM_HO) ||
                     #endif
                     (Mcei_Table[mcei].Mbc_State == MBC_ST_HO)) {
               if (Rep_Table[Mcei_Table[mcei].EncLbn].Rep_Cntr == 1) {
                  Load_Encryption_Key(value->G_PTR_buf, mcei);
               }
               // Transfer to LMAC to be used for further encryption!!!
               buffer.PROCID = LMAC;
               buffer.MSG = LMAC_ENC_KEY_REQ;
               buffer.Parameter1 = mcei;
               buffer.Parameter2 = Mcei_Table[mcei].EncLbn;
               buffer.Parameter3 = NO_LBN;
               buffer.Parameter4 = 1;
               memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
               Dect_SendtoLMAC(&buffer);
            }
         #else
               if ((Mcei_Table[mcei].Mbc_State == MBC_ST_EST)||
                   #ifdef DECT_NG
                   (Mcei_Table[mcei].Mbc_State == MBC_ST_SM_INVOKING)  ||
                   (Mcei_Table[mcei].Mbc_State == MBC_ST_CM_HO)  ||
                   #endif
                   (Mcei_Table[mcei].Mbc_State == MBC_ST_HO))
               {
                  Load_Encryption_Key(value->G_PTR_buf, mcei);
                  // Transfer to LMAC to be used for further encryption!!!
                  buffer.PROCID = LMAC;
                  buffer.MSG = LMAC_ENC_KEY_REQ;
                  buffer.Parameter1 = mcei;
                  buffer.Parameter2 = Mcei_Table[mcei].lbn_1;
                  buffer.Parameter3 = Mcei_Table[mcei].lbn_2;
                  buffer.Parameter4 = 0;
                  memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
                  Dect_SendtoLMAC(&buffer);
               }
         #endif
            }
         }
         break;

      case LMAC_ENC_EKS_IND_SUCCEED:  /*  IN LINE CODE T6002    */
         {
            /* TRANSITION:      T6002                                                */
            /* EVENT:           LMAC_ENC_EKS_IND_SUCCEED                                   */
            /* DESCRIPTION:     Encryption mode confirmation                         */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            /*
             * P1: LBN
             * P2: MCEI
             * P3: n.u., 0 or early encryption, normal(0) / early(1)
             * P4: encryption mode, clear(0) / encrypt(1)
             */

            BYTE lbn;
            BYTE mcei;

            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_ENC_EKS_IND_SUCCEED,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);

            lbn = value->Parameter1;
            mcei = value->Parameter2;
            if ((Mcei_Table[mcei].Mbc_State == MBC_ST_EST)||
                #ifdef DECT_NG
                (Mcei_Table[mcei].Mbc_State == MBC_ST_SM_INVOKING)  ||
                (Mcei_Table[mcei].Mbc_State == MBC_ST_CM_HO)  ||
                #endif
                (Mcei_Table[mcei].Mbc_State == MBC_ST_HO))
            {
               /* P1:  TRUE / FALSE                */
               /* P4:  Crypt Mode / Clear Mode     */
               #ifdef CONFIG_EARLY_ENCRYPTION
               if (value->Parameter3 != YES)
               #endif
               {
                 buffer.PROCID = LC;
                 buffer.MSG = LC_ENC_EKS_IND_MAC;
                 buffer.Parameter1 = TRUE;
                 buffer.Parameter2 = 0;
                 buffer.Parameter3 = 0;
                 buffer.Parameter4 = value->Parameter4;
                 buffer.CurrentInc= mcei;
                 Dect_SendtoStack(&buffer);
               }
               #ifdef CONFIG_EARLY_ENCRYPTION
               Mcei_Table[mcei].Enc_State = value->Parameter4;
               #else
               Mcei_Table[mcei].Enc_State = TRUE;
               #endif
            }
         }
         break;

      case LMAC_ENC_EKS_IND_FAIL:  /*  IN LINE CODE T6003    */
         {
            /* TRANSITION:      T6003                                                */
            /* EVENT:           LMAC_ENC_EKS_IND_FAIL                                 */
            /* DESCRIPTION:     Encryption mode setting failure                      */
            /* STARTING STATE:  AI_ATAD_AT                                           */
            /* END STATE:       AI_ATAD_AT                                           */
            /* ----------------------------------------------------------------------*/
            BYTE lbn;
            BYTE mcei;
            /* P1: LBN                          */
            /* P2: MCEI                         */

            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_ENC_EKS_IND_FAIL,, %02x %02x\n", value->Parameter1, value->Parameter2);

            lbn = value->Parameter1;
            mcei = value->Parameter2;
            /* After unsuccessful cipher        */
            /* switching, the link must be      */
            /* released !                       */

            /* P1: lbn                                */
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_TB_RELEASE_REQ;
            buffer.Parameter1 = lbn;
            Dect_SendtoLMAC(&buffer);
            Mcei_Table[mcei].Enc_State = FALSE;
         }
         break;

      case MAC_SLOTTYPE_MOD_RQ_SWI:  /*  IN LINE CODE T6100    */
         {
            /* TRANSITION:      T6100                                                 */
            /* EVENT:           MAC_SLOTTYPE_MOD_RQ_SWI                                     */
            /* DESCRIPTION:     SLOT TYPE  setting                            */
            /* REFERENCE:       ETS 300 175-5:1996                                   */
            /* PARAMETER:       P1: MCEI                                        */
            /*                  P2: not used                                         */
            /*                  P3: not used                                         */
            /*                  P4: go long_slot(WBS)/go full slot(NBS)                             */
            /* STARTING STATE:  FREE                                                 */
            /* END STATE:       FREE                                                 */
            /* ----------------------------------------------------------------------*/
            #ifdef DECT_NG
            BYTE lbn;
            BYTE mcei;
            /* Request Encryption mode setting  */
            /* ---------------------------------*/
            /* P1: MCEI                         */
            /* P2: not used                     */
            /* P3: not used                     */
            /* P4: go long_slot(WBS)/go full slot(NBS)         */
            
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_SLOTTYPE_MOD_RQ_SWI,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
            
            mcei = value->Parameter1;	// hiryu_20071220
            lbn = Get_Lbn_of_only_TB(mcei);
            switch ( Mcei_Table[mcei].Mbc_State )
            {
               case MBC_ST_EST:
                  buffer.PROCID = LMAC;
                  buffer.MSG = LMAC_MOD_REQ;
                  buffer.Parameter1 = mcei;
                  buffer.Parameter2 = lbn;
                  buffer.Parameter4 = value->Parameter4;
                  Dect_SendtoLMAC(&buffer);
            
                  if( value->Parameter4)
                     Mcei_Table[mcei].Mbc_State = MBC_ST_SM_INVOKING; //Slot type Modification

                  Mcei_Table[mcei].wbs_req = value->Parameter4;
                  break;

               default:
                  Mcei_Table[mcei].wbs_req = value->Parameter4;
                  break;
            }
            #endif
         }
         break;

      case LMAC_MOD_CFM:  /*  IN LINE CODE T6101    */
         {
            /* TRANSITION:      T6101                                                */
            /* EVENT:           MAC_SLOTTYPE_MOD_CFM_HMAC                                     */
            /* DESCRIPTION:     SLOT TYPE  setting confirmation                              */
            /* REFERENCE:       ETS 300 175-4:1996                                   */
            /* PARAMETER:       P1: not used                                         */
            /*                  P2: success/failure                                  */
            /*                  P3: not used                                         */
            /*                  P4: not used                                         */
            /* REMARK:                                                               */
            /************************************************************************/
            #ifdef DECT_NG
            BYTE lbn;
            BYTE mcei;
            /* P1: LBN                          */
            /* P2: MCEI                         */
            /* P3: slot_type                  */
            /* P4: success/failure.                          */
            
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_MOD_CFM,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
            
            lbn = value->Parameter1;
            mcei = value->Parameter2;
            
            /* Confirm Slottype modification  */
            /* ---------------------------------*/
            /* P1: Logical Connection No (LCN)  */
            /* P2: MCEI                    */
            /* P3: Slot_type                     */
            /* P4: success(1)/failure(0)             */
            
            /* it is  special interface */
            /* hmac --> app    derect send command */
            buffer.PROCID = PROCMAX;
            buffer.MSG = FP_SLOTTYPE_MOD_IN_MAC_TO_APP;
            buffer.Parameter1 = mcei;
            
            if(value->Parameter3)
               buffer.Parameter3 = 1; // slot type
            else
               buffer.Parameter3 = 0; // slot type

            buffer.Parameter4 = value->Parameter4;	// success / fail
            buffer.CurrentInc= mcei;
            Dect_SendtoStack(&buffer);
            
            #if 1  // SLOTTYPE_MOD_FIX
            if( value->Parameter4 == 0 )
               Mcei_Table[mcei].Mbc_State = MBC_ST_EST;     // Change Back to original
            #endif
            
            #endif
         }
         break;

      case MAC_A44_SET_RQ_ME:  /*  IN LINE CODE T7000    */
         {
            /* TRANSITION:      T7000                                                */
            /* EVENT:           MAC_A44_SET_RQ_ME                                    */
            /* DESCRIPTION:     The FT starts supporting 'access rights requests'.   */
            /* PARAMETER:       none                                                 */
            /* REFERENCE:       ETS 300175-5, annex F1                               */
            /* REMARKS:          Forward to LMAC                    .                  */
            /* ----------------------------------------------------------------------*/
            /* the MAC is requested to set/clear A44 mode   */
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_A44_SET_RQ_ME,, %02x\n", value->Parameter1);
            
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_A44_SET_REQ;
            buffer.Parameter1 = value->Parameter1;
            Dect_SendtoLMAC(&buffer);
         }
         break;

      case MAC_TBR6_MODE_RQ_ME:  /*  IN LINE CODE T7001    */
         {
            /* TRANSITION:      T7001                                                */
            /* EVENT:           MAC_TBR6_MODE_RQ_ME                                    */
            /* DESCRIPTION:     The FT starts supporting 'tbr6 test mode'.   */
            /* PARAMETER:       none                                                 */
            /* REFERENCE:                                                                       */
            /* REMARKS:          Forward to LMAC                    .                  */
            /* ----------------------------------------------------------------------*/
            /* the MAC is requested to set/clear TBR6 mode   */
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_TBR6_MODE_RQ_ME,, %02x\n", value->Parameter1);
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_TBR6_MODE_REQ;
            buffer.Parameter1 = value->Parameter1;
            Dect_SendtoLMAC(&buffer);
         }
         break;

      case MAC_BOOT_RQ_ME:  /*  IN LINE CODE T8000    */
         {
            /* TRANSITION:      T8000                                                */
            /* EVENT:           MAC_BOOT_RQ_ME                                    */
            /* DESCRIPTION:     The FT boot LMAC */
            /* PARAMETER:       none                                                 */
            /* REFERENCE:                                                                       */
            /* REMARKS:          Forward to LMAC                    .                  */
            /* ----------------------------------------------------------------------*/
            /* the MAC is requested to boot LMAC */
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_BOOT_RQ_ME,, %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3);

            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_BOOT_REQ;
            buffer.Parameter1 = value->Parameter1;
            buffer.Parameter2 = value->Parameter2;
            buffer.Parameter3 = value->Parameter3;
            memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
            Dect_SendtoLMAC(&buffer);
         }
         break;

      case MAC_PARAMETER_PRELOAD_RQ_ME:  /*  IN LINE CODE T8001    */
         {
            /* TRANSITION:      T8001                                                */
            /* EVENT:           MAC_PARAMETER_PRELOAD_RQ_ME                                    */
            /* DESCRIPTION:     The FT load the LMAC parmaters   */
            /* PARAMETER:       none                                                 */
            /* REFERENCE:                                                                       */
            /* REMARKS:          Forward to LMAC                    .                  */
            /* ----------------------------------------------------------------------*/
            /* the MAC is requested to forward LMAC parameters */
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_PARAMETER_PRELOAD_RQ_ME,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);

            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_PARAMETER_PRELOAD_REQ;
            buffer.Parameter1 = value->Parameter1;
            buffer.Parameter2 = value->Parameter2;
            buffer.Parameter3 = value->Parameter3;
            buffer.Parameter4 = value->Parameter4;
            memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
			
			if(buffer.G_PTR_buf[3] & 0x20)
			{
					//printk("\nCosic driver: CoC enabled Antannae setting recvd\n");
					ucDECT_CoCMode = 1;
					gw_stats.uiCoCReqFromModem=0;
			}
			else
			{
					//printk("\nCosic driver: CoC disabled Antannae setting recvd\n");
					ucDECT_CoCMode = 0;
					gw_stats.uiCoCReqFromModem=0;
			}
			
            Dect_SendtoLMAC(&buffer);

            #if 1  // LOW_DUTY_SUPPORT
            if( (value->G_PTR_buf[ 4 ] & 0x80) == 0x80 )
               LowDuty_Support = TRUE;
            else
               LowDuty_Support = FALSE;
            #endif

#ifdef CONFIG_SMP
				{
					unsigned long flags;
   				spin_lock_irqsave(&IntEdgFlgLock,flags);
#endif
            	iDriverStatus = LMAC_BOOT_IND;	
#ifdef CONFIG_SMP
   			spin_unlock_irqrestore(&IntEdgFlgLock,flags);
				}
#endif
            #ifdef SUPERTASK
            iModemRestartCount++;
            #endif
         }
         break;

      case MAC_OSC_SET_RQ_ME:  /*  IN LINE CODE T8002    */
         {
            /* TRANSITION:      T8002                                                */
            /* EVENT:           MAC_OSC_SET_RQ_ME                                    */
            /* DESCRIPTION:     The FT boot LMAC */
            /* PARAMETER:       none                                                 */
            /* REFERENCE:                                                                       */
            /* REMARKS:          Forward to LMAC                    .                  */
            /* ----------------------------------------------------------------------*/
            /* the MAC is requested to boot LMAC */
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_OSC_SET_RQ_ME,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
 
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_OSC_SET_REQ;
            buffer.Parameter1 = value->Parameter1;
            buffer.Parameter2 = value->Parameter2;
            buffer.Parameter3 = value->Parameter3;
            buffer.Parameter4 = value->Parameter4;
            Dect_SendtoLMAC(&buffer);
         }
         break;

      case MAC_GFSK_SET_RQ_ME:  /*  IN LINE CODE T8003    */
         {
            /* TRANSITION:      T8003                                                */
            /* EVENT:           MAC_GFSK_SET_RQ_ME                                    */
            /* DESCRIPTION:     The FT boot LMAC */
            /* PARAMETER:       none                                                 */
            /* REFERENCE:                                                                       */
            /* REMARKS:          Forward to LMAC                    .                  */
            /* ----------------------------------------------------------------------*/
            /* the MAC is requested to boot LMAC */
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_GFSK_SET_RQ_ME,, %02x %02x\n", value->Parameter1, value->Parameter2);
            
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_GFSK_SET_REQ;
            buffer.Parameter1 = value->Parameter1;
            buffer.Parameter2 = value->Parameter2;
            Dect_SendtoLMAC(&buffer);
         }
         break;

      #ifdef CONFIG_EARLY_ENCRYPTION
      case MAC_DEFAULT_CK_SET_REQ:
         /*
            EVENT:       MAC_DEFAULT_CK_SET_REQ 
            DESCRIPTION: Send default CK to LMAC 
            PARAMETER:   Parameter1 - Portable number, 1 ~ 6
                         Parameter2 - Registration status, YES/NO
                         Parameter3 - Hi byte of default cipher key index
                         Parameter4 - Low byte of default cipher key index
                         G_PTR_buf  - default cipher key, 8 bytes
            REFERENCE:
            REMARKS:     Forward to LMAC
          */

         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_DEFAULT_CK_SET_REQ,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
   
         buffer.PROCID = LMAC;
         buffer.MSG = LMAC_DEFAULT_CK_SET_REQ;
         buffer.Parameter1 = value->Parameter1;
         buffer.Parameter2 = value->Parameter2;
         buffer.Parameter3 = value->Parameter3;
         buffer.Parameter4 = value->Parameter4;
         memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
         Dect_SendtoLMAC(&buffer);
         break;
      #endif

      case LMAC_OSC_GET_CFM:  /*  IN LINE CODE T8004    */
         {
            /* TRANSITION:      T8004                                                */
            /* EVENT:           LMAC_OSC_GET_CFM                                    */
            /* DESCRIPTION:     The FT boot LMAC */
            /* PARAMETER:       none                                                 */
            /* REFERENCE:                                                                       */
            /* REMARKS:          Forward to LMAC                    .                  */
            /* ----------------------------------------------------------------------*/
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_OSC_GET_CFM,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
         }
         break;

      case LMAC_GFSK_GET_CFM:  /*  IN LINE CODE T8005    */
         {
            /* TRANSITION:      T8005                                                */
            /* EVENT:           LMAC_GFSK_GET_CFM                                    */
            /* DESCRIPTION:     The FT boot LMAC */
            /* PARAMETER:       none                                                 */
            /* REFERENCE:                                                                       */
            /* REMARKS:          Forward to LMAC                    .                  */
            /* ----------------------------------------------------------------------*/
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_GFSK_GET_CFM,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
         }
         break;

      case MAC_FW_VERSION_IND_LMAC:  /*  IN LINE CODE T8006    */
         {
            /* TRANSITION:      T8006                                                */
            /* EVENT:           MAC_FW_VERSION_IND_LMAC                                    */
            /* DESCRIPTION:     The FT boot LMAC */
            /* PARAMETER:       none                                                 */
            /* REFERENCE:                                                                       */
            /* REMARKS:          Forward to LMAC                    .                  */
            /* ----------------------------------------------------------------------*/
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_FW_VERSION_IND_LMAC,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
         }
         break;
         
      #ifdef CATIQ_NOEMO
      case LMAC_NOEMO_IND:  /*  IN LINE CODE T8006    */
         {
            /* TRANSITION:                                                      */
            /* EVENT:           LMAC_NOEMO_IND                                    */
            /* DESCRIPTION:     The FT change noemo mode */
            /* PARAMETER:       Mode                                                  */
            /* REFERENCE:                                                                       */
            /* REMARKS:          Forward to LMAC                    .                  */
            /* ----------------------------------------------------------------------*/
            #define  MAC_NOEMOM_IDLE   0x00
            #define  MAC_NOEMOM_STOP   0x01
            #define  MAC_NOEMOM_START  0x02
            #define  MAC_NOEMOM_PEND   0x03
            #define  MAC_NOEMOM_ACTIV  0x04
            #define  MAC_NOEMOM_WAKEUP 0x05

            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_NOEMO_IND,, %02x %02x\n", value->Parameter1, value->Parameter2);

            buffer.PROCID = ME;
            buffer.MSG = ME_NOEMO_IN_MAC;
            buffer.Parameter1 = value->Parameter1; // NoEmo status 
            buffer.Parameter2 = value->Parameter2; // NoEmo Cn
            buffer.Parameter3 = 0;
            buffer.Parameter4 = 0;
            buffer.CurrentInc = 0;
            Dect_SendtoStack(&buffer);
         }
         break;

      case MAC_NOEMO_RQ_ME:  /*    */
         /* TRANSITION:                                                    */
         /* EVENT:           MAC_NOEMO_RQ_ME                                    */
         /* DESCRIPTION:     .   */
         /* PARAMETER:       none                                                 */
         /* REFERENCE:                               */
         /* REMARKS:          Forward to LMAC                    .                  */
         /* ----------------------------------------------------------------------*/
         /* the MAC is requested    */
         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_NOEMO_RQ_ME,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);

         buffer.PROCID = LMAC;
         buffer.MSG = LMAC_NOEMO_REQ;
         buffer.Parameter1 = value->Parameter1;
         buffer.Parameter2 = value->Parameter2;
         buffer.Parameter3 = value->Parameter3;
         buffer.Parameter4 = value->Parameter4;
         Dect_SendtoLMAC(&buffer);
         break;
      #endif

      // Qt Message Modification Request command
      case MAC_QT_SET_RQ_ME:
         {
            /* TRANSITION:                                                           */
            /* EVENT:           MAC_QT_SET_RQ_ME                                     */
            /* DESCRIPTION:     Qt Message Set                                       */
            /* PARAMETER:       Parameter1 = Qt Message Indicator                    */
            /* REMARK:          Forward to LMAC                                      */
            /* ----------------------------------------------------------------------*/
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_QT_SET_RQ_ME,, %02x\n", value->Parameter1);
           
            buffer.PROCID = LMAC;
            buffer.MSG = LMAC_QT_SET_REQ;
            buffer.Parameter1 = value->Parameter1;
            buffer.Parameter2 = value->Parameter2;
            buffer.Parameter3 = value->Parameter3;
            buffer.Parameter4 = value->Parameter4;
            memcpy( buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT );
            Dect_SendtoLMAC(&buffer);
            #if 1  // LOW_DUTY_SUPPORT
            if( value->Parameter1 == 1 )
            {
               if( (value->G_PTR_buf[ 1 ] & 0x10) == 0x10 )
                  LowDuty_Support = TRUE;
               else
                  LowDuty_Support = FALSE;
            }
            #endif
         }
         break;

      /* It one time when dect module booting */
      case LMAC_BOOT_IND:
         // TRANSITION:     T0701
         // EVENT:          LMAC_BOOT_IND
         // DESCRIPTION:    BMC ISR Level indicates that a Ct fragment has been
         //                 sent and acknowledged by the PT.
         // STARTING STATE: AI_ATAD_AT
         // END STATE:      AI_ATAD_AT
         // ------------------------------------------------------------------------
         /* the message is passed on to the	*/
         /* LC(PARAMETER1=mcei)				*/

         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_BOOT_IND,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);

         if(value->Parameter1 == 0x01)
         {
            buffer.PROCID = PROCMAX;
            buffer.MSG = STACK_INITAL_CMD;
            buffer.Parameter1 = value->Parameter2;
            buffer.Parameter2 = value->Parameter3;
            buffer.Parameter3 = value->Parameter4;
            buffer.Parameter4 = 0;
            memcpy(buffer.G_PTR_buf, value->G_PTR_buf, G_PTR_MAX_COUNT);
            Dect_SendtoStack(&buffer);

            buffer.PROCID = ME;
            buffer.MSG = ME_RFP_PRELOAD_DIS;
            Dect_SendtoStack(&buffer);

            DECT_DEBUG_HIGH_HMAC_INFO(printk("\n[HMAC] COSIC Modem Version: %1d.%02x.%02x\n", value->Parameter2, value->Parameter3, value->Parameter4));
            DECT_DEBUG_HIGH_HMAC_INFO(printk("[HMAC] COSIC Modem Sub-Version: %1c%1c%1c%1c%1c%1c%1c%1c%1c%1c\n",
                                             value->G_PTR_buf[0], value->G_PTR_buf[1], value->G_PTR_buf[2], value->G_PTR_buf[3], value->G_PTR_buf[4],
                                             value->G_PTR_buf[5], value->G_PTR_buf[6], value->G_PTR_buf[7], value->G_PTR_buf[8], value->G_PTR_buf[9]));
         }
         break;

         /* mac layer status check hiryu_20070911 insert */
      case MAC_STATUS_CHECK:
         break;

      case MAC_INIT_CMD:		/* clear HMAC STATUS   hiryu_20070911 */
         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_INIT_CMD\n");
         Discard_BsCh_Queue(FALSE);
         HMAC_INIT();
         //		Reset_Hmac_Debug_buffer();	
         break;

      case MAC_SOFT_RESET_RQ_LMAC:
         /* TRANSITION:	  										   */
         /* EVENT: 		  MAC_SOFT_RESET_RQ_LMAC									*/
         /* DESCRIPTION:	  SOFTWARE RESET  REQUESET  */
         /* PARAMETER: 	  none												   */
         /* REFERENCE: 																	  */
         /* REMARKS:							  . 				 */
         /* ----------------------------------------------------------------------*/
         /* the MAC is requested to boot LMAC */
         DECT_DEBUG_HIGH_HMAC_PRIMITIVE("MAC_SOFT_RESET_RQ_LMAC\n");
         buffer.PROCID = LMAC;
         buffer.MSG = LMAC_MODULE_RESET_REQ;
         Dect_SendtoLMAC(&buffer);
         break;

      case MAC_HARD_RESET_RQ_LMAC:
         #if 0
         ssc_dect_haredware_reset(0);
         printk("\nMAC_HARD_RESET_RQ_LMAC LOW\n");
         #ifdef LINUX
         udelay(1000);	// 1ms
         udelay(1000);	// 2ms
         udelay(1000);	// 3ms
         udelay(1000);	// 4ms
         udelay(1000);	// 5ms
         udelay(1000);	// 6ms
         udelay(1000);	// 7ms
         udelay(1000);	// 8ms
         udelay(1000);	// 9ms
         udelay(1000);	// 10ms
         #else
         sysUDelay(2000);	// 2ms
         #endif
         ssc_dect_haredware_reset(1);		
         printk("\nMAC_HARD_RESET_RQ_LMAC HIGH\n");
         #endif
         break;
   		
      case LMAC_DEBUG_MESSAGE_IND:
         /* EVENT:			LMAC_DEBUG_MESSAGE_IND	                             	*/
         /* DESCRIPTION: 		debug message indicator  							 	*/
         /* PARAMETER:		P1: main loop status								 	*/
         /*					P2: channel number(high nibble : wideband channel nuber,	*/
         /*			                                            low nibble : narrow band channel nuber)	*/				
         /*					P3: SPI Buffer Status(high nibble : SPI RX Buffer Cnt,		*/
         /*			                                            low nibble : SPI TX Buffer Cnt)			*/				
         /*					P4: not used										 */
         /* REMARK:															 */
         /************************************************************************/
         
         /* it is  special interface */
         /* hmac --> app    derect send command */
         #ifndef DECT_DEBUG_HIGH_HMAC_DEBUG_MESSAGE
         buffer.PROCID = PROCMAX;
         buffer.MSG = FP_DEBUG_MSG_IN_MAC_TO_APP;
         buffer.Parameter1 = value->Parameter1;
         buffer.Parameter2 = value->Parameter2;
         buffer.Parameter3 = value->Parameter3;
         buffer.Parameter4 = value->Parameter4;
         buffer.CurrentInc= value->CurrentInc;
         Dect_SendtoStack(&buffer);
         #else
         DECT_DEBUG_HIGH_HMAC_DEBUG_MESSAGE("LMAC_DEBUG_MESSAGE_IND,, %02x %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3, value->Parameter4);
         #endif
         break;
   				
      case LMAC_MOD_IND:
         // TRANSITION:	    T6102
         // EVENT:		    LMAC_MOD_IND
         // DESCRIPTION:    The BMC ISR level has inform a slot_type modification
         //                 proc will triggered by PP
         // STARTING STATE: IL_AL
         // END STATE:	    IL_AL
         // ----------------------------------------------------------------------
         #ifdef DECT_NG
         {
            /*
               P1: LBN
               P2: MCEI
               P3: slot_type
             */
            
            BYTE lbn;
            BYTE mcei;
            
            DECT_DEBUG_HIGH_HMAC_PRIMITIVE("LMAC_MOD_IND,, %02x %02x %02x\n", value->Parameter1, value->Parameter2, value->Parameter3);
            
            lbn = value->Parameter1;
            mcei = value->Parameter2;
            if( value->Parameter3 == MT_ATTRIBUTES_SLOT_TYPE_LONG ) {
               Mcei_Table[mcei].wbs_req = 1; 							// SLOT_MOD_FIX
               Mcei_Table[mcei].Mbc_State = MBC_ST_SM_INVOKING; //Slot type Modification
            }
         }
         #endif
         break;

      default:
         break;
   } // end of switch message
} // end of DECODE_HMAC()

