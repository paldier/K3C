/******************************************************************************

                              Copyright (c) 2009
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/
#ifndef DRV_DECT_COSIC_DRV_C
#define DRV_DECT_COSIC_DRV_C

/* =======================================================================
 * Include Files
 * ======================================================================= */
#ifdef LINUX
//#include <linux/autoconf.h>
#include <linux/module.h>

#include <linux/kernel.h>   /* printk() */
#include <linux/slab.h>
#include <linux/fs.h>       /* everything... */
#include <linux/errno.h>    /* error codes */
#include <linux/types.h>    /* size_t */
#include <linux/init.h>
#include <linux/proc_fs.h>
#include <linux/poll.h>
#include <linux/ioport.h>
#include <linux/vmalloc.h>
#include <linux/delay.h>
#include <linux/sched.h>
#include <linux/param.h>
#include <linux/timer.h>
#include <linux/ctype.h>
#include <linux/interrupt.h>
#include <linux/version.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <generated/autoconf.h>
//#include <asm/semaphore.h>
#include <asm/irq.h>
#include <linux/unistd.h>
#ifdef CONFIG_LTT
#include <linux/marker.h>
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
	#include <linux/irq.h>
	#include <linux/interrupt.h>
	#include <lantiq_soc.h>
	#ifdef DECT_USE_USIF
		#include <lantiq_usif_spi.h>
	#else
		 #include <lantiq_ssc.h>
	#endif
	#include <lantiq_irq.h>
	#include <linux/gpio.h> 
#else 
	#ifdef DECT_USE_USIF
		#include <ltq_usif_spi.h> 
	#else
		#include <ltq_ssc.h>
	#endif 
#endif 

#ifdef CONFIG_AMAZON_S

#include <asm/amazon_s/amazon_s.h>
#include <asm/amazon_s/irq.h>

#elif defined(CONFIG_DANUBE)


#include <asm-mips/ifx/danube/danube.h>
#include <asm-mips/ifx/danube/irq.h>
#include <asm-mips/ifx/ifx_gpio.h>
#include <asm-mips/ifx/ifx_led.h>
#include<asm-mips/ifx/ifx_gptu.h>
static const int dect_gpio_module_id = IFX_GPIO_MODULE_DECT;
#elif defined CONFIG_AR10
#include <ar10/ar10.h>
#include <ar10/irq.h>
#include <ltq_gpio.h>
static const int dect_gpio_module_id = IFX_GPIO_MODULE_DECT;


#elif defined CONFIG_AR9

#include <ar9/ar9.h>
#include <ar9/irq.h>
#include <ltq_gpio.h>

static const int dect_gpio_module_id = IFX_GPIO_MODULE_DECT;
#elif defined CONFIG_VR9
#include <vr9/vr9.h>
#include <vr9/irq.h>
#include <ltq_gpio.h>

static const int dect_gpio_module_id = IFX_GPIO_MODULE_DECT;
#endif	
#include "ifx_types.h"
//#include "ifx_common_defs.h"
#include "drv_timer.h"
#ifdef CONFIG_SMP 
#include <asm/spinlock.h>
#endif
#endif /* LINUX */
#ifdef SUPERTASK
#include "local.h"
#ifdef _INFXR9
#include "vr9.h"
#include "vr9_hw.h"
#include "irq.h"
#include "ifx_gpio.h"
#define __udelay__  sysUDelay
#else
#include "danube_addrspace.h"
#include "danube_hw.h"
#include "irq.h"
#endif

#include "ifx_ssc.h"
#include "ifxos_thread.h"
#include "drv_tapi_osmap.h"
#include "mtmacro.h"
#endif /* SUPERTASK */

#include "fmbc.h"
#include "drv_dect.h"
#include "drv_dect_cosic_drv.h"
#include "lib_bufferpool.h"
#include "drv_tapi_kpi_io.h"
#include "fdebug.h"
#define printk(...)   
/* =======================================================================
 * External Reference
 * ======================================================================= */
extern modem_dbg_stats modem_stats;
extern gw_dbg_stats gw_stats;
extern dect_version version;
extern modem_dbg_lbn_stats lbn_stats[6];
/* Interrupt number on which the dect notifies */
extern int dect_gpio_intnum;
extern BUFFERPOOL *pTapiWriteBufferPool;
extern unsigned char ucDECT_CoCMode;

#ifdef LINUX
extern atomic_t vuiGwDbgFlag;
extern int viDisableIrq;
extern int iIrqStatus;

extern int Dect_excpFlag;
extern wait_queue_head_t Dect_WakeupList;
extern IFX_SSC_HANDLE *spi_dev_handler;
#endif
#ifdef SUPERTASK
extern unsigned int vuiGwDbgFlag;
extern unsigned long lasttime_wdt_trig;
extern int  cosic_module_init;	//have to wait cosic related module ready...
extern IFX_SSC_HANDLE spi_dev_handler;
#endif

extern u32 ssc_dect_cs(u32 on, u32 cs_data);
extern void WriteDbgPkts(unsigned char debug_info_id, unsigned char rw_indicator, \
                           unsigned char CurrentInc, unsigned char *G_PTR_buf);

extern IFX_int32_t IFX_TAPI_KPI_ReadData( IFX_TAPI_KPI_CH_t nKpiGroup,
                                   IFX_TAPI_KPI_CH_t *nKpiChannel,
                                   void **pPacket,
                                   IFX_uint32_t *nPacketLength,
                                   IFX_uint8_t *nMore);
extern IFX_int32_t IFX_TAPI_KPI_WriteData( IFX_TAPI_KPI_CH_t nKpiChannel,
                                    void *pPacket,
                                    IFX_uint32_t nPacketLength);
#ifdef SUPERTASK
extern IFX_return_t IFX_TAPI_KPI_WaitForData( IFX_TAPI_KPI_CH_t nKpiGroup );
#endif

/* =======================================================================
 * Definitions
 * ======================================================================= */
#ifdef SUPERTASK
// Compilation Options
// -------------------
#define USE_PLC_BIT
#define DEBUG_INFOMATION_VIA_SPI
#define VOICE_CYCLIC_INDEX_CHECK
#define TRACE_BACK 0
/* Can't define in VR9 project */
#ifdef _INFXR9
//#define VOICE_DATA_NIBBLE_SWAP
#else
//#define VOICE_DATA_NIBBLE_SWAP
#endif
#endif

// Constants
// ---------
#define COSIC_RX_HEADER_LEN 8
   
#define WIDEBAND_PKT_LENGTH  80
#define NARROWBAND_PKT_LENGTH  40
   
#define WIDEBAND_PKT  3
#define NARROWBAND_PKT  0
   
#define VOICE_HEADER_LENGTH 6
   
#define FIRST_BYTE_FROM_MODEM_LOADER_MODE 0x55
#define FIRST_BYTE_FROM_MODEM_APP_MODE 0xAA

#ifdef SUPERTASK
#define DECT_STACK_WAITGROUP_ID	3
#define DRIVER_STACK_EVT		0x0002
#define DBG_STACK_EVT			0x0004
#endif

// Macros
// ------
#ifdef LINUX

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
	extern int DECT_IRQ_NUM,IFX_DECT_RST;
	#define ACKNOWLEDGE_IRQ 
	#define CONFIGURE_FALLING_EDGE_INT  irq_set_irq_type(DECT_IRQ_NUM, IRQ_TYPE_EDGE_FALLING)
	#define CONFIGURE_RISING_EDGE_INT   irq_set_irq_type(DECT_IRQ_NUM, IRQ_TYPE_EDGE_RISING)


#elif defined CONFIG_DANUBE
   /*GPT register values*/
#define GPT_INT_NODE_EN_REG 0xBE100aF4
#define GPT_INT_NODE_CTRL_REG 0xBE100aFC
#define GPT_CTRL_REG_COUNTER_2A 0xBE100a30
#define GPT_RELOAD_REG_2A 0xBE100a40
#define GPT_RUN_REG_2A 0xBE100a38
   
   
#define ACKNOWLEDGE_IRQ                         \
   do {                                                     \
      /* ack GPTC 2A IRQ */                                 \
      *(unsigned long *) GPT_INT_NODE_CTRL_REG = 0x00000004;           \
      /* reload GPTC 2A with initial value. in our case with 1*/                                  \
      *(unsigned long *) GPT_RUN_REG_2A = 0x00000005;           \
   } while (0)
   
#define CONFIGURE_FALLING_EDGE_INT *(unsigned long *) GPT_CTRL_REG_COUNTER_2A = 0x0000008C
#define CONFIGURE_RISING_EDGE_INT *(unsigned long *) GPT_CTRL_REG_COUNTER_2A = 0x0000004C
   
#elif defined CONFIG_AR9
#define ACKNOWLEDGE_IRQ  gp_onu_gpio_write_with_bit_mask((unsigned long *)IFX_ICU_EIU_INC, (8),(8))
   
#define CONFIGURE_FALLING_EDGE_INT  \
               *(unsigned long *) IFX_ICU_EIU_EXIN_C &= 0xFFFF0FFF; \
               *(unsigned long *) IFX_ICU_EIU_EXIN_C |= 0x2000
   
#define CONFIGURE_RISING_EDGE_INT  \
               *(unsigned long *) IFX_ICU_EIU_EXIN_C &= 0xFFFF0FFF; \
               *(unsigned long *) IFX_ICU_EIU_EXIN_C |= 0x1000
   
#elif defined(CONFIG_VR9)||defined(CONFIG_AR10)
#define ACKNOWLEDGE_IRQ  gp_onu_gpio_write_with_bit_mask((unsigned long *)IFX_ICU_EIU_INC, (0x32),(0x32))
   
#define CONFIGURE_FALLING_EDGE_INT  \
               *(unsigned long *) IFX_ICU_EIU_EXIN_C &= 0xFF0FFFFF; \
               *(unsigned long *) IFX_ICU_EIU_EXIN_C |= 0x200000
   
#define CONFIGURE_RISING_EDGE_INT  \
               *(unsigned long *) IFX_ICU_EIU_EXIN_C &= 0xFF0FFFFF;  \
               *(unsigned long *) IFX_ICU_EIU_EXIN_C |= 0x100000
   
#elif defined CONFIG_AMAZON_S
#define ACKNOWLEDGE_IRQ gp_onu_gpio_write_with_bit_mask((unsigned long *)AMAZON_S_ICU_EIU_INC, (8),(8))
#endif


#endif /* LINUX */


#ifdef SUPERTASK
#ifdef _INFXR9
#define ACKNOWLEDGE_IRQ  \
	gp_onu_gpio_write_with_bit_mask((unsigned long *)IFX_ICU_EIU_INC, (0x02),(0x02));

#define CONFIGURE_FALLING_EDGE_INT  \
				*(unsigned long *) IFX_ICU_EIU_EXIN_C &= 0xFFFFFF0F; \
				*(unsigned long *) IFX_ICU_EIU_EXIN_C |= 0x20

#define CONFIGURE_RISING_EDGE_INT  \
				*(unsigned long *) IFX_ICU_EIU_EXIN_C &= 0xFFFFFF0F; \
				*(unsigned long *) IFX_ICU_EIU_EXIN_C |= 0x10
#else
#define ACKNOWLEDGE_IRQ  gp_onu_gpio_write_with_bit_mask((unsigned long *)DANUBE_ICU_EIU_INC, (4),(4))

#define CONFIGURE_FALLING_EDGE_INT  \
				*(unsigned long *) DANUBE_ICU_EIU_EXIN_C &= 0xFFFFF0FF; \
				*(unsigned long *) DANUBE_ICU_EIU_EXIN_C |= 0x200

#define CONFIGURE_RISING_EDGE_INT  \
				*(unsigned long *) DANUBE_ICU_EIU_EXIN_C &= 0xFFFFF0FF; \
				*(unsigned long *) DANUBE_ICU_EIU_EXIN_C |= 0x100
#endif
#endif /* SUPERTASK */

#ifdef LINUX      
#ifdef USE_VOICE_BUFFERPOOL
#define BUFFER_POOL_PUT IFX_TAPI_VoiceBufferPut
#else
#define BUFFER_POOL_PUT  bufferPoolPut
#endif
#endif /* LINUX */
#ifdef SUPERTASK
#ifdef USE_VOICE_BUFFERPOOL
	#define BUFFER_POOL_PUT(x) if(x!=NULL) IFX_TAPI_VoiceBufferPut(x)
#else
	#define BUFFER_POOL_PUT(x)  if(x!=NULL) bufferPoolPut(x)
#endif
#endif /* SUPERTASK */

#ifdef LINUX
/*enable the debug in Makefile by passing IFX_COSIC_DEBUG flag*/
#ifdef IFX_COSIC_DEBUG
  #define IFX_COSIC_DMSG(fmt, args...) printk(KERN_INFO "[%s %d]: "fmt,__func__, __LINE__, ##args)
#else
  #define IFX_COSIC_DMSG(fmt, args...)
#endif
#endif /* LINUX */
#ifdef SUPERTASK
#define IFX_COSIC_DMSG cosic_printf
#endif /* SUPERTASK */

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */
typedef struct
{
   int pid;
   unsigned long jiffies;
} my_sched_info_t;

/* =======================================================================
 * Local Variables
 * ======================================================================= */
/* Structure maintaining Mapping between LMAC and HMAC */
static unsigned char Message_Map_Table[][2] = 
{
  {LMACCmd_BOOT_RQ_HMAC,                     LMAC_BOOT_REQ},
  {HMACCmd_BOOT_IND_LMAC,                    LMAC_BOOT_IND},
  {LMACCmd_PARAMETER_PRELOAD_RQ_HMAC,        LMAC_PARAMETER_PRELOAD_REQ},
  
  {LMACCmd_GFSK_VALUE_READ_RQ_HMAC,          LMAC_GFSK_GET_REQ},
  {HMACCmd_GFSK_VALUE_READ_IND_LMAC,         LMAC_GFSK_GET_CFM},
  {LMACCmd_GFSK_VALUE_WRITE_RQ_HMAC,         LMAC_GFSK_SET_REQ},
  {LMACCmd_OSC_VALUE_READ_RQ_HMAC,           LMAC_OSC_GET_REQ},
  {HMACCmd_OSC_VALUE_READ_IND_LMAC,          LMAC_OSC_GET_CFM},
  {LMACCmd_OSC_VALUE_WRITE_RQ_HMAC,          LMAC_OSC_SET_REQ},
  {HMACCmd_SLOT_FRAME_IND_LMAC,              0xFF},  
  
  {LMACCmd_SEND_DUMMY_RQ_HMAC,               LMAC_DUMMY_SEND_REQ},	
  {LMACCmd_A44_SET_RQ_HMAC,                  LMAC_A44_SET_REQ},
  {LMACCmd_TBR6_TEST_MODE_RQ_HMAC,           LMAC_TBR6_MODE_REQ},
  {LMACCmd_Qt_MESSAGE_SET_RQ_HMAC,           LMAC_QT_SET_REQ},
  {LMACCmd_SWITCH_HO_TO_TB_RQ_HMAC,          LMAC_HO_SWITCH_TO_TB_REQ},
  
  {LMACCmd_PAGE_RQ_HMAC,                     LMAC_PAGE_REQ},/*LMAC_PAGE_REQ (HMAC)*/
  {LMACCmd_PAGE_CANCEL_RQ_HMAC,              LMAC_PAGE_CANCEL_REQ},/*MAC_PAGE_CNCL(HMAC)*/
  {HMACCmd_BS_INFO_SENT_LMAC,                LMAC_BS_INFO_SEND_IND},/*MAC_BS_INFO_SENT(LMAC)*/
#ifdef ULE_SUPPORT
  {LMACCmd_ULE_PAGE_RQ_HMAC,                 LMAC_ULE_PAGE_REQ },/*LMAC_ULE_PAGE_REQ (HMAC)*/
#endif
  
  {HMACCmd_ACCESS_RQ_LMAC,                   LMAC_MCEI_REQUEST_IND},/*MAC_MCEI_REQUEST(LMAC)*/
  {LMACCmd_ACCESS_CFM_HMAC,                  LMAC_MCEI_REQUEST_RES},/*MAC_MCEI_CONFIRM(HMAC)*/
  {HMACCmd_ESTABLISHED_IN_LMAC,              LMAC_TB_ESTABLISHE_IND},
  {LMACCmd_RELEASE_TBC_RQ_HMAC,              LMAC_TB_RELEASE_REQ},
  {HMACCmd_RELEASE_TBC_IN_LMAC,              LMAC_TB_RELEASE_IND},/*MAC_RELEASED_TB(LMAC)*/
  {HMACCmd_CO_DATA_DTR_LMAC,                 LMAC_CO_DTR_IND},/*MAC_CO_DATA_DTR(LMAC)*/
  {LMACCmd_CO_DATA_RQ_HMAC,                  LMAC_CO_DATA_REQ},/*LMAC_CO_DATA_REQ(HMAC)*/
  {HMACCmd_CO_DATA_IN_LMAC,                  LMAC_CO_DATA_IND},/*LMAC_CO_DATA_IND(LMAC)*/
  
  {LMACCmd_ENC_KEY_RQ_HMAC,                  LMAC_ENC_KEY_REQ},/*LMAC_ENC_KEY_REQ(HMAC)*/
  {HMACCmd_ENC_EKS_IND_LMAC,                 LMAC_ENC_EKS_IND_SUCCEED},/*LMAC_ENC_EKS_IND_SUCCEED(LMAC)*/
  {HMACCmd_ENC_EKS_FAIL_LMAC,                LMAC_ENC_EKS_IND_FAIL},/*MAC_ENC_EKS_FAIL(LMAC)*/ 
#ifdef CONFIG_EARLY_ENCRYPTION
  {LMACCmd_DEFAULT_CK_SET_RQ_HMAC,           LMAC_DEFAULT_CK_SET_REQ},
#endif

  {LMACCmd_VOICE_EXTERNAL_HMAC,              LMAC_VOICE_EXTERNAL_REQ},
  {LMACCmd_VOICE_INTERNAL_HMAC,              LMAC_VOICE_INTERNAL_REQ},
  {LMACCmd_VOICE_CONFERENCE_HMAC,            LMAC_VOICE_CONFERENCE_REQ},/*MAC_CONF(HMAC)*/
  
  {LMACCmd_SLOTTYPE_MOD_RQ_HMAC,             LMAC_MOD_REQ},
  {HMACCmd_SLOTTYPE_MOD_CFM_LMAC,            LMAC_MOD_CFM},
  {HMACCmd_SLOTTYPE_MOD_TRIGGERED_LMAC,      LMAC_MOD_IND},
  
  {LMACCmd_MODULE_RESET_RQ_HMAC,             LMAC_MODULE_RESET_REQ},
  {HMACCmd_DEBUG_MESSAGE_IND_LMAC,           LMAC_DEBUG_MESSAGE_IND},
  
  {LMACCmd_NOEMO_RQ_HMAC,                    LMAC_NOEMO_REQ},/* "No-emission" mode procedures*/
  {HMACCmd_NOEMO_IND_LMAC,                   LMAC_NOEMO_IND},   
  {HMACCmd_DEBUGMSG_IN_LMAC,                 LMAC_DEBUGMSG_IND},   
  
#ifdef ULE_SUPPORT
  { HMACCmd_MAC_ULE_FU10_ACC_IN,             LMAC_ULE_FU10_ACC_IND},
  { HMACCmd_MAC_ULE_FU10_ACC_RDY_REL_IN,     LMAC_ULE_FU10_ACC_RDY_REL_IND},
  { LMACCmd_MAC_ULE_FU10_GFA_RQ,             LMAC_ULE_FU10_GFA_REQ},
  { HMACCmd_MAC_ULE_FU10_GFA_IN,             LMAC_ULE_FU10_GFA_IND},
  { LMACCmd_MAC_ULE_FU10_RDY_REL_RQ,         LMAC_ULE_FU10_RDY_REL_REQ},
  { HMACCmd_MAC_ULE_FU10_RDY_REL_IN,         LMAC_ULE_FU10_RDY_REL_IND},
  { LMACCmd_MAC_ULE_FU10_REL_RQ,             LMAC_ULE_FU10_REL_REQ},
  { HMACCmd_MAC_ULE_FU10_REL_IN,             LMAC_ULE_FU10_REL_IND},
  { LMACCmd_MAC_ULE_FU10_PAYLOAD_RQ,         LMAC_ULE_FU10_DATA_REQ},
  { HMACCmd_MAC_ULE_FU10_PAYLOAD_IN,         LMAC_ULE_FU10_DATA_IND},
  { HMACCmd_MAC_ULE_FU10_DTR_IN,             LMAC_ULE_FU10_DTR_IND},
  { HMACCmd_MAC_ULE_FU10_BE_REL_IN,          LMAC_ULE_FU10_BE_REL_IND},
  { HMACCmd_MAC_ULE_FU10_OTHER_IN,           LMAC_ULE_FU10_OTHER_IND},
#endif
  
#ifdef CONFIG_REPEATER_SUPPORT
  { LMACCmd_ACCESS_RQ_HMAC,                  LMAC_REP_ACCESS_REQ},
  { HMACCmd_ACCESS_CFM_LMAC,                 LMAC_REP_ACCESS_CFM},
  { HMACCmd_REP_CO_DATA_DTR_LMAC,            LMAC_REP_CO_DTR_IND},
  { LMACCmd_REP_CO_DATA_RQ_HMAC,             LMAC_REP_CO_DATA_REQ},
  { HMACCmd_REP_CO_DATA_IN_LMAC,             LMAC_REP_CO_DATA_IND},
#endif

  {0xFF,0xFF} 
};

#ifdef SUPERTASK
volatile static unsigned long cosic_int_cnt=0;
static unsigned long cosic_int_cnt_pre=0;
volatile static long protest_fg=0;
volatile static long ignore_cnt=0,lost_in_seq=0;
volatile static unsigned int IntEdgFlg;
volatile static int viSPILocked =0;
#endif

/* =======================================================================
 * Global Variables
 * ======================================================================= */
x_IFX_Mcei_Buffer xMceiBuffer[MAX_MCEI];

unsigned int	transmit_len;
unsigned int	rx_len;

int valid_voice_pkt[MAX_MCEI];

int iNeedVersion=1;

/* tapi voice wrtie data */
TAPI_VOICE_WRITE_BUFFER Tapi_voice_write_buffer[MAX_TAPI_BUFFER_CNT];
unsigned char           Tapi_voice_write_buffer_r_cnt;
unsigned char           Tapi_voice_write_buffer_w_cnt;

/* COSIC data packat */
COSIC_PACKET cosic_data_packet;

/* Max SPI data length */
unsigned int Max_spi_data_len_val = MAX_SPI_DATA_LEN;

#ifdef  VOICE_CYCLIC_INDEX_CHECK
unsigned char Tback_cyclic_index[6];
unsigned char Tcheck_cyclic_index[6];
#endif

/* cosic thread/tasklet status variable, It alternates between Tx and Rx */
COSIC_THREAD_STATUS cosic_status = COSIC_THREAD_TRANSFER_STATUS;		
/* Temporary variable used for looping till DECT application comes up */
unsigned int starting_cnt = 0;

/* Voice mute */
#ifdef VOICE_MUTE_SERVICE_CHANGE
unsigned char voice_mute_cnt[MAX_MCEI];
#endif

/* SSC TX and RX buffers */
#if defined(LINUX) && defined(COSIC_DMA)
unsigned char *ssc_cosic_rx_buf_temp,*ssc_cosic_tx_buf_temp;
unsigned char *ssc_cosic_rx_buf;	/* cosic rx  buffer */
unsigned char *ssc_cosic_tx_buf;	/* cosic tx buffer */
#else
unsigned char ssc_cosic_rx_buf[MAX_SPI_DATA_LEN + 128];	/* cosic rx  buffer */
unsigned char ssc_cosic_tx_buf[MAX_SPI_DATA_LEN + 128];	/* cosic tx buffer */
#endif

#ifdef LINUX
struct tasklet_struct x_IFX_Cosic_Tasklet;
struct tasklet_struct x_IFX_Cosic_Tasklet1;
struct tasklet_struct x_IFX_Tapi_Tasklet;
volatile unsigned long i_CosicData;
volatile unsigned long i_CosicData1;
atomic_t vuiIgnoreint;

//unsigned char Dect_mutex_free = 0;

volatile unsigned int IntEdgFlg;
/* Cosic mode indicating Tx/Rx Tx=0, Rx=1 */
int iCosicMode=1;
int viSPILocked =0;
int viSPILockedCB =0;
int iDriverStatus = 0;
////int FirstLock =1;
/*int viSPILocked1 =0;*/
//int viSPIUnLockSchedule =0;
unsigned int  uiReq;
unsigned int  uiResp;

unsigned short FwLen =0;
unsigned char* pvucWriteBuffer=NULL;
#endif /* LINUX */
#ifdef SUPERTASK
int iModemRestartCount=0;

/*wait_queue_head_t dect_interrupt_queue; 		*//*  process wait queue */
TAPI_OS_ThreadCtrl_t cosic_drv_kthread;					/* cosic kernel thread struct */
TAPI_OS_ThreadCtrl_t cosic_drv_TAPI_Read_kthread;					/* cosic kernel TAPI DATA read thread */

int cosic_buffer_cnt;

/* Cosic mode indicating Tx/Rx Tx=0, Rx=1 */
volatile int iCosicMode;
volatile int viSPILockedCB =0;
volatile int iDriverStatus = 0;
volatile int spitaskchk=0;
volatile int cosic_thread_running=0;
volatile int ichipCSRxCount=0;
volatile int ichipCSCount=0;
volatile int ichipCSTxCount=0;
volatile int iFirstByteRx=0;

int iCntlForceLongLock=0;
#endif /* SUPERTASK */

/* =======================================================================
 * Local Function Prototypes
 * ======================================================================= */
int ifx_sscCosicLock(void);
void ifx_sscCosicUnLock(void);
void ifx_sscCosicRx(void);
void ifx_sscCosicTx(void);
int ssc_dect_debug(int on);

#ifdef LINUX
void ifx_cosic_driver(unsigned long ulDummy);
void ifx_cosic_driver1(unsigned long ulDummy);
void IFX_COSIC_TapiRead(unsigned long ulDummy);
void init_tapi_read_write_buffer(void);
#endif
#ifdef SUPERTASK
IFX_void_t COSIC_drv_Kthread(IFXOS_ThreadParams_t *pthread);
IFX_void_t COSIC_drv_TAPI_Read_Kthread(IFXOS_ThreadParams_t *pthread);
#endif

/* =======================================================================
 * Function Definitions
 * ======================================================================= */
#ifdef SUPERTASK
#ifdef TRACE_BACK
#define MAXTRACE 10
unsigned char CT[MAXTRACE]={0};
unsigned int CT_Index=0;
void Update_CT(unsigned char Num)
{
   CT[CT_Index]=Num;
   CT_Index = (CT_Index + 1) % MAXTRACE;
   return;
}

void Print_CT(void)
{
   int i=0;
   iprintf("\n CT PRINTS  Next Index %d\n",CT_Index );
   for(i=0;i<MAXTRACE;i++)
   {
      iprintf("  %d ",CT[i]);
   }
   iprintf("\n");
}
#endif
#endif /* SUPERTASK */
//extern spinlock_t IntEdgFlgLock;
//#undef CONFIG_SMP
#ifdef CONFIG_SMP
#define CONFIG_SMP1
#define CONFIG_SMP2
#define CONFIG_SMP3
#define CONFIG_SMP4
extern spinlock_t IntEdgFlgLock;
extern spinlock_t IOCTL_TASKET_Lock;
#ifdef CONFIG_SMP4
extern spinlock_t DECT_TAPI_Lock;
#endif 
#endif 

#if 0
void irq_safe_lock(unsigned long flags)
{
#ifdef CONFIG_SMP1
	spin_lock_irqsave(&IntEdgFlgLock,flags);
#else
	local_irq_save(flags);
#endif 
}


void irq_safe_unlock(unsigned long flags)
{
#ifdef CONFIG_SMP1
	spin_unlock_irqrestore(&IntEdgFlgLock,flags);
#else
	local_irq_restore(flags);
#endif 
}

#endif

/******************************************************************  
 *  Function Name  : start_tapiThread 
 *  Description    : This function registers a function to execute
 *                   when tapi tasklet is scheduled. In cases where
 *                   tasklets are not supported it starts a kernel 
 *                   thread
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void start_tapiThread(void)
{
   #ifdef LINUX
   int iRet;

   init_tapi_read_write_buffer();
   tasklet_init(&x_IFX_Tapi_Tasklet, &IFX_COSIC_TapiRead, 0);
   iRet=IFX_TAPI_KPI_EgressTaskletRegister(IFX_TAPI_KPI_GROUP2, (void*)&x_IFX_Tapi_Tasklet);
   if(iRet<0){
      printk("TAPI KPI registration failed\n");
   }
   #endif
   #ifdef SUPERTASK
   TAPI_OS_ThreadInit(&cosic_drv_TAPI_Read_kthread, "waitTAPI thread", (IFXOS_ThreadFunction_t)COSIC_drv_TAPI_Read_Kthread,
                      8000, 125, 0, 0);
   #endif
}

/******************************************************************
 *  Function Name  : stop_tapiThread
 *  Description    : This function unregisters the function with
 *                   TAPI tasklet mode/stops the kernel thread
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void stop_tapiThread(void)
{
   #ifdef LINUX
   int iRet;
   tasklet_kill(&x_IFX_Tapi_Tasklet);

   /* TODO: No Unregister function?? */
   iRet=IFX_TAPI_KPI_EgressTaskletRegister(IFX_TAPI_KPI_GROUP2, NULL);
   if(iRet<0){
      printk("TAPI KPI Unregistration failed\n");
   }
   #endif
   #ifdef SUPERTASK
   if(!cosic_drv_TAPI_Read_kthread.thrParams.bShutDown)
      IFXOS_ThreadDelete(&cosic_drv_TAPI_Read_kthread, 10);
   #endif
}

/******************************************************************
 *  Function Name  : start_cosicThread
 *  Description    : This function initializes the COSIC tasklet or
 *                   starts cosic kernel thread
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void start_cosicThread(void)
{
   #ifdef LINUX
   #ifdef COSIC_DMA
   {
      ssc_cosic_tx_buf_temp = kmalloc(519,GFP_KERNEL);
      if(ssc_cosic_tx_buf_temp == NULL){
         printk("Error allocating Tx Buffer\n");
      }
      /*check for byte alignment*/
      if((int)ssc_cosic_tx_buf_temp%8){
         ssc_cosic_tx_buf = ssc_cosic_tx_buf_temp + (8 - ((int)ssc_cosic_tx_buf_temp%8));
      }
      else{
         ssc_cosic_tx_buf = ssc_cosic_tx_buf_temp;
      }
      ssc_cosic_rx_buf_temp = kmalloc(519,GFP_KERNEL);
      if(ssc_cosic_rx_buf_temp == NULL){
         printk("Error allocating Rx Buffer\n");
      }
      /*check for byte alignment*/
      if((int)ssc_cosic_rx_buf_temp%8){
         ssc_cosic_rx_buf = ssc_cosic_rx_buf_temp + (8 - ((int)ssc_cosic_rx_buf_temp%8));
      }
      else{
         ssc_cosic_rx_buf = ssc_cosic_rx_buf_temp;
      }
   }
   #endif

   tasklet_init(&x_IFX_Cosic_Tasklet,(void*)&ifx_cosic_driver, (unsigned long)&i_CosicData);
   tasklet_init(&x_IFX_Cosic_Tasklet1,(void*)&ifx_cosic_driver1, (unsigned long)&i_CosicData1);
   #endif /* LINUX */
   #ifdef SUPERTASK
   /* COSIC DRIVER THREAD */
   TAPI_OS_ThreadInit(&cosic_drv_kthread, "CosicDriver", (IFXOS_ThreadFunction_t)COSIC_drv_Kthread,
                      8000, 125, 0, 0);
   #endif /* SUPERTASK */
}

/******************************************************************
 *  Function Name  : stop_cosicThread 
 *  Description    : This function kilss the cosic drivers'
 *                   tasklet/thread
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void stop_cosicThread(void)
{
   #ifdef LINUX
   tasklet_kill(&x_IFX_Cosic_Tasklet);
   tasklet_kill(&x_IFX_Cosic_Tasklet1);
   #ifdef COSIC_DMA
   if(ssc_cosic_rx_buf_temp != NULL){
      kfree(ssc_cosic_rx_buf_temp);
      ssc_cosic_rx_buf_temp = NULL;
   }
   if(ssc_cosic_tx_buf_temp != NULL){
      kfree(ssc_cosic_tx_buf_temp);
      ssc_cosic_tx_buf_temp = NULL;
   }
   #endif
   if(dect_gpio_intnum != -1 ){
      disable_irq(dect_gpio_intnum);
      iIrqStatus=0;
      free_irq(dect_gpio_intnum , NULL);
      if(spi_dev_handler != NULL)
      {
      	if(viSPILocked)
    	{
      		ifx_sscAsyncUnLock(spi_dev_handler);
	  		viSPILocked = 0;
    	}
         ifx_sscFreeConnection(spi_dev_handler);
         spi_dev_handler = NULL;
      }
      dect_gpio_intnum = -1;
   }
   #endif /* LINUX */
   #ifdef SUPERTASK
   if(!cosic_drv_kthread.thrParams.bShutDown)
      IFXOS_ThreadDelete(&cosic_drv_kthread, 10);
   #endif
}

/******************************************************************
 *  Function Name  : 
 *  Description    : This function parses the data from danube to
 *                   LMAC 
 *  Input Values   : data buffer
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 *        lmac data parsing
 *	+---------+----+----+----+------------
 *	|         |    |    |    |                        
 *	+---------+----+----+----+------------
 *	 Total Len Type Len  Slot 
 *  Type:  0x01-COSIC_MAC_PACKET, 0x17-COSIC_VOICE_PACKET
 *         0x02-COSIC_DECT_SYNC_PACKET, 0x03-COSIC_DECT_SETUP_PACKET    
 * ****************************************************************/
void 
From_LMAC_Data(unsigned char *data)
{
	#ifdef CONFIG_SMP4
      unsigned long flags4;
   #endif
   unsigned int  total_len;
   unsigned int  i;
   unsigned int  data_index;
   unsigned int  data_len;
   unsigned int  voice_channel;
   int ret,iKpiChan=0;
   TAPI_VOICE_WRITE_BUFFER *pTapiData;
   #ifdef VOICE_DATA_NIBBLE_SWAP
   unsigned char voice_nibble;
   #endif
   unsigned char valid_channel;

   /* First 2 bytes constitute the total length */
   total_len = data[COSIC_DATA_HIGH_LENGTH];
   total_len = total_len << 8 | data[COSIC_DATA_LOW_LENGTH];
   /* Remove the bytes reqd for storing total len */
   total_len -= 2;
   data_index = COSIC_DATA_MSG_TYPE;
   /* if the length recvd is lesser than two bytes, it's an erroneous condn */
   if((total_len <= 2) || (total_len > Max_spi_data_len_val)){
      return;
   }

	{
	   #ifdef CONFIG_SMP2
      	unsigned long flags;
			spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   	#endif  
   if((vucDriverMode == DECT_DRV_SET_LOADER_MODE)&&(data[COSIC_DATA_MSG_TYPE] == COSIC_DECT_SYNC_PACKET)){
  	   memcpy(vucReadBuffer[vu16ReadBufHead],data, total_len+2);
     	++vu16ReadBufHead;
      if(vu16ReadBufHead == MAX_READ_BUFFFERS) {
    	   vu16ReadBufHead = 0;
      }
      if(vu16ReadBufHead == vu16ReadBufTail) {
     	   printk(": Read buffer full\n");
     	   vu16ReadBufTail++;
     	   if(vu16ReadBufTail == MAX_READ_BUFFFERS)
  	   	   vu16ReadBufTail = 0;
      }

   	#ifdef CONFIG_SMP2
      	spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   	#endif
      #ifdef LINUX
      Dect_excpFlag = 1;
      wake_up_interruptible(&Dect_WakeupList);
      #endif
      #ifdef SUPERTASK
      //setgrp(DECT_STACK_WAITGROUP_ID, DRIVER_STACK_EVT);
      MTqcmd_c(SETGRP,DECT_STACK_WAITGROUP_ID, DRIVER_STACK_EVT);
      #endif
      return;
   }
   #ifdef CONFIG_SMP2
	else
	{
      	spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
	}		
  	#endif
	}

   /* if totallen is lt HMAC Q size or gt SPI data len mark invalid */
   /* We allow different sized packets => Merged from Intnix Rel 140409 */
   /* if((total_len < sizeof(HMAC_QUEUES)+2)||total_len > Max_spi_data_len_val) */
   if((total_len < (17+2)) || total_len > Max_spi_data_len_val){
      IFX_COSIC_DMSG("invalid packet size total_len=%d\n", total_len);
      return;
   }
  
   while (data[data_index]){
      if (total_len <= data_index) {
         break;
      }

		/* check message type 
		   0x01 : COSIC_MAC_PACKET , 			0x17 : COSIC_VOICE_PACKET
		   0x02 : COSIC_DECT_SYNC_PACKET,	0x03 : COSIC_DECT_SETUP_PACKET    
         0x05 : COSIC_DECT_FU10_PACKET, 0x06 : COSIC_DECT_ULE_FU10_PACKET
		*/
      switch (data[data_index++]) {
         case COSIC_VOICE_PACKET:	
            {
               /* 4 byte header + payload	
                  Type (1 byte) - 0x17
      	         Length (1 byte) - 40 t0 80
      	         MCEI Number(1 byte) - MCEI number / voice channel / DECT channel
      	         Sub Info (nibble),     - don't care
      	         Cyclic Index (nible),  - 4 bits cyclic counter set to help TAPI FW 
                                          in case of lost packets (missed interrupts),
                  Voice Data (40 or 80 bytes)*/
               /*IFX_COSIC_DMSG("cosic voice packet rcvd \n");*/
               #ifdef USE_VOICE_BUFFERPOOL
               pTapiData=(TAPI_VOICE_WRITE_BUFFER*)IFX_TAPI_VoiceBufferGet();
               #else
      	      pTapiData=(TAPI_VOICE_WRITE_BUFFER*)bufferPoolGet(pTapiWriteBufferPool);
               #endif
               if(pTapiData == NULL){
                  /* TODO: error handling?? */
                  printk(" buffer pool get failed\n");
      		      return;
               }
               #ifdef SUPERTASK
               cosic_buffer_cnt++;
               #endif

               /* set packet type */
               pTapiData->type_slot = 0;
               pTapiData->type_slot = TAPI_B_VOICE_PACKET << 4;

               /* populate the data length */
               data_len = data[data_index++] - 2; /* Minus MCEI_num(1byte), sub_Info+seq(1byte) */
               if(data_len > MAX_TAPI_VOICE_BUFFER_SIZE){
                  data_len = MAX_TAPI_VOICE_BUFFER_SIZE;
      	      }
               data_len += 4;
               pTapiData->voice_len_high = (data_len >> 8); /* should be zero */
      	      pTapiData->voice_len_low  = data_len;
      	      data_len -= 4;

               /* mcei number */
               voice_channel = data[data_index++]; 
               if (!valid_voice_pkt[voice_channel]) {
      		      /* Check if there is a valid voice packet on this channel*/
      	         /* 0x10-No error & G.726, 0x40-No error & G.722*/	
      			   if((data[data_index] == 0x10) || (data[data_index] == 0x40)){
                     #ifdef LINUX
                     IFX_COSIC_DMSG("Valid voice pkt\n");
                     #endif
                     #ifdef SUPERTASK
                     //cosic_printf("Valid voice pkt\n");
                     #endif
      				   valid_voice_pkt[voice_channel]=1;
                  }
      		   }
              
               /* set dect channel number */

   				#ifdef CONFIG_SMP4
      				spin_lock_irqsave(&DECT_TAPI_Lock,flags4);
   				#endif			

					iKpiChan=xMceiBuffer[voice_channel].iKpiChan;

   				#ifdef CONFIG_SMP4
      				spin_unlock_irqrestore(&DECT_TAPI_Lock,flags4);
   				#endif

               pTapiData->type_slot |= (iKpiChan & 0x0F);
					//pTapiData->type_slot |= (xMceiBuffer[voice_channel].iKpiChan & 0x0F);
               /* set sub_type & cycle_index */
               #ifndef USE_PLC_BIT
               if (data_len == MAX_TAPI_VOICE_BUFFER_SIZE) {
                  pTapiData->info_cyclic_index =  0x30;/* Wideband */
               } else {
                  pTapiData->info_cyclic_index =  0x00;	/* Narrow band */
               }
               #else
               /* 0x10 - No error & G.726
                  0x90 - PLC set & G.726
      	         0x40 - No error & G.722
      	         0xC0 - PLC Set & G.722
      	         TODO: need one element(plc_bit) 
      	       */
      		
               if (data_len == MAX_TAPI_VOICE_BUFFER_SIZE) {
                  pTapiData->info_cyclic_index =  0x30;/* Wideband */
             	} else {
                  pTapiData->info_cyclic_index =  0x00;	/* Narrow band */
               }

      		   {
      	         unsigned char plc_bit = data[data_index] & 0xF0;

                  if (valid_voice_pkt[voice_channel] != 0) {
              	      if ((plc_bit == 0x90) || (plc_bit == 0xC0)) {
              	         #ifdef LINUX
                        IFX_COSIC_DMSG("PLC set\n");
                        #endif
                        #ifdef SUPERTASK
                        //cosic_printf("PLC set\n");
                        #endif
      	               pTapiData->info_cyclic_index = 0x80;/* wide band */
              	      }
      			   }	
      		   }
               #endif
               pTapiData->info_cyclic_index |=  data[data_index++] & 0x0F;

               /* burst error info is not used currently, set it to zero */
      	      memset(pTapiData->burst_error_info, 0, 4);
               #ifdef VOICE_DATA_NIBBLE_SWAP
               if(data_len < MAX_TAPI_VOICE_BUFFER_SIZE){
      	         /* voice data nibble swap  ralph_20071222 */
      	         for(i=0; i< data_len; i++){
                     voice_nibble = 0;
                     voice_nibble = (data[data_index+i] << 4) & 0xF0;
                     voice_nibble |= (data[data_index+i] >> 4) & 0x0F;
                     data[data_index+i] = voice_nibble;
      	         }
               } 
               #endif
               /* copy the data into voice buffer */
               memcpy(pTapiData->voice_buffer, &data[data_index], data_len);
               valid_channel = 0;
               if((voice_channel < MAX_MCEI) && 
                  (iKpiChan != 0xFF)){
                  /*(xMceiBuffer[voice_channel].iKpiChan != 0xFF)){*/
      	         valid_channel = 1;
               }
               if(valid_channel == 0){
                  #ifdef LINUX
      	         IFX_COSIC_DMSG("@%d %d\n", voice_channel, data_len);
      	         #endif
      	         #ifdef SUPERTASK
                  //cosic_printf("----> [@%d %d\n", voice_channel, data_len);
      	         #endif
                  BUFFER_POOL_PUT(pTapiData);
                  #ifdef SUPERTASK
                  cosic_buffer_cnt--;
                  #endif
                  data_index += data_len;
                  break;
               }
               #ifdef VOICE_MUTE_SERVICE_CHANGE
               if(voice_mute_cnt[voice_channel]){
                  #ifdef SUPERTASK
                  //voice_mute_cnt[voice_channel] --;
                  {
                     extern int rtp_debug;
                     if (rtp_debug==1) {
                        tmp_iprintf_onoff(1);
                        iprintf("voice_mute_cnt %d\n",voice_mute_cnt);
                        tmp_iprintf_onoff(0);
                     }
                  }
                  #endif
                  BUFFER_POOL_PUT(pTapiData);
                  #ifdef SUPERTASK
                  cosic_buffer_cnt--;
                  #endif
                  data_index += data_len;
                  break;
      	      }
               #endif
               /* write to TAPI KPI */
               /* TODO: increase plc_bit lentgh*/
               ret = IFX_TAPI_KPI_WriteData(IFX_TAPI_KPI_GROUP2 | 
                                            (iKpiChan&0x0F), 
                                            pTapiData, data_len+8);
					/*
               ret = IFX_TAPI_KPI_WriteData(IFX_TAPI_KPI_GROUP2 | 
                                            (xMceiBuffer[voice_channel].iKpiChan&0x0F), 
                                            pTapiData, data_len+8);*/

               if (ret != data_len+8 || ret == IFX_ERROR) {
                  BUFFER_POOL_PUT(pTapiData);
                  #ifdef SUPERTASK
                  cosic_buffer_cnt--;
                  #endif
      	         IFX_COSIC_DMSG("IFX_TAPI_KPI_WriteData Error Return ret=%d tapi_CH_arry=%d voice_channel=%d\n", ret,xMceiBuffer[voice_channel].iKpiChan, voice_channel);
                  data_index += data_len;
                  break;
               }
               data_index += data_len;
            }
            break;
         /* COSIC_VOICE_PACKET ]] */

         #ifdef CATIQ_UPLANE
         case COSIC_DECT_FU10_PACKET:  
            {
               /* clear union buffer */
               memset(&cosic_data_packet, 0, sizeof(cosic_data_packet));

               /* Fill buffer with recieved contents */
               data_len=data[data_index++];
               cosic_data_packet.uni.DATA_PACKET.PROCID=data[data_index++];
               cosic_data_packet.uni.DATA_PACKET.MSG= data[data_index++];
               cosic_data_packet.uni.DATA_PACKET.LengthHi=data[data_index++];
               cosic_data_packet.uni.DATA_PACKET.LengthLo=data[data_index++];
               cosic_data_packet.uni.DATA_PACKET.Status=data[data_index++];
               cosic_data_packet.uni.DATA_PACKET.Parameter4=data[data_index++];
               #if 1
               data_len= cosic_data_packet.uni.DATA_PACKET.LengthLo;
        			/* Invalid packet length */
               if(data_len > G_PTR_MAX_COUNT){
                  #ifdef LINUX
                  printk("<RX-FU10 Error> data len %d\n",data_len);
                  return;
                  #endif
                  #ifdef SUPERTASK
                  break;
                  #endif
               }
               #else
               data_len= (cosic_data_packet.uni.DATA_PACKET.LengthHi<<8)+
                          cosic_data_packet.uni.DATA_PACKET.LengthLo;
        			/* Invalid packet length */
               #ifdef LINUX
               if(data_len > MAX_SPI_DATA_LEN){
                  printk("<RX-FU10 Error> data len %d\n",data_len);
                  return;
               }
               #endif
               #ifdef SUPERTASK
               if(data_len > G_PTR_MAX_COUNT) {
                 return;
               }
               #endif
               #endif

               for(i=0;i<data_len; i++){
                  cosic_data_packet.uni.DATA_PACKET.Uplan[i] = data[data_index++];
               }
               cosic_data_packet.uni.DATA_PACKET.CurrentInc=data[data_index++];

               /*process data packet*/ 
               /*printk("<RX-FU10>");*/
               DECODE_HMAC((HMAC_QUEUES*)&cosic_data_packet.uni.temp_hmac);
            }
            break;
         #endif
   
         #ifdef ULE_SUPPORT
         case COSIC_DECT_ULE_FU10_PACKET:  
            {
               /*
                  Packet Type     : [0]       - COSIC_DECT_ULE_FU10_PACKET
                  Packet Length   : [1]       - 6 + 1 + 38 + 1; 46
                  Process ID      : [2]       - HMAC
                  HMAC Message    : [3]
                  Paramater1 (LBN): [4]
                  Paramater2      : [5]
                  Paramater3      : [6]
                  Paramater4      : [7]
                  G_PTR           : [8]       - Length of data; 0 or 38
                                    [9]..[46]
                  MCEI            : [47]
                */
              
               /* clear union buffer */
               memset(&cosic_data_packet, 0, sizeof(cosic_data_packet));

               /* Fill buffer with recieved contents */
               data_index++; // skip packet length field
               cosic_data_packet.uni.ULE_DATA_PACKET.PROCID = data[data_index++];
               cosic_data_packet.uni.ULE_DATA_PACKET.MSG = data[data_index++];
               cosic_data_packet.uni.ULE_DATA_PACKET.Parameter1 = data[data_index++];
               cosic_data_packet.uni.ULE_DATA_PACKET.Parameter2 = data[data_index++];
               cosic_data_packet.uni.ULE_DATA_PACKET.Parameter3 = data[data_index++];
               cosic_data_packet.uni.ULE_DATA_PACKET.Parameter4 = data[data_index++];
               data_len = cosic_data_packet.uni.ULE_DATA_PACKET.Uplan[0] = data[data_index++];
               /* Invalid packet length */
               if(data_len > G_PTR_MAX_ULE_COUNT){
                  printk("<RX-FU10 Error> data len %d\n",data_len);
                  return;
               }
               /* Uplane Payload*/
               for (i = 1; i < G_PTR_MAX_ULE_COUNT + 1; i++) {
                  cosic_data_packet.uni.ULE_DATA_PACKET.Uplan[i] = data[data_index++];
               }
               cosic_data_packet.uni.ULE_DATA_PACKET.CurrentInc = data[data_index++];        
             
               /* command matching */
               i = 0;
               while(1){
                  if(Message_Map_Table[i][0] == cosic_data_packet.uni.ULE_DATA_PACKET.MSG){
                     cosic_data_packet.uni.ULE_DATA_PACKET.MSG = Message_Map_Table[i][1];
                     break;
                  }
                  if(Message_Map_Table[i][0] == 0xFF){
                     IFX_COSIC_DMSG("<COSIC>Message %d Not Found In Message_Map_Table\n", cosic_data_packet.uni.ULE_DATA_PACKET.MSG);
                     cosic_data_packet.uni.ULE_DATA_PACKET.MSG = 0xFF;
                     break;
                  }
                  i++;
               }

               /*process data packet*/ 
               /*printk("<RX-FU10>");*/
               DECODE_HMAC((HMAC_QUEUES*)&cosic_data_packet.uni.temp_hmac);
            }
            break;
         #endif

         case COSIC_MAC_PACKET: /* to HMAC packet data */
            {
               /* 2 byte header + MAC stream	
        	         Type (1 byte), Length (1 byte), MAC Command Stream(MAX 17byte)
                  2 byte header
                  Type=0x01		8bits, 
                  Length=??		8bits,
                  MAC command Stream 
                */

               /* clear union buffer */
               memset(&cosic_data_packet, 0, sizeof(cosic_data_packet));
               data_len = data[data_index++];
               /* copy hmac packet */
               for(i=0;i<data_len; i++){
        	         cosic_data_packet.uni.temp_hmac[i] = data[data_index++];
               }
               #ifdef CATIQ_UPLANE
               /* Copy the last byte to CurrentInc to allow the bigger size of G_PTR_buf */
               cosic_data_packet.uni.temp_hmac_struct.CurrentInc = cosic_data_packet.uni.temp_hmac[data_len-1];
               #endif
               /* command matching */
               i = 0;
               while(1){
                  if(Message_Map_Table[i][0] == cosic_data_packet.uni.temp_hmac[COSIC_MAC_MSG]){
        	            cosic_data_packet.uni.temp_hmac[COSIC_MAC_MSG] = Message_Map_Table[ i ][ 1 ];
           	         if(cosic_data_packet.uni.temp_hmac[COSIC_MAC_MSG] == LMAC_BOOT_IND)
           				{
           				   /*Send Version query debug pkt*/
                        if(iNeedVersion == 1){
           					   WriteDbgPkts(6,0,0,NULL);
                           iNeedVersion=0;
                        }
           		      } 
                     break;
                  }
                  if(Message_Map_Table[i][0] == 0xFF){
                     #ifdef LINUX
                     IFX_COSIC_DMSG("<COSIC>Message %d Not Found In Message_Map_Table\n",cosic_data_packet.uni.temp_hmac[COSIC_MAC_MSG]);
                     #endif
                     #ifdef SUPERTASK
                     //printk("<COSIC>Message %d Not Found In Message_Map_Table\n", cosic_data_packet.uni.temp_hmac[COSIC_MAC_MSG]);
                     #endif
                     cosic_data_packet.uni.temp_hmac[COSIC_MAC_MSG] = 0xFF;
                     break;
                  }
                  i++;
               }
              
               if(cosic_data_packet.uni.temp_hmac[COSIC_MAC_MSG] == 0x80){
                  for(i=0; i< 17;i++){
                     IFX_COSIC_DMSG("0x%x ",cosic_data_packet.uni.temp_hmac[i]);
                  }
                  IFX_COSIC_DMSG("\n");
               }

        		   DECODE_HMAC((HMAC_QUEUES*)&cosic_data_packet.uni.temp_hmac);
            }
            break;
         /* COSIC_MAC_PACKET ]] */

         case COSIC_DECT_SYNC_PACKET:
            IFX_COSIC_DMSG("rcvd sync packet\n");

            /* clear union buffer */
            memset(&cosic_data_packet, 0, sizeof(cosic_data_packet));
            cosic_data_packet.uni.SYNC_PACKET.Sync_Packet_RxTxstatus = data[data_index++];
            cosic_data_packet.uni.SYNC_PACKET.Sync_Packet_TimeStamp = data[data_index++];
            cosic_data_packet.uni.SYNC_PACKET.Sync_Packet_Reserved = data[data_index++];
            break;
        
         case COSIC_DECT_SETUP_PACKET:
            IFX_COSIC_DMSG("set up packet \n");

            /* clear union buffer */
            memset(&cosic_data_packet, 0, sizeof(cosic_data_packet));
            data_len = data[data_index++];
            cosic_data_packet.uni.SETUP_PACKET.Setup_Packet_SPIMode = data[data_index++];
            for(i=0; i<12;i++){
               cosic_data_packet.uni.SETUP_PACKET.Setup_RXTX_status[i] = data[data_index++];
            } 
            break;

         case COSIC_DECT_DEBUG_PACKET:
            /* clear union buffer */
            memset(&cosic_data_packet, 0, sizeof(cosic_data_packet));
            data_len = data[data_index++];
            /* Message */
            cosic_data_packet.uni.DEBUG_PACKET.debug_info_id = data[data_index++];
            cosic_data_packet.uni.DEBUG_PACKET.rw_indicator = 0;
            data_index++;
            /* Current inc */
            cosic_data_packet.uni.DEBUG_PACKET.CurrentInc = data[data_index++];
            if(data_len > 1){
               for(i=0; i<data_len-3;i++){
                  cosic_data_packet.uni.DEBUG_PACKET.G_PTR_buf[i] = data[data_index++];
                  #ifdef LINUX
                  IFX_COSIC_DMSG(" %x ",data[data_index-1]);
                  #endif
                  #ifdef SUPERTASK
						//printk(" %x ",data[data_index-1]);
                  #endif
               }
            }

            DECODE_DEBUG_FROM_MODULE((DECT_MODULE_DEBUG_INFO*)&cosic_data_packet.uni.DEBUG_PACKET);
            break;

         default:
            IFX_COSIC_DMSG("Default %x %x %x %x %x %x %x %x %x %x\n", data[0],data[1],
                           data[2],data[3],data[4],data[5],data[6],data[7],
                           data[8],data[9]);
            IFX_COSIC_DMSG("data_index = %d %x %x %x %x %x %x %x %x %x %x\n", 
                           data_index, data[data_index-1], data[data_index],
                           data[data_index+1], data[data_index+2],
                           data[data_index+3],data[data_index+4],
                           data[data_index+5],data[data_index+6],
                           data[data_index+7],data[data_index+8]);
            return;
      }
   }

   return;
}

/******************************************************************
 *  Function Name  : To_LMAC_Data 
 *  Description    : This function packs the data from Danube to
 *                   LMAC
 *  Input Values   : data buffer
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void To_LMAC_Data(unsigned char *data)
{
   #ifdef CONFIG_SMP4
      unsigned long flags4;
   #endif
   static unsigned int   k=0;
   unsigned char temp_hmac[sizeof(HMAC_QUEUES)/*43*/] = {0};
   unsigned int total_len;
   unsigned int i;
   unsigned int sendlen;
   unsigned char voice_packet_cnt = 0;
   unsigned char lmac_packet_cnt = 0;
   unsigned char debug_packet_cnt = 0;
   unsigned int data_index;
   HMAC_QUEUES * hmac_ptr;
   /*unsigned char   voice_nibble;*/

   data_index = COSIC_DATA_MSG_TYPE;
   total_len = 0;

   // **************
   // GET VOICE DATA
   // **************

  #ifdef LINUX
	//while(voice_packet_cnt < 2)
  #endif
	{
   if (k >= MAX_MCEI)	{
      k = 0;
   }
   for (i = k; i < MAX_MCEI; i++, k++)
	{
			  int iVoiceLen = 0, j = 0, iVoiceInfo;
			  char *pcVoiceDataBuffer=NULL;


#ifdef VOICE_MUTE_SERVICE_CHANGE
#ifdef LINUX
			  if (voice_mute_cnt[i]) {
						 voice_mute_cnt[i]--;
			  }
			  if (voice_mute_cnt[i]) {
						 for (j = 0; j < MAX_MCEI; j++) {
#ifdef CONFIG_SMP4
									spin_lock_irqsave(&DECT_TAPI_Lock,flags4);
#endif
									if(xMceiBuffer[j].pcVoiceDataBuffer != NULL) {
											  char *pcTmpVoiceDataBuffer = xMceiBuffer[j].pcVoiceDataBuffer;
#ifdef SUPERTASK
											  cosic_buffer_cnt--;
#endif
											  /* increase read buffer counter */
											  xMceiBuffer[j].pcVoiceDataBuffer = xMceiBuffer[j].pcVoiceDataBuffer1;
											  xMceiBuffer[j].pcVoiceDataBuffer1 = NULL;


#ifdef CONFIG_SMP4
											  spin_unlock_irqrestore(&DECT_TAPI_Lock,flags4);
#endif

											  //BUFFER_POOL_PUT(xMceiBuffer[j].pcVoiceDataBuffer);
											  BUFFER_POOL_PUT(pcTmpVoiceDataBuffer);
									}
#ifdef CONFIG_SMP4
									else
									{
											  spin_unlock_irqrestore(&DECT_TAPI_Lock,flags4);
									}		
#endif
						 }
						 if (j == MAX_MCEI) {
									break;
						 }
			  }
#endif /* LINUX */
#ifdef SUPERTASK
			  if(voice_mute_cnt[i]){
						 BUFFER_POOL_PUT(xMceiBuffer[i].pcVoiceDataBuffer);
						 cosic_buffer_cnt--;
						 xMceiBuffer[i].pcVoiceDataBuffer = xMceiBuffer[i].pcVoiceDataBuffer1;
						 xMceiBuffer[i].pcVoiceDataBuffer1 = NULL;
						 voice_mute_cnt[i]--;
						 //cosic_printf("\n*V2[%d]\n",i);
						 continue;
			  }
#endif /* SUPERTASK */
#endif


#ifdef CONFIG_SMP4
			  spin_lock_irqsave(&DECT_TAPI_Lock,flags4);
#endif

			  pcVoiceDataBuffer=xMceiBuffer[i].pcVoiceDataBuffer;
			  xMceiBuffer[i].pcVoiceDataBuffer=xMceiBuffer[i].pcVoiceDataBuffer1;
			  xMceiBuffer[i].pcVoiceDataBuffer1=NULL;

#ifdef CONFIG_SMP4
			  spin_unlock_irqrestore(&DECT_TAPI_Lock,flags4);
#endif



			  if (pcVoiceDataBuffer != NULL) {
#ifdef LINUX
#ifdef CONFIG_LTT
						 MARK(cosic_event,"long %lu string %s",xMceiBuffer[i].iVBCnt,"4");
#endif
#endif /* LINUX */
#ifdef SUPERTASK
#ifdef MS_DBG
						 extern unsigned long end ;
						 if (((unsigned int)xMceiBuffer[i].pcVoiceDataBuffer & 0x80000000) != 0x80000000 || ((unsigned int)xMceiBuffer[i].pcVoiceDataBuffer >= &end)) {
									char *ptr ;
									printk("To_LMAC_Data> pcVoiceDataBuffer invalid. i=%d, pcVoiceDataBuffer=0x%08x, end=0x%08x\n", i, xMceiBuffer[i].pcVoiceDataBuffer, &end);
									ptr = (char *)&(xMceiBuffer[i]) ;
									ptr -= 512 ;
									util_dump_data(ptr, sizeof(xMceiBuffer[0]) * 2 + 512, 0, 0, "xMceiBuffer=", 1); iprintf("\n");
						 }
#endif
#endif /* SUPERTASK */

						 iVoiceInfo = TAPI_VOICE_PACKET_SUB_TYPE(pcVoiceDataBuffer[TAPI_VOICE_PACKET_SUB_TYPE_INDEX]);
						 if (iVoiceInfo == NARROWBAND_PKT) {
									if (total_len > (Max_spi_data_len_val - (NARROWBAND_PKT_LENGTH+VOICE_HEADER_LENGTH))) { 
											  break;
									}
						 } else if (iVoiceInfo == WIDEBAND_PKT) {
									if (total_len > (Max_spi_data_len_val - (WIDEBAND_PKT_LENGTH+VOICE_HEADER_LENGTH))) {
											  break;
									}
						 }
						 /* cmd */
						 data[data_index++] = COSIC_VOICE_PACKET;
						 /* length */
						 if (iVoiceInfo == NARROWBAND_PKT) {
#ifdef SUPERTASK
									cosic_printf("N");
#endif
									iVoiceLen = NARROWBAND_PKT_LENGTH;	/* force setting */
						 } else if (iVoiceInfo == WIDEBAND_PKT) {
#ifdef SUPERTASK
									cosic_printf("W");
#endif
									iVoiceLen = WIDEBAND_PKT_LENGTH;	/* force setting */
						 }
						 /* voice len +  mcei num + voice infor & cyclic */
						 data[data_index++] = iVoiceLen + 2;
						 /* MCEI num */
						 data[data_index++] = i;
						 /* voice info + cyclic_index */
						 data[data_index] = iVoiceInfo<< 4;
						 data[data_index++] |= (TAPI_VOICE_PACKET_SEQ(pcVoiceDataBuffer[TAPI_VOICE_PACKET_SEQ_INDEX])& 0x0F);
						 /* voice stream */
						 for (j = 0; j < iVoiceLen; j++) {
#ifdef VOICE_DATA_NIBBLE_SWAP
									if (iVoiceLen < MAX_TAPI_VOICE_BUFFER_SIZE) {
											  data[data_index++] = ((pcVoiceDataBuffer[TAPI_VOICE_PACKET_HEADER_LEN+j]<<4)&0xF0) |
														 ((pcVoiceDataBuffer[TAPI_VOICE_PACKET_HEADER_LEN+j]>>4)&0x0F);
									} else {
											  data[data_index++] = pcVoiceDataBuffer[TAPI_VOICE_PACKET_HEADER_LEN + j];
									}
#else
									data[data_index++] = pcVoiceDataBuffer[TAPI_VOICE_PACKET_HEADER_LEN + j];
#endif
						 }
						 BUFFER_POOL_PUT(pcVoiceDataBuffer);
#ifdef SUPERTASK
						 cosic_buffer_cnt--;
#endif
						 /* increase total length - cmd + length + mcei num + 
						  * voice info & cyclic + voice pkt len	*/
						 total_len += (iVoiceLen + 4);
						 /* For Min 2 packet, prioritization*/
						 /* Changed to if 1 to avoid delay in internal calls */
						 voice_packet_cnt++;
  #ifdef LINUX
	if(voice_packet_cnt >= 2)
	{
		break;
	}
  #endif
#ifdef SUPERTASK
#ifdef SBB //not required
						 /* transfer 2 voice packet  1 times */
#if (MAX_SPI_DATA_LEN > 256)
						 if(voice_packet_cnt >= 4)
#else
									if(voice_packet_cnt >= 3)
#endif
									{
											  break;
									}
#endif /* SBB */
#endif /* SUPERTASK */
			  }/*pcVoiceDataBuffer != NULL*/
	}/*i for loop*/
#ifdef LINUX
	/*If No voice active*/
	//if(!voice_packet_cnt)
	//	break;
#endif /* LINUX */
	}/* while voice_packet_cnt*/

   /*********************/
   /* GET FU10/MAC data */
   /*********************/
   /* just one packet data system have many problem never change please */
   while (Dect_Drv_Get_Data((HMAC_QUEUES*)&temp_hmac) != DECT_DRV_HMAC_BUF_EMPTY) {
      hmac_ptr = (HMAC_QUEUES*)&temp_hmac;
      #ifdef CATIQ_UPLANE
      if (hmac_ptr->MSG==MAC_FU10_DATA_RQ) {
         /*printk("<TX FU10>");*/
         data[data_index++] = COSIC_DECT_FU10_PACKET;
         sendlen=data[data_index++] = sizeof(HMAC_QUEUES);
      }
      #ifdef ULE_SUPPORT
      else if ((hmac_ptr->MSG==LMAC_ULE_FU10_DATA_REQ) || (hmac_ptr->MSG==LMAC_ULE_FU10_RDY_REL_REQ) || (hmac_ptr->MSG==LMAC_ULE_PAGE_REQ)) {
         /*printk("<TX ULE>");*/
         data[data_index++] = COSIC_DECT_ULE_FU10_PACKET;
         sendlen=data[data_index++] = sizeof(ULE_HMAC_QUEUES);
      }
      #endif
      else {
         data[data_index++] = COSIC_MAC_PACKET;
         /*Copy current inc to correct position*/
         hmac_ptr->G_PTR_buf[11]=hmac_ptr->CurrentInc;
         sendlen=data[data_index++] = 17; /*proc,msg,p1,p2 p3 p4 data[10],currentinc*/
      }
      total_len += (sendlen + 2); /* Data + cmd + length */
      #elif defined(ULE_SUPPORT)
      if ((hmac_ptr->MSG==LMAC_ULE_FU10_DATA_REQ) || (hmac_ptr->MSG==LMAC_ULE_FU10_RDY_REL_REQ) || (hmac_ptr->MSG==LMAC_ULE_PAGE_REQ)) {
         /*printk("<TX ULE>");*/
         data[data_index++] = COSIC_DECT_ULE_FU10_PACKET;
         sendlen=data[data_index++] = sizeof(ULE_HMAC_QUEUES);
      } else {
         data[data_index++] = COSIC_MAC_PACKET;
         /*Copy current inc to correct position*/
         hmac_ptr->G_PTR_buf[11]=hmac_ptr->CurrentInc;
         sendlen=data[data_index++] = 17; /*proc,msg,p1,p2 p3 p4 data[10],currentinc*/
      }
      total_len += (sendlen + 2); /* Data + cmd + length */
      #else
      data[data_index++] = COSIC_MAC_PACKET;
      sendlen=data[data_index++] = sizeof(HMAC_QUEUES);
      total_len += ((sizeof(HMAC_QUEUES))+2);		/* HMAC_QUEUES size + cmd + length */
      #endif

      /* message matching [[ */
      #ifdef CATIQ_UPLANE
      /*Do message mapping only for non FU10 data*/
      if (hmac_ptr->MSG != MAC_FU10_DATA_RQ) {    
      #endif
         i = 0;
         while (1) {
            if (Message_Map_Table[i][1] == hmac_ptr->MSG) {
               hmac_ptr->MSG = Message_Map_Table[i][0];
               #ifdef VOICE_MUTE_SERVICE_CHANGE
               #ifdef SUPERTASK
               if(hmac_ptr->MSG == LMACCmd_SWITCH_HO_TO_TB_RQ_HMAC){
                 // cosic_printf("HO req\n");
                 voice_mute_cnt[hmac_ptr->Parameter1] = 100;
               }
               #endif
               if (hmac_ptr->MSG == LMACCmd_SLOTTYPE_MOD_RQ_HMAC) {
   				   voice_mute_cnt[hmac_ptr->Parameter1] = 100;/*Took from intinix rel 140409*/
                  #ifdef SUPERTASK
                  // cosic_printf("\n*V[%d]\n",hmac_ptr->Parameter1);
                  #endif
               }
               #endif
               break;
            }

            if (Message_Map_Table[i][0] == 0xFF) {
               #ifdef LINUX
               IFX_COSIC_DMSG(" 0xFF packet???  hmac_ptr->MSG=0x%x\n",hmac_ptr->MSG);
               #endif
               #ifdef SUPERTASK
               printk(" 0xFF packet???  hmac_ptr->MSG=0x%x\n",hmac_ptr->MSG);
               #endif
               hmac_ptr->MSG = 0xFF;
               break;
            }
            i++;
         }
         /* message matching ]] */
      #ifdef CATIQ_UPLANE
      }
      #endif

      if (hmac_ptr->MSG != 0xFF) {
         for (i = 0; i < sendlen; i++) {
            data[data_index++] = temp_hmac[i];
         }
         lmac_packet_cnt++;
         #ifdef LINUX
         if (lmac_packet_cnt > 6) {
            //printk("over packet, total_len=%d, data_index=%d???\n",total_len,data_index);
         }
         #endif /* LINUX */
         #ifdef SUPERTASK
         #ifdef SBB //not required
         if(lmac_packet_cnt > 6) {
           printk("over packet, total_len=%d, data_index=%d???\n",total_len,data_index);
           break;
         }
         #endif
         #endif /* SUPERTASK */
      }
      if (total_len < (Max_spi_data_len_val - (2+sizeof(HMAC_QUEUES)))) {
         continue;
      } else {
         break;
      }
   }
   
   if ((total_len+2) != data_index) {
      printk("MAC/FU10: total_len %d. data_index %d\xd\xa",total_len,data_index);
   }

   if (total_len < (Max_spi_data_len_val - 50)) {
      /* GET Debug data */
	   while (Dect_Debug_Get_Data((DECT_MODULE_DEBUG_INFO*)&temp_hmac) != DECT_DRV_HMAC_BUF_EMPTY) {
         #ifdef LINUX
         IFX_COSIC_DMSG("GET DEBUG INFOMATION\n");
         #endif
         #ifdef SUPERTASK
         //printk("GET DEBUG INFOMATION\n");
         #endif
         
         total_len += ((sizeof(DECT_MODULE_DEBUG_INFO))+2); /* HMAC_QUEUES size + cmd + length */

         data[data_index] = COSIC_DECT_DEBUG_PACKET;
         data_index++;
         data[data_index] = sizeof(DECT_MODULE_DEBUG_INFO);
         data_index++;

         /* message matching [[ */
         hmac_ptr = (HMAC_QUEUES*)&temp_hmac;
         for (i = 0; i < sizeof(DECT_MODULE_DEBUG_INFO); i++) {
            data[data_index++] = temp_hmac[i];
         }
         debug_packet_cnt++;
         if (total_len > (Max_spi_data_len_val - 50)) {
            break;
         }
         #ifdef LINUX
         if (debug_packet_cnt > 6) {
            IFX_COSIC_DMSG("over packet???\n");
            break;
         }
         #endif /* LINUX */
         #ifdef SUPERTASK
         #ifdef SBB  //not required
         if(debug_packet_cnt > 6) {
            printk("over packet???\n");
            break;
         }
         #endif
         #endif /* SUPERTASK */
      }
   }

   /* TX dummy data for rx tx interrupt sync */
   if (total_len == 0) {
      total_len = 0x02;
       data[data_index++] = COSIC_MAC_PACKET;
       data[data_index++] = 0x00;
   }
   if (vucDriverMode == DECT_DRV_SET_LOADER_MODE) {
      data[data_index++] = 0xFF;
   }

   data[COSIC_DATA_HIGH_LENGTH] = ((total_len & 0xFF00) >> 8);
   data[COSIC_DATA_LOW_LENGTH] = total_len & 0x00FF;
}

#ifdef SUPERTASK
/*******************************************************************************
*  Function Name: Show Loss
*  Description:	This function display Cosic Modem statistics
*  Arguments: nothing


*******************************************************************************/
int show_loss()
{
   char acbuff[1000];
   int iLen=0,i=0;

   dect_drv_read_version_proc(acbuff);
   iprintf("**************VERSION INFO ***************\n\n\t\t%s\n\n",acbuff);
   iLen=dect_drv_read_gw_stats_proc(acbuff);
   iprintf("**************GW STATS ***************\n\n\t\t\n\n");
   while(i < iLen)
   {
      iprintf("%c",acbuff[i++]);
   }
   iLen=dect_drv_read_modem_stats_proc(acbuff);
   //iprintf("\n**************Modem STATS ***************\n\n\t\t%s\n\n",acbuff);
   iprintf("\n\n\n**************Modem STATS ***************\n\n\n");
   i=0;
   while(i < iLen)
   {
      iprintf("%c",acbuff[i++]);
   }
   iprintf("\n**************Modem Restart Count (Should be 1)***************\n\n\t\t%d\n\n",iModemRestartCount);
   iprintf("\n**************Cosic Thread STATS ***************\n\n\t\t%d\n\n",spitaskchk);
   iprintf("\n**************iCosicMode ***************\n\n\t\t%d\n\n",iCosicMode);
   iprintf("\n**************iCosicCS Tx: %d Rx : %d  CS  : %d***************\n",ichipCSRxCount,ichipCSTxCount,ichipCSCount);
   iprintf("\nFirst Byte Rx from COSIC %x\n",iFirstByteRx);
   iFirstByteRx=0x00;
}
#endif /* SUPERTASK */

#if !defined(CONFIG_DANUBE) || defined(SUPERTASK)
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,10,00)
/******************************************************************
 *  Function Name  : gp_onu_gpio_write_with_bit_mask 
 *  Description    : This function OR's the GPIO register with
 *                   updated value after masking with bitmask
 *  Input Values   : addr - Register address
 *                   value - Value to be ORed ro existing content
 *                   bit_mask - Bit mask to be applied on given register
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
static void gp_onu_gpio_write_with_bit_mask(volatile unsigned long *addr, 
                                volatile unsigned long value,
                                volatile unsigned long bit_mask)
{
   volatile unsigned long reg_value;

   reg_value = *addr;
   reg_value &= (~bit_mask);
   reg_value |= value;
   *addr = reg_value;
   return;
}
#endif
#endif

/******************************************************************
 *  Function Name  : Dect_GPIO_interrupt
 *  Description    : LMAC GPIO interrupt routine 
 *  Input Values   : irq - Interrupt req number
 *                   dev_id device id
 *  Output Values  : None
 *  Return Value   : Status of IRQ handling
 *  Notes          : 1. occur LMAC GPIO interrupt
 *                   2. clear GPIO interrupt
 *                   3. schedule tasklet/wakeup cosic thread
 * ****************************************************************/
#ifdef LINUX
irqreturn_t  Dect_GPIO_interrupt(int irq, void *dev_id) 
#endif
#ifdef SUPERTASK
void Dect_GPIO_interrupt()
#endif
{ 
   /* Acknowledge the interrupt  */
	ACKNOWLEDGE_IRQ;
	gw_stats.uiInt++;/*Total number of interrupts got from cosic modem*/
   #ifdef SUPERTASK
   ack_danube_irq(dect_gpio_intnum);
   #endif
   /* for waiting dect application active */
   #ifdef LINUX
   #if 1
   if(starting_cnt < 2000){		
      starting_cnt++;
      return IRQ_HANDLED;
   }
   #endif
   #endif /* LINUX */
   #ifdef SUPERTASK
   //QTMW:Get more stable on COSIC init.
   if (starting_cnt < 2000) {
      starting_cnt++;
      return;
   }

	cosic_int_cnt++;
   #if 1
   if ((cosic_int_cnt%12000)==0 && cosic_int_cnt<100000) {
   // if ((cosic_int_cnt%24000)==0) {
      unsigned long curr = get_sys_time();
      tmp_iprintf_onoff(1);
      iprintf("X (%d)cosic_int_cnt %d %d/1000 spitaskchk %d\n"
      ,curr,cosic_int_cnt,(curr-cosic_int_cnt_pre)/12,spitaskchk);
      tmp_iprintf_onoff(0);
      cosic_int_cnt_pre=curr;
   }
   #endif
   #endif /* SUPERTASK */
#if 0
   if (IntEdgFlg) {
		printk("Rising Edge\n");
	}
	else
	{
		printk("Falling Edge\n");
	}
#endif
#ifdef CONFIG_SMP1
	spin_lock(&IntEdgFlgLock);
#endif
   if (IntEdgFlg) {
      IntEdgFlg =0;/*Flag set for next int i,e falling edge*/

#ifdef CONFIG_SMP1
	spin_unlock(&IntEdgFlgLock);
#endif
      /*Rising edge so next should be for falling edge*/
      CONFIGURE_FALLING_EDGE_INT;
      #ifdef LINUX
      if (atomic_read(&vuiIgnoreint) == 1) {
         if (atomic_read(&vuiGwDbgFlag) == 1) {
#ifdef CONFIG_SMP1
   spin_lock(&IntEdgFlgLock);
#endif
            if (iCosicMode) 
				{
               gw_stats.uiLossRx++; /*Total number of rising interrupt ignored due to Rx operation @ GW means Rising int comes before RxCB*/
            } else {
               gw_stats.uiLossTx++;/*Total number of rising interrupts ignored due to Tx operation @ GW means Rising int comes before TxCB*/
            }
#ifdef CONFIG_SMP1
   spin_unlock(&IntEdgFlgLock);
#endif
         }
			//printk("Returning as RBusy\n");
			return IRQ_HANDLED;
		}
		#endif /* LINUX */
		#ifdef SUPERTASK
      if ((protest_fg == 1)&&(cosic_thread_running==1) ||
          (protest_fg == 0)&&(cosic_thread_running==1) ||
   	    (protest_fg == 1)&&(cosic_thread_running==0)) {
   	   ignore_cnt++;
         if (vuiGwDbgFlag==1) {
       	   if (iCosicMode) {
          	   gw_stats.uiLossRx++; /*Total number of rising interrupt ignored due to Rx operation @ GW */
   	      } else {
          	   gw_stats.uiLossTx++;/*Total number of rising interrupts ignored due to Tx operation @ GW */
   	 		}
   		}
         #if 0
         tmp_iprintf_onoff(1);
         iprintf("SBB:Rising Edge : IGE=1\n");
         tmp_iprintf_onoff(0);
         #endif

         return;
      }
		#endif /* SUPERTASK */
		#ifdef CONFIG_SMP1
   		spin_lock(&IntEdgFlgLock);
		#endif
      if ((iDriverStatus  == LMAC_BOOT_IND) && (viSPILocked)) 
		{
			#ifdef CONFIG_SMP1
   			spin_unlock(&IntEdgFlgLock);
			#endif

         #ifdef LINUX
         atomic_set(&vuiIgnoreint,1);
         i_CosicData1 =1;
			printk("Scheduling Unlock TL\n");
         tasklet_hi_schedule(&x_IFX_Cosic_Tasklet1);/*schedule tasklet for rising edge unlock*/
         //viSPIUnLockSchedule =0;
         #endif /* LINUX */
         #ifdef SUPERTASK
         /* SPI locked; so unlock*/
         ifx_sscCosicUnLock();
         #ifdef TRACE_BACK
         Update_CT(1);
         #endif
         #endif /* SUPERTASK */
      }
		else
		{
			#ifdef CONFIG_SMP1
   			spin_unlock(&IntEdgFlgLock);
			#endif
		}

      #ifdef LINUX
      return IRQ_HANDLED;
      #endif
      #ifdef SUPERTASK
      return;
      #endif
   } else {

      IntEdgFlg =1;/*Flag set for next int i,e Rising edge*/
      gw_stats.uiTmpInt++;/*Total number of falling interrupts used to calculate interrupts interval missed*/

#ifdef CONFIG_SMP1
   spin_unlock(&IntEdgFlgLock);
#endif
      /*falling edge so next should be for rising edge*/
      CONFIGURE_RISING_EDGE_INT;

      #ifdef LINUX
      if (atomic_read(&vuiIgnoreint) == 1) {
			//printk("Returning as FBusy");
         return IRQ_HANDLED;
      }
      #endif
      #ifdef SUPERTASK
      if ((protest_fg == 1) && (cosic_thread_running == 1)) {
         ignore_cnt++;
         #if 0
         tmp_iprintf_onoff(1);
         iprintf("SBB:Falling Edge : IGE=1\n");
         tmp_iprintf_onoff(0);
         #endif

         return;
      }
      #endif
   }

   #ifdef LINUX
   /* wake up cosic thread */
   //Dect_mutex_free = 1;
   #endif

   /* No Tx or Rx is going on; but still SPI locked for falling edge;So unlock and return 
      so that other should get a chance to access SPI */
	#ifdef CONFIG_SMP1
   	spin_lock(&IntEdgFlgLock);
	#endif
   if ((iDriverStatus  == LMAC_BOOT_IND) && (viSPILocked)) 
	{
      i_CosicData1 =0;
		#ifdef CONFIG_SMP1
   		spin_unlock(&IntEdgFlgLock);
		#endif
      #ifdef LINUX
      atomic_set(&vuiIgnoreint,1);
		printk("scheduling FUnlock TL\n");
      tasklet_hi_schedule(&x_IFX_Cosic_Tasklet1);/*schedule tasklet for falling edge unlock*/
      return IRQ_HANDLED;
      #endif /* LINUX */
      #ifdef SUPERTASK
      ifx_sscCosicUnLock();
      #ifdef TRACE_BACK
      Update_CT(2);
      #endif
      gw_stats.uiUnLockFallEdge++;/*Total number of falling interrupts  @ GW used to unlock the SPI*/
      //return ;
      #endif /* SUPERTASK */
   }
	else
	{
		#ifdef CONFIG_SMP1
   		spin_unlock(&IntEdgFlgLock);
		#endif
	}	

   #ifdef LINUX
   atomic_set(&vuiIgnoreint,1);
   //printk("scheduling F Normal Process TL\n");
   tasklet_hi_schedule(&x_IFX_Cosic_Tasklet);/*schedule tasklet for falling edge Tx/Rx*/
   //viSPIUnLockSchedule =1;
   return IRQ_HANDLED;
   #endif
   #ifdef SUPERTASK
	lost_in_seq =0;
	protest_fg=1;
	OS_SetEvent(__COSIC_DECT_EVENT);
   #endif
} 

/******************************************************************
 *  Function Name  : trigger_cosic_driver
 *  Description    : This function triggers the cosic driver
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          :
 * ****************************************************************/
void trigger_cosic_driver( void )
{
#ifdef LINUX
   //Dect_mutex_free = 1;
   tasklet_hi_schedule(&x_IFX_Cosic_Tasklet);
#endif
#ifdef SUPERTASK
   static int cnt=0;

   OS_SetEvent(__COSIC_DECT_EVENT);
   cnt++;
   if (cnt%5==0) {
      tmp_iprintf_onoff(1);
      iprintf("trigger_cosic_driver %d\n",cnt);
      tmp_iprintf_onoff(0);
   }
#endif
}

/******************************************************************
 *  Function Name  : gp_onu_enable_external_interrupt 
 *  Description    : This function enables the GPIO interrupt
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void gp_onu_enable_external_interrupt(void)
{
#ifdef LINUX
    #ifdef KLOCWORK
	unsigned long flags=0;
	#else
	unsigned long flags;	
	#endif

   #if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
   		CONFIGURE_FALLING_EDGE_INT;
   #elif defined CONFIG_AMAZON_S
		/* setting falling edge setting */
		gp_onu_gpio_write_with_bit_mask((unsigned long*)AMAZON_S_ICU_EIU_EXIN_C, (0x02000),(0x07000));
		                                                                            
		/* external 5 interrupt enable */
		gp_onu_gpio_write_with_bit_mask((unsigned long*)AMAZON_S_ICU_EIU_INEN, (8),(8));
   #elif defined CONFIG_AR9
		/* setting falling edge setting */
		gp_onu_gpio_write_with_bit_mask((unsigned long*)IFX_ICU_EIU_EXIN_C, (0x02000),(0x07000));
		/* external 5 interrupt enable */
		gp_onu_gpio_write_with_bit_mask((unsigned long*)IFX_ICU_EIU_INEN, (8),(8));
   #elif defined(CONFIG_VR9)||defined(CONFIG_AR10)
	   /* setting falling edge setting */
	   gp_onu_gpio_write_with_bit_mask((unsigned long*)IFX_ICU_EIU_EXIN_C, (0x0200000),(0x0700000));

	   /* external 5 interrupt enable */
	   gp_onu_gpio_write_with_bit_mask((unsigned long*)IFX_ICU_EIU_INEN, (0x32),(0x32));
   #endif

#if 0
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
	CONFIGURE_FALLING_EDGE_INT;
#endif
#endif

	irq_safe_lock(flags);
	IntEdgFlg = 0; /*Indicates falling edge*/
	irq_safe_unlock(flags);
#endif /* LINUX */
#ifdef SUPERTASK
   #ifdef _INFXR9
   /* setting falling edge setting */
   gp_onu_gpio_write_with_bit_mask((unsigned long*)IFX_ICU_EIU_EXIN_C, (0x0000020),(0x0000070));
   IntEdgFlg = 0; /*Indicates falling edge*/
   
   /* external 1 interrupt enable */
   gp_onu_gpio_write_with_bit_mask((unsigned long*)IFX_ICU_EIU_INEN, (0x02),(0x02));
   #else
   gp_onu_gpio_write_with_bit_mask((unsigned long*)DANUBE_ICU_EIU_EXIN_C, (0x0200),(0x0700));
   /* external 2 interrupt enable */
   IntEdgFlg = 0; /*Indicates falling edge*/
   gp_onu_gpio_write_with_bit_mask((unsigned long*)DANUBE_ICU_EIU_INEN, (4),(4));
   #endif
#endif /* SUPERTASK */
}

/******************************************************************
 *  Function Name  : gp_onu_disable_external_interrupt 
 *  Description    : This function disables the GPIO interrupt
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void gp_onu_disable_external_interrupt(void)
{
#ifdef LINUX
	/* Disable interrupt */
	#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
	   disable_irq(DECT_IRQ_NUM);


   #elif defined CONFIG_AMAZON_S
   gp_onu_gpio_write_with_bit_mask((unsigned
   long*)AMAZON_S_ICU_EIU_INEN, (0),(8));
   #elif defined CONFIG_AR9
   gp_onu_gpio_write_with_bit_mask((unsigned long*)IFX_ICU_EIU_INEN, (0),(8));
   #elif defined(CONFIG_VR9)||defined(CONFIG_AR10)
   gp_onu_gpio_write_with_bit_mask((unsigned long*)IFX_ICU_EIU_INEN, (0),(0x32));
   #endif

#endif /* LINUX */
#ifdef SUPERTASK
   /* external 2 interrupt enable */
   #ifdef _INFXR9
   gp_onu_gpio_write_with_bit_mask((unsigned long*)IFX_ICU_EIU_INEN, (0),(0x02));
   #else
   gp_onu_gpio_write_with_bit_mask((unsigned long*)DANUBE_ICU_EIU_INEN, (0),(4));
   #endif
#endif /* SUPERTASK */
}

/******************************************************************
 *  Function Name  : Dect_int_GPIO_init
 *  Description    : GPIO interrupt setting for LMAC
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void Dect_int_GPIO_init(void)
{
#ifdef LINUX
   #if defined (CONFIG_AR9) || defined (CONFIG_VR9) || defined (CONFIG_DANUBE) || defined (CONFIG_AR10)
   ifx_gpio_register(IFX_GPIO_MODULE_DECT);
   #endif	
   #ifdef CONFIG_DANUBE
   ifx_gpio_pin_reserve(21,IFX_GPIO_MODULE_DECT);
   ifx_gpio_altsel0_set(21,IFX_GPIO_MODULE_DECT);
   ifx_gpio_altsel1_set(21,IFX_GPIO_MODULE_DECT);
   ifx_gpio_dir_in_set(21,IFX_GPIO_MODULE_DECT);
   ifx_gpio_open_drain_clear(21,IFX_GPIO_MODULE_DECT);
   ifx_gpio_pudsel_set(21,IFX_GPIO_MODULE_DECT);
   ifx_gpio_puden_set(21,IFX_GPIO_MODULE_DECT);
   ifx_gptu_timer_request(TIMER2A, TIMER_FLAG_16BIT|TIMER_FLAG_COUNTER|TIMER_FLAG_ONCE|\
                          TIMER_FLAG_DOWN|0x40|\
                          TIMER_FLAG_UNSYNC|\
                          TIMER_FLAG_NO_HANDLE, 1, 0, 0);
   /*configure 2A counter for Falling Edge*/
   *(unsigned long *) GPT_CTRL_REG_COUNTER_2A = 0x0000008C;
   /*load the counter value 1 ro 2A counter of GPT*/
   *(unsigned long *) GPT_RELOAD_REG_2A = 0x00000001;
   /*Enable 2A GPT counter*/
   *(unsigned long *) GPT_INT_NODE_EN_REG|= 0x04;
   /*Reloads the counter value when starts + Enable bit of CON will be set for GPT 2A counter*/
   *(unsigned long *) GPT_RUN_REG_2A = 0x00000005;
   #endif	
   #if 0
   if(vucDriverMode != DECT_DRV_SET_APP_MODE){ 
      /* 2. reset pin setting low */
      ssc_dect_haredware_reset(0);
      //ssc_dect_debug(0);

      /* 3. delay 10ms */
      udelay(10000);	

      /* 4. reset pin setting high */
      ssc_dect_haredware_reset(1);
   }
   #endif
#endif /* LINUX */
#ifdef SUPERTASK
   #ifdef DEMO_BOARD
   //Demo board use GPIO20 for Reset DECT
   //Use SPI CS4(GPIO10)
   //Use GPIO2 as EXIN(input)
   //Use GPIO28 as Output
   uint32_t gpio_p0_in;
   uint32_t gpio_p0_dir;
   uint32_t gpio_p0_alt0;
   uint32_t gpio_p0_alt1;
   uint32_t gpio_p0_pudsel;
   uint32_t gpio_p0_puden;
   uint32_t gpio_p0_0d;
   
   //using P0.0 EXIN(0) as input
   printk("ifx_dect_int_GPIO_init\n");
   gpio_p0_in = *(DANUBE_GPIO_P0_IN);
   gpio_p0_dir = *(DANUBE_GPIO_P0_DIR);
   gpio_p0_alt0 = *(DANUBE_GPIO_P0_ALTSEL0);
   gpio_p0_alt1 = *(DANUBE_GPIO_P0_ALTSEL1);
   gpio_p0_pudsel = *(DANUBE_GPIO_P0_PUDSEL);		// gpio PORT 0 PULL UP ENABLE
   gpio_p0_puden = *(DANUBE_GPIO_P0_PUDEN);		// gpio PORT 0 PULL UP ENABLE
   gpio_p0_0d = *(DANUBE_GPIO_P0_OD);		// this open drain
   
   gpio_p0_in |= (4);
   gpio_p0_dir &= ~(4);
   gpio_p0_alt0 &= ~(4);
   gpio_p0_alt1 |= (4);
   gpio_p0_pudsel |= (4);		// gpio PORT 0 PULL UP			hiryu_20070816 test
   gpio_p0_puden |= (4);		// gpio PORT 0 PULL UP ENABLE
   
   printk("gpio_p0_in %x\n", gpio_p0_in);
   printk("gpio_p0_dir %x\n", gpio_p0_dir);
   printk("gpio_p0_alt0 %x\n", gpio_p0_alt0);
   printk("gpio_p0_alt1 %x\n", gpio_p0_alt1);
   printk("gpio_p0_pudsel %x\n", gpio_p0_pudsel);
   printk("gpio_p0_puden %x\n", gpio_p0_puden);
   printk("gpio_p0_0d %x\n", gpio_p0_0d);
   
   *(DANUBE_GPIO_P0_IN) = gpio_p0_in;
   *(DANUBE_GPIO_P0_DIR) = gpio_p0_dir;
   *(DANUBE_GPIO_P0_ALTSEL0) = gpio_p0_alt0;
   *(DANUBE_GPIO_P0_ALTSEL1) = gpio_p0_alt1;
   *(DANUBE_GPIO_P0_PUDSEL) = gpio_p0_pudsel;		// gpio PORT 0 PULL UP			hiryu_20070816 test
   *(DANUBE_GPIO_P0_PUDEN) = gpio_p0_puden;		// gpio PORT 0 PULL UP ENABLE
   
   /* configuring SPI CS pin - GPIO10 Out P0.10 */
   *(DANUBE_GPIO_P0_ALTSEL0) = (*DANUBE_GPIO_P0_ALTSEL0) & 0x0000fbff;
   *(DANUBE_GPIO_P0_ALTSEL1) = (*DANUBE_GPIO_P0_ALTSEL1) | 0x00000400;
   *(DANUBE_GPIO_P0_DIR)     = (*DANUBE_GPIO_P0_DIR) | 0x00000400;
   *(DANUBE_GPIO_P0_OD)      = (*DANUBE_GPIO_P0_OD)| 0x00000400;
   
   // TODO: reset pin setting sequence
   
   //1   1. setting dect hardware reset pin setting
   //GPIO20 Out  P1.4 	// DECT reset output setting
   *(DANUBE_GPIO_P1_ALTSEL0) = (*DANUBE_GPIO_P1_ALTSEL0) & 0x0000ffef;  //DANUBE_GPIO_P1_ALTSEL0.4 = 0
   *(DANUBE_GPIO_P1_ALTSEL1) = (*DANUBE_GPIO_P1_ALTSEL1)  & 0x0000ffef;  //DANUBE_GPIO_P1_ALTSEL1.4 = 0
   *(DANUBE_GPIO_P1_DIR) = (*DANUBE_GPIO_P1_DIR) | 0x00000010 ; //DANUBE_GPIO_P1_DIR.9 = 1
   
   //		*(DANUBE_GPIO_P1_PUDSEL) = (*DANUBE_GPIO_P1_PUDSEL) | 0x00000010;
   //		*(DANUBE_GPIO_P1_PUDEN) =  (*DANUBE_GPIO_P1_PUDEN) | 0x00000010 ;
   
   /* gpio28 - P1.12*/
   *(DANUBE_GPIO_P1_ALTSEL0) = (*DANUBE_GPIO_P1_ALTSEL0) & 0x0000efff;  //DANUBE_GPIO_P1_ALTSEL0.12 = 0
   *(DANUBE_GPIO_P1_ALTSEL1) = (*DANUBE_GPIO_P1_ALTSEL1) & 0x0000efff;  //DANUBE_GPIO_P1_ALTSEL1.12 = 0
   *(DANUBE_GPIO_P1_DIR) = (*DANUBE_GPIO_P1_DIR) | 0x00001000 ; //DANUBE_GPIO_P1_DIR.12 = 1
   #else
   #ifdef _INFXR9
   ifx_gpio_register(IFX_GPIO_MODULE_DECT);  /* For VR9 */
   ifx_gpio_register(IFX_GPIO_MODULE_PAGE);  /* For VR9 */
   #else
   #endif
   #endif
   //1   2. reset pin setting low
   ssc_dect_haredware_reset(0);
   
   //ssc_dect_debug(0);
   __udelay__(2000);
   __udelay__(2000);
   __udelay__(2000);
   __udelay__(2000);
   __udelay__(2000);
   //1   4. reset pin setting high
   //	ssc_dect_debug(1);
   ssc_dect_haredware_reset(1);
#endif /* SUPERTASK */
}

/******************************************************************
 *  Function Name  : ssc_dect_debug 
 *  Description    : This function enables the debugging of SSC for
 *                   DEC
 *  Input Values   : Flag indicating Enable/Disable
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
int ssc_dect_debug(int on)
{
   if (on) {
      #ifdef LINUX
      #ifdef CONFIG_AMAZON_S
      *(AMAZON_S_GPIO_P1_OUT) = (*AMAZON_S_GPIO_P1_OUT)| (0x00001000);
      #elif defined(CONFIG_DANUBE)
      *(IFX_GPIO_P1_OUT) = (*IFX_GPIO_P1_OUT)| (0x00001000);
      #elif defined CONFIG_AR9
      *(IFX_GPIO_P1_OUT) = (*IFX_GPIO_P1_OUT)| (0x00001000);
      #endif
      #endif /* LINUX */
   } else {
      #ifdef LINUX
      #ifdef CONFIG_AMAZON_S
      *(AMAZON_S_GPIO_P1_OUT) = (*AMAZON_S_GPIO_P1_OUT) & (0x0000efff);
      #elif defined(CONFIG_DANUBE)
      *(IFX_GPIO_P1_OUT) = (*IFX_GPIO_P1_OUT) & (0x0000efff);
      #elif defined CONFIG_AR9
      *(IFX_GPIO_P1_OUT) = (*IFX_GPIO_P1_OUT) & (0x0000efff);
      #endif
      #endif /* LINUX */
   }
   return 0;
}

#ifdef LINUX
/******************************************************************
 *  Function Name  : ifx_cosic_AsyncLockCB
 *  Description    : Callback invoked on successfully locking the 
 *                   SPI bus
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : SPI bus is locked for our usage, So start receiving
 *                   cosic messages
 * ****************************************************************/
void ifx_cosic_AsyncLockCB(int iHandle, int iRetVal)
{
#if 0
#ifdef CONFIG_SMP
      #ifdef KLOCWORK
   	unsigned long flags=0;
	   #else
		unsigned long flags;
		#endif
   	spin_lock_irqsave(&IntEdgFlgLock,flags);
#endif

   if (FirstLock == 1) {
      FirstLock=2;
#ifdef CONFIG_SMP
   spin_unlock_irqrestore(&IntEdgFlgLock,flags);
#endif

      if(vucDriverMode != DECT_DRV_SET_APP_MODE){ 
         printk("\n AsyncLockCB: First Lock\n");
         /* 4. reset pin setting high moved to Set Loader mode*/
         //ssc_dect_haredware_reset(1);
      }
      return;
   }
#ifdef CONFIG_SMP
	else
	{
   spin_unlock_irqrestore(&IntEdgFlgLock,flags);
	}
#endif

#endif
   if(spi_dev_handler == NULL)
		  return;

   printk("\nAsyncLockCB\n");
   if (iCosicMode == 0) {
      uiReq = 1;
   printk("\n ifx_sscCosicTx\n");
      ifx_sscCosicTx();
   } else { 
      uiReq = 2;
   printk("\nifx_sscCosicRx\n");
      ifx_sscCosicRx();
   }
   return;
}
#endif /* LINUX */

#ifdef LINUX
/******************************************************************
 *  Function Name  : ifx_cosic_AsyncTxCB
 *  Description    : Callback invoked on successfully locking the 
 *                   Tx
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void ifx_cosic_AsyncTxCB(int iHandle, int iRetVal)
{
   #ifdef KLOCWORK
	unsigned long flags=0;
	#else
   unsigned long flags;
   #endif
   if (uiReq == 1) {
      uiResp = 1;
   }
	printk("Entry ifx_cosic_AsyncTxCB \n");
   atomic_set(&vuiIgnoreint,0);
   irq_safe_lock(flags);
   if (IntEdgFlg == 0) { /*means rising edge int got*/
   	irq_safe_unlock(flags);
      ifx_sscCosicUnLock();
      //gw_stats.uiUnLockAtTxCB++;
   }
	else
	{
   	irq_safe_unlock(flags);
	}
   atomic_set(&vuiIgnoreint,0);
	printk("Exit ifx_cosic_AsyncTxCB \n");
   return;
}
#endif /* LINUX */

#ifdef LINUX
void ifx_cosic_driver1(unsigned long ulIntEdge)
{
#ifdef CONFIG_SMP
   #ifdef KLOCWORK
	unsigned long flags=0;
	#else
	unsigned long flags;
	#endif
	printk("Entry ifx_cosic_driver1 \n");
   spin_lock_irqsave(&IntEdgFlgLock,flags);
#endif
   if (i_CosicData1 == 0) {
      gw_stats.uiUnLockFallEdge++;/*Total number of falling interrupts  @ GW used to unlock the SPI*/
   }
#ifdef CONFIG_SMP
   spin_unlock_irqrestore(&IntEdgFlgLock,flags);
#endif
   ifx_sscCosicUnLock();
   atomic_set(&vuiIgnoreint,0);
}
#endif /* LINUX */

#ifdef LINUX
/******************************************************************
 *  Function Name  : ifx_cosic_driver
 *  Description    : Cosic driver functionality executed in tasklet
 *                   or thread mode
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void ifx_cosic_driver(unsigned long ulIntEdge)
{
	#ifdef CONFIG_SMP
      #ifdef KLOCWORK
	   unsigned long flags=0;
      #else
		unsigned long flags;
		#endif
	#endif
	printk("Entry ifx_cosic_driver \n");
	if(atomic_read(&vuiGwDbgFlag)==1)
  {
		unsigned int uiTmp=0;
    gw_stats.uiCdc++;
    gw_stats.uiTmpCdc++;
		uiTmp=gw_stats.uiTmpInt - gw_stats.uiTmpCdc;
    if(uiTmp >= 10)
    {
      gw_stats.auiIntLossSeq[9]++;
    }
    else if(uiTmp > 0)
    {
      gw_stats.auiIntLossSeq[uiTmp - 1]++;
    }
		gw_stats.uiTmpInt=gw_stats.uiTmpCdc=0;/*Reset temp int count.*/
  }

#if 1
	/*If in CoC Confm state and INT occurs and tasklet schedules means COSIC
	gave a signal to exit CoC. No need to wait till to get normal dummy pkt*/
	if(vucDriverMode ==  DECT_DRV_SET_APP_MODE_CoC_CNF)
	{	   
	   vucDriverMode = DECT_DRV_SET_APP_MODE;	 										   
	}
#endif

  switch(cosic_status){
    case COSIC_THREAD_INIT_STATUS:
    break;
				
    /* COSIC THREAD TRANSFER STATUS  [[ */
    case COSIC_THREAD_TRANSFER_STATUS:
      cosic_status = COSIC_THREAD_RECEIVE_STATUS; /*status change*/

#ifdef CONFIG_SMP
   spin_lock_irqsave(&IntEdgFlgLock,flags);
#endif
			iCosicMode = 0;
#ifdef CONFIG_SMP
   spin_unlock_irqrestore(&IntEdgFlgLock,flags);
#endif

      if(ifx_sscCosicLock()<0){
        cosic_status = COSIC_THREAD_TRANSFER_STATUS;/* status change */

#ifdef CONFIG_SMP
   spin_lock_irqsave(&IntEdgFlgLock,flags);
#endif
        iCosicMode = 1;
#ifdef CONFIG_SMP
   spin_unlock_irqrestore(&IntEdgFlgLock,flags);
#endif

      } 
      break;
      /* COSIC THREAD TRANSFER STATUS  ]] */

      /* COSIC THREAD RECEIVE STATUS [[*/
      case COSIC_THREAD_RECEIVE_STATUS:
      {
        unsigned long before_ssc_op = jiffies;	
        cosic_status = COSIC_THREAD_TRANSFER_STATUS;/* status change */

#ifdef CONFIG_SMP
   spin_lock_irqsave(&IntEdgFlgLock,flags);
#endif
        iCosicMode = 1;
#ifdef CONFIG_SMP
   spin_unlock_irqrestore(&IntEdgFlgLock,flags);
#endif

       if(ifx_sscCosicLock()<0){
          cosic_status = COSIC_THREAD_RECEIVE_STATUS; /*status change*/

#ifdef CONFIG_SMP
   spin_lock_irqsave(&IntEdgFlgLock,flags);
#endif
	  iCosicMode = 0;
#ifdef CONFIG_SMP
   spin_unlock_irqrestore(&IntEdgFlgLock,flags);
#endif

        }
        if(jiffies - before_ssc_op > 1){
          //printk("ssc op is screwed \n");
        }
      }
      break;
      /* COSIC THREAD RECEIE STATUS ]]*/
      
      default:
        printk("Invalid cosic status\n");
        break;
  }
}
#endif /* LINUX */

#ifdef SUPERTASK
/*******************************************************************************
Description:	COSIC driver kernel thread
Arguments:
Note:
*******************************************************************************/
IFX_void_t COSIC_drv_Kthread(IFXOS_ThreadParams_t *pthread)
{
   unsigned int dummy_len;
   unsigned int ret;
   unsigned int nSig;
   unsigned long current_access_time,last_access_time;


   unsigned short u16Len =0;
   unsigned char *pucBuf=NULL;
   //struct task_struct *tsk = current;		// for kernel thread priority setting
   while (cosic_module_init==0) {
      dlytsk(getPID(),DLY_TICKS,100);
   }
   //pritsk(getPID(),130);	//for highest Priority Task..
   //return; // if ISR enabled
   //QTMW:Test priority
   pritsk(getPID(),125);	//for highest Priority Task..

   /* we received a request to terminate ourself */
   tmp_iprintf_onoff(1);
   /* we received a request to terminate ourself */
   printk("##### Cosic Thread Is UP and running ######\n");
   tmp_iprintf_onoff(0);

   /* an endless loop in which we are doing our work */
   for(;;) {
      //QTMW:0205 TESTING
      spitaskchk++;

      if (get_sys_time()-lasttime_wdt_trig>75000) {	//update watch dog timer in case that project.c period task not able to run..
         wdt_enable(90);
         lasttime_wdt_trig=get_sys_time();
      }

      if (pthread->bShutDown) {
         if (dect_gpio_intnum != -1) {
            IrqDisable(dect_gpio_intnum);
            IrqDisconnect(dect_gpio_intnum);
            ifx_sscFreeConnection(spi_dev_handler);
            dect_gpio_intnum = -1;
         }
         tmp_iprintf_onoff(1);
         /* we received a request to terminate ourself */
         printk(" Thread Termination Request\n");
         tmp_iprintf_onoff(0);
         break;
      }
      /* block waitng */
      cosic_thread_running = 0;
      wteset(__COSIC_DECT_EVENT,0);
      clrevt(__COSIC_DECT_EVENT);
      cosic_thread_running = 1;

      if (vuiGwDbgFlag==1) {
         unsigned int uiTmp=0;
         gw_stats.uiCdc++;
         gw_stats.uiTmpCdc++;
         uiTmp=gw_stats.uiTmpInt - gw_stats.uiTmpCdc;
         if (uiTmp >= 10) {
            gw_stats.auiIntLossSeq[9]++;
         } else if(uiTmp > 0) {
            gw_stats.auiIntLossSeq[uiTmp - 1]++;
         }
         gw_stats.uiTmpInt= 0;
         gw_stats.uiTmpCdc=0;/*Reset temp int count.*/
      }
      //protest_fg=1;
      switch (cosic_status) {
         case COSIC_THREAD_INIT_STATUS:
            break;

         /* COSIC THREAD TRANSFER STATUS  [[ */
         case COSIC_THREAD_TRANSFER_STATUS:
            cosic_status = COSIC_THREAD_RECEIVE_STATUS;		// status change
            iCosicMode = 0;
            if ((cosic_status == COSIC_THREAD_TRANSFER_STATUS) ||(iCosicMode == 1)) {
               //tmp_iprintf_onoff(1);
               //iprintf("SBB: TxRpt\n");
               //tmp_iprintf_onoff(0);
            }
            if (ifx_sscCosicLock() < 0) {
               break;
            }
            #ifdef TRACE_BACK
            Update_CT(8);
            #endif
            if (vucDriverMode == DECT_DRV_SET_LOADER_MODE) {
               char ucOpcode1=0,ucOpcode2=0;
               u16Len = 0;
               if (vu16WriteBufTail != vu16WriteBufHead) {
                  //send user data
                  u16Len = (vucWriteBuffer[vu16WriteBufTail][0]<<8) +
                           vucWriteBuffer[vu16WriteBufTail][1];
                  u16Len += 2; //for 'total size' field
                  pucBuf = vucWriteBuffer[vu16WriteBufTail];
                  ucOpcode1 = vucWriteBuffer[vu16WriteBufTail][4];
                  ucOpcode2 = vucWriteBuffer[vu16WriteBufTail][5];
                  ++vu16WriteBufTail;
                  if (vu16WriteBufTail == MAX_WRITE_BUFFERS) {
                     vu16WriteBufTail = 0;
                  }
                  pucBuf[u16Len] = 0xFF; //Extra byte... //TODO: Why it is required? Discuss with Hubert
                  ++u16Len;
                  if (ifx_sscTx(spi_dev_handler, pucBuf, u16Len) != u16Len) {
                     ifx_sscCosicUnLock();
                     #ifdef TRACE_BACK
                     Update_CT(3);
                     #endif
                     iprintf(": ifx_sscTx failed %d\n", u16Len);
                  }
                  #ifdef TRACE_BACK
                  Update_CT(10);
                  #endif
                  //__udelay__(200);
                  //QTMW:removed since ifx_sscTX would call ifx_sscCosicLock
                  if ((ucOpcode1 == 0x10) && (ucOpcode2 == 0x04)) {
                     iprintf(": MOVING TO APP MODE\n");
                     starting_cnt =0;
                     vucDriverMode = DECT_DRV_SET_APP_MODE;
                     __udelay__(2000);
                     __udelay__(2000);
                     __udelay__(2000);
                     __udelay__(2000);
                     __udelay__(2000);
                     cosic_int_cnt=0;
                  }
                  break;
               }
            }
            transmit_len = 0;
            dummy_len = 0;
            ret = 0;
            /* send the data to LMAC */
            if ((vucDriverMode == DECT_DRV_SET_APP_MODE_CoC_RQ) || (vucDriverMode == DECT_DRV_SET_APP_MODE_CoC_CNF)) {
               /*Since under CoC state, send only CoC dummy packet till the CoC state is cleared by Modem by Normal dummy pkt*/
               /*CoC Dummy packet structure :       0x00,0x02,0x01,0x01*/
               /*byte position                       0  ,  1 ,  2 ,  3 */
               ssc_cosic_tx_buf[0]= 0;
               ssc_cosic_tx_buf[1]= 2;
               ssc_cosic_tx_buf[2]= 1;
               ssc_cosic_tx_buf[3]= 1;
               //printk("\nSending CoC dummy pkt from GW\n");
               if (vucDriverMode == DECT_DRV_SET_APP_MODE_CoC_RQ) {
                  /*move driver state from Coc-request to CoC-confirm, as we already ack the CoC req from modem*/
                  vucDriverMode = DECT_DRV_SET_APP_MODE_CoC_CNF;
                  /*Deactivate the COSIC reset timer as we are in CoC and we don't receive any pkt
                  from modem on a periodic basis. If we dont recv any pkt from modem for a particular time out
                  then COSIC modem will be soft reset by Gw. The below function deactivates that timer */
                  //Cosic_modem_monitoring_timer_ctrl(IFX_DECT_OFF);
                  //printk("\nGW into CoC CNF mode\n");
               }
            } else {
               To_LMAC_Data(ssc_cosic_tx_buf);
            }
            transmit_len = (ssc_cosic_tx_buf[COSIC_DATA_HIGH_LENGTH]<<8);
            transmit_len |= ssc_cosic_tx_buf[COSIC_DATA_LOW_LENGTH];
            if (transmit_len) {
               /* ralph_080224 for size 4 unit */
               transmit_len += 2;
               if (vucDriverMode != DECT_DRV_SET_LOADER_MODE) {
                  dummy_len = transmit_len % 4;
                  if (dummy_len) {
                     transmit_len = transmit_len + (4 - dummy_len);		// unit 4byte
                  }
               }
               if (vucDriverMode == DECT_DRV_SET_LOADER_MODE) {
                  if (transmit_len == 4) {
                     transmit_len++;
                  } else {
                     printk("In load mode should not transmit anything else\n");
                     break;
                  }
               }
               if (ifx_sscTx(spi_dev_handler, ssc_cosic_tx_buf, transmit_len) != transmit_len) {
                  tmp_iprintf_onoff(1);
                  iprintf("ssc transmit failed %d\n", transmit_len);
                  tmp_iprintf_onoff(0);
               }
               #ifdef TRACE_BACK
               Update_CT(11);
               #endif
               protest_fg=0;
               if (IntEdgFlg == 0) { /*means rising edge int got*/
                  ifx_sscCosicUnLock();
                  #ifdef TRACE_BACK
                  Update_CT(20);
                  #endif
               }
            }
            break;
         /* COSIC THREAD TRANSFER STATUS  ]] */

         /* COSIC THREAD RECEIE STATUS [[*/
         case COSIC_THREAD_RECEIVE_STATUS:
            cosic_status = COSIC_THREAD_TRANSFER_STATUS;	/* status change */
            iCosicMode = 1;
            if ((cosic_status == COSIC_THREAD_RECEIVE_STATUS) || (iCosicMode == 0)) {
               //tmp_iprintf_onoff(1);
               //iprintf("SBB: RxRpt\n");
               //tmp_iprintf_onoff(0);
            }
            if (ifx_sscCosicLock() < 0) {
               break;
            }
            #ifdef TRACE_BACK
            Update_CT(9);
            #endif
            ifx_sscCosicRx();
            break;
         /* COSIC THREAD RECEIE STATUS ]]*/

         default:
            printk("Invalid cosic status\n");
            break;

      }

      if (pthread->bShutDown) {
         /* we received a request to terminate ourself */
         tmp_iprintf_onoff(1);
         /* we received a request to terminate ourself */
         printk(" Thread Termination Request 1\n");
         tmp_iprintf_onoff(0);
         break;
      }
   }
}
#endif /* SUPERTASK */

/******************************************************************
 *  Function Name  : init_tapi_read_write_buffer 
 *  Description    : This function initializes the TAPI read and write
 *                   buffers
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void init_tapi_read_write_buffer(void)
{
   unsigned char i;
   #ifdef CONFIG_SMP4
      #ifdef KLOCWORK
	   unsigned long flags4=0;
    	#else
      unsigned long flags4;
      #endif
		spin_lock_irqsave(&DECT_TAPI_Lock,flags4);
   #endif
	

   for(i=0;i<MAX_MCEI;i++){
      xMceiBuffer[i].pcVoiceDataBuffer = NULL;
      xMceiBuffer[i].pcVoiceDataBuffer1 = NULL;
      xMceiBuffer[i].iKpiChan = -1; /* Fill some invalid number as of now */
      /* xMceiBuffer[i].acMacBuffer = */
   }
   /* tapi voice wrtie data initial */
   for(i=0; i<MAX_TAPI_BUFFER_CNT; i++){
      memset(&Tapi_voice_write_buffer[i], 0, sizeof(TAPI_VOICE_WRITE_BUFFER));
   }
   Tapi_voice_write_buffer_r_cnt = 0;
   Tapi_voice_write_buffer_w_cnt = 0;

   #ifdef CONFIG_SMP4
      spin_unlock_irqrestore(&DECT_TAPI_Lock,flags4);
   #endif
   #ifdef SUPERTASK
   cosic_buffer_cnt = 0;
   #endif
}

#ifdef LINUX
/******************************************************************
 *  Function Name  : IFX_COSIC_TapiRead 
 *  Description    : This function is registered with TAPI. TAPI calls 
 *                   this whenever there is some data to be sent 
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void IFX_COSIC_TapiRead(unsigned long ulDummy)
{
   #ifdef CONFIG_SMP4
      #ifdef KLOCWORK
	   unsigned long flags4=0;
   	#else
      unsigned long flags4;
      #endif
   #endif
   IFX_uint32_t packet_len;
   long ret;
	char *pcVoiceDataBuffer =NULL;
#ifdef CONFIG_LTT
   static unsigned long  iPktCnt;
#endif
   unsigned short nKpiChannel_number;
   unsigned char  *voice_buffer;
   unsigned char  more_packet;
   unsigned char  i;
   /* IFX_TAPI_KPI_WaitForData, IFX_TAPI_KPI_ReadData is not EXPORT_SYMBOL *
    * change 4 byte header
    * Type=0	4 bits,  
    * Slot=??	4 bits according to recieved slot number 
    *            (just use channel number directly)
    * Subtype=??	4 bits according to def e.g. G.726=1, G.722=4, PLC=8 
    *            (received packet on Cosic was defined to need BEC)
    * Seq= 	4 bits cyclic counter set to help TAPI FW in case of lost 
    *            packets (missed interrupts), we will have to do this here. 
    * Length=??	2 bytes, 40 for G.726, 80 for G.722 and G.711 to 5 byte 
    *            header	+ payload Type (1 byte), Length (1 byte), 
    *            Channel (1 byte), Voice Info (1 byte), Cyclic Index (1 byte), 
    *            Voice Data (40 or 80 bytes)*/
   do{
      ret = IFX_TAPI_KPI_ReadData (IFX_TAPI_KPI_GROUP2,
                                   &nKpiChannel_number,(void**)&voice_buffer,
                                   &packet_len, &more_packet);
      if(ret<0){
         //printk(" KPI_ReadData Failed\n");
         return; 
      }
      /* Find MCEI from TAPI KPI channle number */
      for(i=0;i<MAX_MCEI;i++){
         if(xMceiBuffer[i].iKpiChan == (nKpiChannel_number & 0x00FF)){
            break;
         }
      }
      if((i>=MAX_MCEI) ||
         (TAPI_VOICE_PACKET_TYPE(voice_buffer[TAPI_VOICE_PACKET_TYPE_INDEX]) != TAPI_B_VOICE_PACKET)) {
         BUFFER_POOL_PUT(&voice_buffer[0]);
         if(more_packet){
            continue;
         } 
         else{
            return;
         }
      }

   #ifdef CONFIG_SMP4
      spin_lock_irqsave(&DECT_TAPI_Lock,flags4);
   #endif
      if((xMceiBuffer[i].pcVoiceDataBuffer != NULL) && 
         (xMceiBuffer[i].pcVoiceDataBuffer1 != NULL)){
#ifdef CONFIG_LTT
         iPktCnt++;
         xMceiBuffer[i].iVBCnt = xMceiBuffer[i].iVB1Cnt;
         xMceiBuffer[i].iVB1Cnt = iPktCnt;    
         MARK(tapi_event, "long %lu string %s",iPktCnt,"1");
#endif
         /* Overwite the first packet and return that to pool */
         pcVoiceDataBuffer=xMceiBuffer[i].pcVoiceDataBuffer;
         xMceiBuffer[i].pcVoiceDataBuffer = xMceiBuffer[i].pcVoiceDataBuffer1;
         xMceiBuffer[i].pcVoiceDataBuffer1 = &voice_buffer[0];
      }
#if 1
      else if(xMceiBuffer[i].pcVoiceDataBuffer == NULL){
#ifdef CONFIG_LTT
         iPktCnt++;
         xMceiBuffer[i].iVBCnt = iPktCnt;    
         MARK(tapi_event, "long %lu string %s",iPktCnt,"2");
#endif
         xMceiBuffer[i].pcVoiceDataBuffer = &voice_buffer[0];
      }
      else if(xMceiBuffer[i].pcVoiceDataBuffer1 == NULL){
#ifdef CONFIG_LTT
         iPktCnt++;
         xMceiBuffer[i].iVB1Cnt = iPktCnt;    
         MARK(tapi_event, "long %lu string %s",iPktCnt,"3");
#endif
         xMceiBuffer[i].pcVoiceDataBuffer1 = &voice_buffer[0];
      }
   #ifdef CONFIG_SMP4
      spin_unlock_irqrestore(&DECT_TAPI_Lock,flags4);
   #endif
		if(pcVoiceDataBuffer !=NULL){
      	BUFFER_POOL_PUT(pcVoiceDataBuffer);
			pcVoiceDataBuffer =NULL;
		}
#else
      else if(xMceiBuffer[i].pcVoiceDataBuffer1 == NULL){
#ifdef CONFIG_LTT
         iPktCnt++;
         xMceiBuffer[i].iVB1Cnt = iPktCnt;    
         MARK(tapi_event, "long %lu string %s",iPktCnt,"2");
#endif
         xMceiBuffer[i].pcVoiceDataBuffer1 = &voice_buffer[0];
      }
      else if(xMceiBuffer[i].pcVoiceDataBuffer == NULL){
#ifdef CONFIG_LTT
         iPktCnt++;
         xMceiBuffer[i].iVBCnt = xMceiBuffer[i].iVB1Cnt;
         xMceiBuffer[i].iVB1Cnt = iPktCnt;    
         MARK(tapi_event, "long %lu string %s",iPktCnt,"3");
#endif
         xMceiBuffer[i].pcVoiceDataBuffer = xMceiBuffer[i].pcVoiceDataBuffer1;
         xMceiBuffer[i].pcVoiceDataBuffer1 = &voice_buffer[0];
      }
#endif
   } while (more_packet);
}
#endif /* LINUX */
#ifdef SUPERTASK
/*******************************************************************************
Description:	COSIC driver read TAPI kernel thread
Arguments:
Note:
*******************************************************************************/
IFX_void_t COSIC_drv_TAPI_Read_Kthread(IFXOS_ThreadParams_t *pthread)
{
   unsigned long packet_len;
   unsigned short nKpiChannel_number;
   unsigned char *voice_buffer;
   unsigned char more_packet;
   unsigned char i;
   /* IFX_TAPI_KPI_WaitForData, IFX_TAPI_KPI_ReadData is not EXPORT_SYMBOL *
    * change 4 byte header
    * Type=0	4 bits,
    * Slot=??	4 bits according to recieved slot number
    *            (just use channel number directly)
    * Subtype=??	4 bits according to def e.g. G.726=1, G.722=4, PLC=8
    *            (received packet on Cosic was defined to need BEC)
    * Seq= 	4 bits cyclic counter set to help TAPI FW in case of lost
    *            packets (missed interrupts), we will have to do this here.
    * Length=??	2 bytes, 40 for G.726, 80 for G.722 and G.711 to 5 byte
    *            header	+ payload Type (1 byte), Length (1 byte),
    *            Channel (1 byte), Voice Info (1 byte), Cyclic Index (1 byte),
    *            Voice Data (40 or 80 bytes)*/
   int wait_ret;
   //unsigned char voice_nibble;
   unsigned int nSig;

#ifdef VOICE_CYCLIC_INDEX_CHECK
   static unsigned char	check_cyclic_index[6];
   //static unsigned char	back_cyclic_index[6];
#endif

   //struct task_struct *tsk = current;		// for kernel thread priority setting

   while (cosic_module_init==0) {
      dlytsk(getPID(),DLY_TICKS,100);
   }
   //	pritsk(getPID(),124);	//for highest Priority Task..
   //QTMW:21120402 test for heavy loading
   pritsk(getPID(),125);	//for highest Priority Task..
   init_tapi_read_write_buffer();

   /* an endless loop in which we are doing our work */
   for(;;)
   {
      if (pthread->bShutDown)
      {
         /* we received a request to terminate ourself */
         printk(" Thread Termination Request\n");
         break;
      }
      wait_ret=IFX_TAPI_KPI_WaitForData(IFX_TAPI_KPI_GROUP2);

      /* IFX_TAPI_KPI_WaitForData, IFX_TAPI_KPI_ReadData is not EXPORT_SYMBOL */
      // change 4 byte header
      // Type=0		4 bits,
      // Slot=??		4 bits according to recieved slot number ( just use channel number directly)
      // Subtype=??	4 bits according to def e.g. G.726=1, G.722=4, PLC=8 (received packet on Cosic was defined to need BEC)
      // Seq= 		4 bits cyclic counter set to help TAPI FW in case of lost packets (missed interrupts), we will have to do this
      //				here.
      // Length=??	2 bytes, 40 for G.726, 80 for G.722 and G.711
      // to
      // 5 byte header	+ payload
      // Type (1 byte), Length (1 byte), Channel (1 byte), Voice Info (1 byte), Cyclic Index (1 byte), Voice Data (40 or 80 bytes)

      if(IFX_ERROR != IFX_TAPI_KPI_ReadData (IFX_TAPI_KPI_GROUP2,
         &nKpiChannel_number, (void**)&voice_buffer,
         &packet_len, &more_packet))
      {
         /* Find MCEI from TAPI KPI channle number */
         for(i=0;i<MAX_MCEI;i++){
            if(xMceiBuffer[i].iKpiChan == (nKpiChannel_number & 0x00FF)){
               break;
            }
         }


         if((i>=MAX_MCEI)||
            (TAPI_VOICE_PACKET_TYPE(voice_buffer[TAPI_VOICE_PACKET_TYPE_INDEX]) != TAPI_B_VOICE_PACKET)||
            (wait_ret==IFX_ERROR)){
            BUFFER_POOL_PUT(&voice_buffer[0]);
            cosic_buffer_cnt--;
            goto check_more_pkt;
            //break; //santosh
         }

         if((xMceiBuffer[i].pcVoiceDataBuffer != NULL) &&
            (xMceiBuffer[i].pcVoiceDataBuffer1 != NULL)){

            /* Overwite the first packet and return that to pool */

            BUFFER_POOL_PUT(xMceiBuffer[i].pcVoiceDataBuffer);
            cosic_buffer_cnt--;
            xMceiBuffer[i].pcVoiceDataBuffer = xMceiBuffer[i].pcVoiceDataBuffer1;
            xMceiBuffer[i].pcVoiceDataBuffer1 = &voice_buffer[0];
         }
         else if(xMceiBuffer[i].pcVoiceDataBuffer1 == NULL){
            xMceiBuffer[i].pcVoiceDataBuffer1 = &voice_buffer[0];
         }
         else if(xMceiBuffer[i].pcVoiceDataBuffer == NULL){
            xMceiBuffer[i].pcVoiceDataBuffer = xMceiBuffer[i].pcVoiceDataBuffer1;
            xMceiBuffer[i].pcVoiceDataBuffer1 = &voice_buffer[0];
         }
         check_more_pkt:
         continue;
      }
      else
      {
         //Now it would be always have possibility of reading error, we need to clean it out for time delay and bad quality..
         //cosic_printf(" KPI_ReadData Failed\n");
         continue;
      }
   }/* end of for*/
}
#endif /* SUPERTASK */

#ifdef LINUX
/******************************************************************
 *  Function Name  : ifx_cosic_AsyncRxCB2 
 *  Description    : This function is called when the complete msg
 *                   is read from the SPI bus. SPI bus has to be 
 *                   locked for certain duration before releasing it 
 *                   for other modules to use.
 *  Input Values   : Handle passed in Async RX call back, Number of 
 *                   bytes recvd
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void
ifx_cosic_AsyncRxCB2(int iHandle, int iRetVal)
{
   #ifdef KLOCWORK
	unsigned long flags=0;
	#else
	unsigned long flags;
	#endif
  uiResp = 3;
  /* place holder for avoding delay in tasklet mode */
  if(iRetVal == 0){
    printk("ssc receive failed \n");
  	atomic_set(&vuiIgnoreint,0);
		irq_safe_lock(flags);
		if(IntEdgFlg == 0)/*means rising edge int got*/
  		{
			irq_safe_unlock(flags);
			ifx_sscCosicUnLock();
		}
		else
		{
			irq_safe_unlock(flags);
		}
  atomic_set(&vuiIgnoreint,0);
  	return;
  }
  if((iRetVal > 0) && (iRetVal < Max_spi_data_len_val)){ 
    if((ssc_cosic_rx_buf[0]==FIRST_BYTE_FROM_MODEM_LOADER_MODE) || (ssc_cosic_rx_buf[0]==FIRST_BYTE_FROM_MODEM_APP_MODE)){
      From_LMAC_Data(&ssc_cosic_rx_buf[1]);
    }

    if (vucDriverMode != DECT_DRV_SET_APP_MODE_CoC_CNF) {
      Cosic_modem_monitoring_timer_ctrl(IFX_DECT_ON);
    }
  }
  else{
    int iTemp;
    for(iTemp=0;iTemp<15;iTemp++){
      printk("Buff %x\t",ssc_cosic_rx_buf[iTemp]);
    }
    printk("\nLen = %d\n",iRetVal); 
  }
  atomic_set(&vuiIgnoreint,0);
	irq_safe_lock(flags);
	if(IntEdgFlg == 0)/*means rising edge int got*/
  {
		irq_safe_unlock(flags);
		ifx_sscCosicUnLock();
		//gw_stats.uiUnLockAtRxCB++;
	}
	else
	{
		irq_safe_unlock(flags);
	}
  atomic_set(&vuiIgnoreint,0);

  return;
}
#endif /* LINUX */

#ifdef LINUX
/******************************************************************
 *  Function Name  : ifx_cosic_AsyncRxCB1 
 *  Description    : This function Reads the remaining message
 *                   available on the SPI bus
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : As a first step we read the first 2 bytes to get 
 *                   the message lenght. Once the message size is known 
 *                   remaining information is read
 * ****	************************************************************/
void
ifx_cosic_AsyncRxCB1(int iHandle, int iRetVal)
{
   #ifdef KLOCWORK
	unsigned long flags=0;
	#else
	unsigned long flags;
	#endif
  int left_len = 0;
  IFX_SSC_ASYNC_CALLBACK_t xSscTaskletcb;
  uiResp = 2;
  printk("Entry ifx_cosic_AsyncRxCB1 \n");
  xSscTaskletcb.pFunction = ifx_cosic_AsyncRxCB2;
  xSscTaskletcb.functionHandle = (int)spi_dev_handler;
  if(iRetVal == 0){
    printk("ssc receive failed \n");
    atomic_set(&vuiIgnoreint,0);
		irq_safe_lock(flags);
		if(IntEdgFlg == 0)/*means rising edge int got*/
		{
			irq_safe_unlock(flags);
    		ifx_sscCosicUnLock();
		}
		else
		{
			irq_safe_unlock(flags);
		}
  atomic_set(&vuiIgnoreint,0);
    return;
  }
  rx_len = (ssc_cosic_rx_buf[1] & 0xff) << 8;
  rx_len |= (ssc_cosic_rx_buf[2] & 0xff);

		/*Invalid pkt*/
  if((rx_len > MAX_SPI_DATA_LEN)){
    printk("!");
  if(atomic_read(&vuiGwDbgFlag)==1){
    gw_stats.uiInvSpi++;
	}
    atomic_set(&vuiIgnoreint,0);
		irq_safe_lock(flags);
		if(IntEdgFlg == 0)/*means rising edge int got*/
		{
			irq_safe_unlock(flags);
    		ifx_sscCosicUnLock(); 
		}
		else
		{
			irq_safe_unlock(flags);
		}
  atomic_set(&vuiIgnoreint,0);
    return;
  }
  if(rx_len > (COSIC_RX_HEADER_LEN -3)){
    left_len = rx_len - (COSIC_RX_HEADER_LEN - 3);
  }
  if(left_len > 0){
    uiReq = 3;
    if(ifx_sscAsyncRx(spi_dev_handler, &xSscTaskletcb, 
       ssc_cosic_rx_buf + COSIC_RX_HEADER_LEN, left_len) < 0){
      printk("ssc receive failed \n");
      atomic_set(&vuiIgnoreint,0);
		irq_safe_lock(flags);
		if(IntEdgFlg == 0)/*means rising edge int got*/
		{
			irq_safe_unlock(flags);
      	ifx_sscCosicUnLock();
		}
		else
		{
			irq_safe_unlock(flags);
		}
  atomic_set(&vuiIgnoreint,0);
      return;
    }
  }
  else{
			/*Dummy packet section*/
			/*Check for CoC dummy packet from COSIC MODEM; CoC will be always in App mode*/
			/*CoC Dummy packet structure :       0xAA,0x00,0x02,0x01,0x01*/
      /*byte position                       0  ,  1 ,  2 ,  3 ,  4 */
    	if ((ssc_cosic_rx_buf[4] == 1) && (ssc_cosic_rx_buf[0] == 0xAA) && (vucDriverMode ==  DECT_DRV_SET_APP_MODE))
      {
				//printk("\nCoC dummy pkt from Modem\n");
				 gw_stats.uiCoCReqFromModem ++;
        /*Request for CoC from COSIC modem*/
				if(ucDECT_CoCMode) 
				{
				  vucDriverMode = DECT_DRV_SET_APP_MODE_CoC_RQ;
				}
      }
			/*check for normal dummy pkt from modem to clear CoC*/ 
			/*Normal Dummy packet structure :    0xAA,0x00,0x02,0x01,0x00*/
      /*byte position                       0  ,  1 ,  2 ,  3 ,  4 */
	    else if ((ssc_cosic_rx_buf[4] == 0) && ((vucDriverMode ==  DECT_DRV_SET_APP_MODE_CoC_RQ)|| (vucDriverMode ==  DECT_DRV_SET_APP_MODE_CoC_CNF)))
      {
				//printk("\nNormal dummy pkt from Modem to clear CoC\n");
				/*Change the driver state to Normal AppMode*/
				vucDriverMode = DECT_DRV_SET_APP_MODE;
				/*Activate the COSIC reset timer as we are not in CoC and idealy we should receive dummy pkt
					from modem on a periodic basis. If we dont recv any pkt from modem for a particular time out
					then COSIC modem will be soft reset by Gw. The below function activates that timer */
				Cosic_modem_monitoring_timer_ctrl(IFX_DECT_ON);
      }	
    	/* No more data to be read so unlock the SPI bus */
    	atomic_set(&vuiIgnoreint,0);
			irq_safe_lock(flags);
			if(IntEdgFlg == 0)/*means rising edge int got*/
			{
				irq_safe_unlock(flags);
    			ifx_sscCosicUnLock();
				//gw_stats.uiUnLockAtRxCB++;
			}
			else
			{
				irq_safe_unlock(flags);
			}
    	Cosic_modem_monitoring_timer_ctrl(IFX_DECT_ON);
  		atomic_set(&vuiIgnoreint,0);
  }
  return;
}
#endif /* LINUX */

/******************************************************************
 *  Function Name  : ifx_sscCosicRx 
 *  Description    : Receives Cosic messages on getting and intterupt 
 *                   from GPIO, cosic is in RX mode
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void ifx_sscCosicRx(void)
{
#ifdef LINUX
   #ifdef KLOCWORK
	unsigned long flags=0;
	#else
   unsigned long flags;
   #endif
   IFX_SSC_ASYNC_CALLBACK_t xSscTaskletcb;
      printk("Entry ifx_sscCosicRx \n");

   xSscTaskletcb.pFunction = ifx_cosic_AsyncRxCB1;
   xSscTaskletcb.functionHandle = (int)spi_dev_handler;
  
   /* First, receive the total packet length */
   if (ifx_sscAsyncRx(spi_dev_handler, &xSscTaskletcb, ssc_cosic_rx_buf, COSIC_RX_HEADER_LEN) < 0) {
      printk("ssc receive failed \n");
      irq_safe_lock(flags);
      if (IntEdgFlg == 0) {/*means rising edge int got*/
      	irq_safe_unlock(flags);
         ifx_sscCosicUnLock(); 
      }
		else
		{
      	irq_safe_unlock(flags);
		}
      atomic_set(&vuiIgnoreint,0);
      printk("Exit ifx_sscCosicRx \n");
      return;
   }
   /* In case of Async mode the call back gets called in the tasklet context.
    * If Cosic is running in thread mode explicitly call that function */
      printk("Exit2 ifx_sscCosicRx \n");
#endif /* LINUX */
#ifdef SUPERTASK
   int dummy_read_len = 0, left_len = 0;

   BLOCK_PREEMPTION;
   #if defined(_INF50510)
   Block_VinInt();
   #elif defined(_INF50712)
   dis_int_danube();
   #endif

   /* First, receive the total packet length */
   if (ifx_sscRx(spi_dev_handler, ssc_cosic_rx_buf, COSIC_RX_HEADER_LEN) == 0) {
      printk("ssc receive failed \n");
      goto HandleRxCleanUp;
   }
   iFirstByteRx=ssc_cosic_rx_buf[0];
   #ifdef TRACE_BACK
   Update_CT(13);
   #endif
   rx_len = (ssc_cosic_rx_buf[1] & 0xff) << 8;
   rx_len |= (ssc_cosic_rx_buf[2] & 0xff);

   if (rx_len <= 0 || rx_len > MAX_SPI_DATA_LEN) {
      if (vuiGwDbgFlag == 1) {
         gw_stats.uiInvSpi++;
      }
      goto HandleRxCleanUp;
   }
   //	if (rx_len > (512 - COSIC_RX_HEADER_LEN)) {
   //	  	//goto HandleRxCleanUp;
   //	  	rx_len = 512 - COSIC_RX_HEADER_LEN;
   //	}
   if (rx_len > (COSIC_RX_HEADER_LEN -3)) {
      left_len = rx_len - (COSIC_RX_HEADER_LEN - 3);
   }
   if (left_len > 0) {
      if (ifx_sscRx(spi_dev_handler, ssc_cosic_rx_buf + COSIC_RX_HEADER_LEN, left_len) <= 0)
      {
         printk("ssc receive failed \n");
         goto HandleRxCleanUp;
      } else {
         #if 1
         if (ssc_cosic_rx_buf[0]==FIRST_BYTE_FROM_MODEM_APP_MODE && iCntlForceLongLock==0) {
            #ifdef TRACE_BACK
            Update_CT(14);
            #endif
            protest_fg=0;
            if(IntEdgFlg == 0)/*means rising edge int got*/
            {
               ifx_sscCosicUnLock();
               #ifdef TRACE_BACK
               Update_CT(4);
               #endif
            }

            #if defined(_INF50510)
            UnBlock_VinInt();
            #elif defined(_INF50712)
            en_int_danube();
            #endif
            UNBLOCK_PREEMPTION;
         }
         #endif
         if ((ssc_cosic_rx_buf[0] == FIRST_BYTE_FROM_MODEM_LOADER_MODE) || (ssc_cosic_rx_buf[0] == FIRST_BYTE_FROM_MODEM_APP_MODE)) {
            From_LMAC_Data(&ssc_cosic_rx_buf[1]);
            if (ssc_cosic_rx_buf[0] == FIRST_BYTE_FROM_MODEM_APP_MODE && iCntlForceLongLock == 0) {
               return;
            }
         }
         #ifdef TRACE_BACK
         Update_CT(14);
         #endif
         if (ssc_cosic_rx_buf[0]==FIRST_BYTE_FROM_MODEM_LOADER_MODE || iCntlForceLongLock!=0) {
            goto HandleRxCleanUp;
         }
      }
   } else {
      /*Dummy packet section*/
      /*Check for CoC dummy packet from COSIC MODEM; CoC will be always in App mode*/
      /*CoC Dummy packet structure :       0xAA,0x00,0x02,0x01,0x01*/
      /*byte position                       0  ,  1 ,  2 ,  3 ,  4 */
      if ((ssc_cosic_rx_buf[4] == 1) && (ssc_cosic_rx_buf[0] == 0xAA) && (vucDriverMode ==  DECT_DRV_SET_APP_MODE)) {
         //printk("\nCoC dummy pkt from Modem\n");
         /*Request for CoC from COSIC modem*/
         vucDriverMode = DECT_DRV_SET_APP_MODE_CoC_RQ;
      }
      /*check for normal dummy pkt from modem to clear CoC*/
      /*Normal Dummy packet structure :    0xAA,0x00,0x02,0x01,0x00*/
      /*byte position                       0  ,  1 ,  2 ,  3 ,  4 */
      else if ((ssc_cosic_rx_buf[4] == 0) && ((vucDriverMode ==  DECT_DRV_SET_APP_MODE_CoC_RQ)|| (vucDriverMode ==  DECT_DRV_SET_APP_MODE_CoC_CNF))) {
         //printk("\nNormal dummy pkt from Modem to clear CoC\n");
         /*Change the driver state to Normal AppMode*/
         vucDriverMode = DECT_DRV_SET_APP_MODE;
         /*Activate the COSIC reset timer as we are not in CoC and idealy we should receive dummy pkt
         from modem on a periodic basis. If we dont recv any pkt from modem for a particular time out
         then COSIC modem will be soft reset by Gw. The below function activates that timer */
      }
      /* No more data to be read so unlock the SPI bus */
   }

   HandleRxCleanUp:
   protest_fg=0;
   if (IntEdgFlg == 0) {/*means rising edge int got*/
      ifx_sscCosicUnLock();
      #ifdef TRACE_BACK
      Update_CT(5);
      #endif
   }

   #if defined(_INF50510)
   UnBlock_VinInt();
   #elif defined(_INF50712)
   en_int_danube();
   #endif
   UNBLOCK_PREEMPTION;
   return ;
#endif /* SUPERTASK */
}

/******************************************************************
 *  Function Name  : ifx_sscCosicTx
 *  Description    : This function sends the messages to cosic modem
 *                   using the SPI. Async/Sync is used based on tasklet
 *                   support
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void ifx_sscCosicTx(void)
{
#ifdef LINUX
   #ifdef KLOCWORK
	unsigned long flags=0;
	#else
   unsigned long flags;
   #endif
   unsigned int  dummy_len,ret;
   unsigned short u16Len =0;
   unsigned char* pucBuf=NULL;
   IFX_SSC_ASYNC_CALLBACK_t xSscTaskletcb;

	#ifdef CONFIG_SMP3
		spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   #endif
   if (vucDriverMode == DECT_DRV_SET_LOADER_MODE) {
      char ucOpcode1=0,ucOpcode2=0;
      u16Len = 0;
		printk("Loader Mode!!!!\n");
      if (vu16WriteBufTail != vu16WriteBufHead) {
      /*send user data*/
         u16Len = (vucWriteBuffer[vu16WriteBufTail][0]<<8) + 
                   vucWriteBuffer[vu16WriteBufTail][1];
         u16Len += 2 ; //for 'total size' field
         pucBuf =  vucWriteBuffer[vu16WriteBufTail];
         ucOpcode1 = vucWriteBuffer[vu16WriteBufTail][4];
         ucOpcode2 = vucWriteBuffer[vu16WriteBufTail][5];
         ++vu16WriteBufTail;
         if (vu16WriteBufTail == MAX_WRITE_BUFFERS) {
            vu16WriteBufTail = 0;
         }

   		#ifdef CONFIG_SMP3
      		spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   		#endif

         pucBuf[u16Len] = 0xFF; //Extra byte... //TODO: Why it is required? Discuss with Hubert
         ++u16Len;

#ifdef CONFIG_SMP
   spin_lock_irqsave(&IntEdgFlgLock,flags);
#endif
         iCosicMode = 0;
#ifdef CONFIG_SMP
   spin_unlock_irqrestore(&IntEdgFlgLock,flags);
#endif
         xSscTaskletcb.pFunction = ifx_cosic_AsyncTxCB;
         xSscTaskletcb.functionHandle = (int)spi_dev_handler;
         if (ifx_sscAsyncTx(spi_dev_handler, &xSscTaskletcb, pucBuf, u16Len) < 0) {
            atomic_set(&vuiIgnoreint,0);
            ifx_sscCosicUnLock();
            printk("ssc transmit1 failed %d\n", u16Len);
            //return;
         }
           
         if ((ucOpcode1 == 0x10) && (ucOpcode2 == 0x08)) {
            //printk("\n: Cosic Firmware Download complete\n");
            udelay(10000); 
            vucDriverMode = DECT_DRV_SET_APP_MODE;
            //printk("\n: Cosic Firmware Download complete11111\n");
         }
         return;
      }
		else
		{
   		#ifdef CONFIG_SMP3
      		spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   		#endif
		}
   }
   #ifdef CONFIG_SMP3
	else
	{
      spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
	}
   #endif
		printk("Driver Mode =%d\n",vucDriverMode);

   transmit_len = 0;
   dummy_len = 0;
   ret = 0;

      /* send the data to LMAC */
   if ((vucDriverMode == DECT_DRV_SET_APP_MODE_CoC_RQ) || (vucDriverMode == DECT_DRV_SET_APP_MODE_CoC_CNF)) {
      /*Since under CoC state, send only CoC dummy packet till the CoC state is cleared by Modem by Normal dummy pkt*/
      /*CoC Dummy packet structure :       0x00,0x02,0x01,0x01*/
      /*byte position                       0  ,  1 ,  2 ,  3 */
      ssc_cosic_tx_buf[0]= 0;
      ssc_cosic_tx_buf[1]= 2;
      ssc_cosic_tx_buf[2]= 1;
      ssc_cosic_tx_buf[3]= 1;
      //printk("\nSending CoC dummy pkt from GW\n");
      if (vucDriverMode == DECT_DRV_SET_APP_MODE_CoC_RQ) {
         /*move driver state from Coc-request to CoC-confirm, as we already ack the CoC req from modem*/
         vucDriverMode = DECT_DRV_SET_APP_MODE_CoC_CNF;
         /*Deactivate the COSIC reset timer as we are in CoC and we don't receive any pkt
         from modem on a periodic basis. If we dont recv any pkt from modem for a particular time out
         then COSIC modem will be soft reset by Gw. The below function deactivates that timer */
         Cosic_modem_monitoring_timer_ctrl(IFX_DECT_OFF);
         //printk("\nGW into CoC CNF mode\n");
      }
   } else {
      To_LMAC_Data(ssc_cosic_tx_buf);
   }

   transmit_len = (ssc_cosic_tx_buf[COSIC_DATA_HIGH_LENGTH]<<8);
   transmit_len |= ssc_cosic_tx_buf[COSIC_DATA_LOW_LENGTH];
   if (transmit_len) {
      /* ralph_080224 for size 4 unit */
      transmit_len += 2;

      if (vucDriverMode != DECT_DRV_SET_LOADER_MODE) {
         dummy_len = transmit_len % 4;
         if (dummy_len) {
            transmit_len = transmit_len + (4 - dummy_len);/*unit 4byte*/
         }
      }
      if (vucDriverMode == DECT_DRV_SET_LOADER_MODE) {
         if (transmit_len == 4) {
            transmit_len++;
         } else {
          irq_safe_lock(flags);
         if (IntEdgFlg == 0) { /*means rising edge int got*/
         	irq_safe_unlock(flags);
            ifx_sscCosicUnLock();
         }
			else
			{
         	irq_safe_unlock(flags);
			}	
         atomic_set(&vuiIgnoreint,0);
           printk("In load mode should not transmit anything else\n");
            return;
         }
      }
      xSscTaskletcb.pFunction = ifx_cosic_AsyncTxCB;
      xSscTaskletcb.functionHandle = (int)spi_dev_handler;
		printk("Calling ifx_sscAsyncTx \n");
      if (ifx_sscAsyncTx(spi_dev_handler, &xSscTaskletcb, ssc_cosic_tx_buf, transmit_len) < 0) {
         irq_safe_lock(flags);
         if (IntEdgFlg == 0) { /*means rising edge int got*/
         	irq_safe_unlock(flags);
            ifx_sscCosicUnLock();
         }
			else
			{
         	irq_safe_unlock(flags);
			}
         atomic_set(&vuiIgnoreint,0);
         printk("ssc transmit2 failed %d\n", transmit_len);
      }
   }

   if (viDisableIrq == 1) {
      viDisableIrq=2;
   }

   return;
#endif /* LINUX */
#ifdef SUPERTASK
   //printk(" tx len %d\n",1);
   BLOCK_PREEMPTION;
   #if defined(_INF50510)
   Block_VinInt();
   #elif defined(_INF50712)
   dis_int_danube();
   #endif

   if (ifx_sscTx(spi_dev_handler, ssc_cosic_tx_buf, transmit_len) != transmit_len) {
      printk("ssc transmit failed %d\n", transmit_len);
   }
   #ifdef TRACE_BACK
   Update_CT(12);
   #endif
   protest_fg=0;
   if (IntEdgFlg == 0) {/*means rising edge int got*/
      ifx_sscCosicUnLock();
      #ifdef TRACE_BACK
      Update_CT(6);
      #endif
   }
   #if defined(_INF50510)
   UnBlock_VinInt();
   #elif defined(_INF50712)
   en_int_danube();
   #endif
   UNBLOCK_PREEMPTION;

   return;
#endif /* SUPERTASK */
}

/******************************************************************
 *  Function Name  : ifx_sscCosicUnLock
 *  Description    : This function Unlocks the SPI bus
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
void 
ifx_sscCosicUnLock()
{
#ifdef CONFIG_SMP
   #ifdef KLOCWORK
	unsigned long flags=0;
	#else
	unsigned long flags;
	#endif
#endif
   #ifdef LINUX
   /* Ensure that the callback is called before the unlock */
   if (uiReq != uiResp) {
      return;
   }
   #endif

#ifdef CONFIG_SMP
   spin_lock_irqsave(&IntEdgFlgLock,flags);
#endif
   if ((iDriverStatus  == LMAC_BOOT_IND) && (viSPILocked)) 
	{
#ifdef CONFIG_SMP
   spin_unlock_irqrestore(&IntEdgFlgLock,flags);
#endif
      #ifdef LINUX
      ifx_sscAsyncUnLock(spi_dev_handler);
      #endif
      #ifdef SUPERTASK
		ifx_sscUnlock(spi_dev_handler);
      #endif

		#ifdef CONFIG_SMP
   		spin_lock_irqsave(&IntEdgFlgLock,flags);
		#endif
      viSPILocked = 0;

		#ifdef CONFIG_SMP
   		spin_unlock_irqrestore(&IntEdgFlgLock,flags);
		#endif

      #ifdef LINUX
      if (viDisableIrq == 2) {
         #if 0
         gp_onu_disable_external_interrupt();
         #else
         if (iIrqStatus==1) {
            disable_irq(dect_gpio_intnum);
            iIrqStatus=0;
         }
         #endif
      }
      #endif
   }
	else
	{
		#ifdef CONFIG_SMP
   		spin_unlock_irqrestore(&IntEdgFlgLock,flags);
		#endif
	}

#if 0
   #ifdef LINUX
   viSPILocked1=0;
   #endif
#endif
   return;
}

/******************************************************************
 *  Function Name  : ifx_sscCosicLock
 *  Description    : This function locks the SPI bus
 *  Input Values   : None
 *  Output Values  : None
 *  Return Value   : None
 *  Notes          : 
 * ****************************************************************/
int 
ifx_sscCosicLock()
{
#ifdef CONFIG_SMP
   #ifdef KLOCWORK
	unsigned long flags=0;
	#else
	unsigned long flags;
	#endif
#endif
#ifdef LINUX
   IFX_SSC_ASYNC_CALLBACK_t xSscTaskletcb;
#if 0
   viSPILocked1 = 1;
#endif

  if(spi_dev_handler == NULL)
  		return -1;
  
#ifdef CONFIG_SMP
   spin_lock_irqsave(&IntEdgFlgLock,flags);
#endif
   viSPILockedCB = 1;
   if ((iDriverStatus  != LMAC_BOOT_IND) && (viSPILocked)) {

#ifdef CONFIG_SMP
   spin_unlock_irqrestore(&IntEdgFlgLock,flags);
#endif
      printk("\ncalling LOCAL-Lock\n");
      ssc_dect_cs(0,0);
      //printk("\nlock: LOCAL\n");
      ifx_cosic_AsyncLockCB(((int)spi_dev_handler),0);
      return 0;
   }
	else
	{	
   	viSPILocked=1;
		#ifdef CONFIG_SMP
   		spin_unlock_irqrestore(&IntEdgFlgLock,flags);
		#endif
   	printk("\nCalling AsyncLock\n");
   	xSscTaskletcb.pFunction = ifx_cosic_AsyncLockCB;
   	xSscTaskletcb.functionHandle = (int)spi_dev_handler;
   	if (ifx_sscAsyncLock(spi_dev_handler,&xSscTaskletcb) < 0) {
   		printk("\n ifx_sscAsyncLock failed\n");
			#ifdef CONFIG_SMP
   			spin_lock_irqsave(&IntEdgFlgLock,flags);
			#endif
      	viSPILocked=0;
      	viSPILockedCB =0;
			#ifdef CONFIG_SMP
   			spin_unlock_irqrestore(&IntEdgFlgLock,flags);
			#endif
      	atomic_set(&vuiIgnoreint,0);
      	return -1;
   	}
	}
   return 0;
#endif /* LINUX */
#ifdef SUPERTASK
   int iRet=0;

   if (viSPILockedCB) {
      iprintf("\nSBB: Previous Lock CB has not been called and again Lock is called!!!\n");
      #ifdef TRACE_BACK
      Print_CT();
      #endif
      return -1;
   }
   viSPILockedCB = 1;/*Don't delete to optimize the code. Let it be redundant. it is usefull in Boot mode.*/
   if ((iDriverStatus  != LMAC_BOOT_IND) && (viSPILocked)) {
      ssc_dect_cs(0,0);
      return 0;
   } else if((iDriverStatus  == LMAC_BOOT_IND) && (viSPILocked)) {
      //tmp_iprintf_onoff(1);
      iprintf("SBB:Not toggling but taken care to recovery \n");
      #ifdef TRACE_BACK
      Print_CT();
      #endif
      viSPILockedCB = 0;
      ifx_sscCosicUnLock();
      #ifdef TRACE_BACK
      Update_CT(7);
      #endif
      //tmp_iprintf_onoff(0);
      return -1;
   }

   viSPILockedCB = 1; /*Don't delete it to optimize the code.let it be redundant. it is usefull when we go to recovery mode of not toggling*/
   viSPILocked = 1;
   if ((iRet=ifx_sscLock(spi_dev_handler)) < 0) {
      iprintf("SBB: ifx_sscLock : failed\n");
   }
   return 0;
#endif /* SUPERTASK */
}

#endif /* DRV_DECT_COSIC_DRV_C */
