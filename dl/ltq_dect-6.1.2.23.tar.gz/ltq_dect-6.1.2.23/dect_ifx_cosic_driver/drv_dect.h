/******************************************************************************

                              Copyright (c) 2009
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

#ifndef _DECT_DRV_H_
#define _DECT_DRV_H_

/* =======================================================================
 * Include Files
 * ======================================================================= */
#ifdef LINUX
#include <linux/version.h>
#endif
#include "fhmac.h"

/* =======================================================================
 * External Reference
 * ======================================================================= */

/* =======================================================================
 * Definitions
 * ======================================================================= */
#define MAX_READ_BUFFFERS 5 /* Max buffers that are stored in driver*/
#define MAX_WRITE_BUFFERS 5 /* Max buffers that user can write */
#define COSIC_LOADER_PACKET_SIZE 508 

#define IFX_DECT_ON  0x01
#define IFX_DECT_OFF 0x00


#ifdef LINUX

#ifdef CONFIG_SMP1
#define irq_safe_lock(flags) spin_lock_irqsave(&IntEdgFlgLock,flags)
#define irq_safe_unlock(flags) spin_unlock_irqrestore(&IntEdgFlgLock,flags)
#else
#define irq_safe_lock(flags) local_irq_save(flags)
#define irq_safe_unlock(flags) local_irq_restore(flags)
#endif

#ifdef TWINPASS
	#define DECT_IRQ_NUM    INT_NUM_IM4_IRL30
	#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT0_POS
#elif defined(CONFIG_AMAZON_S)
	// connect JP73 2 and 3  GPIO39 Using P2.7---> EXIN 3--> IM1_IRL0
	#define DECT_IRQ_NUM    INT_NUM_IM1_IRL0
	#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT2_POS//FIXME CS pin, now configure as SPI_CS3
#elif defined(CONFIG_DANUBE)
	#define DECT_IRQ_NUM    INT_NUM_IM1_IRL2
	#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT5_POS
#elif  defined CONFIG_IFX_GW188
	#define DECT_IRQ_NUM    INT_NUM_IM1_IRL0
	#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT0_POS//Not used
#elif defined CONFIG_AR9
	//connect JP73 2 and 3  GPIO39 Using P2.7---> EXIN 3--> IM1_IRL0
	#define DECT_IRQ_NUM    INT_NUM_IM1_IRL0
	#ifdef  CONFIG_AR9_NAND
		#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT3_POS//FIXME CS pin, now configure as SPI_CS3
	#else
		#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT2_POS//FIXME CS pin, now configure as SPI_CS3
	#endif
#elif defined CONFIG_AR10
	//GPIO9 ->Connection and IRQ number to be checked
	#define DECT_IRQ_NUM    INT_NUM_IM1_IRL2
	#ifdef DECT_USE_USIF 
		#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT0_POS//SPI_CS5 for USIF aswell??
	#else
		#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT5_POS//GPIO9-SPI_CS5
	#endif
#elif defined CONFIG_VR9
	//connect JP61 1 and 2  GPIO9 Using P0.9---> EXIN 5--> IM1_IRL2
	#define DECT_IRQ_NUM    INT_NUM_IM1_IRL2
	#ifdef DECT_USE_USIF 
		#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT0_POS//FIXME CS pin, now configure as SPI_CS3
	#else
		#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT1_POS//FIXME CS pin, now configure as SPI_CS3
	#endif
#endif /* Twinpass/Danube */

#ifdef CONFIG_AR9 
	#ifdef CONFIG_IFX_GW188
		#define IFX_DECT_RST 46
		#define IFX_DECT_SPI_CS 33
	#else
		#ifdef COSIC_BMC_FW_ON_RAM
			#define IFX_DECT_RST 33
		#else
			#define IFX_DECT_RST 22
		#endif
		#define IFX_DECT_SPI_CS 13
	#endif
#elif defined(CONFIG_DANUBE)
#define IFX_DECT_RST 20
#define IFX_DECT_SPI_CS 10
extern const int dect_gpio_module_id;
#elif defined(CONFIG_AR10)
#define IFX_DECT_SPI_CS 14
#elif defined(CONFIG_VR9)
	#define IFX_DECT_RST 14 
	#define IFX_DECT_SPI_CS 22
#endif
#endif /* LINUX */
#ifdef SUPERTASK
#ifdef _INFXR9
#define IFX_DECT_RST 12
#define IFX_DECT_INT 1
#define IFX_DECT_SPI_CS 9
#endif
#endif

#ifdef LINUX
#ifdef DECT_USE_USIF

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)

#define ifx_ssc_cs_low lantiq_usif_spi_cs_low
#define ifx_ssc_cs_high lantiq_usif_spi_cs_high
#define ifx_sscLock lantiq_usif_spiLock
#define ifx_sscUnlock lantiq_usif_spiUnLock
#define ifx_sscSetBaud lantiq_usif_spiSetBaud
#define ifx_sscTxRx lantiq_usif_spiTxRx
#define ifx_sscRx lantiq_usif_spiRx
#define ifx_sscTx lantiq_usif_spiTx
#define IFX_SSC_HANDLE LANTIQ_USIF_SPI_HANDLE_t
#define ifx_sscAllocConnection lantiq_usif_spiAllocConnection
#define ifx_sscFreeConnection lantiq_usif_spiFreeConnection
#define ifx_sscAsyncTxRx lantiq_usif_spiAsyncTxRx
#define ifx_sscAsyncTx lantiq_usif_spiAsyncTx
#define ifx_sscAsyncRx lantiq_usif_spiAsyncRx
#define ifx_sscAsyncLock lantiq_usif_spiAsyncLock
#define ifx_sscAsyncUnLock lantiq_usif_spiAsyncUnLock
#define IFX_SSC_PRIO_LOW LANTIQ_USIF_SPI_PRIO_LOW
#define IFX_SSC_PRIO_MID LANTIQ_USIF_SPI_PRIO_MID
#define IFX_SSC_PRIO_HIGH LANTIQ_USIF_SPI_PRIO_HIGH
#define IFX_SSC_PRIO_ASYNC LANTIQ_USIF_SPI_PRIO_ASYNC 
#define IFX_SSC_MODE_0 LANTIQ_USIF_SPI_MODE_0
#define IFX_SSC_MODE_1 LANTIQ_USIF_SPI_MODE_1
#define IFX_SSC_MODE_2 LANTIQ_USIF_SPI_MODE_2
#define IFX_SSC_MODE_3 LANTIQ_USIF_SPI_MODE_3
#define IFX_SSC_MODE_UNKNOWN LANTIQ_USIF_SPI_MODE_UNKNOWN 
#define IFX_SSC_HANDL_TYPE_SYNC LANTIQ_USIF_SPI_HANDL_TYPE_SYNC
#define IFX_SSC_HANDL_TYPE_ASYNC LANTIQ_USIF_SPI_HANDL_TYPE_ASYNC
#define IFX_CS_DATA LANTIQ_USIF_SPI_CS_DATA_t
#define IFX_SSC_CS_ON LANTIQ_USIF_SPI_CS_ON
#define IFX_SSC_CS_OFF LANTIQ_USIF_SPI_CS_OFF
#define IFX_SSC_WHBGPOSTAT_OUT0_POS LANTIQ_USIF_SPI_CS0
#define IFX_SSC_WHBGPOSTAT_OUT1_POS LANTIQ_USIF_SPI_CS1
#define IFX_SSC_WHBGPOSTAT_OUT2_POS LANTIQ_USIF_SPI_CS2
#define IFX_SSC_WHBGPOSTAT_OUT3_POS LANTIQ_USIF_SPI_CS3
#define IFX_SSC_WHBGPOSTAT_OUT4_POS LANTIQ_USIF_SPI_CS4
#define IFX_SSC_WHBGPOSTAT_OUT5_POS LANTIQ_USIF_SPI_CS5
#define IFX_SSC_WHBGPOSTAT_OUT6_POS LANTIQ_USIF_SPI_CS6
#define IFX_SSC_WHBGPOSTAT_OUT7_POS LANTIQ_USIF_SPI_CS7
#define IFX_SSC_CS_CB_t LANTIQ_USIF_SPI_CS_CB_t
#define ifx_ssc_async_fkt_cb_t lantiq_usif_spi_async_fkt_cb_t
#define IFX_SSC_ASYNC_CALLBACK_t LANTIQ_USIF_SPI_ASYNC_CALLBACK_t
#define IFX_SSC_CONFIGURE_t LANTIQ_USIF_SPI_CONFIGURE_t

#else

#define ifx_ssc_cs_low ifx_usif_spi_cs_low
#define ifx_ssc_cs_high ifx_usif_spi_cs_high
#define ifx_sscLock ifx_usif_spiLock
#define ifx_sscUnlock ifx_usif_spiUnLock
#define ifx_sscSetBaud ifx_usif_spiSetBaud
#define ifx_sscTxRx ifx_usif_spiTxRx
#define ifx_sscRx ifx_usif_spiRx
#define ifx_sscTx ifx_usif_spiTx
#define IFX_SSC_HANDLE IFX_USIF_SPI_HANDLE_t
#define ifx_sscAllocConnection ifx_usif_spiAllocConnection
#define ifx_sscFreeConnection ifx_usif_spiFreeConnection
#define ifx_sscAsyncTxRx ifx_usif_spiAsyncTxRx
#define ifx_sscAsyncTx ifx_usif_spiAsyncTx
#define ifx_sscAsyncRx ifx_usif_spiAsyncRx
#define ifx_sscAsyncLock ifx_usif_spiAsyncLock
#define ifx_sscAsyncUnLock ifx_usif_spiAsyncUnLock
#define IFX_SSC_PRIO_LOW IFX_USIF_SPI_PRIO_LOW
#define IFX_SSC_PRIO_MID IFX_USIF_SPI_PRIO_MID
#define IFX_SSC_PRIO_HIGH IFX_USIF_SPI_PRIO_HIGH
#define IFX_SSC_PRIO_ASYNC IFX_USIF_SPI_PRIO_ASYNC 
#define IFX_SSC_MODE_0 IFX_USIF_SPI_MODE_0
#define IFX_SSC_MODE_1 IFX_USIF_SPI_MODE_1
#define IFX_SSC_MODE_2 IFX_USIF_SPI_MODE_2
#define IFX_SSC_MODE_3 IFX_USIF_SPI_MODE_3
#define IFX_SSC_MODE_UNKNOWN IFX_USIF_SPI_MODE_UNKNOWN 
#define IFX_SSC_HANDL_TYPE_SYNC IFX_USIF_SPI_HANDL_TYPE_SYNC
#define IFX_SSC_HANDL_TYPE_ASYNC IFX_USIF_SPI_HANDL_TYPE_ASYNC
#define IFX_CS_DATA IFX_USIF_SPI_CS_DATA_t
#define IFX_SSC_CS_ON IFX_USIF_SPI_CS_ON
#define IFX_SSC_CS_OFF IFX_USIF_SPI_CS_OFF
#define IFX_SSC_WHBGPOSTAT_OUT0_POS IFX_USIF_SPI_CS0
#define IFX_SSC_WHBGPOSTAT_OUT1_POS IFX_USIF_SPI_CS1
#define IFX_SSC_WHBGPOSTAT_OUT2_POS IFX_USIF_SPI_CS2
#define IFX_SSC_WHBGPOSTAT_OUT3_POS IFX_USIF_SPI_CS3
#define IFX_SSC_WHBGPOSTAT_OUT4_POS IFX_USIF_SPI_CS4
#define IFX_SSC_WHBGPOSTAT_OUT5_POS IFX_USIF_SPI_CS5
#define IFX_SSC_WHBGPOSTAT_OUT6_POS IFX_USIF_SPI_CS6
#define IFX_SSC_WHBGPOSTAT_OUT7_POS IFX_USIF_SPI_CS7
#define IFX_SSC_CS_CB_t IFX_USIF_SPI_CS_CB_t
#define ifx_ssc_async_fkt_cb_t ifx_usif_spi_async_fkt_cb_t
#define IFX_SSC_ASYNC_CALLBACK_t IFX_USIF_SPI_ASYNC_CALLBACK_t
#define IFX_SSC_CONFIGURE_t IFX_USIF_SPI_CONFIGURE_t
#endif /*Kernel version check*/
#define ssc_mode spi_mode
#define ssc_prio spi_prio
#endif /*USIF Check*/
#endif /* LINUX */

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */
typedef enum {
  DECT_DRV_HMAC_BUF_EMPTY = 0x00,
  DECT_DRV_HMAC_BUF_LAST,
  DECT_DRV_HMAC_BUF_MORE
} HMAC_LMAC_RETURN_VALUE;

/* Datastructure for maintaining the incoming buffers for voice and data */
typedef struct x_IFX_Mcei_Buffer {
  int iKpiChan;
  int iIn;
  int iOut;
  char *pcVoiceDataBuffer;
  char *pcVoiceDataBuffer1;
  char acMacBuffer[50];
} x_IFX_Mcei_Buffer;

/* =======================================================================
 * Global Variables
 * ======================================================================= */
extern unsigned char vucDriverMode;
extern unsigned char vucReadBuffer[MAX_READ_BUFFFERS][COSIC_LOADER_PACKET_SIZE];
extern unsigned char vucWriteBuffer[MAX_WRITE_BUFFERS][COSIC_LOADER_PACKET_SIZE];
extern unsigned short vu16ReadBufHead;
extern unsigned short vu16ReadBufTail;
extern unsigned short vu16WriteBufHead;
extern unsigned short vu16WriteBufTail;

/* =======================================================================
 * Global Function Prototypes
 * ======================================================================= */
void Dect_SendtoStack(HMAC_QUEUES * data);
void Dect_SendtoLMAC(HMAC_QUEUES * data);
HMAC_LMAC_RETURN_VALUE Dect_Drv_Get_Data(HMAC_QUEUES* data);

void Dect_DebugSendtoApplication(DECT_MODULE_DEBUG_INFO* data);
void Dect_DebugSendtoModule(DECT_MODULE_DEBUG_INFO* data);
HMAC_LMAC_RETURN_VALUE Dect_Debug_Get_Data(DECT_MODULE_DEBUG_INFO* data);

int ssc_dect_haredware_reset(int on);

void Reset_Hmac_Debug_buffer(void);

#endif /* _DECT_DRV_H_ */

