/******************************************************************************

                              Copyright (c) 2009
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/
/*****************************************************************************
*                                                                           *
*     Workfile   :  FMBC.H                                                  *
*     Date       :  18 Nov, 2005                                            *
*     Contents   :  Contents : Function declarations for FMBC.C .           *
*     Hardware   :  IFX 87xx                                                *
*                                                                           *
*****************************************************************************
*/
#ifndef _INC_FMBC
#define _INC_FMBC

/* =======================================================================
 * Include Files
 * ======================================================================= */
#include "fhmac.h"

/* =======================================================================
 * External Reference
 * ======================================================================= */

/* =======================================================================
 * Definitions
 * ======================================================================= */
/* -----------------------------------------------------------------------
 * Project Configuration
 * ----------------------------------------------------------------------- */
// ------------------------
// External Compile Options
// ------------------------
/*
   For Linux
   ---------
   CATIQ
   CATIQ_NOEMO
   CATIQ_UPLANE
   CONFIG_SWITCH_MDIO_ACC
   CONFIG_TWINPASS
   COSIC_DMA
   DECT_NG
   DECT_NG_AS
   DECT_NG_WBS
   DECT_NG_FULL_PAGE
   FT
   IFX_COSIC_DEBUG
   LINUX
   TAPI_LOOPBACK
   ULE_SUPPORT
   USE_PLC_BIT
   USE_VOICE_BUFFERPOOL
   VOICE_CYCLIC_INDEX_CHECK

   For SUPERTASK
   -------------
   __PIN_CODE__
   CATIQ
   CATIQ_NOEMO
   CATIQ_UPLANE
   CATIQ_VE
   DECT_NG
   DECT_NG_AS
   DECT_NG_WBS
   DECT_NG_FULL_PAGE
   DECT_SUPPORT
   F_DECT_STACK_LIBRARY
   FT
   FW_DOWNLOAD
   SUPERTASK
   ULE_SUPPORT
   USE_PLC_BIT
   USE_VOICE_BUFFERPOOL
 */

// ------------------------
// Internal Compile Options
// ------------------------
// Re-keying and early encryption features are added.
#define CONFIG_EARLY_ENCRYPTION
//#define CONFIG_REPEATER_SUPPORT  //=> This moves to /repo_feed_dect/ltq_dect/Makefile

/* -----------------------------------------------------------------------
 * Foundation
 * ----------------------------------------------------------------------- */
// 1 / 0
// -----
#define YES 1
#define NO  0

#define TRUE  YES
#define FALSE NO

#define ON  YES
#define OFF NO

#define MAX_REPEATERS_CASDADED 6
// Scope
// -----
#define IMPORT extern
#define EXPORT
#define GLOBAL
#define LOCAL  static

/* -----------------------------------------------------------------------
 * System (COSIC Driver)
 * ----------------------------------------------------------------------- */
// Debug Messages Level
// --------------------
#define MSG_LEVEL_LOW  0   // Lowest priority messages
#define MSG_LEVEL_MED  1   // Medium priority messages
#define MSG_LEVEL_HIGH 2   // High priority messages
#define MSG_LVL_USER	  250	// User mode
#define MSG_LVL_NONE   255 // No messages (highest priority)

#ifndef MSG_LEVEL // If level is not defined, default is none
#define MSG_LEVEL MSG_LVL_NONE
#endif

// High Level Debug Messages
// -------------------------
// Enable high level debug messages
#if 0 // (MSG_LEVEL < MSG_LVL_USER)
// #define DECT_DEBUG_HIGH_HMAC_PRIMITIVE
// #define DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE
// #define DECT_DEBUG_HIGH_HMAC_REP_PRIMITIVE
// #define DECT_DEBUG_HIGH_HMAC_MCEI_PRIMITIVE
// #define DECT_DEBUG_HIGH_HMAC_PRIMITIVE_NUMBER
// #define DECT_DEBUG_HIGH_HMAC_INFO
// #define DECT_DEBUG_HIGH_HMAC_DEBUG_MESSAGE
// #define DECT_DEBUG_HIGH_LMAC_PRIMITIVE
#endif

// Details of each debug definition for high level debug messages
#ifdef DECT_DEBUG_HIGH_HMAC_PRIMITIVE
#undef DECT_DEBUG_HIGH_HMAC_PRIMITIVE
#define DECT_DEBUG_HIGH_HMAC_PRIMITIVE(fmt,arg...) printk("\n[HMAC] M: "fmt, ##arg)
#else
#define DECT_DEBUG_HIGH_HMAC_PRIMITIVE(fmt,arg...)
#endif

#ifdef DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE
#undef DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE
#define DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE(fmt,arg...) printk("\n[HMAC] M: "fmt, ##arg)
#else
#define DECT_DEBUG_HIGH_HMAC_ULE_PRIMITIVE(fmt,arg...)
#endif

#ifdef DECT_DEBUG_HIGH_HMAC_REP_PRIMITIVE
#undef DECT_DEBUG_HIGH_HMAC_REP_PRIMITIVE
#define DECT_DEBUG_HIGH_HMAC_REP_PRIMITIVE(fmt,arg...) printk("\n[HMAC] M: "fmt, ##arg)
#else
#define DECT_DEBUG_HIGH_HMAC_REP_PRIMITIVE(fmt,arg...)
#endif

#ifdef DECT_DEBUG_HIGH_HMAC_MCEI_PRIMITIVE
#undef DECT_DEBUG_HIGH_HMAC_MCEI_PRIMITIVE
#define DECT_DEBUG_HIGH_HMAC_MCEI_PRIMITIVE(fmt,arg...) printk("\n[HMAC] M: "fmt, ##arg)
#else
#define DECT_DEBUG_HIGH_HMAC_MCEI_PRIMITIVE(fmt,arg...)
#endif

#ifdef DECT_DEBUG_HIGH_HMAC_PRIMITIVE_NUMBER
#undef DECT_DEBUG_HIGH_HMAC_PRIMITIVE_NUMBER
#define DECT_DEBUG_HIGH_HMAC_PRIMITIVE_NUMBER(fmt,arg...) printk("\n[HMAC] M: "fmt, ##arg)
#else
#define DECT_DEBUG_HIGH_HMAC_PRIMITIVE_NUMBER(fmt,arg...)
#endif

#ifdef DECT_DEBUG_HIGH_HMAC_DEBUG_MESSAGE
#undef DECT_DEBUG_HIGH_HMAC_DEBUG_MESSAGE
#define DECT_DEBUG_HIGH_HMAC_DEBUG_MESSAGE(fmt,arg...) printk("\n[HMAC] M: "fmt, ##arg)
#else
#define DECT_DEBUG_HIGH_HMAC_DEBUG_MESSAGE(fmt,arg...)
#endif

#ifdef DECT_DEBUG_HIGH_HMAC_INFO
#undef DECT_DEBUG_HIGH_HMAC_INFO
#define DECT_DEBUG_HIGH_HMAC_INFO(p) p
#else
#define DECT_DEBUG_HIGH_HMAC_INFO(p)
#endif

#ifdef DECT_DEBUG_HIGH_LMAC_PRIMITIVE
#undef DECT_DEBUG_HIGH_LMAC_PRIMITIVE
#define DECT_DEBUG_HIGH_LMAC_PRIMITIVE(fmt,arg...) printk("\n[HMAC] M:"fmt, ##arg)
#else
#define DECT_DEBUG_HIGH_LMAC_PRIMITIVE(fmt,arg...)
#endif

// Medium Level Debug Messages
// ---------------------------
// Enable medium level debug messages
#if 0 // (MSG_LEVEL < MSG_LEVEL_HIGH)
#define DECT_DEBUG_MED_HMAC
#endif

// Details of each debug definition for medium level debug messages
#ifdef DECT_DEBUG_MED_HMAC
#undef DECT_DEBUG_MED_HMAC
#define DECT_DEBUG_MED_HMAC(fmt,arg...) printk("\n[HMAC] %s: "fmt,__FUNCTION__, ##arg)
#else
#define DECT_DEBUG_MED_HMAC(fmt,arg...)
#endif

// Low Level Debug Messages
// ------------------------
// Enable low level debug messages
#if 0 // (MSG_LEVEL < MSG_LEVEL_MED)
#define DECT_DEBUG_LOW_HMAC
#endif

// Details of each debug definition for low level debug messages
#ifdef DECT_DEBUG_LOW_HMAC
#undef DECT_DEBUG_LOW_HMAC
#define DECT_DEBUG_LOW_HMAC(fmt,arg...) printk("\n[HMAC] %s: "fmt,__FUNCTION__, ##arg)
#else
#define DECT_DEBUG_LOW_HMAC(fmt,arg...)
#endif

// Macros
// ------
#ifdef SUPERTASK
#define printk iprintf
#endif

/* -----------------------------------------------------------------------
 * Module
 * ----------------------------------------------------------------------- */
#define NO_MCEI 0xFF // Invalid or unknown MCEI value
#define NO_LBN  0xFF // Invalid or unknown LBN

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */
/* -----------------------------------------------------------------------
 * Foundation
 * ----------------------------------------------------------------------- */
typedef unsigned char  BYTE;  // 1 bytes
typedef unsigned short WORD;  // 2 bytes
typedef unsigned long  DWORD; // 4 bytes
typedef unsigned char  BOOL;


/* -----------------------------------------------------------------------
 * Module
 * ----------------------------------------------------------------------- */
#ifdef ULE_SUPPORT
typedef struct ULE_hmac_queues {
   unsigned char PROCID;
   unsigned char MSG;
   unsigned char Parameter1; // LBN
   unsigned char Parameter2;
   unsigned char Parameter3;
   unsigned char Parameter4;
   unsigned char G_PTR_buf[1 + G_PTR_MAX_ULE_COUNT]; // Length field + Data buffer field
   unsigned char CurrentInc; // Mcei
} ULE_HMAC_QUEUES;
#endif

// MBC states
typedef enum {
   MBC_ST_IDLE = 0,
   MBC_ST_CON_RQ,
   MBC_ST_EST,
   MBC_ST_HO,
   #ifdef DECT_NG
   MBC_ST_CM_HO,       // HO for Connectiontype Modification
   MBC_ST_SM_INVOKING,
   #endif
   #ifdef ULE_SUPPORT
   MBC_ST_RESUME,
   MBC_ST_SUSPEND,
   #endif
   MBC_ST_RELEASE_RQ,
} MBC_ST;


typedef struct {
   BYTE pmid[3];

   BYTE Mbc_State;     // MBC state
   BYTE lbn_1;         // TBC LBN
   BYTE lbn_2;         // TBC LBN
   #ifdef ULE_SUPPORT
   BYTE dck_array[16]; // Default DCK array
   #else
   BYTE dck_array[8];
   #endif
   BYTE Enc_State;     // 'Encryption' state
   // #ifdef DECT_NG
   BYTE wbs_req;       // Marker for an 'slot-type modefication' req. for WBS
   // #endif
   #ifdef ULE_SUPPORT
   BYTE LastRN[2];
   #endif
   #ifdef CONFIG_REPEATER_SUPPORT
   BYTE EncLbn;
   #endif
} MCEI_TAB_STRUC;

#ifdef CONFIG_REPEATER_SUPPORT
typedef struct
{
   unsigned char Rep_Cntr;
   unsigned char Pmid[MAX_REPEATERS_CASDADED][3];
} REP_TAB_STRUCT;
#endif

/* =======================================================================
 * Global Variables
 * ======================================================================= */
extern MCEI_TAB_STRUC Mcei_Table[MAX_MCEI];
#ifdef CONFIG_REPEATER_SUPPORT
extern REP_TAB_STRUCT Rep_Table[MAX_LINK];
#endif

/* =======================================================================
 * Global Function Prototypes
 * ======================================================================= */
void HMAC_INIT(void);
void DECODE_HMAC(HMAC_QUEUES *value);

#ifdef ULE_SUPPORT
void ULE_Init_MBC (void);
unsigned char ULE_New_Mcei( unsigned char *pmid_ptr );
void ULE_Init_Mcei_Table_Element (unsigned char nr);
#endif

void Init_MBC (void);

unsigned char New_Mcei( void );
unsigned char Get_Mcei( unsigned char, unsigned char * );
unsigned char Get_Used_Pmid( unsigned char, unsigned char * );
#ifdef CONFIG_REPEATER_SUPPORT
unsigned char Get_Used_Rep_Pmid( unsigned char, unsigned char, unsigned char * );
unsigned char Get_Used_Rep_Num( unsigned char, unsigned char * );
#endif
unsigned char Get_Enc_State( unsigned char mcei);
unsigned char Get_CC_State ( unsigned char mcei );
void Set_KNL_State(unsigned char cid, unsigned char state);
void Init_Mcei_Table_Element (unsigned char nr);
unsigned char Get_Lbn_of_only_TB( unsigned char );
void Load_Encryption_Key( unsigned char *, unsigned char );
void Attach_TBC_to_MBC( unsigned char, unsigned char );
void Detach_TBC_from_MBC( unsigned char, unsigned char );

unsigned char Check_Same_BsCH_Page  ( unsigned char *, unsigned char );
BYTE Get_Mcei_of_only_TB   ( BYTE );

void Init_BsCh_Queue(void);
void BsCh_Paging_Request( unsigned char *, unsigned char);
void BsCh_Paging_Response( void );
void Discard_BsCh_Queue(unsigned char how);

#ifdef DECT_NG
BYTE Get_no_of_mcei_assigned (void);
#endif

#endif
