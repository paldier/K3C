#include <assert.h>
#include "helper.h"

int verify_valid_version(int version)
{
    return 0;
}

uint32_t get_headersize_for_version(uint32_t version)
{
    uint32_t header_size;
    if (version == 2) {
        header_size = UIMAGE_HEADER_SIZE_V2;
    } else if (version == 3) {
        header_size = UIMAGE_HEADER_SIZE_V3;
    } else {
        ERR("Unsupported version requested:%d\n", version);
        assert(1 == 0);
    }

    return header_size;
}

uint32_t get_headermagic_for_version(uint32_t version)
{
    uint32_t header_magic;
    if (version == 2) {
        header_magic = IMAGE_MAGIC_VER2;
    } else if (version == 3) {
        header_magic = IMAGE_MAGIC_VER3;
    } else {
        ERR("Unsupported version requested:%d\n", version);
        assert(1 == 0);
    }

    return header_magic;
}

uint32_t get_max_partitions_for_version(uint32_t version)
{
    uint32_t max_part;
    if (version == 2) {
        max_part = VER2_MAX_PART_NUM;
    } else if (version == 3) {
        max_part = VER3_MAX_PART_NUM;
    } else {
        ERR("Unsupported version requested:%d\n", version);
        assert(1 == 0);
    }

    return max_part;
}

uint32_t get_h_version(struct imageHeader *h)
{
    assert(h);
    uint32_t version =  ntohl(h->version);
    /* TODO: THIS IS A WORKAROUND DUE TO OLDER TOOLS GENERATING CORRUPT IMAGES.
             SETTING THE VERSION TO 1 WHEN IT IS ACTUALLY VERSION 2. THIS IS
             HERE TO UNBLOCK SPECIFIC PROGRESS DURING CUSTOMER INTEGRATION.
             REMOVE ME!*/
    if (version == 1)
        version = 2;
    return version;
}

uint32_t get_h_part_num(struct imageHeader *h)
{
    assert(h);
    return ntohl(h->partNum);
}

uint32_t get_part_size(struct imageHeader *h, int index)
{
    assert(h);

    uint32_t ret = 0;
    uint32_t version = get_h_version(h);

    if (verify_valid_version(version)) {
        ERR("This requires a valid version.\n");
        assert(1 == 0);
    }

    if (version == 2)
        ret = ntohl(h->info.ver2.pSize[index]);
    else if(version == 3)
        ret = ntohl(h->info.ver3.pSize[index]);
    else
        assert(1 == 0);

    return ret;
}

uint32_t get_part_crc(struct imageHeader *h, int index)
{
    assert(h);

    uint32_t ret = 0;
    uint32_t version = get_h_version(h);

    if (verify_valid_version(version)) {
        ERR("This requires a valid version.\n");
        assert(1 == 0);
    }

    if (version == 2)
        ret = ntohl(h->info.ver2.pCrc[index]);
    else if(version == 3)
        ret = ntohl(h->info.ver3.pCrc[index]);
    else
        assert(1 == 0);

    return ret;
}

uint32_t get_part_type(struct imageHeader *h, int index)
{
    assert(h);

    uint32_t ret = 0;
    uint32_t version = get_h_version(h);

    if (verify_valid_version(version)) {
        ERR("This requires a valid version.\n");
        assert(1 == 0);
    }

    if (version == 2)
        ret = h->info.ver2.pType[index];
    else if(version == 3)
        ret = h->info.ver3.pType[index];
    else
        assert(1 == 0);

    return ret;
}

uint32_t get_part_attr(struct imageHeader *h, int index)
{
    assert(h);

    uint32_t ret = 0;
    uint32_t version = get_h_version(h);

    if (verify_valid_version(version)) {
        ERR("This requires a valid version.\n");
        assert(1 == 0);
    }

    if (version == 2)
        ret = h->info.ver2.pAttribute[index];
    else if(version == 3)
        ret = h->info.ver3.pAttribute[index];
    else
        assert(1 == 0);

    return ret;
}

uint32_t get_h_struct_size(struct imageHeader *h)
{
    assert(h);

    uint32_t ret = 0;
    uint32_t version = get_h_version(h);

    if (verify_valid_version(version)) {
        ERR("This requires a valid version.\n");
        assert(1 == 0);
    }

    if (version == 2)
        ret = UIMAGE_HEADER_SIZE_V2;
    else if(version == 3)
        ret = UIMAGE_HEADER_SIZE_V3;
    else
        assert(1 == 0);

    return ret;
}

uint32_t get_h_image_size(struct imageHeader *h)
{
    assert(h);
    return ntohl(h->imageSize);
}

uint32_t get_h_magic(struct imageHeader *h)
{
    assert(h);
    return ntohl(h->magic);
}

uint32_t get_h_hcrc(struct imageHeader *h)
{
    assert(h);
    return ntohl(h->hCrc);
}

uint32_t get_h_dcrc(struct imageHeader *h)
{
    assert(h);
    return ntohl(h->dCrc);
}

void get_h_date(struct imageHeader *h, uint32_t *year, uint32_t *month, uint32_t *day)
{
    assert(h);

    if (year)  *year  = ((ntohl(h->date) >> 16) & 0xFF) + 1900;
    if (month) *month =  (ntohl(h->date) >>  8) & 0xFF;
    if (day)   *day   =  (ntohl(h->date) >>  0) & 0xFF;
}

void get_h_time(struct imageHeader *h, uint32_t *hour, uint32_t *minute, uint32_t *second)
{
    assert(h);

    if (hour)   *hour   = (ntohl(h->time) >> 16) & 0xFF;
    if (minute) *minute = (ntohl(h->time) >>  8) & 0xFF;
    if (second) *second = (ntohl(h->time) >>  0) & 0xFF;
}

void set_h_version(struct imageHeader *h, uint32_t version)
{
    assert(h);
    assert(!verify_valid_version(version));
    h->version = htonl(version);
}

void set_h_magic(struct imageHeader *h, uint32_t magic)
{
    assert(h);
    h->magic = htonl(magic);
}

void set_h_hcrc(struct imageHeader *h, uint32_t crc)
{
    assert(h);
    h->hCrc = htonl(crc);
}

void set_h_dcrc(struct imageHeader *h, uint32_t crc)
{
    assert(h);
    h->dCrc = htonl(crc);
}

void set_h_part_num(struct imageHeader *h, uint32_t num)
{
    assert(h);
    h->partNum = htonl(num);
}

void set_h_image_size(struct imageHeader *h, uint32_t size)
{
    assert(h);
    h->imageSize = htonl(size);
}

void set_h_date(struct imageHeader *h, uint32_t year, uint32_t month, uint32_t day)
{
    assert(h);
	h->date = htonl(((year - 1900) << 16) | (((month & 0xFF) + 1) << 8) | (day & 0xFF));
}

void set_h_time(struct imageHeader *h, uint32_t hour, uint32_t minute, uint32_t second)
{
    assert(h);
	h->time = htonl((hour << 16) | ((minute & 0xFF) << 8) | (second & 0xFF));
}

void set_part_crc(struct imageHeader *h, uint32_t index, uint32_t crc)
{
    assert(h);

    uint32_t version = get_h_version(h);

    if (verify_valid_version(version)) {
        ERR("This requires a valid version.\n");
        assert(1 == 0);
    }

    if (version == 2)
        h->info.ver2.pCrc[index] = htonl(crc);
    else if(version == 3)
        h->info.ver3.pCrc[index] = htonl(crc);
    else
        assert(1 == 0);
}

void set_part_size(struct imageHeader *h, uint32_t index, uint32_t size)
{
    assert(h);

    uint32_t version = get_h_version(h);

    if (verify_valid_version(version)) {
        ERR("This requires a valid version.\n");
        assert(1 == 0);
    }

    if (version == 2)
        h->info.ver2.pSize[index] = htonl(size);
    else if(version == 3)
        h->info.ver3.pSize[index] = htonl(size);
    else
        assert(1 == 0);
}

void set_part_type(struct imageHeader *h, uint32_t index, uint32_t type)
{
    assert(h);

    uint32_t version = get_h_version(h);

    if (verify_valid_version(version)) {
        ERR("This requires a valid version.\n");
        assert(1 == 0);
    }

    if (version == 2)
        h->info.ver2.pType[index] = type;
    else if(version == 3)
        h->info.ver3.pType[index] = type;
    else
        assert(1 == 0);
}

void set_part_attr(struct imageHeader *h, uint32_t index, uint32_t attr)
{
    assert(h);

    uint32_t version = get_h_version(h);

    if (verify_valid_version(version)) {
        ERR("This requires a valid version.\n");
        assert(1 == 0);
    }

    if (version == 2)
        h->info.ver2.pAttribute[index] = attr;
    else if(version == 3)
        h->info.ver3.pAttribute[index] = attr;
    else
        assert(1 == 0);
}
