#ifndef __HELPER_H__
#define  __HELPER_H__

#include "image.h"
#include <stdio.h>

#define ERR(msg, ...)                                                         \
do {                                                                          \
    fprintf(stdout, "ERROR:\n");                                              \
    fprintf(stdout, " - %s():%d:%s\n", __FUNCTION__, __LINE__, __FILE__);     \
    fprintf(stdout, " - " msg, ##__VA_ARGS__);                                \
} while(0)

uint32_t get_headersize_for_version(uint32_t version);
uint32_t get_headermagic_for_version(uint32_t version);
uint32_t get_max_partitions_for_version(uint32_t version);

uint32_t get_part_size(struct imageHeader *h, int index);
uint32_t get_part_crc(struct imageHeader *h, int index);
uint32_t get_part_type(struct imageHeader *h, int index);
uint32_t get_part_attr(struct imageHeader *h, int index);

uint32_t get_h_part_num(struct imageHeader *h);
uint32_t get_h_version(struct imageHeader *h);
uint32_t get_h_struct_size(struct imageHeader *h);
uint32_t get_h_image_size(struct imageHeader *h);
uint32_t get_h_magic(struct imageHeader *h);
uint32_t get_h_hcrc(struct imageHeader *h);
uint32_t get_h_dcrc(struct imageHeader *h);
void get_h_date(struct imageHeader *h, uint32_t *year, uint32_t *month, uint32_t *day);
void get_h_time(struct imageHeader *h, uint32_t *hour, uint32_t *minute, uint32_t *second);

void set_h_version(struct imageHeader *h, uint32_t version);
void set_h_magic(struct imageHeader *h, uint32_t magic);
void set_h_hcrc(struct imageHeader *h, uint32_t crc);
void set_h_dcrc(struct imageHeader *h, uint32_t crc);
void set_h_part_num(struct imageHeader *h, uint32_t num);
void set_h_image_size(struct imageHeader *h, uint32_t size);
void set_h_date(struct imageHeader *h, uint32_t year, uint32_t month, uint32_t day);
void set_h_time(struct imageHeader *h, uint32_t hour, uint32_t minute, uint32_t second);
void set_part_crc(struct imageHeader *h, uint32_t index, uint32_t crc);
void set_part_size(struct imageHeader *h, uint32_t index, uint32_t size);
void set_part_type(struct imageHeader *h, uint32_t index, uint32_t type);
void set_part_attr(struct imageHeader *h, uint32_t index, uint32_t attr);
#endif
