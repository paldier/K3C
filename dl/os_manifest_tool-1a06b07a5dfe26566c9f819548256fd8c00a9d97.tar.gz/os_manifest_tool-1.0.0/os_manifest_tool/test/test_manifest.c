/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "log.h"
#include "manifest.h"
#include "parameters.h"
#include "utilities.h"
#include "files.h"

#include "ctest.h"
#include "test_keys.h"
#include "test_memory_stream.h"
#include "test_utility.h"

#include <string.h>
#include <stdio.h>
#include <errno.h>

static manifest_input_t *gpInput = NULL;
static manifest_output_t *gpManifest = NULL;
static uint gImageSize = 1024;

static void setup(void)
{
    int i;
    ResetGlobals();
    MemoryStreamOpen();
    CreateRsaPrivateKeyFile1();

    gpInput = CreateInputStruct();
    gpInput->imageSize = gImageSize;
    gpInput->pImage = calloc(1, gpInput->imageSize);
    memset(gpInput->pImage, 2, gpInput->imageSize);
    assert(gpInput->pImage);
    for(i = 0; i < sizeof(gpInput->oemData); i++)
        gpInput->oemData[i] = (char)i;
}

static void tear_down(void)
{
    if (gpInput->pImage)
    {
        free(gpInput->pImage);
        gpInput->pImage = NULL;
    }
    if (gpManifest)
    {
        free(gpManifest);
        gpManifest = NULL;
    }
    DestroyInputStruct(gpInput);
    remove_file(PRIVATE_RSA_KEY_FILE_NAME_1);
    MemoryStreamClose();
}

void test_manifest_size(void)
{
    int signedSize = sizeof(os_signed_t);
    int unsignedSize = sizeof(os_unsigned_t);
    int totalSize = sizeof(manifest_output_t);

    // Compare to manually computed sizes
    assert_equal(signedSize, 508);
    assert_equal(unsignedSize, 516);
    assert_equal(totalSize, 1024);
}

void GenerateManifestRsaPrivateKey(void)
{
    os_signed_t *pUnsignedManifest = NULL;
    uchar pSignature[struct_member_size(os_unsigned_t, manifestSignature)];

    assert_true(gpManifest == NULL);
    assert_equal(GenerateUnsignedManifest(gpInput, &pUnsignedManifest), 0);
    assert_equal_c(GenerateSignature(CreateRsaPrivateKeyFile1(), pUnsignedManifest, pSignature), 0);

    assert_equal(JoinManifest(pSignature, CreateRsaPrivateKeyFile1(), PrivateKey, pUnsignedManifest, &gpManifest), 0);
    assert_equal_c(VerifyManifestSignature(gpManifest), 0);
    assert_true(gpManifest != NULL);

    free(pUnsignedManifest);
}

void GenerateManifestRsaPublicKey(void)
{
    os_signed_t *pUnsignedManifest = NULL;
    uchar pSignature[struct_member_size(os_unsigned_t, manifestSignature)];

    assert_true(gpManifest == NULL);
    assert_equal(GenerateUnsignedManifest(gpInput, &pUnsignedManifest), 0);
    assert_equal_c(GenerateSignature(CreateRsaPrivateKeyFile1(), pUnsignedManifest, pSignature), 0);

    assert_equal_c(JoinManifest(pSignature, CreateRsaPublicKeyFile1(), PublicKey, pUnsignedManifest, &gpManifest), 0);
    assert_equal_c(VerifyManifestSignature(gpManifest), 0);
    assert_true(gpManifest != NULL);

    free(pUnsignedManifest);
}

void GenerateManifestEvpPublicKey(void)
{
    os_signed_t *pUnsignedManifest = NULL;
    uchar pSignature[struct_member_size(os_unsigned_t, manifestSignature)];

    assert_true(gpManifest == NULL);
    assert_equal(GenerateUnsignedManifest(gpInput, &pUnsignedManifest), 0);
    assert_equal_c(GenerateSignature(CreateEvpPrivateKeyFile2(), pUnsignedManifest, pSignature), 0);

    assert_equal_c(JoinManifest(pSignature, CreateEvpPublicKeyFile2(), PublicKey, pUnsignedManifest, &gpManifest), 0);
    assert_equal_c(VerifyManifestSignature(gpManifest), 0);
    assert_true(gpManifest != NULL);

    free(pUnsignedManifest);
}

void test_manifest_creation_and_verify(void)
{
    GenerateManifestRsaPrivateKey();

    char *pImageFileName = "/tmp/image.bin";
    assert_equal(FileWrite(pImageFileName, gpInput->pImage, gpInput->imageSize), 0);
    assert_equal_c(VerifyManifestImageHash(gpManifest, pImageFileName), 0);
    assert_equal(remove_file(pImageFileName), 0);
}

void test_verify_rsa_public_key(void)
{
    GenerateManifestRsaPublicKey();

    char *pImageFileName = "/tmp/image.bin";
    assert_equal(FileWrite(pImageFileName, gpInput->pImage, gpInput->imageSize), 0);
    assert_equal_c(VerifyManifestImageHash(gpManifest, pImageFileName), 0);
    assert_equal(remove_file(pImageFileName), 0);
}

void test_verify_evp_public_key(void)
{
    GenerateManifestEvpPublicKey();

    char *pImageFileName = "/tmp/image.bin";
    assert_equal(FileWrite(pImageFileName, gpInput->pImage, gpInput->imageSize), 0);
    assert_equal_c(VerifyManifestImageHash(gpManifest, pImageFileName), 0);
    assert_equal(remove_file(pImageFileName), 0);
}

void test_manifest_verify_image_different(void)
{
    assert_true(gpManifest == NULL);
    GenerateManifestRsaPrivateKey();

    char *pImageFileName = "/tmp/image.bin";
    uchar *pImage = malloc(gpInput->imageSize);
    assert(pImage);
    memcpy(pImage, gpInput->pImage, gpInput->imageSize);
    
    // Corrupt the image to change the Hash
    pImage[0] ^= 0xFF;

    assert_equal(FileWrite(pImageFileName, pImage, gpInput->imageSize), 0);
    assert_equal_c(VerifyManifestImageHash(gpManifest, pImageFileName), 1);
    MemoryStreamDoesntContains("Image matches manifest");
    assert_equal(remove_file(pImageFileName), 0);
}

void test_verify_identifier(void)
{
    GenerateManifestRsaPrivateKey();

    assert_equal(gpManifest->s.manifestIdentifier[0], '$');
    assert_equal(gpManifest->s.manifestIdentifier[1], 'K');
    assert_equal(gpManifest->s.manifestIdentifier[2], 'F');
    assert_equal(gpManifest->s.manifestIdentifier[3], 'M');
}

void test_verify_internal_version(void)
{
    GenerateManifestRsaPrivateKey();

    assert_equal(gpManifest->s.manifestInternalVersion, 0x11);
}

void test_verify_manifest_struct_size(void)
{
    GenerateManifestRsaPrivateKey();
    assert_equal(gpManifest->s.manifestStructSize, 0x400);
}

void test_verify_secure_version_number(void)
{
    GenerateManifestRsaPrivateKey();
    assert_equal(gpManifest->s.secureVersionNumber, 0);
    free(gpManifest); 
    gpManifest = NULL;

    gpInput->secureVersionNumber = 1;
    GenerateManifestRsaPrivateKey();
    assert_equal(gpManifest->s.secureVersionNumber, 1);
    free(gpManifest); 
    gpManifest = NULL;

    gpInput->secureVersionNumber = 0xFFFFFFFF;
    GenerateManifestRsaPrivateKey();
    assert_equal(gpManifest->s.secureVersionNumber, 0xFFFFFFFF);
}

void test_verify_key_index(void)
{
    GenerateManifestRsaPrivateKey();
    assert_equal(gpManifest->s.publicKeyHashIndex, 0);
    free(gpManifest);
    gpManifest = NULL;

    gpInput->publicKeyHashIndex = 256;
    GenerateManifestRsaPrivateKey();
    assert_equal(gpManifest->s.publicKeyHashIndex, 256);
    free(gpManifest);
    gpManifest = NULL;

    gpInput->publicKeyHashIndex = 0xFFFFFFFF;
    GenerateManifestRsaPrivateKey();
    assert_equal(gpManifest->s.publicKeyHashIndex, 0xFFFFFFFF);
}

void test_verify_hash_not_null(void)
{
    int i, count = 0;
    GenerateManifestRsaPrivateKey();
    for(i = 0; i < sizeof(gpManifest->s.osImageHash); i++)
    {
        if (gpManifest->s.osImageHash[i] == 0) count++;
    }
    assert_true(count != sizeof(gpManifest->s.osImageHash));
}

void test_verify_manifest_type(void)
{
    gpInput->osManifestType = 1;
    GenerateManifestRsaPrivateKey();
    assert_equal(gpManifest->s.osManifestType, 1);
    free(gpManifest);
    gpManifest = NULL;

    gpInput->osManifestType = 0xFFFFFFFF;
    GenerateManifestRsaPrivateKey();
    assert_equal(gpManifest->s.osManifestType, 0xFFFFFFFF);
}

void test_verify_image_size(void)
{
    int imageSize = 2056;

    gpInput->imageSize = imageSize;
    gpInput->pImage = calloc(1, imageSize);
    assert(gpInput->pImage);
    GenerateManifestRsaPrivateKey();
    assert_equal(gpManifest->s.osImageSize, imageSize);
    free(gpManifest);
    gpManifest = NULL;

    imageSize = 3244;
    gpInput->imageSize = imageSize;
    gpInput->pImage = calloc(1, imageSize);
    assert(gpInput->pImage);
    GenerateManifestRsaPrivateKey();
    assert_equal(gpManifest->s.osImageSize, imageSize);
}

void test_verify_oem_data(void)
{
    int i;
    GenerateManifestRsaPrivateKey();

    // Ensure this isn't just a pointer
    assert_true(sizeof(gpManifest->s.oemData) > 128);
    for (i = 0; i < sizeof(gpManifest->s.oemData); i++)
        assert_equal(gpManifest->s.oemData[i], (char)i);
}

void test_verify_public_key_not_null(void)
{
    int i, count = 0;
    GenerateManifestRsaPrivateKey();
    for (i = 0; i < sizeof(gpManifest->u.publicKeyModulus); i++)
        if (!gpManifest->u.publicKeyModulus[i]) count++;
    assert_true(count < sizeof(gpManifest->u.publicKeyModulus));

    count = 0;
    for (i = 0; i < sizeof(gpManifest->u.publicKeyExponent); i++)
        if (!gpManifest->u.publicKeyExponent[i]) count++;
    assert_true(count < sizeof(gpManifest->u.publicKeyExponent));
}

void test_verify_signature_exists(void)
{
    int i, count = 0;
    GenerateManifestRsaPrivateKey();
    for (i = 0; i < sizeof(gpManifest->u.manifestSignature); i++)
        if (!gpManifest->u.manifestSignature[i]) count++;
    if (count >= sizeof(gpManifest->u.manifestSignature))
    {
        printf("ERROR: count (%d) is not less than actual size(%lu)\n", count, sizeof(gpManifest->u.manifestSignature));
        for (i = 0; i < sizeof(gpManifest->u.manifestSignature); i++)
            printf("%02X ", gpManifest->u.manifestSignature[i]);
        printf("\n");

    }
    assert_true(count < sizeof(gpManifest->u.manifestSignature));
}

test_suite_t* create_suite_manifest()
{
    test_suite_t *pSuite = test_suite_create("Manifest");
    test_suite_add_setup(pSuite, setup);
    test_suite_add_teardown(pSuite, tear_down);

    test_suite_add_test(pSuite, test_manifest_size);
    test_suite_add_test(pSuite, test_manifest_creation_and_verify);
    test_suite_add_test(pSuite, test_verify_rsa_public_key);
    test_suite_add_test(pSuite, test_verify_evp_public_key);
    test_suite_add_test(pSuite, test_manifest_verify_image_different);
    test_suite_add_test(pSuite, test_verify_identifier);
    test_suite_add_test(pSuite, test_verify_internal_version);
    test_suite_add_test(pSuite, test_verify_manifest_struct_size);
    test_suite_add_test(pSuite, test_verify_secure_version_number);
    test_suite_add_test(pSuite, test_verify_key_index);
    test_suite_add_test(pSuite, test_verify_hash_not_null);
    test_suite_add_test(pSuite, test_verify_manifest_type);
    test_suite_add_test(pSuite, test_verify_image_size);
    test_suite_add_test(pSuite, test_verify_oem_data);
    test_suite_add_test(pSuite, test_verify_public_key_not_null);
    test_suite_add_test(pSuite, test_verify_signature_exists);

    return pSuite;
}
