/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __TEST_UTILITY_H__
#define __TEST_UTILITY_H__

#include "manifest.h"

#define LIST_LEN(list) (sizeof(list)/sizeof(list[0]))

int remove_file(char *pFileName);
int write_txt_file(char *pStr, char *pFileName);
void run_app(char *pCmd, int argc, char *pArgs[], int *pStatus, char *pOutput, int lenOutput);

#endif
