/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "ctest.h"

#include <stdio.h>

test_suite_t* create_suite_app();
test_suite_t* create_suite_files();
test_suite_t* create_suite_manifest();
test_suite_t* create_suite_manifest_parameters();
test_suite_t* create_suite_parameters();
test_suite_t* create_suite_utility();

int main(int argc, char *argv[])
{
    int failed;
    test_run_t *pTestRun = test_run_create();

    test_set_debug(false);

    test_run_add_suite(pTestRun, create_suite_manifest_parameters());
    test_run_add_suite(pTestRun, create_suite_manifest());
    test_run_add_suite(pTestRun, create_suite_utility());
    test_run_add_suite(pTestRun, create_suite_files());
    test_run_add_suite(pTestRun, create_suite_parameters());
    test_run_add_suite(pTestRun, create_suite_app());

    if(argc == 1)
    {
        failed = test_run_execute(pTestRun, LOG_STYLE_PRINT_ERROR);
    }
    else
    {
        failed = test_run_execute(pTestRun, LOG_STYLE_VERBOSE);
    }

    test_run_destroy(pTestRun);

    return failed;
}
