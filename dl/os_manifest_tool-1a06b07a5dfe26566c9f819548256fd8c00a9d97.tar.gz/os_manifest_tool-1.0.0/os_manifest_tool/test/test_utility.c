/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "files.h"
#include "log.h"

#include "ctest.h"
#include "test_utility.h"

#include <string.h>
#include <unistd.h>

int write_txt_file(char *pStr, char *pFileName)
{
    int ret = 0;
    FILE *pFile = NULL;
    pFile = fopen(pFileName, "w");
    assert_true(pFile != NULL);

    assert_true(fputs(pStr, pFile) >= 0);
    fclose(pFile);
    return ret;
}


int remove_file(char *pFileName)
{
    int ret = 1;

    if (!FileExists(pFileName))
        printf("ERROR: Cannot delete file as it doesn't exist:%s\n", pFileName);
    else if (unlink(pFileName) == 0)
        ret = 0;

    return ret;
}

void append_string(char *pDest, int destSize, char *pSrc)
{
    if (strlen(pDest) + strlen(pSrc) >= destSize)
    {
        printf("ERROR: The source is too long for the destination size\n");
        printf(" - Dst len:%d\n", destSize);
        printf(" - Dst:%lu:%s\n", strlen(pDest), pDest);
        printf(" - Src:%lu:%s\n", strlen(pSrc), pSrc);
        assert_true(1 == 0);
    }
    else
    {
        strcat(pDest, pSrc);
    }
}

void prepare_command_line(char *pCmd, int argc, char *pArgs[], char *pShellCmd, int shellLength)
{
    int i;
    pShellCmd[0] = 0;

    append_string(pShellCmd, shellLength, pCmd);
    append_string(pShellCmd, shellLength, " ");
    for ( i = 0; i < argc; i++)
    {
        append_string(pShellCmd, shellLength, pArgs[i]);
        append_string(pShellCmd, shellLength, " ");
    }
    append_string(pShellCmd, shellLength, "2>&1");
}

void run_app(char *pCmd, int argc, char *pArgs[], int *pStatus, char *pOutput, int lenOutput)
{
    FILE *pStdOut = NULL;
    int status;
    int index = 0;
    char pShellCmd[1024] = {0};

    prepare_command_line(pCmd, argc, pArgs, pShellCmd, sizeof(pShellCmd));
    pStdOut = popen(pShellCmd, "r");
    assert_true(!!pStdOut);

    // We must read the output or the status is not correct.
    while (index+1 < lenOutput && fgets(&pOutput[index], lenOutput-index, pStdOut) != NULL)
    {
        index = strlen(pOutput);
    }

    if (index+1 >= lenOutput)
    {
        fprintf(stderr, "TEST ERROR: Buffer too small.\n");
        fprintf(stderr, "  - Cmd:%s\n", pCmd);
        fprintf(stderr, "  - Buffer: %d bytes\n", lenOutput);
        assert_true(1 == 0);
    }

    status = pclose(pStdOut);
    *pStatus = WEXITSTATUS(status);
}


