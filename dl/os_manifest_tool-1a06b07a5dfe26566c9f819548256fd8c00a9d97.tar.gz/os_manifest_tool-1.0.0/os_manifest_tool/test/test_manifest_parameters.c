/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "log.h"
#include "manifest.h"
#include "parameters.h"
#include "utilities.h"

#include "ctest.h"
#include "test_keys.h"
#include "test_memory_stream.h"
#include "test_utility.h"

#include <string.h>
#include <stdio.h>
#include <errno.h>

static manifest_input_t *gpInput = NULL;
static manifest_output_t *gpManifest = NULL;
char *pPrivateKeyFileName = NULL;

static void setup(void)
{
    ResetGlobals();
    MemoryStreamOpen();
    gpInput = CreateInputStruct();
    CreateRsaPrivateKeyFile1();
    gpInput->imageSize = 1024;
    gpInput->pImage = calloc(1, gpInput->imageSize);
    assert(gpInput->pImage);
    gpManifest = NULL;
    pPrivateKeyFileName = PRIVATE_RSA_KEY_FILE_NAME_1;
}

static void tear_down(void)
{
    if (gpInput->pImage)
        free(gpInput->pImage);
    if (gpManifest)
        free(gpManifest);
    remove_file(PRIVATE_RSA_KEY_FILE_NAME_1);
    DestroyInputStruct(gpInput);
    MemoryStreamClose();
}

static void test_verify_bad_input_version(void)
{
    os_signed_t *pUnsignedManifest = NULL;
    gpInput->version = 0;
    assert_equal(GenerateUnsignedManifest(gpInput, &pUnsignedManifest), 1);
    MemoryStreamContains("Invalid input struct");
}

static void test_verify_NULL_private_key_file(void)
{
    os_signed_t *pUnsignedManifest = NULL;
    uchar pSignature[struct_member_size(os_unsigned_t, manifestSignature)];

    pPrivateKeyFileName = NULL;
    assert_equal(GenerateUnsignedManifest(gpInput, &pUnsignedManifest), 0);
    assert_equal(GenerateSignature(pPrivateKeyFileName, pUnsignedManifest, pSignature), 1);
    MemoryStreamContains("Private key filename is NULL");

    free(pUnsignedManifest);
}

static void test_verify_bad_private_key(void)
{
    os_signed_t *pUnsignedManifest = NULL;
    uchar pSignature[struct_member_size(os_unsigned_t, manifestSignature)];

    char *pFileName = "/tmp/corrupt.private.key.pem";
    char *pKey = strdup(gpRsaPrivateKeyString1);
    memset(pKey+1, 'a', 10);
    assert_equal(write_txt_file(pKey, pFileName), 0);

    pPrivateKeyFileName = pFileName;

    assert_true(gpManifest == NULL);
    assert_equal(GenerateUnsignedManifest(gpInput, &pUnsignedManifest), 0);
    assert_equal(GenerateSignature(pPrivateKeyFileName, pUnsignedManifest, pSignature), 1);
    MemoryStreamContains("The Private key is not in PEM format");
    free(pKey);
    assert_equal(remove_file(pFileName), 0);
}

static void test_verify_NULL_image(void)
{
    os_signed_t *pUnsignedManifest = NULL;

    if (gpInput->pImage)
        free(gpInput->pImage);
    gpInput->pImage = NULL;
    assert_equal(GenerateUnsignedManifest(gpInput, &pUnsignedManifest), 1);
    MemoryStreamContains("The image to hash is NULL");
}

static void test_verify_zero_sized_image(void)
{
    os_signed_t *pUnsignedManifest = NULL;

    gpInput->imageSize = 0;
    assert_equal(GenerateUnsignedManifest(gpInput, &pUnsignedManifest), 1);
    MemoryStreamContains("Image size is zero");
}

test_suite_t* create_suite_manifest_parameters()
{
    test_suite_t *pSuite = test_suite_create("ManifestParameters");
    test_suite_add_setup(pSuite, setup);
    test_suite_add_teardown(pSuite, tear_down);

    test_suite_add_test(pSuite, test_verify_bad_input_version);
    test_suite_add_test(pSuite, test_verify_NULL_private_key_file);
    test_suite_add_test(pSuite, test_verify_bad_private_key);
    test_suite_add_test(pSuite, test_verify_NULL_image);
    test_suite_add_test(pSuite, test_verify_zero_sized_image);
    return pSuite;
}
