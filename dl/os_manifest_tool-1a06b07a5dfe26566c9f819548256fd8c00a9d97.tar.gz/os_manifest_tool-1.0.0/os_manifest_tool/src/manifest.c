/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "files.h"
#include "log.h"
#include "manifest.h"
#include "utilities.h"

#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include <string.h>

void DestroyPemKey(RSA *pKey);
static int GenerateHashOfImage(char *pFileName, uchar *pHash, int len);
int LoadPemKey(const char *pKeyString, RSA **ppKey, key_type_t type);
static int VerifyUnsignedInputValues(manifest_input_t *pInput, os_signed_t **ppUnsignedManifest);
void VerifyIntSize(void);
int WriteKeyMantissaExponent(char *pPrivateKeyFileName, manifest_output_t *pManifest, key_type_t type);

int GenerateUnsignedManifest(manifest_input_t *pInput, os_signed_t **ppUnsignedManifest)
{
    int ret = 0;
    os_signed_t *pManifest = NULL;

    VerifyIntSize();

    if (VerifyUnsignedInputValues(pInput, ppUnsignedManifest))
        goto error;

    *ppUnsignedManifest = calloc(1, sizeof(os_signed_t));
    ASSERT(*ppUnsignedManifest, "calloc failure.\n");

    pManifest = *ppUnsignedManifest;
    memcpy(pManifest->manifestIdentifier, MANIFEST_IDENTIFIER_V2, MANIFEST_IDENTIFIER_LEN);
    pManifest->manifestInternalVersion = MANIFEST_INTERNAL_VERSION; 
    pManifest->manifestStructSize = sizeof(manifest_output_t);
    pManifest->secureVersionNumber = pInput->secureVersionNumber;
    pManifest->publicKeyHashIndex = pInput->publicKeyHashIndex;
    SHA256(pInput->pImage, pInput->imageSize, pManifest->osImageHash);
    pManifest->osManifestType = pInput->osManifestType;
    pManifest->osImageSize = pInput->imageSize;
    memcpy(pManifest->oemData, pInput->oemData, sizeof(pManifest->oemData));

    goto exit;
error:
    ret = 1;
exit:
    return ret;
}

void VerifyIntSize(void)
{
    ASSERT(sizeof(int) == 4, "This program requires that an 'integer' be four bytes. "
            "sizeof(int):%lu\n", sizeof(int));
}

static int VerifyUnsignedInputValues(manifest_input_t *pInput, os_signed_t **ppUnsignedManifest)
{
    int ret = 0;

    if (pInput == NULL)
    {
        ERR("Input pointer is NULL\n");
        goto error;
    }

    if (pInput->version != INPUT_VERSION)
    {
        ERR("Invalid input struct. Input struct not created by the input create function.\n");
        goto error;
    }

    if (pInput->pImage == NULL)
    {
        ERR("The image to hash is NULL\n");
        goto error;
    }

    if (pInput->imageSize == 0)
    {
        ERR("Image size is zero\n");
        goto error;
    }

    if (ppUnsignedManifest == NULL)
    {
        ERR("Passed in manifest pointer is NULL");
        goto error;
    }

    goto exit;

error:
    ret = 1;
exit:
    return ret;
}

int WriteKeyMantissaExponent(char *pKeyFileName, manifest_output_t *pManifest, key_type_t keyType)
{
    int ret = 0;
    int len;
    RSA *pKey = NULL;
    char *pKeyText = NULL;

    ASSERT(pKeyFileName, "Key filename is NULL");
    pKeyText = FileLoadTxt(pKeyFileName);
    if (!pKeyText)
        goto error;

    if (LoadPemKey(pKeyText, &pKey, keyType))
        goto error;

    // Write the public key modulus
    ASSERT(sizeof(pManifest->u.publicKeyModulus) == BN_num_bytes(pKey->n),
            "ERROR: The public key modulus size doesn't match the manifest. "
            "key:%d manifest:%lu\n", BN_num_bytes(pKey->n),
            sizeof(pManifest->u.publicKeyModulus));
    len = BN_bn2bin(pKey->n, pManifest->u.publicKeyModulus);
    ASSERT(sizeof(pManifest->u.publicKeyModulus) == len, "Public key modulus "
           "wasn't completely copied. Key:%lu BytesCopied:%d\n", 
           sizeof(pManifest->u.publicKeyModulus), len);
    SwapEndianness((char*)pManifest->u.publicKeyModulus, sizeof(pManifest->u.publicKeyModulus));

    // Write the public key exponent
    // The publicKeyExponent is 3 bytes for a 2048 bit key.
    ASSERT(sizeof(pManifest->u.publicKeyExponent)-1 == BN_num_bytes(pKey->e),
            "ERROR: The public key exponent size doesn't match the manifest. "
            "key:%d manifest:%lu\n", BN_num_bytes(pKey->e),
            sizeof(pManifest->u.publicKeyExponent)-1);
    len = BN_bn2bin(pKey->e, pManifest->u.publicKeyExponent);
    ASSERT(sizeof(pManifest->u.publicKeyExponent)-1 == len,
            "Public key exponent wasn't completely copied. Key:%lu BytesCopied:%d\n", 
           sizeof(pManifest->u.publicKeyExponent), len);
    SwapEndianness((char*)pManifest->u.publicKeyExponent, sizeof(pManifest->u.publicKeyExponent));
    goto exit;

error:
    ret = 1;
exit:
    if (pKeyText)
        free(pKeyText);
    if (pKey)
        DestroyPemKey(pKey);
    return ret;
}

int LoadPemKey(const char *pKeyString, RSA **ppKey, key_type_t type)
{
    int ret = 0;
    BIO *pBuf = NULL;

    ASSERT(pKeyString != NULL, "Key string is NULL\n");

    *ppKey = RSA_new();

    pBuf = BIO_new_mem_buf((void*)pKeyString, strlen(pKeyString));
    if (!pBuf)
    {
        ERR("Failed creating the memory Buffer\n");
        ERR_print_errors_fp(GetLogFilePointer());
        ret = 1;
        goto exit;
    }

    if (type == PrivateKey)
    {
        if(PEM_read_bio_RSAPrivateKey(pBuf, ppKey, NULL, NULL) == NULL)
        {
            ERR("The Private key is not in PEM format\n");
            ERR("Key:%s:\n", pKeyString);
            ERR_print_errors_fp(GetLogFilePointer());
            ret = 1;
            goto exit;
        }
    }
    else
    {
        // Looking for a PKCS#8 file format. 
        // NOTE: The keyword used here could be other formats and won't protect
        //       against using those key formats. However, subsequent checks
        //       should catch it.
        if (strstr(pKeyString, "BEGIN PUBLIC KEY"))
        {
            EVP_PKEY *pKey = NULL;
            if (PEM_read_bio_PUBKEY(pBuf, &pKey, NULL, NULL) == NULL)
            {
                ERR("The Public key is not in EVP format\n");
                ERR("Key:%s:\n", pKeyString);
                ERR_print_errors_fp(GetLogFilePointer());
                ret = 1;
                goto exit;
            }

            ASSERT(EVP_PKEY_type(pKey->type)== EVP_PKEY_RSA, 
                   "The passed in public key is not an RSA key\n");

            // Get the RSA key from the EVP key.
            *ppKey = EVP_PKEY_get1_RSA(pKey);

            EVP_PKEY_free(pKey);
        } 
        // Looking for RSA PEM formatted key: PKCS#1
        else if (strstr(pKeyString, "BEGIN RSA PUBLIC KEY")) 
        {
            if (PEM_read_bio_RSAPublicKey(pBuf, ppKey, NULL, NULL) == NULL)
            {
                ERR("The Public key is not in PEM format\n");
                ERR("Key:%s:\n", pKeyString);
                ERR_print_errors_fp(stdout);
                ret = 1;
                goto exit;
            }
        }
    }

    INFO("Successfully loaded the %s key.\n", type == PrivateKey ? "Private" : "Public");


exit:
    if (pBuf)
        BIO_free(pBuf);
    return ret;
}

void DestroyPemKey(RSA *pKey)
{
    // RSA_free zeroes the key to destroy the key in memory.
    RSA_free(pKey);
}

int GenerateSignature(char *pPrivateKeyFileName, os_signed_t *pSigned, uchar pManifestSignature[256])
{
    int ret = 0;
    uchar *pSignature = pManifestSignature;
    unsigned int signatureSize;
    uchar pOsManifestHash[32];
    RSA *pPrivateKey = NULL;
    char *pPrivateKeyText = NULL;

    ASSERT(pSigned, "The pSigned is null\n");

    if (!pPrivateKeyFileName)
    {
        ERR("Private key filename is NULL");
        goto error;
    }

    pPrivateKeyText = FileLoadTxt(pPrivateKeyFileName);
    if (!pPrivateKeyText)
        goto error;

    if (LoadPemKey(pPrivateKeyText, &pPrivateKey, PrivateKey))
        goto error;

    // Create the hash of the signed portion of the manifest
    SHA256((const uchar*)pSigned, sizeof(os_signed_t), pOsManifestHash);

    ASSERT(struct_member_size(os_unsigned_t, manifestSignature) == RSA_size(pPrivateKey), 
           "Sizes are different. RSA_size(rsa)=%d sigSize:%d\n", 
           RSA_size(pPrivateKey), signatureSize);

    // Sign the hash with the private key
    ASSERT(pSignature, "Malloc failure.\n");
    if(!RSA_sign(NID_sha256, pOsManifestHash, sizeof(pOsManifestHash), pSignature, 
             &signatureSize, pPrivateKey))
    {
        ERR("The sign has failed in RSA_sign.\n");
        goto error;
    }

    // Ensure the signature size wasn't changed.
    ASSERT(signatureSize == RSA_size(pPrivateKey), "Sizes are different. "
           "RSA_size(rsa)=%d sigSize:%d\n", RSA_size(pPrivateKey), signatureSize);

    // Verify the signature passes. This should never fail.
    if(!RSA_verify(NID_sha256, pOsManifestHash, sizeof(pOsManifestHash), pSignature,
                signatureSize, pPrivateKey))
    {
        ERR("The verification of the sign has failed in RSA_verify.\n");
        goto error;
    }

    goto exit;

error:
    ret = 1;
exit:
    if (pPrivateKey)
        DestroyPemKey(pPrivateKey);
    if (pPrivateKeyText)
        free(pPrivateKeyText);
    return ret;
}

int JoinManifest(uchar *pSignature, char *pKeyFileName, key_type_t keyType, 
                 os_signed_t *pUnsignedManifest, manifest_output_t **ppManifest)
{
    int ret = 0;
    RSA *pPublicKey = NULL;
    char *pPublicKeyText = NULL;
    manifest_output_t *pManifest = NULL;

    ASSERT(pSignature, "JoinManifest: The pSignature is NULL\n");
    ASSERT(pKeyFileName, "JoinManifest: Key filename is NULL");
    ASSERT(pUnsignedManifest, "JoinManifest: Unsigned manifest is NULL");
    ASSERT(ppManifest, "JoinManifest: Output manifest is NULL");

    pManifest = calloc(1, sizeof(manifest_output_t));
    pManifest->s = *pUnsignedManifest;

    SwapEndianness((char*)pSignature, struct_member_size(os_unsigned_t, manifestSignature));
    memcpy(&pManifest->u.manifestSignature, pSignature, struct_member_size(os_unsigned_t, manifestSignature));
    if (WriteKeyMantissaExponent(pKeyFileName, pManifest, keyType))
        goto error;

    goto exit;

error:
    ret = 1;
    if (pManifest)
        free(pManifest);
    pManifest = NULL;
exit:
    if (pPublicKey)
        DestroyPemKey(pPublicKey);
    if (pPublicKeyText)
        free(pPublicKeyText);
    if (pManifest)
        *ppManifest = pManifest;
    return ret;
}

int VerifyManifestSignature(manifest_output_t *pManifest)
{
    int ret = 0;
    RSA *pPublicKey = RSA_new();
    uchar pOsManifestHash[struct_member_size(os_signed_t, osImageHash)];
    char pModulus[struct_member_size(os_unsigned_t, publicKeyModulus)];
    char pExponent[struct_member_size(os_unsigned_t, publicKeyExponent)];
    uchar pSig[struct_member_size(os_unsigned_t, manifestSignature)];

    // Generate the hash of the signed portion of the manifest
    SHA256((const uchar*)&(pManifest->s), sizeof(pManifest->s), pOsManifestHash);

    // Load the public key modulus into the RSA BigNumber (bn)
    memcpy(pModulus, pManifest->u.publicKeyModulus, sizeof(pManifest->u.publicKeyModulus));
    SwapEndianness((char*)pModulus, sizeof(pModulus));
    pPublicKey->n = BN_bin2bn((const uchar*)pModulus, sizeof(pModulus), pPublicKey->n);
    if (pPublicKey->n == NULL)
    {
        ERR("Failed attempting to load the public key modulus.\n");
        goto error;
    }

    // Load the public key exponent into the RSA BigNumber (bn)
    // Remember that the exponent is 3 bytes, but we store 4.
    memcpy(pExponent, pManifest->u.publicKeyExponent, sizeof(pManifest->u.publicKeyExponent));
    SwapEndianness((char*)pExponent, sizeof(pExponent));
    pPublicKey->e = BN_bin2bn((const uchar*)pExponent, sizeof(pExponent)-1, pPublicKey->e);
    if (pPublicKey->e == NULL)
    {
        ERR("Failed attempting to load the public key exponent.\n");
        goto error;
    }

    // Load the signature and verify it
    memcpy(pSig, pManifest->u.manifestSignature, sizeof(pManifest->u.manifestSignature));
    SwapEndianness((char*)pSig, sizeof(pSig));
    if(!RSA_verify(NID_sha256, pOsManifestHash, sizeof(pOsManifestHash), pSig, sizeof(pSig), pPublicKey))
    {
        ERR("RSA_verify failed to verify the signature\n");
        goto error;
    }

    INFO("Signature verified.\n");

    goto exit;
error:
    ret = 1;
exit:
    return ret;
}

int VerifyManifestImageHash(manifest_output_t *pManifest, char *pImageFileName)
{
    int ret = 0;
    uchar pImageHash[struct_member_size(os_signed_t, osImageHash)];
    int len = sizeof(pImageHash);

    if (GenerateHashOfImage(pImageFileName, pImageHash, len))
        goto error;

    // Check the generated hash against the manifest hash.
    if (memcmp((char*)pImageHash, (char*)pManifest->s.osImageHash, len) != 0)
    {
        char *pManifestHashStr = Bin2HexStr(pManifest->s.osImageHash, len);
        char *pImageHashStr = Bin2HexStr(pImageHash, len);
        ERR("The manifest and image do not match.\n"
            "Manifest hash:%s\n"
            "   Image hash:%s\n", pManifestHashStr, pImageHashStr);
        free(pManifestHashStr);
        free(pImageHashStr);
        goto error;
    }

    INFO("Image matches manifest\n");
    goto exit;
error:
    ret = 1;
exit:
    return ret;
}

static int GenerateHashOfImage(char *pFileName, uchar *pHash, int len)
{
    int ret = 0;
    uchar *pImage = NULL;
    int imageSize = 0;

    if (len != SHA256_DIGEST_LENGTH)
    {
        ERR("Failed to generate hash of image as the size (%d) is not equal to "
            "the sha length needed (%d).\n", len, SHA256_DIGEST_LENGTH);
        goto error;
    }

    if (!FileExists(pFileName))
    {
        ERR("Failed to generate hash of image as the file doesn't exist. File:%s\n", pFileName);
        goto error;
    }

    pImage = FileLoadBin(pFileName);
    if (!pImage)
    {
        ERR("Failed verify image. Could not load the file. File:%s\n", pFileName);
        goto error;
    }

    imageSize = FileSize(pFileName);

    SHA256((const uchar*)pImage, imageSize, pHash);
    goto exit;

error:
    ret = 1;
exit:
    if (pImage)
        free(pImage);
    return ret;
}

