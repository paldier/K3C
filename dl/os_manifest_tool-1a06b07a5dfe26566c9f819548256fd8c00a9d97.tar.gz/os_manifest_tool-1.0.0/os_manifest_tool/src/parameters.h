/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __PARAMETERS_H__
#define __PARAMETERS_H__

#include <stdbool.h>

typedef enum 
{
    CommandStep1,
    CommandStep2,
    CommandStep3,
    CommandFull,
    CommandDecode,
} command_t;

int GetCommand(void);
char* GetManifestFile(void);
char* GetUnsignedManifestFile(void);
char* GetDecodeFile(void);
char* GetImageInputFile(void);
int GetImageType(void);
char* GetOemDataFile(void);
char* GetPrivateKeyFile(void);
char* GetPublicKeyFile(void);
int GetPublicKeyIndex(void);
int GetSecureVersion(void);
char* GetSignatureFile(void);

bool IsDecodeSet(void);
bool IsCreateUnsignedManifestSet(void);

void ResetGlobals(void);
int ParseParameters(int argc, char *argv[]);
int VerifyParameters(void);

#endif
