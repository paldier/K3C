/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "log.h"

static loglevel_t gLogLevel = LOG_LEVEL_NORMAL;
static FILE *gpStreamFile = NULL;

loglevel_t GetLogLevel(void)
{
    return gLogLevel;
}

void SetLogLevel(loglevel_t level)
{
    if (level < LOG_LEVEL_MIN || level > LOG_LEVEL_MAX)
        ERR("Level is not valid. level:%d\n", level);
    else
        gLogLevel = level;
}

void SetLogFilePointer(FILE *pStreamFile)
{
    gpStreamFile = pStreamFile;
}

FILE* GetLogFilePointer(void)
{
    if (gpStreamFile)
        return gpStreamFile;
    return stdout;
}
