/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "manifest.h"
#include "log.h"
#include "utilities.h"

#include <ctype.h>
#include <string.h>

void PrintOemData(manifest_output_t *pManifest);
void PrintBinaryLine(char *pLine, int index, int len);

void SwapEndianness(char *pString, int length)
{
    int i;
    ASSERT((length % 4) == 0, "SwapEndianness only works on strings that are "
           "divisible by 4. Len:%d Len%%4:%d\n", length, (length % 4));

    for (i = 0; i <= length-4; i += 4)
    {
        char pSwapped[4];
        pSwapped[0] = pString[i+3];
        pSwapped[1] = pString[i+2];
        pSwapped[2] = pString[i+1];
        pSwapped[3] = pString[i+0];
        memcpy(&pString[i], pSwapped, 4);
    }
}

manifest_input_t* CreateInputStruct(void)
{
    // It is important the structure is zero'd to allow optional arguments.
    manifest_input_t *pInput =  calloc(1, sizeof(manifest_input_t));
    ASSERT(pInput, "calloc failed.\n");
    pInput->version = INPUT_VERSION;
    return pInput;
}

void DestroyInputStruct(manifest_input_t *pInput)
{
    if (pInput)
        free(pInput);
}

char* GetManifestTypeString(int type)
{
    char *pRet = NULL;
    switch (type)
    {
        case  0: pRet = "App CPU Kernel";                   break;
        case  1: pRet = "App CPU Root Filesystem";          break;
        case  2: pRet = "App CPU Video Gateway Filesystem"; break;
        case  3: pRet = "NP CPU Kernel";                    break;
        case  4: pRet = "NP CPU Root Filesystem";           break;
        case  5: pRet = "NP CPU Gateway Filesystem";        break;
        case  6: pRet = "Media CPU Kernel";                 break;
        case  7: pRet = "Media CPU Root Filesystem";        break;
        case  8: pRet = "BIOS Stage 1";                     break;
        case  9: pRet = "Reserved 9";                       break;
        case 10: pRet = "BBU Controller Firmware";          break;
        case 11: pRet = "BBU Controller Configuration";     break;
        case 12: pRet = "Reserved 12";                      break;
        case 13: pRet = "Reserved 13";                      break;
        case 14: pRet = "Reserved 14";                      break;
        case 15: pRet = "Reserved 15";                      break;
        default: pRet = "Unknown Value";
    }
    return pRet;
}

void PrintManifestTypes(void)
{
    int i;
    INFO("Available Types:\n");
    for (i = 0; i <= MAX_MANIFEST_TYPES; i++)
    {
        RAW_INFO("   %2d:%s\n", i, GetManifestTypeString(i));
    }
}

void PrintManifest(manifest_output_t *pManifest)
{
    char *pLine = NULL;

    if ((strncmp(pManifest->s.manifestIdentifier, MANIFEST_IDENTIFIER_V1, MANIFEST_IDENTIFIER_LEN) != 0)
    && (strncmp(pManifest->s.manifestIdentifier, MANIFEST_IDENTIFIER_V2, MANIFEST_IDENTIFIER_LEN) != 0))
    {
        ERR("Failed decoding manifest identifier. Attempting to decode an "
            "invalid manifest. Id:%s:\n", pManifest->s.manifestIdentifier);
        goto exit;
    }

    INFO("%23s:%s\n", "Manifest Identifier", pManifest->s.manifestIdentifier);
    INFO("%23s:0x%02X\n", "Internal Version", pManifest->s.manifestInternalVersion);
    INFO("%23s:0x%02X:%d\n", "Manifest Size", pManifest->s.manifestStructSize, 
         pManifest->s.manifestStructSize);
    INFO("%23s:0x%02X:%d\n", "Secure Version Num", pManifest->s.secureVersionNumber, 
         pManifest->s.secureVersionNumber);
    INFO("%23s:%d\n", "Public Key Hash Index", pManifest->s.publicKeyHashIndex);

    pLine = Bin2HexStr(pManifest->s.osImageHash, sizeof(pManifest->s.osImageHash));
    INFO("%23s:%s\n", "OS Image Hash", pLine);
    free(pLine);

    INFO("%23s:%d:%s\n", "OS Manifest Type", pManifest->s.osManifestType, 
         GetManifestTypeString(pManifest->s.osManifestType));
    PrintOemData(pManifest);

    pLine = Bin2HexStr(pManifest->u.publicKeyModulus, sizeof(pManifest->u.publicKeyModulus));
    INFO("%23s:%s\n", "Public Key Modulus", pLine);
    free(pLine);

    pLine = Bin2HexStr(pManifest->u.publicKeyExponent, sizeof(pManifest->u.publicKeyExponent));
    INFO("%23s:%s\n", "Public Key Exponent", pLine);
    free(pLine);

    pLine = Bin2HexStr(pManifest->u.manifestSignature, sizeof(pManifest->u.manifestSignature));
    INFO("%23s:%s\n", "Manifest Signature", pLine);
    free(pLine);

exit:
    return;
}

void PrintOemData(manifest_output_t *pManifest)
{
    int i;
    int isAllZeroes = 1;
    INFO("%23s:", "OEM Data");

    for (i = 0; i < sizeof(pManifest->s.oemData); i++)
    {
        if (pManifest->s.oemData[i])
        {
            isAllZeroes = 0;
            break;
        }
    }

    if (isAllZeroes)
    {
        RAW_INFO(" All zeroes.\n");
    }
    else
    {
        int bytes = (int)sizeof(pManifest->s.oemData);
        RAW_INFO("\n");
        for (i = 0; i < bytes; i += 16)
        {
            if (i + 16 > bytes)
                PrintBinaryLine(pManifest->s.oemData, i, bytes-i);
            else
                PrintBinaryLine(pManifest->s.oemData, i, 16);
        }
        RAW_INFO("\n");
    }
}

void PrintBinaryLine(char *pLine, int index, int len)
{
    int i;
    int col = 0;
    int j;
    for (i = index; i < index+len; i++)
    {
        col++;
        if (col == 1) RAW_INFO("   %03X - ", i);
        RAW_INFO("%02x ", (uchar)pLine[i]);
        if (col == 8) RAW_INFO(" ");
        if (col == 16) 
        { 
            RAW_INFO(" |");
            for (j = index; j < index+len; j++)
            {
                char c = pLine[j];
                RAW_INFO("%c", isprint(c) ? c : '.');
            }
            RAW_INFO("|\n");
        }
    }
}

// Note: The return string must be freed.
char* Bin2HexStr(void *pBufferVoid, int bufferSize)
{
    int i;
    // Convert each byte to two characters. Add one for the NULL terminator.
    char *pStr = malloc(bufferSize*2+1);
    ASSERT(pStr, "malloc failure.\n");
    uchar *pBuffer = pBufferVoid;
    pStr[bufferSize] = 0;

    for (i = 0; i < bufferSize; i++)
    {
        sprintf(&pStr[i*2], "%02X", pBuffer[i]);
    }

    return pStr;
}

int IsStrEqual(char *pStr1, char *pStr2)
{
    return (strcmp(pStr1, pStr2) == 0);
}
