/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __MANIFEST_H__
#define __MANIFEST_H__

#include <stdlib.h>

// Manfiest version
#define INPUT_VERSION 0xAA
#define MAX_SECURE_VERSION  255
#define MAX_PUBLIC_KEY_INDEX 9

#define MANIFEST_IDENTIFIER_V1 "$OSM"
#define MANIFEST_IDENTIFIER_V2 "$KFM"
#define MANIFEST_IDENTIFIER_LEN (struct_member_size(os_signed_t, manifestIdentifier))
#define MANIFEST_INTERNAL_VERSION 0x11

#define MANIFEST_FILE_EXTENSION ".osmanifest"
#define UNSIGNED_MANIFEST_FILE_EXTENSION ".unsignedmanifest"
#define SIGNATURE_FILE_EXTENSION ".signature"

typedef unsigned int uint;
typedef unsigned char uchar;

typedef struct
{
    int version;
    uchar *pImage;
    uint imageSize;
    uint secureVersionNumber;
    uint publicKeyHashIndex;
    uint osManifestType;
    char oemData[392];
}manifest_input_t;

typedef struct
{
    char manifestIdentifier[4];
    uint manifestInternalVersion;
    uint manifestStructSize;
    uint secureVersionNumber;
    uint publicKeyHashIndex;
    uchar osImageHash[32];
    char reserved1[36];
    uint osManifestType;
    uint osImageSize;
    char oemData[392];
    char reserved2[20];
}os_signed_t;

typedef struct
{
    uchar publicKeyModulus[256];
    uchar publicKeyExponent[4];
    uchar manifestSignature[256];
}os_unsigned_t;

typedef struct
{
    os_signed_t   s;
    os_unsigned_t u;
}manifest_output_t;

typedef enum
{
    PrivateKey,
    PublicKey,
}key_type_t;

int GenerateUnsignedManifest(manifest_input_t *pInput, os_signed_t **ppUnsignedManifest);
int GenerateSignature(char *pPrivateKeyFileName, os_signed_t *pSigned, uchar pManifestSignature[256]);
int VerifyManifestSignature(manifest_output_t *pManifest);
int VerifyManifestImageHash(manifest_output_t *pManifest, char *pImageFileName);
int JoinManifest(uchar *pSignature, char *pKeyFileName, key_type_t keyType, os_signed_t *pUnsignedManifest, manifest_output_t **ppManifest);

#endif
