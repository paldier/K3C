/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

//*****************************************************************************
//  Includes
//*****************************************************************************
#include <assert.h>
#include <stdio.h>
#include <ctest.h>
#include <string.h>

//*****************************************************************************
//  Global Declaration
//*****************************************************************************
// Determines if a test was run or not for validating the framework.
int g_was_run = 0;

//*****************************************************************************
//  Function Declarations
//*****************************************************************************
void test_string(void)
{
    assert_string_eq("Hello", "Hello");
    assert_string_eq_c(NULL, NULL);
    //assert_string_eq_nf("Hello", NULL);
    //assert_string_eq_nf(NULL, "Hello");
    //assert_string_eq_nf("One", "Two");
    assert_substr("Big String", "g Str");
    assert_substr("Big String", NULL);
    assert_no_substr("Big String", "Big Bird");
}

// Validate the assert equal float macro/function.
void test_float(void)
{
    assert_equal_f(0.1, 0.2, 0.1);
    assert_equal_f(0.1, 0, 0.1);
    assert_equal_f(0.1, 0.1, 0.1);
    assert_equal_f(0.1, 0.1, 0);
}

typedef enum
{
    TEST_ENUM_VAL_1 = 0x1,
    TEST_ENUM_VAL_2 = 0x2,
    TEST_ENUM_VAL_3 = 0x4,
}testEnum;

void test_flag_set(void)
{
    assert_flag_set(TEST_ENUM_VAL_1, TEST_ENUM_VAL_1);
    assert_flag_set(TEST_ENUM_VAL_1 | TEST_ENUM_VAL_2, TEST_ENUM_VAL_2);
}

void test_flag_unset(void)
{
    assert_flag_unset(TEST_ENUM_VAL_1, TEST_ENUM_VAL_2);
    assert_flag_unset(TEST_ENUM_VAL_1 | TEST_ENUM_VAL_2, TEST_ENUM_VAL_3);
}

void test_was_run(void)
{
    g_was_run++;
    assert_true(g_was_run == 1);
}

void test_simple_pass(void)
{
    g_was_run++;
    assert_true_c(g_was_run == 2);
}

// Mock function for the function: "inc". It expects a value and has a return.
int inc(int val)
{
    // Verify the parameter.
    check_expected(val);
    // Retrieve the return value.
    return mock();
}

// Helper function to setup the expectations and return values.
void inc_expect(int val, int ret)
{
    expect_value(inc, val);
    will_return_value(inc, ret);
}

void test_mock_val(void)
{
    inc_expect(2, 3);
    inc_expect(4, 5);
    inc_expect(120, 55);
    assert_true_c(inc(2) == 3);
    assert_true_c(inc(4) == 5);
    assert_true_c(inc(120) == 55);
}

void test_mock_many_iterations(void)
{
    int i, num = 100;
    for(i = 0; i < num; i++)
    {
        inc_expect(i, i+1);
    }
    for(i = 0; i < num; i++)
    {
        assert_equal(inc(i), i+1);
    }
}

// Mock function for the function: "mock_str". It expects a value and has a return.
const char* mock_str(char* str)
{
    // Verify the parameter.
    check_expected(str);
    // Retrieve the return value.
    return (const char*)mock();
}

// Helper function to setup the expectations and return values.
void mock_str_expect(const char* str, const char* ret)
{
    expect_string(mock_str, str);
    will_return_string(mock_str, ret);
}

void test_mock_str(void)
{
    mock_str_expect("Are we there yet?", "Yep!");
    assert_string_eq(mock_str("Are we there yet?"), "Yep!");
}

// Mock function for the function: "mock_str_int". 
// It expects a string and values and has a return.
int mock_str_int(char *str, int *val)
{
    check_expected(str);
    *val = (int)mock();
    return (int)mock();
}

// Helper function to setup the expectations and return values.
void mock_str_int_expect(char *str, int val, int ret)
{
    expect_string(mock_str_int, str);
    will_return_value(mock_str_int, val);
    will_return_value(mock_str_int, ret);
}

void test_mock_dual_returns(void)
{
    int val;
    mock_str_int_expect("MyString1", 5, 10);
    mock_str_int_expect("MyString2", 6, 20);
    mock_str_int_expect("MyString3", 7, 30);
    assert_equal(mock_str_int("MyString1", &val), 10);
    assert_equal(val, 5);
    assert_equal(mock_str_int("MyString2", &val), 20);
    assert_equal(val, 6);
    assert_equal(mock_str_int("MyString3", &val), 30);
    assert_equal(val, 7);
}

int main(int argc, char *argv[])
{
    int failed;
    test_run_t   *pTestRun   = test_run_create();
    test_suite_t *pTestSuite1 = test_suite_create("Main1");
    test_suite_t *pTestSuite2 = test_suite_create("Main2");

    test_set_debug(false);

    test_suite_add_test(pTestSuite2, test_mock_dual_returns);
    test_suite_add_test(pTestSuite2, test_mock_str);
    test_suite_add_test(pTestSuite2, test_string);
    test_suite_add_test(pTestSuite2, test_mock_val);
    test_suite_add_test(pTestSuite2, test_mock_many_iterations);

    test_suite_add_test(pTestSuite1, test_was_run);
    test_suite_add_test(pTestSuite1, test_simple_pass);
    test_suite_add_test(pTestSuite1, test_float);
    test_suite_add_test(pTestSuite1, test_flag_set);
    test_suite_add_test(pTestSuite1, test_flag_unset);

    test_run_add_suite(pTestRun, pTestSuite1);
    test_run_add_suite(pTestRun, pTestSuite2);
    if(argc == 1)
    {
        failed = test_run_execute(pTestRun, LOG_STYLE_PRINT_ERROR);
    }
    else
    {
        failed = test_run_execute(pTestRun, LOG_STYLE_VERBOSE);
    }

    assert(g_was_run == 2);

    test_run_destroy(pTestRun);

    return failed;
}
