/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __CTEST_LOGGER_H__
#define __CTEST_LOGGER_H__

// Types of logging
typedef enum
{
    LOG_STYLE_NONE,
    LOG_STYLE_VERBOSE,
    LOG_STYLE_SUMMARY,
    LOG_STYLE_QUIET,
    LOG_STYLE_PRINT_ERROR,
}log_style_t;

#endif //__CTEST_LOGGER_H__
