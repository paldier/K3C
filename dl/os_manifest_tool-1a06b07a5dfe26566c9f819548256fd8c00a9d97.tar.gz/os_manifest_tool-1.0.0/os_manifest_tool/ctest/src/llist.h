/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

/**
    llist.h

    This module contains the prototypes and structures of the
    linked list.
*/

#ifndef _LINKED_LIST_H_
#define _LINKED_LIST_H_

// Add the additional debug information
#define DEBUG 1

// *****************************************************************************
//  Includes
// *****************************************************************************

#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>

// *****************************************************************************
//  Macro definitions
// *****************************************************************************
#define LL_CREATE_ENTRY(type, ll_entry, data) \
    if (!t_ll_create_entry(sizeof(type),                    \
                         ll_entry,                        \
                         (uint8_t**)data,                 \
                         #type))                          \
    {                                                     \
        error("Failed creating entry.");                  \
        ret = false;                                      \
        goto exit;                                        \
    }

#define LL_ADD_TO_BACK(list, entry)                              \
    if (!t_ll_add_entry_to_back(list, entry))                      \
    {                                                            \
        error("Failed adding entry to the back of the list.");   \
        if (!t_ll_delete_entry(entry))                             \
        {                                                        \
            error("Failed deleting entry.");                     \
        }                                                        \
        ret = false;                                             \
        goto exit;                                               \
    }


#define CREATE_ADD_ENTRY(list, ptr, type)                                    \
{                                                                            \
    list_entry_t *ll_entry = NULL;                                           \
    assert(t_ll_create_entry(sizeof(type), &ll_entry,                        \
                           (uint8_t**)&ptr, #type) == true);                 \
    assert(t_ll_add_entry_to_back(&(list), ll_entry));                       \
}

#define error(...) printf(__VA_ARGS__);
#define bug(...) printf(__VA_ARGS__);

// *****************************************************************************
//  Structures and types
// *****************************************************************************

//-----------------------------------------------------------------------------
/**
    Linked list entry structure. The entry has a self managed data pointer
    that stores the entry information.
*/
struct linked_list_t;
struct linked_list_entry_s
{
    uint8_t                    *data; // List managed malloced memory pointer.
    struct linked_list_entry_s *next; // Next entry pointer.
    struct linked_list_t       *list; // List pointer to assist in deleting
                                      // an entry.
    unsigned int       type_checksum; // Ensures the correct type is used.
    #if DEBUG
    char               type[256];     // Debug for helping to determine issues.
    #endif
};
typedef struct linked_list_entry_s list_entry_t;

//-----------------------------------------------------------------------------
/**
    Singlely linked list entry structure.
*/
typedef struct
{
    intptr_t      magic_num; // Keeps track if this list is initialized.
    unsigned int  type_checksum; // Ensures the correct type is used.
    int           size;      // Quickly determines the size of the list and
                             // also helps maintain integrity of the list.
    list_entry_t *head;      // The first list entry.
    #if DEBUG
    char          type[256]; // Debug for helping to determine issues.
    #endif
}linked_list_t;

// *****************************************************************************
//  Function prototypes
// *****************************************************************************

// Macro that allows the list to be iterated across.
#define FOREACH(entry, list_ptr, type)                                   \
    if(!t_ll_verify_list_type(list_ptr, type))                             \
    {                                                                    \
        error("The list types don't match.%s","");                       \
    }                                                                    \
    for(entry = (list_ptr)->head; entry != NULL; entry = entry->next)

/**
    Initializes the linked list, setting all of the internal values including
    the magic number to indicate the list has been initialized.
*/
bool t_ll_init(linked_list_t *list, const char *type);

/**
    Indicates if the linked list has been initialized.
*/
bool t_ll_is_initialized(linked_list_t *list);

/**
    Indicates if the linked list has the specified type.
*/
bool t_ll_verify_list_type(linked_list_t *list, const char* type);

/**
    Deletes each of the individual entries.
*/
bool t_ll_delete_list(linked_list_t *list);

/**
    Returns the number of entries in the list.
*/
int t_ll_size(linked_list_t *list);

/**
    Returns the data pointer at the specfied entry. The index is
    zero based similar to an array.
*/
bool t_ll_entry_at(linked_list_t        *list, 
                 int                   index, 
                 uint8_t             **entry_data);

/**
    Deletes an entry at a specified location. The index is zero
    based similar to an array.
*/
bool t_ll_delete_entry_at(linked_list_t        *list, 
                        unsigned int          index);

/**
    Deletes an entry.
    
    Note: If the entry is stored within a list, it will be
          removed from the list before being deleted.
*/
bool t_ll_delete_entry(list_entry_t *delete_entry, bool free_data_ptr);

/**
    Creates an entry. Also creates a storage area to store the
    information within the entry. Note: If the entry is stored
*/
bool t_ll_create_entry(int             size_in_bytes, 
                     list_entry_t  **entry,
                     uint8_t       **data,
                     const char     *type);

/**
    Adds an entry to the front of the list.
*/
bool t_ll_add_entry_to_front(linked_list_t *list,
                           list_entry_t  *entry);
/**
    Adds an entry to the back of the list.
*/
bool t_ll_add_entry_to_back(linked_list_t  *list,
                          list_entry_t   *entry);

/**
    Copy the source list to the destination list.
*/
bool t_ll_copy_list(linked_list_t *src_list,
                  linked_list_t *dst_list,
                  uint32_t       size_of_stored);

//-----------------------------------------------------------------------------
/**
    Determines if the list is corrupted or valid.

    This function primarily is used within the linked list module.
*/
bool t_ll_verify_integrity(linked_list_t *list);

#endif
