/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __CTEST_INTERNAL_H__
#define __CTEST_INTERNAL_H__

//-----------------------------------------------------------------------------
//  Includes
//-----------------------------------------------------------------------------
#include "llist.h"
#include <stdbool.h>
#include <ctest_runner.h>

//-----------------------------------------------------------------------------
//  Type definition
//-----------------------------------------------------------------------------

typedef struct
{
    const char   *test_name;
    TestFunction  test_func;
}unit_test_t;

typedef struct test_run_t
{
    linked_list_t test_suite_list;
    int passed;
    int failed;
} test_run_t;

typedef struct test_suite_t
{
    linked_list_t tests;
    const char   *suite_name;
    int passed;
    int failed;
    SetupFunction setup;
    TearDownFunction teardown;
} test_suite_t; 

// Determines if debug is turned on.
bool test_get_debug(void);

// Determines if a test is currently in progress.
bool is_test_running(void);

// Terminates the current test.
void terminate_test(void);

// Fails the current test.
void fail_and_finish_test(bool fail_early);

// Determines if the test has failed.
bool has_test_failed(void);

// Indicate that the test has failed.
void set_test_has_failed(void);

// Verifies that all of the mock items have been requested.
bool check_mock_for_remaining_items(void);

// Verifies the passed in values based on the type.
bool assert_generic(intptr_t      actual,
                    intptr_t      expected,
                    expect_type_t type,
                    bool          fail,
                    const char*   function,
                    const char*   file,
                    int           line);

// Prints the type based on expect_type_t
void print_type(intptr_t value, expect_type_t type);

// Returns true if the two strings are equal. Handles NULL pointers.
bool strings_equal(const char *p1, const char *p2);

#endif // __CTEST_INTERNAL_H__
