/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

//*****************************************************************************
//  Includes
//*****************************************************************************
#include "logger.h"
#include <string.h>

//*****************************************************************************
//  Macro Declarations
//*****************************************************************************
#define MIN(a,b) ((a) < (b) ? (a) : (b))

//*****************************************************************************
//  Global Declarations
//*****************************************************************************
static int g_test_count = 0;

//*****************************************************************************
//  Logger Functions
//*****************************************************************************
void summary_run_start(test_run_t *run)
{
}

void summary_run_finished(test_run_t *run, long long usecs)
{
    printf("\n");
    printf("%s - Pass:%d Failed:%d Time:", 
           run->failed > 0 ? "FAIL" : "OK", run->passed, run->failed);
    log_print_usecs(usecs);
    printf("\n");
}

void summary_suite_start(test_suite_t *suite)
{
    printf("%s ", suite->suite_name);
    g_test_count = 0;
}

void summary_suite_finished(test_suite_t *suite)
{
    printf("\n");
}

void summary_test_start(test_suite_t *suite, unit_test_t *test)
{
    g_test_count++;
}

// Prints '!' for failed tests.
// Prints '.' for passed tests.
void summary_test_finished(test_suite_t *suite, unit_test_t *test)
{
    if(has_test_failed())
    {
        printf("!");
    }
    else
    {
        printf(".");
    }
    if(g_test_count >= 16)
    {
        // Add a string the same length as the suite name+1 to line up the dots
        char str[80];
        memset(str, ' ', sizeof(str));
        str[MIN(sizeof(str)-1, strlen(suite->suite_name)+1)] = 0;
        printf("\n%s", str);
        g_test_count = 0;
    }
}

void summary_assert_fail(const char* function,
                         const char* file,
                         int         line)
{
    if(test_get_debug())
    {
        printf("%s:%d: %s() - Test fail called.\n", file, line, function);
    }
}
void summary_assert_true(bool        failed,
                         const char* function, 
                         const char* file,   
                         int         line)
{
    if(test_get_debug() && failed)
    {
        printf("%s:%d: %s() FAILED assert_true.\n",  file, line, function);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() assert_true success.\n",  file, line, function);
    }
}

void summary_assert_string_eq(bool        failed,
                               const char *actual, 
                               const char *expected, 
                               const char* function, 
                               const char* file,   
                               int         line)
{
    if(test_get_debug() && failed)
    {
        printf("%s:%d: %s() FAILED assert_string_eq: '%s' != '%s'\n", 
               file, line, function, actual, expected);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() assert_string_eq success: '%s' == '%s'\n", 
               file, line, function, actual, expected);
    }
}

void summary_assert_substr(bool        failed,
                           const char *main, 
                           const char *substr, 
                           const char* function, 
                           const char* file,   
                           int         line)
{
    if(test_get_debug() && failed)
    {
        printf("%s:%d: %s() FAILED assert_substr: '%s' not in '%s'\n", 
               file, line, function, substr, main);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() assert_substr success: '%s' in '%s'\n", 
               file, line, function, substr, main);
    }
}

void summary_assert_no_substr(bool        failed,
                              const char *main, 
                              const char *substr, 
                              const char* function, 
                              const char* file,   
                              int         line)
{
    if(test_get_debug() && failed)
    {
        printf("%s:%d: %s() FAILED assert_no_substr: '%s' in '%s'\n", 
               file, line, function, substr, main);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() assert_no_substr success: '%s' not in '%s'\n", 
               file, line, function, substr, main);
    }
}

void summary_assert_equal_f(bool       failed,
                            double      actual, 
                            double      expected,
                            double      range,
                            const char* function, 
                            const char* file, 
                            int         line)
{
    if(test_get_debug() && failed)
    {
        printf("%s:%d: %s() FAILED: assert_equal_f '%f' + '%f' (%f) >= '%f' "
               "&& '%f' - '%f' (%f) <= '%f'\n", file, line, function, actual, 
               range, actual+range, expected, actual, range, actual-range, expected);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() success: assert_equal_f '%f' + '%f' (%f) >= '%f' "
               "&& '%f' - '%f' (%f) <= '%f'\n", file, line, function, actual, 
               range, actual+range, expected, actual, range, actual-range, expected);
    }
}

void summary_assert_equal_flag_set(bool       failed,
                                   intptr_t   actual, 
                                   intptr_t   expected,
                                   const char* flag_name,
                                   const char* function, 
                                   const char* file, 
                                   int         line)
{
    if(test_get_debug() && failed)
    {
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' doens't contain Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' contains Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
}

void summary_assert_equal_flag_unset(bool       failed,
                                     intptr_t   actual, 
                                     intptr_t   expected,
                                     const char* flag_name,
                                     const char* function, 
                                     const char* file, 
                                     int         line)
{
    if(test_get_debug() && failed)
    {
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' contains Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' doesn't contain Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
}

void summary_assert_equal(bool       failed,
                          intptr_t   actual, 
                          intptr_t   expected,
                          const char* function, 
                          const char* file, 
                          int         line)
{
    if(test_get_debug() && failed)
    {
        printf("%s:%d: %s() FAILED: assert_equal '%p' != '%p'\n", 
               file, line, function, (void*)actual,  (void*)expected);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() assert_equal success: '%p' == '%p'\n", 
               file, line, function, (void*)actual,  (void*)expected);
    }
}

void summary_mock_param_remaining(const char   *function,
                                  const char   *parameter,
                                  expect_type_t type,
                                  intptr_t      value)
{
    if(test_get_debug())
    {
        printf("Mock FAILURE: Item remaining: Func:%s() Param:%s Val:%p\n",
               function, parameter, (void*)value);
    }
}

void summary_mock_return_remaining(const char   *function,
                                   expect_type_t type,
                                   intptr_t      value)
{
    if(test_get_debug())
    {
        printf("Mock FAILURE: Item remaining: Func:%s() Return:%p\n",
               function, (void*)value);
    }
}

void summary_mock_check(bool          failed, 
                        intptr_t      actual,
                        intptr_t      expected,
                        const char*   function,
                        const char*   parameter,
                        expect_type_t type)
{
    if(test_get_debug() && failed)
    {
        printf("Mock: check_expected failed assert: Func:%s() Param:%s "
               "Expected Value:",function, parameter);
        print_type(expected, type);
        printf(" Actual:");
        print_type(actual, type);
        printf("\n");
    }
    else if(test_get_debug())
    {
        printf("Mock: check_expected passed assert: Func:%s() Param:%s "
               "Expected Value:",function, parameter);
        print_type(expected, type);
        printf(" Actual:");
        print_type(actual, type);
        printf("\n");
    }
}

void summary_mock_get_return(intptr_t      return_val,
                             const char*   function,
                             expect_type_t type)
{
    if(test_get_debug())
    {
        printf("Mock: return: Func:%s() Return Value:%p\n", 
               function, (void*)return_val);
    }
}

void summary_logger_init(logger_t* logger)
{
    logger->log_run_start         = summary_run_start;
    logger->log_run_finished      = summary_run_finished;
    logger->log_suite_start       = summary_suite_start;
    logger->log_suite_finished    = summary_suite_finished;
    logger->log_test_start        = summary_test_start;
    logger->log_test_finished     = summary_test_finished;
    logger->log_assert_fail       = summary_assert_fail;
    logger->log_assert_true       = summary_assert_true;
    logger->log_assert_string_eq  = summary_assert_string_eq;
    logger->log_assert_substr     = summary_assert_substr;
    logger->log_assert_no_substr  = summary_assert_no_substr;
    logger->log_assert_equal_f    = summary_assert_equal_f;
    logger->log_assert_equal_flag_set = summary_assert_equal_flag_set;
    logger->log_assert_equal_flag_unset = summary_assert_equal_flag_unset;
    logger->log_assert_equal      = summary_assert_equal;
    logger->log_mock_param_remaining = summary_mock_param_remaining;
    logger->log_mock_return_remaining= summary_mock_return_remaining;
    logger->log_mock_check        = summary_mock_check;
    logger->log_mock_get_return   = summary_mock_get_return;
}
