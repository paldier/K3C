/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

//-----------------------------------------------------------------------------
//  Includes
//-----------------------------------------------------------------------------
#include "ctest_internal.h"
#include "logger.h"

#include <stdbool.h>
#include <stdio.h>
#include <string.h>

//-----------------------------------------------------------------------------
//  Function Declarations
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//  Fails the test and if fail_early is set, it jumps back to the runner.
//-----------------------------------------------------------------------------
void fail_and_finish_test(bool fail_early)
{
    set_test_has_failed();
    if(is_test_running() && fail_early)
    {
        terminate_test();
    }
}

//-----------------------------------------------------------------------------
//  Compares two strings. Properly handles NULL pointer strings.
//-----------------------------------------------------------------------------
bool strings_equal(const char *p1, const char *p2)
{
    bool equal;
    if(p1 == NULL && p2 == NULL) equal = true;
    else if(p1 == NULL)          equal = false;
    else if(p2 == NULL)          equal = false;
    else if(strcmp(p1, p2) != 0) equal = false;
    else                         equal = true;

    return equal;
}

//-----------------------------------------------------------------------------
//  Test if substring is in main string. Properly handles NULL pointer strings.
//-----------------------------------------------------------------------------
bool string_contains(const char *pMain, const char *pSubStr)
{
    bool contains;
    if(pMain == NULL && pSubStr == NULL)    contains = true;
    else if(pMain == NULL)                  contains = false;
    else if(pSubStr == NULL)                contains = true;
    else if(strstr(pMain, pSubStr) == NULL) contains = false;
    else                                    contains = true;

    return contains;
}

//-----------------------------------------------------------------------------
//  Fails the test.
//-----------------------------------------------------------------------------
bool test_set_failed_(const char* function,
                      const char* file,
                      int         line,
                      bool        fail)
{
    log_assert_fail_(function, file, line);
    fail_and_finish_test(fail);
    return false;
}

//-----------------------------------------------------------------------------
//  Verifies the result evaluates to true.
//-----------------------------------------------------------------------------
bool assert_true_(int         result, 
                  bool        fail, 
                  const char* function, 
                  const char* file, 
                  int         line)
{
    bool failed = !result;

    log_assert_true_(failed, function, file, line);

    if(failed)
    {
        fail_and_finish_test(fail);
    }

    return !failed;
}

//-----------------------------------------------------------------------------
//  Verifies the two strings are equal.
//-----------------------------------------------------------------------------
bool assert_string_eq_(const char *actual, 
                       const char *expected, 
                       bool        fail, 
                       const char* function, 
                       const char* file, 
                       int         line)
{
    bool failed = !strings_equal(actual, expected);

    log_assert_string_eq_(failed, actual, expected, function, file, line);

    if(failed)
    {
        fail_and_finish_test(fail);
    }

    return !failed;
}

//-----------------------------------------------------------------------------
// Verifies that the substring is contained in the main string.
bool assert_substr_(const char *main, 
                    const char *substr, 
                    bool  fail, 
                    const char* function, 
                    const char* file, 
                    int         line)
{
    bool failed = !string_contains(main, substr);

    log_assert_substr_(failed, main, substr, function, file, line);

    if(failed)
    {
        fail_and_finish_test(fail);
    }

    return !failed;
}

// Verifies that the substring is contained in the main string.
bool assert_no_substr_(const char *main, 
                       const char *substr, 
                       bool  fail, 
                       const char* function, 
                       const char* file, 
                       int         line)
{
    bool failed = string_contains(main, substr);

    log_assert_no_substr_(failed, main, substr, function, file, line);

    if(failed)
    {
        fail_and_finish_test(fail);
    }

    return !failed;
}

// Verifies that the actual float is in the range of the expected value. 
// If fail is true, it terminates the test on failure.
bool assert_equal_f_(double      actual, 
                     double      expected,
                     double      range,
                     bool        fail, 
                     const char* function, 
                     const char* file, 
                     int         line)
{
    bool failed = !(actual + range >= expected && actual - range <= expected);

    log_assert_equal_f_(failed, actual, expected, range, function, file, line);

    if(failed)
    {
        fail_and_finish_test(fail);
    }

    return !failed;
}

//-----------------------------------------------------------------------------
//  Verifies the flag of expected is within the actual.
//-----------------------------------------------------------------------------
bool assert_equal_flag_set_(intptr_t   actual, 
                            intptr_t   expected,
                            const char* flag_name,
                            bool        fail,
                            const char* function, 
                            const char* file, 
                            int         line)
{
    bool failed = ((actual & expected) != expected);

    log_assert_equal_flag_set_(failed, actual, expected, flag_name, function, file, line);

    if(failed)
    {
        fail_and_finish_test(fail);
    }

    return !failed;
}

//-----------------------------------------------------------------------------
//  Verifies the flag of expected is not within the actual.
//-----------------------------------------------------------------------------
bool assert_equal_flag_unset_(intptr_t   actual, 
                              intptr_t   expected,
                              const char* flag_name,
                              bool        fail,
                              const char* function, 
                              const char* file, 
                              int         line)
{
    bool failed = ((actual & expected) != 0);

    log_assert_equal_flag_unset_(failed, actual, expected, flag_name, function, file, line);

    if(failed)
    {
        fail_and_finish_test(fail);
    }

    return !failed;
}

//-----------------------------------------------------------------------------
//  Verifies the two values are equal.
//-----------------------------------------------------------------------------
bool assert_equal_(intptr_t   actual, 
                   intptr_t   expected,
                   bool        fail, 
                   const char* function, 
                   const char* file, 
                   int         line)
{
    bool failed = (actual != expected);

    log_assert_equal_(failed, actual, expected, function, file, line);

    if(failed)
    {
        fail_and_finish_test(fail);
    }

    return !failed;
}

//-----------------------------------------------------------------------------
//  Verifies two types based on the expect_type_t value passed in.
//-----------------------------------------------------------------------------
bool assert_generic(intptr_t      actual,
                    intptr_t      expected,
                    expect_type_t type,
                    bool          fail,
                    const char*   function,
                    const char*   file,
                    int           line)
{
    bool ret = false;

    switch(type)
    {
        case EXPECT_VALUE:
            ret = assert_equal_(actual, expected, fail, function, file, line);
            break;
        case EXPECT_STRING:
            ret = assert_string_eq_((const char*)actual,
                                    (const char*)expected,
                                    fail, function, file, line);
            break;
        default:
            printf("Trying to call with non-existent expected type:%d "
                  "Call from %s()-%s:%d Error:%s()-%s:%d\n",
                  type, function, file, line, __FUNCTION__, __FILE__, __LINE__);
            break;
    }

    return ret;
}

