/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

/**
    llist.c

    This module contains the implementation of the linked list.
*/

// *****************************************************************************
//  Includes
// *****************************************************************************

#include <stdlib.h>
#include <string.h> //memcpy
#include <inttypes.h>

#include "llist.h"

// *****************************************************************************
//  Defines
// *****************************************************************************

#define LINKED_LIST_MASK 0xA0A06060

// *****************************************************************************
//  Local Functions
// *****************************************************************************

// Computes the magic number to store for the list.
// The magic number allows the list to be determined if it is initialized or not.
static
intptr_t _get_magic_number(linked_list_t *list)
{
    intptr_t magic_num = 0;

    if (list == NULL)
    {
        error("list ptr is NULL.%s", "");
        goto exit;
    }

    magic_num = ((intptr_t)list) ^ (intptr_t)LINKED_LIST_MASK;

exit:
    return magic_num;
}

// Creates a checksum of a string. This is used to determine if the correct type 
// is accessing the list.
// Algorithm: A simple XOR isn't sufficient to tell "Hello" from "World". By 
//            left shifting by bytes, the hash takes letter order into account
//            and significantly decreases collisions.
static
unsigned int _calculate_str_checksum(const char *type)
{
    unsigned int val = 0;
    int count = 0;
    while (*type != 0)
    {
        val ^= (*type) << count * 8;
        type++;
        count = count >= 3 ? 0 : count + 1;
    }
    return val;
}

// *****************************************************************************
//  Global Functions
// *****************************************************************************

bool t_ll_is_initialized(linked_list_t *list)
{
    bool matches_magic_num = false;

    if (list == NULL)
    {
        error("list ptr is NULL.%s", "");
        goto exit;
    }

    matches_magic_num = (list->magic_num == _get_magic_number(list));

exit:
    return matches_magic_num;
}

bool t_ll_verify_list_type(linked_list_t *list, const char* type)
{
    bool ret = true;

    if (list == NULL)
    {
        error("list ptr is NULL.%s", "");
        ret = false;
        goto exit;
    }

    if (type == NULL)
    {
        error("\"type\" ptr is NULL. type=%p", type);
        ret = false;
        goto exit;
    }

    if (list->type_checksum != _calculate_str_checksum(type))
    {
#if DEBUG
        error("List type:%s len:%d checksum:0x%08x doesn't match:%s len:%d "
              "checksum:0x%08x", 
              list->type, (int)strlen(list->type), list->type_checksum, 
              type, (int)strlen(type), _calculate_str_checksum(type));
#endif
        ret = false;
    }

exit:
    return ret;
}

bool t_ll_init(linked_list_t *list, const char *type)
{
    bool ret = true;

    if (list == NULL)
    {
        error("list ptr is NULL.%s", "");
        ret = false;
        goto exit;
    }

    if (type == NULL)
    {
        error("\"type\" ptr is NULL. type=%p", type);
        ret = false;
        goto exit;
    }

    if (list->magic_num == _get_magic_number(list))
    {
        error("List Corruption: This list has already been initialized. "
              "Ptr:%p MagicNum:%"PRIdPTR, list, list->magic_num);
        ret = false;
        goto exit;
    }

    // Initialize the entries.
    list->size = 0;
    list->head = NULL;
    list->magic_num = _get_magic_number(list);
    list->type_checksum = _calculate_str_checksum(type);
#if DEBUG
    strncpy(list->type, type, sizeof(list->type));
#endif

    // The list is now ready to use. Verify it's integrity.
    if (!t_ll_verify_integrity(list))
    {
        bug("Failed verifying the integrity of the list.%s", "");
        ret = false;
        goto exit;
    }

exit:
    return ret;
}

bool t_ll_delete_list(linked_list_t *list)
{
    bool ret = true;

    if (list == NULL)
    {
        error("list ptr is NULL.%s", "");
        ret = false;
        goto exit;
    }

    if (!t_ll_verify_integrity(list))
    {
        bug("Failed verifying integrity of the list. list:%p", list);
        ret = false;
        goto exit;
    }

    // Walk the list and delete each entry.
    list_entry_t *entry = list->head;
    list_entry_t *prev_entry = list->head;

    while (entry != NULL)
    {
        prev_entry = entry;
        entry = entry->next;

        // Because the entry has already been removed from the list, set the 
        // list attribute to NULL and pass it to the entry destruction function.
        prev_entry->list = NULL;
        if (!t_ll_delete_entry(prev_entry, true))
        {
            bug("Failed deleting an entry during list deletion. ptr:%p",
                prev_entry);
            ret = false;
        }
    }

    // Reset each of the values to ensure this list isn't confused with a
    // working list.
    list->size = 0;
    list->head = NULL;
    list->magic_num = 0;

exit:
    return ret;
}

// Returns the size of the linked list.
int t_ll_size(linked_list_t *list)
{
    if (list == NULL)
    {
        error("list ptr is NULL.%s", "");
        goto failure;
    }

    if (!t_ll_verify_integrity(list))
    {
        bug("Failed integrity test. list:%p", list);
        goto failure;
    }

    return list->size;

failure:
    // Returning zero allows functions that call ll_size on a NULL ptr to
    // continue without failure.
    return 0;
}

// Creates a list entry and the data area. This allows the entry to properly
// release all the memory at deletion.
bool t_ll_create_entry(int             size_in_bytes, 
                     list_entry_t  **entry,
                     uint8_t       **data,
                     const char     *type)
{
    bool ret = true;

    if (size_in_bytes < 1)
    {
        error("Create entry called with an invalid size. size:%d", size_in_bytes);
        ret = false;
        goto exit;
    }

    if (entry == NULL)
    {
        error("\"entry\" pointer is NULL. entry:%p", entry);
        ret = false;
        goto exit;
    }

    if (data == NULL)
    {
        error("\"data\" pointer is NULL. data:%p", data);
        ret = false;
        goto exit;
    }

    if (type == NULL)
    {
        error("\"type\" pointer is NULL. type:%p", type);
        ret = false;
        goto exit;
    }

    // Allocate the memory that will hold the entry
    *entry = calloc(1, sizeof(list_entry_t));
    if (*entry == NULL)
    {
        bug("calloc failed to allocate memory for the entry. ptr:%p", entry);
        ret = false;
        goto exit;
    }

    // Allocate the memory that will hold the internal data
    (*entry)->data = calloc(1, size_in_bytes);
    if ((*entry)->data == NULL)
    {
        bug("calloc failed to allocate memory for the data storage. ptr:%p", 
            (*entry)->data);
        ret = false;
        goto exit;
    }

    // Set the list to NULL to indicate it is not currently attached.
    (*entry)->list = NULL;

    // Set the next pointer to NULL.
    (*entry)->next = NULL;

    // Set the type to be used.
    (*entry)->type_checksum = _calculate_str_checksum(type);
#if DEBUG
    strncpy((*entry)->type, type, sizeof((*entry)->type));
#endif

    // Return the data pointer
    *data = (*entry)->data;

exit:
    return ret;
}

// Deletes an individual entry. 
// If the entry is part of a list (it's list member is set), the entry is first
// removed from the list. 
bool t_ll_delete_entry(list_entry_t *delete_entry, bool free_data_ptr)
{
    bool ret = true;

    if (delete_entry == NULL)
    {
        error("\"delete_entry\" parameter is NULL. delete_entry:%p", 
              delete_entry);
        ret = false;
        goto exit;
    }

    // If the entry is still attached to a list, find the entry, and remove it 
    // from the list.
    if (delete_entry->list != NULL)
    { 
        list_entry_t *found_entry;

        // Ensure the list is still valid.
        if (!t_ll_verify_integrity((linked_list_t*)delete_entry->list))
        {
            bug("The list failed an integrity test. list:%p", 
                delete_entry->list);
            ret = false;
            goto exit;
        }

        // The entry still belongs to a list. Find it within the list.
        found_entry = ((linked_list_t*)delete_entry->list)->head;

        if (found_entry == delete_entry)
        {
            // It is at the head of the list. Move the next item into place.
            ((linked_list_t*)delete_entry->list)->head = delete_entry->next;
            ((linked_list_t*)delete_entry->list)->size--;
        }
        else
        {
            // Iterate through the list to find the entry.
            do
            {
                if (found_entry->next == delete_entry)
                {
                    // Found the entry. Remove it from the list.
                    found_entry->next = delete_entry->next;
                    ((linked_list_t*)delete_entry->list)->size--;
                    break;
                }

                found_entry = found_entry->next;

                // It is assumed that this entry is actually within this list
                // therefore the entry is guareenteed to be found before the 
                // end of the list.
            }
            while (found_entry != NULL);
        }
    }

    // Delete the entry
    if(free_data_ptr)
    {
        // Free the data pointer
        free(delete_entry->data);
    }

    // NULL out the entry's attributes.
    delete_entry->list = NULL;
    delete_entry->data = NULL;
    delete_entry->next = NULL;

    // Free the list entry
    free(delete_entry);

exit:
    return ret;
}

// A zero based index into the list.
bool t_ll_delete_entry_at(linked_list_t *list, 
                        unsigned int   index)
{
    bool ret = true;
    list_entry_t *found_entry;

    if (list == NULL)
    {
        error("\"list\" parameter is NULL. list:%p", list);
        ret = false;
        goto exit;
    }

    if (!t_ll_verify_integrity(list))
    {
        bug("List failed integrity test.%s", "");
        ret = false;
        goto exit;
    }

    // Verify the index is within range.
    if (index >= list->size)
    {
        error("Index Out of Range: Requesting a value outside the range of "
              "the list. Index:%d Size:%d", index, list->size);
        ret = false;
        goto exit;
    }

    // Index into the list to find the requested entry.
    found_entry = list->head;

    if (index == 0)
    {
        // Remove the entry from the head of the list.
        list->head = found_entry->next;
    }
    else
    {
        list_entry_t *prev_entry;

        int i;
        for (i = 0; i < index; i++)
        {
            prev_entry = found_entry;
            found_entry = found_entry->next;
        }

        // Remove the entry from the list.
        prev_entry->next = found_entry->next;
    }

    // Set the list attribute to NULL to allow the entry to be deleted.
    found_entry->list = NULL;
    if (!t_ll_delete_entry(found_entry, true))
    {
        error("Failed deleting entry.%s", "");
        ret = false;
        goto exit;
    }

    // Indicate the list is now one smaller.
    list->size--;

    // Ensure the integrity of the list.
    if (!t_ll_verify_integrity(list))
    {
        bug("List failed the integrity check. list:%p", list);
        ret = false;
        goto exit;
    }
    
exit:
    return ret;
}

// Add the entry to the back of the list.
bool t_ll_add_entry_to_back(linked_list_t *list,
                          list_entry_t  *new_entry)
{
    bool ret = true;

    if (list == NULL)
    {
        error("\"list\" parameter is NULL. list:%p", list);
        ret = false;
        goto exit;
    }

    if (!t_ll_verify_integrity(list))
    {
        bug("List failed integrity test.%s", "");
        ret = false;
        goto exit;
    }

    if (new_entry == NULL)
    {
        error("\"new_entry\" parameter is NULL. new_entry:%p", new_entry);
        ret = false;
        goto exit;
    }

    if (list->type_checksum != new_entry->type_checksum)
    {
        bug("This entry represents a different type and cannot be added to "
             "this list. List:0x%08X Entry:0x%08X", list->type_checksum,
             new_entry->type_checksum);
#if DEBUG
        bug("List type:%s Entry type:%s", list->type, new_entry->type);
#endif
        ret = false;
        goto exit;
    }

    // If the list is empty, add the entry.
    if (list->head == NULL)
    {
        list->head = new_entry;
    }
    else
    {
        // Find the last entry.
        list_entry_t *last_entry = list->head;

        while (last_entry->next != NULL)
        {
            last_entry = last_entry->next;
        }

        last_entry->next = new_entry;
    }

    // Set the entry's list.
    new_entry->list = (struct linked_list_t*)list;

    // Increment the list size.
    list->size++;

exit:
    return ret;
}

// Add the entry to the beginning of the list.
bool t_ll_add_entry_to_front(linked_list_t *list,
                           list_entry_t  *new_entry)
{
    bool ret = true;

    if (list == NULL)
    {
        error("\"list\" parameter is NULL. list:%p", list);
        ret = false;
        goto exit;
    }

    if (!t_ll_verify_integrity(list))
    {
        bug("List failed integrity test.%s", "");
        ret = false;
        goto exit;
    }

    if (new_entry == NULL)
    {
        error("\"new_entry\" parameter is NULL. new_entry:%p", new_entry);
        ret = false;
        goto exit;
    }

    if (list->type_checksum != new_entry->type_checksum)
    {
        bug("This entry represents a different type and cannot be added to"
             "this list. List:0x%08X Entry:0x%08X", list->type_checksum,
             new_entry->type_checksum);
#if DEBUG
        bug("List type:%s Entry type:%s", list->type, new_entry->type);
#endif
        ret = false;
        goto exit;
    }

    // Replace the entry at the head of the new entry.
    new_entry->next = list->head;
    list->head = new_entry;

    // Set the entry's list.
    new_entry->list = (struct linked_list_t*)list;

    // Increment the size of the list.
    list->size++;

exit:
    return ret;
}

// A zero based index into the list.
bool t_ll_entry_at(linked_list_t        *list, 
                 int                   index, 
                 uint8_t             **entry_data)
{
    bool ret = true;

    if (entry_data == NULL)
    {
        error("\"entry_data\" parameter is NULL. entry_data:%p", entry_data);
        ret = false;
        goto exit;
    }

    // Initialize entry_data.
    *entry_data = NULL;

    if (list == NULL)
    {
        error("\"list\" parameter is NULL. list:%p", list);
        ret = false;
        goto exit;
    }

    if (!t_ll_verify_integrity(list))
    {
        bug("List failed integrity test.%s", "");
        ret = false;
        goto exit;
    }

    if (entry_data == NULL)
    {
        error("\"entry_data\" parameter is NULL. entry_data:%p", entry_data);
        ret = false;
        goto exit;
    }

    // If the index exceeds the size, return false.
    if (index < 0 || index >= list->size)
    {
        error("Index Out of Range: Requesting a value outside the range of "
              "the list. Index:%d Size:%d", index, list->size);
        ret = false;
        goto exit;
    }

    // Index into the list to find the requested entry.
    list_entry_t *found_entry = list->head;

    int i;
    for (i = 0; i < index; i++)
    {
        found_entry = found_entry->next;
    }

    *entry_data = found_entry->data;

exit:
    return ret;
}

// Test the list to verify the implementation.
bool t_ll_verify_integrity(linked_list_t *list)
{
    bool ret = true;

    if (list == NULL)
    {
        error("\"list\" parameter is NULL. list:%p", list);
        ret = false;
        goto exit;
    }

    int count = 0;
    list_entry_t *entry;

    // Verify the magic number is correct. This implies that the list has been
    // initialized.
    if (list->magic_num != _get_magic_number(list))
    {
        error("Corrupt List: List not initialized. Ptr:%p "
              "ExpectedMagic:%"PRIdPTR" Magic:%"PRIdPTR" Size:%d Head:%p ",
              list, list->magic_num, _get_magic_number(list),
              list->size, list->head);
        ret = false;
        goto exit;
    }

    // If the head is NULL (there are no entries), ensure that the size is 0.
    if (list->head == NULL)
    {
        if (list->size != 0)
        {
            error("Corrupt List: The list's head is NULL, but the size isn't "
                  "zero. Size:%d", list->size);
            ret = false;
        }
        goto exit;
    }

    // If the size is 0, ensure that the head is NULL (there are no entries).
    if (list->size == 0)
    {
        if (list->head != NULL)
        {
            error("Corrupt List: The list's size is zero, but the head isn't "
                  "NULL. HeadPtr:%p", list->head);
            ret = false;
        }
        goto exit;
    }

    // Loop through all of the entries and count them.
    entry = list->head;

    do
    {
        // Verify that each of the entries have their list attribute set.
        if (entry->list == NULL)
        {
            bug("Corrupt List: An entry's list attribute is set to NULL. "
                "Ptr:%p", entry->list);
            ret = false;
            goto exit;
        }

        // Verify that the types are all the same
        if (entry->type_checksum != list->type_checksum)
        {
            bug("Corrupt List: An entry's type does not match the list's. "
                "Count:%d", count);
#if DEBUG
            bug("List type:%s Entry type:%s", list->type, entry->type);
#endif
            ret = false;
            goto exit;
        }

        count++;
        entry = entry->next;
    }while (list->size > count && entry != NULL);

    // Ensure that the next entry is NULL.
    if (entry != NULL)
    {
        error("Corrupt List: Either the list is the wrong size or the final "
              "entry is not NULL. Counted=%d Len=%d NextPtr=%p", 
              count, list->size, entry);
        ret = false;
        goto exit;
    }

    // Ensure that the sizes match.
    if (count != list->size)
    {
        error("Corrupt List: The list's size doesn't match the number "
              "of entries. ListSize:%d Counted:%d", count, list->size);
        ret = false;
        goto exit;
    }

exit:
    return ret;
}

/**
    Copy the source list to the destination list.
*/
bool t_ll_copy_list(linked_list_t *src_list,
                  linked_list_t *dst_list,
                  uint32_t       size_of_stored)
{
    bool ret = true;

    if (src_list == NULL)
    {
        error("\"src_list\" parameter is NULL. src_list:%p", src_list);
        ret = false;
        goto exit;
    }

    if (dst_list == NULL)
    {
        error("\"dst_list\" parameter is NULL. dst_list:%p", dst_list);
        ret = false;
        goto exit;
    }

    if (!t_ll_verify_integrity(src_list))
    {
        bug("Source list failed integrity test.%s", "");
        ret = false;
        goto exit;
    }

    if (!t_ll_verify_integrity(dst_list))
    {
        bug("Destination list failed integrity test.%s", "");
        ret = false;
        goto exit;
    }

    list_entry_t *src_entry = src_list->head;
    uint8_t      *src_data;
    list_entry_t *dst_entry;
    uint8_t      *dst_data;

    while (src_entry != NULL)
    {
        src_data = src_entry->data;

        // Create a new entry to store the src entry.
        if (!t_ll_create_entry(size_of_stored, &dst_entry, &dst_data, ""))
        {
            bug("Failed creating entry for the destination list.%s", "");
            ret = false;
            goto exit;
        }

        // Copy the type
        dst_entry->type_checksum = src_entry->type_checksum;
#if DEBUG
        strcpy(dst_entry->type, src_entry->type);
#endif

        // Copy the data to the new entry.
        memcpy(dst_data, src_data, size_of_stored);

        // Add entry to the back of the destination list.
        if (!t_ll_add_entry_to_back(dst_list, dst_entry))
        {
            if (!t_ll_delete_entry(dst_entry, true))
            {
                bug("Failed deleting entry.%s","");
                ret = false;
                goto exit;
            }
            bug("Failed adding entry to back of the destination list.%s", "");
            ret = false;
            goto exit;
        }

        src_entry = src_entry->next;
    }

exit:
    return ret;
}
