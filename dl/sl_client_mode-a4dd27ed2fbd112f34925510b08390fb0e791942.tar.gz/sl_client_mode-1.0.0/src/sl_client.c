/*******************************************************************************
		       Lantiq Beteiligungs-GmbH & Co. KG
		       Copyright (c) 2015
  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.
********************************************************************************/
/*  ******************************************************************************
 *         File Name    : sl_client.c   					 *
 *         Description  : this Feature SL is responsible to Client Mode (Repeater)*
 *      									 *
 *  ******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <ugw_proto.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <cal.h>
#include <sys/un.h>
#include <sys/ipc.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <stdint.h>
#include <stdlib.h>
#include <wchar.h>
#include <wctype.h>
#include "fapi_sys_common.h"
#include "client_id.h"
#include "sl_client.h"

/*Definitions*/
#ifndef LOG_LEVEL
uint16_t LOGLEVEL = SYS_LOG_DEBUG + 1;
#else
uint16_t LOGLEVEL = LOG_LEVEL + 1;
#endif

#ifndef LOG_TYPE
uint16_t LOGTYPE = SYS_LOG_TYPE_FILE;
#else
uint16_t LOGTYPE = LOG_TYPE;
#endif

#define SWEEP_ALL	0
#define OBJ_ADD_RO	OBJOPT_ADD | MISC_READ
#define OBJ_MODIFY_RO	OBJOPT_MODIFY | MISC_READ
#define	NO_INTERACTION_REQ	99
#define LAST_VAP_NUM	16
#define LAST_VAP_NUM_STRING "16"
#define FALSE_STRING_SIZE	2

/*MACRO*/
#define MARK_VAP_ENABLE(status)	(status |= 0x1)
#define MARK_VAP_SSID(status)	(status |= 0x2)
#define MARK_VAP_RADIO(status)	(status |= 0x4)
#define IS_VAP_ENABLE(status)	((status == 0x7) ? 1 : 0)

#define CLIENT_HELP_DELETE_OBJ(pxObj, unFlag) \
	if (pxObj) { \
		HELP_DELETE_OBJ(pxObj, SOPT_OBJVALUE, unFlag); \
	} else { \
		LOGF_LOG_DEBUG("Client Mode: cannot delete empty object\n"); \
	}

/*Enum values*/
typedef enum {
	STATION_CHANGE_STATE,
	STATION_ENABLE,
	STATION_DISABLE,
	SYSTEM_CHANGE_STATE,
	VAP_ENABLE,
	VAP_DISABLE,
	L2NAT_ENABLE,
	L2NAT_DISABLE,
	GW_MODE,
	REPEATER_MODE,
	MAX_OPERATION_VAL
} sl_operations;

/*Structs*/
typedef struct{
	char ModeEnabled[MAX_LEN_PARAM_VALUE];
	char WEPKey[MAX_LEN_PARAM_VALUE];
	char KeyPassphrase[MAX_LEN_PARAM_VALUE];
} security_profile;

typedef struct{
	char Enable[NUM_SUPPORTED_AP][MAX_LEN_PARAM_VALUE];
	char radio[NUM_SUPPORTED_AP][MAX_LEN_PARAM_VALUE];
	char SSID[NUM_SUPPORTED_AP][MAX_LEN_PARAM_VALUE];
	security_profile security;
} AP_params;

/*Static function declarations*/

/*Wrapper Functions*/
static void * client_help_create_obj(void);
static void client_help_copy_obj(OUT ObjList *pxObjListOut, IN ObjList *pxObjListIn, IN unsigned char flag);
static void client_help_merge_obj(OUT ObjList *pxObjListOut, IN ObjList *pxObjListIn);
static void client_help_trim_obj_name(char pcObjName[]);
static int client_get_object_from_db(ObjList *pxObjList, IN unsigned int unSubOper, IN char *pcObjNameIn);
static int client_get_param_from_list(IN ObjList *pxObjListIn, IN char *pcObjName, IN int instance,
								IN char *pcParamName, OUT char *pcParamValue);
/*Helper Functions*/
static bool is_numeric(const char *str);
static int is_stringFalse(char *str);
static bool isValidIpAddress(char *ipAddress);
static int client_setRadioConfig(ObjList *pxObjListNew, int index);
static int client_getInstanceNumFromObjectName(IN char *pcChainPath);
static int client_getInterfaceIP(IN char *interfaceName, OUT char *interfaceIP);
static int client_parseProfileEntry(IN ObjList *pxObjList);
static int client_changeWDSstatus(char *reqValue);
static int client_configureRepeaterAP(ObjList *pxBookObj, ObjList *pxObjListWlan,
							ObjList *pxObjListMain, AP_params *ap_param);
static int client_bookkeepMainAP(ObjList *pxBookObj, ObjList *pxObjListWlan, int bookkeep_indexArr[],
								AP_params *ap_param, int radioCfg_indexArr[]);
static int client_deleteBookkeep(ObjList *pxBookObj, ObjList *pxMainObj);
static int client_connectSTAtoAP(ObjList *pxObjListWlan, ObjList *pxObjListMain, AP_params *ap_param);
static int client_parseDB(ObjList *pxMainObj, ObjList *pxReceivedObj);
static int client_enableVAPforGW(ObjList *pxMainObj);
static int client_configureGWAP(ObjList *pxBookObj, ObjList *pxMainObj, ObjList *pxObjListWlan);
static int client_configureBridgeRepeater(ObjList *pxBookObj, ObjList *pxMainObj, ObjList *pxObjListWlan);
static int client_disableActiveVAP(int vap_num, ObjList *pxBookObj, ObjList *pxObjListWlan);
static int client_disableVAPforRepeater(ObjList *pxBookObj, ObjList *pxObjListWlan, ObjList *pxObjListMain);
static int client_freeVAPforSTA(ObjList *pxBookObj, ObjList *pxObjListWlan, ObjList *pxObjListMain, int curr_entry);
static int client_parseRequest(sl_operations req_operation, ObjList *pxObjList, ObjList *pxBookObj, int curr_entry);
static int client_rollBack(sl_operations switch_mode, ObjList *pxBookObj, ObjList *pxMainObj, ObjList *pxObjListWlan);
/*Main Functions*/
static int client_handleSTAStatusChange(ObjList *pxBookObj, ObjList *pxObjListNew, ObjList *pxObjListMain,
							ObjList *pxObjListWlan, sl_operations req_operation, int curr_entry);

static int client_stationChangeMode(ObjList *pxObjMain, int curr_entry, sl_operations interface_op, ObjList *pxBookObj);
static void sl_client_init (INOUT ServdData *pxSlData);
static void sl_client_uninit (INOUT ServdData *pxSlData);
static void sl_client_modify (INOUT ServdData *pxSlData);
static void sl_client_notify (INOUT ServdData *pxSlData);

/**********************************************************************************************************/
/*Wrapper functions*/
/**********************************************************************************************************/
/* =================================================================================
 *  Function Name : client_help_create_obj
 *  Description   : Wrapper to create new object list using helper library.
 * =================================================================================*/
static void * client_help_create_obj(void)
{
	ObjList *pxObjList;

	if ((pxObjList = HELP_CREATE_OBJ(SOPT_OBJVALUE)) == NULL) {
		LOGF_LOG_ERROR("Client Mode : Failed to create Objectlist\n");
	}
	return (void *)pxObjList;
}

/* =================================================================================
 *  Function Name : client_help_copy_obj
 *  Description   : Wrapper to copy object or complete object list using helper library.
 * =================================================================================*/
static void client_help_copy_obj(OUT ObjList *pxObjListOut, IN ObjList *pxObjListIn, IN unsigned char flag)
{
	if (!pxObjListOut || !pxObjListIn) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		return;
	}
	HELP_COPY_OBJ(pxObjListOut, pxObjListIn, SOPT_OBJVALUE, flag);
}

/* =================================================================================
 *  Function Name : client_help_merge_obj
 *  Description   : Wrapper to merge objects
 * =================================================================================*/
static void client_help_merge_obj(OUT ObjList *pxObjListOut, IN ObjList *pxObjListIn)
{
	if (!pxObjListOut || !pxObjListIn) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		return;
	}
	HELP_MERGE_OBJLIST(pxObjListOut, pxObjListIn);
}

/* =================================================================================
 *  Function Name : client_help_trim_obj_name
 *  Description   : This helper function removes a final "." at the end of an
 *      	    object name if present (e.g. Device.WiFi.Radio.1. will convert
 *      	    to Device.WiFi.Radio.1)
 * =================================================================================*/
static void client_help_trim_obj_name(char pcObjName[])
{
	int pcObjNameLen = 0;
	char dot = '.';

	if (!(pcObjNameLen = strlen(pcObjName))) {
		LOGF_LOG_DEBUG("Client Mode: cannot trim string (strlen = 0)\n");
		return;
	}

	if (pcObjName[pcObjNameLen-1] == dot) {
		pcObjName[pcObjNameLen-1] = pcObjName[pcObjNameLen];
	}
	return;
}

/*=============================================================================
 *  Function Name : client_get_object_from_db
 *  Description   : This function can be used to get object list from database
 *===========================================================================*/
static int client_get_object_from_db(ObjList *pxObjList, IN unsigned int unSubOper, IN char *pcObjNameIn)
{
	int nRet = UGW_SUCCESS;
	RespCode xRespCode;
	char pcObjName[MAX_LEN_OBJNAME];

	if (!pxObjList) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto read_end;
	}
	LOGF_LOG_DEBUG("Client Mode read from DB: pxObjList: %p, pcObjNameIn: %s, unSubOper: 0x%x\n", pxObjList, pcObjNameIn, unSubOper);
	memset(&xRespCode, 0x0, sizeof(xRespCode));

	strncpy(pcObjName, pcObjNameIn, MAX_LEN_OBJNAME - 1);
	pcObjName[MAX_LEN_PARAM_VALUE - 1] = '\0';
	if ((nRet = SERVD_GETVALUE_FROM_DB(pxObjList, &xRespCode,
							pcObjName, unSubOper)) != UGW_SUCCESS) {
			LOGF_LOG_ERROR("Client Mode: Getting object from database failed.. Cant proceed further..\n");
			goto read_end;
	}

read_end:
	LOGF_LOG_DEBUG("Client Mode: nRet is %d\n", nRet);
	return nRet;
}

static int client_get_param_from_list(IN ObjList *pxObjListIn, IN char *pcObjName, IN int instance, IN char *pcParamName, OUT char *pcParamValue)
{
	ObjList *pxObjList;
	ObjList *pxTmpObj;
	ParamList *pxParam = NULL;
	char ObjNameStr[MAX_LEN_PARAM_VALUE];

	LOGF_LOG_DEBUG("Client Mode: instance:%d: pcObjName: %s pcParamName: %s\n", instance, pcObjName, pcParamName);
	pxObjList = client_help_create_obj();
	if (!pxObjList) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		return UGW_FAILURE;
	}
	/*Prepare local copy of object name*/
	if (!instance) {
		snprintf(ObjNameStr, MAX_LEN_PARAM_VALUE, "%s", pcObjName);
	} else {
		snprintf(ObjNameStr, MAX_LEN_PARAM_VALUE, "%s%d", pcObjName, instance);
	}
	/* use local copy of the input list */
	client_help_copy_obj(pxObjList, pxObjListIn, COPY_COMPLETE_OBJ);
	/* remove trailing dot in object name */
	client_help_trim_obj_name(ObjNameStr);

	FOR_EACH_OBJ(pxObjList, pxTmpObj) {
		client_help_trim_obj_name(pxTmpObj->sObjName);
		if (!strncmp(pxTmpObj->sObjName, ObjNameStr, MAX_LEN_OBJNAME)) {
			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if (!strncmp(pxParam->sParamName, pcParamName, MAX_LEN_PARAM_NAME)) {
					snprintf(pcParamValue, MAX_LEN_PARAM_VALUE, "%s", pxParam->sParamValue);
					return UGW_SUCCESS;
				}
			}
		}
	}
	LOGF_LOG_DEBUG("Client Mode: param not found: %s\n", pcParamName);
	CLIENT_HELP_DELETE_OBJ(pxObjList, FREE_OBJLIST);
	return UGW_FAILURE;
}

/**********************************************************************************************************/
/*Helper functions*/
/**********************************************************************************************************/

/* ===================================================================================
 *  Function Name : is_numeric
 *  Description   : Helper function to check if string value includes only numbers
 * ===================================================================================*/
static bool is_numeric(const char *str)
{
	while((*str != '\0') && (str != NULL))
	{
		if(*str < '0' || *str > '9')
			return false;
		str++;
	}
	return true;
}

/* ===================================================================================
 *  Function Name : is_stringFalse
 *  Description   : Helper function to check if string value is 'false' or '0'
 * ===================================================================================*/
static int is_stringFalse(char *str)
{
	int i;
	char * false_str[] = {"false" , "0"};

	if (!str) {
		return 0;
	}
	if (str[0] == '\0') {
		LOGF_LOG_DEBUG("Empty string - handle as false entry\n");
		return 1;
	}
	for (i = 0; i < FALSE_STRING_SIZE; i++) {
		if (!strncmp(str, false_str[i], MAX_LEN_PARAM_VALUE)) {
			return 1;
		}
	}
	return 0;
}

/* ===================================================================================
 *  Function Name : isValidIpAddress
 *  Description   : Helper function to check if string IPv4 address is valid
 * ===================================================================================*/
static bool isValidIpAddress(char *ipAddress)
{
	struct sockaddr_in sa;
	int result = inet_pton(AF_INET, ipAddress, &(sa.sin_addr));

	if (!strcmp(ipAddress, DEFAULT_IP_ADDR)) {
		LOGF_LOG_DEBUG("Default IP 0.0.0.0 detected - Reject it\n");
		result = 0;
	}
	LOGF_LOG_DEBUG("Received IP address %s, return valid = %d\n", ipAddress, result);
	return result != 0;
}

/* =============================================================================================
 *  Function Name : client_setRadioConfig
 *  Description   : Helper function to set radio configuration
 * =============================================================================================*/
static int client_setRadioConfig(ObjList *pxObjListNew, int index)
{
	char sParamValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	ObjList *tmpPxObjList = NULL;
	int nRet = UGW_SUCCESS;

	if (!pxObjListNew || (index < 1)) {
		LOGF_LOG_ERROR("Function called with empty objects or invalid index\n");
		nRet = UGW_FAILURE;
		goto radio_exit;
	}

	snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "%s%d.", WIFI_RADIO_OBJECT_NAME, index);
	LOGF_LOG_DEBUG("Set AutoChannel to true on object - %s\n", sParamValue);
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, sParamValue, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto radio_exit;
	}
	/*Set relevant parameter*/
	HELP_PARAM_SET(tmpPxObjList, "AutoChannelEnable", "true", SOPT_OBJVALUE);

	snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "%sX_LANTIQ_COM_Vendor", sParamValue);
	LOGF_LOG_DEBUG("Setting radio ACS enable to object - %s\n", sParamValue);
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, sParamValue, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto radio_exit;
	}
	/*Set relevant parameter*/
	HELP_PARAM_SET(tmpPxObjList, "WaveAcsUpdateTimeout", "0", SOPT_OBJVALUE);

radio_exit:
	LOGF_LOG_DEBUG("Radio Config Done with return value %d\n", nRet);
	return nRet;
}

/* =============================================================================================
 *  Function Name : client_getInstanceNumFromObjectName
 *  Description   : Helper function to get Instance number from object name. Function assumes
 *      	    Latests found number in object name is the entry
 * =============================================================================================*/
static int client_getInstanceNumFromObjectName(IN char *pcChainPath)
{
	char * str;
	char *endptr;
	char sParamValue[MAX_LEN_PARAM_VALUE];
	int nChainInstance = -1;

	strncpy(sParamValue, pcChainPath, MAX_LEN_PARAM_VALUE - 1);
	sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
	str = strtok(sParamValue, ".");
	while (str != NULL) {
		if (is_numeric(str)) {
			/*Save number to be used as entry*/
			nChainInstance = strtol(str, &endptr, 10);
			if (str == endptr) {
				LOGF_LOG_ERROR("Failed to translate number from string!\n");
				nChainInstance = -1;
			}
		}
		str = strtok(NULL, ".");
	}
	LOGF_LOG_DEBUG("Entry number in DB is %d\n", nChainInstance);
	return nChainInstance;
}

/* =============================================================================================
 *  Function Name : client_getInterfaceIP
 *  Description   : Helper function to get given interface IP address
 * =============================================================================================*/
static int client_getInterfaceIP(IN char *interfaceName, OUT char *interfaceIP)
{
	int fd = 0, nRet = UGW_SUCCESS;
	struct ifreq ifr;

	if (!interfaceName || !interfaceIP) {
		LOGF_LOG_ERROR("Function called with NULL interface name!\n");
		nRet = UGW_FAILURE;
		goto interface_exit;
	}

	fd = socket(AF_INET, SOCK_DGRAM, 0);

	if (fd < 0) {
		LOGF_LOG_ERROR("Failed to create socket!\n");
		nRet = UGW_FAILURE;
		goto interface_exit;
	}
	/*Mark we are intereseted in IPv4 IP address */
	ifr.ifr_addr.sa_family = AF_INET;

	strncpy(ifr.ifr_name, interfaceName, IFNAMSIZ-1);
	ifr.ifr_name[IFNAMSIZ - 1] = '\0';

	ioctl(fd, SIOCGIFADDR, &ifr);

	/* display result */
	LOGF_LOG_DEBUG("%s interface IP is %s\n", interfaceName, inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));
	strncpy(interfaceIP, inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr), MAX_LEN_PARAM_VALUE - 1);
	interfaceIP[MAX_LEN_PARAM_VALUE - 1] = '\0';

interface_exit:
	if (fd > -1) {
		close(fd);
	}
	return nRet;
}

/* =============================================================================================
 *  Function Name : client_parseProfileEntry
 *  Description   : Helper function to get Profile Instance number from object name - assuming
 *      	    only one profile exist in received object
 * =============================================================================================*/
static int client_parseProfileEntry(IN ObjList *pxObjList)
{
	ObjList *pxTmpObj = NULL;
	int nRet = -1;

	FOR_EACH_OBJ(pxObjList, pxTmpObj) {
		if (pxTmpObj->unOid != DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE) {
			continue;
		}
		nRet = client_getInstanceNumFromObjectName(pxTmpObj->sObjName);
		break;
	}

	return nRet;
}

/* ===================================================================================
 *  Function Name : client_parseDB
 *  Description   : Helper function to create unified object list
 * ===================================================================================*/
static int client_parseDB(ObjList *pxMainObj, ObjList *pxReceivedObj)
{
	ObjList *pxTmpObj = NULL;
	ObjList *pxObjListTmp = client_help_create_obj();
	int nRet = UGW_SUCCESS;

	if (!pxObjListTmp) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto parse_exit;
	}

	LOGF_LOG_DEBUG("Read current information from DB\n");
	if ((nRet = client_get_object_from_db(pxMainObj, SOPT_OBJVALUE,
						CLIENT_OBJECT_GENERAL_NAME))) {
		LOGF_LOG_INFO("Failed to read object from DB!\n");
		nRet = UGW_SUCCESS;
		goto parse_exit;
	}

	if (pxReceivedObj) {
		FOR_EACH_OBJ(pxReceivedObj, pxTmpObj) {
			LOGF_LOG_DEBUG("Received updated information from caller on %s - merge it\n", pxTmpObj->sObjName);
			client_help_copy_obj(pxObjListTmp, pxTmpObj, COPY_SINGLE_OBJ);
		}
		client_help_merge_obj(pxMainObj, pxObjListTmp);
	}

parse_exit:
	CLIENT_HELP_DELETE_OBJ(pxObjListTmp, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_changeWDSstatus
 *  Description   : Helper function to set WDS value to WLAN
 * ===================================================================================*/
static int client_changeWDSstatus(char *reqValue)
{
	ObjList *pxObjListWlan = client_help_create_obj();
	ObjList *pxObjList = client_help_create_obj();
	ObjList *tmpPxObjList = NULL;
	ObjList *tmpPxObjList1 = NULL;
	ParamList *pxParam = NULL;
	bool param_found = false;
	int nRet = UGW_SUCCESS;

	if (!pxObjListWlan || !pxObjList || !reqValue) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto wds_exit;
	}

	/*Read WLAN DB to find enabled Endpoint*/
	if ((nRet = client_get_object_from_db(pxObjListWlan, SOPT_OBJVALUE, WIFI_ENDPOINT_OBJECT_NAME))) {
		LOGF_LOG_ERROR("Failed to read data from DB - %s!\n", WIFI_ENDPOINT_OBJECT_NAME);
		goto wds_exit;
	}
	FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if (!strcmp(pxParam->sParamName, "Enable")
			 && (!is_stringFalse(pxParam->sParamValue))) {
				LOGF_LOG_DEBUG("Object %s is enabled in DB - Setting WDS value %s\n", tmpPxObjList->sObjName, reqValue);
				tmpPxObjList1 = HELP_OBJECT_SET(pxObjList, tmpPxObjList->sObjName,
									NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
				if (tmpPxObjList1 == NULL) {
					LOGF_LOG_ERROR("Failed to set object!!\n");
					goto wds_exit;
				}
				HELP_PARAM_SET(tmpPxObjList1, "X_LANTIQ_COM_Vendor_WaveEndPointWDS", reqValue, SOPT_OBJVALUE);
				param_found = true;
				break;
			}
		}
		if (param_found) {
			break;
		}
	}

	if (!param_found) {
		LOGF_LOG_ERROR("No Endpoint object is enabled - Return to caller without setting WDS\n");
		nRet = UGW_FAILURE;
		goto wds_exit;
	}
	if (HELP_IS_EMPTY_OBJ_PARAM(pxObjList)) {
		/*Trigger SL request*/
		LOGF_LOG_DEBUG("Sending WDS request:\n");
		HELP_PRINT_OBJ(pxObjList, 0x4); //to be removed
		if ((nRet = SERVD_CAL_SET_SERVICE(pxObjList) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto wds_exit;
		}
	}

wds_exit:
	CLIENT_HELP_DELETE_OBJ(pxObjListWlan, FREE_OBJLIST);
	CLIENT_HELP_DELETE_OBJ(pxObjList, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_disableActiveVAP
 *  Description   : Helper function to disable all active VAPs in WLAN
 * ===================================================================================*/
static int client_disableActiveVAP(int vap_num, ObjList *pxBookObj, ObjList *pxObjListWlan)
{
	ObjList *tmpPxObjList = NULL;
	ObjList *pxObjList = client_help_create_obj();
	char ObjNameStr[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sParamValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	int nRet = UGW_SUCCESS;

	if (!pxObjListWlan || !pxObjList || vap_num < 0) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto disable_exit;
	}

	snprintf(ObjNameStr, MAX_LEN_PARAM_VALUE, "%s%d", WIFI_SSID_OBJECT_NAME, vap_num);
	tmpPxObjList = HELP_OBJECT_SET(pxObjListWlan, ObjNameStr, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto disable_exit;
	}
	/*Set relevant parameters*/
	HELP_PARAM_SET(tmpPxObjList, "Enable", "false", SOPT_OBJVALUE);

	snprintf(ObjNameStr, MAX_LEN_PARAM_VALUE, "%s%d", WIFI_ACCESSPOINT_OBJECT_NAME, vap_num);
	tmpPxObjList = HELP_OBJECT_SET(pxObjListWlan, ObjNameStr, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto disable_exit;
	}
	/*Set relevant parameters*/
	HELP_PARAM_SET(tmpPxObjList, "Enable", "false", SOPT_OBJVALUE);

	/*Bookkeep disabled VAP*/
	LOGF_LOG_DEBUG("Bookkeep disabled VAP to DB\n");

	tmpPxObjList = HELP_OBJECT_SET(pxBookObj, CLIENT_OBJECT_BOOKKEEP_NAME, NO_ARG_VALUE, OBJOPT_ADD, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto disable_exit;
	}
	/*Set relevant parameters*/
	snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "%d", vap_num);
	HELP_PARAM_SET(tmpPxObjList, "InstanceNum", sParamValue, SOPT_OBJVALUE);
	HELP_PARAM_SET(tmpPxObjList, "VAPPreviousValue", "Enable", SOPT_OBJVALUE);

disable_exit:
	CLIENT_HELP_DELETE_OBJ(pxObjList, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_bookkeepMainAP
 *  Description   : Helper function to bookkeep Main AP values to DB
 * ===================================================================================*/
static int client_bookkeepMainAP(ObjList *pxBookObj, ObjList *pxObjListWlan, int bookkeep_indexArr[], AP_params *ap_param, int radioCfg_indexArr[])
{
	char objAccess[MAX_LEN_PARAM_VALUE];
	char objSecurity[MAX_LEN_PARAM_VALUE];
	char objSSID[MAX_LEN_PARAM_VALUE];
	char sParamValue[MAX_LEN_PARAM_VALUE];
	char sObjValue[MAX_LEN_PARAM_VALUE];
	char sParamBackup[MAX_LEN_PARAM_VALUE];
	int nRet = UGW_SUCCESS, i;
	ObjList *pxBookObjTmp = client_help_create_obj();
	ObjList *tmpPxObjList = NULL;
	ObjList *tmpPxObjList1 = NULL;
	ParamList *pxParam = NULL;

	if (!pxBookObjTmp) {
		LOGF_LOG_ERROR("Failed to create object!\n");
		nRet = UGW_FAILURE;
		goto book_exit;
	}

	LOGF_LOG_DEBUG("Start Bookkeep main AP\n");
	for (i = 0; i < NUM_SUPPORTED_AP; i++) {
		if (bookkeep_indexArr[i] < 1) {
			LOGF_LOG_DEBUG("Nothing to bookkeep for entry %d\n", i);
			continue;
		}

		LOGF_LOG_DEBUG("Bookkeep entry %d information\n", i);

		/*Parse from AccessPoint object the relevant SSID entry*/
		snprintf(objAccess, MAX_LEN_PARAM_VALUE, "%s%d.", WIFI_ACCESSPOINT_OBJECT_NAME, bookkeep_indexArr[i]);
		nRet = client_get_param_from_list(pxObjListWlan, objAccess, 0, "SSIDReference", objSSID);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to read parameter SSIDReference from DB\n");
			goto book_exit;
		}

		snprintf(objSecurity, MAX_LEN_PARAM_VALUE, "%s%d.Security", WIFI_ACCESSPOINT_OBJECT_NAME, bookkeep_indexArr[i]);

		if (!tmpPxObjList1) {
			tmpPxObjList1 = HELP_OBJECT_SET(pxBookObjTmp, CLIENT_OBJECT_BOOKKEEP_NAME, NO_ARG_VALUE, OBJOPT_ADD, SOPT_OBJVALUE);
			if (tmpPxObjList1 == NULL) {
				LOGF_LOG_ERROR("Failed to set object!!\n");
				nRet = UGW_FAILURE;
				goto book_exit;
			}
		}

		FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
			if (strstr(tmpPxObjList->sObjName, objSecurity)
			 && (strlen(tmpPxObjList->sObjName) < strlen(objSecurity) + 1)) {
				/*Bookkeep values*/
				FOR_EACH_PARAM(tmpPxObjList, pxParam) {
					if (!strcmp(pxParam->sParamName, "ModeEnabled")
						&& (pxParam->sParamValue[0] != '\0')) {
						HELP_PARAM_SET(tmpPxObjList1, "ModeEnabled", pxParam->sParamValue, SOPT_OBJVALUE);
					} else if (!strcmp(pxParam->sParamName, "WEPKey")
						&& (pxParam->sParamValue[0] != '\0')) {
						HELP_PARAM_SET(tmpPxObjList1, "WEPKey", pxParam->sParamValue, SOPT_OBJVALUE);
					} else if (!strcmp(pxParam->sParamName, "KeyPassphrase")
						&& (pxParam->sParamValue[0] != '\0')) {
						HELP_PARAM_SET(tmpPxObjList1, "KeyPassphrase", pxParam->sParamValue, SOPT_OBJVALUE);
					}
				}
			} else if (!strcmp(tmpPxObjList->sObjName, objSSID)) {
				FOR_EACH_PARAM(tmpPxObjList, pxParam) {
					if (!strcmp(pxParam->sParamName, "Name")
					 && (pxParam->sParamValue[0] != '\0')) {
						if (!strcmp(pxParam->sParamValue, "wlan0")) {
							HELP_PARAM_SET(tmpPxObjList1, "SSIDReference", ap_param->SSID[0], SOPT_OBJVALUE);
							HELP_PARAM_SET(tmpPxObjList1, "InstanceNum", "1", SOPT_OBJVALUE);
						} else if (!strcmp(pxParam->sParamValue, "wlan2")) {
							HELP_PARAM_SET(tmpPxObjList1, "SSIDReference", ap_param->SSID[1], SOPT_OBJVALUE);
							HELP_PARAM_SET(tmpPxObjList1, "InstanceNum", "2", SOPT_OBJVALUE);
						}
					} else if (!strcmp(pxParam->sParamName, "SSID")
						 && (pxParam->sParamValue[0] != '\0')) {
						HELP_PARAM_SET(tmpPxObjList1, "SSID", pxParam->sParamValue, SOPT_OBJVALUE);
					}
				}
			}
		}

		if ((tmpPxObjList1 != NULL) && (radioCfg_indexArr[i] > 0)) {
			snprintf(sObjValue, MAX_LEN_PARAM_VALUE, "%s%d.", WIFI_RADIO_OBJECT_NAME, radioCfg_indexArr[i]);
			nRet = client_get_param_from_list(pxObjListWlan, sObjValue, 0, "AutoChannelEnable", sParamValue);
			if (nRet) {
				LOGF_LOG_ERROR("Failed to find AutoChannelEnable in DB\n");
				goto book_exit;
			}
			/*Saving both index value and parameter content to DB as index.value*/
			snprintf(sParamBackup, MAX_LEN_PARAM_VALUE, "%d.%s", radioCfg_indexArr[i], sParamValue);
			LOGF_LOG_DEBUG("Bookkeep radio configuration to DB for object index - %d with value %s\n", radioCfg_indexArr[i], sParamBackup);
			HELP_PARAM_SET(tmpPxObjList1, "AutoChannelEnable", sParamBackup, SOPT_OBJVALUE);

			snprintf(sObjValue, MAX_LEN_PARAM_VALUE, "%sX_LANTIQ_COM_Vendor", sObjValue);
			nRet = client_get_param_from_list(pxObjListWlan, sObjValue, 0, "WaveAcsUpdateTimeout", sParamValue);
			if (nRet) {
				LOGF_LOG_ERROR("Failed to find WaveAcsUpdateTimeout in DB\n");
				goto book_exit;
			}
			/*Saving both index value and parameter content to DB as index.value*/
			snprintf(sParamBackup, MAX_LEN_PARAM_VALUE, "%d.%s", radioCfg_indexArr[i], sParamValue);
			LOGF_LOG_DEBUG("Bookkeep radio configuration to DB for object index - %d with value %s\n", radioCfg_indexArr[i], sParamBackup);
			HELP_PARAM_SET(tmpPxObjList1, "WaveAcsUpdateTimeout", sParamBackup, SOPT_OBJVALUE);
		}
		/*If we reached here - Need to bookkeep the values to DB*/
		if (HELP_IS_EMPTY_OBJ_PARAM(pxBookObjTmp)) {
			/*Mark current VAP entry as enabled*/
			HELP_PARAM_SET(tmpPxObjList1, "Enable", "true", SOPT_OBJVALUE);
			LOGF_LOG_DEBUG("Copy bookkeep values for %s object:\n", tmpPxObjList->sObjName);
			HELP_PRINT_OBJ(pxBookObjTmp, 0x4); //to be removed
			client_help_copy_obj(pxBookObj, pxBookObjTmp, COPY_COMPLETE_OBJ);
		}
		CLIENT_HELP_DELETE_OBJ(pxBookObjTmp, EMPTY_OBJLIST);
		tmpPxObjList1 = NULL;
	}

book_exit:
	if (nRet == UGW_SUCCESS) {
		LOGF_LOG_DEBUG("Values to bookkeep:\n");
		HELP_PRINT_OBJ(pxBookObj, 0x4); //to be removed
	}
	CLIENT_HELP_DELETE_OBJ(pxBookObjTmp, FREE_OBJLIST);
	LOGF_LOG_DEBUG("Bookkeep function done with return code %d\n", nRet);
	return nRet;
}

/* =======================================================================================
 *  Function Name : client_disconnectSTAfromAP
 *  Description   : Helper function to disconnect STA VAP from remote AP
 * =======================================================================================*/
static int client_disconnectSTAfromAP(ObjList *pxObjListWlan)
{
	int nRet = UGW_SUCCESS;
	char sObjValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sProfileValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	ObjList *pxObjListNew = client_help_create_obj();
	ObjList *tmpPxObjList = NULL;
	ObjList *tmpPxObjList1 = NULL;
	ParamList *pxParam = NULL;

	if (!pxObjListNew || !pxObjListWlan) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto disconnect_exit;
	}

	LOGF_LOG_DEBUG("Looping on WLAN DB to find enabled EndPoint object\n");
	sObjValue[0] = '\0';
	FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
		if (!strstr(tmpPxObjList->sObjName, WIFI_ENDPOINT_OBJECT_NAME)
		 || (strlen(tmpPxObjList->sObjName) > strlen(WIFI_ENDPOINT_OBJECT_NAME) + 3)) {
			continue;
		}
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if (!strcmp(pxParam->sParamName, "Enable")
			 && (!is_stringFalse(pxParam->sParamValue))) {
				strncpy(sObjValue, tmpPxObjList->sObjName, MAX_LEN_PARAM_VALUE - 1);
				sObjValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
				break;
			}
		}
		if (sObjValue[0] != '\0') {
			break;
		}
	}
	if (sObjValue[0] == '\0'){
		LOGF_LOG_DEBUG("No active EndPoint connection found!\n");
		goto disconnect_exit;
	}
	snprintf(sProfileValue, MAX_LEN_PARAM_VALUE, "%sProfile.", sObjValue);
	LOGF_LOG_DEBUG("Looping on WLAN DB to find connected profile in object - %s\n", sObjValue);
	FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
		if (!strstr(tmpPxObjList->sObjName, sObjValue)) {
			continue;
		}
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if (!strcmp("Status", pxParam->sParamName)
			 && (!strcmp(pxParam->sParamValue, "Active"))) {
				LOGF_LOG_DEBUG("Disconnecting Station VAP\n");
				tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, tmpPxObjList->sObjName, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
				if (tmpPxObjList1 == NULL) {
					LOGF_LOG_ERROR("Failed to set object!!\n");
					nRet = UGW_FAILURE;
					goto disconnect_exit;
				}
				HELP_PARAM_SET(tmpPxObjList1, "Status", "Disabled", SOPT_OBJVALUE);
				HELP_PARAM_SET(tmpPxObjList1, "Priority", "10", SOPT_OBJVALUE);
			}
		}
	}

	LOGF_LOG_DEBUG("Finished preparing object to disconnect from STA AP:\n");
	if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListNew)) {
		HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
		/*Trigger SL request*/
		if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListNew) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto disconnect_exit;
		}
	} else {
		LOGF_LOG_ERROR("No active STA AP connection was found! Assum already disconnected!\n");
		nRet = UGW_SUCCESS;
		goto disconnect_exit;
	}

disconnect_exit:
	CLIENT_HELP_DELETE_OBJ(pxObjListNew, FREE_OBJLIST);
	return nRet;
}

/* =======================================================================================
 *  Function Name : client_configureGWAP
 *  Description   : Helper function to configure GW AP according to pre-saved parameters
 * =======================================================================================*/
static int client_configureGWAP(ObjList *pxBookObj, ObjList *pxMainObj, ObjList *pxObjListWlan)
{
	char sParamValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	char objNameStr[MAX_LEN_PARAM_VALUE];
	char SSIDRefObj[MAX_LEN_PARAM_VALUE];
	char autoChannelStr[MAX_LEN_PARAM_VALUE] = { '\0' };
	char acsStr[MAX_LEN_PARAM_VALUE] = { '\0' };
	char *str = NULL;
	int nRet = UGW_SUCCESS;
	ObjList *pxObjListNew = client_help_create_obj();
	ObjList *tmpPxObjList = NULL;
	ObjList *tmpPxObjList1 = NULL;
	ParamList *pxParam = NULL;
	bool entry_enable = false;

	if (!pxMainObj || !pxBookObj || !pxObjListNew) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto configure_exit;
	}

	FOR_EACH_OBJ(pxMainObj, tmpPxObjList) {
		if (!strstr(tmpPxObjList->sObjName, CLIENT_OBJECT_BOOKKEEP_NAME)) {
			continue;
		}
		entry_enable = false;
		nRet = client_get_param_from_list(pxMainObj, tmpPxObjList->sObjName, 0, "InstanceNum", sParamValue);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to read parameter from DB!\n");
			goto configure_exit;
		}
		if (!strcmp(sParamValue, "0") || sParamValue[0] == '\0') {
			LOGF_LOG_DEBUG("Current object %s do not include instance number information, instance number is %s\n", tmpPxObjList->sObjName, sParamValue);
			continue;
		}
		LOGF_LOG_DEBUG("Restore default values for entry %s\n", sParamValue);
		snprintf(objNameStr, MAX_LEN_PARAM_VALUE, "%s%s.", WIFI_ACCESSPOINT_OBJECT_NAME, sParamValue);
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			switch (pxParam->unParamId) {
			case DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_ENABLE:
				if (pxParam->sParamValue[0] != '\0') {
					tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, objNameStr, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
					if (tmpPxObjList1 == NULL) {
						LOGF_LOG_ERROR("Failed to set object!!\n");
						nRet = UGW_FAILURE;
						goto configure_exit;
					}
					HELP_PARAM_SET(tmpPxObjList1, "Enable", pxParam->sParamValue, SOPT_OBJVALUE);
					entry_enable = true;
				}
				break;
			}
		}
		if (!entry_enable) {
			LOGF_LOG_DEBUG("Current bookkeep object %s do not include enabled VAP to be restored\n", tmpPxObjList->sObjName);
			break;
		}

		nRet = client_get_param_from_list(pxObjListWlan, objNameStr, 0, "SSIDReference", SSIDRefObj);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to read data from DB %s\n", objNameStr);
			goto configure_exit;
		}

		snprintf(objNameStr, MAX_LEN_PARAM_VALUE, "%s%s.Security.", WIFI_ACCESSPOINT_OBJECT_NAME, sParamValue);
		tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, objNameStr, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
		if (tmpPxObjList1 == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			nRet = UGW_FAILURE;
			goto configure_exit;
		}

		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			switch (pxParam->unParamId) {
			case DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_MODEENABLED:
				if (pxParam->sParamValue[0] != '\0') {
					HELP_PARAM_SET(tmpPxObjList1, "ModeEnabled", pxParam->sParamValue, SOPT_OBJVALUE);
				}
				break;
			case DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_WEPKEY:
				if (pxParam->sParamValue[0] != '\0') {
					HELP_PARAM_SET(tmpPxObjList1, "WEPKey", pxParam->sParamValue, SOPT_OBJVALUE);
				}
				break;
			case DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_KEYPASSPHRASE:
				if (pxParam->sParamValue[0] != '\0') {
					HELP_PARAM_SET(tmpPxObjList1, "KeyPassphrase", pxParam->sParamValue, SOPT_OBJVALUE);
				}
				break;
			case DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_AUTOCHANNELENABLE:
				if (pxParam->sParamValue[0] != '\0') {
					strncpy(autoChannelStr, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					autoChannelStr[MAX_LEN_PARAM_VALUE - 1] = '\0';
				}
				break;
			case DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_WAVEACSUPDATETIMEOUT:
				if (pxParam->sParamValue[0] != '\0') {
					strncpy(acsStr, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					acsStr[MAX_LEN_PARAM_VALUE - 1] = '\0';
				}
				break;
			default:
				break;
			}
		}

		if ((autoChannelStr[0] != '\0') && (acsStr[0] != '\0')) {
			str = strtok(autoChannelStr, ".");
			snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "%s%s.", WIFI_RADIO_OBJECT_NAME, str);
			tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, sParamValue, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
			if (tmpPxObjList1 == NULL) {
				LOGF_LOG_ERROR("Failed to set object!!\n");
				nRet = UGW_FAILURE;
				goto configure_exit;
			}
			/*Proceed to bookkeeped value*/
			str = autoChannelStr + strlen(str) + 1;
			HELP_PARAM_SET(tmpPxObjList1, "AutoChannelEnable", str, SOPT_OBJVALUE);
			LOGF_LOG_DEBUG("Setting bookkeeped value %s to object - %s\n", str, sParamValue);

			snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "%sX_LANTIQ_COM_Vendor", sParamValue);
			tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, sParamValue, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
			if (tmpPxObjList1 == NULL) {
				LOGF_LOG_ERROR("Failed to set object!!\n");
				nRet = UGW_FAILURE;
				goto configure_exit;
			}
			str = strtok(acsStr, ".");
			/*Proceed to object name*/
			str = acsStr + strlen(str) + 1;
			HELP_PARAM_SET(tmpPxObjList1, "WaveAcsUpdateTimeout", str, SOPT_OBJVALUE);
			LOGF_LOG_DEBUG("Setting bookkeeped value %s to object - %s\n", str, sParamValue);
		}

		tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, SSIDRefObj, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
		if (tmpPxObjList1 == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			nRet = UGW_FAILURE;
			goto configure_exit;
		}
		nRet = client_get_param_from_list(pxMainObj, tmpPxObjList->sObjName, 0, "SSID", sParamValue);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to read parameter from DB!\n");
			goto configure_exit;
		}
		HELP_PARAM_SET(tmpPxObjList1, "SSID", sParamValue, SOPT_OBJVALUE);
	}

	if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListNew)) {
		LOGF_LOG_DEBUG("Restore previous AP values:\n");
		HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
		/*Trigger SL request*/
		if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListNew) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto configure_exit;
		}
	}

configure_exit:
	CLIENT_HELP_DELETE_OBJ(pxObjListNew, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_configureBridgeGW
 *  Description   : Helper function to set bridge configuration to GW mode
 * ===================================================================================*/
static int client_configureBridgeGW(ObjList *pxBookObj, ObjList *pxMainObj)
{
	int nRet = UGW_SUCCESS, entry_num = 0;
	char sParamValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sBookkeepValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sObjName[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sObjBridgeEntry[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sLowerLayer[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sSubnetMask[MAX_LEN_PARAM_VALUE] = { '\0' };
	bool entry_found = false;
	ObjList *pxObjListNew = client_help_create_obj();
	ObjList *pxObjListETH = client_help_create_obj();
	ObjList *pxObjListNet = client_help_create_obj();
	ObjList *pxObjListGroup = client_help_create_obj();
	ParamList *pxParam = NULL;
	ObjList *tmpPxObjList = NULL;
	ObjList *tmpPxObjList1 = NULL;
	NotifyObjData xNotify;

	if (!pxObjListNew || !pxObjListETH || !pxObjListNet || !pxObjListGroup || !pxBookObj) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}

	LOGF_LOG_DEBUG("Configuring Linux bridge to match GW mode\n");

	if ((nRet = client_get_object_from_db(pxObjListETH, SOPT_OBJVALUE, NETWORK_IP_INTERFACE_OBJECT_NAME))) {
		LOGF_LOG_ERROR("Failed to read data from DB!\n");
		goto bridge_exit;
	}
	/*Loop on ETH DB to find br-lan entry*/
	FOR_EACH_OBJ(pxObjListETH, tmpPxObjList) {
		if (strstr(tmpPxObjList->sObjName, NETWORK_IP_INTERFACE_OBJECT_NAME)
		 && (strlen(tmpPxObjList->sObjName) < strlen(NETWORK_IP_INTERFACE_OBJECT_NAME) + 3)) {
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "Name")
				 && (!strcmp(pxParam->sParamValue, DEFAULT_BRIDGE_NAME))){
					entry_num = client_getInstanceNumFromObjectName(tmpPxObjList->sObjName);
					if (entry_num < 0) {
						LOGF_LOG_ERROR("Failed to parse instance number!\n");
						nRet = UGW_FAILURE;
						goto bridge_exit;
					}
					strncpy(sObjBridgeEntry, tmpPxObjList->sObjName, MAX_LEN_PARAM_VALUE - 1);
					sObjBridgeEntry[MAX_LEN_PARAM_VALUE - 1] = '\0';
					LOGF_LOG_DEBUG("Found default bridge entry in DB = %d entry is %s\n", entry_num, sObjBridgeEntry);
					break;
				}
			}
		}
		if (entry_num > 0)
			break;
	}

	if (entry_num < 1) {
		LOGF_LOG_ERROR("Failed to find br-lan entry in DB\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	snprintf(sObjName, MAX_LEN_PARAM_VALUE, "%s%d.IPv4Address.1.", NETWORK_IP_INTERFACE_OBJECT_NAME, entry_num);

	/*Read current ETH DB values*/
	CLIENT_HELP_DELETE_OBJ(pxObjListETH, EMPTY_OBJLIST);
	if ((nRet = client_get_object_from_db(pxObjListETH, SOPT_OBJVALUE, NETWORK_DHCP4_CLIENT_OBJECT_NAME))) {
		LOGF_LOG_ERROR("Failed to read data from DB!\n");
		goto bridge_exit;
	}

	/*This section is sensestive! keep current structure*/
	tmpPxObjList1= NULL;
	LOGF_LOG_DEBUG("Removing DHCP client entry if exist\n");
	FOR_EACH_OBJ(pxObjListETH, tmpPxObjList) {
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if (!strcmp(pxParam->sParamName, "Interface")
			 && (strstr(pxParam->sParamValue, sObjBridgeEntry))) {
				tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, tmpPxObjList->sObjName, NO_ARG_VALUE, OBJOPT_DEL, SOPT_OBJVALUE);
				if (tmpPxObjList1 == NULL) {
					LOGF_LOG_ERROR("Failed to set object!!\n");
					nRet = UGW_FAILURE;
					goto bridge_exit;
				}
				LOGF_LOG_DEBUG("Found DHCP client entry %s - remove it\n", tmpPxObjList->sObjName);
				break;
			}
		}
		if (tmpPxObjList1 != NULL) {
			break;
		}
	}

	/*Read back IP value from bookkeep*/
	FOR_EACH_OBJ(pxMainObj, tmpPxObjList) {
		if (tmpPxObjList->unOid != DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP) {
			continue;
		}
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_SSID)
			 && (!strcmp(pxParam->sParamValue, DEFAULT_BRIDGE_NAME))) {
				entry_found = true;
			} else if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_VAPPREVIOUSVALUE) {
				strncpy(sParamValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
				sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
			}
		}
		if (entry_found) {
			if (!isValidIpAddress(sParamValue)) {
				LOGF_LOG_ERROR("Could not recover a valid IP address for br-lan - Setting to default\n");
				strncpy(sParamValue, DEFAULT_BRIDGE_IP, MAX_LEN_PARAM_VALUE - 1);
				sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
			}
			break;
		}
	}

	LOGF_LOG_DEBUG("Read current SubnetMask from DB\n");
	CLIENT_HELP_DELETE_OBJ(pxObjListETH, EMPTY_OBJLIST);
	nRet = client_get_object_from_db(pxObjListETH, SOPT_OBJVALUE, sObjName);
	if (nRet) {
		LOGF_LOG_ERROR("Failed to read data from DB %s!\n", sObjName);
		goto bridge_exit;
	}
	nRet = client_get_param_from_list(pxObjListETH, sObjName, 0, "SubnetMask", sSubnetMask);
	if (nRet) {
		LOGF_LOG_INFO("Failed to read SubnetMask from DB! Setting default value\n");
		strncpy(sSubnetMask, SUBNETMASK_VALUE, MAX_LEN_PARAM_VALUE - 1);
		sSubnetMask[MAX_LEN_PARAM_VALUE - 1] = '\0';
	}
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, sObjName, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	HELP_PARAM_SET(tmpPxObjList, "IPAddress", sParamValue, SOPT_OBJVALUE);
	HELP_PARAM_SET(tmpPxObjList, "SubnetMask", sSubnetMask, SOPT_OBJVALUE);

	if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListNew)) {
		HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
		/*Trigger SL request*/
		if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListNew) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto bridge_exit;
		}
	}

	CLIENT_HELP_DELETE_OBJ(pxObjListNew, EMPTY_OBJLIST);


	LOGF_LOG_DEBUG("Enabling DHCP server and DNS server\n");
	/*Start dhcpd and Enable it for following reboots*/
	system("/etc/init.d/odhcpd start; /etc/init.d/odhcpd enable");

	/*DNS*/
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, NETWORK_DNS_RELAY_OBJECT_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	HELP_PARAM_SET(tmpPxObjList, "Enable", "1", SOPT_OBJVALUE);
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, NETWORK_DNS_CLIENT_RELAY_OBJECT_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	HELP_PARAM_SET(tmpPxObjList, "Enable", "1", SOPT_OBJVALUE);
	/*Enabling DHCPv4 and DHCPv6 (No need to enable Relay)*/
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, NETWORK_DHCP4_OBJECT_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	HELP_PARAM_SET(tmpPxObjList, "Enable", "1", SOPT_OBJVALUE);
#if 0
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, NETWORK_DHCP6_OBJECT_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	HELP_PARAM_SET(tmpPxObjList, "Enable", "true", SOPT_OBJVALUE);
#endif

	if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListNew)) {
		HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
		/*Trigger SL request*/
		if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListNew) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto bridge_exit;
		}
		CLIENT_HELP_DELETE_OBJ(pxObjListNew, EMPTY_OBJLIST);
	}

	/*Read ETH DB object to find relevant WAN entry number*/
	if ((nRet = client_get_object_from_db(pxObjListNet, SOPT_OBJVALUE, NETWORK_WANCONNECTION_OBJECT_NAME))) {
		LOGF_LOG_INFO("Failed to read data from DB %s! Assum no WAN interface exist\n", NETWORK_WANCONNECTION_OBJECT_NAME);
		nRet = UGW_SUCCESS;
	} else {
		if ((nRet = client_get_object_from_db(pxObjListGroup, SOPT_OBJVALUE, NETWORK_WANGROUP_OBJECT_NAME))) {
			LOGF_LOG_INFO("Failed to read data from DB!\n");
			goto bridge_exit;
		}
		FOR_EACH_OBJ(pxObjListNet, tmpPxObjList) {
			if (!strstr(tmpPxObjList->sObjName, NETWORK_WANCONNECTION_OBJECT_NAME)
			 || (strlen(tmpPxObjList->sObjName) > strlen(NETWORK_WANCONNECTION_OBJECT_NAME) + 3)) {
				continue;
			}
			sParamValue[0] = '\0';
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "BaseInterfaceName")){
					strncpy(sParamValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
				}
			}
			if (sParamValue[0] != '\0') {
				entry_found = false;
				sBookkeepValue[0] = '\0';
				LOGF_LOG_DEBUG("Found WAN entry %s - Check if it was enabled in original configuration\n", sParamValue);
				FOR_EACH_OBJ(pxMainObj, tmpPxObjList) {
					if (tmpPxObjList->unOid != DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP) {
						continue;
					}
					FOR_EACH_PARAM(tmpPxObjList, pxParam) {
						if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_SSID)
						 && (!strcmp(pxParam->sParamValue, sParamValue))) {
							entry_found = true;
						} else if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_VAPPREVIOUSVALUE) {
							strncpy(sBookkeepValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
							sBookkeepValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
						}
					}
					if (entry_found) {
						break;
					}
				}
				if (sBookkeepValue[0] == '\0') {
					LOGF_LOG_INFO("Could not parse WAN previous status in DB - Assume it was disabled\n");
				} else {
					nRet = client_get_param_from_list(pxObjListGroup, NETWORK_WANGROUP_OBJECT_NAME, 1, "MappingLowerLayer", sLowerLayer);
					if (nRet) {
						LOGF_LOG_ERROR("Failed to get parameter from DB!\n");
						goto bridge_exit;
					}
					pxParam = HELP_CREATE_PARAM(SOPT_OBJVALUE);
					if (!pxParam) {
						LOGF_LOG_ERROR("Failed to create parameter pointer!\n");
						nRet = UGW_FAILURE;
						goto bridge_exit;
					}
					HELP_ONLY_PARAM_SET(pxParam, "Type", "WAN", SOPT_OBJVALUE);
					HELP_ONLY_PARAM_SET(pxParam, "Ifname", sParamValue, SOPT_OBJVALUE);
					HELP_ONLY_PARAM_SET(pxParam, "Protos", "Static,DHCP,Auto,Bridge", SOPT_OBJVALUE);
					HELP_ONLY_PARAM_SET(pxParam, "Enable", "true", SOPT_OBJVALUE);
					HELP_ONLY_PARAM_SET(pxParam, "LinkEnable", sBookkeepValue, SOPT_OBJVALUE);
					HELP_ONLY_PARAM_SET(pxParam, "L1ObjectName", sLowerLayer, SOPT_OBJVALUE);
					memset(&xNotify, 0x0, sizeof(xNotify));
					xNotify.unNotifyId = NOTIFY_INTERFACE_REGISTRATION;
					xNotify.pxParamList = pxParam;
					if(SERVD_API_NOTIFY(&xNotify, NOTIFY_ASYNC) != UGW_SUCCESS) {
						LOGF_LOG_CRITICAL("Sending notification failed !\n");
					}

					break;
				}
			}
		}
	}

bridge_exit:
	LOGF_LOG_DEBUG("Change of Bridge value to GW mode done with return code %d\n", nRet);
	CLIENT_HELP_DELETE_OBJ(pxObjListNew, FREE_OBJLIST);
	CLIENT_HELP_DELETE_OBJ(pxObjListNet, FREE_OBJLIST);
	CLIENT_HELP_DELETE_OBJ(pxObjListGroup, FREE_OBJLIST);
	CLIENT_HELP_DELETE_OBJ(pxObjListETH, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_configureBridgeRepeater
 *  Description   : Helper function to set bridge configuration to repeater mode
 * ===================================================================================*/
static int client_configureBridgeRepeater(ObjList *pxBookObj, ObjList *pxMainObj, ObjList *pxObjListWlan)
{
	int nRet = UGW_SUCCESS, entry_num = 0, counter = 0;
	char sParamValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sLowerLayer[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sIPv4Addr[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sIPv4AddrObjValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	ObjList *pxObjListNew = client_help_create_obj();
	ObjList *pxObjListNet = client_help_create_obj();
	ObjList *pxObjListETH = client_help_create_obj();
	ObjList *pxObjListGroup = client_help_create_obj();
	ParamList *pxParam = NULL;
	ObjList *tmpPxObjList = NULL;
	ObjList *tmpPxObjList1 = NULL;
	NotifyObjData xNotify;
	bool dhcp_client = true, profile_enable = false;

	if (!pxObjListNew || !pxObjListNet || !pxMainObj || !pxBookObj || !pxObjListWlan || !pxObjListETH || !pxObjListGroup) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}

	LOGF_LOG_DEBUG("Configuring Linux bridge to match repeater mode\n");
	LOGF_LOG_DEBUG("Disabling DHCP server and DNS server\n");
	/*DHCPv4*/
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, NETWORK_DHCP4_OBJECT_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	HELP_PARAM_SET(tmpPxObjList, "Enable", "0", SOPT_OBJVALUE);
	/*DHCPv4 Relay*/
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, NETWORK_DHCP4_RELAY_OBJECT_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	HELP_PARAM_SET(tmpPxObjList, "Enable", "0", SOPT_OBJVALUE);
	/*DHCPv6 - Currently disabled - ToDo - Enable once supported*/
	#if 0
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, NETWORK_DHCP6_OBJECT_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	HELP_PARAM_SET(tmpPxObjList, "Enable", "false", SOPT_OBJVALUE);
	#endif
	/*DNS*/
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, NETWORK_DNS_RELAY_OBJECT_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	HELP_PARAM_SET(tmpPxObjList, "Enable", "0", SOPT_OBJVALUE);
	tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, NETWORK_DNS_CLIENT_RELAY_OBJECT_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	HELP_PARAM_SET(tmpPxObjList, "Enable", "0", SOPT_OBJVALUE);

	if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListNew)) {
		HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
		/*Trigger SL request*/
		if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListNew) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto bridge_exit;
		}
	}

	LOGF_LOG_DEBUG("Disabling WAN connection\n");

	/*Read ETH DB object to find relevant WAN entry number*/
	if ((nRet = client_get_object_from_db(pxObjListNet, SOPT_OBJVALUE, NETWORK_WANCONNECTION_OBJECT_NAME))) {
		LOGF_LOG_INFO("Failed to read data from DB %s! Assum no WAN interface exist\n", NETWORK_WANCONNECTION_OBJECT_NAME);
		nRet = UGW_SUCCESS;
	} else {
		if ((nRet = client_get_object_from_db(pxObjListGroup, SOPT_OBJVALUE, NETWORK_WANGROUP_OBJECT_NAME))) {
			LOGF_LOG_INFO("Failed to read data from DB!\n");
			goto bridge_exit;
		}
		FOR_EACH_OBJ(pxObjListNet, tmpPxObjList) {
			if (!strstr(tmpPxObjList->sObjName, NETWORK_WANCONNECTION_OBJECT_NAME)
			 || (strlen(tmpPxObjList->sObjName) > strlen(NETWORK_WANCONNECTION_OBJECT_NAME) + 3)) {
				continue;
			}
			sParamValue[0] = '\0';
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "BaseInterfaceName")){
					strncpy(sParamValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
				}
			}
			if (sParamValue[0] != '\0') {
				LOGF_LOG_DEBUG("Found enabled WAN entry - Disabling it\n");
				/*Read enabled entry from WAN group - assuming only 1 WAN is enabled*/
				HELP_PRINT_OBJ(pxObjListGroup, 0x4); //to be removed
				nRet = client_get_param_from_list(pxObjListGroup, NETWORK_WANGROUP_OBJECT_NAME, 1, "MappingLowerLayer", sLowerLayer);
				if (nRet) {
					LOGF_LOG_ERROR("Failed to get parameter from DB!\n");
					goto bridge_exit;
				}
				pxParam = HELP_CREATE_PARAM(SOPT_OBJVALUE);
				if (!pxParam) {
					LOGF_LOG_ERROR("Failed to create parameter pointer!\n");
					nRet = UGW_FAILURE;
					goto bridge_exit;
				}
				HELP_ONLY_PARAM_SET(pxParam, "Type", "WAN", SOPT_OBJVALUE);
				HELP_ONLY_PARAM_SET(pxParam, "Ifname", sParamValue, SOPT_OBJVALUE);
				HELP_ONLY_PARAM_SET(pxParam, "Protos", "Static,DHCP,Auto,Bridge", SOPT_OBJVALUE);
				HELP_ONLY_PARAM_SET(pxParam, "Enable", "false", SOPT_OBJVALUE);
				HELP_ONLY_PARAM_SET(pxParam, "LinkEnable", "false", SOPT_OBJVALUE);
				HELP_ONLY_PARAM_SET(pxParam, "L1ObjectName", sLowerLayer, SOPT_OBJVALUE);
				memset(&xNotify, 0x0, sizeof(xNotify));
				xNotify.unNotifyId = NOTIFY_INTERFACE_REGISTRATION;
				xNotify.pxParamList = pxParam;
				if(SERVD_API_NOTIFY(&xNotify, NOTIFY_ASYNC) != UGW_SUCCESS) {
					LOGF_LOG_CRITICAL("Sending notification failed !\n");
				}

				/*Bookkeep values*/
				tmpPxObjList1 = HELP_OBJECT_SET(pxBookObj, CLIENT_OBJECT_BOOKKEEP_NAME, NO_ARG_VALUE, OBJOPT_ADD, SOPT_OBJVALUE);
				if (tmpPxObjList1 == NULL) {
					LOGF_LOG_ERROR("Failed to set object!!\n");
					nRet = UGW_FAILURE;
					goto bridge_exit;
				}
				HELP_PARAM_SET(tmpPxObjList1, "SSID", sParamValue, SOPT_OBJVALUE);
				HELP_PARAM_SET(tmpPxObjList1, "VAPPreviousValue", "true", SOPT_OBJVALUE);

				break;
			}
		}
	}

	/*By default bridge is set to manual IP - Check to see what user requested*/
	sParamValue[0] = '\0';
	FOR_EACH_OBJ(pxMainObj, tmpPxObjList) {
		if (tmpPxObjList->unOid != DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE) {
			continue;
		}
		profile_enable = false;
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_MANUALIP)
			 && (!is_stringFalse(pxParam->sParamValue))) {
				dhcp_client = false;
			} else if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_MANAGEMENTIP) {
				strncpy(sParamValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
				sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
			} else if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_ENABLE) {
				profile_enable = !(is_stringFalse(pxParam->sParamValue));
			}
		}
		if (profile_enable) {
			break;
		}
	}
	if (!profile_enable) {
		LOGF_LOG_ERROR("No active profile found in DB!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	CLIENT_HELP_DELETE_OBJ(pxObjListNet, EMPTY_OBJLIST);
	if ((nRet = client_get_object_from_db(pxObjListNet, SOPT_OBJVALUE, NETWORK_IP_INTERFACE_OBJECT_NAME))) {
		LOGF_LOG_ERROR("Failed to read data from DB!\n");
		goto bridge_exit;
	}
	/*Loop on ETH DB to find br-lan entry*/
	sIPv4Addr[0] = '\0';
	FOR_EACH_OBJ(pxObjListNet, tmpPxObjList) {
		if (strstr(tmpPxObjList->sObjName, NETWORK_IP_INTERFACE_OBJECT_NAME)
		 && (strlen(tmpPxObjList->sObjName) < strlen(NETWORK_IP_INTERFACE_OBJECT_NAME) + 3)) {
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "Name")
				 && (!strcmp(pxParam->sParamValue, DEFAULT_BRIDGE_NAME))){
					entry_num = client_getInstanceNumFromObjectName(tmpPxObjList->sObjName);
					if (entry_num < 0) {
						LOGF_LOG_ERROR("Failed to parse instance number!\n");
						nRet = UGW_FAILURE;
						goto bridge_exit;
					}
					LOGF_LOG_DEBUG("Found default bridge entry in DB = %d\n", entry_num);
					snprintf(sIPv4AddrObjValue, MAX_LEN_PARAM_VALUE, "%s.%s", tmpPxObjList->sObjName, NETWORK_IP4_ADDRESS);
					LOGF_LOG_DEBUG("Looking for %s object\n", sIPv4AddrObjValue);
					sIPv4Addr[0] = '\0';
					break;
				}
			}
		} else if (strstr(tmpPxObjList->sObjName, sIPv4AddrObjValue)
			&& (entry_num > 0)) {
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "IPAddress")) {
					LOGF_LOG_DEBUG("Matching IP address for br-lan entry is %s\n", pxParam->sParamValue);
					strncpy(sIPv4Addr, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					sIPv4Addr[MAX_LEN_PARAM_VALUE - 1] = '\0';
				}
			}
		}

		if ((sIPv4Addr[0] != '\0') && (entry_num > 0)) {
			break;
		}
	}

	if (sIPv4Addr[0] == '\0') {
		LOGF_LOG_ERROR("Failed to find br-lan entry and valid IP in DB\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	CLIENT_HELP_DELETE_OBJ(pxObjListNew, EMPTY_OBJLIST);

	if (dhcp_client) {
		LOGF_LOG_DEBUG("Configure bridge to work as DHCP client\n");
		snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "%s%d.", NETWORK_IP_INTERFACE_OBJECT_NAME, entry_num);
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, NETWORK_DHCP4_CLIENT_OBJECT_NAME, NO_ARG_VALUE, OBJOPT_ADD, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			nRet = UGW_FAILURE;
			goto bridge_exit;
		}
		HELP_PARAM_SET(tmpPxObjList, "Interface", sParamValue, SOPT_OBJVALUE);
	} else {
		if (sParamValue[0] == '\0' || !isValidIpAddress(sParamValue)) {
			LOGF_LOG_ERROR("Manual IP requested without a valid IP value!\n");
			nRet = UGW_FAILURE;
			goto bridge_exit;
		}
		LOGF_LOG_DEBUG("Configure bridge to work with manual IP %s\n", sParamValue);
		snprintf(sIPv4AddrObjValue, MAX_LEN_PARAM_VALUE, "%s%d.IPv4Address.1.", NETWORK_IP_INTERFACE_OBJECT_NAME, entry_num);
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, sIPv4AddrObjValue, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			nRet = UGW_FAILURE;
			goto bridge_exit;
		}
		HELP_PARAM_SET(tmpPxObjList, "IPAddress", sParamValue, SOPT_OBJVALUE);
	}

	if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListNew)) {
		HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
		/*Trigger SL request*/
		if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListNew) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto bridge_exit;
		}
	}

	LOGF_LOG_DEBUG("Stop odhcpd and disable it from running\n");
	system("/etc/init.d/odhcpd stop; /etc/init.d/odhcpd disable");

	/*Bookkeep values*/
	tmpPxObjList = HELP_OBJECT_SET(pxBookObj, CLIENT_OBJECT_BOOKKEEP_NAME, NO_ARG_VALUE, OBJOPT_ADD, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set object!!\n");
		nRet = UGW_FAILURE;
		goto bridge_exit;
	}
	HELP_PARAM_SET(tmpPxObjList, "SSID", DEFAULT_BRIDGE_NAME, SOPT_OBJVALUE);
	HELP_PARAM_SET(tmpPxObjList, "VAPPreviousValue", sIPv4Addr, SOPT_OBJVALUE);

	if (dhcp_client) {
		/*This is a WA to solve WLANSW-4867 - See description in the JIRA*/
		for (counter = 1; counter <= NUM_SUPPORTED_AP; counter++) {
			strncpy(sParamValue, "false", MAX_LEN_PARAM_VALUE);
			client_get_param_from_list(pxMainObj, CLIENT_OBJECT_PROFILE_NAME, counter, "Enable", sParamValue);
			if (!is_stringFalse(sParamValue)) {
				LOGF_LOG_DEBUG("Adding interface for entry %d to be used by dhcp client\n", counter);
				if (counter == 1) {
					/*First entry in profile corresponds to WLAN1*/
					system("brctl addif br-lan wlan1");
				} else {
					/*First entry in profile corresponds to WLAN3*/
					system("brctl addif br-lan wlan3");
				}
			}
		}
		/*Verify that br-lan received IP*/
		counter = 0;
		do {
			counter++;
			sParamValue[0] = '\0';
			LOGF_LOG_DEBUG("Check number %d if bridge received IP address\n", counter);
			if ((nRet = client_getInterfaceIP(DEFAULT_BRIDGE_NAME, sParamValue))) {
				LOGF_LOG_ERROR("Failed to get interface name in attempt %d!\n", counter);
			}
		} while (!isValidIpAddress(sParamValue) && !sleep(5) && counter < 6);

		if (counter > 5) {
			LOGF_LOG_ERROR("Failed to set IP address on bridge Fail to complete...\n");
			nRet = UGW_FAILURE;
			goto bridge_exit;
		}
	}

	LOGF_LOG_DEBUG("Notify WLAN that bridge configuration was changed\n");
	memset(&xNotify, 0x0, sizeof(xNotify));
	xNotify.unNotifyId = NOTIFY_WIFI_BRIDGE_RELOAD;
	xNotify.pxParamList = NULL;
	if(SERVD_API_NOTIFY(&xNotify, NOTIFY_SYNC) != UGW_SUCCESS) {
		LOGF_LOG_CRITICAL("Sending notification failed !\n");
	}

bridge_exit:
	CLIENT_HELP_DELETE_OBJ(pxObjListNew, FREE_OBJLIST);
	CLIENT_HELP_DELETE_OBJ(pxObjListNet, FREE_OBJLIST);
	CLIENT_HELP_DELETE_OBJ(pxObjListGroup, FREE_OBJLIST);
	CLIENT_HELP_DELETE_OBJ(pxObjListETH, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_configureRepeaterAP
 *  Description   : Helper function to configure local repeater AP
 * ===================================================================================*/
static int client_configureRepeaterAP(ObjList *pxBookObj, ObjList *pxObjListWlan, ObjList *pxObjListMain, AP_params *ap_param)
{
	char sParamValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	int nRet = UGW_SUCCESS, index, iteration_count = 0, i;
	int bookkeep_indexArr[NUM_SUPPORTED_AP];
	int radioCfg_indexArr[NUM_SUPPORTED_AP];
	bool rule_enable = false;
	ObjList *tmpPxObjList = NULL;
	ObjList *tmpPxObjList1 = NULL;
	ObjList *pxObjListNew =  client_help_create_obj();
	ParamList *pxParam = NULL;
	ParamList *pxParam1 = NULL;

	if (!pxObjListNew) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto configure_exit;
	}

	/*init bookkeep values*/
	for (i = 0; i < NUM_SUPPORTED_AP; i++) {
		bookkeep_indexArr[i] = 0;
		radioCfg_indexArr[i] = 0;
	}
	/*Init all radio to disable as default*/
	for (index = 0; index < NUM_SUPPORTED_AP; index++) {
		strncpy(ap_param->Enable[index], "false", MAX_LEN_PARAM_VALUE);
	}

	iteration_count = 0;
	LOGF_LOG_DEBUG("Check which AP network requested by client and configure them accordingly\n");
	FOR_EACH_OBJ(pxObjListMain, tmpPxObjList) {
		if (tmpPxObjList->unOid != DEVICE_X_LANTIQ_COM_CLIENTMODE_RULE) {
			continue;
		}
		/*Set wlan0 to index 0 and wlan2 to index 1*/
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_RULE_RADIOTYPE) {
				if (!strcmp(pxParam->sParamValue, RADIO_2_4)) {
					index = 0;
					break;
				} else {
					index = 1;
					break;
				}
			}
		}
		LOGF_LOG_DEBUG("Saving information for index=%d\n", index);
		ap_param->SSID[index][0] = '\0';
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_RULE_ENABLE) {
				strncpy(ap_param->Enable[index], pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
				ap_param->Enable[index][MAX_LEN_PARAM_VALUE - 1] = '\0';
			} else if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_RULE_SSID) {
				strncpy(ap_param->SSID[index], pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
				ap_param->SSID[index][MAX_LEN_PARAM_VALUE - 1] = '\0';
			} else if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_RULE_RADIOTYPE) {
				strncpy(ap_param->radio[index], pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
				ap_param->radio[index][MAX_LEN_PARAM_VALUE - 1] = '\0';
			} else if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_RULE_PROFILEREFERENCE) {
				strncpy(sParamValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
				sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
			}
		}
		if (!is_stringFalse(ap_param->Enable[index])) {
			rule_enable = true;
		}
		if (ap_param->SSID[index][0] == '\0') {
			FOR_EACH_OBJ(pxObjListMain, tmpPxObjList1) {
				if (tmpPxObjList1->unOid != DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE
				&& (strcmp(tmpPxObjList1->sObjName, sParamValue))) {
					continue;
				}
				FOR_EACH_PARAM(tmpPxObjList1, pxParam1) {
					if (pxParam1->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_SSID) {
						strncpy(ap_param->SSID[index], pxParam1->sParamValue, MAX_LEN_PARAM_VALUE - 1);
						ap_param->SSID[index][MAX_LEN_PARAM_VALUE - 1] = '\0';
					} else if ((pxParam1->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_ENABLE)
						&& (is_stringFalse(pxParam1->sParamValue))) {
						/*In this case the profile is disabled, so move to next one*/
						ap_param->SSID[index][0] = '\0';
						break;
					}
				}
				if (ap_param->SSID[index][0] != '\0') {
					break;
				}
			}
			if (ap_param->SSID[index][0] == '\0') {
				LOGF_LOG_ERROR("No valid SSID found in either Rule or Profile entry!\n");
				nRet = UGW_FAILURE;
				goto configure_exit;
			}
			LOGF_LOG_DEBUG("User did not set Rule SSID name - use SSID value %s from profile %s\n", sParamValue, ap_param->SSID[index]);
		}
		/*Rules are set per profile - so if at least one rule is enabled - break*/
		if ((iteration_count % NUM_SUPPORTED_AP) == (NUM_SUPPORTED_AP - 1)
		  && rule_enable) {
			LOGF_LOG_DEBUG("Found enabled rule - continue to WLAN interface\n");
			break;
		}
		iteration_count++;
	}

	/*Find enabled profile to be used later on*/
	for (index = 1; index <= NUM_SUPPORTED_AP; index++) {
		nRet = client_get_param_from_list(pxObjListMain, CLIENT_OBJECT_PROFILE_NAME, index, "Enable", sParamValue);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to get parameter from DB!\n");
			goto configure_exit;
		}
		if (!is_stringFalse(sParamValue)) {
			LOGF_LOG_DEBUG("Enabled profile is %s%d\n", CLIENT_OBJECT_PROFILE_NAME, index);
			break;
		}
	}

	FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
		if (strstr(tmpPxObjList->sObjName, WIFI_ACCESSPOINT_OBJECT_NAME)
		 && (strlen(tmpPxObjList->sObjName) < strlen(WIFI_ACCESSPOINT_OBJECT_NAME) + 3)) {
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "SSIDReference")
				 && (!strcmp(pxParam->sParamValue, "Device.WiFi.SSID.1"))) {
					if (is_stringFalse(ap_param->Enable[0]) || ap_param->SSID[0] == '\0') {
						LOGF_LOG_DEBUG("Device.WiFi.SSID.1 is not set! Continue to next entry\n");
						index = client_getInstanceNumFromObjectName(tmpPxObjList->sObjName);
						if (index < 0) {
							LOGF_LOG_ERROR("Failed to parse instance number!\n");
							nRet = UGW_FAILURE;
							goto configure_exit;
						}
						/*Save index value for future bookkeep of main VAP*/
						bookkeep_indexArr[0] = index;
						continue;
					}
					tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, tmpPxObjList->sObjName, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
					if (tmpPxObjList1 == NULL) {
						LOGF_LOG_ERROR("Failed to set object!!\n");
						nRet = UGW_FAILURE;
						goto configure_exit;
					}
					/*Set relevant parameters*/
					HELP_PARAM_SET(tmpPxObjList1, "Enable", ap_param->Enable[0], SOPT_OBJVALUE);

					index = client_getInstanceNumFromObjectName(tmpPxObjList->sObjName);
					if (index < 0) {
						LOGF_LOG_ERROR("Failed to parse instance number!\n");
						nRet = UGW_FAILURE;
						goto configure_exit;
					}
					snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "%s%d.Security.", WIFI_ACCESSPOINT_OBJECT_NAME, index);
					LOGF_LOG_DEBUG("Setting security for object %s\n", sParamValue);
					tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, sParamValue, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
					if (tmpPxObjList1 == NULL) {
						LOGF_LOG_ERROR("Failed to set object!!\n");
						nRet = UGW_FAILURE;
						goto configure_exit;
					}
					if (ap_param->security.ModeEnabled[0] != '\0') {
						HELP_PARAM_SET(tmpPxObjList1, "ModeEnabled", ap_param->security.ModeEnabled, SOPT_OBJVALUE);
					}
					if (ap_param->security.WEPKey[0] != '0' && ap_param->security.WEPKey[0] != '\0') {
						HELP_PARAM_SET(tmpPxObjList1, "WEPKey", ap_param->security.WEPKey, SOPT_OBJVALUE);
					}
					if (ap_param->security.KeyPassphrase[0] != '\0') {
						HELP_PARAM_SET(tmpPxObjList1, "KeyPassphrase", ap_param->security.KeyPassphrase, SOPT_OBJVALUE);
					}
					/*Save index value for future bookkeep*/
					bookkeep_indexArr[0] = index;
					index++;
				} else if (!strcmp(pxParam->sParamName, "SSIDReference")
				 && (!strcmp(pxParam->sParamValue, "Device.WiFi.SSID.2"))) {
					if (is_stringFalse(ap_param->Enable[1]) || ap_param->SSID[1] == '\0') {
						LOGF_LOG_DEBUG("Device.WiFi.SSID.2 is not set! Continue to next entry\n");
						index = client_getInstanceNumFromObjectName(tmpPxObjList->sObjName);
						if (index < 0) {
							LOGF_LOG_ERROR("Failed to parse instance number!\n");
							nRet = UGW_FAILURE;
							goto configure_exit;
						}
						/*Save index value for future bookkeep of main VAP*/
						bookkeep_indexArr[1] = index;
						continue;
					}
					tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, tmpPxObjList->sObjName, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
					if (tmpPxObjList1 == NULL) {
						LOGF_LOG_ERROR("Failed to set object!!\n");
						nRet = UGW_FAILURE;
						goto configure_exit;
					}
					/*Set relevant parameters*/
					HELP_PARAM_SET(tmpPxObjList1, "Enable", ap_param->Enable[1], SOPT_OBJVALUE);

					index = client_getInstanceNumFromObjectName(tmpPxObjList->sObjName);
					if (index < 0) {
						LOGF_LOG_ERROR("Failed to parse instance number!\n");
						nRet = UGW_FAILURE;
						goto configure_exit;
					}
					snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "%s%d.Security.", WIFI_ACCESSPOINT_OBJECT_NAME, index);
					LOGF_LOG_DEBUG("Setting security for object %s\n", sParamValue);
					tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, sParamValue, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
					if (tmpPxObjList1 == NULL) {
						LOGF_LOG_ERROR("Failed to set object!!\n");
						nRet = UGW_FAILURE;
						goto configure_exit;
					}
					if (ap_param->security.ModeEnabled[0] != '\0') {
						HELP_PARAM_SET(tmpPxObjList1, "ModeEnabled", ap_param->security.ModeEnabled, SOPT_OBJVALUE);
					}
					if (ap_param->security.WEPKey[0] != '0' && ap_param->security.WEPKey[0] != '\0') {
						HELP_PARAM_SET(tmpPxObjList1, "WEPKey", ap_param->security.WEPKey, SOPT_OBJVALUE);
					}
					if (ap_param->security.KeyPassphrase[0] != '\0') {
						HELP_PARAM_SET(tmpPxObjList1, "KeyPassphrase", ap_param->security.KeyPassphrase, SOPT_OBJVALUE);
					}
					/*Save index value for future bookkeep*/
					bookkeep_indexArr[1] = index;
					index++;
				}
			}
		} else if (strstr(tmpPxObjList->sObjName, WIFI_SSID_OBJECT_NAME)
			 && (strlen(tmpPxObjList->sObjName) < strlen(WIFI_SSID_OBJECT_NAME) + 3)) {
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "Name")
				 && (!strcmp(pxParam->sParamValue, "wlan0"))) {
					if (is_stringFalse(ap_param->Enable[0]) || ap_param->SSID[0] == '\0') {
						LOGF_LOG_DEBUG("Disable wlan0 VAP as it marked disabled or no SSID value provided\n");
						snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "%s1.", WIFI_ACCESSPOINT_OBJECT_NAME);
						tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, sParamValue, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
						if (tmpPxObjList1 == NULL) {
							LOGF_LOG_ERROR("Failed to set object!!\n");
							nRet = UGW_FAILURE;
							goto configure_exit;
						}
						/*Set relevant parameters*/
						HELP_PARAM_SET(tmpPxObjList1, "Enable", "false", SOPT_OBJVALUE);
					} else {
						LOGF_LOG_DEBUG("Setting wlan0 with SSID value %s\n", ap_param->SSID[0]);
						tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, tmpPxObjList->sObjName, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
						if (tmpPxObjList1 == NULL) {
							LOGF_LOG_ERROR("Failed to set object!!\n");
							nRet = UGW_FAILURE;
							goto configure_exit;
						}
						/*Set relevant parameters for 2.4 GHz radio*/
						HELP_PARAM_SET(tmpPxObjList1, "SSID", ap_param->SSID[0], SOPT_OBJVALUE);
						if (index == 1) {
							LOGF_LOG_DEBUG("Setting wlan0 radio auto channel and ACS\n");
							index = client_getInstanceNumFromObjectName(tmpPxObjList->sObjName);
							nRet = client_setRadioConfig(pxObjListNew, index);
							if (nRet) {
								LOGF_LOG_ERROR("Failed to set radio configuration parameters\n");
								goto configure_exit;
							}
							radioCfg_indexArr[0] = index;
						}
					}
				} else if (!strcmp(pxParam->sParamName, "Name")
					   && (!strcmp(pxParam->sParamValue, "wlan2"))) {
					if (is_stringFalse(ap_param->Enable[1]) || ap_param->SSID[1] == '\0') {
						LOGF_LOG_DEBUG("Disable wlan2 VAP as it marked disabled or no SSID value provided\n");
						snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "%s2.", WIFI_ACCESSPOINT_OBJECT_NAME);
						tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, sParamValue, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
						if (tmpPxObjList1 == NULL) {
							LOGF_LOG_ERROR("Failed to set object!!\n");
							nRet = UGW_FAILURE;
							goto configure_exit;
						}
						/*Set relevant parameters*/
						HELP_PARAM_SET(tmpPxObjList1, "Enable", "false", SOPT_OBJVALUE);
					} else {
						LOGF_LOG_DEBUG("Setting wlan2 with SSID value %s\n", ap_param->SSID[1]);
						tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, tmpPxObjList->sObjName, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
						if (tmpPxObjList1 == NULL) {
							LOGF_LOG_ERROR("Failed to set object!!\n");
							nRet = UGW_FAILURE;
							goto configure_exit;
						}
						/*Set relevant parameters for 5 GHz radio*/
						HELP_PARAM_SET(tmpPxObjList1, "SSID", ap_param->SSID[1], SOPT_OBJVALUE);
						if (index == 2) {
							LOGF_LOG_DEBUG("Setting wlan2 radio auto channel to enable\n");
							index = client_getInstanceNumFromObjectName(tmpPxObjList->sObjName);
							nRet = client_setRadioConfig(pxObjListNew, index);
							if (nRet) {
								LOGF_LOG_ERROR("Failed to set radio configuration parameters\n");
								goto configure_exit;
							}
							radioCfg_indexArr[1] = index;
						}
					}
				}
			}
		}
	}

	LOGF_LOG_DEBUG("Finished preparing object to configure local AP:\n");
	if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListNew)) {
		HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
		/*Trigger SL request*/
		if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListNew) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto configure_exit;
		}
	}

	/*Bookkeep values*/
	nRet = client_bookkeepMainAP(pxBookObj, pxObjListWlan, bookkeep_indexArr, ap_param, radioCfg_indexArr);
	if (nRet) {
		LOGF_LOG_ERROR("Failed to bookkeep values to DB!\n");
		goto configure_exit;
	}

configure_exit:
	CLIENT_HELP_DELETE_OBJ(pxObjListNew, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_connectSTAtoAP
 *  Description   : Helper function to connect STA VAP to AP
 * ===================================================================================*/
static int client_connectSTAtoAP(ObjList *pxObjListWlan, ObjList *pxObjListMain, AP_params *ap_param)
{
	char sSSIDValue[MAX_LEN_PARAM_VALUE] = {'\0'};
	char sAliasValue[MAX_LEN_PARAM_VALUE] = {'\0'};
	char sBSSIDValue[MAX_LEN_PARAM_VALUE] = {'\0'};
	char sParamValue[MAX_LEN_PARAM_VALUE] = {'\0'};
	char objNameStr[MAX_LEN_PARAM_VALUE];
	char profileObjNameStr[MAX_LEN_PARAM_VALUE];
	int nRet = UGW_SUCCESS, received_entry = -1;
	bool profile_found = false;
	bool feature_enable = false;
	ObjList *tmpPxObjList = NULL;
	ObjList *pxObjListNew =  client_help_create_obj();
	ParamList *pxParam = NULL;

	if (!pxObjListNew) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto connect_exit;
	}

	/*Initialize security values*/
	ap_param->security.ModeEnabled[0] = '\0';
	ap_param->security.WEPKey[0] = '\0';
	ap_param->security.KeyPassphrase[0] = '\0';

	/*Search for choosen profile SSID*/
	feature_enable = false;
	FOR_EACH_OBJ(pxObjListMain, tmpPxObjList) {
		if (tmpPxObjList->unOid == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE) {
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_SSID) {
					strncpy(sSSIDValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					sSSIDValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
				} else if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_ENABLE)
				       && (!is_stringFalse(pxParam->sParamValue))) {
						feature_enable = true;
				}
			}
			if (feature_enable) {
				/*Save current entry number for future use*/
				received_entry = client_getInstanceNumFromObjectName(tmpPxObjList->sObjName);
				if (received_entry < 0) {
					LOGF_LOG_ERROR("Failed to parse instance number!\n");
					nRet = UGW_FAILURE;
					goto connect_exit;
				}
			}
		} else if (tmpPxObjList->unOid == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_SECURITY) {
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_SECURITY_MODEENABLED)
				 && (pxParam->sParamValue[0] !='\0')) {
					strncpy(ap_param->security.ModeEnabled, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					ap_param->security.ModeEnabled[MAX_LEN_PARAM_VALUE - 1] = '\0';
				}
				if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_SECURITY_WEPKEY)
				 && ((pxParam->sParamValue[0] != '0') || (strlen(pxParam->sParamValue) > 1))) {
					strncpy(ap_param->security.WEPKey, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					ap_param->security.WEPKey[MAX_LEN_PARAM_VALUE - 1] = '\0';
				}
				if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_SECURITY_KEYPASSPHRASE)
				  && (pxParam->sParamValue[0] !='\0')) {
					strncpy(ap_param->security.KeyPassphrase, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					ap_param->security.KeyPassphrase[MAX_LEN_PARAM_VALUE - 1] = '\0';
				}
			}
			if (feature_enable) {
				break;
			}
		}
	}

	if (sSSIDValue[0] == '\0' || !feature_enable || received_entry < 0) {
		LOGF_LOG_ERROR("Data received from caller did not include profile SSID information or feature disabled!\n");
		nRet = UGW_FAILURE;
		goto connect_exit;
	}
	LOGF_LOG_DEBUG("Find profile reference in WLAN DB\n");
	/*Create EndPoint object name - Profile correspond with EndPoint entry*/
	snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "%s%d.Profile.", WIFI_ENDPOINT_OBJECT_NAME, received_entry);
	FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
		if (strstr(tmpPxObjList->sObjName, sParamValue)) {
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "SSID")
				&& (!strcmp(pxParam->sParamValue, sSSIDValue))) {
					strncpy(profileObjNameStr, tmpPxObjList->sObjName, MAX_LEN_PARAM_VALUE - 1);
					profileObjNameStr[MAX_LEN_PARAM_VALUE - 1] = '\0';
					profile_found = true;
				} else if (!strcmp(pxParam->sParamName, "Alias")){
					strncpy(sAliasValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					sAliasValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
				} else if (!strcmp(pxParam->sParamName, CLIENT_BSSID_NAME)) {
					strncpy(sBSSIDValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					sBSSIDValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
				}
			}
			if (profile_found)
				break;
		}
	}
	if (profile_found) {
		LOGF_LOG_DEBUG("Profile reference value is %s\n", profileObjNameStr);
		snprintf(objNameStr, MAX_LEN_PARAM_VALUE, "%s%d.", WIFI_ENDPOINT_OBJECT_NAME, received_entry);

		/*Set Endpoint profile*/
		LOGF_LOG_DEBUG("Setting object %s parameter %s with value %s\n", objNameStr,
										PROFILE_REF, profileObjNameStr);
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, objNameStr, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			nRet = UGW_FAILURE;
			goto connect_exit;
		}

		HELP_PARAM_SET(tmpPxObjList, PROFILE_REF, profileObjNameStr, SOPT_OBJVALUE);

		/*Set Profile parameters*/
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, profileObjNameStr, NO_ARG_VALUE,
										OBJOPT_MODIFY, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			nRet = UGW_FAILURE;
			goto connect_exit;
		}

		HELP_PARAM_SET(tmpPxObjList, "Enable", "true", SOPT_OBJVALUE);
		HELP_PARAM_SET(tmpPxObjList, "Status", "Active", SOPT_OBJVALUE);
		HELP_PARAM_SET(tmpPxObjList, "Priority", "0", SOPT_OBJVALUE);
		HELP_PARAM_SET(tmpPxObjList, "Alias", sAliasValue, SOPT_OBJVALUE);
		HELP_PARAM_SET(tmpPxObjList, CLIENT_BSSID_NAME, sBSSIDValue, SOPT_OBJVALUE);
		HELP_PARAM_SET(tmpPxObjList, "SSID", sSSIDValue, SOPT_OBJVALUE);

		snprintf(objNameStr, MAX_LEN_PARAM_VALUE, "%s.Security.", profileObjNameStr);
		LOGF_LOG_DEBUG("Setting security mode for object %s\n", objNameStr);
		/*Set Profile parameters*/
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, objNameStr, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			nRet = UGW_FAILURE;
			goto connect_exit;
		}
		feature_enable = false;
		if (ap_param->security.ModeEnabled[0] != '\0') {
			HELP_PARAM_SET(tmpPxObjList, "ModeEnabled", ap_param->security.ModeEnabled, SOPT_OBJVALUE);
			feature_enable = true;
		}
		if (ap_param->security.WEPKey[0] != '\0') {
			HELP_PARAM_SET(tmpPxObjList, "WEPKey", ap_param->security.WEPKey, SOPT_OBJVALUE);
			feature_enable = true;
		}
		if (ap_param->security.KeyPassphrase[0] != '\0') {
			HELP_PARAM_SET(tmpPxObjList, "KeyPassphrase", ap_param->security.KeyPassphrase, SOPT_OBJVALUE);
			feature_enable = true;
		}

		if (!feature_enable) {
			LOGF_LOG_ERROR("No security values detected!\n");
			nRet = UGW_FAILURE;
			goto connect_exit;
		}

		LOGF_LOG_DEBUG("Finished preparing object to enable AP connectivity:\n");
		if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListNew)) {
			HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
			/*Trigger SL request*/
			if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListNew) != UGW_SUCCESS)) {
				LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
				goto connect_exit;
			}
		}
	} else {
		/*Handle a case were new profile should be created*/
		LOGF_LOG_INFO("Parameters received from user do not match an existing profile - Creating a new one\n");

		/*Use choosen entry number because it stands for Radio Type*/
		snprintf(objNameStr, MAX_LEN_PARAM_VALUE, "%s%d.Profile.", WIFI_ENDPOINT_OBJECT_NAME, received_entry);
		/*Set SSID Value Parameter*/
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, objNameStr, NO_ARG_VALUE, OBJOPT_ADD, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			nRet = UGW_FAILURE;
			goto connect_exit;
		}
		HELP_PARAM_SET(tmpPxObjList, "Enable", "true", SOPT_OBJVALUE);
		HELP_PARAM_SET(tmpPxObjList, "SSID", sSSIDValue, SOPT_OBJVALUE);
		snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "cpe-Profile-%d", received_entry);
		HELP_PARAM_SET(tmpPxObjList, "Alias", sParamValue, SOPT_OBJVALUE);
		HELP_PARAM_SET(tmpPxObjList, "Priority", "0", SOPT_OBJVALUE);
		HELP_PARAM_SET(tmpPxObjList, "Status", "Active", SOPT_OBJVALUE);

		LOGF_LOG_DEBUG("Setting hidden SSID parameter according to bridge type (DHCP / Manual) with value true\n");
		HELP_PARAM_SET(tmpPxObjList, "X_LANTIQ_COM_Vendor_IsHiddenSsid", "true", SOPT_OBJVALUE);

		/*Modify created security entry*/
		snprintf(objNameStr, MAX_LEN_PARAM_VALUE, "%s%s.Security.", objNameStr, sParamValue);
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, objNameStr, NO_ARG_VALUE, OBJ_MODIFY_RO, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			nRet = UGW_FAILURE;
			goto connect_exit;
		}
		feature_enable = false;
		if (ap_param->security.ModeEnabled[0] != '\0') {
			HELP_PARAM_SET(tmpPxObjList, "ModeEnabled", ap_param->security.ModeEnabled, SOPT_OBJVALUE);
			feature_enable = true;
		}
		if (ap_param->security.WEPKey[0] != '\0') {
			HELP_PARAM_SET(tmpPxObjList, "WEPKey", ap_param->security.WEPKey, SOPT_OBJVALUE);
			feature_enable = true;
		}
		if (ap_param->security.KeyPassphrase[0] != '\0') {
			HELP_PARAM_SET(tmpPxObjList, "KeyPassphrase", ap_param->security.KeyPassphrase, SOPT_OBJVALUE);
			feature_enable = true;
		}

		if (!feature_enable) {
			LOGF_LOG_ERROR("No security values detected!\n");
			nRet = UGW_FAILURE;
			goto connect_exit;
		}

		LOGF_LOG_INFO("Creating a new profile from object %s - Adding the following profile:\n", profileObjNameStr);
		HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
		if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListNew)) {
			/*Trigger SL request*/
			if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListNew) != UGW_SUCCESS)) {
				LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
				goto connect_exit;
			}
		}

		LOGF_LOG_INFO("Looping on return object to parse created profile number and set it to enable\n");
		HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
		FOR_EACH_OBJ(pxObjListNew, tmpPxObjList) {
			if (strstr(tmpPxObjList->sObjName, WIFI_ENDPOINT_OBJECT_NAME)
			 &&(strstr(tmpPxObjList->sObjName, "Profile."))) {
				LOGF_LOG_DEBUG("Return Profile object name is %s\n", tmpPxObjList->sObjName);
				strncpy(profileObjNameStr, tmpPxObjList->sObjName, MAX_LEN_PARAM_VALUE - 1);
				profileObjNameStr[MAX_LEN_PARAM_VALUE - 1] = '\0';
				break;
			}
		}
		/*Use choosen entry number because it stands for Radio Type*/
		snprintf(objNameStr, MAX_LEN_PARAM_VALUE, "%s%d.", WIFI_ENDPOINT_OBJECT_NAME, received_entry);

		/*Create second request*/
		LOGF_LOG_DEBUG("Delete received profile - create a new one\n");
		CLIENT_HELP_DELETE_OBJ(pxObjListNew, EMPTY_OBJLIST);
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, objNameStr, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			nRet = UGW_FAILURE;
			goto connect_exit;
		}
		HELP_PARAM_SET(tmpPxObjList, "ProfileReference", profileObjNameStr, SOPT_OBJVALUE);

		if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListNew)) {
			LOGF_LOG_INFO("Setting final profile details:\n");
			HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
			/*Trigger SL request*/
			if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListNew) != UGW_SUCCESS)) {
				LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
				goto connect_exit;
			}
		}
	}

connect_exit:
	CLIENT_HELP_DELETE_OBJ(pxObjListNew, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_deleteBookkeep
 *  Description   : Helper function to delete all current bookkeep values from DB
 * ===================================================================================*/
static int client_deleteBookkeep(ObjList *pxBookObj, ObjList *pxMainObj)
{
	ObjList *tmpPxObjList = NULL;
	ObjList *tmpPxObjList1 = NULL;
	int nRet = UGW_SUCCESS;

	FOR_EACH_OBJ(pxMainObj, tmpPxObjList) {
		if (tmpPxObjList->unOid == DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP) {
			tmpPxObjList1 = HELP_OBJECT_SET(pxBookObj, tmpPxObjList->sObjName, NO_ARG_VALUE, OBJOPT_DEL, SOPT_OBJVALUE);
			if (tmpPxObjList1 == NULL) {
				LOGF_LOG_ERROR("Failed to delete object!!\n");
				nRet = UGW_FAILURE;
				goto book_exit;
			}
		}
	}

book_exit:
	LOGF_LOG_DEBUG("Finished deleting bookkeep values - nRet = %d", nRet);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_enableVAPforGW
 *  Description   : Helper function to reconnect all previously disabled VAPs
 * ===================================================================================*/
static int client_enableVAPforGW(ObjList *pxMainObj)
{
	char sParamValue[MAX_LEN_PARAM_VALUE];
	char sObjNameStr[MAX_LEN_PARAM_VALUE];
	int nRet = UGW_SUCCESS;
	ObjList *tmpPxObjList = NULL;
	ObjList *tmpPxObjList1 = NULL;
	ObjList *pxObjListNew =  client_help_create_obj();
	ParamList *pxParam = NULL;

	if (!pxObjListNew) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto enable_exit;
	}

	FOR_EACH_OBJ(pxMainObj, tmpPxObjList) {
		if (!strstr(tmpPxObjList->sObjName, CLIENT_OBJECT_BOOKKEEP_NAME)) {
			continue;
		}
		nRet = client_get_param_from_list(pxMainObj, tmpPxObjList->sObjName,
									0, "InstanceNum", sParamValue);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to read value from DB!\n");
			goto enable_exit;
		}
		if (!strcmp(sParamValue, "0")) {
			LOGF_LOG_DEBUG("Illigal instance value - 0. Continue...\n");
			continue;
		}

		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if (pxParam->unParamId != DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_VAPPREVIOUSVALUE) {
				continue;
			}
			if (!is_stringFalse(pxParam->sParamValue)) {
				snprintf(sObjNameStr, MAX_LEN_PARAM_VALUE, "%s%s.", WIFI_SSID_OBJECT_NAME, sParamValue);
				LOGF_LOG_DEBUG("Setting VAP entry %s back to enable\n", sParamValue);
				tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, sObjNameStr, NO_ARG_VALUE,
											OBJOPT_MODIFY, SOPT_OBJVALUE);
				if (tmpPxObjList1 == NULL) {
					LOGF_LOG_ERROR("Failed to set object!!\n");
					nRet = UGW_FAILURE;
					goto enable_exit;
				}
				/*Set relevant parameters*/
				HELP_PARAM_SET(tmpPxObjList1, "Enable", "true", SOPT_OBJVALUE);

				snprintf(sObjNameStr, MAX_LEN_PARAM_VALUE, "%s%s.", WIFI_ACCESSPOINT_OBJECT_NAME, sParamValue);
				LOGF_LOG_DEBUG("Setting VAP entry %s back to enable\n", sParamValue);
				tmpPxObjList1 = HELP_OBJECT_SET(pxObjListNew, sObjNameStr, NO_ARG_VALUE,
										OBJOPT_MODIFY, SOPT_OBJVALUE);
				if (tmpPxObjList1 == NULL) {
					LOGF_LOG_ERROR("Failed to set object!!\n");
					nRet = UGW_FAILURE;
					goto enable_exit;
				}
				/*Set relevant parameters*/
				HELP_PARAM_SET(tmpPxObjList1, "Enable", "true", SOPT_OBJVALUE);
			}
		}
	}

	if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListNew)) {
		HELP_PRINT_OBJ(pxObjListNew, 0x4); //to be removed
		/*Trigger SL request*/
		if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListNew) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto enable_exit;
		}
	}

enable_exit:
	CLIENT_HELP_DELETE_OBJ(pxObjListNew, FREE_OBJLIST);
	return nRet;

}

/* ===================================================================================
 *  Function Name : client_disableVAPforRepeater
 *  Description   : Helper function to disable VAP for repeater mode
 * ===================================================================================*/
static int client_disableVAPforRepeater(ObjList *pxBookObj, ObjList *pxObjListWlan, ObjList *pxObjListMain)
{
	int vap_status, vap_index = 0, index = 0, i = 0, nRet = UGW_SUCCESS;
	bool main_vap = false;
	char ssid_refArray[MAX_SSID_NUM][MAX_LEN_PARAM_VALUE + 1];
	char sParamValue[MAX_LEN_PARAM_VALUE];
	char sEntryVal[MAX_LEN_PARAM_VALUE];
	ObjList *tmpPxObjList = NULL;
	ObjList *tmpPxObjList1 = NULL;
	ObjList *pxNewObj = client_help_create_obj();
	ParamList *pxParam = NULL;

	if (!pxNewObj) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto repeater_exit;
	}

	LOGF_LOG_DEBUG("Search for all enabled VAPs on a given radio\n");
	FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
		if (strstr(tmpPxObjList->sObjName, WIFI_ACCESSPOINT_OBJECT_NAME)
		 && (strlen(tmpPxObjList->sObjName) < strlen(WIFI_ACCESSPOINT_OBJECT_NAME) + 3)) {
			/*Save SSIDReference name*/
			main_vap = false;
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "SSIDReference")) {
					/*Verify this is not Main VAP*/
					vap_index = 0;
					while (mainWlanSSIDRef[vap_index]) {
						if (!strcmp(pxParam->sParamValue, mainWlanSSIDRef[vap_index])) {
							main_vap = true;
							break;
						}
						vap_index++;
					}
					if (!main_vap) {
						strncpy(ssid_refArray[index], pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
						ssid_refArray[index][MAX_LEN_PARAM_VALUE - 1] = '\0';
						index++;
					}
				}
			}
		}
	}
	if (index == 0) {
		LOGF_LOG_INFO("No VAPs enabled other then main VAPs\n");
		nRet = UGW_SUCCESS;
		goto repeater_exit;
	}
	/*Loop again on object list and check for enabled SSIDs on required radio*/
	FOR_EACH_OBJ(pxObjListMain, tmpPxObjList) {
		if (tmpPxObjList->unOid != DEVICE_X_LANTIQ_COM_CLIENTMODE_ENDPOINT) {
			continue;
		}
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_ENDPOINT_ENABLE)
			 && (is_stringFalse(pxParam->sParamValue))) {
				sParamValue[0] = '\0';
				break;
			} else if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_ENDPOINT_RADIOTYPE) {
				strncpy(sParamValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
				sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
			}
		}
		if (sParamValue[0] != '\0') {
			break;
		}
	}

	if (sParamValue[0] == '\0') {
		LOGF_LOG_ERROR("Failed to read parameter from DB!\n");
		nRet = UGW_FAILURE;
		goto repeater_exit;
	}
	FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
		if (!strstr(tmpPxObjList->sObjName, WIFI_SSID_OBJECT_NAME)
		 || (strlen(tmpPxObjList->sObjName) > strlen(WIFI_SSID_OBJECT_NAME) + 3)) {
			continue;
		}
		vap_status = 0;
		/*Look for reference SSID and check radio type and status*/
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if (!strcmp(pxParam->sParamName, "Enable")
			 &&(!is_stringFalse(pxParam->sParamValue))) {
				MARK_VAP_ENABLE(vap_status);
			}
			if (!strcmp(pxParam->sParamName, "LowerLayers")) {
				if (!strcmp(pxParam->sParamValue, sParamValue)) {
					MARK_VAP_RADIO(vap_status);
				}
			}
			if (!strcmp(pxParam->sParamName, "Name")) {
				for (i = 0; i < index; i++) {
					if (!strcmp(pxParam->sParamValue, ssid_refArray[i])) {
						MARK_VAP_SSID(vap_status);
						break;
					}
				}
			}
		}
		if (IS_VAP_ENABLE(vap_status)) {
			/*Disable current VAP*/
			index = client_getInstanceNumFromObjectName(tmpPxObjList->sObjName);
			if (index < 0) {
				LOGF_LOG_ERROR("Failed to parse instance number from object - %s\n", tmpPxObjList->sObjName);
				nRet = UGW_FAILURE;
				goto repeater_exit;
			}
			if ((nRet = client_disableActiveVAP(index, pxBookObj, pxNewObj))) {
				LOGF_LOG_ERROR("Failed to disable active VAP!\n");
				goto repeater_exit;
			}
			tmpPxObjList1 = HELP_OBJECT_SET(pxBookObj, CLIENT_OBJECT_BOOKKEEP_NAME,
									NO_ARG_VALUE, OBJOPT_ADD, SOPT_OBJVALUE);
			if (tmpPxObjList1 == NULL) {
				LOGF_LOG_ERROR("Failed to set object!!\n");
				nRet = UGW_FAILURE;
				goto repeater_exit;
			}
			/*Set relevant parameters*/
			HELP_PARAM_SET(tmpPxObjList1, "VAPPreviousValue", "Enable", SOPT_OBJVALUE);
			/*We can use i as an index*/
			HELP_PARAM_SET(tmpPxObjList1, "SSID", ssid_refArray[i], SOPT_OBJVALUE);
			snprintf(sEntryVal, MAX_LEN_PARAM_VALUE, "%d", client_getInstanceNumFromObjectName(tmpPxObjList->sObjName));
			HELP_PARAM_SET(tmpPxObjList1, "InstanceNum", sEntryVal, SOPT_OBJVALUE);
		}
	}
	if (HELP_IS_EMPTY_OBJ_PARAM(pxNewObj)) {
		LOGF_LOG_DEBUG("Object list to be sent:\n");
		HELP_PRINT_OBJ(pxNewObj, 0x4); //to be removed
		/*Trigger SL request*/
		if ((nRet = SERVD_CAL_SET_SERVICE(pxNewObj) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto repeater_exit;
		}
	}

repeater_exit:
	LOGF_LOG_DEBUG("Function ends with return value %d\n", nRet);
	CLIENT_HELP_DELETE_OBJ(pxNewObj, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_freeVAPforSTA
 *  Description   : Helper function to disable all VAPs for repeater mode
 * ===================================================================================*/
static int client_freeVAPforSTA(ObjList *pxBookObj, ObjList *pxObjListWlan,
							ObjList *pxObjListMain, int curr_entry)
{
	ObjList *tmpPxObjList = NULL;
	ObjList *pxNewObj = client_help_create_obj();
	ParamList *pxParam = NULL;
	char ssid_refArray[MAX_SSID_NUM][MAX_LEN_PARAM_VALUE + 1];
	char sParamValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	char *endptr;
	int nRet = UGW_SUCCESS, enabled_VAP = 0, i, index = 0;
	unsigned int vap_status = 0;

	if (!pxNewObj) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto handle_exit;
	}

	if ((nRet = client_get_param_from_list(pxObjListWlan, WIFI_GENERAL_OBJECT_NAME, 0,
					"AccessPointNumberOfEntries", sParamValue))) {
		LOGF_LOG_ERROR("Failed to read parameter from DB!\n");
		goto handle_exit;
	}
	enabled_VAP = strtol(sParamValue, &endptr, 10);
	if (sParamValue == endptr) {
		LOGF_LOG_ERROR("Failed to translate string into number\n");
		nRet = UGW_FAILURE;
		goto handle_exit;
	}
	if (enabled_VAP < 16) {
		LOGF_LOG_DEBUG("No need to disable any VAPs in order to enable station mode\n");
		nRet = UGW_SUCCESS;
		goto handle_exit;
	}

	LOGF_LOG_DEBUG("Count the number of enabled VAPs on requested radio to verify we can create station VAP\n");
	FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
		if (strstr(tmpPxObjList->sObjName, WIFI_ACCESSPOINT_OBJECT_NAME)
		 && (strlen(tmpPxObjList->sObjName) < strlen(WIFI_ACCESSPOINT_OBJECT_NAME) + 3)) {
			/*Save SSIDReference name*/
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "SSIDReference")) {
					strncpy(ssid_refArray[index], pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					ssid_refArray[index][MAX_LEN_PARAM_VALUE - 1] = '\0';
					index++;
				}
			}
		}
	}
	/*Loop again on object list and check for enabled SSIDs on required radio*/
	enabled_VAP = 0;
	nRet = client_get_param_from_list(pxObjListMain, CLIENT_OBJECT_ENDPOINT_NAME,
							curr_entry, "RadioType", sParamValue);
	if (nRet) {
		LOGF_LOG_ERROR("Failed to read parameter from DB!\n");
		goto handle_exit;
	}
	FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
		if (strstr(tmpPxObjList->sObjName, WIFI_SSID_OBJECT_NAME)
		 && (strlen(tmpPxObjList->sObjName) < strlen(WIFI_SSID_OBJECT_NAME) + 3)) {
			vap_status = 0;
			/*Look for reference SSID and check radio type and status*/
			for (i = 0; i < index; i++) {
				if (!strcmp(tmpPxObjList->sObjName, ssid_refArray[i])) {
					MARK_VAP_SSID(vap_status);
				}
			}
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "Enable")
				 &&(!is_stringFalse(pxParam->sParamValue))) {
					MARK_VAP_ENABLE(vap_status);
				}
				if (!strcmp(pxParam->sParamName, "LowerLayers")
				 && (!strcmp(pxParam->sParamValue, sParamValue))) {
					MARK_VAP_RADIO(vap_status);
				}
			}
			if (IS_VAP_ENABLE(vap_status)) {
				enabled_VAP++;
			}
		}
	}
	if (enabled_VAP > 15) {
		LOGF_LOG_INFO("Detected 16 enabled VAPs on radio %s, disabeling last VAP\n", sParamValue);
		nRet = client_disableActiveVAP(LAST_VAP_NUM, pxBookObj, pxNewObj);
	}
	if (HELP_IS_EMPTY_OBJ_PARAM(pxNewObj)) {
		/*Trigger SL request*/
		if ((nRet = SERVD_CAL_SET_SERVICE(pxNewObj) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto handle_exit;
		}
	}

handle_exit:
	CLIENT_HELP_DELETE_OBJ(pxNewObj, FREE_OBJLIST);
	LOGF_LOG_DEBUG("Function ends with return value %d\n", nRet);
	return nRet;
}

static int client_setL2NATStatus(sl_operations operation, char *STAVapName)
{
	char sParamValue[MAX_LEN_PARAM_VALUE];
	FILE *fp = NULL;
	int nRet = UGW_SUCCESS;

	if (!STAVapName) {
		LOGF_LOG_ERROR("Function called with NULL value!\n");
	}

	if (operation == L2NAT_ENABLE) {
		nRet = snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "echo add %s > %s", STAVapName, L2NAT_PROC_DEV_STR);
	} else if (operation == L2NAT_DISABLE) {
		nRet = snprintf(sParamValue, MAX_LEN_PARAM_VALUE, "echo del %s > %s", STAVapName, L2NAT_PROC_DEV_STR);
	} else {
		LOGF_LOG_ERROR("Received wrong operation value!\n");
		nRet = UGW_FAILURE;
		goto l2nat_exit;
	}
	if (nRet < 0) {
		LOGF_LOG_ERROR("Failed to set string value!\n");
		goto l2nat_exit;
	}
	/*Using system command as a WA - Need to fix this*/
	if ((nRet = system(sParamValue)) < 0) {
		LOGF_LOG_ERROR("Failed to set L2NAT interface!");
		goto l2nat_exit;
	}

	LOGF_LOG_DEBUG("Setting bridge learning state\n");

	fp = fopen(PPA_BRIDGE_DEV_STR, "w+");
	if (!fp) {
		LOGF_LOG_ERROR("failed to open file: %s\n", PPA_BRIDGE_DEV_STR);
		nRet = UGW_FAILURE;
		goto l2nat_exit;
	}

	if (operation == L2NAT_ENABLE) {
		nRet = fprintf(fp, "enable");
		if (nRet < 0) {
			LOGF_LOG_ERROR("Failed to write data to file!\n");
			goto l2nat_exit;
		}

		nRet = fapi_sys_setBridgeAccelState("disable");
	} else {
		nRet = fprintf(fp, "disable");
		if (nRet < 0) {
			LOGF_LOG_ERROR("Failed to write data to file!\n");
			goto l2nat_exit;
		}
		nRet = fapi_sys_setBridgeAccelState("enable");
	}

	fflush(fp);
	fclose(fp);
	fp = NULL;

l2nat_exit:
	if (nRet != UGW_SUCCESS) {
		LOGF_LOG_ERROR("Failed to set bridge learning status to disable\n");
		if (fp != NULL) {
			fclose(fp);
		}
	}
	return nRet;
}

/**********************************************************************************************************/
/*Main Functions*/
/**********************************************************************************************************/

/* ===================================================================================
 *  Function Name : client_handleSTAStatusChange
 *  Description   : Function to prepare object list for STA VAP Enable / Disable
 * ===================================================================================*/
static int client_handleSTAStatusChange(ObjList *pxBookObj, ObjList *pxObjListNew, ObjList *pxObjListMain,
							ObjList *pxObjListWlan, sl_operations req_operation, int curr_entry)
{
	ParamList *pxParam = NULL;
	ObjList *tmpPxObjList = NULL;
	ObjList *pxObjList = client_help_create_obj();
	char ObjNameStr[MAX_LEN_PARAM_VALUE];
	char sParamValue[MAX_LEN_PARAM_VALUE];
	bool entry_enable = false;
	int nRet = UGW_SUCCESS, index = 0;

	if (!pxObjListWlan || !pxObjListNew || !pxObjListMain || !pxBookObj || !pxObjList) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto status_exit;
	}

	if (req_operation == STATION_ENABLE) {
		if ((nRet = client_freeVAPforSTA(pxBookObj, pxObjListWlan, pxObjListMain, curr_entry))) {
			LOGF_LOG_ERROR("Failed to handle current VAPs!\n");
			goto status_exit;
		}

		LOGF_LOG_DEBUG("Enable Station VAP\n");
		/*Parse EndPoint entry from Radio name*/
		nRet = client_get_param_from_list(pxObjListMain, CLIENT_OBJECT_ENDPOINT_NAME,
								curr_entry, "RadioType", sParamValue);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to read parameter from DB\n");
			goto status_exit;
		}

		index = client_getInstanceNumFromObjectName(sParamValue);
		if (index < 0) {
			LOGF_LOG_ERROR("Failed to parse instance number!\n");
			nRet = UGW_FAILURE;
			goto status_exit;
		}

		/*Set values to enable STA VAP*/
		snprintf(ObjNameStr, MAX_LEN_PARAM_VALUE, "%s%d", WIFI_ENDPOINT_OBJECT_NAME, index);
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, ObjNameStr, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			goto status_exit;
		}
		/*Set relevant parameters*/
		HELP_PARAM_SET(tmpPxObjList, "Enable", "true", SOPT_OBJVALUE);

		/*Set WDS value*/
		nRet = client_get_param_from_list(pxObjListMain, CLIENT_OBJECT_ENDPOINT_NAME,
								curr_entry, "WDS", sParamValue);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to read parameter from DB\n");
			goto status_exit;
		}
		HELP_PARAM_SET(tmpPxObjList, "X_LANTIQ_COM_Vendor_WaveEndPointWDS", sParamValue, SOPT_OBJVALUE);

		/*Read matching EndPoint SSID Referance*/
		sParamValue[0] = '\0';
		FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
			if (strstr(tmpPxObjList->sObjName, ObjNameStr)
			&& (strlen(tmpPxObjList->sObjName) < strlen(ObjNameStr) + 3)) {
				FOR_EACH_PARAM(tmpPxObjList, pxParam) {
					if (!strcmp(pxParam->sParamName, "SSIDReference")) {
						strncpy(sParamValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
						sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
						break;
					}
				}
			}
		}
		if (sParamValue[0] == '\0') {
			LOGF_LOG_ERROR("Failed to find SSID reference in DB!\n");
			nRet = UGW_FAILURE;
			goto status_exit;
		}

		/*Set SSID related parameters*/
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, sParamValue, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			goto status_exit;
		}
		/*Set relevant parameters*/
		HELP_PARAM_SET(tmpPxObjList, "Enable", "true", SOPT_OBJVALUE);
		HELP_PARAM_SET(tmpPxObjList, WIFI_BRIDGE_NAME, DEFAULT_BRIDGE_NAME, SOPT_OBJVALUE);
	} else if (req_operation == STATION_DISABLE) {
		LOGF_LOG_DEBUG("Disable Station VAP\n");
		/*Parse EndPoint entry from Radio name*/
		nRet = client_get_param_from_list(pxObjListMain, CLIENT_OBJECT_ENDPOINT_NAME, curr_entry,
										"RadioType", sParamValue);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to read parameter from DB\n");
			goto status_exit;
		}
		index = client_getInstanceNumFromObjectName(sParamValue);
		if (index < 0) {
			LOGF_LOG_ERROR("Failed to parse instance number!\n");
			nRet = UGW_FAILURE;
			goto status_exit;
		}
		snprintf(ObjNameStr, MAX_LEN_PARAM_VALUE, "%s%d", WIFI_ENDPOINT_OBJECT_NAME, index);

		/*Set values to enable STA VAP*/
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, ObjNameStr, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			goto status_exit;
		}
		/*Set relevant parameters*/
		HELP_PARAM_SET(tmpPxObjList, "Enable", "false", SOPT_OBJVALUE);

		/*Set WDS value*/
		nRet = client_get_param_from_list(pxObjListMain, CLIENT_OBJECT_ENDPOINT_NAME,
									curr_entry, "WDS", sParamValue);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to read parameter from DB\n");
			goto status_exit;
		}

		HELP_PARAM_SET(tmpPxObjList, "X_LANTIQ_COM_Vendor_WaveEndPointWDS", sParamValue, SOPT_OBJVALUE);

		/*Read matching EndPoint SSID Referance*/
		sParamValue[0] = '\0';
		FOR_EACH_OBJ(pxObjListWlan, tmpPxObjList) {
			if (strstr(tmpPxObjList->sObjName, ObjNameStr)
			 && (strlen(tmpPxObjList->sObjName) < strlen(ObjNameStr) + 3)) {
				FOR_EACH_PARAM(tmpPxObjList, pxParam) {
					if (!strcmp(pxParam->sParamName, "SSIDReference")) {
						strncpy(sParamValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
						sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
						break;
					}
				}
			}
		}
		if (sParamValue[0] == '\0') {
			LOGF_LOG_ERROR("Failed to find SSID reference in DB!\n");
			nRet = UGW_FAILURE;
			goto status_exit;
		}

		index = -1;
		/*Set SSID related parameters*/
		tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, sParamValue, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
		if (tmpPxObjList == NULL) {
			LOGF_LOG_ERROR("Failed to set object!!\n");
			goto status_exit;
		}
		/*Set relevant parameters*/
		HELP_PARAM_SET(tmpPxObjList, "Enable", "false", SOPT_OBJVALUE);
		/*Re-enable VAP if needed*/
		LOGF_LOG_DEBUG("VAP bookkeep value will be read from DB\n");
		nRet = client_get_object_from_db(pxObjList, SOPT_OBJVALUE, CLIENT_OBJECT_GENERAL_NAME);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to read object from DB!\n");
			goto status_exit;
		}
		FOR_EACH_OBJ(pxObjList, tmpPxObjList) {
			if (tmpPxObjList->unOid != DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP) {
				continue;
			}
			entry_enable = false;
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_INSTANCENUM) {
					strncpy(sParamValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
				} else if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_BOOKKEEP_MODEENABLED)
				       && (!is_stringFalse(pxParam->sParamValue))) {
					entry_enable = true;
				}
			}
			if (entry_enable) {
				if (!strcmp(sParamValue, "0")) {
					LOGF_LOG_DEBUG("Current entry is 0 - no need to re-enable\n");
					continue;
				}
				LOGF_LOG_DEBUG("Re-enable entry %s\n", sParamValue);
				snprintf(ObjNameStr, MAX_LEN_PARAM_VALUE, "%s%s", WIFI_SSID_OBJECT_NAME, sParamValue);
				tmpPxObjList = HELP_OBJECT_SET(pxObjListNew, ObjNameStr, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
				if (tmpPxObjList == NULL) {
					LOGF_LOG_ERROR("Failed to set object!!\n");
					nRet = UGW_FAILURE;
					goto status_exit;
				}
				/*Set relevant parameters*/
				HELP_PARAM_SET(tmpPxObjList, "Enable", "true", SOPT_OBJVALUE);

				snprintf(ObjNameStr, MAX_LEN_PARAM_VALUE, "%s%s", CLIENT_OBJECT_BOOKKEEP_NAME, sParamValue);
				tmpPxObjList = HELP_OBJECT_SET(pxBookObj, ObjNameStr, NO_ARG_VALUE, OBJOPT_DEL, SOPT_OBJVALUE);
				if (tmpPxObjList == NULL) {
					LOGF_LOG_ERROR("Failed to set object!!\n");
					nRet = UGW_FAILURE;
					goto status_exit;
				}
			}
		}
	}

status_exit:
	LOGF_LOG_DEBUG("Done with return code %d\n", nRet);
	CLIENT_HELP_DELETE_OBJ(pxObjList, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_stationChangeMode
 *  Description   : Function to handle station mode change (Enable / Disable)
 * ===================================================================================*/
static int client_stationChangeMode(ObjList *pxObjMain, int curr_entry, sl_operations interface_op, ObjList *pxBookObj)
{
	int nRet = UGW_SUCCESS;
	bool entry_status = false;
	char sParamValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sObjName[MAX_LEN_PARAM_VALUE] = { '\0' };
	ObjList *pxObjListInter = client_help_create_obj();
	ObjList *pxObjListWlan = client_help_create_obj();
	ObjList *tmpPxObj = NULL;
	ParamList *pxParam = NULL;

	/*Prepare interface creation object*/
	if (!pxObjListInter || !pxObjMain || !pxBookObj || !pxObjListWlan) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto interface_exit;
	}

	/*Read WLAN object from DB*/
	if ((nRet = client_get_object_from_db(pxObjListWlan, SOPT_OBJVALUE, WIFI_GENERAL_OBJECT_NAME))) {
		LOGF_LOG_ERROR("Failed to read object from DB!\n");
		goto interface_exit;
	}

	nRet = client_handleSTAStatusChange(pxBookObj, pxObjListInter, pxObjMain, pxObjListWlan, interface_op, curr_entry);
	if (nRet == NO_INTERACTION_REQ) {
		LOGF_LOG_DEBUG("No operation required\n");
		nRet = UGW_SUCCESS;
		goto interface_exit;
	}
	else if (nRet != UGW_SUCCESS) {
		LOGF_LOG_ERROR("Failed to prepare interface object list\n");
		goto interface_exit;
	}

	LOGF_LOG_DEBUG("Trigger SL request with the following object list:\n");
	HELP_PRINT_OBJ(pxObjListInter, 0x4);

	if (HELP_IS_EMPTY_OBJ_PARAM(pxObjListInter)) {
		/*Trigger SL request*/
		if ((nRet = SERVD_CAL_SET_SERVICE(pxObjListInter) != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to transfer request to SL interface!\n");
			goto interface_exit;
		}
	}
	sParamValue[0] = '\0';
	nRet = client_get_param_from_list(pxObjMain, CLIENT_OBJECT_ENDPOINT_NAME, curr_entry, "WDS", sParamValue);
	if (nRet) {
		LOGF_LOG_ERROR("Failed to read WDS parameter from DB - Exit!\n");
		nRet = UGW_FAILURE;
		goto interface_exit;
	}

	if (!is_stringFalse(sParamValue)) {
		LOGF_LOG_DEBUG("No need to enable L2NAT - WDS is enabled\n");
		nRet = UGW_SUCCESS;
		goto interface_exit;
	}
	LOGF_LOG_DEBUG("Setting L2NAT status\n");
	sObjName[0] = '\0';
	FOR_EACH_OBJ(pxObjListInter, tmpPxObj) {
		if (strstr(tmpPxObj->sObjName, WIFI_SSID_OBJECT_NAME)
		 && (strlen(tmpPxObj->sObjName) < strlen(WIFI_SSID_OBJECT_NAME) + 3) ) {
			strncpy(sObjName, tmpPxObj->sObjName, MAX_LEN_PARAM_VALUE - 1);
			sObjName[MAX_LEN_PARAM_VALUE - 1] = '\0';
		}
	}
	if (sObjName[0] == '\0') {
		LOGF_LOG_ERROR("Failed to find SSID entry in returned Object!\n");
		nRet = UGW_FAILURE;
		goto interface_exit;
	}

	/*Looping now on SSID object*/
	if (interface_op == STATION_ENABLE) {
		entry_status = true;
	} else {
		entry_status = false;
	}

	sParamValue[0] = '\0';
	FOR_EACH_OBJ(pxObjListWlan, tmpPxObj) {
		if (!strstr(sObjName, tmpPxObj->sObjName)) {
			continue;
		}
		FOR_EACH_PARAM(tmpPxObj, pxParam) {
			if (!strcmp(pxParam->sParamName, "Name")) {
				strncpy(sParamValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
				sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
			}
		}
	}
	if (sParamValue[0] == '\0') {
		LOGF_LOG_ERROR("Failed to parse STA VAP Name from DB!\n");
		nRet = UGW_FAILURE;
		goto interface_exit;
	}
	if (entry_status) {
		LOGF_LOG_DEBUG("Enable L2NAT\n");
		nRet = client_setL2NATStatus(L2NAT_ENABLE, sParamValue);
	} else {
		LOGF_LOG_DEBUG("Disabling L2NAT\n");
		nRet = client_setL2NATStatus(L2NAT_DISABLE, sParamValue);
	}

	if (nRet) {
		LOGF_LOG_ERROR("Failed to change L2NAT!\n");
		goto interface_exit;
	}

interface_exit:
	CLIENT_HELP_DELETE_OBJ(pxObjListInter, FREE_OBJLIST);
	CLIENT_HELP_DELETE_OBJ(pxObjListWlan, FREE_OBJLIST);
	LOGF_LOG_DEBUG("Function done with return code %d\n", nRet);
	return nRet;
}

static int client_rollBack(sl_operations switch_mode, ObjList *pxBookObj, ObjList *pxMainObj, ObjList *pxObjListWlan)
{
	int nRet = UGW_SUCCESS;

	if (switch_mode == GW_MODE) {
		LOGF_LOG_DEBUG("Rolling back to GW mode\n");
		/*ToDo - Enable Gateway features*/

		/*Disconnect STA VAP*/
		LOGF_LOG_DEBUG("Disconnect STA VAP\n");
		if ((nRet = client_disconnectSTAfromAP(pxObjListWlan))) {
			LOGF_LOG_ERROR("Failed to Disconnect STA VAP!\n");
			goto rollback_exit;
		}

		/*Configure AP networks back to pre-saved values*/
		LOGF_LOG_DEBUG("Configure AP networks back to pre-saved values\n");
		if ((nRet = client_configureGWAP(pxBookObj, pxMainObj, pxObjListWlan))) {
			LOGF_LOG_ERROR("Failed to configure AP networks back to pre-saved values!\n");
			goto rollback_exit;
		}

		/*Configure bridge to GW mode*/
		if ((nRet = client_configureBridgeGW(pxBookObj, pxMainObj))) {
			LOGF_LOG_ERROR("Failed to Configure bridge according to user request!\n");
			goto rollback_exit;
		}

		/*reconnect all previously disabled VAPs*/
		LOGF_LOG_DEBUG("Reconnect all previously disabled VAPs\n");
		if ((nRet = client_enableVAPforGW(pxMainObj))) {
			LOGF_LOG_ERROR("Failed to reconnect previously disabled VAPs!\n");
			goto rollback_exit;
		}

		LOGF_LOG_DEBUG("Delete all bookkeep information from DB\n");
		if ((nRet = client_deleteBookkeep(pxBookObj, pxMainObj))) {
			LOGF_LOG_ERROR("Failed to delete bookkeep values from DB\n");
			goto rollback_exit;
		}
	}

rollback_exit:
	LOGF_LOG_DEBUG("Rollback function is done with exit value %d\n", nRet);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_handleModifyCurrStatus
 *  Description   : Function to handle a modification of current state - without
 *      	    switching to GW / Repeater
 * ===================================================================================*/
static int client_handleModifyCurrStatus(ObjList *pxObjList, ObjList *pxBookObj)
{
	ObjList *pxMainObj = client_help_create_obj();
	ObjList *pxObjListWlan = client_help_create_obj();
	ObjList *tmpPxObjList = NULL;
	ParamList *pxParam = NULL;
	int nRet = NO_INTERACTION_REQ;
	char sParamValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	bool modify_operation = true;
	AP_params ap_param;

	if (!pxObjList || !pxBookObj || !pxMainObj) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto modify_status_exit;
	}
	/*Assumption here is that profile Enable parameter will not be included in this case*/
	FOR_EACH_OBJ(pxObjList, tmpPxObjList) {
		if (tmpPxObjList->unOid == DEVICE_X_LANTIQ_COM_CLIENTMODE_ENDPOINT) {
			LOGF_LOG_DEBUG("Received object includes general endpoint information\n");
			modify_operation = false;
			break;
		} else if (tmpPxObjList->unOid != DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE) {
				continue;
		}

		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if (pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_PROFILE_ENABLE) {
				modify_operation = false;
			}
		}
	}

	if (!modify_operation) {
		LOGF_LOG_INFO("Operation is not modify of current status - continue to parse request\n");
		nRet = NO_INTERACTION_REQ;
		goto modify_status_exit;
	}

	/*Read data from DB to be used for restore information*/
	if ((nRet = client_parseDB(pxMainObj, pxObjList))) {
		LOGF_LOG_ERROR("Failed to read data from DB\n");
		goto modify_status_exit;
	}
	if ((nRet = client_get_param_from_list(pxMainObj, CLIENT_OBJECT_GENERAL_NAME, 0, "GWMode", sParamValue))) {
		LOGF_LOG_ERROR("Failed to read parameter from DB - %s\n", CLIENT_OBJECT_GENERAL_NAME);
		goto modify_status_exit;
	}

	if (!is_stringFalse(sParamValue)) {
		LOGF_LOG_INFO("Modify operation is not supported in GW mode\n");
		nRet = NO_INTERACTION_REQ;
		goto modify_status_exit;
	}

	LOGF_LOG_DEBUG("First step - Switch back to GW mode\n");
	/*Read WLAN object from DB*/
	if ((nRet = client_get_object_from_db(pxObjListWlan, SOPT_OBJVALUE, WIFI_GENERAL_OBJECT_NAME))) {
		LOGF_LOG_ERROR("Failed to read object from DB!\n");
		goto modify_status_exit;
	}

	if ((nRet = client_rollBack(GW_MODE, pxBookObj, pxMainObj, pxObjListWlan))) {
			LOGF_LOG_ERROR("Failed to rollback to GW mode!\n");
			goto modify_status_exit;
	}

	/*Enable repeater mode*/
	LOGF_LOG_DEBUG("Read and disable all VAPs except for main VAPs\n");
	if ((nRet = client_disableVAPforRepeater(pxBookObj, pxObjListWlan, pxMainObj)) != UGW_SUCCESS) {
		LOGF_LOG_ERROR("Failed to disable all VAPs in DB!\n");
		goto modify_status_exit;
	}

	/*Connect STA VAP to AP*/
	LOGF_LOG_DEBUG("Connecting STA VAP to far AP\n");
	if ((nRet = client_connectSTAtoAP(pxObjListWlan, pxMainObj, &ap_param)) != UGW_SUCCESS) {
		LOGF_LOG_ERROR("Failed to connect STA VAP to far AP!\n");
		goto modify_status_exit;
	}

	/*Configure local AP networks*/
	LOGF_LOG_DEBUG("Configure local AP according to user request\n");
	if (((nRet = client_configureRepeaterAP(pxBookObj, pxObjListWlan, pxMainObj, &ap_param))) != UGW_SUCCESS) {
		LOGF_LOG_ERROR("Failed to Configure local AP according to user request!\n");
		goto modify_status_exit;
	}

	/*Configure bridge to Repeater mode*/
	if ((nRet = client_configureBridgeRepeater(pxBookObj, pxMainObj, pxObjListWlan)) != UGW_SUCCESS) {
		LOGF_LOG_ERROR("Failed to Configure bridge according to user request!\n");
		goto modify_status_exit;
	}

	/*ToDo - Disable Gateway features*/
	LOGF_LOG_DEBUG("Bookkeep GW mode status\n");
	tmpPxObjList = HELP_OBJECT_SET(pxBookObj, CLIENT_OBJECT_GENERAL_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
	if (tmpPxObjList == NULL) {
		LOGF_LOG_ERROR("Failed to set bookkeep object!!\n");
		nRet = UGW_FAILURE;
		goto modify_status_exit;
	}
	/*Set relevant parameters*/
	HELP_PARAM_SET(tmpPxObjList, "GWMode", "false", SOPT_OBJVALUE);

	nRet = UGW_SUCCESS;

modify_status_exit:
	LOGF_LOG_DEBUG("Function is done with return value %d\n", nRet);
	CLIENT_HELP_DELETE_OBJ(pxObjListWlan, FREE_OBJLIST);
	CLIENT_HELP_DELETE_OBJ(pxMainObj, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : client_parseRequest
 *  Description   : Function to parse user request operation and handle accordingly
 * ===================================================================================*/

static int client_parseRequest(sl_operations req_operation, ObjList *pxObjList, ObjList *pxBookObj, int curr_entry)
{
	ObjList *pxMainObj = client_help_create_obj();
	ObjList *pxUnifiedObj = client_help_create_obj();
	ObjList *pxObjListWlan = client_help_create_obj();
	ObjList *tmpPxObjList = NULL;
	ParamList *pxParam = NULL;
	char currValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	char reqValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sParamValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	int nRet = UGW_SUCCESS;
	AP_params ap_param;

	if (!pxObjList || !pxBookObj || !pxObjListWlan || !pxMainObj || !pxUnifiedObj || curr_entry < 0) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto parse_exit;
	}

	if (req_operation == STATION_CHANGE_STATE) {
		/*Compare requested value from caller with current status*/
		if ((nRet = client_get_object_from_db(pxMainObj, SOPT_OBJVALUE, CLIENT_OBJECT_ENDPOINT_NAME))) {
			LOGF_LOG_INFO("Failed to read object %s from DB, assume not exist\n", CLIENT_OBJECT_ENDPOINT_NAME);
			nRet = UGW_SUCCESS;
			strncpy(currValue, "false", MAX_LEN_PARAM_VALUE);
		} else {
			nRet = client_get_param_from_list(pxMainObj, CLIENT_OBJECT_ENDPOINT_NAME, curr_entry, "Enable", currValue);
			if (nRet) {
				LOGF_LOG_INFO("Failed to read parameter from DB - %s! assuming feature is disabled\n", currValue);
				strncpy(currValue, "false", MAX_LEN_PARAM_VALUE);
				nRet = UGW_SUCCESS;
			}
		}

		/*Read caller request value*/
		if ((nRet = client_get_param_from_list(pxObjList, CLIENT_OBJECT_ENDPOINT_NAME, curr_entry, "Enable", reqValue))) {
			LOGF_LOG_INFO("Failed to read Enable/Disable parameter from User DB - %s!\n", reqValue);
			LOGF_LOG_INFO("Check to see if WDS parameter was set by user!\n");
			nRet = client_get_param_from_list(pxObjList, CLIENT_OBJECT_ENDPOINT_NAME, curr_entry, "WDS", reqValue);
			if (nRet) {
				LOGF_LOG_ERROR("Failed to read WDS parameter from DB - Exit!\n");
				nRet = UGW_FAILURE;
				goto parse_exit;
			}
			/*handle a case were only WDS was changed*/
			nRet = client_changeWDSstatus(reqValue);
			goto parse_exit;
		}

		if (!strcmp(currValue, reqValue)) {
			LOGF_LOG_DEBUG("Request from user has no meaning as current status is already %s\n", currValue);
			nRet = UGW_SUCCESS;
			goto parse_exit;
		}

		if (is_stringFalse(reqValue)) {
			/*Read data from DB to be used for restore information*/
			if ((nRet = client_parseDB(pxUnifiedObj, pxObjList))) {
				LOGF_LOG_ERROR("Failed to read data from DB\n");
				goto parse_exit;
			}
			nRet = client_stationChangeMode(pxUnifiedObj, curr_entry, STATION_DISABLE, pxBookObj);
		} else {
			/*Verify no other Endpoint value is set to Enable in DB*/
			FOR_EACH_OBJ(pxMainObj, tmpPxObjList) {
				if (tmpPxObjList->unOid != DEVICE_X_LANTIQ_COM_CLIENTMODE_ENDPOINT) {
					continue;
				}
				FOR_EACH_PARAM(tmpPxObjList, pxParam) {
					if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_ENDPOINT_ENABLE)
					 && (!is_stringFalse(pxParam->sParamValue))) {
						LOGF_LOG_ERROR("Trying to enable more than 1 STA VAP is not permitted");
						nRet = UGW_FAILURE;
						goto parse_exit;
					}
				}
			}
			/*Read data from DB to be used for restore information*/
			if ((nRet = client_parseDB(pxUnifiedObj, pxObjList))) {
				LOGF_LOG_ERROR("Failed to read data from DB\n");
				goto parse_exit;
			}
			nRet = client_stationChangeMode(pxUnifiedObj, curr_entry, STATION_ENABLE, pxBookObj);
		}

		if (nRet) {
			LOGF_LOG_ERROR("Failed to set station mode!\n");
			goto parse_exit;
		}
	} else if (req_operation == SYSTEM_CHANGE_STATE) {
		/*Read data from DB to be used for restore information*/
		if ((nRet = client_parseDB(pxMainObj, pxObjList))) {
			LOGF_LOG_ERROR("Failed to read data from DB\n");
			goto parse_exit;
		}
		/*Parse user request*/
		if ((nRet = client_get_param_from_list(pxMainObj, CLIENT_OBJECT_GENERAL_NAME, 0, "GWMode", sParamValue))) {
			LOGF_LOG_ERROR("Failed to read parameter from DB - %s\n", CLIENT_OBJECT_GENERAL_NAME);
			goto parse_exit;
		}

		if ((nRet = client_get_param_from_list(pxObjList, CLIENT_OBJECT_PROFILE_NAME, curr_entry, "Enable", reqValue))) {
			LOGF_LOG_INFO("Failed to read parameter from DB - %s Assume it is false\n", CLIENT_OBJECT_PROFILE_NAME);
			strncpy(reqValue, "false", MAX_LEN_PARAM_VALUE);
		}

		if (is_stringFalse(reqValue) == !is_stringFalse(sParamValue)) {
			if (!is_stringFalse(reqValue)) {
				LOGF_LOG_DEBUG("User request is not supported\n");
				nRet = UGW_SUCCESS;
				goto parse_exit;
			} else {
				LOGF_LOG_INFO("Mode change is not required as we are already in required mode - GW is %s\n", sParamValue);
				nRet = UGW_SUCCESS;
				goto parse_exit;
			}
		}

		/*Read WLAN object from DB*/
		if ((nRet = client_get_object_from_db(pxObjListWlan, SOPT_OBJVALUE, WIFI_GENERAL_OBJECT_NAME))) {
			LOGF_LOG_ERROR("Failed to read object from DB!\n");
			goto parse_exit;
		}

		if (is_stringFalse(reqValue)) {
			if ((nRet = client_rollBack(GW_MODE, pxBookObj, pxMainObj, pxObjListWlan))) {
				LOGF_LOG_ERROR("Failed to rollback to GW mode!\n");
				goto parse_exit;
			}
			tmpPxObjList = HELP_OBJECT_SET(pxBookObj, CLIENT_OBJECT_GENERAL_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
			if (tmpPxObjList == NULL) {
				LOGF_LOG_ERROR("Failed to set bookkeep object!!\n");
				nRet = UGW_FAILURE;
				goto parse_exit;
			}
			/*Set relevant parameters*/
			HELP_PARAM_SET(tmpPxObjList, "GWMode", "true", SOPT_OBJVALUE);

		} else {
			/*Enable repeater mode*/
			LOGF_LOG_DEBUG("Read and disable all VAPs except for main VAPs\n");
			if ((nRet = client_disableVAPforRepeater(pxBookObj, pxObjListWlan, pxMainObj)) != UGW_SUCCESS) {
				LOGF_LOG_ERROR("Failed to disable all VAPs in DB!\n");
				goto parse_exit;
			}

			/*Connect STA VAP to AP*/
			LOGF_LOG_DEBUG("Connecting STA VAP to far AP\n");
			if ((nRet = client_connectSTAtoAP(pxObjListWlan, pxMainObj, &ap_param)) != UGW_SUCCESS) {
				LOGF_LOG_ERROR("Failed to connect STA VAP to far AP!\n");
				goto parse_exit;
			}

			/*Configure local AP networks*/
			LOGF_LOG_DEBUG("Configure local AP according to user request\n");
			if (((nRet = client_configureRepeaterAP(pxBookObj, pxObjListWlan, pxMainObj, &ap_param))) != UGW_SUCCESS) {
				LOGF_LOG_ERROR("Failed to Configure local AP according to user request!\n");
				goto parse_exit;
			}

			/*Configure bridge to Repeater mode*/
			if ((nRet = client_configureBridgeRepeater(pxBookObj, pxMainObj, pxObjListWlan)) != UGW_SUCCESS) {
				LOGF_LOG_ERROR("Failed to Configure bridge according to user request!\n");
				goto parse_exit;
			}

			/*ToDo - Disable Gateway features*/
			LOGF_LOG_DEBUG("Bookkeep GW mode status\n");
			tmpPxObjList = HELP_OBJECT_SET(pxBookObj, CLIENT_OBJECT_GENERAL_NAME, NO_ARG_VALUE, OBJOPT_MODIFY, SOPT_OBJVALUE);
			if (tmpPxObjList == NULL) {
				LOGF_LOG_ERROR("Failed to set bookkeep object!!\n");
				nRet = UGW_FAILURE;
				goto parse_exit;
			}
			/*Set relevant parameters*/
			HELP_PARAM_SET(tmpPxObjList, "GWMode", "false", SOPT_OBJVALUE);
		}
	}

parse_exit:
	CLIENT_HELP_DELETE_OBJ(pxMainObj, FREE_OBJLIST);
	CLIENT_HELP_DELETE_OBJ(pxUnifiedObj, FREE_OBJLIST);
	CLIENT_HELP_DELETE_OBJ(pxObjListWlan, FREE_OBJLIST);
	return nRet;
}

static int client_init_run(ObjList *pxMainObj, ObjList *pxBookObj)
{
	int nRet = UGW_SUCCESS, curr_entry = -1;
	ObjList *pxWlanObj = client_help_create_obj();
	ObjList *tmpPxObjList = NULL;
	ParamList *pxParam = NULL;
	char sSSIDValue[MAX_LEN_PARAM_VALUE] = { '\0' };
	char sParamValue[MAX_LEN_PARAM_VALUE] ={ '\0' };
	bool feature_enable = false, wds_enable = false, endpoint_enable = false;

	if (!pxWlanObj || !pxMainObj || !pxBookObj) {
		LOGF_LOG_ERROR("Received empty object from caller or failed to create object\n");
		nRet = UGW_FAILURE;
		goto init_run_exit;
	}

	/*Check if Client Mode is enabled in DB*/
	FOR_EACH_OBJ(pxMainObj, tmpPxObjList) {
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_RULENUMBEROFENTRIES)
			 && (strcmp(pxParam->sParamValue, "0"))){
				feature_enable = true;
				break;
			} else if ((pxParam->unParamId == DEVICE_X_LANTIQ_COM_CLIENTMODE_ENDPOINT_ENABLE)
			 && (!is_stringFalse(pxParam->sParamValue))){
				feature_enable = true;
				break;
			}
		}
	}
	if (feature_enable == false) {
		LOGF_LOG_DEBUG("Client mode feature is disabled - exiting\n");
		nRet = UGW_SUCCESS;
		goto init_run_exit;
	}
	LOGF_LOG_DEBUG("Client mode feature is enabled - check if it is already configured\n");
	/*Check if Client Mode configuration required*/
	if ((nRet = client_get_object_from_db(pxWlanObj, SOPT_OBJVALUE, WIFI_GENERAL_OBJECT_NAME))) {
		LOGF_LOG_ERROR("Failed to read value from DB\n");
		goto init_run_exit;
	}
	feature_enable = false;
	FOR_EACH_OBJ(pxWlanObj, tmpPxObjList) {
		if (!strstr(tmpPxObjList->sObjName, WIFI_ENDPOINT_OBJECT_NAME)
		 || (strlen(tmpPxObjList->sObjName) > (strlen(WIFI_ENDPOINT_OBJECT_NAME) + 3))) {
			continue;
		}
		FOR_EACH_PARAM(tmpPxObjList, pxParam) {
			if (!strcmp(pxParam->sParamName, "Enable")
			 && (!is_stringFalse(pxParam->sParamValue))) {
				feature_enable = true;
				LOGF_LOG_DEBUG("Client Mode feature is already enabled in DB\n");
			} else if (!strcmp(pxParam->sParamName, "SSIDReference")) {
				strncpy(sSSIDValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
				sSSIDValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
			}
		}
		if (feature_enable) {
			break;
		}
	}

	/*check if WDS is enabled or not in WLAN DB*/
	wds_enable = false;
	endpoint_enable = false;
	FOR_EACH_OBJ(pxWlanObj, tmpPxObjList) {
		if (strstr(tmpPxObjList->sObjName, WIFI_ENDPOINT_OBJECT_NAME)
		 && (strlen(tmpPxObjList->sObjName) < strlen(WIFI_ENDPOINT_OBJECT_NAME) + 3)) {
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "X_LANTIQ_COM_Vendor_WaveEndPointWDS")
				 && (!is_stringFalse(pxParam->sParamValue))) {
					wds_enable = true;
				} else if (!strcmp(pxParam->sParamName, "Enable")
					&& (!is_stringFalse(pxParam->sParamValue))) {
					endpoint_enable = true;
				}
			}
			if (wds_enable && endpoint_enable) {
				LOGF_LOG_DEBUG("Detected WDS enabled - not enabling L2NAT\n");
				break;
			} else {
				wds_enable = false;
				endpoint_enable = false;
			}
		}
	}

	if (feature_enable && !wds_enable && !endpoint_enable) {
		LOGF_LOG_DEBUG("Client Mode feature is already enabled. Enabling L2NAT\n");
		FOR_EACH_OBJ(pxWlanObj, tmpPxObjList) {
			if (strcmp(tmpPxObjList->sObjName, sSSIDValue)) {
				continue;
			}
			FOR_EACH_PARAM(tmpPxObjList, pxParam) {
				if (!strcmp(pxParam->sParamName, "Name")) {
					strncpy(sParamValue, pxParam->sParamValue, MAX_LEN_PARAM_VALUE - 1);
					sParamValue[MAX_LEN_PARAM_VALUE - 1] = '\0';
				}
			}

			if (sParamValue[0] == '\0') {
				LOGF_LOG_ERROR("Failed to parse STA VAP Name from DB!\n");
				nRet = UGW_FAILURE;
				goto init_run_exit;
			}
			LOGF_LOG_DEBUG("Enable L2NAT\n");
			nRet = client_setL2NATStatus(L2NAT_ENABLE, sParamValue);
			if (nRet) {
				LOGF_LOG_ERROR("Failed to Enable L2NAT!\n");
				goto init_run_exit;
			}
			goto init_run_exit;
		}
	}

	LOGF_LOG_DEBUG("Client Mode feature will now be enabled\n");

	/*Set up STA VAP channel*/
	FOR_EACH_OBJ(pxMainObj, tmpPxObjList) {
		if (strstr(tmpPxObjList->sObjName, CLIENT_OBJECT_ENDPOINT_NAME)) {
			curr_entry = client_getInstanceNumFromObjectName(tmpPxObjList->sObjName);
			if (curr_entry < 0) {
				LOGF_LOG_ERROR("Failed to parse instance number!\n");
				nRet = UGW_FAILURE;
				goto init_run_exit;
			}
			nRet = client_parseRequest(STATION_CHANGE_STATE, pxMainObj, pxBookObj, curr_entry);
			if (nRet) {
				LOGF_LOG_ERROR("Failed to set up STA VAP!\n");
				goto init_run_exit;
			}
		}
	}
	feature_enable = false;
	/*Check if set up of repeater mode required*/
	FOR_EACH_OBJ(pxMainObj, tmpPxObjList) {
		if (strstr(tmpPxObjList->sObjName, CLIENT_OBJECT_RULE_NAME)
		 ||(strstr(tmpPxObjList->sObjName, CLIENT_OBJECT_PROFILE_NAME))) {
			feature_enable = true;
		}
	}

	if (feature_enable) {
		nRet = client_parseRequest(SYSTEM_CHANGE_STATE, pxMainObj, pxBookObj, 0);
		if (nRet) {
			LOGF_LOG_ERROR("Failed to enable repeater mode!\n");
			goto init_run_exit;
		}
	}

init_run_exit:
	CLIENT_HELP_DELETE_OBJ(pxWlanObj, FREE_OBJLIST);
	return nRet;
}

/* ===================================================================================
 *  Function Name : sl_client_init
 *  Description   : Client Mode function to handle init routine
 * ===================================================================================*/
static void sl_client_init(INOUT ServdData *pxSlData)
{
	pxSlData->nStatus = UGW_SUCCESS;
}

/* ===================================================================================
 *  Function Name : sl_client_uninit
 *  Description   : Client Mode function to handle uninit routine
 * ===================================================================================*/
static void sl_client_uninit(INOUT ServdData *pxSlData)
{
	LOGF_LOG_DEBUG("Client Mode >> UNINIT function done\n");
	pxSlData->nStatus = UGW_SUCCESS;
}

/* ===================================================================================
 *  Function Name : sl_client_modify
 *  Description   : Client Mode function to handle modifications
 * ===================================================================================*/
static void sl_client_modify(INOUT ServdData *pxSlData)
{
	int nRet = UGW_SUCCESS, curr_entry = 0;
	ObjList *pxBookObj = client_help_create_obj();
	ObjList *pxObjList = pxSlData->pxObjList;
	ObjList *pxTmpObj = NULL;

	LOGF_LOG_DEBUG("Client Mode >> MODIFY function: ops = %d\n", pxSlData->unMainOper);
	if (!pxBookObj || !pxObjList) {
		LOGF_LOG_ERROR("Client empty object list detected! Modify fails\n");
		nRet = UGW_FAILURE;
		goto modify_exit;
	}

	/*Check if caller request is to modify current status without switching to GW/Repeater*/
	nRet = client_handleModifyCurrStatus(pxObjList, pxBookObj);
	if (nRet != NO_INTERACTION_REQ) {
		goto modify_exit;
	}

	nRet = UGW_SUCCESS;
	/*Handle the request arrived from caller*/
	FOR_EACH_OBJ(pxObjList, pxTmpObj) {
		if (strstr(pxTmpObj->sObjName, CLIENT_OBJECT_ENDPOINT_NAME)) {
			curr_entry = client_getInstanceNumFromObjectName(pxTmpObj->sObjName);
			if (curr_entry < 0) {
				LOGF_LOG_ERROR("Failed to parse instance number!\n");
				nRet = UGW_FAILURE;
				goto modify_exit;
			}
			nRet = client_parseRequest(STATION_CHANGE_STATE, pxObjList, pxBookObj, curr_entry);
			/*No need to continue to loop on objects*/
			break;
		} else if (strstr(pxTmpObj->sObjName, CLIENT_OBJECT_RULE_NAME)
			||(strstr(pxTmpObj->sObjName, CLIENT_OBJECT_PROFILE_NAME))) {
				if ((curr_entry = client_parseProfileEntry(pxObjList)) < 0) {
					LOGF_LOG_ERROR("Failed to parse received profile instance number!\n");
					nRet = UGW_FAILURE;
					goto modify_exit;
				}
			nRet = client_parseRequest(SYSTEM_CHANGE_STATE, pxObjList, pxBookObj, curr_entry);
			/*No need to continue to loop on objects*/
			break;
		} else
			continue;

		if ((nRet != NO_INTERACTION_REQ) && (nRet != UGW_SUCCESS)) {
			LOGF_LOG_ERROR("Failed to handle modify request!\n");
			goto modify_exit;
		}
	}

modify_exit:
	if (nRet != UGW_SUCCESS) {
		LOGF_LOG_ERROR("Client Mode >> MODIFY function done with exit value %d\n", nRet);
		nRet = UGW_FAILURE;
	} else {
		FOR_EACH_OBJ(pxObjList, pxTmpObj) {
			if(IS_OBJOPT_ADD(pxTmpObj->unObjOper)) {
				pxTmpObj->unObjOper = OBJOPT_MODIFY;
			}
		}
		if (HELP_IS_EMPTY_OBJ_PARAM(pxBookObj)) {
			client_help_copy_obj(pxObjList, pxBookObj, COPY_COMPLETE_OBJ);
		}
	}
	CLIENT_HELP_DELETE_OBJ(pxBookObj, FREE_OBJLIST);
	pxSlData->nStatus = nRet;

	LOGF_LOG_DEBUG("Client Mode >> MODIFY function done with exit value %d bookkeep values:\n", nRet);
	HELP_PRINT_OBJ(pxObjList, 0x4);
	return;
}

/* ===================================================================================
 *  Function Name : sl_client_notify
 *  Description   : Client Mode function to handle notifications
 * ===================================================================================*/
static void sl_client_notify(INOUT ServdData *pxSlData)
{
	int nRet = UGW_SUCCESS;
	ObjList *pxBookObj = client_help_create_obj();
	ObjList *pxMainObj = client_help_create_obj();

	LOGF_LOG_DEBUG("Client Mode >> NOTIFY function: ops = %d\n", pxSlData->unMainOper);
	if (!pxBookObj || !pxMainObj) {
		LOGF_LOG_ERROR("Client failed to create object\n");
		nRet = UGW_FAILURE;
		goto notify_exit;
	}

	if ((nRet = client_parseDB(pxMainObj, pxSlData->pxObjList))) {
		LOGF_LOG_ERROR("Failed to parse Object list from DB\n");
		goto notify_exit;
	}

	switch (pxSlData->xNotify.unNotifyId) {
		case NOTIFY_ALL_INIT_COMPLETED:
			LOGF_LOG_INFO("Client Mode - all SL finished booting - start init routine\n");
			nRet = client_init_run(pxMainObj, pxBookObj);
			break;
		default:
			LOGF_LOG_INFO("Client Mode unfamiliar notification\n");
			break;
	}

notify_exit:
	if (nRet == UGW_SUCCESS) {
		/*Bookkeep values to DB*/
		if (!pxSlData->pxObjList) {
			pxSlData->pxObjList = pxBookObj;
		} else {
			client_help_copy_obj(pxSlData->pxObjList, pxBookObj, COPY_COMPLETE_OBJ);
			CLIENT_HELP_DELETE_OBJ(pxBookObj, FREE_OBJLIST);
		}
	} else {
		nRet = UGW_FAILURE;
	}

	CLIENT_HELP_DELETE_OBJ(pxMainObj, FREE_OBJLIST);
	pxSlData->nStatus = nRet;
	LOGF_LOG_DEBUG("Client Mode >> NOTIFY function done\n");
	return;
}

/* ===================================================================================
 *  Function Name : sl_client_handler
 *  Description   : Client Mode handler function to external requests
 * ===================================================================================*/

void sl_client_handler(SERVDEXPORTS, INOUT ServdData *pxSlData)
{
	LOCAL_EXPORT_SERVDEXPORTS;
	if (IS_MOPT_INIT (pxSlData->unMainOper)) {
		sl_client_init(pxSlData);
	} else if (IS_MOPT_UNINIT (pxSlData->unMainOper)) {
		sl_client_uninit(pxSlData);
	} else if (IS_MOPT_MODIFY (pxSlData->unMainOper)) {
		sl_client_modify(pxSlData);
	} else if (IS_MOPT_NOTIFY (pxSlData->unMainOper)) {
		sl_client_notify(pxSlData);
	} else{
		pxSlData->nStatus = SL_FUNC_NOT_SUPPORTED;
	}
	return;
}
