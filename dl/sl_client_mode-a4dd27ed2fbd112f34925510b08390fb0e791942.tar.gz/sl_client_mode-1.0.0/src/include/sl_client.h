/*******************************************************************************
			Copyright (c) 2015
			Lantiq Beteiligungs-GmbH & Co. KG

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.
********************************************************************************/

/*  *****************************************************************************
 *         File Name    : sl_client.h                                          *
 *         Description  : client mode related structs,defs,enums,prototyps *
 *  *****************************************************************************/

/*! \file sl_client.h
 \brief This File contains the Constants, enumerations, related Data
    structures and API's.
*/

#ifndef _SL_CLIENT_H
#define _SL_CLIENT_H

#include <ugw_proto.h>
#include "sl_hook.h"
#include "ugw_structs.h"
#include "ltq_api_include.h"
#include "client_id.h"

/*DB and servd*/
OBJS_SUPPORTED = {
	"Device.X_LANTIQ_COM_ClientMode",
	"Device.X_LANTIQ_COM_ClientMode.EndPoint",
	"Device.X_LANTIQ_COM_ClientMode.Rule",
	"Device.X_LANTIQ_COM_ClientMode.Profile",
	"Device.X_LANTIQ_COM_ClientMode.Profile.Security",
	"Device.X_LANTIQ_COM_ClientMode.Bookkeep",
};

OBJS_DEPENDS = {
};

OBJS_NOTIFY = {
	NOTIFY_ALL_INIT_COMPLETED,
};

SL_IDENTIFY = {
	/*Feature SL should always start after native SLs*/
	.name = "sl_client",
	.start = 99,
	OBJS_FILL
};

/*Defined objects*/
#define CLIENT_OBJECT_GENERAL_NAME	"Device.X_LANTIQ_COM_ClientMode."
#define CLIENT_OBJECT_ENDPOINT_NAME	"Device.X_LANTIQ_COM_ClientMode.EndPoint."
#define CLIENT_OBJECT_RULE_NAME	"Device.X_LANTIQ_COM_ClientMode.Rule."
#define CLIENT_OBJECT_PROFILE_NAME	"Device.X_LANTIQ_COM_ClientMode.Profile."
#define CLIENT_OBJECT_BOOKKEEP_NAME	"Device.X_LANTIQ_COM_ClientMode.Bookkeep."

/*WiFi Related Objects*/
#define WIFI_GENERAL_OBJECT_NAME	"Device.WiFi."
#define WIFI_SSID_OBJECT_NAME	"Device.WiFi.SSID."
#define WIFI_ENDPOINT_OBJECT_NAME	"Device.WiFi.EndPoint."
#define WIFI_ENDPOINT_PROFILE_OBJECT_NAME	"Device.WiFi.EndPoint.Profile."
#define WIFI_ACCESSPOINT_OBJECT_NAME	"Device.WiFi.AccessPoint."
#define WIFI_RADIO_OBJECT_NAME	"Device.WiFi.Radio."

/*Network Related Objects*/
#define NETWORK_ETH_GENERAL_OBJECT_NAME	"Device.Ethernet."
#define NETWORK_DHCP4_OBJECT_NAME	"Device.DHCPv4.Server."
#define NETWORK_DHCP4_CLIENT_OBJECT_NAME	"Device.DHCPv4.Client."
#define NETWORK_DHCP6_OBJECT_NAME	"Device.DHCPv6.Server."
#define NETWORK_DHCP4_RELAY_OBJECT_NAME	"Device.DHCPv4.Relay."
#define NETWORK_DNS_RELAY_OBJECT_NAME	"Device.DNS.Relay."
#define NETWORK_DNS_CLIENT_RELAY_OBJECT_NAME	"Device.DNS.Client."
#define NETWORK_ETH_INTERFACE_OBJECT_NAME	"Device.Ethernet.Interface."
#define NETWORK_IP_INTERFACE_OBJECT_NAME	"Device.IP.Interface."
#define NETWORK_WANGROUP_OBJECT_NAME	"Device.X_LANTIQ_COM_NwHardware.WANGroup."
#define NETWORK_WANCONNECTION_OBJECT_NAME	"Device.X_LANTIQ_COM_NwHardware.WANConnection."

/*WiFi Related Parameters*/
#define WIFI_BRIDGE_NAME	"X_LANTIQ_COM_Vendor_BridgeName"
#define MAX_SSID_NUM	48 //Maximum number of SSID per 3 radios

/*General Definitions*/
#define DEFAULT_BRIDGE_NAME	"br-lan"
#define DEFAULT_BRIDGE_IP	"192.168.1.1"
#define SUBNETMASK_VALUE	"255.255.255.0"
#define NETWORK_IP4_ADDRESS	"IPv4Address"
#define PROFILE_REF	"ProfileReference"
#define CLIENT_BSSID_NAME	"X_LANTIQ_COM_Vendor_BSSID"
#define NUM_SUPPORTED_AP	2
#define RADIO_2_4	"Device.WiFi.Radio.1."
#define RADIO_5	"Device.WiFi.Radio.2."
#define L2NAT_PROC_DEV_STR	"/proc/l2nat/dev"
#define PPA_BRIDGE_DEV_STR	"/proc/ppa/api/bridged_flow_learning"
#define DEFAULT_IP_ADDR	"0.0.0.0"

static char * mainWlanSSIDRef[] = {
	"Device.WiFi.SSID.1",
	"Device.WiFi.SSID.2",
	NULL,
};

/*Function declaration*/
void sl_client_handler(SERVDEXPORTS, INOUT ServdData *pxSlData);

#endif //#ifndef _SL_CLIENT_H

