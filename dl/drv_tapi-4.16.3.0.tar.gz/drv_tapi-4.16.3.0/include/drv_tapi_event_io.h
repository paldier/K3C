#ifndef DRV_TAPI_EVENT_IO_H
#define DRV_TAPI_EVENT_IO_H

/******************************************************************************

                              Copyright (c) 2014
                            Lantiq Deutschland GmbH

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/


#endif  /* DRV_TAPI_EVENT_IO_H */
