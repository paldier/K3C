/************************************************************************
 *
 * Copyright (c) 2012-2016 Intel Corporation
 * Consumer Electronics Firmware Development Kit (CEFDK) Source Code.
 * Use of this CEFDK Source Code is subject to the terms and conditions
 * of the Intel(R) CEFDK Software License Agreement.
 *
 ************************************************************************/


#include <assert.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <malloc.h>
#include <linux/limits.h>

#include "image.h"
#include "helper.h"
#include "crc.h"
#include "sha256.h"

/* Defines*/
#define DEFAULT_IMAGE_NAME "Intel_Unified_Image"

#define FLAG_CHECK_REQUESTED    (1<<1)
#define FLAG_GENERATE_REQUESTED (1<<2)
#define FLAG_APPEND_REQUESTED   (1<<3)
#define FLAG_STRIP_REQUESTED    (1<<4)
#define FLAG_VERSION_SET        (1<<5)
#define FLAG_EXPAND_REQUESTED   (1<<6)

#define ERROR(fmt, args...)                                      \
do {                                                             \
    printf("ERROR:\n");                                          \
    printf(" - %s():%d:%s", __FUNCTION__, __LINE__, __FILE__);   \
    printf(" - " fmt, ## args);                                  \
} while(0)

#define INFO(fmt, args...)                                       \
do {                                                             \
    printf(" - " fmt, ## args);                                  \
} while(0)

#define DEBUG(fmt, args...)                                      \
do {                                                             \
	if (g_debug) {                                               \
		printf("%s [debug] %14s:%d: " fmt, g_prog_name,          \
			   __FUNCTION__, __LINE__, ## args);                 \
	}                                                            \
} while(0)

struct part_file
{
	char        *name;
	uint8_t      attr;
	uint8_t      type;
	unsigned int size;
	unsigned int crc;
    FILE        *file;
};

/* Structure that respresents all the possible partition types. */
struct all_parts
{
	struct part_file p[MAX_PART_TYPES];
};

/* Local functions */
static void add_part_to_header(struct imageHeader *h, struct part_file *part, int part_index);
static int all_parts_open_files(struct all_parts *parts);
static void all_parts_close_files(struct all_parts *parts);
static int all_parts_compute_size(struct all_parts *parts, unsigned int *ret_size);
static int append_image(char *base_file, char *second_file, char *output_file, uint32_t version);
static int buffer_add_part_and_compute_crc(struct part_file *part, FILE *file, unsigned long int *crc);
static int convert_manifest_type_to_part_type(int manifestType);
static char* convert_bin_to_str(void *void_buffer, int buffer_size);
static int do_headers_types_overlap(char *base_file, char *second_file);
static int expand_image(char *file_name);
static int extract_partition(const char *file_name, int index, uint8_t **ret_buffer, uint32_t *ret_size);
static int compute_SHA256(char *file_name, uchar hash[32]);
static int file_exists(const char *file_name);
static int get_file_size(FILE *f, uint32_t *file_size);
static int get_manifest_type_of_index(char *file_name, int index, uint8_t *type);
static int generate_image(char* image, char* files, char *name, int version);
static char* get_attribute_str(char attr);
static char get_attribute(char* attributeName);
static char getFileType(char* typeName);
static char* get_image_type_str(int type);
static char* get_type_str(uint8_t type);
static int has_orphaned_manifests(struct all_parts *parts, struct all_parts *manifests);
static int image_header_has_manifest_type(char *file_name, struct imageHeader *h, uint8_t manifest_type_to_test);
static int image_header_has_type(struct imageHeader *h, uint8_t type);
static void* load_file(const char *file_name, uint32_t *ret_file_size);
static void* load_file_num_bytes(const char *file_name, uint32_t bytes_to_read);
static int load_image_header(const char *file, struct imageHeader **ret_h);
static int parse_files_parts(char* files, struct all_parts *parts, struct all_parts *os_manifests);
static int parse_parameters(int argc, char *argv[]);
static char* parse_tokenize_and_skip_to_next_token(char *files, const char *token_str);
static void print_header(struct imageHeader *h);
static void print_usage(void);
static void print_version_info(void);
static int strip_image(const char *strip_filename, const char *output_filename);
static int verify_image(char* image, int checkCRC);
static int verify_image_header(struct imageHeader *h);
static int verify_manifests_match_partitions(struct all_parts *parts, struct all_parts *manifests);
static int verify_parameters(void);
static int verify_partition_hash(char *manifest_file, char *partition_file);

/* Global variables*/
int g_debug = 0;            /* Enable debug output*/
char *g_prog_name = NULL;   /* For debug :Store program name */
int  g_version = MAX_VERSION;
char *g_combo_file_str = NULL;
char *g_output_image_filename = NULL;
char *g_internal_name = DEFAULT_IMAGE_NAME;
char *g_append_first_filename = NULL;
char *g_append_second_filename = NULL;
char *g_strip_filename = NULL;
char *g_expand_filename = NULL;
char *g_expand_path = ".";
unsigned int g_flag = 0;
int g_check_CRC = 1;

int main(int argc, char *argv[])
{
	int ret = 0;
	g_prog_name = argv[0];   /* Update the name of this application - for debug print */

	if (parse_parameters(argc, argv))
		goto error;

	if (verify_parameters())
		goto error;

	DEBUG("Starts...\n");
	
	if (g_flag & FLAG_CHECK_REQUESTED) {
		if (verify_image(g_output_image_filename, g_check_CRC))
			goto error;
		goto exit;
	}

	if (g_flag & FLAG_GENERATE_REQUESTED) {
		if (generate_image(g_output_image_filename, g_combo_file_str, g_internal_name, g_version))
			goto error;
		goto exit;
	}

	if (g_flag & FLAG_APPEND_REQUESTED) {
		if (append_image(g_append_first_filename, g_append_second_filename, 
						 g_output_image_filename, g_version)) 
			goto error;
	}

	if (g_flag & FLAG_STRIP_REQUESTED) {
		if (strip_image(g_strip_filename, g_output_image_filename)) 
			goto error;
	}

	if (g_flag & FLAG_EXPAND_REQUESTED) {
		if (expand_image(g_expand_filename))
			goto error;
	}

	goto exit;
error:
	ret = 1;
exit:
    return ret;
}

static int parse_parameters(int argc, char *argv[])
{
	int ret = 0;
	int i;

	for (i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "-f") || !strcmp(argv[i], "--file")) {
			if ((i + 1) >= argc) {
				ERROR("Too few parameters. Please insert files list!\n");
				goto error;
			}
			g_combo_file_str = argv[++i];
			g_flag |= FLAG_GENERATE_REQUESTED;
		} else if (!strcmp(argv[i], "-g") || !strcmp(argv[i], "--generate")) {
			if ((i + 2) >= argc) {
				ERROR("Too few parameters. This requires the file list and the "
					  "output image file name!\n");
				goto error;
			}
			if (g_output_image_filename != NULL) {
				ERROR("The \"--generate\" option cannot be used with \"--image\". "
					  "Please use \"--file\" or remove \"--image\"\n");
				goto error;
			}
			g_combo_file_str = argv[++i];
			g_output_image_filename = argv[++i];
			g_flag |= FLAG_GENERATE_REQUESTED;
		} else if (!strcmp(argv[i], "-i") || !strcmp(argv[i], "--image")) {
			if ((i + 1) >= argc) {
				ERROR("Too few parameters. Please insert output image file name!\n");
				goto error;
			}
			if (g_output_image_filename != NULL) {
				ERROR("The \"--image\" option cannot be used with the "
					  "\"--generate\" option. Please use \"--file\".\n");
				goto error;
			}
			g_output_image_filename = argv[++i];
		} else if (!strcmp(argv[i], "-a") || !strcmp(argv[i], "--append")) {
			if ((i + 2) >= argc) {
				ERROR("Too few parameters. Append requires two images!\n");
				goto error;
			}
			g_append_first_filename = argv[++i];
			g_append_second_filename = argv[++i];
			g_flag |= FLAG_APPEND_REQUESTED;
		} else if (!strcmp(argv[i], "-e") || !strcmp(argv[i], "--expand")) {
			if ((i + 1) >= argc) {
				ERROR("Too few parameters. Expand requires an image!\n");
				goto error;
			}
			g_expand_filename = argv[++i];
			g_flag |= FLAG_EXPAND_REQUESTED;
		} else if (!strcmp(argv[i], "-p") || !strcmp(argv[i], "--path")) {
			if ((i + 1) >= argc) {
				ERROR("Too few parameters. Path requires an images!\n");
				goto error;
			}
			g_expand_path = argv[++i];
		} else if (!strcmp(argv[i], "-c") || !strcmp(argv[i], "--check")) {
			if ((i + 1) >= argc) {
				ERROR("Too few parameters. Please insert input image!\n");
				goto error;
			}
			g_output_image_filename = argv[++i];
			g_flag |= FLAG_CHECK_REQUESTED;
		} else if (!strcmp(argv[i], "-s") || !strcmp(argv[i], "--strip")) {
			if ((i + 1) >= argc) {
				ERROR("Too few parameters. Strip requires the input file and the "
					  "output image file name!\n");
				goto error;
			}
			g_strip_filename = argv[++i];
			g_flag |= FLAG_STRIP_REQUESTED;
		} else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--version")) {
			if ((i + 1) >= argc) {
				ERROR("Too few parameters. Please insert version number!\n");
				goto error;
			}
			g_version = atoi(argv[++i]);
			g_flag |= FLAG_VERSION_SET;
		} else if (!strcmp(argv[i], "-n") || !strcmp(argv[i], "--name")) {
			if ((i + 1) >= argc) {
				ERROR("Too few parameters. Please insert image name!\n");
				goto error;
			}
			g_internal_name = argv[++i];
		} else if (!strcmp(argv[i], "-N") || !strcmp(argv[i], "--noCRC")) {
			g_check_CRC = 0;
		} else if (!strcmp(argv[i], "-d") || !strcmp(argv[i], "--debug")) {
			g_debug = 1;
		} else if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
			goto error;
		} else {
			ERROR("Unrecognized argument. Num:%d Arg:%s\n", i, argv[i]);
			goto error;
		}
	}

	goto exit;
error:
	ret = 1;
	print_usage();
exit:
	return ret;
}

static int verify_parameters(void)
{
	int ret = 0;

	if (!(g_flag & FLAG_CHECK_REQUESTED) && !(g_flag & FLAG_GENERATE_REQUESTED)
     && !(g_flag & FLAG_APPEND_REQUESTED) && !(g_flag & FLAG_STRIP_REQUESTED)
     && !(g_flag & FLAG_EXPAND_REQUESTED)) {
		ERROR("Neither check, generate, append, strip, nor expand requested. Please set the "
			  "appropriate option\n");
        ret = 1;
	}

	if ((g_flag & FLAG_GENERATE_REQUESTED) && (g_output_image_filename == NULL)) {
		ERROR("To generate a uimage, an output image must be specified. \"--image\"\n");
        ret = 1;
	}

	if (g_flag & FLAG_APPEND_REQUESTED) {
		if (g_output_image_filename == NULL) {
			ERROR("To generate a uimage, an output image must be specified. \"--image\"\n");
			ret = 1;
		}

		if (!g_append_first_filename){
			ERROR("Append requested, but no first file set\n");
			ret = 1;
		}

		if (!file_exists(g_append_first_filename)) {
			ERROR("The first append image does not exist. File:%s\n", g_append_first_filename);
			ret = 1;
		}

		if (!g_append_second_filename) {
			ERROR("Append requested, but no second file set\n");
			ret = 1;
		}

		if (!file_exists(g_append_second_filename)) {
			ERROR("The second append image does not exist. File:%s\n", g_append_second_filename);
			ret = 1;
		}
	}


	if (g_flag & FLAG_STRIP_REQUESTED) {
		if (g_output_image_filename == NULL) {
		ERROR("To strip a uimage, an output image must be specified. \"--image\"\n");
		ret = 1;
		}

		if (g_flag & FLAG_VERSION_SET) {
			ERROR("Strip doesn't support the \"--version\" option\n");
			ret = 1;
		}
	}


	if ((g_flag & FLAG_VERSION_SET) && (g_version < MIN_VERSION || g_version > MAX_VERSION)) {
		ERROR("Requesting unsupported version. Ver:%d Min:%d Max:%d\n",
			  g_version, MIN_VERSION, MAX_VERSION);
        ret = 1;
	}

	if (strlen(g_internal_name) > MAX_NAME_LEN) {
		ERROR("The image header name is too long. Len:%ld Max length:%d Str:%s:\n",
			  (long int)strlen(g_internal_name), MAX_NAME_LEN, g_internal_name);
		ret = 1;
	}


    if (ret == 1)
        print_usage();

	return ret;
}

/* Dump and Check Unified Image*/
static int verify_image(char* file_name, int checkCRC)
{
	int ret = 0;
	FILE* f_image = NULL;
	unsigned int fileSize = 0;
	unsigned int dataSize = 0;
	unsigned int headerSize = -1;
	struct imageHeader h, *h_temp;
	char *data_buf = NULL;

	DEBUG("Start image checking\n");

	if (load_image_header(file_name, &h_temp)) {
		goto error;
	}

    /* Open the image to be verfified */
	f_image = fopen(file_name, "rb");
	if (f_image == NULL) {
		ERROR("Verify Image: Failed to open file to verify it. File:'%s' Err:%s\n", 
			  file_name, strerror(errno));
		goto error;
	}

	headerSize = get_h_struct_size(h_temp);

	/* Load the header */
	memset(&h, 0, sizeof(struct imageHeader));
	if (fread(&h, 1, headerSize, f_image) != headerSize) {
		ERROR("Verify Image: Trying to read header from image:'%s'. Err:%s\n", 
			  file_name, strerror(errno));
		goto error;
	}

	if (get_file_size(f_image, &fileSize))
		goto error;

	/* Verify the header size matches the actual file size*/
	if (get_h_image_size(&h) != fileSize) {
		ERROR("Verify Image: Actual file size (%d bytes) doesn't match size in "
			  "the header (%d bytes)\n", fileSize, get_h_image_size(&h));
		ret = 1;
	}

	dataSize = fileSize - headerSize;
	data_buf = calloc(1, dataSize);
	assert(data_buf);

	if (checkCRC) {
		int i;
		uint32_t headerCrc = get_h_hcrc(&h);

		/* Zero CRC, before calculating the CRC because that was how it was originally calculated */
		set_h_hcrc(&h, 0);

		if (headerCrc != crc32(0, (uint8_t*)&h, headerSize)) {
			ERROR("Verify image: Image Header CRC error!\n");
			goto error;
		}

		/* Restore Header CRC (for correct printing) */
		set_h_hcrc(&h, headerCrc);

		/* Read remaining Data to the data buffer for data CRC verfication */
		if (fread(data_buf, 1, dataSize, f_image) != dataSize) {
			ERROR("Verify Image: Failed trying to read data from image:'%s'. Err:%s\n", 
				  file_name, strerror(errno));
			goto error;
		}

		/* Verify the entire data crc */
		if (get_h_dcrc(&h) != crc32(0, (uint8_t*)data_buf, dataSize)) {
			ERROR("Verify Image: Image data CRC error!\n");
			goto error;
		}

		/* Verify the CRC of each of the partitions */
		for (i = 0; i < get_h_part_num(&h); i++) {
			uint8_t *buffer = NULL;
			unsigned long crc;
			uint32_t size;

			if (extract_partition(file_name, i, &buffer, &size)) {
				INFO(" - FAILED to get partition index:%d\n", i);
				ret = 1;
				continue;
			}

			crc = crc32(0, buffer, size);

			if (get_part_crc(&h, i) != crc) {
				INFO(" - Part #%d FAILED crc. Computed:0x%08lX CRC:0x%08X\n", 
					 i, crc, get_part_crc(&h, i));
				ret = 1;
			} else {
				INFO(" - Part #%d passed crc. CRC:0x%08lX\n", i, crc);
			}

			assert(buffer);
			free(buffer);
		}
	} else {
		INFO("Skipping CRC check.\n");
	}

	print_header(&h);

	INFO("Image is OK.\n");
	goto exit;

error:
	ret = 1;
exit:

	if (data_buf)
		free(data_buf);

	if (f_image) {
		if (fclose(f_image)) {
			ERROR("Failed trying to close file. Err:%s\n", strerror(errno));
		}
	}

	return ret;
}

static int verify_image_header(struct imageHeader *h)
{
	int ret = 0;
	uint32_t version, header_magic;

	if (get_h_magic(h) != IMAGE_MAGIC_VER2 && get_h_magic(h) != IMAGE_MAGIC_VER3) {
		ERROR("Verify Image: Bad magic number - Not a unified image file. "
			  "Magic:0x%08X\n", header_magic);
		goto error;
	}

	version = get_h_version(h);
	if (version < MIN_VERSION || version > MAX_VERSION) {
		ERROR("Unable to verify image. Unsupported version:%d Min:%d Max:%d\n",
			  version, MIN_VERSION, MAX_VERSION);
		goto error;
	}

	header_magic = get_headermagic_for_version(version);
    if (get_h_magic(h) != header_magic) {
        ERROR("The header magic version doesn't match the internal version. "
              "Ver:%d\n",version);
        goto error;
    }
	goto exit;

error:
	ret = 1;
exit:
	return ret;
}

/* Generate new Unified Image */
static int generate_image(char* output_file_name, char* files, char *name, int version)
{
	int ret = 0;
	time_t t;
	struct tm *tm;
	struct all_parts parts, os_manifests;
	struct imageHeader h;
	uint32_t header_size;
	uint32_t data_size = 0;
	unsigned long int data_crc = 0;
	FILE* output_image = NULL;
    unsigned int i;
	unsigned int part_count = 0;

	if (version < MIN_VERSION || version > MAX_VERSION) {
		ERROR("The requested version is not supported. Min:%d Max:%d Ver:%d\n", 
			  MIN_VERSION, MAX_VERSION, version);
		goto error;
	}

	header_size = get_headersize_for_version(version);

    /* Clear the header */
	memset(&h, 0, sizeof(struct imageHeader));
    /* Set the version as it is used in later functions */
	set_h_version(&h, version);

	/* Parse the "files" in the command line parameter */
	memset(&parts, 0, sizeof(parts));
	memset(&os_manifests, 0, sizeof(os_manifests));
	if (parse_files_parts(files, &parts, &os_manifests))
        goto error;

    if (has_orphaned_manifests(&parts, &os_manifests))
        goto error;

	if (verify_manifests_match_partitions(&parts, &os_manifests))
		goto error;

	/* Open the output image file */
	output_image = fopen(output_file_name, "wb");
	if (output_image == NULL) {
		ERROR("Generate Image: Failed to create '%s'. Err:%s\n", 
			  output_file_name, strerror(errno));
		goto error;
	}

	/* Write the header to the output file */
    /* This is a dummy write. We will overwrite this later with the actual header. */
	if (fwrite(&h, 1, header_size, output_image) != header_size) {
		ERROR("Generate Image: Failed writing 1st header. Err:%s\n", strerror(errno));
		goto error;
	}

    if (all_parts_open_files(&os_manifests)) goto error;
    if (all_parts_open_files(&parts))        goto error;

    if (all_parts_compute_size(&os_manifests, &data_size)) goto error;
    if (all_parts_compute_size(&parts, &data_size))        goto error;

    /* Interleave the manifests with the binaries */
	for (i = 0; i < MAX_PART_TYPES; i++) {
		struct part_file *part;
		part = &os_manifests.p[i];
        if (buffer_add_part_and_compute_crc(part, output_image, &data_crc)) goto error;
		add_part_to_header(&h, part, part_count);
        if (part->name)
            part_count++;

		part = &parts.p[i];
        if (buffer_add_part_and_compute_crc(part, output_image, &data_crc)) goto error;
		add_part_to_header(&h, part,  part_count);
        if (part->name)
            part_count++;
	}

	/* Finish header */
	set_h_magic(&h, get_headermagic_for_version(version));
	strncpy((char*)h.name, name, MAX_NAME_LEN - 1);

	time(&t);
	tm = gmtime(&t);
	set_h_date(&h, tm->tm_year + 1900, tm->tm_mon, tm->tm_mday);
	set_h_time(&h, tm->tm_hour, tm->tm_min, tm->tm_sec);
	set_h_image_size(&h, header_size + data_size);
	set_h_dcrc(&h, data_crc);
	set_h_part_num(&h, part_count);

	/* Calculate Header CRC  - must be last*/
	set_h_hcrc(&h, crc32(0, (uint8_t*)&h, header_size));

	print_header(&h);

    /* Re-write the now ready header. */
	fseek(output_image, 0, SEEK_SET);
	if (fwrite(&h, 1, header_size, output_image) != header_size) {
		ERROR("Generate Image: Failed writing 2nd header. Err:%s\n", strerror(errno));
		goto error;
	}

	INFO("%s is ready\nDone OK.\n", output_file_name);
	goto exit;

error:
	ret = 1;
exit:
    all_parts_close_files(&parts);
    all_parts_close_files(&os_manifests);

	if (output_image) {
		if (fclose(output_image)) {
			ERROR("Failed trying to close file. Err:%s\n", strerror(errno));
		}
	}

	return ret;
}

static int all_parts_open_files(struct all_parts *parts)
{
    int ret = 0;
    unsigned int i;

	for (i = 0; i < MAX_PART_TYPES; i++) {
        if (!parts->p[i].name)
            continue;

        parts->p[i].file = fopen(parts->p[i].name, "rb");
		if (parts->p[i].file == NULL) {
			ERROR("'%s' can't be opened. Err:%s\n", 
				  parts->p[i].name, strerror(errno));
			goto error;
		}
        
		DEBUG("[%d] Open '%s'\n", i, parts->p[i].name);
	}
    goto exit;

error:
    ret = 1;
exit:
    return ret;
}

static void all_parts_close_files(struct all_parts *parts)
{
    unsigned int i;

	for (i = 0; i < MAX_PART_TYPES; i++) {
        if (!parts->p[i].file)
            continue;
        if(fclose(parts->p[i].file))
            ERROR("Failed closing file. File:%s. Err:%s\n", 
				  parts->p[i].name, strerror(errno));
        parts->p[i].file = NULL;
	}
}

static int all_parts_compute_size(struct all_parts *parts, unsigned int *ret_size)
{
    int ret = 0;
    unsigned int i;
    uint32_t data_size = 0;

	for (i = 0; i < MAX_PART_TYPES; i++) {
        if (!parts->p[i].name)
            continue;

        if (!parts->p[i].file) {
            ERROR("BUG: File is not opened. File:%s\n", parts->p[i].name);
            goto error;
        }
        
		if (get_file_size(parts->p[i].file, &parts->p[i].size))
			goto error;

		DEBUG("[%d] '%s' (length = %d) \n", i, parts->p[i].name, parts->p[i].size);
		data_size += parts->p[i].size;
	}
    goto exit;

error:
    ret = 1;
exit:
    *ret_size += data_size;
    return ret;
}

static int buffer_add_part_and_compute_crc(struct part_file *part, FILE *file, 
										   unsigned long int *ret_crc)
{
    assert(part);
    assert(file);

	int ret = 0;
    uint8_t *buffer = NULL;

    if (!part->name)
        goto exit;

	buffer = malloc(part->size);
	assert(buffer);

    if (fread(buffer, 1, part->size, part->file) != part->size) {
		ERROR("Failed to read from file:%s. Err:%s\n", part->name, strerror(errno));
		goto error;
	}

	if (fwrite(buffer, 1, part->size, file) != part->size) {
		ERROR("Failed writing to output file. Err:%s\n", strerror(errno));
		goto error;
	}

	part->crc = crc32(0, (unsigned char*)buffer, part->size);
	*ret_crc = crc32(*ret_crc, (unsigned char*)buffer, part->size);
	goto exit;

error:
	ret = 1;
exit:
	if (buffer)
		free(buffer);
    return ret;
}

static void add_part_to_header(struct imageHeader *h, struct part_file *part, int part_index)
{
	int version = get_h_version(h);

	if (!part->name)
		goto exit;

	if (part_index >= get_max_partitions_for_version(version)) {
		ERROR("Attempting to add too many partitions to a Version %d image. "
			  "It only supports %d partitions.\n", version, get_max_partitions_for_version(version));
		goto exit;
	}

	set_part_size(h, part_index, part->size);
	set_part_crc(h, part_index, part->crc);
	set_part_type(h, part_index, part->type);
	set_part_attr(h, part_index, part->attr);

	if (part->type == PART_TYPE_OS_MANIFEST) {
		/* Load the file in order to print the manifest type */
		manifest_output_t *manifest = load_file(part->name, NULL);
		INFO("Adding part to %d. name:%s ManifestType:%d\n", part_index, part->name, 
			 manifest->s.osManifestType);
		free(manifest);
	}
	else {
		INFO("Adding part to %d. name:%s Type:%d\n", part_index, part->name, part->type);
	}

exit:
	return;
}

static int append_image(char *base_file, char *second_file, char *output_file, uint32_t version)
{
	assert(base_file);
	assert(second_file);
	assert(output_file);

	int ret = 0;
	FILE *f = NULL;
	uint8_t *tmp = NULL;
	int i;
	time_t t;
	struct tm *tm;
	unsigned long data_crc = 0;
	uint8_t *imageBuffer1, *imageBuffer2;
	struct imageHeader h_output;
	struct imageHeader *h1, *h2;
	uint32_t size1, size2, tmp_size;
	uint32_t headerSize1, headerSize2;
	uint32_t data_size = 0;

	imageBuffer1 = imageBuffer2 = NULL;
	h1 = h2 = NULL;

	if (do_headers_types_overlap(base_file, second_file))
		goto error;

	if (load_image_header(base_file, &h1))
		goto error;

	if (load_image_header(second_file, &h2))
		goto error;

	memset(&h_output, 0, sizeof(struct imageHeader));
	set_h_version(&h_output, version);

	headerSize1 = get_h_struct_size(h1);
	headerSize2 = get_h_struct_size(h2);

	if (get_h_part_num(h1) + get_h_part_num(h2) > get_max_partitions_for_version(version)) {
		ERROR("The combined images would be greater than the allowed maximum for this version."
			  "Image1:%d + Image2:%d > Maximum:%d\n", 
			  get_h_part_num(h1), get_h_part_num(h2), get_max_partitions_for_version(version));
		goto error;
	}

	// Append partition header info of image1 to output.
	for (i = 0; i < get_h_part_num(h1); i++) {
		int part_num = get_h_part_num(&h_output);
		set_part_crc(&h_output, part_num, get_part_crc(h1, i));
		set_part_size(&h_output, part_num, get_part_size(h1, i));
		set_part_type(&h_output, part_num, get_part_type(h1, i));
		set_part_attr(&h_output, part_num, get_part_attr(h1, i));
		set_h_part_num(&h_output, part_num+1);
		data_size += get_part_size(h1, i);
	}
	for (i = 0; i < get_h_part_num(h2); i++) {
		int part_num = get_h_part_num(&h_output);
		set_part_crc(&h_output, part_num, get_part_crc(h2, i));
		set_part_size(&h_output, part_num, get_part_size(h2, i));
		set_part_type(&h_output, part_num, get_part_type(h2, i));
		set_part_attr(&h_output, part_num, get_part_attr(h2, i));
		set_h_part_num(&h_output, part_num+1);
		data_size += get_part_size(h2, i);
	}

	imageBuffer1 = load_file(base_file, &size1);
	imageBuffer2 = load_file(second_file, &size2);

	if (!imageBuffer1 || size1 == 0) goto error;
	if (!imageBuffer2 || size2 == 0) goto error;

	f = fopen(output_file, "wb");
	if (f == NULL) {
		ERROR("Failed to open output file to write. File:'%s' Err:%s\n", 
			  output_file, strerror(errno));
		goto error;
	}

	// Write the dummy header that will be overwritten later.
	tmp = (uint8_t*)&h_output;
	tmp_size = get_h_struct_size(&h_output);
	if (fwrite(tmp, 1, tmp_size, f) != tmp_size) {
		ERROR("Failed writing appended file. File:%s Err:%s\n", output_file, 
			  strerror(errno));
		goto error;
	}

	// Write image1's data block to the output image.
	tmp = imageBuffer1 + headerSize1;
	tmp_size = size1 - headerSize1;
	data_crc = crc32(data_crc, tmp, tmp_size);
	if (fwrite(tmp, 1, tmp_size, f) != tmp_size) {
		ERROR("Failed writing appended file. File:%s Err:%s\n", output_file, 
			  strerror(errno));
		goto error;
	}

	// Write image2's data block to the output image.
	tmp = imageBuffer2 + headerSize2;
	tmp_size = size2 - headerSize2;
	data_crc = crc32(data_crc, tmp, tmp_size);
	if (fwrite(tmp, 1, tmp_size, f) != tmp_size) {
		ERROR("Failed writing appended file. File:%s Err:%s\n", output_file, 
			  strerror(errno));
		goto error;
	}

	// Set the header
	set_h_magic(&h_output, get_headermagic_for_version(version));
	time(&t);
	tm = gmtime(&t);
	set_h_date(&h_output, tm->tm_year + 1900, tm->tm_mon, tm->tm_mday);
	set_h_time(&h_output, tm->tm_hour, tm->tm_min, tm->tm_sec);
	if (g_internal_name)
		strcpy((char*)h_output.name, g_internal_name);
	else
		strcpy((char*)h_output.name, DEFAULT_IMAGE_NAME);
	set_h_image_size(&h_output, data_size + get_h_struct_size(&h_output));
	set_h_dcrc(&h_output, data_crc);
	set_h_hcrc(&h_output, 0);
	set_h_hcrc(&h_output, crc32(0, (uint8_t*)&h_output, get_h_struct_size(&h_output)));

	// Re-write the header with the now correct header.
	if (fseek(f, 0, SEEK_SET)) {
        ERROR("Failed trying to reset the file pointer to start to write the "
			  "header. Err:%s\n", strerror(errno));
		goto error;
    }

	tmp = (uint8_t*)&h_output;
	tmp_size = get_h_struct_size(&h_output);
	if (fwrite(tmp, 1, tmp_size, f) != tmp_size) {
		ERROR("Failed writing appended file. File:%s Err:%s\n", output_file, 
			  strerror(errno));
		goto error;
	}

	print_header(h1);
	INFO("Append was successful\n");

	goto exit;
error:
	ret = 1;
exit:
	if (f && fclose(f))
		ERROR("Failed trying to close file. Err:%s\n", strerror(errno));
	if (imageBuffer1)
		free(imageBuffer1);
	if (imageBuffer2)
		free(imageBuffer2);
	if (h1)
		free(h1);
	if (h2)
		free(h2);
	return ret;
}

// Look at the two images and determine if the headers hold the same types.
// If they do, they can't be joined. Return an error.
static int do_headers_types_overlap(char *base_file, char *second_file)
{
	int ret = 0;
	int i;
	struct imageHeader *h1 = NULL;
	struct imageHeader *h2 = NULL;

	if (load_image_header(base_file, &h1))
		goto error;

	if (load_image_header(second_file, &h2))
		goto error;


	// Loop through all the partition types in the second file to see if any
	// match the first image partitions.
	for (i = 0; i < get_h_part_num(h2); i++) {

		uint8_t type2 = get_part_type(h2, i);

		if (type2 == PART_TYPE_OS_MANIFEST) {

			uint8_t manifest_type2;

			if (get_manifest_type_of_index(second_file, i, &manifest_type2)) {
				ERROR("Failed trying to get manifest type\n");
				goto error;
			}

			if (image_header_has_manifest_type(base_file, h1, manifest_type2)) {
				ERROR("Headers share the same OS manifest. Type:%d\n", type2);
				goto error;
			}
		}
		else {
			if (image_header_has_type(h1, type2)) {
				ERROR("Headers share the same type. Type:%d\n", type2);
				goto error;
			}
		}
	}

	goto exit;

error:
	ret = 1;
exit:
	if (h1)
		free(h1);
	if (h2)
		free(h2);

	return ret;
}

static int load_image_header(const char *file, struct imageHeader **ret_h)
{
	assert(ret_h);

	int ret = 0;
	struct imageHeader *h = NULL;

	h = load_file_num_bytes(file, UIMAGE_HEADER_SIZE_MAX);
	if (!h)
		goto error;

	if (verify_image_header(h))
		goto error;

	*ret_h = h;

	goto exit;

error:
	ret = 1;
	if (h)
		free(h);
exit:
	return ret;
}

static int get_manifest_type_of_index(char *file_name, int index, uint8_t *type)
{
	assert(file_name);
	assert(type);

	int ret = 0;
	manifest_output_t *manifest = NULL;

	if (extract_partition(file_name, index, (uint8_t**)&manifest, NULL))
		goto error;

    if ((strncmp(manifest->s.manifestIdentifier, 
				MANIFEST_IDENTIFIER_V1, MANIFEST_IDENTIFIER_LEN) != 0)
     && (strncmp(manifest->s.manifestIdentifier,
				MANIFEST_IDENTIFIER_V2, MANIFEST_IDENTIFIER_LEN) != 0)) {
		ERROR("The manifest header is not valid.\n");
		goto error;
	}

	*type = manifest->s.osManifestType;
	goto exit;

error:
	ret = 1;
exit:
	if (manifest)
		free(manifest);
	return ret;
}

// Extracts a partition from an image. It then returns the bytes in the partition.
// NOTE: The returned buffer must be free'd.
static int extract_partition(const char *file_name, int index, uint8_t **ret_buffer, 
							 uint32_t *ret_size)
{
	assert(ret_buffer);

	int ret = 0;
	int i;
	struct imageHeader *h = NULL;
	uint8_t *buffer = NULL;
	int bytes_to_read;
	long position = 0;
	FILE *f = NULL;

	if (load_image_header(file_name, &h))
		goto error;

	if (index >= get_h_part_num(h)) {
		ERROR("The requested index to extract is larger than the number of "
			  "partitions. Requested:%d Total:%d\n", index, get_h_part_num(h));
		goto error;
	}

	// Calculate the location of the requested partition
	// Jump past the header.
	position += get_h_struct_size(h);

	// Add the sizes of all the partitions in front of the desired partition.
	for (i = 0; i < index; i++) {
		position += get_part_size(h, i);
	}

	f = fopen(file_name, "rb");
	if (!f) {
		ERROR("Failed open file to extract partition. File:%s\n", file_name);
		goto error;
	}

	if (fseek(f, position, SEEK_SET)) {
		ERROR("Failed setting location to read in the uimage to extract "
			  "parition. Pos:%ld\n", position);
		goto error;
	}

	bytes_to_read = get_part_size(h, index);
	buffer = malloc(bytes_to_read);
	assert(buffer);

	if (fread(buffer, 1, bytes_to_read, f) != bytes_to_read) {
		ERROR("Failed reading file:'%s'. Err:%s\n", file_name, strerror(errno));
		goto error;
	}

	if (ret_size)
		*ret_size = bytes_to_read;

	goto exit;

error:
	ret = 1;
	if (buffer)
		free(buffer);
	buffer = NULL;
exit:
	if (f && fclose(f))
		ERROR("Failed trying to close file. Err:%s\n", strerror(errno));
	if (h)
		free(h);
	*ret_buffer = buffer;
	return ret;
}

static int image_header_has_type(struct imageHeader *h, uint8_t type)
{
	unsigned int i;
	int ret = 0;

	for (i = 0; i < get_h_part_num(h); i++) {
		
   		 if (get_part_type(h, i) == type) {
			ERROR("Overlapping types. Index:%d Type:%d\n", i, type);
			ret = 1;
			break;
		}
	}

	return ret;
}

static int image_header_has_manifest_type(char *file_name, struct imageHeader *h, 
										  uint8_t manifest_type_to_test)
{
	int ret = 0;
	int i;

	// Loop through all of the partition in the image header looking for the
	// manifest type.
	for (i = 0; i < get_h_part_num(h); i++) {

		if (get_part_type(h, i) == PART_TYPE_OS_MANIFEST) {

			uint8_t manifest_type;

			if (get_manifest_type_of_index(file_name, i, &manifest_type)) {
				ERROR("Failed trying to get the manifest type to verify.\n");
				goto error;
			}

			if (manifest_type == manifest_type_to_test) {
				ERROR("First image already has a manifest of type:%d\n", manifest_type);
				goto error;
			}
		}
	}

	goto exit;
error:
	ret = 1;
exit:
	return ret;
}

/* Print Unified Image header*/
static void print_header(struct imageHeader *h)
{
	unsigned int i;
	uint32_t year, month, day, hour, minute, second;
	int version = get_h_version(h);

	get_h_date(h, &year, &month, &day);
	get_h_time(h, &hour, &minute, &second);

	INFO("Unified Image:\n");
	INFO("  Image: %s, size: %d\n", h->name, get_h_image_size(h));
	INFO("  Version:%d \n", get_h_version(h));
	INFO("  Build time: %d/%d/%d, %d:%d:%d UTC\n", year, month, day, hour, minute, second);
	INFO("  Header CRC: 0x%.8X\n", get_h_hcrc(h));
	INFO("  Data CRC:   0x%.8X\n", get_h_dcrc(h));
	INFO("  Number of parts: %d\n", get_h_part_num(h));
	if (version < MIN_VERSION || version > MAX_VERSION) {
		ERROR("This version is not supported. Ver:%d\n", version);
		exit(1);
	} else {
		for (i = 0; i < get_h_part_num(h); i++) {
			uint8_t type  = get_part_type(h, i);
			uint32_t size = get_part_size(h, i);
			uint32_t crc  = get_part_crc(h, i);
			uint8_t attr  = get_part_attr(h, i);

            if (type == PART_TYPE_CEFDK_BIN)
                INFO("   part[%d] Type:%-17s size:%7d bytes Crc=0x%08X "
                     "attributes:0x%08X (%s)\n", i, get_image_type_str(type),
                     size, crc, attr, get_attribute_str(attr));
            else
                INFO("   part[%d] Type:%-17s size:%7d bytes Crc=0x%08X "
                     "attributes:0x%08X\n", i, get_image_type_str(type),
                     size, crc, attr);
		}
	}
}

/* Get image type number from image type string  */
static char getFileType(char* typeName)
{
	if (typeName == NULL)                       return PART_TYPE_NOT_SET;
	if (strcmp(typeName, "appcpu") == 0)        return PART_TYPE_APPCPU_UIMG;
	if (strcmp(typeName, "appcpu_kernel") == 0) return PART_TYPE_APPCPU_KERNEL_BIN;
	if (strcmp(typeName, "appcpu_rootfs") == 0) return PART_TYPE_APPCPU_ROOTFS_BIN;
	if (strcmp(typeName, "npcpu") == 0)         return PART_TYPE_NPCPU_UBFI;
	if (strcmp(typeName, "cefdk") == 0)         return PART_TYPE_CEFDK_BIN;
	if (strcmp(typeName, "uboot") == 0)         return PART_TYPE_UBOOT_BIN;
	if (strcmp(typeName, "cefdk_uimg") == 0)    return PART_TYPE_CEFDK_UIMG;
	if (strcmp(typeName, "npcpu_kernel") == 0)  return PART_TYPE_NPCPU_KERNEL_BIN;
	if (strcmp(typeName, "npcpu_rootfs") == 0)  return PART_TYPE_NPCPU_ROOTFS_BIN;
    if (strcmp(typeName, "gwfs") == 0)          return PART_TYPE_GWFS_BIN;
    if (strcmp(typeName, "ibb1") == 0)          return PART_TYPE_UEFI_IBB1;
    if (strcmp(typeName, "ibb2") == 0)          return PART_TYPE_UEFI_IBB2;
    if (strcmp(typeName, "cse_bup_fs") == 0)    return PART_TYPE_CSE_BUP_FW;
    if (strcmp(typeName, "bbuc_bl") == 0)       return PART_TYPE_BBUC_BL;
    if (strcmp(typeName, "bbuc_conf") == 0)     return PART_TYPE_BBUC_CONF;
    if (strcmp(typeName, "bbuc_fw") == 0)       return PART_TYPE_BBUC_FW;
    if (strcmp(typeName, "mcu") == 0)           return PART_TYPE_MCU;
	if (strcmp(typeName, "uefi_bundle") == 0)   return PART_TYPE_UEFI_BUNDLE;
	if (strcmp(typeName, "rawspi") == 0)        return PART_TYPE_RAW_SPI;
	if (strcmp(typeName, "os_manifest") == 0)   return PART_TYPE_OS_MANIFEST;

	/* Not found */
	ERROR("Undefined image type: '%s'\n", typeName);
	exit(1);
}

/* Get image type number from image type string  */
static char* get_type_str(uint8_t type)
{
    if (type == PART_TYPE_APPCPU_UIMG)       return "appcpu";
    if (type == PART_TYPE_APPCPU_KERNEL_BIN) return "appcpu_kernel";
    if (type == PART_TYPE_APPCPU_ROOTFS_BIN) return "appcpu_rootfs";
    if (type == PART_TYPE_NPCPU_UBFI)        return "npcpu";
    if (type == PART_TYPE_CEFDK_BIN)         return "cefdk";
    if (type == PART_TYPE_UBOOT_BIN)         return "uboot";
    if (type == PART_TYPE_CEFDK_UIMG)        return "cefdk_uimg";
    if (type == PART_TYPE_NPCPU_KERNEL_BIN)  return "npcpu_kernel";
    if (type == PART_TYPE_NPCPU_ROOTFS_BIN)  return "npcpu_rootfs";
    if (type == PART_TYPE_GWFS_BIN)          return "gwfs";
    if (type == PART_TYPE_UEFI_IBB1)         return "ibb1";
    if (type == PART_TYPE_UEFI_IBB2)         return "ibb2";
    if (type == PART_TYPE_CSE_BUP_FW)        return "cse_bup_fs";
    if (type == PART_TYPE_BBUC_BL)           return "bbuc_bl";
    if (type == PART_TYPE_BBUC_CONF)         return "bbuc_conf";
    if (type == PART_TYPE_BBUC_FW)           return "bbuc_fw";
    if (type == PART_TYPE_MCU)               return "mcu";
    if (type == PART_TYPE_UEFI_BUNDLE)       return "uefi_bundle";
    if (type == PART_TYPE_RAW_SPI)           return "rawspi";
    if (type == PART_TYPE_OS_MANIFEST)       return "os_manifest";

    return "Unknown";
}

/* Get Image Type Message from uImage type */
static char* get_image_type_str(int type)
{
	switch (type)
	{
	case PART_TYPE_APPCPU_UIMG:       return "APP-CPU";
	case PART_TYPE_APPCPU_KERNEL_BIN: return "APP-CPU (kernel)";
	case PART_TYPE_APPCPU_ROOTFS_BIN: return "APP-CPU (root-fs)";
	case PART_TYPE_NPCPU_UBFI:        return "NP-CPU (UBFI)";
	case PART_TYPE_CEFDK_BIN:         return "CEFDK (binary)";
	case PART_TYPE_UBOOT_BIN:         return "U-BOOT";
	case PART_TYPE_CEFDK_UIMG:        return "CEFDK (uImage)";
	case PART_TYPE_NPCPU_KERNEL_BIN:  return "NP-CPU (Kernel)";
	case PART_TYPE_NPCPU_ROOTFS_BIN:  return "NP-CPU (root-fs)";
	case PART_TYPE_GWFS_BIN:          return "GWFS";
	case PART_TYPE_UEFI_IBB1:         return "IBB1";
	case PART_TYPE_UEFI_IBB2:         return "IBB2";
	case PART_TYPE_CSE_BUP_FW:        return "CSE BPU FW";
	case PART_TYPE_BBUC_BL:           return "BBU BL";
	case PART_TYPE_BBUC_CONF:         return "BBUC CONF";
	case PART_TYPE_BBUC_FW:           return "BBUC FW";
	case PART_TYPE_MCU:               return "MCU";
	case PART_TYPE_RAW_SPI:           return "RAW SPI";
	case PART_TYPE_UEFI_BUNDLE:       return "UEFI BUNDLE (ibb1, ibb2 & mcu combined)";
	case PART_TYPE_OS_MANIFEST:       return "OS Manifest";
	case PART_TYPE_NOT_SET:           return "Not Set";
	}

	return "UnknownImageType";
}

static int convert_manifest_type_to_part_type(int manifestType)
{
    int ret = -1;
    switch(manifestType)
    {
    case MANIFEST_TYPE_APP_CPU_KERNEL:            ret = PART_TYPE_APPCPU_KERNEL_BIN; break;
    case MANIFEST_TYPE_APP_CPU_ROOT_FILESYSTEM:   ret = PART_TYPE_APPCPU_ROOTFS_BIN; break;
    case MANIFEST_TYPE_NP_CPU_KERNEL:             ret = PART_TYPE_NPCPU_KERNEL_BIN; break;
    case MANIFEST_TYPE_NP_CPU_ROOT_FILESYSTEM:    ret = PART_TYPE_NPCPU_ROOTFS_BIN; break;
    case MANIFEST_TYPE_NP_CPU_GATEWAY_FILESYSTEM: ret = PART_TYPE_GWFS_BIN; break;

    case MANIFEST_TYPE_APP_CPU_VIDEO_GATEWAY_FILESYSTEM:
    case MANIFEST_TYPE_MEDIA_CPU_KERNEL:
    case MANIFEST_TYPE_MEDIA_CPU_ROOT_FILESYSTEM:
    case MANIFEST_TYPE_BIOS_STAGE_1:
    case MANIFEST_TYPE_BBU_CONTROLLER_FIRMWARE:
    case MANIFEST_TYPE_BBU_CONTROLLER_CONFIGURATION:
    case MANIFEST_TYPE_RESERVED_9:
    case MANIFEST_TYPE_RESERVED_12:
    case MANIFEST_TYPE_RESERVED_13:
    case MANIFEST_TYPE_RESERVED_14:
    case MANIFEST_TYPE_RESERVED_15:
    default: 
        ret = PART_TYPE_NOT_SET;
        ERROR("WARNING: The manifestType is not supported:%d\n", manifestType);
    }
    return ret;
}

/* Get Image Attribute Mask from string */
static char get_attribute(char* attributeName)
{
	if (attributeName == NULL) /* For CEFDK, default 'zero' mean 'allow for failsafe'*/
		return 0;

	if (strcmp(attributeName, "allow_failsafe_cefdk") == 0)
		return 0 << PART_ATTR_DISABLE_FAILSAFE_CEFDK_UPGRADE_BIT;

	if (strcmp(attributeName, "allow_non_failsafe_cefdk") == 0)
		return (0x1 << PART_ATTR_DISABLE_FAILSAFE_CEFDK_UPGRADE_BIT) 
             | (0x1 << PART_ATTR_ALLOW_NON_FAILSAFE_CEFDK_UPGRADE_BIT);

	if (strcmp(attributeName, "allow_both_cefdk") == 0)
		return 0x1 << PART_ATTR_ALLOW_NON_FAILSAFE_CEFDK_UPGRADE_BIT;

	/* Not found */
	ERROR("Undefined image attribute: '%s'\n", attributeName);
	exit(1);
}

/* Get Attribute string for CEFDK only */
static char* get_attribute_str(char attr)
{
	int disable_fail_safe = 0;
	int allow_non_fail_safe = 0;

	if (attr & (1 << PART_ATTR_DISABLE_FAILSAFE_CEFDK_UPGRADE_BIT)) {
		/* disable fail safe is set */
		disable_fail_safe = 1;
	}

	if (attr & (1 << PART_ATTR_ALLOW_NON_FAILSAFE_CEFDK_UPGRADE_BIT)) {
		/* Allow non-failsafe is set */
		allow_non_fail_safe = 1;
	}

	if (disable_fail_safe) {
        if (allow_non_fail_safe)
            return "Non FailSafe only";
        else
            return "Neither FailSafe nor Non FailSafe";
    } else {
        if (allow_non_fail_safe)
            return "Both FailSafe and Non FailSafe";
        else
            return "FailSafe only";
    }

	return NULL;
}

static int get_file_size(FILE *f, uint32_t *file_size)
{
	int ret = 0;
	long currentPosition, size = 0;

	if (!f) {
		ERROR("Passed in file is NULL\n");
		goto error;
	}

	currentPosition = ftell(f);
	if (currentPosition == -1) {
        ERROR("Failed trying to get the file pointer. Err:%s\n",
              strerror(errno));
		goto error;
	}

	if (fseek(f, 0L, SEEK_END)) {
        ERROR("Failed trying to set the file pointer to the end of the file. Err:%s\n",
              strerror(errno));
		goto error;
    }

	size = ftell(f);
	if (size == -1) {
        ERROR("Failed trying to get the file size. Err:%s\n",
              strerror(errno));
		goto error;
	}

	if (fseek(f, currentPosition, SEEK_SET)) {
        ERROR("Failed trying to reset the file pointer to the previous position. Err:%s\n",
              strerror(errno));
		goto error;
    }
	goto exit;

error:
	ret = 1;
exit:
	*file_size = size;
	return ret;
}

static int get_manifest_type(const char *file, uint8_t *type)
{
	int ret = 0;
	manifest_output_t *manifest;
	uint32_t file_size;

	manifest = load_file(file, &file_size);
	if (!manifest)
		goto error;

	if (file_size != sizeof(manifest_output_t)) {
		ERROR("The manifest file is not the expected output size. "
			  "Expected:%lu Actual:%u\n", (long int)sizeof(manifest_output_t), file_size);
		goto error;
	}

    if ((strncmp(manifest->s.manifestIdentifier, 
				MANIFEST_IDENTIFIER_V1, MANIFEST_IDENTIFIER_LEN) != 0)
     && (strncmp(manifest->s.manifestIdentifier,
				MANIFEST_IDENTIFIER_V2, MANIFEST_IDENTIFIER_LEN) != 0)) {
        ERROR("File is not manifest file. File:%s\n", file);
		goto error;
    }

	if (type)
		*type = manifest->s.osManifestType;
	goto exit;

error:
	ret = 1;
exit:
	if (manifest)
		free(manifest);
	return ret;
}

/* Parse the files from the command line */
static int parse_files_parts(char* files, struct all_parts *parts, struct all_parts *os_manifests)
{
    int ret = 0;

	if (NULL == files) {
        ERROR("No files requested to add to the final uimage.\n");
        goto error;
    }

	do {
		char *file, *type = NULL, *attr = NULL;
		file = files;
		files = parse_tokenize_and_skip_to_next_token(files, ":");
		type = parse_tokenize_and_skip_to_next_token(file, ",");
        attr = parse_tokenize_and_skip_to_next_token(type, ",");

		if (!file_exists(file)) {
			ERROR("The specified input file doesn't exist. File:%s Type:%s\n", file, type);
			goto error;
		}

		uint8_t file_type = getFileType(type);

		if (file_type == PART_TYPE_OS_MANIFEST) {
			uint8_t manifest_type = 0, part_type;

			if (get_manifest_type(file, &manifest_type))
				goto error;

            part_type = convert_manifest_type_to_part_type(manifest_type);
            if (os_manifests->p[part_type].name) {
                ERROR("Found a duplicate manifest type. Orig:%s Duplicate:%s\n",
                      os_manifests->p[part_type].name, file);
                goto error;
            }
			os_manifests->p[part_type].name = file;
			os_manifests->p[part_type].type = file_type;
			os_manifests->p[part_type].attr = attr ? get_attribute(attr) : 0;
		} else {
            if (parts->p[file_type].name) {
                ERROR("Found a duplicate partition file. Orig:%s Duplicate:%s\n",
                      parts->p[file_type].name, file);
                goto error;
            }
			parts->p[file_type].name = file;
			parts->p[file_type].type = file_type;
			parts->p[file_type].attr = attr ? get_attribute(attr) : 0;
		}
	}
	while (files != NULL); 
    goto exit;

error:
    ret = 1;
exit:
    return ret;
}

static char* parse_tokenize_and_skip_to_next_token(char *files, const char *token_str)
{
	assert(files != NULL);

	char *next_file = strstr(files, token_str);

	if (next_file) {
		*next_file = 0;
		next_file++;
	}

	return next_file;
}

static int has_orphaned_manifests(struct all_parts *parts, struct all_parts *manifests)
{
    int ret = 0;
    unsigned int i;

	for (i = 0; i < MAX_PART_TYPES; i++) {
        if (manifests->p[i].name && !parts->p[i].name) {
            ERROR("Found an orphaned manifest that doesn't match with a binary "
                  "partition file. Manifest:%s\n", manifests->p[i].name);
            goto error;
        }

	}
    goto exit;

error:
    ret = 1;
exit:
    return ret;
}

static int verify_manifests_match_partitions(struct all_parts *parts, 
											 struct all_parts *manifests)
{
    int ret = 0;
    unsigned int i;

	for (i = 0; i < MAX_PART_TYPES; i++)
	{
        if (manifests->p[i].name && parts->p[i].name)
			ret |= verify_partition_hash(manifests->p[i].name, parts->p[i].name);

	}
    goto exit;

exit:
    return ret;
}

static int verify_partition_hash(char *manifest_file, char *partition_file)
{
	int ret = 0;
	manifest_output_t *manifest = NULL;
	uint32_t hash_len = SHA256_BLOCK_SIZE;
	uchar part_hash[hash_len];

	// Ensure that the SHA256 size matches the manifest hash size
	assert(SHA256_BLOCK_SIZE == struct_member_size(os_signed_t, osImageHash));

	compute_SHA256(partition_file, part_hash);

	manifest = load_file(manifest_file, NULL);
	if (!manifest)
		goto error;

	if (memcmp(part_hash, manifest->s.osImageHash, hash_len) != 0) {
		char *part_hash_str = convert_bin_to_str(part_hash, hash_len);
		char *man_hash_str = convert_bin_to_str(manifest->s.osImageHash, hash_len);
		ERROR("The partition hash doesn't match the OS manifest's hash.\n"
			  "  - Part:%s\n"
			  "      Hash:%s\n"
			  "  - Manifest:%s\n"
			  "      Hash:%s\n", 
			  partition_file, part_hash_str, manifest_file, man_hash_str);
		free(part_hash_str);
		free(man_hash_str);
        // TODO: The issue is that the os_manifest_tool is run against the 
        // bzImage and the mkuImage adds the bzImage partition. When mkuImage 
        // verifies the hashs, they don't match. Allowing this to be a warning 
        // for now and architect a long term solution.
		//goto error;
	}

	goto exit;
error:
	ret = 1;
exit:
	if (manifest)
		free(manifest);
	return ret;
}

static int compute_SHA256(char *file_name, uchar hash[32])
{
	int ret = 0;
	uint32_t file_size;
	uchar *buffer = NULL;
	SHA256_CTX ctx;

	buffer = load_file(file_name, &file_size);
	if (!buffer)
		goto error;

	sha256_init(&ctx);
	sha256_update(&ctx, buffer, file_size);
	sha256_final(&ctx, hash);

	goto exit;
error:
	ret = 1;
exit:
	if (buffer)
		free(buffer);
	return ret;
}

static int file_exists(const char *file_name)
{
	int ret = 1;
	FILE *f_image = NULL;

	f_image = fopen(file_name, "rb");
	if (f_image == NULL) {
		goto error;
	}

	goto exit;

error:
	ret = 0;
exit:
	if (f_image)
		fclose(f_image);

	return ret;
}

static void* load_file(const char *file_name, uint32_t *ret_file_size)
{
	uint32_t file_size = 0;
	FILE *f_image = NULL;
	uchar *buffer = NULL;

	f_image = fopen(file_name, "rb");
	if (f_image == NULL) {
		ERROR("Failed to open file to load it. File:'%s' Err:%s\n", 
			  file_name, strerror(errno));
		goto error;
	}

	if (get_file_size(f_image, &file_size))
		goto error;

	buffer = malloc(file_size);
	assert(buffer);

	if (fread(buffer, 1, file_size, f_image) != file_size) {
		ERROR("Failed reading file:'%s'. Err:%s\n", 
			  file_name, strerror(errno));
		goto error;
	}

	goto exit;
error:
	if (buffer)
		free(buffer);
	buffer = NULL;
exit:
	if (f_image)
		fclose(f_image);
	if (ret_file_size)
		*ret_file_size = file_size;
	return buffer;
}

static void* load_file_num_bytes(const char *file_name, uint32_t bytes_to_read)
{
	uint32_t file_size;
	FILE *f_image = NULL;
	uchar *buffer = NULL;

	f_image = fopen(file_name, "rb");

	if (f_image == NULL) {
		ERROR("Failed to open file to load it. File:'%s' Err:%s\n", 
			  file_name, strerror(errno));
		goto error;
	}

	if (get_file_size(f_image, &file_size))
		goto error;

	if (file_size < bytes_to_read) {
		ERROR("Not enough bytes in the file to read. Desired:%d Actual:%d File:%s\n",
			  bytes_to_read, file_size, file_name);
		goto error;
	}

	buffer = malloc(bytes_to_read);
	assert(buffer);

	if (fread(buffer, 1, bytes_to_read, f_image) != bytes_to_read) {
		ERROR("Failed reading file:'%s'. Err:%s\n", file_name, strerror(errno));
		goto error;
	}

	goto exit;

error:
	if (buffer)
		free(buffer);
	buffer = NULL;
exit:
	if (f_image)
		fclose(f_image);
	return buffer;
}

// Note: The return string must be freed.
static char* convert_bin_to_str(void *void_buffer, int buffer_size)
{
    int i;

    // Convert each byte to two characters. Add one for the NULL terminator.
    char *str = malloc(buffer_size*2+1);
    assert(str);
    uchar *buffer = void_buffer;
    str[buffer_size] = 0;

    for (i = 0; i < buffer_size; i++) {
        sprintf(&str[i*2], "%02X", buffer[i]);
    }

    return str;
}

static int strip_image(const char *strip_filename, const char *output_filename)
{
	assert(g_strip_filename);
	assert(g_output_image_filename);

	int ret = 0;
	struct imageHeader *h_input;
	struct imageHeader h_output;
	uint32_t header_size = 0;
	FILE *f_output = NULL;
	uint8_t *partition_buffer = NULL;
	unsigned long int data_crc = 0;
	int i, part_index;

	f_output = fopen(output_filename, "wb");
	if (f_output == NULL) {
		ERROR("Strip: Failed to open output file to write the stripped image. "
			  "File:'%s' Err:%s\n", output_filename, strerror(errno));
		goto error;
	}

	if (load_image_header(strip_filename, &h_input))
		goto error;

	/* Clear the output header*/
	memset(&h_output, 0, UIMAGE_HEADER_SIZE_MAX);

	set_h_version(&h_output, get_h_version(h_input));
	set_h_magic(&h_output, get_headermagic_for_version(get_h_version(&h_output)));
	set_h_image_size(&h_output, get_headersize_for_version(get_h_version(&h_output)));

	/* Write the dummy header */
	header_size = get_h_struct_size(h_input);
	if (fwrite(&h_output, 1, header_size, f_output) != header_size) {
		ERROR("Strip: Failed writing 1st header. Err:%s\n", strerror(errno));
		goto error;
	}

	part_index = 0;
	for (i = 0; i < get_h_part_num(h_input); i++) {

		uint8_t type = get_part_type(h_input, i);

		if (type != PART_TYPE_OS_MANIFEST) {

			struct part_file part = {"", 0, 0, 0, 0, NULL};

			part.crc  = get_part_crc(h_input, i);
			part.size = get_part_size(h_input, i);
			part.type = get_part_type(h_input, i);
			part.attr = get_part_attr(h_input, i);
            
			INFO("Writing partition:%d Size:%d\n", i, part.size);

			if (extract_partition(strip_filename, i, &partition_buffer, NULL)) {
				ERROR("Strip: Failed to get the needed partition. index:%d\n", i);
				goto error;
			}

			data_crc = crc32(data_crc, partition_buffer, part.size);
			if (fwrite(partition_buffer, 1, part.size, f_output) != part.size) {
				ERROR("Strip: Failed writing partition. Index:%d Err:%s\n", i, strerror(errno));
				goto error;
			}

			free(partition_buffer);
			partition_buffer = NULL;

			add_part_to_header(&h_output, &part, part_index);
			part_index++;
			set_h_image_size(&h_output, get_h_image_size(&h_output) + part.size);
		}
		else {
			INFO("Ignoring Manifest\n");
		}
	}

	/* Now finish the header information */
	set_h_part_num(&h_output, part_index);
	set_h_dcrc(&h_output, data_crc);
	set_h_hcrc(&h_output, 0);
	set_h_hcrc(&h_output, crc32(0, (uint8_t*)&h_output, header_size));

    /* Re-write the header. */
	if (fseek(f_output, 0, SEEK_SET)) {
        ERROR("Strip: Failed trying to reset the file pointer to start to write the "
			  "header. Err:%s\n", strerror(errno));
		goto error;
    }

	if (fwrite(&h_output, 1, header_size, f_output) != header_size) {
		ERROR("Strip: Failed writing 2nd header. Err:%s\n", strerror(errno));
		goto error;
	}

	print_header(&h_output);

	INFO("Stripped image is ready.\n");

	goto exit;

error:
	ret = 1;
exit:
	if (h_input) 
		free(h_input);
	if (f_output && fclose(f_output)) {
		ERROR("Failed trying to close file. File:%s Err:%s\n", output_filename, strerror(errno));
	}
	return ret;
}

char* manifest_type_filename(uint8_t manifest_type)
{
    switch(manifest_type)
    {
    case MANIFEST_TYPE_APP_CPU_KERNEL:            return "app_cpu_kernel";
    case MANIFEST_TYPE_APP_CPU_ROOT_FILESYSTEM:   return "app_cpu_rootfs";
    case MANIFEST_TYPE_NP_CPU_KERNEL:             return "np_cpu_kernel";
    case MANIFEST_TYPE_NP_CPU_ROOT_FILESYSTEM:    return "np_cpu_rootfs";
    case MANIFEST_TYPE_NP_CPU_GATEWAY_FILESYSTEM: return "np_cpu_gw";
    }
    ERROR("WARNING: The manifestType is not supported:%d\n", manifest_type);
    return "UnknownManifestType";
}

static int write_bin_file(char *file_name, uint8_t *buffer, uint32_t size)
{
    int ret = 0;
    FILE *file = NULL;

    file = fopen(file_name, "wb");
    if (!file)
    {
        int err = errno;
        ERR("Failed to open the file to write.\nFile:%s\nerrno:%d:%s\n",
                file_name, err, strerror(err));
        goto error;
    }

    size_t len;
    len = fwrite(buffer, size, 1, file);
    if (len != 1)
    {
        int err = errno;
        ERR("Failed to write the file.\nFile:%s\nNum elements written:%d\nerrno:%d:%s\n",
                file_name, (int)len, err, strerror(err));
        goto error;
    }

    goto exit;
error:
    ret = 1;
exit:
    if (file)
        fclose(file);
    return ret;
}

static int expand_image(char *file_name)
{
	assert(file_name);

	int ret = 0;
    int i;
	struct imageHeader *h;

	if (load_image_header(file_name, &h))
		goto error;

    INFO(" - Expanding Image:%s\n", file_name);
    INFO(" - Expand Path:%s\n", g_expand_path);

    for(i = 0; i < get_h_part_num(h); i++) {
        uint8_t type = get_part_type(h, i);
        uint8_t *buffer = NULL;
        uint32_t size;
        char output_file_name[PATH_MAX];

        output_file_name[0] = 0;
        strcat(output_file_name, g_expand_path);
        strcat(output_file_name, "/");
        if (type == PART_TYPE_OS_MANIFEST)
        {
            uint8_t manifest_type;
            if (get_manifest_type_of_index(file_name, i, &manifest_type))
                goto error;
            strcat(output_file_name, manifest_type_filename(manifest_type));
            strcat(output_file_name, ".osmanifest");
        }
        else
        {
            strcat(output_file_name, get_type_str(type));
            strcat(output_file_name, ".bin");
        }

        INFO("   - Extracting partition [% 2d]: %s\n", i, output_file_name);

        if (extract_partition(file_name, i, &buffer, &size))
            goto error;

        if (write_bin_file(output_file_name, buffer, size))
            goto error;

        free(buffer);
    }

	goto exit;

error:
	ret = 1;
exit:
	if (h) 
		free(h);
	return ret;
}

static void print_version_info(void)
{
	printf("Current version: 2.4.1\n");
	printf("\n");
	printf("Version History:\n");
	printf("2.4.1:\n");
	printf("  - Added support for v1 and v2 OS manifest files\n");
	printf("  - Added the version history\n");
	printf("2.4:\n");
	printf("  - Added the ability to expand a uimage into its original files\n");
	printf("  - Added the ability to accept corrupted ver2 uimages whose header\n");
	printf("    doesn't match the internal version (Temporary)\n");
	printf("2.3.1:\n");
	printf("  - Allow OS manifest hashs to fail as the BIOS wants to only hash\n");
	printf("    the kernel (Temporary)\n");
	printf("2.3:\n");
	printf("  - Renamed from mkimage to mkuImage\n");
	printf("2.1:\n");
	printf("  - Added ability to append a uimage to another uimage\n");
	printf("  - Added ability to strip a uimage of the OS manifests\n");
	printf("  - Added OS manifest hash verification to ensure manifests match \n");
	printf("    the partition\n");
	printf("  - Added both new and old style command line options\n");
	printf("2.0:\n");
	printf("  - Added OS Manifest support\n");
	printf("  - Added v3 uimage support (20 partitions)\n");
	printf("  - Added both BIOS mkuimage style command line options\n");
}

/* Print unified image header, and exit */
static void print_usage(void)
{
	print_version_info();
	printf("\n");
	printf("Usage: %s [-h]\n", g_prog_name);
	printf("      Generate: %s [-d] --generate <files_list> <output_image_file_name> "
		   "[--name <internal_header_name>] [--version <version>]\n", g_prog_name);
	printf("  Alt Generate: %s [-d] --files <files_list> --image <output_image_file_name> "
		   "[--name <internal_header_name>] [--version <version>]\n", g_prog_name);
	printf("        Append: %s [-d] --append <first_image_file> <second_image_file> "
		   "--image <output_image_file_name> [--name <internal_header_name>]\n", g_prog_name);
	printf("         Strip: %s [-d] --strip <input_uimage> --image <output_uimage>\n", g_prog_name);
	printf("        Verify: %s [-d] --check <image_file_name> [-N]\n", g_prog_name);
	printf("        Expand: %s [-d] --expand <image_file_name> [--path <path_to_store_output>]\n", g_prog_name);
	printf("\n");
    printf("Commands:\n");
	printf("  -g --generate  Create a new image. Arg: <files_list> <output_name>\n");
	printf("  -f --file      Create a new image. Image name is set with \"--image\". Arg: <file_list>\n");
    printf("  -a --append    Append the second uimage to the first uimage (Only supports version 3)\n");
    printf("  -c --check     Verify the image\n");
	printf("  -s --strip     Remove all the Chain-Of-Trust OS manifests from the uimage.\n");
	printf("  -e --expand    Expands a uimage into its individual files.\n");
	printf("\n");
	printf("Options:\n");
	printf("  -i --image     Output image file name\n");
    printf("  -N --noCRC     Do not verify the CRC of the image to check\n");
    printf("  -n --name      Optional internal name of image (default:'"DEFAULT_IMAGE_NAME"')\n");
    printf("  -v --version   Version of image (%d or %d)  - default:%d\n", MAX_VERSION-1, MAX_VERSION, MAX_VERSION);
    printf("  -p --path      Path to store expanded files\n");
    printf("  -d --debug     Debug output enable\n");
    printf("  -h --help      Print this help message\n");
	printf("\n");
    printf("Format:\n");
	printf("  image_name       Name of the unified image to be created or verified\n");
	printf("  files_list       List of input file descriptions separated by ':'\n");
    printf("                     Ex: file_desc1:file_desc2:file_desc3\n");
    printf("  file_description A file followed by type and optional attribute separated by ','\n");
    printf("                     Ex: filename1,type1,optional_attr1\n");
	printf("  types            Supported partition types:\n");
    printf("                      npcpu, appcpu, appcpu_kernel, appcpu_rootfs, npcpu_kernel,\n");
    printf("                      npcpu_rootfs, npcpu_gfs, ibb1, ibb2, cse_bup_fs, bbuc_bl,\n");
    printf("                      bbuc_conf, bbuc_fw, mcu, cefdk, cefdk_uimg, uboot, rawspi,\n");
    printf("                      uefi_bundle, os_manifest\n");
	printf("  attributes:      Optional attributes that follow a type (Only applicable to cefdk image type):\n");
    printf("                      allow_failsafe_cefdk, allow_non_failsafe_cefdk,\n");
    printf("                      allow_both_cefdk \n");
	printf("\n");
	printf("Examples:\n");
	printf("  Verify image:\n");
	printf("    %s --check uimage.img \n", g_prog_name);
	printf("  Generate image:\n");
	printf("    %s --file cefdk.bin,cefdk,allow_both_cefdk:kernel.img,"
           "appcpu_kernel:rootfs.img,appcpu_rootfs uimage.uimg --name \"My Uimage Name\""
           " --version %d --image my_output_image_file.uimg\n", g_prog_name, MAX_VERSION-1);
	printf("  Append images:\n");
	printf("    %s --append uimage1.uimg uimage2.uimg --image final.uimg --name "
		   "\"My Uimage Name\"\n", g_prog_name);
	printf("\n");
}
