/************************************************************************
 *
 * Copyright (c) 2012-2016 Intel Corporation
 * Consumer Electronics Firmware Development Kit (CEFDK) Source Code.
 * Use of this CEFDK Source Code is subject to the terms and conditions
 * of the Intel(R) CEFDK Software License Agreement.
 *
 ************************************************************************/
#ifndef _IMAGE_H
#define _IMAGE_H

#ifdef __linux__
  #include <arpa/inet.h>
#elif _WIN32
  #define _CRT_SECURE_NO_WARNINGS
  #include <conio.h>
  #include "Winsock2.h"
#else
  #error Platform not supported
#endif


#define VER2_MAX_PART_NUM 10
#define VER3_MAX_PART_NUM 20
#define MAX_PART_NUM      VER3_MAX_PART_NUM

#define MIN_VERSION 2
#define MAX_VERSION 3

#define MAX_NAME_LEN          20       

#define IMAGE_MAGIC_IMAG       ('I' << 24 | 'M' << 16 | 'A' << 8 | 'G')
#define IMAGE_MAGIC_VER2       ('V' << 24 | 'E' << 16 | 'R' << 8 | '2')
#define IMAGE_MAGIC_VER3       ('V' << 24 | 'E' << 16 | 'R' << 8 | '3')

#define PART_TYPE_NOT_SET            0   /* No image type */
#define PART_TYPE_APPCPU_UIMG        1   /* Application CPU unified image type */
#define PART_TYPE_APPCPU_KERNEL_BIN  2   /* Application CPU - Kernel binary image type */
#define PART_TYPE_APPCPU_ROOTFS_BIN  3   /* Application CPU - Root FS binary image type */
#define PART_TYPE_NPCPU_UBFI         4   /* Network Processor CPU image type */ 
#define PART_TYPE_CEFDK_BIN          5   /* CEFDK boot loader binary image type */
#define PART_TYPE_UBOOT_BIN          6   /* U-boot binary image type */
#define PART_TYPE_CEFDK_UIMG         7   /* CEFDK boot loader unified image type */
#define PART_TYPE_NPCPU_KERNEL_BIN   8   /* Network Processing CPU - Kernel binary image type */
#define PART_TYPE_NPCPU_ROOTFS_BIN   9   /* Network Processing CPU - Root FS binary image type */
#define PART_TYPE_GWFS_BIN           10  /* Network Processing CPU - GW FS binary image type */
#define PART_TYPE_UEFI_IBB1          11  /* UEFI Stage 1 binary image type */
#define PART_TYPE_UEFI_IBB2          12  /* UEFI Stage 2 binary image type */
#define PART_TYPE_CSE_BUP_FW         13  /* CSE BUP & FW image type */
#define PART_TYPE_BBUC_BL            14  /* BBU-C bootloader image type */
#define PART_TYPE_BBUC_CONF          15  /* BBU-C config image type */
#define PART_TYPE_BBUC_FW            16  /* BBU-C FW image type */
#define PART_TYPE_MCU                17  /* MCU image type */
#define PART_TYPE_RAW_SPI            18  /* Raw SPI image type */
#define PART_TYPE_UEFI_BUNDLE        19  /* UEFI Bundle image: IBB1,IBB2 and MCU combined */
#define PART_TYPE_OS_MANIFEST        25  /* OS manifest type, supports authenticating OS and filesystem images.*/


// MANIFEST types
#define MANIFEST_TYPE_APP_CPU_KERNEL                    0
#define MANIFEST_TYPE_APP_CPU_ROOT_FILESYSTEM           1
#define MANIFEST_TYPE_APP_CPU_VIDEO_GATEWAY_FILESYSTEM  2
#define MANIFEST_TYPE_NP_CPU_KERNEL                     3
#define MANIFEST_TYPE_NP_CPU_ROOT_FILESYSTEM            4
#define MANIFEST_TYPE_NP_CPU_GATEWAY_FILESYSTEM         5
#define MANIFEST_TYPE_MEDIA_CPU_KERNEL                  6
#define MANIFEST_TYPE_MEDIA_CPU_ROOT_FILESYSTEM         7
#define MANIFEST_TYPE_BIOS_STAGE_1                      8
#define MANIFEST_TYPE_RESERVED_9                        9
#define MANIFEST_TYPE_BBU_CONTROLLER_FIRMWARE          10
#define MANIFEST_TYPE_BBU_CONTROLLER_CONFIGURATION     11
#define MANIFEST_TYPE_RESERVED_12                      12
#define MANIFEST_TYPE_RESERVED_13                      13
#define MANIFEST_TYPE_RESERVED_14                      14
#define MANIFEST_TYPE_RESERVED_15                      15

#define MAX_PART_TYPES PART_TYPE_OS_MANIFEST

#define PART_ATTR_DISABLE_FAILSAFE_CEFDK_UPGRADE_BIT           0x00/*bit to support failsafe CEFDK upgrade: 0-failsafe upgrade is supported, 1-failsafe upgrade is disabled. 
                                                                     This logical is to make sure the backward compatability*/
#define PART_ATTR_ALLOW_NON_FAILSAFE_CEFDK_UPGRADE_BIT        0x01/*bit support non-failsafe CEFDK upgrade: 0-non_failsafe upgrade is disabled, 1-non_failsafe upgrade is enabled*/

struct ver2_info {
	uint32_t pCrc[VER2_MAX_PART_NUM];       /*partition CRC*/
	uint32_t pSize[VER2_MAX_PART_NUM];      /*partition size*/
    uint8_t  pType[VER2_MAX_PART_NUM];      /*partition Type*/
    uint8_t  pAttribute[VER2_MAX_PART_NUM]; /*partition Attributes*/
	uint8_t  reserved[8];
}__attribute__((packed));

struct ver3_info {
	uint32_t pCrc[VER3_MAX_PART_NUM];  /*partition CRC*/
	uint32_t pSize[VER3_MAX_PART_NUM]; /*partition size*/
    uint8_t  pType[VER3_MAX_PART_NUM]; /*partition Type*/
    uint8_t  pAttribute[VER3_MAX_PART_NUM]; /*partition Attributes*/
}__attribute__((packed));

struct imageHeader {
	uint32_t magic;
	uint8_t name[MAX_NAME_LEN];
	uint32_t date; /* UTC date (year-1900) << 16 | month << 8 | day */
	uint32_t time; /* UTC time hour << 16 | minute << 8 | second */
	uint32_t version; /*image version*/
	uint32_t imageSize;
	uint32_t partNum;
	uint32_t hCrc; /*image header CRC*/
	uint32_t dCrc; /*all data CRC*/
	union {
		struct ver2_info ver2;
		struct ver3_info ver3;
	}info;
}__attribute__((packed));

// The following gets the size of a structural member.
#define struct_member_size(type, member) (sizeof(((type*)0)->member))

#define UNION_SIZE            (struct_member_size(struct imageHeader, info))
#define VER2_INFO_SIZE  	  (sizeof(struct ver2_info))
#define VER3_INFO_SIZE  	  (sizeof(struct ver3_info))
#define MAX_INFO_SIZE  	      (VER3_INFO_SIZE)
#define UIMAGE_COMMON_SIZE (sizeof(struct imageHeader) - UNION_SIZE)
#define UIMAGE_HEADER_SIZE_V2 (UIMAGE_COMMON_SIZE + VER2_INFO_SIZE)
#define UIMAGE_HEADER_SIZE_V3 (UIMAGE_COMMON_SIZE + VER3_INFO_SIZE)
#define UIMAGE_HEADER_SIZE_MAX (sizeof(struct imageHeader))

#define MANIFEST_IDENTIFIER_V2 "$KFM"
#define MANIFEST_IDENTIFIER_V1 "$OSM"
#define MANIFEST_IDENTIFIER_LEN (struct_member_size(os_signed_t, manifestIdentifier))

typedef unsigned int uint;
typedef unsigned char uchar;

typedef struct
{
    char manifestIdentifier[4];
    uint manifestInternalVersion;
    uint manifestStructSize;
    uint secureVersionNumber;
    uint publicKeyHashIndex;
    uchar osImageHash[32];
    char reserved1[36];
    uint osManifestType;
    uint osImageSize;
    char oemData[392];
    char reserved2[20];
}os_signed_t;

typedef struct
{
    uchar publicKeyModulus[256];
    uchar publicKeyExponent[4];
    uchar manifestSignature[256];
}os_unsigned_t;

typedef struct
{
    os_signed_t   s;
    os_unsigned_t u;
}manifest_output_t;

#endif
