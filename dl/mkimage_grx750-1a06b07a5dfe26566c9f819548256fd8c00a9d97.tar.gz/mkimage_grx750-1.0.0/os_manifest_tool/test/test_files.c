/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "files.h"
#include "log.h"
#include "parameters.h"
#include "utilities.h"

#include "ctest.h"
#include "test_keys.h"
#include "test_memory_stream.h"
#include "test_utility.h"

#include <string.h>

static void setup(void)
{
    ResetGlobals();
    MemoryStreamOpen();
}

static void tear_down(void)
{
    MemoryStreamClose();
}

void test_read_file(void)
{
    char *pStr1 = "abcdefg";
    char *pStr2 = NULL;
    char *pFileName = "/tmp/somefile.txt";

    assert_equal(FileExists(pFileName), 0);
    assert_equal( write_txt_file(pStr1, pFileName), 0);
    assert_equal(FileExists(pFileName), 1);
    pStr2 = FileLoadTxt(pFileName);
    assert_true(pStr2 != NULL);
    assert_string_eq(pStr1, pStr2);
    assert_equal(remove_file(pFileName), 0);
}

void test_create_file(void)
{
    char *pFileName = "/tmp/test" MANIFEST_FILE_EXTENSION;
    manifest_output_t manifest;

    if(FileExists(pFileName))
        remove_file(pFileName);
    assert_equal_c(FileWrite(pFileName, &manifest, sizeof(manifest_output_t)), 0);
    assert_equal(FileExists(pFileName), 1);
    assert_equal(FileSize(pFileName), sizeof(manifest_output_t));

    manifest_output_t *pManifest = FileLoadBin(pFileName);
    assert_true(memcmp(pManifest, &manifest, sizeof(manifest_output_t)) == 0);
    free(pManifest);
    assert_equal(remove_file(pFileName), 0);
}

test_suite_t* create_suite_files()
{
    test_suite_t *pSuite = test_suite_create("Files");
    test_suite_add_setup(pSuite, setup);
    test_suite_add_teardown(pSuite, tear_down);

    test_suite_add_test(pSuite, test_create_file);
    test_suite_add_test(pSuite, test_read_file);
    return pSuite;
}

