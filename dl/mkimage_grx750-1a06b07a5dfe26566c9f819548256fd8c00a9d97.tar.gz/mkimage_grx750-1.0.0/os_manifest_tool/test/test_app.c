/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "files.h"
#include "log.h"
#include "parameters.h"
#include "utilities.h"

#include "ctest.h"
#include "test_utility.h"
#include "test_keys.h"

#include <openssl/pem.h>
#include <stdio.h>
#include <sys/wait.h>
#include <string.h>

#define IMAGE_FILE  "/tmp/app_image.bin"
#define CREATE_MANIFEST "/tmp/app_dummyCreateManifest"
#define CREATE_UNSIGNED_MANIFEST "/tmp/app_dummyUnsignedManifest"
#define SIGNATURE_FILE "/tmp/app_dummySignatureFile"
#define OEM_FILE "/tmp/app_oem.data"

static void create_files(void)
{
    int i;
    char pOemStr[392+1]; // Leave room for a NULL termination byte
    char *pImageStr = calloc(1024, 1);
    assert(pImageStr);
    memset(pImageStr, '1', sizeof(pImageStr)-1);
    assert_equal(write_txt_file(pImageStr, IMAGE_FILE), 0);
    CreateRsaPrivateKeyFile1();
    for (i = 0; i < sizeof(pOemStr); i++)
        pOemStr[i] = 'a' + (i % 26);
    pOemStr[sizeof(pOemStr)-1] = 0;
    assert_equal(write_txt_file(pOemStr, OEM_FILE), 0);
}

static void delete_files(void)
{
    assert_equal(remove_file(PRIVATE_RSA_KEY_FILE_NAME_1), 0);
    assert_equal(remove_file(IMAGE_FILE), 0);
    assert_equal(remove_file(OEM_FILE), 0);
}

static void setup(void)
{
    ResetGlobals();
    create_files();
}

static void tear_down(void)
{
    delete_files();
}

static void do_step1_create_unsigned_manifest(void)
{
    int status;
    char pOutput[4048*10];
    char *pCmd = "src/os_manifest_tool";
    char *pArgs[] = {"step1", "-u=" CREATE_UNSIGNED_MANIFEST, "-image=" IMAGE_FILE, "-type=7", 
                      "-oem=" OEM_FILE, "-version=42", "-keyIndex=5"};

    run_app(pCmd, LIST_LEN(pArgs), pArgs, &status, pOutput, sizeof(pOutput));
    assert_equal_c(status, 0);
    assert_substr(pOutput, "Create Unsigned Manifest");
    assert_substr(pOutput, CREATE_UNSIGNED_MANIFEST);
    assert_substr(pOutput, "Requested version:42");
    assert_substr(pOutput, "Requested type:7:Media CPU Root Filesystem");
    assert_substr(pOutput, "Unsigned Manifest successfully created");
    assert_no_substr(pOutput, "ERROR");
}

static void do_step2_generate_signature(void)
{
    int status;
    char pOutput[4048*10];
    char *pCmd = "src/os_manifest_tool";
    char *pArgs2[] = {"step2", "-u=" CREATE_UNSIGNED_MANIFEST UNSIGNED_MANIFEST_FILE_EXTENSION, 
                      "-private=" PRIVATE_RSA_KEY_FILE_NAME_1, "-sig=" SIGNATURE_FILE};

    CreateRsaPrivateKeyFile1();
    run_app(pCmd, LIST_LEN(pArgs2), pArgs2, &status, pOutput, sizeof(pOutput));
    assert_equal_c(status, 0);
    assert_substr(pOutput, "Create Unsigned Manifest");
    assert_substr(pOutput, CREATE_UNSIGNED_MANIFEST);
    assert_substr(pOutput, "Signature successfully created");
    assert_no_substr(pOutput, "ERROR");
    assert_equal(FileExists(SIGNATURE_FILE SIGNATURE_FILE_EXTENSION), 1);
}

static void do_step3_combine_manifest_to_signature()
{
    int status;
    char pOutput[4048*10];
    char *pCmd = "src/os_manifest_tool";
    char *pArgs3[] = {"step3", "-u=" CREATE_UNSIGNED_MANIFEST UNSIGNED_MANIFEST_FILE_EXTENSION, 
                      "-sig=" SIGNATURE_FILE SIGNATURE_FILE_EXTENSION, "-c=" CREATE_MANIFEST,
                      "-public=" PUBLIC_RSA_KEY_FILE_NAME_1 };

    CreateRsaPublicKeyFile1();
    run_app(pCmd, LIST_LEN(pArgs3), pArgs3, &status, pOutput, sizeof(pOutput));
    assert_equal_c(status, 0);
    assert_substr(pOutput, "Unsigned Manifest");
    assert_substr(pOutput, "Manifest successfully created");
    assert_substr(pOutput, CREATE_UNSIGNED_MANIFEST);
    assert_no_substr(pOutput, "ERROR");
}

void test_app_take_steps(void)
{
    char pOutput[4048*10];
    char *pCmd = "src/os_manifest_tool";
    int status;

    do_step1_create_unsigned_manifest();
    do_step2_generate_signature();
    do_step3_combine_manifest_to_signature();

    char *pArgs4[] = {"decode", "-f=" CREATE_MANIFEST MANIFEST_FILE_EXTENSION, "-image=" IMAGE_FILE};
    run_app(pCmd, LIST_LEN(pArgs4), pArgs4, &status, pOutput, sizeof(pOutput));
    assert_equal_c(status, 0);
    assert_substr(pOutput, "Manifest Size:0x400");
    assert_substr(pOutput, "Secure Version Num:0x2A:42");
    assert_substr(pOutput, "Public Key Hash Index:5");
    assert_substr(pOutput, "OS Manifest Type:7:Media CPU Root Filesystem");
    assert_substr(pOutput, "OEM Data:");
    assert_substr(pOutput, "|abcdefghijklmnop|");
    assert_substr(pOutput, "Image matches manifest");
    assert_no_substr(pOutput, "ERROR");
    assert_equal(remove_file(CREATE_MANIFEST MANIFEST_FILE_EXTENSION), 0);

    // Verify the Hash is correct
    char *pImage = FileLoadBin(IMAGE_FILE);
    int imageSize = FileSize(IMAGE_FILE);
    uchar pHash[32];
    SHA256((uchar*)pImage, imageSize, pHash);
    char *pLine = Bin2HexStr(pHash, sizeof(pHash));
    assert_substr(pOutput, pLine);
    free(pLine);
}

static void test_corrupt_unsigned_manifest()
{
    char pOutput[4048*10];
    char *pCmd = "src/os_manifest_tool";
    int status;
    char *pUnsignedManifestFile = CREATE_UNSIGNED_MANIFEST UNSIGNED_MANIFEST_FILE_EXTENSION;
    char *pArgs3[] = {"step3", "-u=" CREATE_UNSIGNED_MANIFEST UNSIGNED_MANIFEST_FILE_EXTENSION, 
                      "-sig=" SIGNATURE_FILE SIGNATURE_FILE_EXTENSION, "-c=" CREATE_MANIFEST,
                      "-public=" PUBLIC_RSA_KEY_FILE_NAME_1 };

    do_step1_create_unsigned_manifest();
    do_step2_generate_signature();

    // Corrupt the unsigned manifest to ensure that step 3 fails.
    char *pImage = FileLoadBin(pUnsignedManifestFile);
    int imageSize = FileSize(pUnsignedManifestFile);
    pImage[0] = 0;
    assert_equal(FileWrite(pUnsignedManifestFile, pImage, imageSize), 0);
    free(pImage);

    run_app(pCmd, LIST_LEN(pArgs3), pArgs3, &status, pOutput, sizeof(pOutput));
    assert_equal_c(status, 1);
    assert_substr(pOutput, "ERROR");
    assert_substr(pOutput, "corrupt");
}

void test_app_create_decode(void)
{
    char pOutput[4048*10];
    char *pCmd = "src/os_manifest_tool";
    char *pArgs1[] = {"full", "-c=" CREATE_MANIFEST, "-private=" PRIVATE_RSA_KEY_FILE_NAME_1,
                      "-image=" IMAGE_FILE, "-type=7", "-oem=" OEM_FILE, 
                      "-version=42", "-keyIndex=5"};
    int status;

    run_app(pCmd, LIST_LEN(pArgs1), pArgs1, &status, pOutput, sizeof(pOutput));
    assert_equal_c(status, 0);
    assert_substr(pOutput, "Create Manifest");
    assert_substr(pOutput, CREATE_MANIFEST);
    assert_substr(pOutput, "Requested version:42");
    assert_substr(pOutput, "Requested type:7:Media CPU Root Filesystem");
    assert_no_substr(pOutput, "ERROR");

    char *pArgs2[] = {"decode", "-f=" CREATE_MANIFEST MANIFEST_FILE_EXTENSION, "-image=" IMAGE_FILE};
    run_app(pCmd, LIST_LEN(pArgs2), pArgs2, &status, pOutput, sizeof(pOutput));
    assert_equal_c(status, 0);
    assert_substr(pOutput, "Manifest Size:0x400");
    assert_substr(pOutput, "Secure Version Num:0x2A:42");
    assert_substr(pOutput, "Public Key Hash Index:5");
    assert_substr(pOutput, "OS Manifest Type:7:Media CPU Root Filesystem");
    assert_substr(pOutput, "OEM Data:");
    assert_substr(pOutput, "|abcdefghijklmnop|");
    assert_substr(pOutput, "Image matches manifest");
    assert_no_substr(pOutput, "ERROR");
    assert_equal(remove_file(CREATE_MANIFEST MANIFEST_FILE_EXTENSION), 0);

    // Verify the Hash is correct
    char *pImage = FileLoadBin(IMAGE_FILE);
    int imageSize = FileSize(IMAGE_FILE);
    uchar pHash[32];
    SHA256((uchar*)pImage, imageSize, pHash);
    char *pLine = Bin2HexStr(pHash, sizeof(pHash));
    assert_substr(pOutput, pLine);
    free(pLine);
}

void test_app_create_decode_no_oem_data(void)
{
    char pOutput[4048*10];
    char *pCmd = "src/os_manifest_tool";
    char *pArgs1[] = {"full", "-c=" CREATE_MANIFEST, "-private=" PRIVATE_RSA_KEY_FILE_NAME_1,
                      "-image=" IMAGE_FILE, "-type=3", "-version=254", 
                      "-keyIndex=6"};
    int status;

    run_app(pCmd, LIST_LEN(pArgs1), pArgs1, &status, pOutput, sizeof(pOutput));
    assert_substr(pOutput, "Create Manifest");
    assert_substr(pOutput, CREATE_MANIFEST);
    assert_substr(pOutput, "Requested version:254");
    assert_substr(pOutput, "Requested type:3:NP CPU Kernel");
    assert_no_substr(pOutput, "ERROR");
    assert_equal(status, 0);

    char *pArgs2[] = {"decode", "-f=" CREATE_MANIFEST MANIFEST_FILE_EXTENSION};
    run_app(pCmd, LIST_LEN(pArgs2), pArgs2, &status, pOutput, sizeof(pOutput));
    assert_substr(pOutput, "Secure Version Num:0xFE:254");
    assert_substr(pOutput, "Public Key Hash Index:6");
    assert_substr(pOutput, "OS Manifest Type:3:NP CPU Kernel");
    assert_substr(pOutput, "OEM Data:");
    assert_no_substr(pOutput, "ERROR");
    assert_equal(status, 0);
    assert_equal(remove_file(CREATE_MANIFEST MANIFEST_FILE_EXTENSION), 0);
}

test_suite_t* create_suite_app()
{
    test_suite_t *pSuite = test_suite_create("App");
    test_suite_add_setup(pSuite, setup);
    test_suite_add_teardown(pSuite, tear_down);

    test_suite_add_test(pSuite, test_app_create_decode);
    test_suite_add_test(pSuite, test_app_create_decode_no_oem_data);
    test_suite_add_test(pSuite, test_app_take_steps);
    test_suite_add_test(pSuite, test_corrupt_unsigned_manifest);
    return pSuite;
}


