/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "log.h"

#include "ctest.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

static char *gpStreamBuffer = NULL;
static size_t gStreamSize;
static FILE *gpStreamFile = NULL;
static bool gIsStreamOpen = false;
static bool gDebugStream = false;

void MemoryStreamOpen_(const char *pFunction, const char *pFile, int line)
{
    static char *pLastFunction = NULL;
    static char *pLastFile = NULL;
    static int lastLine = 0;

    if (gDebugStream)
        printf("%s: From:%s:%s():%d\n", __FUNCTION__, pFile, pFunction, line);

    if (gIsStreamOpen)
    {
        fprintf(stderr, "ERROR: Stream is already open\n");
        fprintf(stderr, "Previously opened by %s:%s():%d\n", pLastFile, pLastFunction, lastLine);
        assert(gIsStreamOpen == false);
    }

    if (pLastFile)
        free(pLastFile);
    pLastFile = strdup(pFile);
    if (pLastFunction)
        free(pLastFunction);
    pLastFunction = strdup(pFunction);
    lastLine = line;

    gIsStreamOpen = true;
    gpStreamFile = open_memstream(&gpStreamBuffer, &gStreamSize);
    SetLogFilePointer(gpStreamFile);
}

void MemoryStreamClose(void)
{
    if (gDebugStream)
        printf("%s\n", __FUNCTION__);

    if (!gIsStreamOpen)
    {
        fprintf(stderr, "ERROR: Trying to close a closed Stream\n");
        assert(gIsStreamOpen == true);
    }

    SetLogFilePointer(NULL);
    fclose(gpStreamFile);
    gIsStreamOpen = false;
}

void MemoryStreamPrint(void)
{
    if (!gIsStreamOpen)
    {
        fprintf(stderr, "ERROR: Attempting to print a closed memory stream.\n");
        assert(gIsStreamOpen == true);
    }

    fflush(gpStreamFile);
    printf("Size:%lu Str:%s\n", gStreamSize, gpStreamBuffer);
}

void MemoryStreamContains_(char *pSubStr, const char *pFunc, int line)
{
    if (!gIsStreamOpen)
    {
        fprintf(stderr, "ERROR: Attempting to test a closed memory stream.\n");
        assert(gIsStreamOpen == true);
    }

    fflush(gpStreamFile);
    assert_substr_c(gpStreamBuffer, pSubStr);
    if (has_test_failed())
        printf("--------> Error at %s():%d\n", pFunc, line);
}

void MemoryStreamDoesntContains_(char *pSubStr, const char *pFunc, int line)
{
    if (!gIsStreamOpen)
    {
        fprintf(stderr, "ERROR: Attempting to test a closed memory stream.\n");
        assert(gIsStreamOpen == true);
    }

    fflush(gpStreamFile);
    assert_no_substr_c(gpStreamBuffer, pSubStr);
    if (has_test_failed())
        printf("--------> Error at %s():%d\n", pFunc, line);
}

