/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __TEST_MEMORY_STREAM_H__
#define __TEST_MEMORY_STREAM_H__

#define MemoryStreamOpen() MemoryStreamOpen_(__FUNCTION__, __FILE__, __LINE__)
void MemoryStreamOpen_(const char *pFunction, const char *pFile, int line);
void MemoryStreamClose(void);
void MemoryStreamPrint(void);
#define MemoryStreamContains(pSubStr) MemoryStreamContains_(pSubStr, __FUNCTION__, __LINE__)
void MemoryStreamContains_(char *pSubStr, const char *pFunc, int line);
#define MemoryStreamDoesntContains(pSubStr) MemoryStreamDoesntContains_(pSubStr, __FUNCTION__, __LINE__)
void MemoryStreamDoesntContains_(char *pSubStr, const char *pFunc, int line);

#endif
