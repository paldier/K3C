/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "manifest.h"
#include "utilities.h"
#include "log.h"

#include "ctest.h"

void test_verify_swap_bytes(void)
{
    uint pVal[3];
    pVal[0] = 0xDEADBEEF;
    pVal[1] = 0x12345678;
    pVal[2] = 0x0A0B0C0D;
    SwapEndianness((char*)pVal, sizeof(pVal));
    assert_equal(pVal[0], 0xEFBEADDE);
    assert_equal(pVal[1], 0x78563412);
    assert_equal(pVal[2], 0x0D0C0B0A);
}

void test_verify_bin2hexstr(void)
{
    uchar pNumList[6] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66};
    char *pLine = Bin2HexStr(pNumList, sizeof(pNumList));
    assert_string_eq(pLine, "112233445566");
    free(pLine);
}

void test_verify_isstrequal(void)
{
    assert_equal(IsStrEqual("1", "1"), 1);
    assert_equal(IsStrEqual("1", "2"), 0);
}

test_suite_t* create_suite_utility()
{
    test_suite_t *pSuite = test_suite_create("Utility");
    test_suite_add_test(pSuite, test_verify_swap_bytes);
    test_suite_add_test(pSuite, test_verify_bin2hexstr);
    test_suite_add_test(pSuite, test_verify_isstrequal);
    return pSuite;
}
