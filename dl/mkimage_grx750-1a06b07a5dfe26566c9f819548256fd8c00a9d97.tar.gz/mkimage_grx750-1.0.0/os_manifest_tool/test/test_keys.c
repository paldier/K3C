/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include <stdlib.h>
#include "test_utility.h"
#include "test_keys.h"

char *gpRsaPrivateKeyString1 = 
"-----BEGIN RSA PRIVATE KEY-----\n"
"MIIEowIBAAKCAQEAn6ONQhGv2IM9JV2rUp+/mMtjf6wzFadSImhLPp1LAlD938xA\n"
"3I/qLOh46NWAKV27YmUtLajLSo6+zhTL8w81TmksYCxzElXUuZargx/kR/hOTXAh\n"
"IaiBvyO+zXS/KxazI4KUVf37hnmXXvF/I8gUVBCzDjt7jOQeor7v61VRoiOlAKZp\n"
"1rHYx79hv6QStSvl27qzZYYOQikeq2vfrUxC27tZO6yfVdOuJZWvLPKhGZ2vo/yG\n"
"BJjxy2PU41iL/ze00okS1UpC+XP9XM31Vi2SDFZ/QDgYE92zupvcgOSnhlSo7r4E\n"
"eqcARFNotPOFv5v+J5T+Y8TMxvP4a/c3ck35wQIDAQABAoIBAEnVVBT1pzXlZRdu\n"
"HjnlprDdiNRY6XufWo6NXBfGmhWlLfYfOvSIH0/L6XgOnusC7hLRJrcSdYuzP66C\n"
"0d1F8GqmnB6TEFmvluaLOCI6UtOylUydisVNcUzdFHdkArLEGfBXiZHIGVgVzpvb\n"
"5+i9tiE3ZAk2G6uLKlwtITvfxxTM2o2qtlA7aMwsFtkTzQne3kLukCZ8YLhv6t7l\n"
"1+sVH0/bZWOhiYHRVKBTA+Oaqimp8oYMhe/qnJudZSu992ikvMI+sHXAHVS29ol2\n"
"xAzGcYOmwhQeKbPCx1VAn6FkXmo4xfJxh8JCFhYOybt7oYKJls/gJViQjUTeXo1X\n"
"hK8YHQECgYEAzp08UNLtEdH3xQm51PJlqY4JMJIn0C6wTiKn+lyRWRCVNo4l1V1U\n"
"QpCZBibO24uocSJA/5hgJgLwYFgkdt2WBYTLyIpewvM37PqCgCwkFlRiMktdBAx1\n"
"Dwf4OY7Uo1DNYfu5+EvBXwUT4FqEZ9zwhBl/nKK5t6x7Wmzjs9iva5ECgYEAxcvi\n"
"8KlIbgM+RnGq6fBzLbx4P3qFxFk+3ZFQlCKZVFqnVj9ebOdWWDxRWCIu+QddeNED\n"
"PQIhOlYag7pltWstGrNJpQfHkjFSj7nOrxBbkuSa1jW5y4F0ZAC82SAGRYpoK3+o\n"
"ygvMMlx4vNdriSmLxLQNR8158XEYGGL46N5EszECgYByC+qyNmtzjbG1SnQQLiid\n"
"mfBKpjJhwJPC3XBZSuVUA0pJzdbmWljbUVOWSK+gEgvNPvof260e7jpfA+hE0HUx\n"
"4KZXsMEz3Or+3RxRwYu946A8YMscJAAtZtnGc6e96ikkL73sZ2x6laPuECjL5/G/\n"
"CRAeltfqocOJG1fo+u+BcQKBgEFaipNl+46N98eiywwc7JGSElE3FHe53TGsT+mC\n"
"PRNIGL5Aldx522ewFlh+gvK5YkMHHIDN8VirFnur3OtCjFakIpMqrOA698KRbB8f\n"
"0oIIkrhwbAE3ttNMAxnioO/dOWoV9hk8KK4DK8mJi/h4B7xomXK+C6qg6Ys1OHUI\n"
"674hAoGBAM5Fn0qVu+UJShTGJEnMIOXVJXCrvzwgyYBShjzF6Vp9nfXOkncFepdm\n"
"kw/eXjfuQwJaPHjbQkIg2K1K6fdf1MjCHqUCOVwOd1jfEPCl2XMs7hhXXo7Y5iX4\n"
"hgDPDIiGvgalLKkVdu7K8dsmJLi/Q2uQiHg4oAraE0KHkZNXtGJN\n"
"-----END RSA PRIVATE KEY-----";

char *gpRsaPublicKeyString1 = 
"-----BEGIN RSA PUBLIC KEY-----\n"
"MIIBCgKCAQEAn6ONQhGv2IM9JV2rUp+/mMtjf6wzFadSImhLPp1LAlD938xA3I/q\n"
"LOh46NWAKV27YmUtLajLSo6+zhTL8w81TmksYCxzElXUuZargx/kR/hOTXAhIaiB\n"
"vyO+zXS/KxazI4KUVf37hnmXXvF/I8gUVBCzDjt7jOQeor7v61VRoiOlAKZp1rHY\n"
"x79hv6QStSvl27qzZYYOQikeq2vfrUxC27tZO6yfVdOuJZWvLPKhGZ2vo/yGBJjx\n"
"y2PU41iL/ze00okS1UpC+XP9XM31Vi2SDFZ/QDgYE92zupvcgOSnhlSo7r4EeqcA\n"
"RFNotPOFv5v+J5T+Y8TMxvP4a/c3ck35wQIDAQAB\n"
"-----END RSA PUBLIC KEY-----\n";

char *gpEvpPrivateKeyString2 = 
"-----BEGIN RSA PRIVATE KEY-----\n"
"MIIEowIBAAKCAQEAn6ONQhGv2IM9JV2rUp+/mMtjf6wzFadSImhLPp1LAlD938xA\n"
"3I/qLOh46NWAKV27YmUtLajLSo6+zhTL8w81TmksYCxzElXUuZargx/kR/hOTXAh\n"
"IaiBvyO+zXS/KxazI4KUVf37hnmXXvF/I8gUVBCzDjt7jOQeor7v61VRoiOlAKZp\n"
"1rHYx79hv6QStSvl27qzZYYOQikeq2vfrUxC27tZO6yfVdOuJZWvLPKhGZ2vo/yG\n"
"BJjxy2PU41iL/ze00okS1UpC+XP9XM31Vi2SDFZ/QDgYE92zupvcgOSnhlSo7r4E\n"
"eqcARFNotPOFv5v+J5T+Y8TMxvP4a/c3ck35wQIDAQABAoIBAEnVVBT1pzXlZRdu\n"
"HjnlprDdiNRY6XufWo6NXBfGmhWlLfYfOvSIH0/L6XgOnusC7hLRJrcSdYuzP66C\n"
"0d1F8GqmnB6TEFmvluaLOCI6UtOylUydisVNcUzdFHdkArLEGfBXiZHIGVgVzpvb\n"
"5+i9tiE3ZAk2G6uLKlwtITvfxxTM2o2qtlA7aMwsFtkTzQne3kLukCZ8YLhv6t7l\n"
"1+sVH0/bZWOhiYHRVKBTA+Oaqimp8oYMhe/qnJudZSu992ikvMI+sHXAHVS29ol2\n"
"xAzGcYOmwhQeKbPCx1VAn6FkXmo4xfJxh8JCFhYOybt7oYKJls/gJViQjUTeXo1X\n"
"hK8YHQECgYEAzp08UNLtEdH3xQm51PJlqY4JMJIn0C6wTiKn+lyRWRCVNo4l1V1U\n"
"QpCZBibO24uocSJA/5hgJgLwYFgkdt2WBYTLyIpewvM37PqCgCwkFlRiMktdBAx1\n"
"Dwf4OY7Uo1DNYfu5+EvBXwUT4FqEZ9zwhBl/nKK5t6x7Wmzjs9iva5ECgYEAxcvi\n"
"8KlIbgM+RnGq6fBzLbx4P3qFxFk+3ZFQlCKZVFqnVj9ebOdWWDxRWCIu+QddeNED\n"
"PQIhOlYag7pltWstGrNJpQfHkjFSj7nOrxBbkuSa1jW5y4F0ZAC82SAGRYpoK3+o\n"
"ygvMMlx4vNdriSmLxLQNR8158XEYGGL46N5EszECgYByC+qyNmtzjbG1SnQQLiid\n"
"mfBKpjJhwJPC3XBZSuVUA0pJzdbmWljbUVOWSK+gEgvNPvof260e7jpfA+hE0HUx\n"
"4KZXsMEz3Or+3RxRwYu946A8YMscJAAtZtnGc6e96ikkL73sZ2x6laPuECjL5/G/\n"
"CRAeltfqocOJG1fo+u+BcQKBgEFaipNl+46N98eiywwc7JGSElE3FHe53TGsT+mC\n"
"PRNIGL5Aldx522ewFlh+gvK5YkMHHIDN8VirFnur3OtCjFakIpMqrOA698KRbB8f\n"
"0oIIkrhwbAE3ttNMAxnioO/dOWoV9hk8KK4DK8mJi/h4B7xomXK+C6qg6Ys1OHUI\n"
"674hAoGBAM5Fn0qVu+UJShTGJEnMIOXVJXCrvzwgyYBShjzF6Vp9nfXOkncFepdm\n"
"kw/eXjfuQwJaPHjbQkIg2K1K6fdf1MjCHqUCOVwOd1jfEPCl2XMs7hhXXo7Y5iX4\n"
"hgDPDIiGvgalLKkVdu7K8dsmJLi/Q2uQiHg4oAraE0KHkZNXtGJN\n"
"-----END RSA PRIVATE KEY-----\n";

char *gpEvpPublicKeyString2 =
"-----BEGIN PUBLIC KEY-----\n"
"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAn6ONQhGv2IM9JV2rUp+/\n"
"mMtjf6wzFadSImhLPp1LAlD938xA3I/qLOh46NWAKV27YmUtLajLSo6+zhTL8w81\n"
"TmksYCxzElXUuZargx/kR/hOTXAhIaiBvyO+zXS/KxazI4KUVf37hnmXXvF/I8gU\n"
"VBCzDjt7jOQeor7v61VRoiOlAKZp1rHYx79hv6QStSvl27qzZYYOQikeq2vfrUxC\n"
"27tZO6yfVdOuJZWvLPKhGZ2vo/yGBJjxy2PU41iL/ze00okS1UpC+XP9XM31Vi2S\n"
"DFZ/QDgYE92zupvcgOSnhlSo7r4EeqcARFNotPOFv5v+J5T+Y8TMxvP4a/c3ck35\n"
"wQIDAQAB\n"
"-----END PUBLIC KEY-----\n";

char* CreateRsaPrivateKeyFile1(void)
{
    char *ret = NULL;
    if(!write_txt_file(gpRsaPrivateKeyString1, PRIVATE_RSA_KEY_FILE_NAME_1))
    {
        ret = PRIVATE_RSA_KEY_FILE_NAME_1;
    }
    return ret;
}

char* CreateRsaPublicKeyFile1(void)
{
    char *ret = NULL;
    if(!write_txt_file(gpRsaPublicKeyString1, PUBLIC_RSA_KEY_FILE_NAME_1))
    {
        ret = PUBLIC_RSA_KEY_FILE_NAME_1;
    }
    return ret;
}

char* CreateEvpPrivateKeyFile2(void)
{
    char *ret = NULL;
    if(!write_txt_file(gpRsaPrivateKeyString1, PRIVATE_RSA_KEY_FILE_NAME_1))
    {
        ret = PRIVATE_RSA_KEY_FILE_NAME_1;
    }
    return ret;
}

char* CreateEvpPublicKeyFile2(void)
{
    char *ret = NULL;
    if(!write_txt_file(gpRsaPublicKeyString1, PUBLIC_RSA_KEY_FILE_NAME_1))
    {
        ret = PUBLIC_RSA_KEY_FILE_NAME_1;
    }
    return ret;
}
