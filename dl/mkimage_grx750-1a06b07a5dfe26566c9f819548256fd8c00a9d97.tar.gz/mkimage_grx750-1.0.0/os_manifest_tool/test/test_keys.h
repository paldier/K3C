/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __KEYS_H__
#define __KEYS_H__
#define PRIVATE_RSA_KEY_FILE_NAME_1 "/tmp/PrivateRsaKeyTestFile1.pem"
#define PUBLIC_RSA_KEY_FILE_NAME_1 "/tmp/PublicRsaKeyTestFile1.pem"
#define PRIVATE_EVP_KEY_FILE_NAME_2 "/tmp/PrivateEvpKeyTestFile2.pem"
#define PUBLIC_EVP_KEY_FILE_NAME_2 "/tmp/PublicEvpKeyTestFile2.pem"
char* CreateRsaPrivateKeyFile1(void);
char* CreateRsaPublicKeyFile1(void);
char* CreateEvpPrivateKeyFile2(void);
char* CreateEvpPublicKeyFile2(void);
extern char *gpRsaPrivateKeyString1;
extern char *gpRsaPublicKeyString1;
#endif
