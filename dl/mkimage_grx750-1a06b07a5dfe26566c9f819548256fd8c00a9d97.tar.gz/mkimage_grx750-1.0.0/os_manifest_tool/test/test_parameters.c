/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "parameters.h"
#include "log.h"

#include "ctest.h"
#include "test_keys.h"
#include "test_memory_stream.h"
#include "test_utility.h"

#include <stdio.h>
#include <string.h>

#define IMAGE_FILE  "/tmp/param_image.bin"
#define DUMMY_MANIFEST "/tmp/param_dummyManifest"
#define CREATE_MANIFEST "/tmp/param_dummyCreateManifest"
#define OEM_FILE "/tmp/param_oem.data"
#define OEM_BIG_FILE "/tmp/param_oem_BIG.data"

static void create_files(void)
{
    int i;
    char pOemStr[392+1]; // Leave room for a NULL termination byte
    char pOemBigStr[393+1]; // Leave room for a NULL termination byte
    char *pImageStr = calloc(1024, 1);
    assert(pImageStr);
    memset(pImageStr, '1', sizeof(pImageStr)-1);
    assert_equal(write_txt_file(pImageStr, IMAGE_FILE), 0);
    CreateRsaPrivateKeyFile1();
    CreateRsaPublicKeyFile1();
    assert_equal(write_txt_file("test manifest", DUMMY_MANIFEST), 0);
    for (i = 0; i < sizeof(pOemStr); i++)
        pOemStr[i] = '0' + (i % 10);
    pOemStr[sizeof(pOemStr)-1] = 0;

    assert_equal(write_txt_file(pOemStr, OEM_FILE), 0);
    for (i = 0; i < sizeof(pOemBigStr); i++)
        pOemBigStr[i] = '0' + (i % 10);
    pOemBigStr[sizeof(pOemBigStr)-1] = 0;
    assert_equal(write_txt_file(pOemBigStr, OEM_BIG_FILE), 0);
}

static void delete_files(void)
{
    assert_equal(remove_file(IMAGE_FILE), 0);
    assert_equal(remove_file(PRIVATE_RSA_KEY_FILE_NAME_1), 0);
    assert_equal(remove_file(PUBLIC_RSA_KEY_FILE_NAME_1), 0);
    assert_equal(remove_file(DUMMY_MANIFEST), 0);
    assert_equal(remove_file(OEM_FILE), 0);
    assert_equal(remove_file(OEM_BIG_FILE), 0);
}

static void setup(void)
{
    create_files();
    MemoryStreamOpen();

    ResetGlobals();
    assert_string_eq(GetDecodeFile(), NULL);
    //assert_equal(IsCreateSet(), false);
    assert_string_eq(GetManifestFile(), NULL);
}

static void tear_down(void)
{
    delete_files();
    MemoryStreamClose();
}

///////////////////////////////////////////////////////
// Step1
void test_param_step1_verify_command(void)
{
    char *pArgv1[] = {"cmd", "step1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);

    assert_equal(GetCommand(), CommandStep1);
    MemoryStreamContains("Step1");

    char *pArgv2[] = {"cmd", "generate_unsigned_manifest"};
    assert_equal(ParseParameters(LIST_LEN(pArgv2), pArgv2), 0);
    assert_equal(GetCommand(), CommandStep1);
    MemoryStreamContains("Step1");
}

void test_param_step1_verify_output_file(void)
{
    #define DUMMY_FILE "/tmp/dummy_file"
    char *pArgv1[] = {"cmd", "step1", "-u=" DUMMY_FILE};
    assert_equal(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_string_eq(GetUnsignedManifestFile(), DUMMY_FILE UNSIGNED_MANIFEST_FILE_EXTENSION);
    MemoryStreamContains("Create Unsigned Manifest");
}

void test_param_step1_set_image(void)
{
    char *pArgv[] = {"cmd", "step1", "-image="IMAGE_FILE };
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("Image file to be hashed:");
    assert_string_eq(GetImageInputFile(), IMAGE_FILE);
}

void test_param_step1_set_image_no_file(void)
{
    char *pArgv[] = {"cmd", "step1", "-image="IMAGE_FILE".blah" };
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("The image file doesn't exist");
    assert_string_eq(GetImageInputFile(), NULL);
}

void test_param_step1_set_oem_data(void)
{
    char *pArgv[] = {"cmd", "step1", "-oem="OEM_FILE };
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("OEM Data File:");
    assert_string_eq(GetOemDataFile(), OEM_FILE);
}

void test_param_step1_set_oem_data_no_file(void)
{
    char *pArgv[] = {"cmd", "step1", "-oem="OEM_FILE".blah" };
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("The OEM data file doesn't exist");
    assert_string_eq(GetOemDataFile(), NULL);
}

void test_param_step1_set_oem_data_too_big(void)
{
    char *pArgv[] = {"cmd", "step1", "-oem="OEM_BIG_FILE };
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("OEM data file is too big");
    assert_string_eq(GetOemDataFile(), NULL);
}

void test_param_step1_set_type(void)
{
    char *pArgv[] = {"cmd", "step1", "-type=8"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    assert_equal(GetImageType(), 8);
    MemoryStreamContains("8:BIOS Stage 1");
}

void test_param_step1_set_invalid_type(void)
{
    char *pArgv[] = {"cmd", "step1", "-type=16"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    assert_equal(GetImageType(), -1);
    MemoryStreamContains("The requested type (16) is less");
    tear_down();

    setup();
    char *pArgv1[] = {"cmd", "step1", "-type=-1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv1), 1);
    assert_equal(GetImageType(), -1);
    MemoryStreamContains("The requested type (-1) is less");
}

void test_param_step1_set_secure_version_number(void)
{
    char *pArgv[] = {"cmd", "step1", "-version=255"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    assert_equal(GetSecureVersion(), 255);
    MemoryStreamContains("Requested version:255");
    tear_down();

    setup();
    char *pArgv1[] = {"cmd", "step1", "-version=1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_equal(GetSecureVersion(), 1);
    MemoryStreamContains("Requested version:1");
}

void test_param_step1_set_invalid_secure_version_number(void)
{
    char *pArgv[] = {"cmd", "step1", "-version=-1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    assert_equal(GetSecureVersion(), 0);
    MemoryStreamContains("The requested secured version");
    tear_down();

    setup();
    char *pArgv1[] = {"cmd", "step1", "-version=256"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 1);
    assert_equal(GetSecureVersion(), 0);
    MemoryStreamContains("The requested secured version");
}

void test_param_step1_set_public_key_index(void)
{
    char *pArgv1[] = {"cmd", "step1", "-keyIndex=0"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_equal(GetPublicKeyIndex(), 0);
    MemoryStreamContains("Requested public key index:0");
    tear_down();

    setup();
    char *pArgv2[] = {"cmd", "step1", "-keyIndex=9"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv2), pArgv2), 0);
    assert_equal(GetPublicKeyIndex(), 9);
    MemoryStreamContains("Requested public key index:9");
}

void test_param_step1_set_invalid_public_key_index(void)
{
    char *pArgv1[] = {"cmd", "step1", "-keyIndex=-1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 1);
    assert_equal(GetPublicKeyIndex(), -1);
    MemoryStreamContains("The requested public key index (-1)");
    tear_down();

    setup();
    char *pArgv2[] = {"cmd", "step1", "-keyIndex=10"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv2), pArgv2), 1);
    assert_equal(GetPublicKeyIndex(), -1);
    MemoryStreamContains("The requested public key index (10)");
}

void test_param_step1_list_types(void)
{
    char *pArgv[] = {"cmd", "step1", "-list"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("0:App CPU Kernel");
    MemoryStreamContains("8:BIOS Stage 1");
    MemoryStreamDoesntContains("ERROR");
}

///////////////////////////////////////////////////////
// Step2
void test_param_step2_verify_command(void)
{
    char *pArgv1[] = {"cmd", "step2"};
    assert_equal(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_equal(GetCommand(), CommandStep2);
    MemoryStreamContains("Step2");

    char *pArgv2[] = {"cmd", "generate_signature"};
    assert_equal(ParseParameters(LIST_LEN(pArgv2), pArgv2), 0);
    assert_equal(GetCommand(), CommandStep2);
    MemoryStreamContains("Step2");
}

void test_param_step2_set_private_key_no_file(void)
{
    char *pArgv[] = {"cmd", "step2", "-private=" PRIVATE_RSA_KEY_FILE_NAME_1 ".blah"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("The private key doesn't exist");
    assert_string_eq(GetPrivateKeyFile(), NULL);
}

void test_param_step2_set_private_key(void)
{
    char *pArgv[] = {"cmd", "step2", "-private=" PRIVATE_RSA_KEY_FILE_NAME_1};
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("Private key:");
    assert_string_eq(GetPrivateKeyFile(), PRIVATE_RSA_KEY_FILE_NAME_1);
}

///////////////////////////////////////////////////////
// Step3
void test_param_step3_verify_command(void)
{
    char *pArgv1[] = {"cmd", "step3"};
    assert_equal(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_equal(GetCommand(), CommandStep3);
    MemoryStreamContains("Step3");

    char *pArgv2[] = {"cmd", "attach_signature_to_unsigned_manifest"};
    assert_equal(ParseParameters(LIST_LEN(pArgv2), pArgv2), 0);
    assert_equal(GetCommand(), CommandStep3);
    MemoryStreamContains("Step3");
}

void test_param_step3_set_public_key_no_file(void)
{
    char *pArgv[] = {"cmd", "step3", "-public=" PUBLIC_RSA_KEY_FILE_NAME_1 ".blah"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("The public key doesn't exist");
    assert_string_eq(GetPrivateKeyFile(), NULL);
}

void test_param_step3_set_public_key(void)
{
    char *pArgv[] = {"cmd", "step3", "-public=" PUBLIC_RSA_KEY_FILE_NAME_1};
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("Public key:");
    assert_string_eq(GetPublicKeyFile(), PUBLIC_RSA_KEY_FILE_NAME_1);
}

void test_param_step3_set_sig_no_file(void)
{
    char *pArgv[] = {"cmd", "step3", "-sig=" PUBLIC_RSA_KEY_FILE_NAME_1 ".blah"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("The signature file doesn't exist");
    assert_string_eq(GetPrivateKeyFile(), NULL);
}

void test_param_step3_set_sig(void)
{
    char *pArgv[] = {"cmd", "step3", "-sig=" PUBLIC_RSA_KEY_FILE_NAME_1};
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("Signature file:");
    assert_string_eq(GetSignatureFile(), PUBLIC_RSA_KEY_FILE_NAME_1);
}

void test_param_step3_set_output_file(void)
{
    char *pArgv[] = {"cmd", "step3", "-c=" CREATE_MANIFEST};
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("Create Manifest:");
    assert_string_eq(GetManifestFile(), CREATE_MANIFEST MANIFEST_FILE_EXTENSION );
}

///////////////////////////////////////////////////////
// Full
void test_param_full_verify_command(void)
{
    char *pArgv1[] = {"cmd", "full"};
    assert_equal(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_equal(GetCommand(), CommandFull);
    MemoryStreamContains("Full");
}

void test_param_full_verify_output_file(void)
{
    char *pArgv1[] = {"cmd", "full", "-c=" CREATE_MANIFEST};
    assert_equal(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_string_eq(GetManifestFile(), CREATE_MANIFEST MANIFEST_FILE_EXTENSION);
    MemoryStreamContains("Create Manifest");
}

void test_param_full_set_image(void)
{
    char *pArgv[] = {"cmd", "full", "-image="IMAGE_FILE };
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("Image file to be hashed:");
    assert_string_eq(GetImageInputFile(), IMAGE_FILE);
}

void test_param_full_set_image_no_file(void)
{
    char *pArgv[] = {"cmd", "full", "-image="IMAGE_FILE".blah" };
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("The image file doesn't exist");
    assert_string_eq(GetImageInputFile(), NULL);
}

void test_param_full_set_oem_data(void)
{
    char *pArgv[] = {"cmd", "full", "-oem="OEM_FILE };
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("OEM Data File:");
    assert_string_eq(GetOemDataFile(), OEM_FILE);
}

void test_param_full_set_oem_data_no_file(void)
{
    char *pArgv[] = {"cmd", "full", "-oem="OEM_FILE".blah" };
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("The OEM data file doesn't exist");
    assert_string_eq(GetOemDataFile(), NULL);
}

void test_param_full_set_oem_data_too_big(void)
{
    char *pArgv[] = {"cmd", "full", "-oem="OEM_BIG_FILE };
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("OEM data file is too big");
    assert_string_eq(GetOemDataFile(), NULL);
}

void test_param_full_set_invalid_type(void)
{
    char *pArgv[] = {"cmd", "full", "-type=16"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    assert_equal(GetImageType(), -1);
    MemoryStreamContains("The requested type (16) is less");
    tear_down();

    setup();
    char *pArgv1[] = {"cmd", "full", "-type=-1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv1), 1);
    assert_equal(GetImageType(), -1);
    MemoryStreamContains("The requested type (-1) is less");
}

void test_param_full_set_secure_version_number(void)
{
    char *pArgv[] = {"cmd", "full", "-version=255"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    assert_equal(GetSecureVersion(), 255);
    MemoryStreamContains("Requested version:255");
    tear_down();

    setup();
    char *pArgv1[] = {"cmd", "full", "-version=1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_equal(GetSecureVersion(), 1);
    MemoryStreamContains("Requested version:1");
}

void test_param_full_set_invalid_secure_version_number(void)
{
    char *pArgv[] = {"cmd", "full", "-version=-1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    assert_equal(GetSecureVersion(), 0);
    MemoryStreamContains("The requested secured version");
    tear_down();

    setup();
    char *pArgv1[] = {"cmd", "full", "-version=256"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 1);
    assert_equal(GetSecureVersion(), 0);
    MemoryStreamContains("The requested secured version");
}

void test_param_full_set_public_key_index(void)
{
    char *pArgv1[] = {"cmd", "full", "-keyIndex=0"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_equal(GetPublicKeyIndex(), 0);
    MemoryStreamContains("Requested public key index:0");
    tear_down();

    setup();
    char *pArgv2[] = {"cmd", "full", "-keyIndex=9"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv2), pArgv2), 0);
    assert_equal(GetPublicKeyIndex(), 9);
    MemoryStreamContains("Requested public key index:9");
}

void test_param_full_set_invalid_public_key_index(void)
{
    char *pArgv1[] = {"cmd", "full", "-keyIndex=-1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 1);
    assert_equal(GetPublicKeyIndex(), -1);
    MemoryStreamContains("The requested public key index (-1)");
    tear_down();

    setup();
    char *pArgv2[] = {"cmd", "full", "-keyIndex=10"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv2), pArgv2), 1);
    assert_equal(GetPublicKeyIndex(), -1);
    MemoryStreamContains("The requested public key index (10)");
}

void test_param_full_list_types(void)
{
    char *pArgv[] = {"cmd", "full", "-list"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("0:App CPU Kernel");
    MemoryStreamContains("8:BIOS Stage 1");
    MemoryStreamDoesntContains("ERROR");
}

void test_param_full_set_private_key_no_file(void)
{
    char *pArgv[] = {"cmd", "full", "-private=" PRIVATE_RSA_KEY_FILE_NAME_1 ".blah"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("The private key doesn't exist");
    assert_string_eq(GetPrivateKeyFile(), NULL);
}

void test_param_full_set_private_key(void)
{
    char *pArgv[] = {"cmd", "full", "-private=" PRIVATE_RSA_KEY_FILE_NAME_1};
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("Private key:");
    assert_string_eq(GetPrivateKeyFile(), PRIVATE_RSA_KEY_FILE_NAME_1);
}

///////////////////////////////////////////////////////
// Decode
void test_param_decode_verify_command(void)
{
    char *pArgv1[] = {"cmd", "decode"};
    assert_equal(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_equal(GetCommand(), CommandDecode);
    MemoryStreamContains("Decode");
}

void test_param_decode_no_file(void)
{
    char *pArgv[] = {"cmd", "decode", "-f=" PUBLIC_RSA_KEY_FILE_NAME_1 ".blah"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("OS manifest file to decode doesn't exist");
    assert_string_eq(GetDecodeFile(), NULL);
}

void test_param_decode_set_file(void)
{
    char *pArgv[] = {"cmd", "decode", "-f=" PUBLIC_RSA_KEY_FILE_NAME_1};
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("Requesting decode");
    assert_string_eq(GetDecodeFile(), PUBLIC_RSA_KEY_FILE_NAME_1);
}

///////////////////////////////////////////////////////
void test_param_verify_create(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST};

    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    //assert_equal(IsCreateSet(), true);
    assert_string_eq(GetManifestFile(), CREATE_MANIFEST MANIFEST_FILE_EXTENSION);
    MemoryStreamContains("Create Manifest: " CREATE_MANIFEST MANIFEST_FILE_EXTENSION);
    MemoryStreamContains(CREATE_MANIFEST);
}

void test_param_verify_decode(void)
{
    char *pArgv[] = {"cmd", "-d=" DUMMY_MANIFEST};
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    assert_string_eq(GetDecodeFile(), DUMMY_MANIFEST);
    MemoryStreamContains("Requesting decompose");
}

void test_param_verify_no_create_and_decode(void)
{
    char *pArgv[] = {"cmd", "-d=" DUMMY_MANIFEST, "-c=" CREATE_MANIFEST};
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    assert_equal(VerifyParameters(), 1);
    //assert_equal(IsCreateSet(), false);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("Decode and Create must be set independently");
}

void test_param_verify_no_create_or_decode(void)
{
    char *pArgv[] = {"cmd"};
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    assert_equal(VerifyParameters(), 1);
    //assert_equal(IsCreateSet(), false);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("Decode or Create must be set");
}

void test_param_set_private_key_no_file(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-private=" PRIVATE_RSA_KEY_FILE_NAME_1 ".blah"};
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("The private key doesn't exist");
    assert_string_eq(GetPrivateKeyFile(), NULL);
}

void test_param_set_private_key(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-private=" PRIVATE_RSA_KEY_FILE_NAME_1};
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("Private key:");
    assert_string_eq(GetPrivateKeyFile(), PRIVATE_RSA_KEY_FILE_NAME_1);
}

void test_param_set_image(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-image="IMAGE_FILE };
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("Image file to be hashed:");
    assert_string_eq(GetImageInputFile(), IMAGE_FILE);
}

void test_param_set_image_no_file(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-image="IMAGE_FILE".blah" };
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("The image file doesn't exist");
    assert_string_eq(GetImageInputFile(), NULL);
}

void test_param_set_oem_data(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-oem="OEM_FILE };
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    MemoryStreamContains("OEM Data File:");
    assert_string_eq(GetOemDataFile(), OEM_FILE);
}

void test_param_set_oem_data_no_file(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-oem="OEM_FILE".blah" };
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("ERROR:");
    MemoryStreamContains("The OEM data file doesn't exist");
    assert_string_eq(GetOemDataFile(), NULL);
}

void test_param_set_oem_data_too_big(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-oem="OEM_BIG_FILE };
    assert_equal(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("OEM data file is too big");
    assert_string_eq(GetOemDataFile(), NULL);
}

void test_param_list_types(void)
{
    char *pArgv[] = {"cmd", "-list"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    MemoryStreamContains("0:App CPU Kernel");
    MemoryStreamContains("8:BIOS Stage 1");
    MemoryStreamDoesntContains("ERROR");
}

void test_param_set_type(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-type=8"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    assert_equal(GetImageType(), 8);
    MemoryStreamContains("8:BIOS Stage 1");
}

void test_param_set_invalid_type(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-type=16"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    assert_equal(GetImageType(), -1);
    MemoryStreamContains("The requested type (16) is less");
    tear_down();

    setup();
    char *pArgv1[] = {"cmd", "-c=" CREATE_MANIFEST, "-type=-1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv1), 1);
    assert_equal(GetImageType(), -1);
    MemoryStreamContains("The requested type (-1) is less");
}

void test_param_set_secure_version_number(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-version=255"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    assert_equal(GetSecureVersion(), 255);
    MemoryStreamContains("Requested version:255");
    tear_down();

    setup();
    char *pArgv1[] = {"cmd", "-c=" CREATE_MANIFEST, "-version=1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_equal(GetSecureVersion(), 1);
    MemoryStreamContains("Requested version:1");
}

void test_param_set_invalid_secure_version_number(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-version=-1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    assert_equal(GetSecureVersion(), 0);
    MemoryStreamContains("The requested secured version");
    tear_down();

    setup();
    char *pArgv1[] = {"cmd", "-c=" CREATE_MANIFEST, "-version=256"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 1);
    assert_equal(GetSecureVersion(), 0);
    MemoryStreamContains("The requested secured version");
}

void test_param_set_public_key_index(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-keyIndex=0"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 0);
    assert_equal(GetPublicKeyIndex(), 0);
    MemoryStreamContains("Requested public key index:0");
    tear_down();

    setup();
    char *pArgv1[] = {"cmd", "-c=" CREATE_MANIFEST, "-keyIndex=9"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 0);
    assert_equal(GetPublicKeyIndex(), 9);
    MemoryStreamContains("Requested public key index:9");
}

void test_param_set_invalid_public_key_index(void)
{
    char *pArgv[] = {"cmd", "-c=" CREATE_MANIFEST, "-keyIndex=-1"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv), pArgv), 1);
    assert_equal(GetPublicKeyIndex(), -1);
    MemoryStreamContains("The requested public key index (-1)");
    tear_down();

    setup();
    char *pArgv1[] = {"cmd", "-c=" CREATE_MANIFEST, "-keyIndex=10"};
    assert_equal_c(ParseParameters(LIST_LEN(pArgv1), pArgv1), 1);
    assert_equal(GetPublicKeyIndex(), -1);
    MemoryStreamContains("The requested public key index (10)");
}

test_suite_t* create_suite_parameters()
{
    test_suite_t *pSuite = test_suite_create("Parameters");
    test_suite_add_setup(pSuite, setup);
    test_suite_add_teardown(pSuite, tear_down);

    test_suite_add_test(pSuite, test_param_step1_verify_command);
    test_suite_add_test(pSuite, test_param_step1_verify_output_file);
    test_suite_add_test(pSuite, test_param_step1_set_image);
    test_suite_add_test(pSuite, test_param_step1_set_image_no_file);
    test_suite_add_test(pSuite, test_param_step1_set_oem_data);
    test_suite_add_test(pSuite, test_param_step1_set_oem_data_no_file);
    test_suite_add_test(pSuite, test_param_step1_set_oem_data_too_big);
    test_suite_add_test(pSuite, test_param_step1_set_type);
    test_suite_add_test(pSuite, test_param_step1_set_invalid_type);
    test_suite_add_test(pSuite, test_param_step1_set_secure_version_number);
    test_suite_add_test(pSuite, test_param_step1_set_invalid_secure_version_number);
    test_suite_add_test(pSuite, test_param_step1_set_public_key_index);
    test_suite_add_test(pSuite, test_param_step1_set_invalid_public_key_index);
    test_suite_add_test(pSuite, test_param_step1_list_types);

    test_suite_add_test(pSuite, test_param_step2_verify_command);
    test_suite_add_test(pSuite, test_param_step2_set_private_key_no_file);
    test_suite_add_test(pSuite, test_param_step2_set_private_key);

    test_suite_add_test(pSuite, test_param_step3_verify_command);
    test_suite_add_test(pSuite, test_param_step3_set_public_key_no_file);
    test_suite_add_test(pSuite, test_param_step3_set_public_key);
    test_suite_add_test(pSuite, test_param_step3_set_sig_no_file);
    test_suite_add_test(pSuite, test_param_step3_set_sig);
    test_suite_add_test(pSuite, test_param_step3_set_output_file);

    test_suite_add_test(pSuite, test_param_full_verify_command);
    test_suite_add_test(pSuite, test_param_full_verify_output_file);
    test_suite_add_test(pSuite, test_param_full_set_image);
    test_suite_add_test(pSuite, test_param_full_set_image_no_file);
    test_suite_add_test(pSuite, test_param_full_set_oem_data);
    test_suite_add_test(pSuite, test_param_full_set_oem_data_no_file);
    test_suite_add_test(pSuite, test_param_full_set_oem_data_too_big);
    test_suite_add_test(pSuite, test_param_full_set_invalid_type);
    test_suite_add_test(pSuite, test_param_full_set_secure_version_number);
    test_suite_add_test(pSuite, test_param_full_set_invalid_secure_version_number);
    test_suite_add_test(pSuite, test_param_full_set_public_key_index);
    test_suite_add_test(pSuite, test_param_full_set_invalid_public_key_index);
    test_suite_add_test(pSuite, test_param_full_list_types);
    test_suite_add_test(pSuite, test_param_full_set_private_key_no_file);
    test_suite_add_test(pSuite, test_param_full_set_private_key);

    test_suite_add_test(pSuite, test_param_decode_verify_command);
    test_suite_add_test(pSuite, test_param_decode_no_file);
    test_suite_add_test(pSuite, test_param_decode_set_file);
    /*
    test_suite_add_test(pSuite, test_param_verify_decode);
    test_suite_add_test(pSuite, test_param_verify_create);
    test_suite_add_test(pSuite, test_param_verify_no_create_and_decode);
    test_suite_add_test(pSuite, test_param_verify_no_create_or_decode);
    test_suite_add_test(pSuite, test_param_set_private_key_no_file);
    test_suite_add_test(pSuite, test_param_set_private_key);
    test_suite_add_test(pSuite, test_param_set_image);
    test_suite_add_test(pSuite, test_param_set_image_no_file);
    test_suite_add_test(pSuite, test_param_set_oem_data);
    test_suite_add_test(pSuite, test_param_set_oem_data_no_file);
    test_suite_add_test(pSuite, test_param_set_oem_data_too_big);
    test_suite_add_test(pSuite, test_param_list_types);
    test_suite_add_test(pSuite, test_param_set_type);
    test_suite_add_test(pSuite, test_param_set_invalid_type);
    test_suite_add_test(pSuite, test_param_set_secure_version_number);
    test_suite_add_test(pSuite, test_param_set_invalid_secure_version_number);
    test_suite_add_test(pSuite, test_param_set_public_key_index);
    test_suite_add_test(pSuite, test_param_set_invalid_public_key_index);
    */
    return pSuite;
}
