/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "files.h"
#include "log.h"

#include <stdio.h>
#include <errno.h>
#include <stdbool.h>
#include <string.h>
#include <sys/stat.h>

static void* FileLoad(char *pFileName, bool isText);

int FileExists(char *pFileName)
{
    int ret = 0;
    struct stat st;

    // If it exists and is a regular file
    if (stat(pFileName, &st) == 0 && S_ISREG(st.st_mode))
        ret = 1;

    return ret;
}

void* FileLoadTxt(char *pFileName)
{
    return FileLoad(pFileName, true);
}

void* FileLoadBin(char *pFileName)
{
    return FileLoad(pFileName, false);
}

static void* FileLoad(char *pFileName, bool isText)
{
    char *pStr = NULL;
    int size;
    FILE *pFile = NULL;

    if (!FileExists(pFileName))
    {
        ERR("Attempting to load a non-existent file:%s\n", pFileName);
        goto error;
    }

    size = FileSize(pFileName);
    // Add room for a null character for strings
    pStr = calloc(isText ? size+1 : size, 1);
    ASSERT(pStr != NULL, "calloc returned a NULL pointer. Size:%d\n", size);

    if (FileLoadIntoBuffer(pFileName, (uchar*)pStr, size) != 0)
        goto error;

    goto exit;

error:
    if (pStr)
        free(pStr);
    pStr = NULL;

exit:
    if (pFile)
        fclose(pFile);
    return pStr;
}

int FileLoadIntoBuffer(char *pFileName, void *pBuffer, int bufferSize)
{
    int ret = 0;
    int bytes;
    FILE *pFile = NULL;

    if (!FileExists(pFileName))
    {
        ERR("Attempting to load a non-existent file:%s\n", pFileName);
        goto error;
    }

    pFile = fopen(pFileName, "rb");
    if (!pFile)
    {
        ERR("Unable to open the file for reading:%s\n", pFileName);
        goto error;
    }

    if ((bytes = fread(pBuffer, 1, bufferSize, pFile)) != bufferSize)
    {
        ERR("Unable to read the file:%s bytesRead:%d != bufferSize:%d\n", 
            pFileName, bytes, bufferSize);
        goto error;
    }
    goto exit;

error:
    ret = 1;
exit:
    if (pFile)
        fclose(pFile);
    return ret;
}

int FileSize(char *pFileName)
{
    int ret = -1;
    struct stat st;

    // If it exists and is a regular file
    if (stat(pFileName, &st) == 0 && S_ISREG(st.st_mode))
        ret = st.st_size;

    return ret;
}

int FileWrite(char *pFileName, void *pBuffer, int bufferSize)
{
    int ret = 0;
    FILE *pFile = NULL;

    pFile = fopen(pFileName, "wb");
    if (!pFile)
    {
        int err = errno;
        ERR("Failed to open the file to write.\nFile:%s\nerrno:%d:%s\n",
                pFileName, err, strerror(err));
        goto error;
    }

    size_t len;
    len = fwrite(pBuffer, bufferSize, 1, pFile);
    if (len != 1)
    {
        int err = errno;
        ERR("Failed to write the file.\nFile:%s\nNum elements written:%d\nerrno:%d:%s\n",
                pFileName, (int)len, err, strerror(err));
        goto error;
    }

    goto exit;
error:
    ret = 1;
exit:
    if (pFile)
        fclose(pFile);
    return ret;
}
