/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __FILES_H__
#define __FILES_H__

#include "manifest.h"

int FileExists(char *pFileName);
void* FileLoadTxt(char *pFileName);
void* FileLoadBin(char *pFileName);
int FileLoadIntoBuffer(char *pFileName, void *pBuffer, int bufferSize);
int FileSize(char *pFileName);
int FileWrite(char *pFileName, void *pBuffer, int bufferSize);


#endif
