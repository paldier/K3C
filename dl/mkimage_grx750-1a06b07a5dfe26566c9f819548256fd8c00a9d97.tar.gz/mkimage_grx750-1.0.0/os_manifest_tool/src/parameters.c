/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "files.h"
#include "log.h"
#include "parameters.h"
#include "utilities.h"

#include <linux/limits.h>
#include <stdlib.h>
#include <string.h>

char* GetStringAfterEquals(const char *pStr);
int IfStartsWith(char *pStr, char *pSubStr);
void ResetGlobals(void);
static char* GetCommandStr(command_t command);

static void SetUnsignedManifestFile(char *pFileName);
static void SetManifestFile(char *pFileName);
static void SetCommand(int val);
static void SetDecodeFile(char *pFileName);
static void SetImageInputFile(char *pFile);
static void SetImageType(int type);
static void SetOemDataFile(char *pFile);
static void SetPrivateKeyFile(char *pFile);
static void SetPublicKeyFile(char *pFile);
static void SetPublicKeyIndex(int index);
static void SetSecureVersion(int type);
static void SetSignatureFile(char *pFile);

static int ParseArgManifestOutput(char *arg);
static int ParseArgDecode(char *arg, int *pError);
static int ParseArgSig(char *arg, int *pError);
static int ParseArgPublic(char *arg, int *pError);
static int ParseArgPrivate(char *arg, int *pError);
static int ParseArgList(char *arg, int *pError);
static int ParseArgKeyIndex(char *arg, int *pError);
static int ParseArgVersion(char *arg, int *pError);
static int ParseArgType(char *arg, int *pError);
static int ParseArgOem(char *arg, int *pError);
static int ParseArgImage(char *arg, int *pError);
static int ParseArgUnsignedManifest(char *arg);
static int ParseCommand(int argc, char *argv[]);

void PrintVersionInformation()
{
    RAW_INFO("Current version: 2.1.1\n");
    RAW_INFO("\n");
    RAW_INFO("2.1.1:\n");
    RAW_INFO("  - Added v1 OS manifest ($OSM) to allow decoding of v1 manifests\n");
    RAW_INFO("2.1:\n");
    RAW_INFO("  - Switched to new v2 OS manifest identifier ($KFM)\n");
    RAW_INFO("2.0:\n");
    RAW_INFO("  - Split the manifest creation into multiple phases to accomodate\n");
    RAW_INFO("    a seperate HW signer\n");
    RAW_INFO("1.0:\n");
    RAW_INFO("  - Added ability to create OS manifests\n");
}

void usage(char *pArgv[])
{
    PrintVersionInformation();
    RAW_INFO("\n");
    RAW_INFO("-----------------------------\n");
    RAW_INFO("-- HELP MESSAGE -------------\n");
    RAW_INFO("-----------------------------\n");
    RAW_INFO("\n");
    if (pArgv)
        RAW_INFO("Application:%s\n", pArgv[0]);
    RAW_INFO("  This application creates or decodes OS manifest files.\n");
    RAW_INFO("  Usage:\n");
    RAW_INFO("    %s <Command> <options_for_command>\n", pArgv ? pArgv[0] : "app");
    RAW_INFO("  The first option is the command. Options are command specific.\n");
    RAW_INFO("  Command list:\n");
    RAW_INFO("     \"step1\" or \"generate_unsigned_manifest\"\n");
    RAW_INFO("     \"step2\" or \"generate_signature\"\n");
    RAW_INFO("     \"step3\" or \"attach_signature_to_unsigned_manifest\"\n");
    RAW_INFO("     \"full\"   <- Performs all three steps\n");
    RAW_INFO("     \"decode\" <- Decodes a OS manifest\n");
    RAW_INFO("  Step1/generate_unsigned_manifest:\n");
    RAW_INFO("    Takes in the binary partition file to be signed, the type of partition,\n");
    RAW_INFO("    and the key slot in the BIOS that represents the key. It will produce\n");
    RAW_INFO("    a file that needs to be signed post-fixed with \".unsignedmanifest\".\n");
    RAW_INFO("  Step2/generate_signature:\n");
    RAW_INFO("    Takes in the unsigned manifest and a private key. It outputs the signature.\n");
    RAW_INFO("  Step3/attach_signature_to_unsigned_manifest:\n");
    RAW_INFO("    Takes in the unsigned manifest, the private/public key and the signature.\n");
    RAW_INFO("    It combines them into a completed OS manifest.\n");
    RAW_INFO("  Full:\n");
    RAW_INFO("    Performs all three steps. Useful for internal testing.\n");
    RAW_INFO("  Decode:\n");
    RAW_INFO("    Takes in a OS manifest with the image. Then decodes and prints out the information.\n");
    RAW_INFO("    It also verifies the image matches the internal hash of the binary partition.\n");

    RAW_INFO("\n");
    RAW_INFO(" Options step1/generate_unsigned_manifest:\n");
    RAW_INFO("  -u=<path_to_file>         - Name of unsigned manifest file to be created\n");
    RAW_INFO("  -image=<path_to_file>     - Location of the binary image to sign\n");
    RAW_INFO("  -oem=<path_to_file>       - Location of OEM Data file (Optional)\n");
    RAW_INFO("  -list                     - List all image types\n");
    RAW_INFO("  -type=<image_number>      - Image Type\n");
    RAW_INFO("  -version=<version_number> - The Secure Version Number (0-255)\n");
    RAW_INFO("  -keyIndex=<index_number>  - The Public Key Hash Index\n");
    RAW_INFO(" Options step2/generate_signature:\n");
    RAW_INFO("  -u=<path_to_file>         - Name of unsigned manifest file\n");
    RAW_INFO("  -private=<path_to_file>   - Location of Private PEM-formatted key\n");
    RAW_INFO("  -sig=<path_to_file>       - Name of Signature file to create\n");
    RAW_INFO(" Options step3/attach_signature_to_unsigned_manifest:\n");
    RAW_INFO("  -u=<path_to_file>         - Name of unsigned manifest file\n");
    RAW_INFO("  -public=<path_to_file>    - Location of Public or Private PEM-formatted key\n");
    RAW_INFO("  -sig=<path_to_file>       - Location of Signature\n");
    RAW_INFO("  -c=<path_to_output_file>  - Name of output OS manifest file\n");
    RAW_INFO(" Options \"full\":\n");
    RAW_INFO("  -image=<path_to_file>     - Location of the binary image to sign\n");
    RAW_INFO("  -private=<path_to_file>   - Location of Private PEM-formatted key\n");
    RAW_INFO("  -list                     - List all image types\n");
    RAW_INFO("  -type=<image_number>      - Image Type\n");
    RAW_INFO("  -oem=<path_to_file>       - Location of OEM Data file (Optional)\n");
    RAW_INFO("  -version=<version_number> - The Secure Version Number (0-255)\n");
    RAW_INFO("  -keyIndex=<index_number>  - The Public Key Hash Index\n");
    RAW_INFO("  -c=<path_to_output_file>  - Name of output OS manifest file\n");
    RAW_INFO(" Options \"decode\":\n");
    RAW_INFO("  -f=<path_to_osmanifest>   - Decode a file\n");
    RAW_INFO("  -image=<path_to_image>    - Verify the image related to the decoded manifest\n");
    RAW_INFO("\n");
    RAW_INFO("  -h                        - Prints this message\n");
}


int ParseParameters(int argc, char *argv[])
{
    int i, ret = 0;
    int errorVal = 0;
    command_t command;

    if (ParseCommand(argc, argv))
        goto error;

    command = GetCommand();

    switch(command)
    {
        case CommandStep1:
            for(i = 2 ; i < argc; i++)
            {
                if (ParseArgUnsignedManifest(argv[i]))    continue;
                if (ParseArgImage(argv[i], &errorVal))    continue;
                if (ParseArgOem(argv[i], &errorVal))      continue;
                if (ParseArgType(argv[i], &errorVal))     continue;
                if (ParseArgVersion(argv[i], &errorVal))  continue;
                if (ParseArgKeyIndex(argv[i], &errorVal)) continue;
                if (ParseArgList(argv[i], &errorVal))     continue;

                if (errorVal)
                    goto error;

                ERR("Unknown argument:%s:\n", argv[i]);
                usage(argv);
                goto error;
            }
            break;
        case CommandStep2:
            for(i = 2 ; i < argc; i++)
            {
                if (ParseArgUnsignedManifest(argv[i]))   continue;
                if (ParseArgPrivate(argv[i], &errorVal)) continue;
                if (ParseArgSig(argv[i], &errorVal))     continue;

                if (errorVal)
                    goto error;

                ERR("Unknown argument:%s:\n", argv[i]);
                usage(argv);
                goto error;
            }
            break;
        case CommandStep3:
            for(i = 2 ; i < argc; i++)
            {
                if (ParseArgUnsignedManifest(argv[i]))  continue;
                if (ParseArgPublic(argv[i], &errorVal)) continue;
                if (ParseArgSig(argv[i], &errorVal))    continue;
                if (ParseArgManifestOutput(argv[i]))    continue;

                if (errorVal)
                    goto error;

                ERR("Unknown argument:%s:\n", argv[i]);
                usage(argv);
                goto error;
            }
            break;
        case CommandFull:
            for(i = 2 ; i < argc; i++)
            {
                if (ParseArgImage(argv[i], &errorVal))    continue;
                if (ParseArgPrivate(argv[i], &errorVal)) continue;
                if (ParseArgList(argv[i], &errorVal))     continue;
                if (ParseArgType(argv[i], &errorVal))     continue;
                if (ParseArgOem(argv[i], &errorVal))      continue;
                if (ParseArgVersion(argv[i], &errorVal))  continue;
                if (ParseArgKeyIndex(argv[i], &errorVal)) continue;
                if (ParseArgManifestOutput(argv[i]))    continue;

                if (errorVal)
                    goto error;

                ERR("Unknown argument:%s:\n", argv[i]);
                usage(argv);
                goto error;
            }
            break;
        case CommandDecode:
            for(i = 2 ; i < argc; i++)
            {
                if (ParseArgDecode(argv[i], &errorVal))    continue;
                if (ParseArgImage(argv[i], &errorVal))    continue;

                if (errorVal)
                    goto error;

                ERR("Unknown argument:%s:\n", argv[i]);
                usage(argv);
                goto error;
            }
            break;
    }
    goto exit;
error:
    // TODO: Fix this
    ret = errorVal | 1;
exit:
    return ret;
}

static int ParseCommand(int argc, char *argv[])
{
    int ret = 0;
    char *pCommand;

    if (argc < 2)
    {
        ERR("Please specify the desired command\n");
        usage(argv);
        goto error;
    }

    pCommand = argv[1];
    if (IsStrEqual(pCommand, "step1") || IsStrEqual(pCommand, "generate_unsigned_manifest"))
        SetCommand(CommandStep1);
    else if (IsStrEqual(pCommand, "step2") || IsStrEqual(pCommand, "generate_signature"))
        SetCommand(CommandStep2);
    else if (IsStrEqual(pCommand, "step3") || IsStrEqual(pCommand, "attach_signature_to_unsigned_manifest"))
        SetCommand(CommandStep3);
    else if (IsStrEqual(pCommand, "full"))
        SetCommand(CommandFull);
    else if (IsStrEqual(pCommand, "decode"))
        SetCommand(CommandDecode);
    else if (IsStrEqual(pCommand, "-V"))
    {
        PrintVersionInformation();
        goto error;
    }
    else if (IsStrEqual(pCommand, "-h"))
    {
        usage(argv);
        goto error;
    }
    else
    {
        ERR("Unrecognized Command:%s\n", pCommand);
        goto error;
    }

    INFO("Command: %s\n", GetCommandStr(GetCommand()));
    goto exit;

error:
    ret = 1;
exit:
    return ret;
}

static char* GetCommandStr(command_t command)
{
    char *ret;
    switch(command)
    {
        case CommandStep1:  ret = "Step1/generate_unsigned_manifest";            break;
        case CommandStep2:  ret = "Step2/generate_signature";                    break;
        case CommandStep3:  ret = "Step3/attach_signature_to_unsigned_manifest"; break;
        case CommandFull:   ret = "Full";                                        break;
        case CommandDecode: ret = "Decode";                                      break;
        default:            ret = "UnknownCommand";                              break;
    }
    return ret;
}


static int ParseArgUnsignedManifest(char *arg)
{
    int ret = 0;
    if (IfStartsWith(arg, "-u="))
    {
        char *pFile = GetStringAfterEquals(arg);

        // Append file extension
        static char pTmp[PATH_MAX];
        strncpy(pTmp, pFile, sizeof(pTmp));
        if (GetCommand() == CommandStep1) 
            strcat(pTmp, UNSIGNED_MANIFEST_FILE_EXTENSION);
        SetUnsignedManifestFile(pTmp);

        if (GetCommand() == CommandStep3)
            INFO("Unsigned Manifest: %s\n", GetUnsignedManifestFile());
        else
            INFO("Create Unsigned Manifest: %s\n", GetUnsignedManifestFile());
        ret = 1;
    }
    return ret;
}

static int ParseArgImage(char *arg, int *pError)
{
    int ret = 0;
    if (IfStartsWith(arg, "-image="))
    {
        char *pFile = GetStringAfterEquals(arg);
        INFO("Image file to be hashed:%s\n", pFile);
        if (!FileExists(pFile))
        {
            ERR("The image file doesn't exist:%s\n", pFile);
            *pError = 1;
            goto error;
        }
        SetImageInputFile(pFile);
        ret = 1;
    }
error:
    return ret;
}

static int ParseArgOem(char *arg, int *pError)
{
    int ret = 0;
    if (IfStartsWith(arg, "-oem="))
    {
        char *pFile = GetStringAfterEquals(arg);
        INFO("OEM Data File:%s\n", pFile);
        if (!FileExists(pFile))
        {
            ERR("The OEM data file doesn't exist:%s\n", pFile);
            *pError = 1;
            goto error;
        }

        if (FileSize(pFile) > struct_member_size(manifest_input_t, oemData))
        {
            ERR("The OEM data file is too big. Max:%lu File:%d Name:%s\n", 
                    struct_member_size(manifest_input_t, oemData),
                    FileSize(pFile), pFile);
            *pError = 1;
            goto error;
        }
        SetOemDataFile(pFile);
        ret = 1;
    }

error:
    return ret;
}

static int ParseArgType(char *arg, int *pError)
{
    int ret = 0;
    if (IfStartsWith(arg, "-type="))
    {
        char *pInt = GetStringAfterEquals(arg);
        int type = atoi(pInt);
        if (type < 0 || type > MAX_MANIFEST_TYPES  )
        {
            ERR("The requested type (%d) is less than min(%d) or larger than max(%d)\n", 
                type, 0, MAX_MANIFEST_TYPES);
            *pError = 1;
            goto error;
        }
        INFO("Requested type:%d:%s\n", type, GetManifestTypeString(type));
        SetImageType(type);
        ret = 1;
    }
error:
    return ret;
}

static int ParseArgVersion(char *arg, int *pError)
{
    int ret = 0;
    if (IfStartsWith(arg, "-version="))
    {
        char *pInt = GetStringAfterEquals(arg);
        int version = atoi(pInt);
        if (version < 0 || version > MAX_SECURE_VERSION)
        {
            ERR("The requested secured version (%d) is less than min(%d) or "
                "larger than max(%d)\n", version, 0, MAX_SECURE_VERSION);
            *pError = 1;
            goto error;
        }
        INFO("Requested version:%d\n", version);
        SetSecureVersion(version);
        ret = 1;
    }
error:
    return ret;
}

static int ParseArgKeyIndex(char *arg, int *pError)
{
    int ret = 0;
    if (IfStartsWith(arg, "-keyIndex="))
    {
        char *pInt = GetStringAfterEquals(arg);
        int index = atoi(pInt);
        if (index < 0 || index > MAX_PUBLIC_KEY_INDEX)
        {
            ERR("The requested public key index (%d) is less than min(%d) or "
                "larger than max(%d)\n", index, 0, MAX_PUBLIC_KEY_INDEX);
            *pError = 1;
            goto error;
        }
        INFO("Requested public key index:%d\n", index);
        SetPublicKeyIndex(index);
        ret = 1;
    }
error:
    return ret;
}

static int ParseArgList(char *arg, int *pError)
{
    if (IfStartsWith(arg, "-list"))
    {
        PrintManifestTypes();
        *pError = 1;
    }

    // Always return zero so that we can fall out.
    return 0;
}

static int ParseArgPrivate(char *arg, int *pError)
{
    int ret = 0;
    if (IfStartsWith(arg, "-private="))
    {
        char *pFile = GetStringAfterEquals(arg);
        INFO("Private key:%s\n", pFile);
        if (!FileExists(pFile))
        {
            ERR("The private key doesn't exist:%s\n", pFile);
            *pError = 1;
            goto error;
        }
        SetPrivateKeyFile(pFile);
        ret = 1;
    }
error:
    return ret;
}

static int ParseArgPublic(char *arg, int *pError)
{
    int ret = 0;
    if (IfStartsWith(arg, "-public="))
    {
        char *pFile = GetStringAfterEquals(arg);
        INFO("Public key:%s\n", pFile);
        if (!FileExists(pFile))
        {
            ERR("The public key doesn't exist:%s\n", pFile);
            *pError = 1;
            goto error;
        }
        SetPublicKeyFile(pFile);
        ret = 1;
    }
error:
    return ret;
}

static int ParseArgSig(char *arg, int *pError)
{
    int ret = 0;
    if (IfStartsWith(arg, "-sig="))
    {
        char *pFile = GetStringAfterEquals(arg);
        INFO("Signature file:%s\n", pFile);
        if (GetCommand() == CommandStep2)
        {
            // Append file extension
            static char pTmp[PATH_MAX];
            strncpy(pTmp, pFile, sizeof(pTmp));
            strcat(pTmp, SIGNATURE_FILE_EXTENSION);
            SetSignatureFile(pTmp);
        }
        if (GetCommand() == CommandStep3)
        {
            if (!FileExists(pFile))
            {
                ERR("The signature file doesn't exist:%s\n", pFile);
                *pError = 1;
                goto error;
            }
            SetSignatureFile(pFile);
        }
        ret = 1;
    }
error:
    return ret;
}

static int ParseArgDecode(char *arg, int *pError)
{
    int ret = 0;
    if (IfStartsWith(arg, "-f="))
    {
        char *pFile = GetStringAfterEquals(arg);
        INFO("Requesting decode\n");
        if (!FileExists(pFile))
        {
            ERR("The requested OS manifest file to decode doesn't exist:%s\n", pFile);
            *pError = 1;
            goto error;
        }
        SetDecodeFile(pFile);
        ret = 1;
    }
error:
    return ret;
}

static int ParseArgManifestOutput(char *arg)
{
    int ret = 0;
    if (IfStartsWith(arg, "-c="))
    {
        char *pFile = GetStringAfterEquals(arg);

        // Append file extension
        char pTmp[PATH_MAX];
        strncpy(pTmp, pFile, sizeof(pTmp));
        strcat(pTmp, MANIFEST_FILE_EXTENSION);
        SetManifestFile(pTmp);

        INFO("Create Manifest: %s\n", GetManifestFile());
        ret = 1;
    }
    return ret;
}


int VerifyParameters(void)
{
    int ret = 0;

    // Look for mandatory options
    switch(GetCommand())
    {
        case CommandStep1:
            if (GetUnsignedManifestFile() == NULL)
            {
                INFO("No output unsigned manifest file specified\n");
                ret = 1;
            }
            if (GetImageInputFile() == NULL)
            {
                INFO("No image file specified\n");
                ret = 1;
            }
            if (GetImageType() == -1)
            {
                INFO("No image type specified\n");
                ret = 1;
            }
            if (GetPublicKeyIndex() == -1)
            {
                INFO("No public key index specified\n");
                ret = 1;
            }
            break;
        case CommandStep2:
            if (GetUnsignedManifestFile() == NULL)
            {
                INFO("No output unsigned manifest file specified\n");
                ret = 1;
            }
            if (GetPrivateKeyFile() == NULL)
            {
                INFO("No private key specified\n");
                ret = 1;
            }
            if (GetSignatureFile() == NULL)
            {
                INFO("No signature file specified\n");
                ret = 1;
            }
            break;
        case CommandStep3:
            if (GetManifestFile() == NULL)
            {
                INFO("No output manifest file specified\n");
                ret = 1;
            }
            if (GetUnsignedManifestFile() == NULL)
            {
                INFO("No input unsigned manifest file specified\n");
                ret = 1;
            }
            if (GetPublicKeyFile() == NULL)
            {
                INFO("No public key specified\n");
                ret = 1;
            }
            if (GetSignatureFile() == NULL)
            {
                INFO("No signature file specified\n");
                ret = 1;
            }
            break;
        case CommandFull:
            if (GetManifestFile() == NULL)
            {
                INFO("No output manifest file specified\n");
                ret = 1;
            }
            if (GetImageInputFile() == NULL)
            {
                INFO("No image file specified\n");
                ret = 1;
            }
            if (GetImageType() == -1)
            {
                INFO("No image type specified\n");
                ret = 1;
            }
            if (GetPublicKeyIndex() == -1)
            {
                INFO("No public key index specified\n");
                ret = 1;
            }
            if (GetPrivateKeyFile() == NULL)
            {
                INFO("No private key specified\n");
                ret = 1;
            }
            break;
        case CommandDecode:
            if (GetDecodeFile() == NULL)
            {
                INFO("No decode file specified\n");
                ret = 1;
            }
            break;
    }

    if (ret == 1)
    {
        ResetGlobals();
        usage(NULL);
    }
    return ret;
}

int IfStartsWith(char *pStr, char *pSubStr)
{
    int ret = 0;
    if (strncmp(pStr, pSubStr, strlen(pSubStr)) == 0)
    {
        ret = 1;
    }
    return ret;
}

char* GetStringAfterEquals(const char *pStr)
{
    char *pSubStr = strchr(pStr, '=');
    ASSERT(pSubStr != NULL, "There was no '=' in the string. Str:%s:\n", pStr);

    // Skip the equal character
    pSubStr++;

    return pSubStr;
}

void ResetGlobals(void)
{
    SetUnsignedManifestFile(NULL);
    SetCommand(-1);
    SetDecodeFile(NULL);
    SetManifestFile(NULL);
    SetPrivateKeyFile(NULL);
    SetPublicKeyFile(NULL);
    SetImageInputFile(NULL);
    SetOemDataFile(NULL);
    SetImageType(-1);
    SetSecureVersion(0);
    SetPublicKeyIndex(-1);
    SetLogLevel(LOG_LEVEL_NORMAL);
}

//////////////////////////////////////////////////////////
// Globals and their accessors
#define DEFINE_GETTER_SETTER_STR(VarName) \
static char *gp##VarName = NULL;          \
static void Set##VarName(char *pStr)      \
{                                         \
    if (gp##VarName)                      \
        free(gp##VarName);                \
    if (pStr)                             \
        gp##VarName = strdup(pStr);       \
    else                                  \
        gp##VarName = NULL;               \
}                                         \
char* Get##VarName(void)                  \
{                                         \
    return gp##VarName;                   \
}
DEFINE_GETTER_SETTER_STR(DecodeFile)
DEFINE_GETTER_SETTER_STR(PrivateKeyFile)
DEFINE_GETTER_SETTER_STR(PublicKeyFile)
DEFINE_GETTER_SETTER_STR(ImageInputFile)
DEFINE_GETTER_SETTER_STR(OemDataFile)
DEFINE_GETTER_SETTER_STR(SignatureFile)
DEFINE_GETTER_SETTER_STR(ManifestFile)
DEFINE_GETTER_SETTER_STR(UnsignedManifestFile);

#define DEFINE_GETTER_SETTER_INT(VarName) \
static int g##VarName = -1;               \
static void Set##VarName(int val)         \
{                                         \
    g##VarName = val;                     \
}                                         \
int Get##VarName(void)                    \
{                                         \
    return g##VarName;                    \
}
DEFINE_GETTER_SETTER_INT(ImageType)
DEFINE_GETTER_SETTER_INT(SecureVersion)
DEFINE_GETTER_SETTER_INT(PublicKeyIndex)
DEFINE_GETTER_SETTER_INT(Command)

