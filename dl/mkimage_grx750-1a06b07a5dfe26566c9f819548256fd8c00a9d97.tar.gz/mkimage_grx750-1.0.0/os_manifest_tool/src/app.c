/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#include "parameters.h"
#include "manifest.h"
#include "utilities.h"
#include "files.h"
#include "log.h"

#include <stdio.h>
#include <string.h>

int PerformStep1GenerateUnsignedManifest(os_signed_t **ppUnsignedManifest);

int main(int argc, char *argv[])
{
    int ret = 0;

    if (ParseParameters(argc, argv))
        goto error;

    if (VerifyParameters())
        goto error;

    switch(GetCommand())
    {
    case CommandStep1:
        {
            os_signed_t *pUnsignedManifest = NULL;
            if (PerformStep1GenerateUnsignedManifest(&pUnsignedManifest))
                goto error;

            if (FileWrite(GetUnsignedManifestFile(), pUnsignedManifest, sizeof(os_signed_t)))
                goto error;

            INFO("Unsigned Manifest successfully created");
        }
        break;
    case CommandStep2:
        {
            uchar pSignature[struct_member_size(os_unsigned_t, manifestSignature)];
            os_signed_t *pToSign = FileLoadBin(GetUnsignedManifestFile());
            if (!pToSign)
            {
                ERR("Failed loading the file:%s\n", GetUnsignedManifestFile());
                goto error;
            }

            if (GenerateSignature(GetPrivateKeyFile(), pToSign, pSignature))
                goto error;

            if (FileWrite(GetSignatureFile(), pSignature, sizeof(pSignature)))
                goto error;

            INFO("Signature successfully created");
        }
        break;
    case CommandStep3:
        {
            manifest_output_t *pManifest = NULL;
            os_signed_t *pUnsignedManifest = FileLoadBin(GetUnsignedManifestFile());
            uchar *pSignature = FileLoadTxt(GetSignatureFile());

            if (!pSignature)
            {
                ERR("Failed reading the signature file:%s\n", GetSignatureFile());
                goto error;
            }

            if (!pUnsignedManifest)
            {
                ERR("Failed reading the unsigned manifest file:%s\n", GetUnsignedManifestFile());
                goto error;
            }

            if (strncmp(pUnsignedManifest->manifestIdentifier, MANIFEST_IDENTIFIER_V2, MANIFEST_IDENTIFIER_LEN) != 0)
            {
                ERR("The specified unsigned manifest file does not have the "
                    "appropriate header and is considered corrupt:%s\n", GetUnsignedManifestFile());
                goto error;
            }

            if (JoinManifest(pSignature, GetPublicKeyFile(), PublicKey, pUnsignedManifest, &pManifest))
                goto error;

            if (VerifyManifestSignature(pManifest))
                goto error;

            if (FileWrite(GetManifestFile(), pManifest, sizeof(manifest_output_t)))
                goto error;

            INFO("Manifest successfully created");
        }
        break;
    case CommandFull:
        {
            manifest_output_t *pManifest = NULL;
            os_signed_t *pUnsignedManifest = NULL;
            uchar pSignature[struct_member_size(os_unsigned_t, manifestSignature)];

            if (PerformStep1GenerateUnsignedManifest(&pUnsignedManifest))
                goto error;

            if (GenerateSignature(GetPrivateKeyFile(), pUnsignedManifest, pSignature))
                goto error;

            if (JoinManifest(pSignature, GetPrivateKeyFile(), PrivateKey, pUnsignedManifest, &pManifest))
                goto error;

            if (VerifyManifestSignature(pManifest))
                goto error;

            if (FileWrite(GetManifestFile(), pManifest, sizeof(manifest_output_t)))
                goto error;
        }
        break;
    case CommandDecode:
        {
            char *pFileName = GetDecodeFile();
            manifest_output_t *pManifest = FileLoadBin(pFileName);
            PrintManifest(pManifest);
            if (VerifyManifestSignature(pManifest))
                goto error;
            if (GetImageInputFile() && VerifyManifestImageHash(pManifest, GetImageInputFile()))
                goto error;
        }
        break;
    }
    goto exit;

error:
    ret = 1;
exit:
    return ret;
}

int PerformStep1GenerateUnsignedManifest(os_signed_t **ppUnsignedManifest)
{
    int ret = 0;
    manifest_input_t *pInput    = CreateInputStruct();
    pInput->pImage              = FileLoadBin(GetImageInputFile());
    pInput->imageSize           = FileSize(GetImageInputFile());
    pInput->secureVersionNumber = GetSecureVersion();
    pInput->publicKeyHashIndex  = GetPublicKeyIndex();
    pInput->osManifestType      = GetImageType();

    if (GetOemDataFile() 
     && FileLoadIntoBuffer(GetOemDataFile(), pInput->oemData, sizeof(pInput->oemData)))
        goto error;

    if (GenerateUnsignedManifest(pInput, ppUnsignedManifest))
        goto error;

    goto exit;

error:
    ret = 1;
exit:
    if (pInput)
    {
        if (pInput->pImage)
            free(pInput->pImage);
        DestroyInputStruct(pInput);
        pInput = NULL;
    }
    return ret;
}
