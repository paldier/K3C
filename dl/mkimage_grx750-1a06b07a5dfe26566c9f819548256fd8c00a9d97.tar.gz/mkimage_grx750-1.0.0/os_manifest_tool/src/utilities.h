/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __UTILITIES_H__
#define __UTILITIES_H__

#include "manifest.h"

// The following gets the size of a structural member.
#define struct_member_size(type, member) (sizeof(((type*)0)->member))

#define MAX_MANIFEST_TYPES  15

manifest_input_t* CreateInputStruct(void);
void DestroyInputStruct(manifest_input_t *pInput);

char* GetManifestTypeString(int type);

void SwapEndianness(char *pString, int length);

void PrintManifest(manifest_output_t *pManifest);
void PrintManifestTypes(void);

char* Bin2HexStr(void *pBuffer, int bufferSize);

int IsStrEqual(char *pStr1, char *pStr2);
#endif
