/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __LOG_H_
#define __LOG_H_

#include <assert.h>
#include <stdio.h>

// The following macros are to be the only printing done in the entire app. 
// This allows all of the output to be captured by the tests.

// Prints out message without any extra output.
#define RAW_INFO(msg, ...)                                                    \
do                                                                            \
{                                                                             \
    if (GetLogLevel() >= LOG_LEVEL_NORMAL)                                    \
    {                                                                         \
        fprintf(GetLogFilePointer(), msg, ##__VA_ARGS__);                     \
    }                                                                         \
} while(0)

// Adds a small prefix to each output
#define INFO(msg, ...)                                                        \
do                                                                            \
{                                                                             \
    if (GetLogLevel() >= LOG_LEVEL_NORMAL)                                    \
    {                                                                         \
        fprintf(GetLogFilePointer(), " - " msg, ##__VA_ARGS__);               \
    }                                                                         \
} while(0)

// Prints out relevant location information
#define ERR(msg, ...)                                                         \
do                                                                            \
{                                                                             \
    if (GetLogLevel() >= LOG_LEVEL_NORMAL)                                    \
    {                                                                         \
        fprintf(GetLogFilePointer(), "ERROR:\n");                             \
        fprintf(GetLogFilePointer(), " - %s():%d:%s\n", __FUNCTION__, __LINE__, __FILE__); \
        fprintf(GetLogFilePointer(), " - " msg, ##__VA_ARGS__);               \
    }                                                                         \
} while(0)

// Prints out relevant location information
#define ASSERT(test, msg, ...)                                                \
do                                                                            \
{                                                                             \
    if (!(test))                                                              \
    {                                                                         \
        fprintf(stderr, "ASSERT-ERROR:\n");                      \
        fprintf(stderr, " - %s():%d:%s\n", __FUNCTION__, __LINE__, __FILE__); \
        fprintf(stderr, " - " msg, ##__VA_ARGS__);               \
        assert(test);                                                         \
    }                                                                         \
} while(0)

typedef enum 
{
    LOG_LEVEL_NONE   = 1,
    LOG_LEVEL_NORMAL = 2,
    LOG_LEVEL_DEBUG  = 3,

    LOG_LEVEL_MIN = LOG_LEVEL_NONE,
    LOG_LEVEL_MAX = LOG_LEVEL_DEBUG,
} loglevel_t;

void SetLogLevel(loglevel_t level);
loglevel_t GetLogLevel(void);
void SetLogFilePointer(FILE *pStreamFile);
FILE* GetLogFilePointer(void);

#endif
