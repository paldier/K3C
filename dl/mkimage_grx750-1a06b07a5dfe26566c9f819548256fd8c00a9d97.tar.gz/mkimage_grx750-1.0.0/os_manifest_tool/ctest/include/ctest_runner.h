/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __CTEST_RUNNER_H__
#define __CTEST_RUNNER_H__

typedef void (*TestFunction)(void);
typedef void (*SetupFunction)(void);
typedef void (*TearDownFunction)(void);

typedef enum expect_type_t
{
    EXPECT_VALUE,
    EXPECT_STRING,
} expect_type_t;

#endif //__CTEST_RUNNER_H__
