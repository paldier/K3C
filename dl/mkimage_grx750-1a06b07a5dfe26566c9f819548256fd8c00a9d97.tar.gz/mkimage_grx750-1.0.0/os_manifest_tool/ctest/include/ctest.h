/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __C_TEST_H__
#define __C_TEST_H__

#include <stdbool.h>
#include <stdint.h>

#include <ctest_runner.h>
#include <ctest_logger.h>

//-----------------------------------------------------------------------------
// Forward type declaractions
//-----------------------------------------------------------------------------

// Forward declaration of test_run_t
typedef struct test_run_t test_run_t;

// Forward declaration of test_suite_t
typedef struct test_suite_t test_suite_t;

//-----------------------------------------------------------------------------
// Test Run/Suite/Adding functions
//-----------------------------------------------------------------------------

// Creates an empty test run.
test_run_t* test_run_create();

// Creates an empty test suite.
test_suite_t* test_suite_create(const char* suite_name);

// Add a setup function that runs before each test in the suite
void test_suite_add_setup(test_suite_t *suite, SetupFunction func);
// Add a teardown function that runs after each test in the suite
void test_suite_add_teardown(test_suite_t *suite, TearDownFunction func);

// Add a test to the test suite.
#define test_suite_add_test(test_suite, test_func) \
        test_suite_add_test_(test_suite,           \
                             #test_func,           \
                             &test_func)

// Add a test_suite_t to a test_run_t
#define test_run_add_suite(test_run, suite) test_run_add_suite_(test_run, suite)

// Internally adds a test suite to a test run
void test_run_add_suite_(test_run_t *test_run,  test_suite_t *suite);
// Internally add a test to a test suite.
void test_suite_add_test_(test_suite_t *suite, const char *test_name, TestFunction func);

// Run all the tests
#define test_run_execute(test_run, style) test_run_execute_(test_run, NULL, style)
int test_run_execute_(test_run_t *test_run, 
                      const char *test_name,
                      log_style_t style);

// Run a single test.
int test_run_execute_single(test_run_t *test_run, 
                            const char* test_name, 
                            log_style_t style);

// Clean up all the memory from the test run.
void test_run_destroy(test_run_t *test_run);

// Enables/Disables debug printing. When enabled, all asserts are printed out.
void test_set_debug(bool debug);

//-----------------------------------------------------------------------------
// Assertions
//-----------------------------------------------------------------------------

// Reports whether the test that is running has failed.
bool has_test_failed(void);

// Report that the test has failed and terminate the test.
#define test_set_failed() test_set_failed_(__FUNCTION__, __FILE__, __LINE__, true)

// Report that the test has failed, but continue.
#define test_set_failed_c() test_set_failed_(__FUNCTION__, __FILE__, __LINE__, false)

// Internal function that reports that the test has failed.
bool test_set_failed_(const char* function, const char* file, int line, bool fail);

// Verifys that the "result" evaluates to true otherwise it fails and 
// terminates the test.
#define assert_true(result) assert_true_(result,          \
                                         true,            \
                                         __FUNCTION__,    \
                                         __FILE__,        \
                                         __LINE__)

// Verify the result, but don't terminate the test on failure. 
// Note: The test is logged as a failure.
#define assert_true_c(result) assert_true_(result,        \
                                           false,         \
                                           __FUNCTION__,  \
                                           __FILE__,      \
                                           __LINE__)

// Internal function that accepts a result and whether it should 
// continue or fail.
bool assert_true_(int         result, 
                  bool        fail, 
                  const char* function, 
                  const char* file, 
                  int         line);

// Verifies that the actual float value is in the range of the expected value.
// Terminates the test if it fails.
#define assert_equal_f(actual, expected, range)   \
     assert_equal_f_(actual,                      \
                     expected,                    \
                     range,                       \
                     true,                        \
                     __FUNCTION__,                \
                     __FILE__,                    \
                     __LINE__)

// Verifies that the actual value matches the expected value. Terminates the
// test if it fails.
#define assert_flag_set(actual, expected) assert_equal_flag_set_(actual,       \
                                                                 expected,     \
                                                                 #expected,    \
                                                                 true,         \
                                                                 __FUNCTION__, \
                                                                 __FILE__,     \
                                                                 __LINE__)

// Verifies that the actual value matches the expected value. Terminates the
// test if it fails.
#define assert_flag_unset(actual, expected) assert_equal_flag_unset_(actual,       \
                                                                     expected,     \
                                                                     #expected,    \
                                                                     true,         \
                                                                     __FUNCTION__, \
                                                                     __FILE__,     \
                                                                     __LINE__)

// Verifies that the actual value matches the expected value. Continues the
// test if it fails.
#define assert_equal_c(actual, expected) assert_equal_(actual,         \
                                                       expected,       \
                                                       false,          \
                                                       __FUNCTION__,   \
                                                       __FILE__,       \
                                                       __LINE__)

// Verifies that the actual value matches the expected value. Terminates the
// test if it fails.
#define assert_equal(actual, expected)  assert_equal_(actual,             \
                                                      expected,           \
                                                      true,               \
                                                      __FUNCTION__,       \
                                                      __FILE__,           \
                                                      __LINE__)

// Verifies that the actual value matches the expected value. Continues the
// test if it fails.
#define assert_equal_c(actual, expected) assert_equal_(actual,         \
                                                       expected,       \
                                                       false,          \
                                                       __FUNCTION__,   \
                                                       __FILE__,       \
                                                       __LINE__)

// Verifies that the actual value matches the expected value.
// If fail is true, it terminates the test on failure.
bool assert_equal_(intptr_t   actual, 
                   intptr_t   expected,
                   bool        fail, 
                   const char* function, 
                   const char* file, 
                   int         line);

// Verifies that the actual float is in the range of the expected value. 
// If fail is true, it terminates the test on failure.
bool assert_equal_f_(double      actual, 
                     double      expected,
                     double      range,
                     bool        fail, 
                     const char* function, 
                     const char* file, 
                     int         line);

// Verifies that the expected flag is in the actual value.
// If fail is true, it terminates the test on failure.
bool assert_equal_flag_set_(intptr_t   actual, 
                            intptr_t   expected,
                            const char* flag_name,
                            bool        fail,
                            const char* function, 
                            const char* file, 
                            int         line);

// Verifies that the expected flag is not set in the actual value.
// If fail is true, it terminates the test on failure.
bool assert_equal_flag_unset_(intptr_t   actual, 
                              intptr_t   expected,
                              const char* flag_name,
                              bool        fail,
                              const char* function, 
                              const char* file, 
                              int         line);

// Verifies that the actual value matches the expected value.
// If fail is true, it terminates the test on failure.
bool assert_equal_(intptr_t   actual, 
                   intptr_t   expected,
                   bool        fail, 
                   const char* function, 
                   const char* file, 
                   int         line);

// Verifies that the strings are equal. Terminates the test on failure.
#define assert_string_eq(actual, expected)                  \
        assert_string_eq_((const char*)actual,              \
                          (const char*)expected,            \
                          true,                             \
                          __FUNCTION__,                     \
                          __FILE__,                         \
                          __LINE__)

// Verifies that the strings are equal. Continues the test on failure.
#define assert_string_eq_c(actual, expected)                \
        assert_string_eq_((const char*)actual,              \
                          (const char*)expected,            \
                          false,                            \
                          __FUNCTION__,                     \
                          __FILE__,                         \
                          __LINE__)

// Internal function that verifies that the strings are equal.
bool assert_string_eq_(const char *actual, 
                       const char *expected, 
                       bool  fail, 
                       const char* function, 
                       const char* file, 
                       int         line);

// Verifies that the substring is contained in the main stream. Terminates the test on failure.
#define assert_substr(main, substr)                  \
        assert_substr_((const char*)main,            \
                       (const char*)substr,          \
                       true,                         \
                       __FUNCTION__,                 \
                       __FILE__,                     \
                       __LINE__)

// Verifies that the substring is contained in the main stream. Terminates the test on failure.
#define assert_substr_c(main, substr)                \
        assert_substr_((const char*)main,            \
                       (const char*)substr,          \
                       false,                        \
                       __FUNCTION__,                 \
                       __FILE__,                     \
                       __LINE__)

// Internal function that verifies that the substring is contained in the main stream.
bool assert_substr_(const char *main, 
                    const char *substr, 
                    bool  fail, 
                    const char* function, 
                    const char* file, 
                    int         line);

// Verifies that the substring is contained in the main stream. Terminates the test on failure.
#define assert_no_substr(main, substr)                  \
        assert_no_substr_((const char*)main,            \
                          (const char*)substr,          \
                          true,                         \
                          __FUNCTION__,                 \
                          __FILE__,                     \
                          __LINE__)

// Verifies that the substring is contained in the main stream. Terminates the test on failure.
#define assert_no_substr_c(main, substr)                \
        assert_no_substr_((const char*)main,            \
                          (const char*)substr,          \
                          false,                        \
                          __FUNCTION__,                 \
                          __FILE__,                     \
                          __LINE__)

// Internal function that verifies that the substring is contained in the main stream.
bool assert_no_substr_(const char *main, 
                       const char *substr, 
                       bool  fail, 
                       const char* function, 
                       const char* file, 
                       int         line);

//-----------------------------------------------------------------------------
// Mock Functions
//-----------------------------------------------------------------------------

// Stores the expected parameter and its value in the mock's parameter list.
// This will be retrieved when the check_expected function is called.
#define expect_value(function, parameter)        \
        expect_parameter_(#function,             \
                          #parameter,            \
                          EXPECT_VALUE,          \
                          parameter)

// Stores the expected parameter and its string in the mock's parameter list.
// This will be retrieved when the check_expected function is called.
#define expect_string(function, parameter)       \
        expect_parameter_(#function,             \
                          #parameter,            \
                          EXPECT_STRING,         \
                          (intptr_t)parameter)

// Internal function that stores the expected parameter.
void expect_parameter_(const char*   function,
                       const char*   parameter,
                       expect_type_t type,
                       intptr_t      value);

// Looks for the function, parameter in the mock's parameter list. If it finds it,
// it verifies the passed in parameter is correct. If it isn't it sets the test
// failed flag.
#define check_expected(parameter)                \
        check_expected_(__FUNCTION__,            \
                        #parameter,              \
                        (intptr_t)parameter,     \
                        __FILE__,                \
                        __LINE__)

// Internal function that validates the function/parameter pair with the value.
bool check_expected_(const char * function,
                     const char * parameter,
                     intptr_t     value,
                     const char * file,
                     int          line);

// Stores the return value in the mock's return list.
// This will be retrieved when the mock function is called.
#define will_return_value(function, value)    \
        will_return_(#function,               \
                     (intptr_t)value,         \
                     EXPECT_VALUE)

// Stores the return string in the mock's return list.
// This will be retrieved when the mock function is called.
#define will_return_string(function, value)        \
        will_return_(#function,                    \
                     (intptr_t)value,              \
                     EXPECT_STRING)

// Internal function that stores the function/value pair.
void will_return_(const char*   function,
                  intptr_t      value,
                  expect_type_t type);

// Returns the "return" value set by will_return_value/will_return_string.
#define mock()  mock_(__FUNCTION__)

// Internal function that returns the function/value pair.
intptr_t mock_(const char * function);

#endif // __C_TEST_H__
