/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

//*****************************************************************************
//  Includes
//*****************************************************************************
#include "logger.h"

//*****************************************************************************
//  Logger Functions
//*****************************************************************************
void quiet_run_start(test_run_t *run)
{
}

void quiet_run_finished(test_run_t *run, long long usecs)
{
    printf("Overall Pass:%d Failed:%d Time:", run->passed, run->failed);
    log_print_usecs(usecs);
    printf("\n");
}

void quiet_suite_start(test_suite_t *suite)
{
}

void quiet_suite_finished(test_suite_t *suite)
{
}

void quiet_test_start(test_suite_t *suite, unit_test_t *test)
{
}

void quiet_test_finished(test_suite_t *suite, unit_test_t *test)
{
}

void quiet_assert_fail(const char* function,
                       const char* file,
                       int         line)
{
}

void quiet_assert_true(bool        failed,
                       const char* function, 
                       const char* file,   
                       int         line)
{
}

void quiet_assert_string_eq(bool        failed,
                            const char *actual, 
                            const char *expected, 
                            const char* function, 
                            const char* file,   
                            int         line)
{
}

void quiet_assert_equal_f(bool        failed,
                          double      actual, 
                          double      expected,
                          double      range,
                          const char* function, 
                          const char* file, 
                          int         line)
{
}

void quiet_assert_equal_flag_set(bool       failed,
                                 intptr_t   actual, 
                                 intptr_t   expected,
                                 const char* flag_name,
                                 const char* function, 
                                 const char* file, 
                                 int         line)
{
}

void quiet_assert_equal_flag_unset(bool       failed,
                                   intptr_t   actual, 
                                   intptr_t   expected,
                                   const char* flag_name,
                                   const char* function, 
                                   const char* file, 
                                   int         line)
{
}

void quiet_assert_equal(bool        failed,
                        intptr_t    actual, 
                        intptr_t    expected,
                        const char* function, 
                        const char* file, 
                        int         line)
{
}

void quiet_mock_param_remaining(const char   *function,
                                const char   *parameter,
                                expect_type_t type,
                                intptr_t      value)
{
}

void quiet_mock_return_remaining(const char   *function,
                                 expect_type_t type,
                                 intptr_t      value)
{
}

void quiet_mock_check(bool          failed, 
                      intptr_t      actual,
                      intptr_t      expected,
                      const char*   function,
                      const char*   parameter,
                      expect_type_t type)
{
}

void quiet_mock_get_return(intptr_t      return_val,
                           const char*   function,
                           expect_type_t type)
{
}

void quiet_logger_init(logger_t* logger)
{
    logger->log_run_start         = quiet_run_start;
    logger->log_run_finished      = quiet_run_finished;
    logger->log_suite_start       = quiet_suite_start;
    logger->log_suite_finished    = quiet_suite_finished;
    logger->log_test_start        = quiet_test_start;
    logger->log_test_finished     = quiet_test_finished;
    logger->log_assert_fail       = quiet_assert_fail;
    logger->log_assert_true       = quiet_assert_true;
    logger->log_assert_string_eq  = quiet_assert_string_eq;
    logger->log_assert_equal      = quiet_assert_equal;
    logger->log_assert_equal_f    = quiet_assert_equal_f;
    logger->log_assert_equal_flag_set   = quiet_assert_equal_flag_set;
    logger->log_assert_equal_flag_unset = quiet_assert_equal_flag_unset;
    logger->log_assert_equal      = quiet_assert_equal;
    logger->log_mock_param_remaining = quiet_mock_param_remaining;
    logger->log_mock_return_remaining= quiet_mock_return_remaining;
    logger->log_mock_check        = quiet_mock_check;
    logger->log_mock_get_return   = quiet_mock_get_return;
}
