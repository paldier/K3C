/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

//*****************************************************************************
//  Includes
//*****************************************************************************
#include "logger.h"
#include <string.h>

//*****************************************************************************
//  Macro Declarations
//*****************************************************************************
#define MIN(a,b) ((a) < (b) ? (a) : (b))

//*****************************************************************************
//  Global Declarations
//*****************************************************************************
static int g_test_count = 0;

//*****************************************************************************
//  Logger Functions
//*****************************************************************************
void error_run_start(test_run_t *run)
{
}

typedef enum
{
    RED    = 1,
    GREEN  = 2,
    NORMAL = 3,
} color_t;

void error_set_color(color_t color)
{
    char *pRed = "\x1B[31m";
    char *pGreen = "\x1B[32m";
    char *pNormal = "\x1B[0m";
    char *pStr = NULL;

    switch(color)
    {
        case RED:   pStr = pRed; break;
        case GREEN: pStr = pGreen; break;
        case NORMAL:
        default:
                    pStr = pNormal;
    }
    printf("%s", pStr);
}

void error_run_finished(test_run_t *run, long long usecs)
{
    printf("\n");
    error_set_color((run->failed > 0) ? RED : GREEN);
    printf("%s - Pass:%d Failed:%d Time:", 
           run->failed > 0 ? "FAIL" : "OK", run->passed, run->failed);
    log_print_usecs(usecs);
    error_set_color(NORMAL);
    printf("\n");
}

void error_suite_start(test_suite_t *suite)
{
    printf("%s ", suite->suite_name);
    g_test_count = 0;
}

void error_suite_finished(test_suite_t *suite)
{
    printf("\n");
}

void error_test_start(test_suite_t *suite, unit_test_t *test)
{
    g_test_count++;
}

// Prints '!' for failed tests.
// Prints '.' for passed tests.
void error_test_finished(test_suite_t *suite, unit_test_t *test)
{
    if(has_test_failed())
    {
        error_set_color(RED);
        printf("!");
    }
    else
    {
        error_set_color(GREEN);
        printf(".");
    }
    if(g_test_count >= 16)
    {
        // Add a string the same length as the suite name+1 to line up the dots
        char str[80];
        memset(str, ' ', sizeof(str));
        str[MIN(sizeof(str)-1, strlen(suite->suite_name)+1)] = 0;
        printf("\n%s", str);
        g_test_count = 0;
    }
    error_set_color(NORMAL);
}

void error_assert_fail(const char* function,
                       const char* file,
                       int         line)
{
    printf("\n");
    error_set_color(RED);
    printf("%s:%d: %s() - Test fail called.\n", file, line, function);
    error_set_color(NORMAL);
}

void error_assert_true(bool        failed,
                       const char* function, 
                       const char* file,   
                       int         line)
{
    if(failed)
    {
        printf("\n");
        error_set_color(RED);
        printf("%s:%d: %s() FAILED assert_true.\n",  file, line, function);
    }
    else if(test_get_debug())
    {
        error_set_color(GREEN);
        printf("%s:%d: %s() assert_true success.\n",  file, line, function);
    }
    error_set_color(NORMAL);
}

void error_assert_string_eq(bool        failed,
                            const char *actual, 
                            const char *expected, 
                            const char* function, 
                            const char* file,   
                            int         line)
{
    if(failed)
    {
        printf("\n");
        error_set_color(RED);
        printf("%s:%d: %s() FAILED assert_string_eq: Actual:'%s' != "
               "Expected'%s'\n",  file, line, function, actual, expected);
    }
    else if(test_get_debug())
    {
        error_set_color(GREEN);
        printf("%s:%d: %s() passed assert_string_eq: Actual:'%s' != "
               "Expected'%s'\n",  file, line, function, actual, expected);
    }
    error_set_color(NORMAL);
}

void error_assert_substr(bool        failed,
                         const char *main, 
                         const char *substr, 
                         const char* function, 
                         const char* file,   
                         int         line)
{
    if(failed)
    {
        printf("\n");
        error_set_color(RED);
        printf("%s:%d: %s() FAILED assert_substr: SubStr:'%s' not in "
               "'%s'\n",  file, line, function, substr, main);
    }
    else if(test_get_debug())
    {
        error_set_color(GREEN);
        printf("%s:%d: %s() passed assert_substr: SubStr:'%s' in "
               "'%s'\n",  file, line, function, substr, main);
    }
    error_set_color(NORMAL);
}

void error_assert_no_substr(bool        failed,
                            const char *main, 
                            const char *substr, 
                            const char* function, 
                            const char* file,   
                            int         line)
{
    if(failed)
    {
        printf("\n");
        error_set_color(RED);
        printf("%s:%d: %s() FAILED assert_no_substr: SubStr:'%s' is in "
               "'%s'\n",  file, line, function, substr, main);
    }
    else if(test_get_debug())
    {
        error_set_color(GREEN);
        printf("%s:%d: %s() passed assert_no_substr: SubStr:'%s' not in "
               "'%s'\n",  file, line, function, substr, main);
    }
    error_set_color(NORMAL);
}

void error_assert_equal_f(bool       failed,
                          double      actual, 
                          double      expected,
                          double      range,
                          const char* function, 
                          const char* file, 
                          int         line)
{
    if(failed)
    {
        printf("\n");
        error_set_color(RED);
        printf("%s:%d: %s() FAILED: assert_equal_f '%f' + '%f' (%f) >= '%f' "
               "&& '%f' - '%f' (%f) <= '%f'\n", file, line, function, actual, 
               range, actual+range, expected, actual, range, actual-range, expected);
    }
    else if(test_get_debug())
    {
        error_set_color(GREEN);
        printf("%s:%d: %s() success: assert_equal_f '%f' + '%f' (%f) >= '%f' "
               "&& '%f' - '%f' (%f) <= '%f'\n", file, line, function, actual, 
               range, actual+range, expected, actual, range, actual-range, expected);
    }
    error_set_color(NORMAL);
}

void error_assert_equal_flag_set(bool       failed,
                                 intptr_t   actual, 
                                 intptr_t   expected,
                                 const char* flag_name,
                                 const char* function, 
                                 const char* file, 
                                 int         line)
{
    error_set_color(RED);
    if(failed)
    {
        printf("\n");
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' doesn't contain Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' contains Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
    error_set_color(NORMAL);
}

void error_assert_equal_flag_unset(bool       failed,
                                   intptr_t   actual, 
                                   intptr_t   expected,
                                   const char* flag_name,
                                   const char* function, 
                                   const char* file, 
                                   int         line)
{
    error_set_color(RED);
    if(failed)
    {
        printf("\n");
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' contains Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' doesn't contain Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
    error_set_color(NORMAL);
}

void error_assert_equal(bool       failed,
                        intptr_t   actual, 
                        intptr_t   expected,
                        const char* function, 
                        const char* file, 
                        int         line)
{
    if(failed)
    {
        error_set_color(RED);
        printf("\n");
        printf("%s:%d: %s() FAILED: assert_equal Actual:'%p' != Expected:'%p'\n", 
               file, line, function, (void*)actual,  (void*)expected);
    }
    else if(test_get_debug())
    {
        error_set_color(GREEN);
        printf("%s:%d: %s() assert_equal success: Actual:'%p' == Expected:'%p'\n", 
               file, line, function, (void*)actual,  (void*)expected);
    }
    error_set_color(NORMAL);
}

void error_mock_param_remaining(const char   *function,
                                const char   *parameter,
                                expect_type_t type,
                                intptr_t      value)
{
    error_set_color(RED);
    printf("Mock FAILURE: Item remaining: Func:%s() Param:%s Val:",
           function, parameter);
    print_type(value, type);
    printf("\n");
    error_set_color(NORMAL);
}

void error_mock_return_remaining(const char   *function,
                                 expect_type_t type,
                                 intptr_t      value)
{
    error_set_color(RED);
    printf("Mock FAILURE: Item remaining: Func:%s() Return:", function);
    print_type(value, type);
    printf("\n");
    error_set_color(NORMAL);
}

void error_mock_check(bool          failed, 
                      intptr_t      actual,
                      intptr_t      expected,
                      const char*   function,
                      const char*   parameter,
                      expect_type_t type)
{
    if(failed)
    {
        error_set_color(RED);
        printf("Mock: check_expected failed assert: Func:%s() Param:%s "
               "Expected Value:",function, parameter);
        print_type(expected, type);
        printf(" Actual:");
        print_type(actual, type);
        printf("\n");
    }
    else if(test_get_debug())
    {
        error_set_color(GREEN);
        printf("Mock: check_expected passed assert: Func:%s() Param:%s "
               "Expected Value:",function, parameter);
        print_type(expected, type);
        printf(" Actual:");
        print_type(actual, type);
        printf("\n");
    }
    error_set_color(NORMAL);
}

void error_mock_get_return(intptr_t      return_val,
                           const char*   function,
                           expect_type_t type)
{
    if(test_get_debug())
    {
        printf("Mock: return: Func:%s() Return Value:%p\n", 
               function, (void*)return_val);
    }
}

void error_logger_init(logger_t* logger)
{
    logger->log_run_start         = error_run_start;
    logger->log_run_finished      = error_run_finished;
    logger->log_suite_start       = error_suite_start;
    logger->log_suite_finished    = error_suite_finished;
    logger->log_test_start        = error_test_start;
    logger->log_test_finished     = error_test_finished;
    logger->log_assert_fail       = error_assert_fail;
    logger->log_assert_true       = error_assert_true;
    logger->log_assert_string_eq  = error_assert_string_eq;
    logger->log_assert_substr     = error_assert_substr;
    logger->log_assert_no_substr  = error_assert_no_substr;
    logger->log_assert_equal_f    = error_assert_equal_f;
    logger->log_assert_equal_flag_set   = error_assert_equal_flag_set;
    logger->log_assert_equal_flag_unset = error_assert_equal_flag_unset;
    logger->log_assert_equal      = error_assert_equal;
    logger->log_mock_param_remaining = error_mock_param_remaining;
    logger->log_mock_return_remaining= error_mock_return_remaining;
    logger->log_mock_check        = error_mock_check;
    logger->log_mock_get_return   = error_mock_get_return;
}
