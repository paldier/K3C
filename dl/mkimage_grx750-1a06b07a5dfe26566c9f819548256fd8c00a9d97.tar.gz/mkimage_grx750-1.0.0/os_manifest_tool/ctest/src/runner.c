/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

//*****************************************************************************
//  Includes
//*****************************************************************************
#include "ctest_internal.h"
#include "logger.h"
#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <string.h>
#include <sys/time.h>

//*****************************************************************************
//  Global Declarations
//*****************************************************************************

// Defines the jump point to return to when test terminates early.
static jmp_buf g_test_jmp;

// Defines if a test is currently running.
static bool g_test_in_progress = false;

// Defines if the test has failed.
static bool g_test_has_failed = false;

// Defines if debugging is enabled.
static bool g_debug_output_enabled = false;

//*****************************************************************************
//  Function Declarations
//*****************************************************************************

// Sets the global debug enabled flag.
void test_set_debug(bool debug)
{
    g_debug_output_enabled = debug;
}

// Returns the global debug enabled flag.
bool test_get_debug(void)
{
    return g_debug_output_enabled;
}

// Returns true if the test is running.
bool is_test_running(void)
{
    return g_test_in_progress;
}

// Returns true if the test has failed.
bool has_test_failed(void)
{
    return g_test_has_failed;
}

// Sets the global that the test has failed.
void set_test_has_failed(void)
{
    g_test_has_failed = true;
}

// Ends the test and returns back to the runner.
void terminate_test(void)
{
    return longjmp(g_test_jmp, 1);
}

// Creates an empty test run
test_run_t* test_run_create()
{
    test_run_t *run = calloc(1, sizeof(test_run_t));
    assert(run);
    t_ll_init(&run->test_suite_list, "test_suite_t*");
    return run;
}

// Creates an empty test suite
test_suite_t* test_suite_create(const char* suite_name)
{
    test_suite_t *suite = calloc(1, sizeof(test_suite_t));
    assert(suite);
    t_ll_init(&suite->tests, "unit_test_t");
    suite->suite_name = suite_name;
    return suite;
}

void test_suite_add_setup(test_suite_t *suite, SetupFunction func)
{
    if (suite)
        suite->setup = func;
}

void test_suite_add_teardown(test_suite_t *suite, TearDownFunction func)
{
    if (suite)
        suite->teardown = func;
}

// Adds a test_suite_t to a test_run_t
void test_run_add_suite_(test_run_t   *test_run, 
                         test_suite_t *suite)
{
    test_suite_t **suite_ptr;
    CREATE_ADD_ENTRY(test_run->test_suite_list, suite_ptr, test_suite_t*);
    *suite_ptr = suite;
}

// Adds a test function to a test_suite_t
void test_suite_add_test_(test_suite_t *suite, 
                          const char   *test_name, 
                          TestFunction  test_func)
{
    unit_test_t *unit_test;
    CREATE_ADD_ENTRY(suite->tests, unit_test, unit_test_t);

    unit_test->test_name = test_name;
    unit_test->test_func = test_func;
}

// Runs a single test.
void run_test(test_suite_t *suite, unit_test_t *unit_test)
{
    TestFunction test = unit_test->test_func;

    // First saves the point to return to if the test were to fail.
    if(setjmp(g_test_jmp) == 0)
    {
        log_test_start(suite, unit_test);
        g_test_has_failed = false;
        g_test_in_progress = true;
        if (suite->setup) suite->setup();
        (*test)();
        if (suite->teardown) suite->teardown();
        g_test_in_progress = false;
    }
    else
    {
        if (suite->teardown) suite->teardown();
        // longjmp was called.
        g_test_in_progress = false;
    }

    // Ensure that there are no mock item remaining.
    if(check_mock_for_remaining_items() == true)
    {
        g_test_has_failed = true;
    }

    log_test_finished(suite, unit_test);
    g_test_has_failed = false;
}

// If test_name is NULL, run all the tests in the suite.
// Otherwise run only the specified test.
void run_test_suite(test_suite_t *suite, const char *test_name)
{

    log_suite_start(suite);

    list_entry_t *ll_entry;
    unit_test_t *unit_test;
    FOREACH(ll_entry, &suite->tests, "unit_test_t")
    {
        unit_test = (unit_test_t*)ll_entry->data;
        if(test_name == NULL)
        {
            run_test(suite, unit_test);
        }
        else if(strcmp(unit_test->test_name, test_name) == 0)
        {
            run_test(suite, unit_test);
        }
    }

    log_suite_finished(suite);
}

// If test_name is NULL, run all the tests in the test_run_t.
// Otherwise run only the specified test.
int test_run_execute_(test_run_t *test_run, 
                      const char *test_name,
                      log_style_t style)
{
    struct timeval start, end;
    long long diff;
    gettimeofday(&start, NULL);

    log_set_style(style);

    log_run_start(test_run);

    list_entry_t *ll_entry;
    test_suite_t **suite;
    FOREACH(ll_entry, &test_run->test_suite_list, "test_suite_t*")
    {
        suite = (test_suite_t**)ll_entry->data;
        run_test_suite(*suite, test_name);
        test_run->passed += (*suite)->passed;
        test_run->failed += (*suite)->failed;
    }

    gettimeofday(&end, NULL);
    diff = (end.tv_sec   * 1000000LL +   end.tv_usec)
         - (start.tv_sec * 1000000LL + start.tv_usec);
    log_run_finished(test_run, diff);

    return test_run->failed;
}

// Run a single test.
int test_run_execute_single(test_run_t *test_run, 
                            const char* test_name, 
                            log_style_t style)
{
    if(test_name == NULL || strcmp(test_name, "") == 0)
    {
        error("No test specified\n");
        return 0;
    }

    return test_run_execute_(test_run, test_name, style);
}

// Clear out any remaining portions of the test suite.
void cleanup_test_suite(test_suite_t *suite)
{
    t_ll_delete_list(&suite->tests);
    free(suite);
}

// Clear out any remaining portions of the test run.
void test_run_destroy(test_run_t *test_run)
{
    list_entry_t *ll_entry;
    test_suite_t **suite;
    FOREACH(ll_entry, &test_run->test_suite_list, "test_suite_t*")
    {
        suite = (test_suite_t**)ll_entry->data;
        cleanup_test_suite(*suite);
    }

    t_ll_delete_list(&test_run->test_suite_list);
    free(test_run);
}

// Prints the value based on the type.
void print_type(intptr_t value, expect_type_t type)
{
    switch(type)
    {
    case EXPECT_VALUE:
        printf("%p:%d", (void*)value, (int)value);
        break;
    case EXPECT_STRING:
        printf("%p:\"%s\":", (void*)value, (char*)value);
        break;
    default:
        printf("Unknown type:%d Val:%p\n", type, (void*)value);
        break;
    }
}
