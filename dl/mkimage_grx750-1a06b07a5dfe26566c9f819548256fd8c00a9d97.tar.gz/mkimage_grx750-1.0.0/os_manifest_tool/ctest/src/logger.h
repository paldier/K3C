/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

#ifndef __LOGGER_H__
#define __LOGGER_H__

//-----------------------------------------------------------------------------
//  Includes
//-----------------------------------------------------------------------------
#include "ctest_internal.h"
#include <ctest_logger.h>
#include <stdbool.h>

//-----------------------------------------------------------------------------
//  Type Declarations
//-----------------------------------------------------------------------------
struct logger_t;

typedef struct logger_t
{
    void (*destroy)(struct logger_t *logger);
    void (*log_run_start)(test_run_t *run);
    void (*log_run_finished)(test_run_t *run, long long usecs);
    void (*log_suite_start)(test_suite_t *suite);
    void (*log_suite_finished)(test_suite_t *suite);
    void (*log_test_start)(test_suite_t *suite, unit_test_t *test);
    void (*log_test_finished)(test_suite_t *suite, unit_test_t *test);

    void (*log_assert_fail)(const char* function,
                            const char* file,
                            int         line);
    void (*log_assert_true)(bool        failed,
                            const char* function, 
                            const char* file,   
                            int         line);
    void (*log_assert_string_eq)(bool        failed,
                                 const char *actual, 
                                 const char *expected, 
                                 const char* function,  
                                 const char* file,   
                                 int         line);
    void (*log_assert_substr)(bool        failed,
                              const char *main, 
                              const char *substr, 
                              const char* function,  
                              const char* file,   
                              int         line);
    void (*log_assert_no_substr)(bool        failed,
                                 const char *main, 
                                 const char *substr, 
                                 const char* function,  
                                 const char* file,   
                                 int         line);
    void (*log_assert_equal_f)(bool        failed,
                               double      actual, 
                               double      expected,
                               double      range,
                               const char* function,  
                               const char* file, 
                               int         line);
    void (*log_assert_equal_flag_set)(bool       failed,
                                      intptr_t   actual, 
                                      intptr_t   expected,
                                      const char* flag_name,
                                      const char* function, 
                                      const char* file, 
                                      int         line);
    void (*log_assert_equal_flag_unset)(bool       failed,
                                        intptr_t   actual, 
                                        intptr_t   expected,
                                        const char* flag_name,
                                        const char* function, 
                                        const char* file, 
                                        int         line);
    void (*log_assert_equal)(bool       failed,
                             intptr_t   actual, 
                             intptr_t   expected,
                             const char* function,  
                             const char* file, 
                             int         line);
    void (*log_mock_param_remaining)(const char   *function,
                                     const char   *parameter,
                                     expect_type_t type,
                                     intptr_t      value);
    void (*log_mock_return_remaining)(const char   *function,
                                      expect_type_t type,
                                      intptr_t      value);
    void (*log_mock_check)(bool          failed, 
                           intptr_t      actual,
                           intptr_t      expected,
                           const char*   function,
                           const char*   parameter,
                           expect_type_t type);
    void (*log_mock_get_return)(intptr_t      return_val,
                                const char*   function,
                                expect_type_t type);
} logger_t;

//-----------------------------------------------------------------------------
//  Function Declarations
//-----------------------------------------------------------------------------

// Sets the style and creates the logger.
void log_set_style(log_style_t style);

// Prints the usecs.
void log_print_usecs(long long usecs);

//-----------------------------------------------------------------------------
// Logger Functions
//-----------------------------------------------------------------------------
void log_run_start(test_run_t *run);
void log_run_finished(test_run_t *run, long long usecs);

void log_suite_start(test_suite_t *suite);
void log_suite_finished(test_suite_t *suite);

void log_test_start(test_suite_t *suite, unit_test_t *test);
void log_test_finished(test_suite_t *suite, unit_test_t *test);


void log_assert_fail_(const char* function,
                      const char* file,
                      int         line);
void log_assert_true_(bool        failed,
                      const char* function, 
                      const char* file, 
                      int         line);
void log_assert_string_eq_(bool        failed,
                           const char *actual, 
                           const char *expected, 
                           const char* function, 
                           const char* file, 
                           int         line);
void log_assert_substr_(bool        failed,
                        const char *main, 
                        const char *substr, 
                        const char* function, 
                        const char* file, 
                        int         line);
void log_assert_no_substr_(bool        failed,
                           const char *main, 
                           const char *substr, 
                           const char* function, 
                           const char* file, 
                           int         line);
void log_assert_equal_f_(bool        failed,
                         double      actual, 
                         double      expected,
                         double      range,
                         const char* function, 
                         const char* file, 
                         int         line);
void log_assert_equal_flag_set_(bool       failed,
                                intptr_t   actual, 
                                intptr_t   expected,
                                const char* flag_name,
                                const char* function, 
                                const char* file, 
                                int         line);
void log_assert_equal_flag_unset_(bool       failed,
                                  intptr_t   actual, 
                                  intptr_t   expected,
                                  const char* flag_name,
                                  const char* function, 
                                  const char* file, 
                                  int         line);
void log_assert_equal_(bool        failed,
                       intptr_t    actual, 
                       intptr_t    expected,
                       const char* function, 
                       const char* file, 
                       int         line);

void log_mock_param_remaining(const char   *function,
                              const char   *parameter,
                              expect_type_t type,
                              intptr_t      value);
void log_mock_return_remaining(const char   *function,
                               expect_type_t type,
                               intptr_t      value);
void log_mock_check(bool          failed, 
                    intptr_t      actual,
                    intptr_t      expected,
                    const char*   function,
                    const char*   parameter,
                    expect_type_t type);
void log_mock_get_return(intptr_t      return_val,
                         const char*   function,
                         expect_type_t type);
#endif //__LOGGER_H__
