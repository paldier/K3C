/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

//*****************************************************************************
//  Includes
//*****************************************************************************
#include <assert.h>
#include "ctest_internal.h"
#include "llist.h"
#include "logger.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

//*****************************************************************************
//  Global/Macro Defines
//*****************************************************************************

// The parameter name for return values.
#define RET_PARAM_NAME "__SPECIAL_CTEST_RETURN_VAL__"

// The list of function_list_t. function_list_t holds a list of expected
// parameters that are checked.
linked_list_t g_parameter_map;

// A list of function_list_t. function_list_t holds a list of expected
// result values.
linked_list_t g_return_map;

// Debug printing global
static bool g_debug = false;

//*****************************************************************************
//  Type Declarations
//*****************************************************************************

// Function List has the name of the function to mock and a list of parameters
typedef struct
{
    const char   *name;
    linked_list_t list;
}function_list_t;

// Holds the parameter's name, value and its type for comparing it to the actual.
typedef struct
{
    const char    *name;
    intptr_t       value;
    expect_type_t  type;
}parameter_t;

//*****************************************************************************
//  Function Declarations
//*****************************************************************************

// Debug helper function for printing out the function list of a 
// parameter/return list.
void print_function_list(function_list_t *func_list)
{
    assert(func_list != NULL);
    printf("Function:%s\n", func_list->name);
    list_entry_t *ll_entry;
    parameter_t *param;
    FOREACH(ll_entry, &func_list->list, "parameter_t")
    {
        param = (parameter_t*)ll_entry->data;
        printf("\t%s() param:%p: => ", param->name, (void*)param->value);
        print_type(param->value, param->type);
        printf("\n");
    }
}

// Debug helper function for printing out the parameter/return list.
void print_parameter_list(linked_list_t *list, 
                          const char    *func, 
                          const char    *list_name)
{
    if(g_debug)
    {
        if(list == NULL || func == NULL || list_name == NULL)
        {
            printf("Func:%s ListName:%s List:%p. Values not allowed to be NULL.\n",
                   func, list_name, list);
            return;
        }
        if(t_ll_verify_integrity(list) != true)
        {
            printf("Func:%s ListName:%s List:%p. List fails validity check.\n",
                   func, list_name, list);
            return;
        }
        printf("Print list:%s From:%s\n", list_name, func);
        list_entry_t *ll_entry;
        function_list_t *func_list;
        FOREACH(ll_entry, list, "function_list_t")
        {
            func_list = (function_list_t*)ll_entry->data;
            print_function_list(func_list);
        }
    }
}

// Look through the parameter/return list for the specific function list.
function_list_t* find_function_list(linked_list_t *list, const char* function)
{
    function_list_t *ret_list = NULL;

    list_entry_t    *ll_entry;
    function_list_t *func_list;

    if(!t_ll_verify_list_type(list, "function_list_t"))
    {                                                                    
        bug("The list types don't match. List:%s Expect:%s\n\n", 
            list->type, "function_list_t");                     
        goto exit;
    }                                                                   

    FOREACH(ll_entry, list, "function_list_t")
    {
        func_list = (function_list_t*)ll_entry->data;
        if(strings_equal(func_list->name, function))
        {
            ret_list = func_list;
            break;
        }
    }

exit:
    return ret_list;
}

// Look through the function list for the specific parameter.
parameter_t* find_parameter(function_list_t *func, const char* param_name)
{
    parameter_t *ret_param = NULL;

    list_entry_t *ll_entry;
    parameter_t  *param;
    FOREACH(ll_entry, &func->list, "parameter_t")
    {
        param = (parameter_t*)ll_entry->data;
        if(strings_equal(param->name, param_name))
        {
            // Remove the entry, without freeing the pointer. Freeing is 
            // the responsiblity of the calling function.
            t_ll_delete_entry(ll_entry, false);

            // Save the data pointer.
            ret_param = param;
            break;
        }
    }

    return ret_param;
}

// Generic application for adding a parameter/result to a function's list.
void add_parameter_result(const char*    function,
                          const char*    parameter,
                          expect_type_t  type,
                          intptr_t       value,
                          linked_list_t *map)
{
    // On the first call, initialize the map.
    if(!t_ll_is_initialized(map))
    {
        t_ll_init(map, "function_list_t");
    }

    // Find the function list
    function_list_t *func_list = find_function_list(map, function);

    // If it doesn't exist, create it.
    if(func_list == NULL)
    {
        // Create the entry and add it to the list.
        CREATE_ADD_ENTRY(*map, func_list, function_list_t);

        // Set the values.
        func_list->name = function;
        t_ll_init(&func_list->list, "parameter_t");
    }

    // Create a parameter_t to hold the parameter
    parameter_t *param;
    CREATE_ADD_ENTRY(func_list->list, param, parameter_t);

    param->name  = parameter;
    param->value = value;
    param->type  = type;

}

// Adds the expected parameter value for later testing.
void expect_parameter_(const char*   function,
                       const char*   parameter,
                       expect_type_t type,
                       intptr_t      value)
{
    add_parameter_result(function, parameter, type, value, &g_parameter_map);

    if(test_get_debug())
    {
        printf("Mock: Func:%s() - add parameter:%s Val:", 
               function, parameter);
        print_type(value,type);
        printf("\n");
    }
}

// Adds the expected return value for later mock return.
void will_return_(const char*   function,
                  intptr_t      value,
                  expect_type_t type)
{
    add_parameter_result(function, 
                         RET_PARAM_NAME, 
                         type, 
                         value, 
                         &g_return_map);

    if(test_get_debug())
    {
        printf("Mock: Func:%s() - add return:",  function);
        print_type(value,type);
        printf("\n");
    }
}

// Retrieves the param/return from the map.
intptr_t get_param_value(const char    *function,
                         const char    *parameter,
                         linked_list_t *map,
                         bool          *found,
                         expect_type_t *type)
{
    parameter_t *param = NULL;
    intptr_t     ret   = 0;
    *found = false;

    // On the first call, initialize the map.
    if(!t_ll_is_initialized(map))
    {
        t_ll_init(map, "function_list_t");
    }

    // Find the function list
    function_list_t *func_list = find_function_list(map, function);
    if(func_list == NULL)
    {
        printf("There is no function list that holds expected parameteres. "
               "Func:%s Param:%s\n", function, parameter);
        fail_and_finish_test(false);
        goto exit;
    }

    param = find_parameter(func_list, parameter);
    if(param == NULL)
    {
        printf("There are no parameters expected. Func:%s Param:%s\n",
               function, parameter);
        fail_and_finish_test(false);
        goto exit;
    }

    ret   = param->value;
    *type = param->type;
    *found = true;


exit:
    return ret;
}

// Validates the parameter is what was expected.
bool check_expected_(const char * function,
                     const char * parameter,
                     intptr_t     value,
                     const char * file,
                     int          line)
{
    bool found = false;
    bool failed = false;
    expect_type_t type;
    print_parameter_list(&g_parameter_map, function, "Parameter List");
    intptr_t expected_val = get_param_value(function,
                                            parameter,
                                            &g_parameter_map,
                                            &found,
                                            &type);

    if(found == false)
    {
        printf("Mock fail: check_expected: Unable to find paramter to check. "
               "Function:%s() Param:%s Value:", function, parameter);
        print_type(value, type);
        printf("\n");
        fail_and_finish_test(false);
        failed = true;
    }
    else
    {
        // Test the value. 
        failed = assert_generic(value, 
                       expected_val,
                       type,
                       false,
                       function,
                       file,
                       line);
    }

    log_mock_check(!failed, value,  expected_val, function, parameter, type);

    return found;
}


// Retrieves the stored return value.
intptr_t mock_(const char * function)
{
    bool found;
    expect_type_t type;

    print_parameter_list(&g_return_map, function, "Return List");

    intptr_t ret_val = get_param_value(function,
                                       RET_PARAM_NAME,
                                       &g_return_map,
                                       &found,
                                       &type);

    return ret_val;
}


// Look through the parameter/return maps for additional items that haven't
// been used. Delete the remaining items.
bool check_mock_for_remaining_items(void)
{
    bool ret = false;

    if(t_ll_is_initialized(&g_parameter_map) == true)
    {
        list_entry_t    *ll_func_entry;
        function_list_t *func_list;
        FOREACH(ll_func_entry, &g_parameter_map, "function_list_t")
        {
            func_list = (function_list_t*)ll_func_entry->data;

            // Search the list for parameters and delete them
            list_entry_t *ll_entry;
            parameter_t  *param;
            FOREACH(ll_entry, &func_list->list, "parameter_t")
            {
                param = (parameter_t*)ll_entry->data;
                log_mock_param_remaining(func_list->name, 
                                         param->name, 
                                         param->type, 
                                         param->value);
                ret = true;
            }
        }

        int i;
        for(i = t_ll_size(&g_parameter_map)-1; i >= 0; i--)
        {
            t_ll_entry_at(&g_parameter_map, i, (uint8_t**)&func_list);
            t_ll_delete_list(&func_list->list);
        }

        t_ll_delete_list(&g_parameter_map);
    }

    if(t_ll_is_initialized(&g_return_map) == true)
    {
        list_entry_t    *ll_func_entry;
        function_list_t *func_list;
        FOREACH(ll_func_entry, &g_return_map, "function_list_t")
        {
            func_list = (function_list_t*)ll_func_entry->data;

            // Search the list for parameters and delete them
            list_entry_t *ll_entry;
            parameter_t  *param;
            FOREACH(ll_entry, &func_list->list, "parameter_t")
            {
                param = (parameter_t*)ll_entry->data;
                log_mock_return_remaining(func_list->name, 
                                          param->type, 
                                          param->value);
                ret = true;
            }
        }

        int i;
        for(i = t_ll_size(&g_return_map)-1; i >= 0; i--)
        {
            t_ll_entry_at(&g_return_map, i, (uint8_t**)&func_list);
            t_ll_delete_list(&func_list->list);
        }
        t_ll_delete_list(&g_return_map);
    }

    memset(&g_return_map, 0, sizeof(linked_list_t));
    memset(&g_parameter_map, 0, sizeof(linked_list_t));

    return ret;
}

