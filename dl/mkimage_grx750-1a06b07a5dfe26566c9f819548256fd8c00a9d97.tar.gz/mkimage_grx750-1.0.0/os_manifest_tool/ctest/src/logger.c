/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

//-----------------------------------------------------------------------------
//  Includes
//-----------------------------------------------------------------------------
#include "ctest_internal.h"
#include "logger.h"
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

//-----------------------------------------------------------------------------
//  Global Declarations
//-----------------------------------------------------------------------------

// Stores the current logger.
static logger_t *g_logger = NULL;

//-----------------------------------------------------------------------------
//  Function Declarations
//-----------------------------------------------------------------------------
void verbose_logger_init(logger_t* logger);
void summary_logger_init(logger_t* logger);
void quiet_logger_init(logger_t* logger);
void error_logger_init(logger_t* logger);

//-----------------------------------------------------------------------------
// Frees the logger
//-----------------------------------------------------------------------------
void destroy_logger(logger_t *logger)
{
    free(logger);
}

//-----------------------------------------------------------------------------
// Allocates the logger
//-----------------------------------------------------------------------------
logger_t* create_logger(void)
{
    logger_t *logger = calloc(1, sizeof(logger_t));
    assert(logger);
    logger->destroy = &destroy_logger;
    return logger;
}

//-----------------------------------------------------------------------------
// Creates the logger based on the requested style.
//-----------------------------------------------------------------------------
void log_set_style(log_style_t style)
{
    if(g_logger != NULL)
    {
        (g_logger->destroy)(g_logger);
    }

    g_logger = create_logger();

    if (g_logger)
    {
        switch(style)
        {
            case LOG_STYLE_VERBOSE:
                verbose_logger_init(g_logger);
                break;
            case LOG_STYLE_SUMMARY:
                summary_logger_init(g_logger);
                break;
            case LOG_STYLE_QUIET:
                quiet_logger_init(g_logger);
                break;
            case LOG_STYLE_PRINT_ERROR:
                error_logger_init(g_logger);
                break;
            case LOG_STYLE_NONE:
                error("Unimplemented log style:%d.\n", style);
                break;
            default:
                error("Unknown log style:%d.\n", style);
                break;
        }
    }
}

//-----------------------------------------------------------------------------
// Prints the usecs
//-----------------------------------------------------------------------------
void log_print_usecs(long long usecs)
{
    if(usecs < 1000000LL)
    {
        printf("%lld.%03lld msecs", usecs / 1000LL, (usecs) % 1000LL);
    }
    else if(usecs < 60*1000000LL) 
    {
        printf("%lld.%03lld secs", usecs / 1000000LL, (usecs/ 1000LL) % 1000LL);
    }
    else// if(usecs < 60*60*1000000LL)
    {
        usecs /= 60;
        printf("%lld.%03lld minutes", usecs / 1000000LL, (usecs/ 1000LL) % 1000LL);
    }
}

void log_run_start(test_run_t *run)
{
    if(g_logger)
    {
        (*g_logger->log_run_start)(run);
    }
}

void log_run_finished(test_run_t *run, long long usecs)
{
    if(g_logger)
    {
        (*g_logger->log_run_finished)(run, usecs);
    }
}

void log_suite_start(test_suite_t *suite)
{
    suite->passed = 0;
    suite->failed = 0;
    if(g_logger) (*g_logger->log_suite_start)(suite);
}

void log_suite_finished(test_suite_t *suite)
{
    if(g_logger) (*g_logger->log_suite_finished)(suite);
}

void log_test_start(test_suite_t *suite, unit_test_t *test)
{
    if(g_logger) (*g_logger->log_test_start)(suite, test);
}

void log_test_finished(test_suite_t *suite, unit_test_t *test)
{
    if(has_test_failed())
    {
        suite->failed++;
    }
    else
    {
        suite->passed++;
    }
    if(g_logger) (*g_logger->log_test_finished)(suite, test);
}


void log_assert_fail_(const char* function,
                      const char* file,
                      int         line)
{
    if(g_logger)
    {
        (*g_logger->log_assert_fail)(function,file,line);
    }
}

void log_assert_true_(bool        failed,
                      const char* function, 
                      const char* file, 
                      int         line)
{
    if(g_logger)
    {
        (*g_logger->log_assert_true)(failed, function, file, line);
    }
}

void log_assert_string_eq_(bool        failed,
                           const char *actual, 
                           const char *expected, 
                           const char* function, 
                           const char* file, 
                           int         line)
{
    if(g_logger) 
    {
        (*g_logger->log_assert_string_eq)(failed,
                                          actual, 
                                          expected, 
                                          function, 
                                          file, 
                                          line);
    }
}

void log_assert_substr_(bool        failed,
                        const char *main, 
                        const char *substr, 
                        const char* function, 
                        const char* file, 
                        int         line)
{
    if(g_logger) 
    {
        (*g_logger->log_assert_substr)(failed,
                                       main, 
                                       substr, 
                                       function, 
                                       file, 
                                       line);
    }
}

void log_assert_no_substr_(bool        failed,
                           const char *main, 
                           const char *substr, 
                           const char* function, 
                           const char* file, 
                           int         line)
{
    if(g_logger) 
    {
        (*g_logger->log_assert_no_substr)(failed,
                                          main, 
                                          substr, 
                                          function, 
                                          file, 
                                          line);
    }
}

void log_assert_equal_f_(bool        failed,
                         double      actual, 
                         double      expected,
                         double      range,
                         const char* function, 
                         const char* file, 
                         int         line)
{
    if(g_logger)
    {
        (*g_logger->log_assert_equal_f)(failed, 
                                        actual, 
                                        expected, 
                                        range,
                                        function, 
                                        file, 
                                        line);
    }
}

void log_assert_equal_flag_set_(bool       failed,
                                intptr_t   actual, 
                                intptr_t   expected,
                                const char* flag_name,
                                const char* function, 
                                const char* file, 
                                int         line)
{
    if(g_logger)
    {
        (*g_logger->log_assert_equal_flag_set)(failed, 
                                               actual, 
                                               expected, 
                                               flag_name,
                                               function, 
                                               file, 
                                               line);
    }
}

void log_assert_equal_flag_unset_(bool       failed,
                                  intptr_t   actual, 
                                  intptr_t   expected,
                                  const char* flag_name,
                                  const char* function, 
                                  const char* file, 
                                  int         line)
{
    if(g_logger)
    {
        (*g_logger->log_assert_equal_flag_unset)(failed, 
                                                 actual, 
                                                 expected, 
                                                 flag_name,
                                                 function, 
                                                 file, 
                                                 line);
    }
}

void log_assert_equal_(bool       failed,
                       intptr_t   actual, 
                       intptr_t   expected,
                       const char* function, 
                       const char* file, 
                       int         line)
{
    if(g_logger)
    {
        (*g_logger->log_assert_equal)(failed, 
                                      actual, 
                                      expected, 
                                      function, 
                                      file, 
                                      line);
    }
}

void log_mock_param_remaining(const char   *function,
                              const char   *parameter,
                              expect_type_t type,
                              intptr_t      value)
{
    if(g_logger)
    {
        (*g_logger->log_mock_param_remaining)(function, parameter, type, value);
    }
}

void log_mock_return_remaining(const char   *function,
                               expect_type_t type,
                               intptr_t      value)
{
    if(g_logger)
    {
        (*g_logger->log_mock_return_remaining)(function, type, value);
    }
}

void log_mock_check(bool          failed, 
                    intptr_t      actual,
                    intptr_t      expected,
                    const char*   function,
                    const char*   parameter,
                    expect_type_t type)
{
    if(g_logger)
    {
        (*g_logger->log_mock_check)(failed, 
                                    actual, 
                                    expected, 
                                    function,
                                    parameter,
                                    type);
    }
}

void log_mock_get_return(intptr_t      return_val,
                         const char*   function,
                         expect_type_t type)
{
    if(g_logger)
    {
        (*g_logger->log_mock_get_return)(return_val, function, type);
    }
}
