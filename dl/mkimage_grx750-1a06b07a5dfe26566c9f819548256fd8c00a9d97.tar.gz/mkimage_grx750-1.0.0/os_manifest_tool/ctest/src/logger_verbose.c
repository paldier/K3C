/*****************************************************************************
 * Copyright (c) 2016 Intel Corporation
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel Software License Agreement provided with the Intel(R)
 * Media Processor Software Development Kit.
 ******************************************************************************/

//*****************************************************************************
//  Includes
//*****************************************************************************
#include "logger.h"

void verbose_run_start(test_run_t *run)
{
}

void verbose_run_finished(test_run_t *run, long long usecs)
{
    printf("-------------------------------------------\n");
    printf("Overall Pass:%d Failed:%d Time:", run->passed, run->failed);
    log_print_usecs(usecs);
    printf("\n-------------------------------------------\n");
}

void verbose_suite_start(test_suite_t *suite)
{
    printf(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
    printf(">>> Begin Suite:%s\n", suite->suite_name);
    printf(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
}

void verbose_suite_finished(test_suite_t *suite)
{
    printf("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n");
    printf("<<< Finished Suite:%s\n", suite->suite_name);
    printf("<<< Passed: %d Failed: %d\n", suite->passed, suite->failed);
    printf("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n\n");
}

void verbose_test_start(test_suite_t *suite, unit_test_t *test)
{
    printf(" =====> %s <=====\n", test->test_name);
}

void verbose_test_finished(test_suite_t *suite, unit_test_t *test)
{
    if(has_test_failed())
    {
        printf("######> FAILED TEST [%s]\n", test->test_name);
    }
    else
    {
        printf(" -----> passed\n");
    }
}


void verbose_assert_fail(const char* function,
                         const char* file,
                         int         line)
{
    printf("%s:%d: %s() - Test fail called.\n", file, line, function);
}

void verbose_assert_true(bool        failed,
                         const char* function, 
                         const char* file,   
                         int         line)
{
    if(failed)
    {
        printf("%s:%d: %s() FAILED assert_true.\n",  file, line, function);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() assert_true success.\n",  file, line, function);
    }
}

void verbose_assert_string_eq(bool        failed,
                              const char *actual, 
                              const char *expected, 
                              const char* function, 
                              const char* file,   
                              int         line)
{
    if(failed)
    {
        printf("%s:%d: %s() FAILED assert_string_eq: Actual:'%s' != "
               "Expected'%s'\n",  file, line, function, actual, expected);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() passed assert_string_eq: Actual:'%s' != "
               "Expected'%s'\n",  file, line, function, actual, expected);
    }
}

void verbose_assert_substr(bool        failed,
                           const char *main, 
                           const char *substr, 
                           const char* function, 
                           const char* file,   
                           int         line)
{
    if(failed)
    {
        printf("%s:%d: %s() FAILED assert_substr: SubStr:'%s' not in "
               "'%s'\n",  file, line, function, substr, main);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() passed assert_substr: SubStr:'%s' in "
               "'%s'\n",  file, line, function, substr, main);
    }
}

void verbose_assert_no_substr(bool        failed,
                              const char *main, 
                              const char *substr, 
                              const char* function, 
                              const char* file,   
                              int         line)
{
    if(failed)
    {
        printf("%s:%d: %s() FAILED assert_no_substr: SubStr:'%s' in "
               "'%s'\n",  file, line, function, substr, main);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() passed assert_no_substr: SubStr:'%s' not in "
               "'%s'\n",  file, line, function, substr, main);
    }
}

void verbose_assert_equal_f(bool       failed,
                            double      actual, 
                            double      expected,
                            double      range,
                            const char* function, 
                            const char* file, 
                            int         line)
{
    if(failed)
    {
        printf("%s:%d: %s() FAILED: assert_equal_f '%f' + '%f' (%f) >= '%f' "
               "&& '%f' - '%f' (%f) <= '%f'\n", file, line, function, actual, 
               range, actual+range, expected, actual, range, actual-range, expected);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() success: assert_equal_f '%f' + '%f' (%f) >= '%f' "
               "&& '%f' - '%f' (%f) <= '%f'\n", file, line, function, actual, 
               range, actual+range, expected, actual, range, actual-range, expected);
    }
}

void verbose_assert_equal_flag_set(bool       failed,
                                   intptr_t   actual, 
                                   intptr_t   expected,
                                   const char* flag_name,
                                   const char* function, 
                                   const char* file, 
                                   int         line)
{
    if(failed)
    {
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' doesn't contain Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' contains Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
}

void verbose_assert_equal_flag_unset(bool       failed,
                                     intptr_t   actual, 
                                     intptr_t   expected,
                                     const char* flag_name,
                                     const char* function, 
                                     const char* file, 
                                     int         line)
{
    if(failed)
    {
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' contains Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() FAILED: assert_equal_flag Actual:'%p' doesn't contain Expected Flag:'%p'\n"
               "Flag name:%s\n", 
               file, line, function, (void*)actual,  (void*)expected, flag_name);
    }
}

void verbose_assert_equal(bool       failed,
                          intptr_t   actual, 
                          intptr_t   expected,
                          const char* function, 
                          const char* file, 
                          int         line)
{
    if(failed)
    {
        printf("%s:%d: %s() FAILED: assert_equal Actual:'%p' != Expected:'%p'\n", 
               file, line, function, (void*)actual,  (void*)expected);
    }
    else if(test_get_debug())
    {
        printf("%s:%d: %s() assert_equal success: Actual:'%p' == Expected:'%p'\n", 
               file, line, function, (void*)actual,  (void*)expected);
    }
}

void verbose_mock_param_remaining(const char   *function,
                                  const char   *parameter,
                                  expect_type_t type,
                                  intptr_t      value)
{
    printf("Mock FAILURE: Item remaining: Func:%s() Param:%s Val:",
           function, parameter);
    print_type(value, type);
    printf("\n");
}

void verbose_mock_return_remaining(const char   *function,
                                   expect_type_t type,
                                   intptr_t      value)
{
    printf("Mock FAILURE: Item remaining: Func:%s() Return:", function);
    print_type(value, type);
    printf("\n");
}

void verbose_mock_check(bool          failed, 
                        intptr_t      actual,
                        intptr_t      expected,
                        const char*   function,
                        const char*   parameter,
                        expect_type_t type)
{
    if(failed)
    {
        printf("Mock: check_expected failed assert: Func:%s() Param:%s "
               "Expected Value:",function, parameter);
        print_type(expected, type);
        printf(" Actual:");
        print_type(actual, type);
        printf("\n");
    }
    else if(test_get_debug())
    {
        printf("Mock: check_expected passed assert: Func:%s() Param:%s "
               "Expected Value:",function, parameter);
        print_type(expected, type);
        printf(" Actual:");
        print_type(actual, type);
        printf("\n");
    }
}

void verbose_mock_get_return(intptr_t      return_val,
                             const char*   function,
                             expect_type_t type)
{
    if(test_get_debug())
    {
        printf("Mock: return: Func:%s() Return Value:%p\n", 
               function, (void*)return_val);
    }
}

void verbose_logger_init(logger_t* logger)
{
    logger->log_run_start         = verbose_run_start;
    logger->log_run_finished      = verbose_run_finished;
    logger->log_suite_start       = verbose_suite_start;
    logger->log_suite_finished    = verbose_suite_finished;
    logger->log_test_start        = verbose_test_start;
    logger->log_test_finished     = verbose_test_finished;
    logger->log_assert_fail       = verbose_assert_fail;
    logger->log_assert_true       = verbose_assert_true;
    logger->log_assert_string_eq  = verbose_assert_string_eq;
    logger->log_assert_substr     = verbose_assert_substr;
    logger->log_assert_no_substr  = verbose_assert_no_substr;
    logger->log_assert_equal_f    = verbose_assert_equal_f;
    logger->log_assert_equal_flag_set   = verbose_assert_equal_flag_set;
    logger->log_assert_equal_flag_unset = verbose_assert_equal_flag_unset;
    logger->log_assert_equal      = verbose_assert_equal;
    logger->log_mock_param_remaining = verbose_mock_param_remaining;
    logger->log_mock_return_remaining= verbose_mock_return_remaining;
    logger->log_mock_check        = verbose_mock_check;
    logger->log_mock_get_return   = verbose_mock_get_return;
}
