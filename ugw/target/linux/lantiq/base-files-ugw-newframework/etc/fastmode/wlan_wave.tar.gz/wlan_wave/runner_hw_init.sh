cd /tmp
cp -s /opt/lantiq/lib/modules/3.10.102/net/mtlkroot.ko /tmp/
cp -s /opt/lantiq/bin/fw_scd_file.scd /tmp/
cp -s /opt/lantiq/bin/hw_scd_file.scd /tmp/
cp -s /opt/lantiq/lib/modules/3.10.102/net/mtlk.ko /tmp/
cp -s /opt/lantiq/wave/images/* /tmp/
if [ -d /nvram/etc/wave_overlay ]
then
	for f in /nvram/etc/wave_overlay/*
	do
		echo "NOTE:  Overriding  ${f#/nvram/etc/wave_overlay/}" with file from wave_overlay
		cp -s $f /tmp
	done
fi
echo /opt/lantiq/sbin/hotplug > /proc/sys/kernel/hotplug
udevd_up=`ps | grep -c udevd`
[ $udevd_up -gt 1 ] || udevd --daemon
export COUNTRY=00
crda
touch /tmp/wlan_wave/crda_executed
insmod mtlkroot.ko
cp -s /opt/lantiq/bin/logserver /tmp/
/tmp/logserver -f /tmp/dev/mtlkroot0 -s /tmp/fw_scd_file.scd &
if [ ! -e /tmp/cal_wlan0.bin ]
then
	read_img wlanconfig /tmp/eeprom.tar.gz
	tar xzf /tmp/eeprom.tar.gz -C /tmp/
fi
insmod mtlk.ko ap=1,1 fastpath=1,1 ahb_off=1
cd - > /dev/null
ubus call servd notify '{"nid":16,"type":false,"pn1":"Name","pv1":"wlan2","pn2":"Status","pv2":"NotPresent"}' &
