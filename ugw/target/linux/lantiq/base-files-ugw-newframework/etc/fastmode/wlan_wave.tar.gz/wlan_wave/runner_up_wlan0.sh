ppacmd getportid -i wlan0 > /dev/null
if [ $? -eq 0 ]
then
	ppacmd dellan -i wlan0
fi
killall hostapd_cli_wlan0 2>/dev/null
hostapd_cli_count=`ps | grep hostapd_cli_wlan0 -c`
hostapd_cli_down_timeout=0
while [ $hostapd_cli_count -gt 1 ] && [ $hostapd_cli_down_timeout -lt 15 ]; do
	sleep 1
	hostapd_cli_count=`ps | grep hostapd_cli_wlan0 -c`
	hostapd_cli_down_timeout=$((hostapd_cli_down_timeout+1))
done
[ $hostapd_cli_down_timeout -eq 15 ] && echo fapi_wlan_wave_down ERROR: HOSTAPD_CLI WAS KILLED BUT DID NOT DIE ON TIME > /dev/console && exit 1
killall hostapd_wlan0 2>/dev/null
hostapd_count=`ps | grep hostapd_wlan0 -c`
down_timeout=0
while [ $hostapd_count -gt 1 ] && [ $down_timeout -lt 15 ]; do sleep 1; hostapd_count=`ps | grep hostapd_wlan0 -c`; down_timeout=$((down_timeout+1)); done
[ $down_timeout -eq 15 ] && echo fapi_wlan_wave_down ERROR: HOSTAPD WAS KILLED BUT DID NOT DIE ON TIME > /dev/console && exit 1
if_timeout=0
if_count=`ifconfig | grep wlan0 -c`
while [ $if_count -gt 0 ] && [ $if_timeout -lt 30 ]; do
sleep 1
echo fapi_wlan_wave_down WARNING: INTERFACES ARE UP AFTER HOSTAPD WAS KILLED > /dev/console
if_count=`ifconfig | grep wlan0 -c`
if_timeout=$((if_timeout+1))
done
[ $if_timeout -eq 30 ] && echo fapi_wlan_wave_down ERROR: INTERFACES ARE UP AFTER HOSTAPD WAS KILLED > /dev/console && exit 1
ubus call servd notify '{"nid":16,"type":false,"pn1":"Name","pv1":"wlan0","pn2":"Status","pv2":"Down"}' &
ubus call servd notify '{"nid":17,"type":false,"pn1":"Name","pv1":"wlan0","pn2":"Status","pv2":"Down"}' &
rm -f /tmp/hostapd_wlan0
rm -f /tmp/hostapd_cli_wlan0
iwpriv wlan0 sSetRxTH -82
echo 262144 > /proc/sys/net/core/rmem_max
cp -s /opt/lantiq/bin/hostapd /tmp/hostapd_wlan0
/tmp/hostapd_wlan0 /tmp/wlan_wave/hostapd_wlan0.conf -e /tmp/hostapd_ent_wlan0 -B
num_vaps=`grep "^bss=" -c /tmp/wlan_wave/hostapd_wlan0.conf`
num_vaps=$((num_vaps+1))
up_timeout=0
while [ `ifconfig -a | grep '^wlan0' -c` -lt $num_vaps ] && [ $up_timeout -lt 30 ]
do sleep 1; up_timeout=$((up_timeout+1)); done
cp -s /opt/lantiq/bin/hostapd_cli /tmp/hostapd_cli_wlan0
/tmp/hostapd_cli_wlan0 -iwlan0 -a/opt/lantiq/wave/scripts/fapi_wlan_wave_events_hostapd.sh -B
loop=0
while [ $loop -lt 100 ]
do
	[ $loop -eq 99 ] && echo "Error: iwconfig is not ready when RUNNER is executed !"
	ret=$(iwconfig wlan0 2>&1)
	found=`echo $ret | grep -c "No such device"`
	if [ $found -eq 0 ]
	then
		loop=100
		ubus call servd notify '{"nid":16,"type":false,"pn1":"Name","pv1":"wlan0","pn2":"Status","pv2":"Up"}' &
		ubus call servd notify '{"nid":17,"type":false,"pn1":"Name","pv1":"wlan0","pn2":"Status","pv2":"Up"}' &
	else
		sleep 1
		loop=$((loop+1))
	fi
done
iwpriv wlan0 sCoCPower 0 3 3
iwpriv wlan0 sEnableRadio 1
iwpriv wlan0 sPCoCPower 1
iwpriv wlan0 sPCoCAutoCfg 125 10000 1024000 2048000
iwpriv wlan0 sDoSimpleCLI 33 1
iwpriv wlan0 sRadarRssiTh -70
iwpriv wlan0 sAcsUpdateTo 0
iwpriv wlan0 sRTSmode 0 0
iwpriv wlan0 sFixedRateCfg 255 1 2 3 1 0 1
iwpriv wlan0 sInterfDetThresh -68 -68 -68 -68 5 -68
iwpriv wlan0 sCcaAdapt 10 5 -30 10 5 30 60
iwpriv wlan0 sAPforwarding 1
hs_cli AP_ISO -O DISABLE -I wlan0
iwpriv wlan0 sReliableMcast 1
iwpriv wlan0 sBridgeMode 0
iwpriv wlan0 sFourAddrMode 0
iwpriv wlan0 sAggrConfig 1 1
ppacmd addlan -i wlan0
echo 8 rdebug=0 > /proc/net/mtlk_log/debug
echo LogRemStream 1 wlan0 0 > /proc/net/mtlk_log/rtlog
